//
// Copyright (C) 2004 eFunds Corporation ("eFunds").  All Rights Reserved.
// eFunds Canada Corporation is an authorized user.
//
// IST is a registered trademark of eFunds Corporation.  Other brand or
// product names are trademarks or registered trademarks of their respective
// holders.
//
// The information contained herein is the unpublished proprietary property
// of eFunds.  Except as specifically authorized in writing by eFunds, the
// holder of this document shall: i) keep all information contained herein
// confidential, and ii) protect the information, in whole or in part, from
// disclosure and dissemination to all third parties.
//
// This document and the software described in it are furnished under license
// and may be used or copied only in accordance with the terms of such license.
// This document is supplied for information purposes only, is subject to
// change without notice, and should not be construed as a commitment by
// either eFunds Corporation or eFunds Canada Corporation.
//

static char ver[]="test";
static char _shcdketest_cxx_what[] = "@(#) shcdketest.cxx 1.8 12/05/29 06:39:32";

/*
 *	IST and IST/Share are registered trademarks of Oasis Technology Ltd.
 *
 *	Copyright (C) 1990 - 1997 Oasis Technology Ltd.
 *	All Rights Reserved
 *	This Module contains Proprietary Information of
 *	Oasis Technology Ltd., and should be treated as Confidential.
 *
 *	THIS IS UNPUBLISHED PROPRIETARY SOURCE CODE OF OASIS TECHNOLOGY LTD.
 *	The copyright notice above does not evidence any  
 *	actual or intended publication of such source code.
 */
/*
 *
 *    MODIFICATION HISTORY                  REVIEW
 *
 *	SPR#	Who	Date	Description			Who	Date   
 * ===========================================================================
 *          qd 24sep97  Created
 * R007062	gbeeng	26Nov2001	C++ Migration
 */
/*------------------------------------------------------------------------*
 * Include Block
 *------------------------------------------------------------------------*/
#include <stdio.h>
#include <string.h>
#include <signal.h>
#include <fcntl.h>
#include <oasis.h>
#include <ist_otrace.h>
#include <mb.h>
#include <rules.h>
#include <isttrigger.h>
#include <math.h>
#include <shc.h>
#include <ShcApp.h>
#include <ShcDKEHelper.h>

/*------------------------------------------------------------------------*
 * Function Prototype Block
 *------------------------------------------------------------------------*/
extern "C"
{
	void shcdke_exit(int n);
}


/*------------------------------------------------------------------------*
 * Main Function Block
 *------------------------------------------------------------------------*/
int main(int argc, char **argv)
{
	int  ret = 0;

	/*
	 * HouseKeeping
	 */

	argv0 = *argv;
	catch_all_signals(shcdke_exit);
	OTraceOn("shcdketest.debug");
	ist_otrace_set_level(OTRACE_DUMP);

	shcApp = new ShcApp;
	shcApp->shcDKEApiObj->shc_inc_kpecnt((char *)"0000008");

	pow((long double)2,56);	

	/*
	 * Clean up the battle fields and die in peace
	 */
	shcdke_exit(0);
	return(0);
}

/*------------------------------------------------------------------------*
 * shcdke_exit() Function Block 
 *------------------------------------------------------------------------*/
void shcdke_exit(int n)
{
	if(n == 0 || n == SIGTERM)
		OTraceInfo("I-SHC-0735: Normal Exit %d\n", n);
	else	
		OTraceWarning("W-SHC-0736: Exit due to signal %d\n", n);
			
	OTraceOff();

	if(n > 1)
		kill(getpid(), n);

	exit(n);
}
/*------------------------------------------------------------------------*
 * End of file
 *------------------------------------------------------------------------*/
