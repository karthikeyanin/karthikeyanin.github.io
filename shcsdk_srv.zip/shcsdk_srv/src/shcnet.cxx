static	char _Shcnet_cxx_what[] = "@(#) shcnet.cxx 1.11 19/11/07 16:27:31";
static	char ver[100]="IST/SHC: Version ";

/*
 *  Copyright (C) 2004 eFunds Corporation ("eFunds").  All Rights Reserved.     
 *  eFunds Canada Corporation is an authorized user.                            
 *                                                                              
 *  IST is a registered trademark of eFunds Corporation.  Other brand or        
 *  product names are trademarks or registered trademarks of their respective   
 *  holders.                                                                    
 *                                                                              
 *  The information contained herein is the unpublished proprietary property    
 *  of eFunds.  Except as specifically authorized in writing by eFunds, the     
 *  holder of this document shall: i) keep all information contained herein     
 *  confidential, and ii) protect the information, in whole or in part, from    
 *  disclosure and dissemination to all third parties.                          
 *                                                                          
 *  This document and the software described in it are furnished under license  
 *  and may be used or copied only in accordance with the terms of such license.
 *  This document is supplied for information purposes only, is subject to      
 *  change without notice, and should not be construed as a commitment by       
 *  either eFunds Corporation or eFunds Canada Corporation. 
 *
 *
 *                        MODIFICATION HISTORY                  REVIEW
 *
 * SCR#     Who    Date  Description
 * ===========================================================================
 * R0xxxxx 
 */

//File Number 133

/*****************************************************************************/

#include <stdio.h>
#include <signal.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/timeb.h>
#include <errno.h>
#include <oasis.h>
#include <mb.h>
#include <tsk.h>
#include <rules.h>
#include <config.h>
#include <ist_otrace.h>
#include <ShcMsgCache.h>
#include <CShcLog.h>
#include <shcThrottle.h>
#include <shc_callback.h>
#include <cam.h>
#include <shc_util_funcs.h>
#include <ShcnetMainLoop.h>
#include <ShcApp.h>
#include <ShcnetApp.h>
#include <TxnStat.h>

#include <HaPtmCctHelper.h>

#include <ShcAsynchApi.h>

extern "C"
{
	void	netexit(int);
}

extern ShcnetApp *shcnetApp;

int main(int argc, char **argv)
{
	argv0 = *argv;
	catch_all_signals( netexit );
	
	OTraceOn("shcnet.debug");

	HaPtmCctHelper::init() ;

	mb_init();
	dbm_init();
	shc_init();

	shcnetApp = (ShcnetApp *)shcHelperRegister.getTargetObj(SHC_ShcnetApp);
	
	if(argc > 1)                  
		shcnetApp->netname = argv[1];        
	else                          
		shcnetApp->netname = shcnetApp->default_netmgr; 

	if(shcIsAsynchSecMode())
		setAsynchMbName((const char *)shcnetApp->netname);
	
	strcat(ver, VERSION);     
	syslg("%s\n", ver);       

	TxnStatSetSrcId( TS_SHCNET ) ;
	
	ShcnetMainLoop* shcnet = ShcnetMainLoop::getInstance();
	if ( shcnet )
	{
		shcnet->registerProcessors();
		shcnet->registerBaseTxns();
		shcnet->process();
	}

	HaPtmCctHelper::cleanUp() ;
	
	//	Why not call netexit(0) as single exit fn ?
	exit ( 0 );
}



void netexit(int n)
{
	if(n == 0 || n == SIGTERM)
		syslg("I-SHC-13301: Normal exit # %d\n", n);
	else
		syslg("F-SHC-13302: Exit due to signal %d\n", n);

	dbm_close_all(dbmid);

	HaPtmCctHelper::cleanUp() ;

	OTraceOff();
	if(n > 1)
		kill(getpid(), n);
	
	exit(n);
}

