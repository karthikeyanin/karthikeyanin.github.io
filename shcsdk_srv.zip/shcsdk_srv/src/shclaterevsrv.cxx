static char _cusc_reversal_what [] = "@(#) shclaterevsrv.cxx 1.4.2.6 19/03/19 11:23:14";
/*
 *	IST and IST/Share are registered trademarks of Oasis Technology Ltd.
 *
 *	Copyright (C) 1990 - 2003 Oasis Technology Ltd.
 *	All Rights Reserved
 *	This Module contains Proprietary Information of
 *	Oasis Technology Ltd., and should be treated as Confidential.
 *
 *	THIS IS UNPUBLISHED PROPRIETARY SOURCE CODE OF OASIS TECHNOLOGY LTD.
 *	The copyright notice above does not evidence any
 *	actual or intended publication of such source code.
 */
/*
 *
 *                        MODIFICATION HISTORY                  REVIEW
 *
 *	SCR#	Who		Date	Description			Who	Date
 * ===========================================================================
 *  		yd	  	08Sept03 Created for generating late response reversal
 * R025643	sel		27Feb09	 call dbm_commit for logging 430 in shclog
 * R026229  ASh     03Apr09  Call shc_init after dbm_init to perform a proper shc initialization
 * R027905  Dipa	25Mar10	 Reversal-Void Enhancement
 * R030381  Dipa	02Mar12	 Txn statistics changes
 */


/*----------------------------------------------------------------------------
 * Include Block
 *---------------------------------------------------------------------------*/
#include <shcdef.h>
#include <dbm.h>
#include <shc.h>
#include <ShcAppBase.h>
#include <ShcmsgHeader.h>
#include <ist_otrace.h>
#include <ShcLateRev.h>
#include <ShcApp.h>
//R028271 >>> deepa
#include <TxnStat.h>
//<<< R028271

#include <HaPtmCctHelper.h>

/*----------------------------------------------------------------------------
 * Global Varible Block
 *---------------------------------------------------------------------------*/
static  char    msgbuf[sizeof(struct shc) + SHC_SEG_MAX];
static  struct  shcsegrec   shcsegrecbuf;
static  int sleep_time = -1;
struct  shc *shcP;

int		mid = -1;
/*----------------------------------------------------------------------------
 * Function Prototype Block
 *---------------------------------------------------------------------------*/
extern "C"
{

int		laterev_init();
void 	laterev_process();
void 	laterev_exit(int n);
static int 	laterev_isTraceRequest(void);

}

/**----------------------------------------------------------------------------
 * Main() Function Block
 *---------------------------------------------------------------------------*/
int main(int argc, char **argv)
{
	/**
     * Attach to system logging and trace engine
     */
	catch_all_signals(laterev_exit);

	argv0 = *argv;
	syslg("%s\n",  _cusc_reversal_what);

	OTraceOn("shclaterevsrv.debug");
	OTraceDebug("I-LATEREVDRV-00001: %s\n", _cusc_reversal_what);
	//ist_otrace_set_level(OTRACE_DEBUG);

	HaPtmCctHelper::init() ;

	/**
     * Attach to IST system: mailbox, dbm and switch
     */
	if (laterev_init() < 0)
		laterev_exit(1);

	laterev_process();

	laterev_exit(0);

	return(0);
}

/**---------------------------------------------------------------------------
 * Ist_accumu_exit() Function Block
 *---------------------------------------------------------------------------*/
void laterev_exit( int n )
{

	if(n == 0 || n == SIGTERM)
		syslg("I-shcLateRev-9999: Normal cusc_laterev_exit # %d\n", n);
	else
		syslg("F-shcLateRev-9999: Unexpected cusc_laterev_exit # %d\n", n);

	dbm_close_all(getpid());

	HaPtmCctHelper::cleanUp() ;

	OTraceOff();
	exit(n);
}

int laterev_init(void)
{
	int ret = 0;
	char buf[1024];


	mb_init();
	dbm_init();

	shcApp = thisShcApp = (ShcApp *)shcHelperRegister.getTargetObj(SHC_ShcApp);
	 shc_init(); //  --- R026229

	shcmid = mb_locatemailbox(SHC_SERVER_NAME);
	if(shcmid < 0)
    {
        OTraceFatal("F-shcLateRev-00100:Unable to locate switch at '%s'\n",
                    SHC_SERVER_NAME);
        ret = -1;
    }


	if ( mid < 0 )
	{
		if ( (mid = mb_createmailbox("shcLateRev", getpid(), 0L)) < 0 )
		{
			OTraceFatal("F-shcLateRev-00002: Unable to create required mailbox.\n");
			ret = -1;
		}
	}

	mbSetMailboxOptions(mid, MB_TAB_APPL_TRACE);

	shcsegrecbuf.segdata = msgbuf;
	shcsegrecbuf.segsize = SHC_SEG_MAX;

	HaPtmCctHelper::addHandler( "system.dcs.shc" ) ;

	if (cf_open(u_constructfile("files/shc.cfg")) >= 0)
	{
		memset(buf, 0, sizeof(buf));

	 	if ( cf_locate("shc.holdRevCheckInterval",buf) > 0)
				sleep_time = atoi(buf);
		 cf_close();
	}

	if (sleep_time < 0)
	{
		sleep_time = 60;
	}

	OTraceInfo("I-shcLateRev-00002:shc.holdRevCheckInterval %d\n", sleep_time);

	return ret;
}
static ShcmsgHeader *header = NULL;
void laterev_process()
{
	struct shcmsg 	msg;
	int				id, len;
	int				maxsize;
	int tmp_msgtype;

	ShcLateRev shcLateRev;


	shcP = (struct shc *)shcsegrecbuf.segdata;
    maxsize = sizeof(struct shcmsg) + shcsegrecbuf.segsize;

	HaPtmCctHelper::prepare() ;

	

	for( ;; )
	{
		if( HaPtmCctHelper::checkBefore() != 0 )
		{
			OTraceInfo( "I-shcLateRev-9998: Terminate by HaPtmCct\n" ) ;
			syslg( "I-shcLateRev-9998: Terminate by HaPtmCct\n" ) ;
			break ;
		}

		memset(shcP, 0, sizeof(struct shc) + SHC_SEG_MAX );

		mb_settimer(sleep_time);
		len = mb_read( mid, &shcP->msg, maxsize ) ;
		mb_unsettimer();

		if (mb_timer_expired())
		{
			OTraceInfo( "I-shcLateRev-9001:Check For orignal(unmatch Reversal)\n");
			shcLateRev.checkForOrig(0, NULL);
			if (dbm_commit(getpid()) < 0)
				OTraceDebug("I-shcLateRev-10007: DBM Commit Failed\n");

			 continue;
		}

		if( len < 0 )
		{
			if( mb_test() < 0 ) break ;
			continue ;
		}

		if ( laterev_isTraceRequest() )
			continue;

		id = mbLastSenderId();

		if (len < 100)
		{
			// Command
			OTraceInfo( "I-SHCLRS-8999:CMD %s\n", (char *)&shcP->msg);
			if (strncmp("SCANALL", (char *)&shcP->msg, 7) == 0)
			{
			 	OTraceInfo( "I-shcLateRev-9001.1:Check For orignal(unmatch Reversal)\n");
				shcLateRev.checkForOrig(0, NULL);
				if (dbm_commit(getpid()) < 0)
					OTraceDebug("I-shcLateRev-10008: DBM Commit Failed\n");
			}
			if (strncmp("SCANONE", (char *)&shcP->msg, 7) == 0)
			{
				char *ptr = NULL;

				int site_id = 0;
				char logid[21];
				memset (logid, 0, sizeof(logid));

				ptr = strtok((char *)&shcP->msg, " ");
				ptr = strtok( NULL, " ");
				if (ptr != NULL)
				{
					site_id = atoi(ptr);
					ptr = strtok( NULL, " ");
					if (ptr != NULL)
					{
						strncpy(logid, ptr, 20);
					}
				}


			 	OTraceInfo( "I-shcLateRev-9001.2:Check For orignal(unmatch Reversal) %d %s\n", site_id, logid);
				shcLateRev.checkForOrig(site_id, logid);
				if (dbm_commit(getpid()) < 0)
					OTraceDebug("I-shcLateRev-10009: DBM Commit Failed\n");
			}

			continue;
		}

		if (header)
			delete header;
		
		tmp_msgtype = 0;
		if (shcP->msg.msgtype == (SHC_REVREQ_ADVICE + 1000) || shcP->msg.msgtype == (SHC_REVREQ + 1000))
		{
			tmp_msgtype = shcP->msg.msgtype;
			shcP->msg.msgtype -= 1000;
		}

		ShcHeader *tmpHeader = shcHeaderRegister.getTargetObj( &shcP->msg);
		if( ! tmpHeader
		 || strncmp(tmpHeader->getName(), SHC_ShcmsgHeader, strlen(SHC_ShcmsgHeader))!= 0)
		{
			OTraceInfo("I-shcLateRev-401:Not ShcmsgHeader[%s], ignore\n",
					tmpHeader?tmpHeader->getName():"<NULL>" );
			continue;
		}
		header = (ShcmsgHeader *)tmpHeader;

		if (!header)
		{
			OTraceError("E-LateRev-0409:Can't classify this message[%d]\n", shcP->msg.msgtype);
			continue;
		}

		if (tmp_msgtype != 0)
		{
			header->msg.msgtype = tmp_msgtype;
		}
		OTraceDebug("I-LateRev-0384:ID[%s]m%04d/t%06d/p%06d/r%02d/c%s/tid:%s/ld:%ld/lt:%ld/mb%d\n",
			header->msg.shclog_id, header->msg.msgtype,
			header->msg.trace, header->msg.pcode, header->msg.respcode, shc_maskpan(header->msg.pan),header->msg.termid, header->msg.local_date, header->msg.local_time, id);

		//R028271 >>>
		if (strlen(header->msg.shclog_id))
			TxnStatReport(header->msg.shclog_id, TS_SHC,TSR_RECEIVE,header->msg.msgtype,0,id);
		//<<< R028271

		if (header->msg.msgtype == (SHC_REVREQ_ADVICE + 1000) || header->msg.msgtype == (SHC_REVREQ + 1000)) 
		{
			shcLateRev.rev_nooriginal(header);
		}
		else if (header->msg.msgtype == SHC_REVREQ_ADVICE || header->msg.msgtype == SHC_REVREQ) // 0420 (or) 400(R027905)
		{
			shcLateRev.rev_request(header);
		}
		else if (header->msg.msgtype == SHC_FINREQ_RESPONSE || header->msg.msgtype == SHC_AUTHREQ_RESPONSE) // 0210 (or) 0110 (R027905)
		{
			shcLateRev.fin_request(header);
		}
		//R027905 >>>
		else if ((header->msg.msgtype == SHC_FINREQ || header->msg.msgtype == SHC_AUTHREQ) &&
				  header->isVoidTxn())
		{
			shcLateRev.rev_request(header);
		}
		// <<< R027905

		// >>> R025643
		if (dbm_commit(getpid()) < 0)
			OTraceDebug("I-shcLateRev-00007: DBM Commit Failed\n");
		//	<<<	R025643
	}
}

static int laterev_isTraceRequest(void)
{
	if(mbIsApplTraceRequest())
	{
		if(mbIsApplTraceStart())
		{
			ist_otrace_set_level(OTRACE_DEBUG);
			OTraceDebug("I-LATEREVDRV-00005: Trace - ON.\n");
		}
		else if(mbIsApplTraceStop())
		{
			OTraceDebug("I-LATEREVDRV-00006: Trace - OFF.\n");
			ist_otrace_set_level(OTRACE_ERROR);
		}
		return(True);
	}

	return(False);
}
/*----------------------------------------------------------------------------
 * End of File
 *---------------------------------------------------------------------------*/
