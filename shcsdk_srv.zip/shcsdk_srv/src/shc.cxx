static	char _Shc_cxx_what[] = "@(#) shc.cxx 1.14 13/07/05 15:41:13";
static	char ver[100]="IST/SHC: Version ";

/*
 *  Copyright (C) 2004-2005 eFunds Corporation ("eFunds").  All Rights Reserved.     
 *  eFunds Canada Corporation is an authorized user.                            
 *                                                                              
 *  IST is a registered trademark of eFunds Corporation.  Other brand or        
 *  product names are trademarks or registered trademarks of their respective   
 *  holders.                                                                    
 *                                                                              
 *  The information contained herein is the unpublished proprietary property    
 *  of eFunds.  Except as specifically authorized in writing by eFunds, the     
 *  holder of this document shall: i) keep all information contained herein     
 *  confidential, and ii) protect the information, in whole or in part, from    
 *  disclosure and dissemination to all third parties.                          
 *                                                                          
 *  This document and the software described in it are furnished under license  
 *  and may be used or copied only in accordance with the terms of such license.
 *  This document is supplied for information purposes only, is subject to      
 *  change without notice, and should not be construed as a commitment by       
 *  either eFunds Corporation or eFunds Canada Corporation. 
 *
 *
 *                        MODIFICATION HISTORY                  REVIEW
 *
 * SCR#     Who    Date  Description
 * ===========================================================================
 * R0xxxxx 
 * R018276 pve	27Nov06	Remove excessive syslg messages 
 */

//File Number 131

/*****************************************************************************/

#include <stdio.h>
#include <signal.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/timeb.h>
#include <errno.h>
#include <oasis.h>
#include <mb.h>
#include <tsk.h>
#include <rules.h>

#include <ist_otrace.h>
#include <ShcMsgCache.h>
#include <shcThrottle.h>
#include <shc_callback.h>
#include <cam.h>
#include <shc_util_funcs.h>
#include <ShcMainLoop.h>
#include <config.h>
#include <TxnStat.h>

#include <HaPtmCctHelper.h>

extern "C" void shcexit(int n);

#if defined(MB_LICENSE_CHECK)
#include <oasisenv.h>
#include <string.h>
#include <sys/stat.h>
#include <unistd.h>
#include <lserv.h>
#define myErrorHandler p34057327
#define LMan y2325782
#define check p03977895
#define release js32985734

extern "C" LS_STATUS_CODE myErrorHandler(LS_STATUS_CODE cd, char *featureName)
{
	const char *msg = 0;
	
	switch (cd)
	{
	case VLS_APP_NODE_LOCKED: 	msg = "Node locked"; break;
	case VLS_APP_UNNAMED:		msg = "Unnamed"; break;
	case VLS_CALLING_ERROR:		msg = "Calling error"; break;
	case VLS_HOST_UNKNOWN:		msg = "Host unknown"; break;
	case VLS_INTERNAL_ERROR:	msg = "Internal error"; break;
	// we don't want messages showing up if we call VLSrelease when we do not hold a token
	case VLS_NO_KEY_TO_RETURN:	msg = 0; break;
	case VLS_NO_LICENSE_GIVEN:	msg = "No license given"; break;
	case VLS_NO_RESPONSE_TO_BROADCAST: msg = "No response to broadcast"; break;
	case VLS_NO_SERVER_FILE:	msg = "No server file"; break;
	case VLS_NO_SERVER_RESPONSE:msg = "No server response"; break;
	case VLS_NO_SERVER_RUNNING:	msg = "No server running"; break;
	case VLS_NO_SUCH_FEATURE:	msg = "License string not found"; break;
	case VLS_RETURN_FAILED:		msg = "Return failed"; break;
	case VLS_SEVERE_INTERNAL_ERROR:	msg = "Severe internal error"; break;
	case VLS_UNKNOWN_SHARED_ID:	msg = "Unknown shared id"; break;
	case VLS_USER_EXCLUDED:		msg = "User excluded"; break;
	default: msg = "Unknown error"; break;
	}
	if (msg != 0)
		OTraceError("E-SHC : %s (%d)\n", msg, cd);
	return cd;
}

class LMan
{
	bool valid_handle;
	bool initialized;
	LS_HANDLE lshandle;
	unsigned long secs_left;
	time_t start_time;
	time_t last_warned;
	const char *_fname;
	time_t last_mtime;
	const char *fname()
	{
		if (_fname == 0)
			_fname = strdup(uenv_constructfile(OSITE_ROOT_ENV, "cfg/lservrc"));
		return _fname;
	};
	bool file_changed()
	{
		struct stat stat_str;
		memset(&stat_str, 0, sizeof(stat_str));
		if (stat(fname(), &stat_str) != 0)
		{
			OTraceError("E-SHC : Failed to locate license file, errno=%d\n", errno);
			last_mtime = 0;
			return true;
		}
		if (last_mtime != 0 && stat_str.st_mtime == last_mtime)
			return false;
		last_mtime = stat_str.st_mtime;
		return true;
	};
	int get_handle()
	{
		unsigned char publisher[30];
		publisher[18] = '\0';
		publisher[1] = 'a';
		publisher[7] = 'c';
		publisher[17] = 'd';
		publisher[6] = 'e';
		publisher[13] = 'g';
		publisher[8] = 'h';
		publisher[3] = 'i';
		publisher[11] = 'l';
		publisher[15] = 'L';
		publisher[9] = 'n';
		publisher[10] = 'o';
		publisher[12] = 'o';
		publisher[0] = 'O';
		publisher[2] = 's';
		publisher[4] = 's';
		publisher[16] = 't';
		publisher[5] = 'T';
		publisher[14] = 'y';
		unsigned char feature[10];
		feature[3] = '\0';
		feature[2] = 'c';
		feature[1] = 'h';
		feature[0] = 's';

		unsigned char version[10] = {0};
		{
			const unsigned char *src = (const unsigned char *)VERSION;
			unsigned char *dest = version;
			while (*src != '\0' && *src != '.')
				*dest++ = *src++;
			*dest = '\0';
		}
		if (!initialized)
		{
			{
				// new SentinelLM 7.2 feature, skip "putenv"
				// it must be called BEFORE VLSinitialize, otherwise it will cause trouble after 2-3 calls
				int lm_ret = VLSsetFileName(VLS_LSERVRC, (unsigned char *)fname(), 0, 0);
				if (lm_ret != LS_SUCCESS)
				{
					OTraceFatal("F-SHC : Failed to initialize license file path, error=%d\n", lm_ret);
					return -1;
				}
			}

#			if defined( HAS_VLScontrolRemoteSession )
				VLScontrolRemoteSession( VLS_OFF ) ;
#			endif

			if (VLSinitialize() != LS_SUCCESS)
			{
				VLScleanup();
				//if (show_msg)
					OTraceError("E-SHC : License initialization error\n");
				return -1;
			}
			initialized = true;
		}
		VLSsetErrorHandler(myErrorHandler, VLS_APP_NODE_LOCKED);
		VLSsetErrorHandler(myErrorHandler, VLS_APP_UNNAMED);
		VLSsetErrorHandler(myErrorHandler, VLS_CALLING_ERROR);
		VLSsetErrorHandler(myErrorHandler, VLS_HOST_UNKNOWN);
		VLSsetErrorHandler(myErrorHandler, VLS_INTERNAL_ERROR);
		VLSsetErrorHandler(myErrorHandler, VLS_NO_KEY_TO_RETURN);
		VLSsetErrorHandler(myErrorHandler, VLS_NO_LICENSE_GIVEN);
		VLSsetErrorHandler(myErrorHandler, VLS_NO_RESPONSE_TO_BROADCAST);
		VLSsetErrorHandler(myErrorHandler, VLS_NO_SERVER_FILE);
		VLSsetErrorHandler(myErrorHandler, VLS_NO_SERVER_RESPONSE);
		VLSsetErrorHandler(myErrorHandler, VLS_NO_SERVER_RUNNING);
		VLSsetErrorHandler(myErrorHandler, VLS_NO_SUCH_FEATURE);
		VLSsetErrorHandler(myErrorHandler, VLS_RETURN_FAILED);
		VLSsetErrorHandler(myErrorHandler, VLS_SEVERE_INTERNAL_ERROR);
		VLSsetErrorHandler(myErrorHandler, VLS_UNKNOWN_SHARED_ID);
		VLSsetErrorHandler(myErrorHandler, VLS_USER_EXCLUDED);
		int lm_ret = LSRequest(LS_ANY, publisher, feature, version, 0, 0, 0, &lshandle);
		if (lm_ret != LS_SUCCESS)
		{
			static const char msg[] = "License initialization error: %d\n";
			OTraceInfo(msg, lm_ret);
			//syslg(msg, lm_ret);	//	R018276
			release();
			return -1;
		}
		if (VLSdisableAutoTimer(lshandle, VLS_OFF) != LS_SUCCESS)
		{
			static const char msg[] = "WARNING: License initialization error: %d\n";
			OTraceError(msg, lm_ret);
		}
		secs_left = 999999999;
		start_time = time(0);
#if defined(CHECK_LICENSE_EXPIRY)
		lm_ret = VLSgetFeatureTimeLeftFromHandle(lshandle, &secs_left);

		if (lm_ret != LS_SUCCESS)
		{
			OTraceError("E-SHC : License initialization error (non-fatal): %d\n", lm_ret);
			secs_left = 999999999;
		}
#endif
		//OTraceInfo("I-SHC : Time left: %d\n", secs_left);
		return 0;
	};
public:
	LMan() : 
		valid_handle(false),
		initialized(false),
		secs_left(0),
		start_time(0),
		last_warned(0),
		_fname(0),
		last_mtime(0)
	{ };
	~LMan() 
	{ 
		release(); 
		if (_fname != 0) 
			free((void *)_fname); 
		_fname = 0; 
	};
	bool check()
	{
		for (;;)
		{
			if (!valid_handle)
			{
				if (file_changed())
				{
					release();
					valid_handle = (get_handle() == 0);
				}
			}
			if (!valid_handle)
				return false;
#if defined(CHECK_LICENSE_EXPIRY)
			//
			// we won't use this
			//
			const time_t curr_time = time(0);
			const int elapsed = curr_time - start_time;
			// LSUpdate does nothing in standalone version (does not detect that the license has
			// expired since it was acquired)
			if (elapsed >= secs_left)
			{
				LSRelease(lshandle, LS_DEFAULT_UNITS, 0);
				// perhaps it got updated?
				valid_handle = false;
				VLScleanup();
				continue;
			}
			if ((elapsed + 86400*60) > secs_left)
			{
				// we are in warning territory
				if (last_warned == 0 || (curr_time - last_warned) > 7200)
				{
					last_warned = curr_time;
					const char msg[] = "D-SHC-131000: WARNING: Your license will expire in %d %s\n";
					if (secs_left < 86400)
						OTraceDebug(msg, secs_left/3600, "hours");	//	R018276
					else
						OTraceDebug(msg, secs_left/86400, "days");	//	R018276
				}
			}
#endif
			// this is ineffective for libnonet
#if 0
			int lm_ret = LSUpdate(lshandle, LS_DEFAULT_UNITS, 0, 0, 0);
			if (lm_ret != LS_SUCCESS)
			{
				release();
			}
#endif
			break;
		}
		return true;
	};
	void release()
	{
		if (initialized)
		{
			if (valid_handle)
			{
				LSRelease(lshandle, LS_DEFAULT_UNITS, 0);
				valid_handle = false;
			}
			VLScleanup();
			initialized = false;
		}
	};
};
#endif


static int   call_dbm_init = (0); 

int main(int argc, char **argv)
{
	argv0 = *argv;
	catch_all_signals( shcexit );
#if defined(Linux) && defined(CATCH_FATAL_SIGNALS)
	CATCH_FATAL_SIGNALS(shcexit);
#endif
	
	syslg("%s\n", ver);	//	R018276

	OTraceOn("shc.debug");
	ODumpOn("shcdump.debug");

	TxnStatSetSrcId( TS_SHC ) ;

	HaPtmCctHelper::init() ;
	
	if( argc > 1 )
	{
		ODebug("I-SHC-131001: %s %s\n", ver, VERSION );
		exit( 0 );
	}
	
	ShcMainLoop* shc = ShcMainLoop::getInstance();
#if defined(MB_LICENSE_CHECK)
	LMan lm;
	if (!lm.check())
		shcexit(TSK_EXIT_NORELOAD);
#endif
	shc->registerProcessors();
	shc->registerBaseTxns();
	shc->process();

	HaPtmCctHelper::cleanUp() ;
	
	//  Why not call shcexit(0) as single exit fn ?
	exit ( 0 );
}


/*****************************************************************************/


void shcexit(int n)
{
	static int	count = 0;


	if(n == 0 || n == SIGTERM)
	{
		syslg("I-SHC-131002: Normal Exit # %d.\n", n);
		OTraceInfo("I-SHC-131003: Normal Exit # %d.\n", n);
	}
	else
	{
		OTraceFatal("F-SHC-131004: Exit Due to Signal %d\n", n);
	}
	
	/*  Release semaphore, if locked by this process.  */
	if(++count == 1)
		if(sem_exit(MB_BUF_SEM_NAME) == 0)
			OTraceFatal("F-SHC-131005: Unlocked semaphore '%s' in exit function\n", MB_BUF_SEM_NAME);

	if (call_dbm_init == 1)
		dbm_close_all(dbmid);
	
	/*  Delete private mailbox for camsrv  */
    cam_delete_private_mbox();

	HaPtmCctHelper::cleanUp() ;

	mb_disconnect();
		
	OTraceOff();

	struct sigaction act;
	memset(&act, 0, sizeof(act));
	act.sa_handler = SIG_DFL;
	sigaction(n, &act, 0 );

	if(n > 1)
		kill(getpid(), n);

	exit(n);
}

