static char _ShcnetMainLoop_cxx_what[] = "@(#) ShcnetMainLoop.cxx 1.25 19/11/11 08:49:05" ;

/*
 *  Copyright (C) 2004 eFunds Corporation ("eFunds").  All Rights Reserved.
 *  eFunds Canada Corporation is an authorized user.
 *
 *  IST is a registered trademark of eFunds Corporation.  Other brand or
 *  product names are trademarks or registered trademarks of their respective
 *  holders.
 *
 *  The information contained herein is the unpublished proprietary property
 *  of eFunds.  Except as specifically authorized in writing by eFunds, the
 *  holder of this document shall: i) keep all information contained herein
 *  confidential, and ii) protect the information, in whole or in part, from
 *  disclosure and dissemination to all third parties.
 *
 *  This document and the software described in it are furnished under license
 *  and may be used or copied only in accordance with the terms of such license.
 *  This document is supplied for information purposes only, is subject to
 *  change without notice, and should not be construed as a commitment by
 *  either eFunds Corporation or eFunds Canada Corporation.
 *
 *
 *                        MODIFICATION HISTORY                  REVIEW
 *
 * SCR#     Who    Date  Description
 * ===========================================================================
 * R0xxxxx jyang 10Oct03 Created
 * R018276 pve	 27Nov06 Remove excessive syslg messages
 * R026142 vmp	 06Mar09 eventId '0' is valid
 * R028271 dipa  21Jun10 Txn Statistics
 * R028305 dipa  09Jul10 CCT and PTM
 * R030207 dipa  06Feb12 Clone of R030000, R030034
 */

 //File Number 134

/*****************************************************************************/

#include <sys/timeb.h>
#include <mb_umi.h>
#include <CShcLog.h>
#include <ShcMsgCache.h>
#include <ShcmsgProcessor.h>
#include <shc.h>
#include <shcThrottle.h>
#include <shc_callback.h>
#include <ist_otrace.h>
#include <ShcmsgHelper.h>
#include <ShcCamHelper.h>
#include <ShcFinAuthHelper.h>
#include <ShcIBFTHelper.h>
#include <ShcKeyHelper.h>
#include <ShcMacHelper.h>
#include <ShcNetworkMsgHelper.h>
#include <CShcNotify.h>
#include <ShcPreauthHelper.h>
#include <ShcSaf.h>
#include <ShcTimerHelper.h>
#include <ShcnetMainLoop.h>
#include <ShcnetApp.h>
#include <ShcnetApp.h>
#include <shc500std.h>
#include <ShcProcessorRegistration.h>
#include <ShcHelper.h>
#include <TxnStat.h>
#include <mb_umi.h>
#include <HaPtmCctHelper.h>
#include <istsafe.h>

// #include <ist_seg_name.h>
// #include <ist_seg_elf_id_map.h>
// #include <ist_seg_id.h>
// #include <ist_seg_msg_replication_data.h>

#include <ShcAsynchApi.h>
// #include <asynchSecApi.h>

extern "C"
{
	void	netexit(int);
}

extern int getAsynchEvent(char *readBuf,int &len,int readSize,struct shcmsg *oMsg);
int ShcnetMainLoop::_initialized = 0;
ShcnetMainLoop *ShcnetMainLoop::_instance    = 0;
struct shcsegrec  ShcnetMainLoop::shcsegrecbuf = {0};
ShcnetApp *shcnetApp = NULL;
ShcnetMainLoop* ShcnetMainLoop::getInstance()
{
	if ( !_instance )
	{
		_instance = new ShcnetMainLoop;
	}
	return _instance;
}

ShcnetMainLoop::ShcnetMainLoop()
{
	if ( _initialized <= 0 )
	{
		if ( (_initialized=initialize()) < 0 )
			OTraceFatal("F-SHC-13401: Failed to create a ShcnetMainLoop object.\n");
	}

}

int ShcnetMainLoop::initialize()
{

	dbmid = getpid();
	/*
	 *	Initialise the network system
	 */
	shcApp = thisShcApp= shcnetApp;

	shcApp->shcHelperObj->shc_init();
	/*
	 *	o	Find the shared cash manager
	 */
	shcnetApp->shcid = mb_locatemailbox(SHC_SERVER_NAME);
	if(shcnetApp->shcid < 0)
	{
		OTraceFatal("F-SHC-13402:  Unable to locate the shared cash server: %s\n", SHC_SERVER_NAME);
		netexit(0);
	}

	/*
	 *	o	Create an entry for my self
	 */
	if((shcApp->netid = mb_locatemailbox(shcnetApp->netname)) < 0)
	{
		if((shcApp->netid = mb_createmailbox(shcnetApp->netname, 0, MB_TAB_APPL_TRACE)) < 0)
		{
			OTraceFatal("F-SHC-13403: Unable to locate or create entry %s\n", shcnetApp->netname);
			netexit(0);
		}
	}
	else
	{
		 mbSetMailboxOptions(shcApp->netid,MB_TAB_APPL_TRACE);
	}

	//This is new in sdk in order to support callback in shcnet
    /* Read Configuration file and build Factory and Table */
    if (readCallBackConfig() < 0)
    {
        OTraceFatal("F-SHC-13414: Reading CallBack Configuration Parameters failed.\n");		//	R018276
    }


	shcmid = shcnetApp->shcid;

	/*	Initialise the segment message */
	shcsegrecbuf.segdata = (char *)calloc(1, SHC_SEG_MAX + sizeof(ShcmsgHeader));	// length changed !
	if(shcsegrecbuf.segdata == NULL)
	{
		OTraceFatal("F-SHC-13404: Unable to allocate segment data.\n");
		netexit( -4 );
	}

	shcsegrecbuf.segsize = SHC_SEG_MAX;

	return 0;
}

int ShcnetMainLoop::registerProcessors()
{
	return 0;
}

int ShcnetMainLoop::registerBaseTxns()
{
	return 0;
}
ShcProcessor *ShcnetMainLoop::processQueue()
{
	ShcProcessor *nextProcessor = shcApp->msgQueue.front();
	if (nextProcessor)
		shcApp->msgQueue.remove();
	return nextProcessor;

}

int ShcnetMainLoop::process()
{
	int		len;
	int		eventId = -1;

	OTraceInfo("I-SHC-13405: Starts working ...\n");
	int		readSize = sizeof(struct shcmsg) + shcsegrecbuf.segsize;
	char   *readBuf = shcsegrecbuf.segdata;
	struct shcmsg *msgp;
	//struct asynchRespBuf asynchResp;

	HaPtmCctHelper::prepare() ;

	for(;;)
	{
		memset(readBuf, 0, readSize);
		memset(&routingRecord, 0, sizeof(routingRecord));

		// R0xxxxx Process tasks in the queue
		if ((shcProcessor = (ShcProcessor *)processQueue()) == NULL)		
		{
			//	-rc-
			//	When there is nothing in the local-Q, read from mbox
			//	This is the point when process can be terminated by HaPtmCct
			//	local-Q must be cleared before possible termination

			if( HaPtmCctHelper::checkBefore() != 0 )
			{
				OTraceInfo( "I-SHC-13405.1: Terminate due to HaPtmCct\n" );
				syslg( "I-SHC-13405.1: Terminate due to HaPtmCct\n" );
				break ;
			}


			len = mb_read( shcApp->netid, readBuf, readSize ) ;
			if( len < 0 )
			{
				if( mb_test() < 0 ) break ;
				//	-rc-
				//	continue to check local-Q again - it is fine since it is empty
				//	followed by checkBefore() - will terminate if it should
				continue ;
			}

			eventId = -1;
			if(mbIsApplTraceRequest())
			{
				if(mbIsApplTraceStart())
				{
					OTraceInfo("I-SHC-13408: Request to turn on tracing.\n");
					ist_otrace_set_level(OTRACE_DEBUG); /* switch routine debug on */
				}
				else if(mbIsApplTraceStop())
				{
					OTraceInfo("I-SHC-13409: Request to turn off tracing.\n");
					ist_otrace_set_level(OTRACE_NONE); /* switch routine debug off */
				}
				continue;
			}
			else if(mbIsEvent())
			{
				((struct shcmsg *)readBuf)->msgtype += SHC_EVENT;
				tm_dequeue(mbLastEvent());
				eventId		= mbLastEvent();
			}

			if ((strncmp(readBuf, "conn", 4)==0) || (strncmp(readBuf, "disc", 4)==0))
			{
				// struct shcmsg *msgp = (struct shcmsg *)readBuf;
				msgp = (struct shcmsg *)readBuf;
				char tmpBuf[sizeof(msgp->pan)] = { 0 };
				strncpy(tmpBuf, readBuf, sizeof(tmpBuf)-1);
				msgp->msgtype = SHC_NETWORK_PORT_NOTIFICATION;
				msgp->flipped_msgtype = 0; //Clear garbage
				istsafe_strcpy(msgp->pan,sizeof(msgp->pan), tmpBuf);

				int txnIdLen=0;
				mb_get_tid(msgp->shclog_id,sizeof(msgp->shclog_id),&txnIdLen);
				if (!txnIdLen)
				{
					mb_getUmi(msgp->shclog_id, sizeof(msgp->shclog_id));
				}
				TxnStatReport(msgp->shclog_id,
					TS_SHC,TSR_RECEIVE,msgp->msgtype,0,mbLastSenderId());
				
			}

			msgp = (struct shcmsg *)readBuf;
			if(shcIsAsynchSecMode() && strstr(mbMailBoxName(mbLastSenderId()),SECURITY_MBOX_NAME))
			{
				getAsynchEvent(readBuf,len,readSize,msgp);
			}

			if ((mbLastSenderId() == shcmid ) && (shcmsgIsResponse((struct shcmsg *)readBuf)))
				respMsgFromShc = 1;
			else
				respMsgFromShc = 0;

			if (shcmsgIsSettlement((struct shcmsg *)readBuf) ||
				((struct shcmsg *)readBuf)->msgtype == SHC500_MSG_DAYEND ||
				((struct shcmsg *)readBuf)->msgtype == (SHC500_MSG_DAYEND + 10))
			{

				if(!(((struct shc500std *)readBuf)->shclog_id[0]))
				{
					int txnIdLen=-1;
					if(mb_get_tid(((struct  shc500std *)readBuf)->shclog_id,sizeof(((struct  shc500std *)readBuf)->shclog_id),&txnIdLen) <= 0)
					{
						//Do not create txnid..Anyway, this txn will be dropped right away.
					}
				}

				if(strlen(((struct shc500std *)readBuf)->shclog_id))
				{
					//Received...
					TxnStatReport(((struct shc500std *)readBuf)->shclog_id,
						TS_SHC,TSR_RECEIVE,((struct shc500std *)readBuf)->msgtype,0,mbLastSenderId());
					//...and Dropped
					TxnStatReport(((struct shc500std *)readBuf)->shclog_id,
						TS_SHC,TSR_DROP,DROP_MSG_UNCLASSIFIED,0,0);
				}

				OTraceLog("L-SHC-13412: Drop Post-cutover reconciliation message ID[%s] /m%04d\n",
					((struct  shc500std *)readBuf)->shclog_id,
					((struct  shc500std *)readBuf)->msgtype);
				continue;
			}
			else
			{
				if(!(((struct shcmsg *)readBuf)->shclog_id[0]))
				{
					mb_getUmi(((struct  shcmsg *)readBuf)->shclog_id,sizeof(((struct  shcmsg *)readBuf)->shclog_id)); //R030034
				}
				mb_set_tid(((struct  shcmsg *)readBuf)->shclog_id,strlen(((struct  shcmsg *)readBuf)->shclog_id));
				TxnStatReport(((struct  shcmsg *)readBuf)->shclog_id,
					TS_SHC,TSR_RECEIVE,((struct  shcmsg *)readBuf)->msgtype,0,mbLastSenderId());

				OTraceLog("L-SHC-13413: Received %d bytes from %s ID[%s] /m%04d/t%d/p%06d\n",
					len, mbMailBoxName(mbLastSenderId()),
					((struct  shcmsg *)readBuf)->shclog_id,
					((struct  shcmsg *)readBuf)->msgtype,
					((struct  shcmsg *)readBuf)->trace,
					((struct  shcmsg *)readBuf)->pcode);
			}
			shcProcessor = shcProcessorRegistration.getTargetObj(readBuf);
		}

		if ( shcProcessor )
		{
			if (eventId >= 0)
				shcProcessor->header->eventId = eventId;
			else
			{
				shcProcessor->header->shcerr&=~SH_IGNORE;
			}

			shcProcessor->header->setTxnStartTime();
			if(shcIsAsynchSecMode() && strstr(mbMailBoxName(mbLastSenderId()),SECURITY_MBOX_NAME))
			{
				msgp = (struct shcmsg *)readBuf;
				setAsynchTxnFlgs(shcProcessor->header,msgp);
				OTraceDebug("D-SHC-001103 Set Proc Flags [0x%08x] ShcErr[0x%08x] Log[%08x]\n",
					shcProcessor->header->procFlag,shcProcessor->header->shcerr,shcProcessor->header->logFlag);
			}

			shcProcessor->process();
			delete shcProcessor;
		}
		else
		{
			if(((struct shcmsg *)readBuf)->shclog_id[0])
				TxnStatReport(((struct shcmsg *)readBuf)->shclog_id,TS_SHC,TSR_DROP,DROP_MSG_UNCLASSIFIED,0,0);

			OTraceLog("L-SHC-13415: Can't classify this message, Drop message ID[%s]/m%04d\n",
                    ((struct  shcmsg *)readBuf)->shclog_id,
                    ((struct  shcmsg *)readBuf)->msgtype);
		}

	}

	return(0);
}
