static char _ShcMainLoop_cxx_what[] = "@(#) ShcMainLoop.cxx 1.34.10.3 19/10/29 18:06:17";

/*
 *  Copyright (C) 2004 eFunds Corporation ("eFunds").  All Rights Reserved.
 *  eFunds Canada Corporation is an authorized user.
 *
 *  IST is a registered trademark of eFunds Corporation.  Other brand or
 *  product names are trademarks or registered trademarks of their respective
 *  holders.
 *
 *  The information contained herein is the unpublished proprietary property
 *  of eFunds.  Except as specifically authorized in writing by eFunds, the
 *  holder of this document shall: i) keep all information contained herein
 *  confidential, and ii) protect the information, in whole or in part, from
 *  disclosure and dissemination to all third parties.
 *
 *  This document and the software described in it are furnished under license
 *  and may be used or copied only in accordance with the terms of such license.
 *  This document is supplied for information purposes only, is subject to
 *  change without notice, and should not be construed as a commitment by
 *  either eFunds Corporation or eFunds Canada Corporation.
 *
 *
 *                        MODIFICATION HISTORY                  REVIEW
 *
 * SCR#     Who    Date  Description
 * ===========================================================================
 * R0xxxxx jyang 10Oct03 Created
 * R018276 pve	 27Nov06 Remove excessive syslg messages and add new OTraceLog messages
 * R024672 MPS   16Sep08 Transaction amount is printed as $0.00 in SHC Debug
 * R026142 vmp	 06Mar09 eventId '0' is valid
 * R028271 dipa  21Jun10 Txn Statistics
 * R028305 dipa  09Jul10 CCT and PTM
 * R028557 dipa  20Sep10 Txn Statistics - correction
 * R028821 dipa  28Dec10 WR33700 - Interface to Data query tool
 * R028821 dipa  12Jan11 WR33700 - Commented out the changes done - to be release after integ. testing is done
 * R028821 dipa  16Feb11 WR33700 - Change the commenting style
 * R030207 dipa	 06Feb12 Clone of R029751, R030000, R030034
 * R030381 dipa  02Mar12 Txn statistics changes
 */

 //File Number 132

/*****************************************************************************/

#include <sys/timeb.h>
#include <ShcMsgCache.h>
#include <ShcProcessor.h>
#include <shc.h>
#include <shcThrottle.h>
#include <shc_callback.h>
#include <ist_otrace.h>
#include <ShcmsgHelper.h>
#include <ShcCamHelper.h>
#include <ShcFinAuthHelper.h>
#include <ShcIBFTHelper.h>
#include <ShcKeyHelper.h>
#include <ShcMacHelper.h>
#include <ShcNetworkMsgHelper.h>
#include <CShcNotify.h>
#include <ShcPreauthHelper.h>
#include <ShcSaf.h>
#include <ShcTimerHelper.h>
#include <ShcMainLoop.h>
#include <ShcApp.h>
#include <ShcmsgEventHelper.h>
#include <ShcnetApp.h>
#include <Shc300Helper.h>
#include <ShcHelper.h>
#include <ShcProcessorRegistration.h>
#include <ShcmsgFMHeader.h>
#include <ShcmsgODHeader.h>
#include <BinRoute.h>
#include <TxnStat.h>
#include <mb_umi.h>
#include <HaPtmCctHelper.h>
#include <istsafe.h>
#include <ShcAsynchApi.h>

extern "C" void shcexit(int n);
int do_shcmsg_throttle_action(char* throttleString, int level, void* msg, int msglen);

int ShcMainLoop::_initialized = 0;
int ShcMainLoop::call_dbm_init = 0;
ShcMainLoop *ShcMainLoop::_instance    = 0;
struct shcsegrec  ShcMainLoop::shcsegrecbuf = {0};
//ShcnetApp *shcnetApp = NULL;
extern int shcIsAsynchSecMode();
extern int getAsynchEvent(char *readBuf,int &len,int readSize,struct shcmsg *oMsg);
//extern int isAsynchCmdTrnsltPin(int iCmd);
//int setAsynchTxnFlgs(ShcProcessor* shcProcessor,struct  shcmsg *shcmsgP);

ShcMainLoop* ShcMainLoop::getInstance()
{
	if ( !_instance )
	{
		_instance = new ShcMainLoop;
	}
	return _instance;
}

ShcMainLoop::ShcMainLoop()
{
	if ( _initialized <= 0 )
	{
		if ( (_initialized=initialize()) < 0 )
			log_msg(FATAL, TO_CC, "F-SHC-13201: Failed to create a ShcMainLoop object.\n");
	}

}

int ShcMainLoop::initialize()
{
	mb_init();
	dbm_init();

	if (!thisShcApp)
		shcApp = thisShcApp = (ShcApp *)shcHelperRegister.getTargetObj(SHC_ShcApp);
	if (!shcApp)
	{
		OTraceFatal("Can't register ShcApp class, aborting\n");
		shcexit(13);
	}


	/*  Register my server  */
	if ( (::shcmid=mb_createmailbox("SharedCash", 0, MB_TAB_APPL_TRACE)) < 0 )
	{
		OTraceFatal( "F-SHC-13202: Unable to create mailbox 'SharedCash'\n" );
		return ( -1 );
	}

	if(shcIsAsynchSecMode())
		setAsynchMbName((const char *)SHC_SERVER_NAME);

	/*  Get an owner id for the database access  */
	dbmid = getpid();
	call_dbm_init = 1;

    /* Read Configuration file and build Factory and Table */
    //syslg("Read CallBack Configuration Parameters ...\n");	//	R018276
    if (readCallBackConfig() < 0)
    {
        OTraceFatal("F-SHC-13217: Reading CallBack Configuration Parameters failed.\n");		//	R018276
        return ( -2 );
    }

	/*	now tell internal routines that I'm the switch */
	shcApp->shcHelperObj->shc_setswitchflag( 1 );

	/* Initialise my shared cash enviornment */
	if(shcApp->shcHelperObj->shc_initsys() < 0)
	{
		/* Wait for a start packet before initialisation */
		OTraceInfo("I-SHC-13203: Waiting for start packet\n");
		if(mb_waitforstart(shcmid) < 0)
			return ( -3 );

		shcApp->shcHelperObj->shc_init();
	}

	shcApp->shcExtendedEventLocate = 1;

	/*	Initialise the segment message */
	shcsegrecbuf.segdata = (char *)calloc(1, SHC_SEG_MAX + sizeof(ShcmsgHeader));	// length changed !
	if(shcsegrecbuf.segdata == NULL)
	{
		OTraceFatal("F-SHC-13204: Unable to allocate segment data.\n");
		return( -4 );
	}

	int ret = shc_getInstitutionIdFromCardScheme(mcInst, "05");
	int oret = shc_getInstitutionIdFromCardScheme(mcInstOther, "25");
	if (ret < 0 && oret < 0)
	{
		OTraceWarning("W-SHC-9621:No MasterCard institution found, no special MasterCard checking\n");
		mcInst[0] = '\0';
		mcInstOther[0] = '\0';
	}

	ret = shc_getInstitutionIdFromCardScheme(visaInst, "04");
	if (ret < 0)
	{
		OTraceWarning("W-SHC-9622:No Visa institution found, no special Visa checking\n");
		visaInst[0] = '\0';
	}


	shcsegrecbuf.segsize = SHC_SEG_MAX;
	beginCacheMsg();

	return ( 1 );
}

int ShcMainLoop::registerProcessors()
{
	return 0;
}

int ShcMainLoop::registerBaseTxns()
{
	return 0;
}
ShcProcessor *ShcMainLoop::processQueue()
{
	ShcProcessor *nextProcessor = shcApp->msgQueue.front();
	if (nextProcessor)
	{
		shcApp->msgQueue.remove();
	}
	return nextProcessor;

}


int ShcMainLoop::process()
{
    struct  shcmsg *shcmsgP;
	int		is300;
	int		len;
	int		eventId = -1;	//	---	R026142
	struct timeb tmpTime;
	long nxt = 0;

	HaPtmCctHelper::prepare() ;

	OTraceInfo("I-SHC-13205: Starts working ...\n");
	int		readSize = sizeof(struct shcmsg) + shcsegrecbuf.segsize;
	char   *readBuf = shcsegrecbuf.segdata;

	shcmsgP = (struct shcmsg *)shcsegrecbuf.segdata;

	if(shcStats)
		time((time_t *)&shcStats->start_stats);

	for(;;)
	{
		OTraceDebug("###[No.%d]###\n", ++nxt);

		if ((shcProcessor = (ShcProcessor *)processQueue()) )		// Process tasks in the queue
		{
			OTraceDebug("D-SHC-13206: Read from Message Queue\n" );
		}
		else
		{
			//  -rc-
			//  When there is nothing in the local-Q, read from mbox
			//  This is the point when process can be terminated by HaPtmCct
			//  local-Q must be cleared before possible termination

			if( HaPtmCctHelper::checkBefore() != 0 )
			{
				OTraceInfo( "I-SHC-13207: Terminate by HaPtmCct\n" ) ;
				syslg( "I-SHC-13207: Terminate by HaPtmCct\n" ) ;
				break ;
			}

			/*	Clear every thing for the next tansaction */
			//memset(&shcApp->shccard, 0, sizeof(shcApp->shccard));

			/* 961204 */
			memset(readBuf, 0, readSize);
			memset(&routingRecord, 0, sizeof(routingRecord));

			len = mb_read( shcmid, readBuf, readSize ) ;
			if( len < 0 )
			{
				if( mb_test() < 0 ) break ;
				//  -rc-
				//  continue to check local-Q again - it is fine since it is empty
				//  followed by checkBefore() - will terminate if it should
				continue ;
			}

			OTraceDebug("D-SHC-13208: Read %d bytes\n", len);
    		ftime(&tmpTime);

			if(shcIsAsynchSecMode() && strstr(mbMailBoxName(mbLastSenderId()),SECURITY_MBOX_NAME))
			{
				getAsynchEvent(readBuf,len,readSize,shcmsgP);
			}

			if( (shcmsgP->msgtype/1000 == 8) && (shcmsgIsResponse(shcmsgP)) )    //  >>>>> R024672  M.P.S
			{
				struct s_FMDecision *f = ( struct s_FMDecision *)shcmsgP;
				//R028271 >>>
				//R028271: For txns sent to FM/LM, we pass the chip index as TID in request.
				//R028271: While receiving response from FM/LM, we get the same chip index as TID,
				//R028271: contrary to the usual behavior where the response message will
				//R028271: have a different TID. So, there is no need to equate the TIDs of
				//R028271: request and response.
				char txnId[1024];
				int txnIdLen=-1;
				int ret=-1;
				memset(txnId,0x00,sizeof(txnId));
				mb_get_tid(txnId,sizeof(txnId),&txnIdLen);
				if(txnIdLen)
					TxnStatReport(txnId, TS_SHC,TSR_RECEIVE,f->msgtype,0,mbLastSenderId());
				else
				{
					//R028271: This is strange...request WILL have txnid plugged-in and where has
					//R028271: it gone in the response?
				}
				//<<< R028271

				if (shcmsgP->msgtype/100==86)
				{
					struct s_ODDecision *o = ( struct s_ODDecision *)shcmsgP;
					OTraceLog("L-SHC-13208b: Received %d bytes from %s: m%04d/%s/%d at %ld %d\n",
						   len, mbMailBoxName(mbLastSenderId()), o->msgtype,
						   o->logId, o->eventId);
				}
				else

				OTraceLog("L-SHC-13208a: Received %d bytes from %s: m%04d/t%06ld/p%06ld at %ld %d\n",
						   len, mbMailBoxName(mbLastSenderId()), f->msgtype,
						   f->trace, f->pcode, tmpTime.time, tmpTime.millitm);
			}
			else
			{																     //  <<<<<  R024672  M.P.S

				//R028271 >>>
				if(len)
				{
					int txnIdLen=-1;
					if(!strlen(shcmsgP->shclog_id))
					{
						if(mb_get_tid(shcmsgP->shclog_id,sizeof(shcmsgP->shclog_id),&txnIdLen) <= 0) //R030034
							mb_getUmi(shcmsgP->shclog_id,sizeof(shcmsgP->shclog_id)); //R030000
					}
					else
					{
						char tid[sizeof(shcmsgP->shclog_id)];
						tid[0] = 0;
						mb_get_tid(tid, sizeof(tid), &txnIdLen);
						if (strcmp(tid, shcmsgP->shclog_id)!=0)
						{
							if (shcmsgIsResponse(shcmsgP))
								TxnStatEquate(shcmsgP->shclog_id, tid);
							mb_set_tid(shcmsgP->shclog_id, strlen(shcmsgP->shclog_id));
						}
					}

					struct shc_data shc_data_p;
					memcpy(&shc_data_p, (shc_data*) shcmsgP->shc_data_buffer, sizeof(shc_data));// copy original value 

					if( (strlen(shcmsgP->pan) == 0) && (strlen(shc_data_p.expiry_date)==0) 
						&& (strlen(shcmsgP->track2) > 0))  
					{
						memset(shcmsgP->pan, 0, sizeof(shcmsgP->pan));

						memset(shc_data_p.expiry_date, 0, sizeof(shc_data_p.expiry_date));
						char *p = strstr(shcmsgP->track2, "D") ;

						if(p ==NULL ){ 
							
							p = strstr(shcmsgP->track2, "=");
						} 
							
						
						istsafe_strcpy(shcmsgP->pan, (p - shcmsgP->track2)+1 , shcmsgP->track2);
						istsafe_strcpy(shc_data_p.expiry_date, sizeof(shc_data_p.expiry_date), p+1); 
						shc_data_p.expiry_date[5] = 0;

						memcpy(shcmsgP->shc_data_buffer, (char*) &shc_data_p, sizeof(shcmsgP->shc_data_buffer));	
					} 	
					//R028557
					TxnStatReport(shcmsgP->shclog_id,TS_SHC,TSR_RECEIVE,shcmsgP->msgtype,shcmsgP->respcode,mbLastSenderId());
				}
				//<<< R028271

				OTraceLog("L-SHC-13208: Received %d bytes from %s ID[%s]/m%04d/t%06d/p%06d at %ld %d\n",
		        	       len, mbMailBoxName(mbLastSenderId()), shcmsgP->shclog_id, shcmsgP->msgtype,
						   shcmsgP->trace, shcmsgP->pcode, tmpTime.time, tmpTime.millitm);
			//	<<<	R018276
			}

			/* For now ignore special packets */
			if(mbIsStart())
			{
				OTraceDebug("D-SHC-13209: Read start packet\n");
				continue;
			}

			if(mbIsApplTraceRequest())
			{
				if(mbIsApplTraceStart())
				{
					OTraceInfo("I-SHC-13210: Request to turn on tracing.\n");
					ist_otrace_set_level(OTRACE_DEBUG);
				}
				else if(mbIsApplTraceStop())
				{
					OTraceInfo("I-SHC-13211: Request to turn off tracing.\n");
					ist_otrace_set_level(OTRACE_NONE);
				}

				continue;
			}

			if(mbIsEvent())
			{
				((struct shcmsg *)readBuf)->msgtype += SHC_EVENT;
				eventId		= mbLastEvent();
				mb_set_tid(shcmsgP->shclog_id, strlen(shcmsgP->shclog_id));
			}
			else
				eventId = -1;
			if (strncmp(readBuf, "conn", 4)==0)
			{
				OTraceInfo("I-SHC-: received string(%s), ignore\n", readBuf);
				continue;
			}
			else if (strncmp(readBuf, "disc", 4)==0)
			{
				binRouteObj->setRemoteRouteStatus(BIN_ROUTE_STATUS_DOWN);
				OTraceInfo("I-SHC-:received string(%s), set remote route down\n", readBuf);
				continue;
			}
			if (initEnvForMsg(readBuf) < 0)
			{
				if (eventId>=0)
					tm_dequeue(eventId);
				continue;
			}

			processingDoneOnOtherNode = 0;
			shcProcessor = shcProcessorRegistration.getTargetObj(readBuf);

			if ( shcProcessor )
			{
				if ( eventId < 0 )
				{
					shcProcessor->header->shcerr&=~SH_IGNORE;
					if(!(shcIsAsynchSecMode() && strstr(mbMailBoxName(mbLastSenderId()),SECURITY_MBOX_NAME)))
						shcProcessor->header->setSenderId(mbLastSenderId());
					shcProcessor->header->setTxnStartTime();
				}
				else
				{
					shcProcessor->header->eventId = eventId;
				}
			}
		}

		if ( shcProcessor )
		{
			if(shcIsAsynchSecMode() && strstr(mbMailBoxName(mbLastSenderId()),SECURITY_MBOX_NAME))
				setAsynchTxnFlgs(shcProcessor->header,shcmsgP);

			shcProcessor->process();
			delete shcProcessor;
		}
		else
		{
			OTraceInfo("I-SHC-13212:Can't classify this message yet, message dropped\n");
			//      >>>     R018276
			if( shcmsgP->shclog_id[0] )
			{
				OTraceLog("L-SHC-13218: Drop message ID[%s]/m%04d/t%06ld/p%06ld\n",
					shcmsgP->shclog_id, shcmsgP->msgtype, shcmsgP->trace, shcmsgP->pcode);
				//R028271 >>>
				TxnStatReport(shcmsgP->shclog_id, TS_SHC,TSR_DROP,DROP_MSG_UNCLASSIFIED,0,0);
				//<<< R028271
			}
			else
				OTraceLog("L-SHC-13219: Drop message m%04d/t%06ld/p%06ld\n",
					shcmsgP->msgtype, shcmsgP->trace, shcmsgP->pcode);
			//	<<<     R018276
			continue;
		}
	}

	return(0);
}

int ShcMainLoop::initEnvForMsg(char *msg)
{
	int     isdropped = 0;
	int     level = 0;
	struct shcmsg *msgP = (struct shcmsg *)msg;

	shcApp->shcmsgHelperObj->shc_dispmsg_x(msgP, 0 ,0);

	shcApp->acquirerShcParamsList = NULL;
	shcApp->issuerShcParamsList = NULL;

	OTraceInfo("I-SHC-13213: Got request from (%d)\n", mbLastSenderId());

	/*	get the current time */
	shc_get_current_date();

	/* R003931 SHC Throttling */
	if ((level = check_throttle("SHC")) > 0)
	{
		OTraceInfo("I-SHC-13214: Throttle Level = %d\n", level);
		isdropped = do_shcmsg_throttle_action((char *)"SHC", level, (void*)msgP,
										sizeof(struct shc));
	}
	else
		isdropped = 0;

	if (isdropped > 0)
	{
		OTraceInfo("I-SHC-13215:THROTTLE: No further processing.\n");
		//R028271 >>>
		if(strlen(msgP->shclog_id))
			TxnStatReport(msgP->shclog_id, TS_SHC,TSR_DROP,DROP_THROTTLED,0,0);
		//<<< R028271
		return -1;
	}
	else
	{
		OTraceInfo("I-SHC-13216:THROTTLE: Continue processing.\n");
	}

	return 0;
}

//int setAsynchTxnFlgs(ShcProcessor* shcProcessor,struct  shcmsg *shcmsgP)
//{
//	int iCmd=0;
//	long skipFlg;

//	skipFlg=TXN_PROC_SKIP_ENRICH|TXN_PROC_SKIP_RESTORE|TXN_PROC_SKIP_EDIT;

//	iCmd=shcmsgP->respcode/1000;
//	if(isAsynchCmdTrnsltPin(iCmd))
		// Trasnslate PIN Blk is into doWork, verify() is done
//		skipFlg |= TXN_PROC_SKIP_VERIFY;
//	shcProcessor->header->shcerr|=SH_ASYNCH_RESUME;
//	shcProcessor->header->setSkipFlag(skipFlg);

//	shcProcessor->header->logFlag = 0;
//	OTraceDebug("D-SHC-01212 From SecSrv [0x%08x] ShcErr[0x%08x] Log[%08x] Cmd[%d]\n",
//		shcProcessor->header->procFlag,shcProcessor->header->shcerr,shcProcessor->header->logFlag,
//		iCmd);

//	return(1);
//}

