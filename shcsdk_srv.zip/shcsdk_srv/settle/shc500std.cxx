//
// Copyright (C) 2004 eFunds Corporation ("eFunds").  All Rights Reserved.  
// eFunds Canada Corporation is an authorized user. 
// 
// IST is a registered trademark of eFunds Corporation.  Other brand or
// product names are trademarks or registered trademarks of their respective
// holders. 
// 
// The information contained herein is the unpublished proprietary property
// of eFunds.  Except as specifically authorized in writing by eFunds, the
// holder of this document shall: i) keep all information contained herein
// confidential, and ii) protect the information, in whole or in part, from
// disclosure and dissemination to all third parties. 
// 
// This document and the software described in it are furnished under license
// and may be used or copied only in accordance with the terms of such license.
// This document is supplied for information purposes only, is subject to
// change without notice, and should not be construed as a commitment by
// either eFunds Corporation or eFunds Canada Corporation. 
//
static char ver[100]="IST:shc500std r";
static char _shc500std_cxx_what[] = "@(#) shc500std.cxx 2.14 12/05/29 06:39:34";

/*
 *	IST and IST/Share are registered trademarks of Oasis Technology Ltd.
 *
 *	Copyright (C) 1990 - 1997 Oasis Technology Ltd.
 *	All Rights Reserved
 *	This Module contains Proprietary Information of
 *	Oasis Technology Ltd., and should be treated as Confidential.
 *
 *	THIS IS UNPUBLISHED PROPRIETARY SOURCE CODE OF OASIS TECHNOLOGY LTD.
 *	The copyright notice above does not evidence any  
 *	actual or intended publication of such source code.
 */
/*
 *
 *                        MODIFICATION HISTORY                  REVIEW
 *
 *	SPR#	Who	Date	Description			Who	Date   
 * ===========================================================================
 *	ad		08jan92		added logic to handle amt_auth and amt_auth_rev
 * 10002364 la  02jul96 Modified to route 500 message structure.
 *          cw  29Nov96 Combined 520/522 processing into 
 *						perform_settlement_advice(). Made logging configurable
 *						with cfg param: shc.500_52x_logging
 * R003932  fg  29Jan00 Mailbox Throttling
 * R007062	gbeeng	26Nov2001	C++ Migration
 *R008118 ztang 27Sep02 Send 530 response to where it come from 
 * R028271 dipa	21Jun10	Txn Statistics
 * R030381 dipa	02Mar12	Txn Statistics
 */

//File Number 142

#include <stdio.h>
#include <string.h>
#include <oasis.h>
#include <mb.h>
#include <tm.h>
#include <rules.h>
#include <ist_otrace.h>
#include <shc.h>
#include <shc500std.h>
#include "shc_util_funcs.h"

//R028271 >>>
#include <TxnStat.h>
//<<< R028271

/*
 *	Standard on-line settlement program
 *
 *	Usage:		shc500std
 *
 *	Mailbox		StdSettlement
 *
 */
extern "C"
{
	void	stdexit( int );
}
int std_init();
int std_processes();
int perform_db_update();
int perform_settlement(struct shc500std *msg);
int create_update_event();
int perform_inquire(struct shc500std *msg);
int perform_db_update();
int perform_dayend( struct shc500std *msg );
int perform_response_update(struct shc500std *msg);
int perform_settlement_advice(struct shc500std *msg );
extern int shc500InstantDBUpdate( struct shc500std *msg );
extern int shc500_end();
extern int shc500_init();
extern struct  shc500std *shc500FindEntry(bin_t bin, date_t date);
extern int shc500UpdateEntry(struct shc500std_key *key);
int	mbid = (-1);
int	something_changed = 0;
int	std500_update_interval = 10;
/*  29Nov96 */
int std500_52x_logging = 0;

static int savedSenderId = 0;


int main(int argc, char **argv)
{
	argv0 = *argv;
	catch_all_signals(stdexit);

	strcat(ver, VERSION);
	syslg("%s\n", ver);
	OTraceOn(argv0);
	ist_otrace_set_level(OTRACE_NONE);

	mb_init();
	shc_init();
	std_init();

	std_processes();
	stdexit(0);
	return(0);
}


void stdexit(int n)
{
	syslg("Exit due to signal(%d)\n", n);

	perform_db_update();
	
	shc500_end();

	if(mbid >= 0)
		mb_deletemailbox(mbid);
	
	OTraceOff();

	mbid = (-1);

	if(n > 2)
		kill(getpid(), n);
	
	exit(n);
}


int std_init()
{
	/*
	 *	Initialise the settlement program
	 */
	int		i;

	mbid = mb_createmailbox(SHC500STD_MAILBOX, 0, MB_TAB_APPL_TRACE);
	if(mbid < 0)
	{
		OTraceFatal("F-SHC-142001:Unable to create mail box '%s'\n", SHC500STD_MAILBOX);
		stdexit(1);
	}


	if(shc500_init() < 0)
	{
		OTraceFatal("F-SHC-142002:Unable to initialise system.\n");
		stdexit(1);
	}

	/*
	 *	Read the configuration files
	 */
	if(cf_open("files/shc.cfg") < 0)
		return(-1);
	
	if(cf_locatenum("shc.500_update_interval", &i) >= 0)
		std500_update_interval = i;

	/* 29Nov96 */	
	if(cf_locatenum("shc.500_52x_logging", &i) >= 0)
		std500_52x_logging = i;

	cf_close();

	return( 0 );
}


int std_processes()
{
	struct	shc500std	std500;
	int					senderid;
	int len;

	for(;;)
	{
		if((len = mb_read(mbid, &std500, sizeof(struct shc500std))) < 0)
			break;
	
		if(mbIsApplTraceRequest())
		{
			if(mbIsApplTraceStart())
			{
				ist_otrace_set_level(OTRACE_DEBUG);
				OTraceInfo("I-SHC-142003:SHC500: Request to turn on tracing.\n");
			}
			else if(mbIsApplTraceStop())
			{
				OTraceInfo("I-SHC-142004:SHC500: Request to turn off tracing.\n");
				ist_otrace_set_level(OTRACE_NONE);
			}
			
			continue;
		}
       
		senderid = mbLastSenderId();
		savedSenderId = senderid = mbLastSenderId();	/* R008297 */
		
		OTraceLog("L-SHC-142036: Received %d bytes from %s ID[%s] /m%04d\n",
			len, mbMailBoxName(senderid),
			std500.shclog_id, std500.msgtype);
		//R028271 >>>
		TxnStatReport(std500.shclog_id, TS_SHC,TSR_RECEIVE,std500.msgtype,0,senderid);
		//<<< R028271

		if(ist_otrace_get_level() >= OTRACE_DEBUG)
		{
			OTraceDebug("D-SHC-142005:SHC500: Recieved message\n");
			OTraceDebug("D-SHC-142006:SHC500:   from  : %s[%d]\n", mbMailBoxName(senderid),
				senderid);
			OTraceDebug("D-SHC-142007:SHC500:   type  : %d\n", std500.msgtype);
		}

		switch(std500.msgtype){
		default:
		case	SHC500_MSG_TRANSACTION:
			perform_settlement(&std500);

			if(!something_changed)
			{
				something_changed = 1;
				create_update_event();
			}

			if(std500.msgtype / 100 == 5)
			{
				/*	then they expect a reply */
				std500.msgtype += 10;
				OTraceDebug("D-SHC-142008:SHC500:  sending reply message\n");
				OTraceDebug("D-SHC-142009:SHC500:   to    : %s[%d]\n",
						mbMailBoxName(senderid), senderid);

				/* R003932 */
				TxnStatReport(std500.shclog_id,TS_SHC,TSR_SEND,std500.msgtype,0,senderid);
				if (mb_write_nothrottle(senderid, mbid, &std500, sizeof(struct shc500std))<0)
				{
					OTraceLog("L-SHC-142037: Failed to send msg ID[%s] /m%04d to %s\n",
						std500.shclog_id, std500.msgtype, mbMailBoxName(senderid));
				}
				else
				{
					OTraceLog("L-SHC-142038: Sent msg ID[%s] /m%04d to %s\n",
						std500.shclog_id, std500.msgtype, mbMailBoxName(senderid));
				}
			}
			break;
		
		case	SHC500_MSG_INQUIRE:
			perform_inquire(&std500);
			OTraceDebug("D-SHC-142010:SHC500:  sending reply message\n");
			OTraceDebug("D-SHC-142011:SHC500:   to    : %s[%d]\n",
					mbMailBoxName(senderid), senderid);

			TxnStatReport(std500.shclog_id,TS_SHC,TSR_SEND,std500.msgtype,0,senderid);
			/* R003932 */
			if ((mb_write_nothrottle(senderid, mbid, &std500, sizeof(struct shc500std)))<0)
				{
					OTraceLog("L-SHC-142039: Failed to send msg ID[%s] /m%04d to %s\n",
						std500.shclog_id, std500.msgtype, mbMailBoxName(senderid));
				}
				else
				{
					OTraceLog("L-SHC-142040: Sent msg ID[%s] /m%04d to %s\n",
						std500.shclog_id, std500.msgtype, mbMailBoxName(senderid));
				}
			break;
		
		case	SHC500_MSG_UPDATE_DB:
			/*	Update the date base with incore entries */

			/*	Remove current queue item */
			if(mbIsEvent())
				tm_dequeue(mbLastEvent());
			perform_db_update();
			break;

		case	SHC500_MSG_DAYEND:
			std500.unit = senderid;								/* 10002364 */
			perform_dayend(&std500);
			break;
		
		case	SHC_STLMTREQ_ADVICE_RESPONSE:
			std500.unit = senderid;
			perform_response_update(&std500);

			if( !something_changed )
			{
				something_changed = 1;
				create_update_event();
			}
			break;
		/* 10002898 - cwen */
		case SHC_STLMTREQ_ADVICE:
		case SHC_STLMTREQ_ISSUER_ADVICE: 
				OTraceDebug("D-SHC-142012:SHC500: Received message %d from source(%d) .\n", 
					std500.msgtype, senderid);
				perform_settlement_advice(&std500);
				break;
		}
	}
	return( 0 );
}


int perform_settlement(struct shc500std *msg)
{
	struct	shc500std	*iss, *acq, *sw;

	if(ist_otrace_get_level() >= OTRACE_DEBUG)
	{
		OTraceDebug("D-SHC-142013:SHC500:   issuer  : %s\n", msg->issuer);
		OTraceDebug("D-SHC-142014:SHC500:   acquirer: %s\n", msg->acquirer);
		OTraceDebug("D-SHC-142015:SHC500:   switch  : %s\n", shc500SwitchId);
	}

	iss = shc500FindEntry(msg->issuer, msg->settlement_date);
	acq = shc500FindEntry(msg->acquirer, msg->settlement_date);
	sw  = shc500FindEntry(shc500SwitchId, msg->settlement_date);

	if( !iss )
	{
		OTraceError("E-SHC-142016:SHC500: Unable to find issuer entry\n");
		return( -1 );
	}

	if( !acq )
	{
		OTraceError("E-SHC-142017:SHC500: Unable to find switch entry\n");
		return( -1 );
	}

	if( !sw )
	{
		OTraceError("E-SHC-142018:SHC500: Unable to find acquirer\n");
		return( -1 );
	}

	if(msg->msgtype == SHC500_MSG_TRANSACTION)
	{
		OTraceDebug("D-SHC-142019:SHC500:   reason: %d\n", msg->advice_reason);

		iss->currency_code = msg->currency_code;
		acq->currency_code = msg->currency_code;
		sw->currency_code = msg->currency_code;

		switch(msg->advice_reason){
		case	SHC_TXNTYPE_CREDIT:
			if(msg->flags & SHC500_TXN_REVERSAL)
			{
				iss->num_credit_rev += msg->num_credit_rev;
				acq->num_debit_rev += msg->num_credit_rev;
				sw->num_credit_rev += msg->num_credit_rev;
				sw->num_debit_rev += msg->num_credit_rev;
				dbm_decaddx(&iss->amt_credit_rev, &msg->amt_credit_rev);
				dbm_decaddx(&acq->amt_debit_rev, &msg->amt_credit_rev);
				dbm_decaddx(&sw->amt_credit_rev, &msg->amt_credit_rev);
				dbm_decaddx(&sw->amt_debit_rev, &msg->amt_credit_rev);

				/*	net settlement */
				dbm_decsubx(&iss->amt_netset, &msg->amt_credit_rev);
				dbm_decaddx(&acq->amt_netset, &msg->amt_credit_rev);
			}
			else
			{
				iss->num_credit += msg->num_credit;
				acq->num_debit += msg->num_credit;
				sw->num_credit += msg->num_credit;
				sw->num_debit += msg->num_credit;
				dbm_decaddx(&iss->amt_credit, &msg->amt_credit);
				dbm_decaddx(&acq->amt_debit, &msg->amt_credit);
				dbm_decaddx(&sw->amt_credit, &msg->amt_credit);
				dbm_decaddx(&sw->amt_debit, &msg->amt_credit);

				/*	net settlement */
				dbm_decaddx(&iss->amt_netset, &msg->amt_credit);
				dbm_decsubx(&acq->amt_netset, &msg->amt_credit);
			}
			break;

		case	SHC_TXNTYPE_DEBIT:
			if(msg->flags & SHC500_TXN_REVERSAL)
			{
				iss->num_debit_rev += msg->num_debit_rev;
				acq->num_credit_rev += msg->num_debit_rev;
				sw->num_credit_rev += msg->num_debit_rev;
				sw->num_debit_rev += msg->num_debit_rev;
				dbm_decaddx(&iss->amt_debit_rev, &msg->amt_debit_rev);
				dbm_decaddx(&acq->amt_credit_rev, &msg->amt_debit_rev);
				dbm_decaddx(&sw->amt_credit_rev, &msg->amt_debit_rev);
				dbm_decaddx(&sw->amt_debit_rev, &msg->amt_debit_rev);

				/*	net settlement */
				dbm_decaddx(&iss->amt_netset, &msg->amt_debit_rev);
				dbm_decsubx(&acq->amt_netset, &msg->amt_debit_rev);
			}
			else
			{
				iss->num_debit += msg->num_debit;
				acq->num_credit += msg->num_debit;
				sw->num_credit += msg->num_debit;
				sw->num_debit += msg->num_debit;
				dbm_decaddx(&iss->amt_debit, &msg->amt_debit);
				dbm_decaddx(&acq->amt_credit, &msg->amt_debit);
				dbm_decaddx(&sw->amt_credit, &msg->amt_debit);
				dbm_decaddx(&sw->amt_debit, &msg->amt_debit);

				/*	net settlement */
				dbm_decsubx(&iss->amt_netset, &msg->amt_debit);
				dbm_decaddx(&acq->amt_netset, &msg->amt_debit);
			}
			break;

		case	SHC_TXNTYPE_TRANSFER:
			if(msg->flags & SHC500_TXN_REVERSAL)
			{
				iss->num_transfer_rev += msg->num_transfer_rev;
				sw->num_transfer_rev += msg->num_transfer_rev;
			}
			else
			{
				iss->num_transfer += msg->num_transfer;
				sw->num_transfer += msg->num_transfer;
			}
			break;

		case	SHC_TXNTYPE_INQUIRY:
			iss->num_inquiry += msg->num_inquiry;
			sw->num_inquiry += msg->num_inquiry;
			break;

		case	SHC_TXNTYPE_AUTHORIZE:
			if(msg->flags & SHC500_TXN_REVERSAL)
			{
				iss->num_auth_rev += msg->num_auth_rev;
				acq->num_auth_rev += msg->num_auth_rev;
				sw->num_auth_rev += msg->num_auth_rev;

				dbm_decaddx(&iss->amt_auth_rev, &msg->amt_auth_rev);
				dbm_decsubx(&acq->amt_auth_rev, &msg->amt_auth_rev);
				dbm_decsubx(&sw->amt_auth_rev, &msg->amt_auth_rev);
			}
			else
			{
				iss->num_auth += msg->num_auth;
				acq->num_auth += msg->num_auth;
				sw->num_auth += msg->num_auth;

				dbm_decaddx(&iss->amt_auth, &msg->amt_auth);
				dbm_decsubx(&acq->amt_auth, &msg->amt_auth);
				dbm_decsubx(&sw->amt_auth, &msg->amt_auth);
			}
			break;

		default:
			break;
		}


		/*	Set all entries as changed */
		shc500MarkEntryChanged(&shc500StdKey[iss->index]);
		shc500MarkEntryChanged(&shc500StdKey[acq->index]);
		shc500MarkEntryChanged(&shc500StdKey[sw->index]);

	}
	return(0);
}

/* 10002364 */
int perform_dayend( struct shc500std *msg )
{
	struct shcpkg	*pkg;
	int				outbound;

	if( shc_locate_bin(&pkg, msg->issuer) < 0 )
	{
		OTraceError("E-SHC-142020:SHC500: Unable to locate bin for '%s'\n", msg->issuer);
		return( -1 );
	}

	outbound = pkg->bin.mailbox;

	OTraceError("E-SHC-142021:SHC500:  mailbox: %s [%d]\n", mbMailBoxName(outbound),
			outbound);

	TxnStatReport(msg->shclog_id,TS_SHC,TSR_SEND,msg->msgtype,0,outbound);
	/* R003932 */
	if( mb_write_nothrottle(outbound, mbid, (char *)msg, sizeof(struct shc500std)) < 0 )
	{
		OTraceLog("L-SHC-142041: Failed to send msg ID[%s] /m%04d to %s\n",
			msg->shclog_id, msg->msgtype, mbMailBoxName(outbound));
		return(-1);
	}
	else
	{
		OTraceLog("L-SHC-142042: Sent msg ID[%s] /m%04d to %s\n",
			msg->shclog_id, msg->msgtype, mbMailBoxName(outbound));

	}

    OTraceInfo("I-SHC-142023: Route: m%04d/t%06ld/r%02d --> (%d)\n",
            msg->msgtype, msg->trace % 1000000,
            msg->respcode, outbound);

	return( 0 );
}


int perform_inquire(struct shc500std *msg)
{
	struct	shc500std	*p;

	if(ist_otrace_get_level() >= OTRACE_DEBUG)
	{
		OTraceDebug("D-SHC-142024:SHC500:  Inquiry request for\n");
		OTraceDebug("D-SHC-142025:SHC500:   issuer: %s\n", msg->issuer);
		OTraceDebug("D-SHC-142026:SHC500:   date  : %ld\n", msg->settlement_date);
	}

	p = shc500FindEntry(msg->issuer, msg->settlement_date);
	msg->respcode = (-1);
	if(p == NULL)
		return(0);
	
	memcpy(msg, p, sizeof(struct shc500std));
	msg->respcode = 0;
	return(0);
}


int perform_db_update()
{
	/*
	 *	Scan the table and choose all entries which need update
	 */
	int		i;

	for(i = 0; i < shc500StdMaxKeys; ++i)
		if((shc500StdKey[i].flags & SHC500_INUSE)
		   && shc500EntryIsChanged(&shc500StdKey[i]))
			shc500UpdateEntry(&shc500StdKey[i]);
	
	something_changed = 0;

	return( 0 );
}


int create_update_event()
{
	struct	shc500std	msg;
	int		i;
	
	if(std500_update_interval <= 0)
		return(0);

	msg.msgtype = SHC500_MSG_UPDATE_DB;

	/*	Set an event to trigger the next update phase */
	i = tm_enqueue(mbid, time(0) + std500_update_interval,
	   TM_NOTIFY_ONCE, 1, (char *)&msg, sizeof(struct shc500std));
	
	tm_setflags(i, TM_NOSAVE, 1);
	return(0);
}

int perform_response_update(struct shc500std *msg)
{
	struct	shc500std	*iss;
	static int			advice_mbid = -1;

	if(ist_otrace_get_level() >= OTRACE_DEBUG)
	{
		OTraceDebug("D-SHC-142027:SHC500:  response message\n");
		OTraceDebug("D-SHC-142028:SHC500:   issuer  : %s\n", msg->issuer);
		OTraceDebug("D-SHC-142029:SHC500:   respcode: %s\n", msg->respcode);
	}

	iss = shc500FindEntry(msg->issuer, msg->settlement_date);

	if( !iss )
	{
		OTraceError("E-SHC-142030:SHC500: Unable to find issuer entry\n");
		return( -1 );
	}

	iss->respcode = msg->respcode;

	/*	Set all entries as changed */
	shc500MarkEntryChanged(&shc500StdKey[iss->index]);

	/* Send reply to advice */
	if( advice_mbid < 0 )
		if( (advice_mbid = mb_locatemailbox(AUTH_ADVICE_RESPONSE_NAME)) < 0 )
		{
			printf("W-SHC500: Unable to locate mailbox '%s'\n",
				AUTH_ADVICE_RESPONSE_NAME);
			return( -1 );
		}

	/* R003932 */
	TxnStatReport(msg->shclog_id,TS_SHC,TSR_SEND,msg->msgtype,0,advice_mbid);
	if( mb_write_nothrottle(advice_mbid, mbid, (char *)msg, sizeof(struct shc500std)) < 0 )
	{
		OTraceLog("L-SHC-142043: Failed to send msg ID[%s] /m%04d to %s\n",
			msg->shclog_id, msg->msgtype, mbMailBoxName(advice_mbid));
		return(-1);
	}
	else
	{
		OTraceLog("L-SHC-142044: Sent msg ID[%s] /m%04d to %s\n",
			msg->shclog_id, msg->msgtype, mbMailBoxName(advice_mbid));
	}

	return( 0 );
}


/* 10002898 - cwen */
int perform_settlement_advice(struct shc500std *msg )
{
	struct shcpkg	*pkg;
	int		outbound;

	if( shc_locate_bin(&pkg, msg->issuer) < 0 )
	{
		printf("W-SHC500: Unable to locate bin for '%s'\n", msg->issuer);
		return( -1 );
	}

	outbound = savedSenderId;	/* R008297 */

	OTraceDebug("D-SHC-142032:SHC500:  mailbox: %s [%d]\n", mbMailBoxName(outbound),
			outbound);

	if (std500_52x_logging > 0 && shc500InstantDBUpdate(msg) == -1)
	{
		OTraceDebug("D-SHC-142033:SHC500: Failed to log msg [%d] into database.\n", 
				msg->msgtype);
	}

	msg->msgtype += 10;
	msg->advice_reason =  9; /* Must be '9' */
	
	/* R003932 */
	TxnStatReport(msg->shclog_id,TS_SHC,TSR_SEND,msg->msgtype,0,outbound);
	if (mb_write_nothrottle(outbound, mbid, (char *)msg, 
			sizeof(struct shc500std))< 0)
	{
		OTraceLog("L-SHC-142045: Failed to send msg ID[%s] /m%04d to %s\n",
			msg->shclog_id, msg->msgtype, mbMailBoxName(outbound));
		return(-1);
	}
	else
	{
		OTraceLog("L-SHC-142046: Sent msg ID[%s] /m%04d to %s\n",
			msg->shclog_id, msg->msgtype, mbMailBoxName(outbound));
	}
	OTraceDebug("D-SHC-142035:SHC500: Send message %d to dest(%d) .\n", msg->msgtype, 
			outbound);

	return( 0 );
}

