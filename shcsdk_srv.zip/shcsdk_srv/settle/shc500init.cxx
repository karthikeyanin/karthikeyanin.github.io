//
// Copyright (C) 2004 eFunds Corporation ("eFunds").  All Rights Reserved.  
// eFunds Canada Corporation is an authorized user. 
// 
// IST is a registered trademark of eFunds Corporation.  Other brand or
// product names are trademarks or registered trademarks of their respective
// holders. 
// 
// The information contained herein is the unpublished proprietary property
// of eFunds.  Except as specifically authorized in writing by eFunds, the
// holder of this document shall: i) keep all information contained herein
// confidential, and ii) protect the information, in whole or in part, from
// disclosure and dissemination to all third parties. 
// 
// This document and the software described in it are furnished under license
// and may be used or copied only in accordance with the terms of such license.
// This document is supplied for information purposes only, is subject to
// change without notice, and should not be construed as a commitment by
// either eFunds Corporation or eFunds Canada Corporation. 
//
static char ver[]="IST:shc500init r1.0.0 07Apr97";
static char _shc500init_cxx_what[] = "@(#) shc500init.cxx 2.7 16/08/02 04:04:31";

/*
 *	IST and IST/Share are registered trademarks of Oasis Technology Ltd.
 *
 *	Copyright (C) 1990 - 1997 Oasis Technology Ltd.
 *	All Rights Reserved
 *	This Module contains Proprietary Information of
 *	Oasis Technology Ltd., and should be treated as Confidential.
 *
 *	THIS IS UNPUBLISHED PROPRIETARY SOURCE CODE OF OASIS TECHNOLOGY LTD.
 *	The copyright notice above does not evidence any  
 *	actual or intended publication of such source code.
 */
/*
 *
 *                        MODIFICATION HISTORY                  REVIEW
 *
 *	SPR#	Who	Date	Description			Who	Date   
 * ===========================================================================
 *	ad		08jan92		compiled to support new amt_auth, amt_auth_rev fields.
 * R007062	gbeeng	26Nov2001	C++ Migration
 */

//File Number 141

#include <stdio.h>
#include <string.h>
#include <util.h>
#include <mb.h>
#include <rules.h>
#include <DBM3.h>
#include <dbm.h>
#include <dbm_private.h>
#include <ist_otrace.h>
#include <shc.h>
#include <shc500std.h>
#include "shc_util_funcs.h"


/*
 *	Example application initialiser
 */

/*
 *	An application initialiser is invoked with the following paramaters
 *
 *		<taskname>	<mode>	<rulename>	<appid> <srvname> [<data>]
 *
 *	<taskname>		the executable name of this task		(argv[0])
 *	<mode>			the mode of processing
 *						'count'			count space needed and report to strm
 *						'init'			init the rules in-core database
 *						'update'		update an existing rule
 *						'load'			load you application
 *
 *	<rulename>		the name of the rule to be initialised
 *	<appid>			the system assigned application id for this rule
 *
 *	<srvname>		the server to which count information should be sent
 *
 *	<data>			data which might be included in an 'update' command
 *					The format of the data is
 *						currency-code effdate
 *
 *
 *****************************************************************************
 *
 *	This is currency tables initialiser
 *	This task accepts initialisation requests for these types of messages
 *
 *			settlement
 *
 *
 */

/* Following two parameters determines the minimum number of entries allocated in shared memory */
#define MINIMUM_MEMORY_INCREMENT 100

/* Minimum percentage of extra memory needed */
#define EXTRA_MEMORY                20

int count_records();
int init_records();
int load_servers();
int update_record(char *code, char *date);
extern int shc500_init();

int		con_id = (-1);
struct	rules_keytab keytab = {0};
int		my_count = 0;
int		appid;
int		size;
const char	*bp = "select count(networkid) from shcbin";


#define	MAIN_REC	1
int		msgtype = 0;


int		argc = 0;
char	**argv = NULL;


int main(int a_rgc, char **a_rgv)
{
	argv = a_rgv;
	argc = a_rgc;

	argv0 = *argv;
	catch_all_signals(NULL);

	syslg("%s\n", ver);

	if(argc < 5)
		log_msg(FATAL, TO_CC, "F-SHC-141001:%d is an invalid number of parameters\n", argc);
	

	mb_init();

	/*
	 *	Connect to the named server
	 */
	con_id = mb_locatemailbox(argv[RULES_PARM_SRVNAME]);
	if(con_id == -1)
		log_msg(FATAL, TO_CC, "F-SHC-141002:Unable to connect to %s: Error: %d\n",
			argv[RULES_PARM_SRVNAME], errno);
	

	/*
	 *	Extract all paramaters
	 */
	appid = atoi(argv[RULES_PARM_APPID]);
	
	if(stricmp("settlement-tables", argv[RULES_PARM_RULENAME]) == 0)
		msgtype = MAIN_REC;
	else
		log_msg(FATAL, TO_CC, "F-SHC-141003:Invalid message type: %s\n", 
					argv[RULES_PARM_RULENAME]);
	
	/*
	 *	Now determine which we need and perform action
	 */
	if(stricmp(argv[RULES_PARM_MODE], "count") == 0)
		count_records();
	else if(stricmp(argv[RULES_PARM_MODE], "init") == 0)
		init_records();
	else if(stricmp(argv[RULES_PARM_MODE], "load") == 0)
		load_servers();
	else if(stricmp(argv[RULES_PARM_MODE], "update") == 0)
		update_record(argv[RULES_PARM_DATA], argv[RULES_PARM_DATA + 1]);
	else
		log_msg(FATAL, TO_CC, 
		"F-SHC-141004:I don't know how to interpret mode '%s'\n", argv[RULES_PARM_MODE]);
	

	exit(0);
	return(0);
}

int shcinitGetMinimumSpace()
{
	int ret;
	int numOfEntries = 0;
	DBMHSTMT tmpStmt;
	
    if (dbm_connect() >=0)
    {
        OTraceDebug("D-SHC-141005:Connecting to database successful");
    }
    else
    {
        OTraceFatal("F-SHC-141006:Connecting to database failed");
        return -1;
    }
    dbm_dbconn;
    ret=DBMAllocStmt(dbm_dbconn, &tmpStmt);
    if (ret < 0)
    {
        OTraceFatal("F-SHC-141007:Can't allocate statment:%s", bp);
        return -1;
    }
    ret=DBMPrepare(tmpStmt, (char *)bp);
    if (ret < 0)
    {
        OTraceFatal("F-SHC-141008:Can't prepare statment:%s", bp);
        return -1;
    }
    ret=DBMExecute(tmpStmt);
    if (ret < 0)
    {
        OTraceFatal("F-SHC-141009:Can't execute statment:%s", bp);
        return -1;
    }
    
    long status;
    ret=DBMBindCol(tmpStmt, 1, DBM_LONGTYPE, &status, sizeof(status), &numOfEntries);
    if (ret < 0)
    {
        OTraceFatal("F-SHC-141010:Can't bind for statment:%s", bp);
        return -1;
    }

    ret=DBMFetch(tmpStmt);
    if (ret == DBM_NO_DATA)
    	numOfEntries = 0;
	else if (ret < 0)
    {
        OTraceFatal("F-SHC-141011:Can't fetch for statment:%s", bp);
        return -1;
    }
    DBMFreeStmt(tmpStmt, DBM_CLOSE);
    
    /* Now calculate how many entries we should allocate
     * The number of entries increase by 100.
     * And we need to keep at least 20% free space
     */
    numOfEntries = (numOfEntries+1) * (MINIMUM_MEMORY_INCREMENT + EXTRA_MEMORY)/100;
    numOfEntries = (numOfEntries + MINIMUM_MEMORY_INCREMENT - 1)/MINIMUM_MEMORY_INCREMENT * MINIMUM_MEMORY_INCREMENT;
    
    return numOfEntries;
}

int count_records()
{
	/*
	 *	He wants me to inidcate how many keys and text buffers
	 *	as well as their respective sizes
	 *
	 *	I can do this by reading the database or by lokking in a
	 *	config file
	 */
	
		
	/*
	 *	Set up my retrun packet
	 */
	keytab.appid = atoi(argv[RULES_PARM_APPID]);

	if ((my_count = shcinitGetMinimumSpace()) < 0)
		log_msg(FATAL, TO_CC, "F-SHC-141012:Can't estimate shared memory needed.\n");
	/*
	 *	Now i tell him how large my buffers should be
	 */
	keytab.keysize	= sizeof(struct shc500std_key);
	keytab.nkeys	= my_count;

	keytab.textsize	= sizeof(struct shc500std_text);
	keytab.ntext	= my_count;

	snprintf(keytab.name, sizeof(keytab.name),"%s",argv[RULES_PARM_RULENAME]);

	/*
	 *	Now i send him the information
	 */
	mb_write(con_id, 0, &keytab, sizeof(keytab));

	return( 0 );
}




int init_records()
{
	/*
	 *	Now I can actualy initialise my table
	 */
	int		i;

	shc500_init();

	for(i = 0; i < shc500StdMaxKeys; ++i)
		shc500StdKey[i].textid = i;
	return(0);
}



int load_servers()
{
	return(0);
}


int update_record(char *code, char *date)
{
	return(0);
}
