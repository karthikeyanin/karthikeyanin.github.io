//
// Copyright (C) 2004 eFunds Corporation ("eFunds").  All Rights Reserved.  
// eFunds Canada Corporation is an authorized user. 
// 
// IST is a registered trademark of eFunds Corporation.  Other brand or
// product names are trademarks or registered trademarks of their respective
// holders. 
// 
// The information contained herein is the unpublished proprietary property
// of eFunds.  Except as specifically authorized in writing by eFunds, the
// holder of this document shall: i) keep all information contained herein
// confidential, and ii) protect the information, in whole or in part, from
// disclosure and dissemination to all third parties. 
// 
// This document and the software described in it are furnished under license
// and may be used or copied only in accordance with the terms of such license.
// This document is supplied for information purposes only, is subject to
// change without notice, and should not be construed as a commitment by
// either eFunds Corporation or eFunds Canada Corporation. 
//
static char _shc_500func_cxx_what[] = "@(#) shc_500func.cxx 2.7.1.2 20/02/04 14:16:49";

/*
 *	IST and IST/Share are registered trademarks of Oasis Technology Ltd.
 *
 *	Copyright (C) 1990 - 1997 Oasis Technology Ltd.
 *	All Rights Reserved
 *	This Module contains Proprietary Information of
 *	Oasis Technology Ltd., and should be treated as Confidential.
 *
 *	THIS IS UNPUBLISHED PROPRIETARY SOURCE CODE OF OASIS TECHNOLOGY LTD.
 *	The copyright notice above does not evidence any  
 *	actual or intended publication of such source code.
 */
/*
 *
 *                        MODIFICATION HISTORY                  REVIEW
 *
 *	SPR#	Who	Date	Description			Who	Date   
 * ===========================================================================
 *	ad		08jan92		Added support for fields amt_auth, amt_auth_rev
 *  R001654 yh 09mar99  Change C++ keyword (new) to (new_entry)
 *  R007062	gbeeng	26Nov2001	C++ Migration
 */

//File Number 143

#include <stdio.h>
#include <string.h>
#include <oasis.h>
#include <ist_otrace.h>
#include <mb.h>
#include <dbm.h>
#include <rules.h>
#include <shc.h>
#include <shc500std.h>
#include "shc_util_funcs.h"
#include <istsafe.h>

/*
 *	Internal routines for the settlement server
 */
int CreateEntry();
int FillMemoryFromDatabase( register struct shc500stddb *db,
					struct shc500std_key *key, int id);

/*
 *	Global data
 */

struct	shc500std_key	*shc500StdKey		= NULL;
struct	shc500std_text	*shc500StdText		= NULL;
struct	rules_keytab	*shc500StdRuleKeyp	= NULL;
int						shc500StdAppid		= (-1);
bin_t					shc500SwitchId		= "0000000001";

/*
 *	Static data
 */
static	int		dbmfd = (-1);
static	int		xdbmid = (-1);




int shc500_init()
{
	/*
	 *	Initialise the settlement functions
	 */
	int		appid;
	bin_t	org;

	rm_init();

	/*	Attach to the rules database */
	if((appid = rm_getappid(SHC500STD_RULENAME)) < 0)
	{
		OTraceError("E-SHC-143001:unable to locate message name: %s\n", SHC500STD_RULENAME);
		return(-1);
	}
	else {

		shc500StdRuleKeyp = rm_getapphead(appid);

		/*	Find the first entry of my key table */
		shc500StdKey	= (struct shc500std_key *)rm_getappkey(appid);
		shc500StdText	= (struct shc500std_text *)rm_getapptext(appid);
		shc500StdAppid	= appid;
	}

	if(cf_open("files/shc.cfg") < 0)
		return(-1);
	
	if(cf_locate("shc.originator", org) > 0)
		shc_normalizenumber(shc500SwitchId, org, 10);
	
	cf_close();
	
	return(0);
}


int shc500_end()
{
	dbm_close_all(xdbmid);
	return(0);
}

/*
 *	Internal functions
 */
static int OpenDatabase()
{
	if(dbmfd >= 0)
		return(dbmfd);
	
	dbm_init();
	xdbmid = getpid();

	dbmfd = dbm_open("std500_1", xdbmid);
	return(dbmfd);
}


static struct shc500std *LocateEntryInMemory(bin_t bin, date_t date)
{
	int		i;
	for(i = 0; i < shc500StdMaxKeys; ++i)
		if(shc500StdKey[i].flags & SHC500_INUSE)
		{
			if(strcmp(shc500StdKey[i].issuer, bin) == 0)
				if(date > 0 &&
			      shc500StdText[shc500StdKey[i].textid].msg.settlement_date
																==date)
					return(&shc500StdText[shc500StdKey[i].textid].msg);
				else if(date <= 0)
					return(&shc500StdText[shc500StdKey[i].textid].msg);
		}
					
	
	return(NULL);
}

static struct shc500std *LocateEntryInDatabase(bin_t bin, date_t date)
{
	int		i, id;
	struct	shc500std	*p;
	struct	shc500stddb	db;

	if(dbmfd == -1)
		if(OpenDatabase() < 0)
			return(NULL);
	
	db.msgtype = SHC500_MSG_UPDATE_DB;
	istsafe_strcpy(db.issuer, sizeof(db.issuer), bin);
	db.settlement_date = date;
	i = dbm_read(dbmfd, (char *)&db, DBM_REQUAL);

	if(i < 0)
		return(NULL);
	
	/*	try to re-use memory slot if possible */
	p = LocateEntryInMemory(bin, (date_t)(-1));
	if(p == NULL)
		id = CreateEntry();
	else
		id = p->index;

	if(id < 0)
		return(NULL);


	/*	Fill the memory with the database */
	FillMemoryFromDatabase(&db, &shc500StdKey[id], id);
	return(&shc500StdText[shc500StdKey[id].textid].msg);
}



/*static FillMemoryFromDatabase( register struct shc500stddb *db,*/
int FillMemoryFromDatabase( register struct shc500stddb *db,
					struct shc500std_key *key, int id)
{
	/*	Fill header */
	struct	shc500std_text	*tp;
	register struct	shc500std	*msg;

	tp = &shc500StdText[key->textid];
	msg = &tp->msg;

	/*	Fill in key information */
	msg->index	= id;
	strcpy(key->issuer, db->issuer);

	/*	Fill in data */
	msg->msgtype	= db->msgtype;
	msg->trace		= db->trace;
	msg->trandate	= db->trandate;
	msg->trantime	= db->trantime;
	msg->flags		= db->flags;

	msg->settlement_date	= db->settlement_date;

	strcpy(msg->forward_inst, db->forward_inst);
	strcpy(msg->issuer, db->issuer);
	strcpy(msg->acquirer, db->acquirer);
	strcpy(msg->settlement_agent, db->settlement_agent);

	msg->currency_code	= db->currency_code;
	msg->advice_reason	= db->advice_reason;
	msg->respcode	= db->respcode;
	msg->serial_number	= db->serial_number;

	strcpy(msg->network_data, db->network_data);

	msg->num_credit	= db->num_credit;
	msg->num_credit_rev	= db->num_credit_rev;

	msg->num_debit	= db->num_debit;
	msg->num_debit_rev	= db->num_debit_rev;

	msg->num_transfer	= db->num_transfer;
	msg->num_transfer_rev	= db->num_transfer_rev;

	msg->num_inquiry	= db->num_inquiry;

	msg->num_auth	= db->num_auth;
	msg->num_auth_rev	= db->num_auth_rev;

	/*	fees */
	dbm_deccopy(&msg->fee_cr_processing, &db->fee_cr_processing);
	dbm_deccopy(&msg->fee_cr_transaction, &db->fee_cr_transaction);
	dbm_deccopy(&msg->fee_db_processing, &db->fee_db_processing);
	dbm_deccopy(&msg->fee_db_transaction, &db->fee_db_transaction);


	/*	amounts */
	dbm_deccopy(&msg->amt_credit, &db->amt_credit);
	dbm_deccopy(&msg->amt_credit_rev, &db->amt_credit_rev);
	dbm_deccopy(&msg->amt_debit, &db->amt_debit);
	dbm_deccopy(&msg->amt_debit_rev, &db->amt_debit_rev);
	dbm_deccopy(&msg->amt_auth, &db->amt_auth);
	dbm_deccopy(&msg->amt_auth_rev, &db->amt_auth_rev);

	dbm_deccopy(&msg->amt_netset, &db->amt_netset);
	return(0);
}


static
int FillDatabaseFromMemory(
		register struct shc500stddb *db, struct shc500std_key *key)
{
	/*	Fill header */
	struct	shc500std_text	*tp;
	register struct	shc500std	*msg;

	tp = &shc500StdText[key->textid];
	msg = &tp->msg;

	/*	Fill in key information */
	strcpy(db->issuer, key->issuer);

	/*	Fill in data */
	db->msgtype	= msg->msgtype;
	db->trace		= msg->trace;
	db->trandate	= msg->trandate;
	db->trantime	= msg->trantime;
	db->flags		= msg->flags;

	db->settlement_date	= msg->settlement_date;

	strcpy(db->forward_inst, msg->forward_inst);
	strcpy(db->issuer, msg->issuer);
	strcpy(db->acquirer, msg->acquirer);
	strcpy(db->settlement_agent, msg->settlement_agent);

	db->currency_code	= msg->currency_code;
	db->advice_reason	= msg->advice_reason;
	db->respcode	= msg->respcode;
	db->serial_number	= msg->serial_number;

	strcpy(db->network_data, msg->network_data);

	db->num_credit	= msg->num_credit;
	db->num_credit_rev	= msg->num_credit_rev;

	db->num_debit	= msg->num_debit;
	db->num_debit_rev	= msg->num_debit_rev;

	db->num_transfer	= msg->num_transfer;
	db->num_transfer_rev	= msg->num_transfer_rev;

	db->num_inquiry	= msg->num_inquiry;

	db->num_auth	= msg->num_auth;
	db->num_auth_rev	= msg->num_auth_rev;

	/*	fees */
	dbm_deccopy(&db->fee_cr_processing, &msg->fee_cr_processing);
	dbm_deccopy(&db->fee_cr_transaction, &msg->fee_cr_transaction);
	dbm_deccopy(&db->fee_db_processing, &msg->fee_db_processing);
	dbm_deccopy(&db->fee_db_transaction, &msg->fee_db_transaction);


	/*	amounts */
	dbm_deccopy(&db->amt_credit, &msg->amt_credit);
	dbm_deccopy(&db->amt_credit_rev, &msg->amt_credit_rev);
	dbm_deccopy(&db->amt_debit, &msg->amt_debit);
	dbm_deccopy(&db->amt_debit_rev, &msg->amt_debit_rev);
	dbm_deccopy(&db->amt_auth, &msg->amt_auth);
	dbm_deccopy(&db->amt_auth_rev, &msg->amt_auth_rev);

	dbm_deccopy(&db->amt_netset, &msg->amt_netset);
	db->site_id = mbGetSiteId();
	return(0);
}



/*static CreateEntry()*/
int CreateEntry()
{
	/*	Find a free slot and return its id's */
	int		i;

	for(i = 0; i < shc500StdMaxKeys; ++i)
		if(!(shc500StdKey[i].flags & SHC500_INUSE))
		{
			shc500StdKey[i].flags = SHC500_INUSE;
			return(i);
		}
	
	return(-1);
}


static int MakeEntryNull(int i)
{
	struct	shc500std_text	*tp;
	register struct	shc500std	*msg;
	
	if(i < 0 || i >= shc500StdMaxKeys)
		return(-1);

	tp = &shc500StdText[shc500StdKey[i].textid];
	msg = &tp->msg;
	
	memset(msg, 0, sizeof(struct shc500std));

	/*	Fill in key information */
	msg->index	= i;

	/*	Fill in data */
	msg->msgtype	= SHC500_MSG_UPDATE_DB;

	/*	fees */
	dbm_dbltodec(&msg->fee_cr_processing, (double)0);
	dbm_dbltodec(&msg->fee_cr_transaction, (double)0);
	dbm_dbltodec(&msg->fee_db_processing, (double)0);
	dbm_dbltodec(&msg->fee_db_transaction, (double)0);


	/*	amounts */
	dbm_dbltodec(&msg->amt_credit, (double)0);
	dbm_dbltodec(&msg->amt_credit_rev, (double)0);
	dbm_dbltodec(&msg->amt_debit, (double)0);
	dbm_dbltodec(&msg->amt_debit_rev, (double)0);
	dbm_dbltodec(&msg->amt_auth, (double)0);
	dbm_dbltodec(&msg->amt_auth_rev, (double)0);

	dbm_dbltodec(&msg->amt_netset, (double)0);

	return(i);
}



static struct shc500std *CreateNewEntry(bin_t bin, date_t date)
{
	int		i;
	struct	shc500std_key	*key;
	struct	shc500std		*msg;

	msg = LocateEntryInMemory(bin, (-1));
	if(msg == NULL)
		i = CreateEntry();
	else
		i = msg->index;

	if(i < 0)
		return(NULL);
	
	MakeEntryNull(i);

	/*	Fill in the obvious information */
	key = &shc500StdKey[i];
	istsafe_strcpy(key->issuer, sizeof(key->issuer), bin);
	
	/*	Fill in the text information */
	msg = &shc500StdText[key->textid].msg;
	msg->settlement_date = date;

	istsafe_strcpy(msg->issuer, sizeof(msg->issuer), bin);
	strcpy(msg->settlement_agent, shc500SwitchId);
	shc500MarkEntryChanged(key);

	return(msg);
}



/*
 *	Global functions
 */
struct	shc500std	*shc500FindEntry(bin_t bin, date_t date)
{
	/*
	 *	Locate the entry for this issuer in the database
	 *
	 *	Returns a pointer to the entry or NULL
	 */
	
	struct	shc500std	*p;

	p = LocateEntryInMemory(bin, date);
	if(p)
		return(p);
	
	/*	Attempt to locat the entry in the data base */
	p = LocateEntryInDatabase(bin, date);
	if(p)
		return(p);
	
	/*	Otherwise create a new entry */
	p = CreateNewEntry(bin, date);
	if(p)
		return(p);
	
	/*	All failed */
	return(NULL);
}


int shc500UpdateEntry(struct shc500std_key *key)
{
	/*
	 *	Given a key entry update the database
	 */
	struct	shc500stddb db;
	int		new_entry = 0;		/*  R001654.  */

	if(dbmfd == -1)
		if(OpenDatabase() < 0)
			return(-1);
	
	/*
	 *	Try to locate database record
	 */
	db.msgtype = SHC500_MSG_UPDATE_DB;
	strcpy(db.issuer, key->issuer);
	db.settlement_date = shc500StdText[key->textid].msg.settlement_date;
	if(dbm_read(dbmfd, (char *)&db, DBM_REQUAL | DBM_RLOCK) != 0)
		new_entry = 1;

	/*
	 *	Fill the proper values
	 */
	FillDatabaseFromMemory(&db, key);
	db.msgtype = SHC500_MSG_UPDATE_DB;
	
	if(new_entry)
		dbm_insert(dbmfd, (char *)&db, 0);
	else
		dbm_write(dbmfd, (char *)&db, 0);
	
	shc500MarkEntryClean(key);

	dbm_commit(xdbmid);
	return(0);
}


/* 29Nov96 */
void std500Dump(struct shc500std *msg)
{
	char buf1[256], buf2[256], buf3[256], buf4[256];

	OTraceDebug("D-SHC-143002:Transaction Type: [%d]\t\tTrace[%f]\n", msg->msgtype, msg->trace);
	OTraceDebug("D-SHC-143003:NetworkID/Issuer [%s]\tForwarder [%s]\tAcquirer [%s]\n",msg->issuer, msg->forward_inst, msg->acquirer);
	dbm_dectochar(&msg->amt_netset, buf1);
	OTraceDebug("D-SHC-143004:Sttlmnt[%s]\tCurrency Code [%d]\tAdvice Reason [%d]\n",buf1, msg->currency_code, msg->advice_reason);
	OTraceDebug("D-SHC-143005:Type                   Number          Amount          Fee/Proc    Fee/Txn\n");
	OTraceDebug("D-SHC-143006: -----------------------------------------------------------------------------\n");
	dbm_dectochar(&msg->amt_credit, buf2);
	dbm_dectochar(&msg->fee_cr_processing, buf3);
	dbm_dectochar(&msg->fee_cr_transaction, buf4);
	OTraceDebug("D-SHC-143007:Credit\t\t\t[%d]\t[%s]\t[%s]\t[%s]\n", msg->num_credit, buf2, buf3, buf4);
	dbm_dectochar(&msg->amt_credit_rev, buf2);
	OTraceDebug("D-SHC-143008:Credit/Rev\t[%d]\t[%s]\n", msg->num_credit_rev, buf2);
	dbm_dectochar(&msg->amt_debit, buf2);
	dbm_dectochar(&msg->fee_db_processing, buf3);
	dbm_dectochar(&msg->fee_db_transaction, buf4);
	OTraceDebug("D-SHC-143009:Debit\t\t\t[%d]\t[%s]\t[%s]\t[%s]\n", msg->num_debit, buf2, buf3, buf4);
	OTraceDebug("D-SHC-143010:Authorizations\t\t\t[%d]\n", msg->num_auth);
	OTraceDebug("D-SHC-143011:Authorizations/Rev\t[%d]\n", msg->num_auth_rev);
	OTraceDebug("D-SHC-143012:Transfers            [%d]\n", msg->num_transfer);
	OTraceDebug("D-SHC-143013:Transfers/Rev        [%d]\n", msg->num_transfer_rev);
	OTraceDebug("D-SHC-143014:Inquiry				 [%d]\n", msg->num_inquiry);
}
int shc500InstantDBUpdate( struct shc500std *msg )
{
	struct	shc500stddb	db;
	char	buf[256];
	int		new_entry = 0;		/*  R001654.  */

	/* std500Dump(msg); */
	/* Perform database update */

	if(dbmfd == -1)
		if(OpenDatabase() < 0)
			return(-1);
	
	db.msgtype	= msg->msgtype;
	db.settlement_date	= msg->settlement_date;
	strcpy(db.issuer, msg->issuer);
	/*
	 *	Try to locate database record
	 */
	if(dbm_read(dbmfd, (char *)&db, DBM_REQUAL | DBM_RLOCK) != 0)
		new_entry = 1;

	db.trandate	= msg->trandate;
	db.trace		= msg->trace;
	db.trantime	= msg->trantime;
	db.flags		= msg->flags;


	strcpy(db.forward_inst, msg->forward_inst);
	strcpy(db.acquirer, msg->acquirer);
	strcpy(db.settlement_agent, msg->settlement_agent);

	db.currency_code	= msg->currency_code;
	db.advice_reason	= msg->advice_reason;
	db.respcode	= msg->respcode;
	db.serial_number	= msg->serial_number;

	strcpy(db.network_data, msg->network_data);

	db.num_credit	= msg->num_credit;
	db.num_credit_rev	= msg->num_credit_rev;

	db.num_debit	= msg->num_debit;
	db.num_debit_rev	= msg->num_debit_rev;

	db.num_transfer	= msg->num_transfer;
	db.num_transfer_rev	= msg->num_transfer_rev;

	db.num_inquiry	= msg->num_inquiry;

	db.num_auth	= msg->num_auth;
	db.num_auth_rev	= msg->num_auth_rev;

	/*	fees */
	dbm_deccopy(&(db.fee_cr_processing), &msg->fee_cr_processing);
	dbm_deccopy(&(db.fee_cr_transaction), &msg->fee_cr_transaction);
	dbm_deccopy(&db.fee_db_processing, &msg->fee_db_processing);
	dbm_deccopy(&db.fee_db_transaction, &msg->fee_db_transaction);


	/*	amounts */
	dbm_deccopy(&db.amt_credit, &msg->amt_credit);
	dbm_deccopy(&db.amt_credit_rev, &msg->amt_credit_rev);
	dbm_deccopy(&db.amt_debit, &msg->amt_debit);
	dbm_deccopy(&db.amt_debit_rev, &msg->amt_debit_rev);
	dbm_deccopy(&db.amt_auth, &msg->amt_auth);
	dbm_deccopy(&db.amt_auth_rev, &msg->amt_auth_rev);

	dbm_deccopy(&db.amt_netset, &msg->amt_netset);
	dbm_dectochar(&db.amt_netset, buf);

	if(new_entry)
		dbm_insert(dbmfd, (char *)&db, 0);
	else
		dbm_write(dbmfd, (char *)&db, 0);
	
	dbm_commit(xdbmid);
	return( 0 );
}

