//
// Copyright (C) 2004 eFunds Corporation ("eFunds").  All Rights Reserved.  
// eFunds Canada Corporation is an authorized user. 
// 
// IST is a registered trademark of eFunds Corporation.  Other brand or
// product names are trademarks or registered trademarks of their respective
// holders. 
// 
// The information contained herein is the unpublished proprietary property
// of eFunds.  Except as specifically authorized in writing by eFunds, the
// holder of this document shall: i) keep all information contained herein
// confidential, and ii) protect the information, in whole or in part, from
// disclosure and dissemination to all third parties. 
// 
// This document and the software described in it are furnished under license
// and may be used or copied only in accordance with the terms of such license.
// This document is supplied for information purposes only, is subject to
// change without notice, and should not be construed as a commitment by
// either eFunds Corporation or eFunds Canada Corporation. 
//

/*
 *	IST and IST/Share are registered trademarks of Oasis Technology Ltd.
 *
 *	Copyright (C) 1990 - 1999 Oasis Technology Ltd.
 *	All Rights Reserved
 *	This Module contains Proprietary Information of
 *	Oasis Technology Ltd., and should be treated as Confidential.
 *
 *	THIS IS UNPUBLISHED PROPRIETARY SOURCE CODE OF OASIS TECHNOLOGY LTD.
 *	The copyright notice above does not evidence any  
 *	actual or intended publication of such source code.
 */
/*
 *
 *                        MODIFICATION HISTORY                  REVIEW
 *
 *	SPR#	Who	Date		Description			Who	Date   
 * ===========================================================================
 * R008717 ztang 15May02	Creation
 */

#include <stdio.h>
#include <signal.h>
#include <stdlib.h>
#include <errno.h>
#include <oasis.h>
#include <mb.h>
#include <mb_umi.h>
#include <tsk.h>
#include <rules.h>
#include <config.h>
#include <string.h>
#include <shc.h>
#include <multi_institution.h>
#include <ist_otrace.h>
#include <InstProfile.h>
#include <BinRoute.h>
#include <CShcLog.h>
#include <iostream>
#include <vector>
#include <ShcmsgHeader.h>
#include<ist_seg_name.h>
#include<ist_seg_fn_data.h>
#include<ist_seg_elf_id_map.h>
#include <ShcmsgProcessor.h>
#include <Shc300Helper.h>
#include <ShcApp.h>
#include <ShcHelper.h>
#include <ist_seg_id.h>



using namespace std;

ShcLog *shcmsgLogObj = NULL;

//initDB();
//int prepareUpdateVoid();
//virtual int prepareUpdateReversal();
//virtual int prepareUpdateFinCapture();
//virtual int doUpdateVoid();
//virtual int doUpdateReversal();
//virtual int doUpdateFinCapture();

#include <Shc300Header.h>
#include <ShcTimerHelper.h>
#include <ShcmsgTxnHelper.h>
#include <ShcBin.h>
#include <ShcmsgHelper.h>
#include <ShcmsgHeader.h>
#include <ShcApp.h>
#include <ShcFinAuthHelper.h>


int main(int argc, char **argv)
{
	argv0 = *argv;
	char buf[200];
	char choice[10];

	if (argc < 2)
	{
		printf("Usage:%s <bin_instid> <bin_userbinid> <inst_profile_id>\n",argv[0]);
		printf("The bin must have pinverparm\n");
		printf("The inst_profile must have keyparam\n");
		return 0;
	}
	OTraceOn(argv0);
	ist_otrace_set_level(OTRACE_DEBUG);

	mb_init();
	dbm_init();
	shcApp=thisShcApp= new ShcApp();
	shc_init();

	shcmid = mb_locatemailbox("SharedCash");
	thisShcApp->netid = mb_locatemailbox("ShcNetworkManager");

    ShcmsgHeader h;
    bin_t b;
    strcpy(b, argv[2]);
    thisShcApp = new ShcApp;
    thisShcApp->shcmsgHelperObj->shc_normalizebin(b);
	bin_t internalBin;
	if (shc_externalBin2InternalBin(internalBin, argv[1], b) < 0)
	{
		printf("bin[%s,%s] can't be found.\n",argv[1], b);
		return 0;
	}
    h.setIssShcBin(internalBin);
    h.setAcqShcBin(internalBin);
	
	int id = shcApp->instProfileObj->locateById(atoi(argv[3]));
	if (id < 0)
	{
		printf("can't find inst_profile for id[%s].\n", argv[3]);
		return 0;
	}
	struct InstitutionProfile *ip = (struct InstitutionProfile *)shcApp->instProfileObj->getEntry(id);
	if (!ip)
	{
		printf("can't find inst_profile for id[%s].\n", argv[3]);
		return 0;
	}
	if (ip->keyparm<0)
	{
		printf("keyparm empty in inst_profile id[%s].\n", argv[3]);
		return 0;
	}
	h.setSegmentData((char *)ip, sizeof(*ip), NETWORK_DATA_REQ_id, ACQ_INST_PROFILE_ENTRY);
	h.setSegmentData((char *)ip, sizeof(*ip), NETWORK_DATA_REQ_id, ISS_INST_PROFILE_ENTRY);
	h.issShcBin->setKey(ip);
	h.acqShcBin->setKey(ip);

	int counter = 1;

	RoutingInfo lr;
	RoutingInfo rr;
	lr.flag = ROUTE_INFO_FLAG_USE_FOR_REQ | ROUTE_INFO_FLAG_USE_BINROUTE;
	rr.flag = ROUTE_INFO_FLAG_USE_FOR_REQ | ROUTE_INFO_FLAG_USE_BINROUTE;

	strcpy(rr.destNode, "othernode");
	strcpy(rr.srcNode, mbcurrentnode);
	strcpy(lr.destNode, mbcurrentnode);
	strcpy(lr.srcNode, "othernode");
	strcpy(h.msg.pan, "1234123412341234   ");

	//********non-Interac 
	h.issShcBin->binPkg->bin.bin_cfg &= ~SH_CFG_INTERAC;

	//1:device to net
	sprintf(h.msg.pin, "%016d", counter);
	h.msg.device_cap = 0;
	h.setSegmentData((char *)&lr, sizeof(lr), NETWORK_DATA_REQ_id,ROUTING_INFO);
	int ret = thisShcApp->shcFinAuthHelperObj->translatePinBlock(&h);
	memset(h.msg.shc_data_buffer, 0, sizeof(h.msg.shc_data_buffer));
	sprintf(h.msg.pin, "%016d", counter);
	h.setSegmentData((char *)&rr, sizeof(rr), NETWORK_DATA_REQ_id,ROUTING_INFO);
	ret = thisShcApp->shcFinAuthHelperObj->translatePinBlock(&h);
	h.setSegmentData((char *)&lr, sizeof(rr), NETWORK_DATA_REQ_id,ROUTING_INFO);
	ret = thisShcApp->shcFinAuthHelperObj->translatePinBlock(&h);

	//********Interac
	ODebug("Interac device to net******************\n");
	h.issShcBin->binPkg->bin.bin_cfg |= SH_CFG_INTERAC;
	counter++;
	sprintf(h.msg.pin, "%016d", counter);
	h.msg.device_cap = 0;
	memset(h.msg.shc_data_buffer, 0, sizeof(h.msg.shc_data_buffer));
	h.setSegmentData((char *)&lr, sizeof(lr), NETWORK_DATA_REQ_id,ROUTING_INFO);
	ret = thisShcApp->shcFinAuthHelperObj->translatePinBlock(&h);
	memset(h.msg.shc_data_buffer, 0, sizeof(h.msg.shc_data_buffer));
	sprintf(h.msg.pin, "%016d", counter);
	h.setSegmentData((char *)&rr, sizeof(rr), NETWORK_DATA_REQ_id,ROUTING_INFO);
	ret = thisShcApp->shcFinAuthHelperObj->translatePinBlock(&h);
	h.setSegmentData((char *)&lr, sizeof(rr), NETWORK_DATA_REQ_id,ROUTING_INFO);
	ret = thisShcApp->shcFinAuthHelperObj->translatePinBlock(&h);

	ODebug("Interac net to net******************\n");
	counter++;
	sprintf(h.msg.pin, "%016d", counter);
	h.msg.device_cap = SH_DEVCAP_FROM_NETWORK;
	memset(h.msg.shc_data_buffer, 0, sizeof(h.msg.shc_data_buffer));
	h.setSegmentData((char *)&lr, sizeof(lr), NETWORK_DATA_REQ_id,ROUTING_INFO);
	ret = thisShcApp->shcFinAuthHelperObj->translatePinBlock(&h);
	memset(h.msg.shc_data_buffer, 0, sizeof(h.msg.shc_data_buffer));
	sprintf(h.msg.pin, "%016d", counter);
	h.setSegmentData((char *)&rr, sizeof(rr), NETWORK_DATA_REQ_id,ROUTING_INFO);
	ret = thisShcApp->shcFinAuthHelperObj->translatePinBlock(&h);
	h.setSegmentData((char *)&lr, sizeof(rr), NETWORK_DATA_REQ_id,ROUTING_INFO);
	ret = thisShcApp->shcFinAuthHelperObj->translatePinBlock(&h);

	OTraceOff();
	
	return 0;
}

