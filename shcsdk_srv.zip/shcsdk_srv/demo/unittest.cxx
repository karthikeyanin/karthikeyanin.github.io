static char _unittest_cxx_what[] = "@(#) unittest.cxx 1.2 12/05/29 06:38:08";

/*
 *  Copyright (C) 2004 eFunds Corporation ("eFunds").  All Rights Reserved.     
 *  eFunds Canada Corporation is an authorized user.                            
 *                                                                              
 *  IST is a registered trademark of eFunds Corporation.  Other brand or        
 *  product names are trademarks or registered trademarks of their respective   
 *  holders.                                                                    
 *                                                                              
 *  The information contained herein is the unpublished proprietary property    
 *  of eFunds.  Except as specifically authorized in writing by eFunds, the     
 *  holder of this document shall: i) keep all information contained herein     
 *  confidential, and ii) protect the information, in whole or in part, from    
 *  disclosure and dissemination to all third parties.                          
 *                                                                          
 *  This document and the software described in it are furnished under license  
 *  and may be used or copied only in accordance with the terms of such license.
 *  This document is supplied for information purposes only, is subject to      
 *  change without notice, and should not be construed as a commitment by       
 *  either eFunds Corporation or eFunds Canada Corporation. 
 */
/*
 *
 *                        MODIFICATION HISTORY                  REVIEW
 *
 *	SPR#	Who	Date	Description			Who	Date   
 * ===========================================================================
 * R000000 ztang        Creation
 */

//File Number 137

#include <stdio.h>
#include <string.h>
#include <oasis.h>
#include <oasisenv.h>
#include<ic/ic_instid.h>
#include<ic/ic_bin.h>
#include <ist_otrace.h>
#include <util.h>
#include <mb.h>
#include <rules.h>

/* R002563 */
#include <DBM3.h>
#include <dbm.h>
#include <dbm_private.h>
#include <shc.h> 
#include <ShcApp.h>
#include <ShcHelper.h>
#include <ShcBin.h>
#include <ShcSafIOHelper.h>
#include <ist_argv0.h>
#include <ShcCamHelper.h>
#include <ShcFinAuthHelper.h>
#include <DNSegHelper.h>

int main(int a_rgc, char **a_rgv)
{
	char answer[128];
	int ret;
//	argv = a_rgv;
//	argc = a_rgc;
	int len;
	printf("stage:%d\n",__LINE__);

	argv0 = *a_rgv;
	printf("stage:%d\n",__LINE__);
	catch_all_signals(NULL);
	printf("stage:%d\n",__LINE__);

	OTraceOn(argv0);
	printf("stage:%d\n",__LINE__);
	

	noBraodcastFlag = 1;
	mb_init();
	printf("stage:%d\n",__LINE__);
	if(dbm_init() == -1)
		return(-1);
	printf("stage:%d\n",__LINE__);

	thisShcApp = new ShcApp;
	printf("stage:%d\n",__LINE__);

	dbmid = getpid();
	
	struct shcpkg pkg = { 0 };
	pkg.bin.bin_cfg |= SH_CFG_EMV_STIP;
	ShcmsgHeader h1;
	h1.msg.msgtype = SHC_FINREQ;
	h1.issShcBin = new ShcBin;
	h1.issShcBin->setBinPkg(&pkg);
	printf("stage:%d\n",__LINE__);
	ret = thisShcApp->shcCamHelperObj->shc_cam_stip_request_start (&h1);
	printf("Check unittest.debug, there should be no 'I-SHC-064001'\n");
	printf("press <ENTER> to continue\n");
	getchar();
	
	emv tmpEmv = { 0 };
	h1.setSegmentData((char *)&tmpEmv, sizeof(tmpEmv), EMV_BUF_id, 0);
	h1.msg.formatter_devcap =0;
	ret = thisShcApp->shcCamHelperObj->shc_cam_stip_request_start (&h1);
	printf("Check unittest.debug, there should be 'I-SHC-064001'\n");
	printf("press <ENTER> to continue\n");
	getchar();
	
	struct shcmsg msg2 = { 0 };
	h1.allocateAndCopyReqMsg(&msg2);
	tmpEmv.term_type = 2;
	h1.setSegmentData((char *)&tmpEmv, sizeof(tmpEmv), EMV_BUF_id, 0);
	thisShcApp->shcFinAuthHelperObj->shc_restore_fields(&h1);
	emv tmpEmv2 = { 0 };
	len = sizeof(tmpEmv2);
	h1.getSegmentData((char *)&tmpEmv2, &len, EMV_BUF_id, 0);
	if (tmpEmv2.term_type != 2)
	{
		printf("shc_restore_fields test: test 1 failed\n");
	}
	
	tmpEmv2.term_type = 3;
	h1.setReqSegmentData((char *)&tmpEmv2, sizeof(tmpEmv), EMV_BUF_id, 0);
	thisShcApp->shcFinAuthHelperObj->shc_restore_fields(&h1);
	tmpEmv2.term_type = 0;
	h1.getSegmentData((char *)&tmpEmv2, &len, EMV_BUF_id, 0);
	if (tmpEmv2.term_type != 3)
	{
		printf("shc_restore_fields test: test 2 failed\n");
	}

	printf("stage:%d\n",__LINE__);

	shc_init();
	
	#include <ist_seg_dn.h>
	DNSegHelper *dnHelper = new DNSegHelper();
	printf("input inst_id entity_id card_scheme\n");
	char inst_id[32], entity_id[32], card_scheme[32];
	scanf("%s %s %s\n", inst_id, entity_id, card_scheme);
	dnHelper->setAlternateMerchantID(&h1, inst_id, entity_id, card_scheme);

	SHCLOG_DN    dnbuf;
	dnHelper->setDNSegmentValue(&h1);
	len = sizeof(dnbuf);
	h1.getSegmentData((char *)&dnbuf, &len, DN_SEG_id, 0);
	printf("shclog_id[%s]\n", dnbuf.shclog_id);       
	printf("alt_merchant_id:[%s]\n", dnbuf.alt_merchant_id); 
	printf("alt_terminal_id:[%s]\n", dnbuf.alt_terminal_id);  
	printf("card_category:[%c]\n", dnbuf.card_category);       
	printf("clerk_id[%d]\n", dnbuf.clerk_id);            
	printf("debit_proc_busday[%d]\n",  dnbuf.debit_proc_busday);   
	printf("device_type[%s]\n",dnbuf.device_type);      
	printf("issuer_proc_id[%s]\n",dnbuf.issuer_proc_id);
	printf("pos_geo_location[%s]\n",dnbuf.pos_geo_location);
	printf("customer_id[%s]\n",dnbuf.customer_id);     
	printf("acquiring_channel[%s]\n",dnbuf.acquiring_channel);
	printf("transaction_group[%s]\n",dnbuf.transaction_group);

	thisShcApp->shcmsgLogObj->logTxn(&h1);



	return 0;
}
