#ifndef _DEMOPROCESSORFACTORY_H_
#define _DEMOPROCESSORFACTORY_H_

static char _DemoProcessorFactory_h_what[] = "@(#) DemoProcessorFactory.h 1.1 04/07/19 11:54:21";
/*
 *  Copyright (C) 2004 eFunds Corporation ("eFunds").  All Rights Reserved.     
 *  eFunds Canada Corporation is an authorized user.                            
 *                                                                              
 *  IST is a registered trademark of eFunds Corporation.  Other brand or        
 *  product names are trademarks or registered trademarks of their respective   
 *  holders.                                                                    
 *                                                                              
 *  The information contained herein is the unpublished proprietary property    
 *  of eFunds.  Except as specifically authorized in writing by eFunds, the     
 *  holder of this document shall: i) keep all information contained herein     
 *  confidential, and ii) protect the information, in whole or in part, from    
 *  disclosure and dissemination to all third parties.                          
 *                                                                          
 *  This document and the software described in it are furnished under license  
 *  and may be used or copied only in accordance with the terms of such license.
 *  This document is supplied for information purposes only, is subject to      
 *  change without notice, and should not be construed as a commitment by       
 *  either eFunds Corporation or eFunds Canada Corporation. 
 *
 *                        MODIFICATION HISTORY                  REVIEW
 *
 * SCR#     Who    Date  Description
 * ===========================================================================
 * R0xxxxx 
 */


#include <oasis.h>
#include <ShcProcessor.h>
#include <SdkTargetFactory.h>
#include <ShcProcessorFactory.h>

class DemoProcessor : public ShcProcessor
{
	ShcBaseTxn *classify();	//Get base transaction object
	int getBINs();			//Set appropriate  bins in header
	int log();				//Log the transaction
	int route();			//Route the transaction
public:
	DemoProcessor(char *msgbuf);
	//virtual ~ShcmsgProcessor();
	int process();			//Begin process this message
};

class DemoProcessorFactory : public ShcProcessorFactory
{
public:
	virtual ShcProcessor *getTargetObj(char *condition, void *msg);
};

#endif
