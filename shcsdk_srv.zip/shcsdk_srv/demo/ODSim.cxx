#include <stdio.h>
#include <string.h>
#include <ctype.h>
#include <time.h>
#include <dirent.h>
#include <stdarg.h>
#include <stdlib.h>

#include <oasis.h>
#include <mb.h>
#include <tm.h>
#include <shc.h>
#include <oc/oc_thread.h>

#include <ShcApp.h>
#include <ShcHelper.h>
#include <ShcBin.h>
#include <ShcmsgHeader.h>
#include <ShcTimerHelper.h>
#include <ShcmsgODHeader.h>

int main( int argc, char **argv )
{
    argv0 = *argv;

	OTraceOn(argv0);
	ist_otrace_set_level(7);

	mb_init();
	int mbid = mb_locateoutbound("OndotTLVFormatter");
	if (mbid <0)
	{
		printf("Can't find mailbox ONDOTFMT\n");
		return 0;
	}
	if (argc<2)
	{
		printf("Usage:%0 <OD DE39> <OD vector>\n");
		return 0;
	}

	struct ShcmsgWithSegment msg;
	int len;

	struct s_ODDecision od;
	od.msgtype = 8610;
	strcpy(od.DE39, argv[1]);
	strcpy(od.OnDotVector, argv[2]);

	while (1)
	{
		len = mb_read(mbid, &msg, sizeof(msg));
		if (len < sizeof (struct shcmsg))
		{
			printf("msg too small:%d, drop\n", len);
			continue;
		}
		strcpy(od.logId, msg.msg.shclog_id);
		od.eventId = msg.msg.netcode;
		mb_write(mbLastSenderId(), mbid, &od, sizeof(od));
	}
	return 0;
}
		

		

	

