#include <stdio.h>
#include <string.h>
#include <ctype.h>
#include <time.h>
#include <dirent.h>
#include <stdarg.h>
#include <stdlib.h>

#include <oasis.h>
#include <mb.h>
#include <tm.h>
#include <shc.h>
#include <oc/oc_thread.h>

#include <ShcApp.h>
#include <ShcHelper.h>
#include <ShcBin.h>
#include <ShcmsgHeader.h>
#include <ShcTimerHelper.h>
#include <ShcmsgFMHeader.h>

int main( int argc, char **argv )
{
    argv0 = *argv;

	OTraceOn(argv0);
	ist_otrace_set_level(7);

	mb_init();
	int mbid = mb_locateoutbound("FMformatter");
	if (mbid <0)
	{
		printf("Can't find mailbox FMformatter\n");
		return 0;
	}
	if (argc<2)
	{
		printf("Usage:%s <FM respcode> <FM reasoncode> <FM rulelist> <FM domain_list> <FM rulecount> <FM domaincount>\n"
			" Example: %s 0 23 rule1 domain1 1 1\n", argv[0], argv[0]);
		return 0;
	}

	struct ShcmsgWithSegment msg;
	int len;

	struct s_FMDecision fm;
	fm.msgtype = 8110;
	fm.respcode = atoi( argv[1]);
	strcpy(fm.reasoncode ,argv[2]);
	strcpy(fm.rule_list, argv[3]);
	strcpy(fm.domain_list, argv[4]);
	fm.rule_count = atoi( argv[5]);
	fm.domain_count = atoi( argv[6]);
	strcpy(fm.additionalInfo, "test");

	while (1)
	{
		len = mb_read(mbid, &msg, sizeof(msg));
		if (len < sizeof (struct shcmsg))
		{
			printf("msg too small:%d, drop\n", len);
			continue;
		}
		fm.flipped_msgtype = msg.msg.flipped_msgtype;
		strcpy(fm.pan, msg.msg.pan);
		fm.pcode = msg.msg.pcode;
		memcpy(&fm.amount, &msg.msg.amount, sizeof(fm.amount));
		memcpy(&fm.new_amount, &msg.msg.new_amount, sizeof(fm.amount));
		fm.trace = msg.msg.trace;
		fm.pos_entry_code = msg.msg.pos_entry_code;
		strcpy(fm.acquirer, msg.msg.acquirer);
		strcpy(fm.issuer, msg.msg.issuer);
		strcpy(fm.transferee, msg.msg.transferee);
		fm.origmsg = msg.msg.origmsg;
		strcpy(fm.txnSrc, msg.msg.txnSrc);
		strcpy(fm.txnDest, msg.msg.txnDest);

		mb_write(mbLastSenderId(), mbid, &fm, sizeof(fm));
	}
	return 0;
}
		

		

	

