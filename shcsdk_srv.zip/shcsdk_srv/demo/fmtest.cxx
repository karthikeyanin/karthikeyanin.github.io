static char _fmtest_cxx_what[] = "@(#) fmtest.cxx 1.2 12/05/29 06:38:15";

#include <stdio.h>
#include <string.h>
#include <ctype.h>
#include <oasis.h>
#include <ist_otrace.h>
#include <shcdef.h>
#include <shc.h>
#include <FMInstList.h>
#include <ShcmsgFMHelper.h>

int main()
{
char instlist1[]="23:43:56:76:78:98:3:6:991:100";
char instlist2[]="1:11:111";
char instlist3[]="all";
int choice=0;

	ShcmsgFMHelper *shcmsgFMHelperObj;
	shcmsgFMHelperObj = new ShcmsgFMHelper;
	printf("Created ShcmsgFMHelper obj\n");
	printf("inst list1 is [%s]\n",instlist1);
	printf("inst list2 is [%s]\n",instlist2);
	printf("inst list3 is [%s]\n",instlist3);

	printf("Input which instlist to set: ");
	scanf("%d",&choice);

	if(choice == 1){
	if(shcmsgFMHelperObj->update_record(FM_INST_ADD,instlist1) == -1)
	{
		printf("update_record failed\n");
	}
	}
	else if(choice == 2)
	{
	if(shcmsgFMHelperObj->update_record(FM_INST_ADD,instlist2) == -1)
	{
		printf("update_record failed\n");
	}
	}
	else if(choice == 3)
	{
	if(shcmsgFMHelperObj->update_record(FM_INST_ADD,instlist3) == -1)
	{
		printf("update_record failed\n");
	}
	}
	printf("exiting\n");
	return 0;
}
