static char _DemoProcessor_cxx_what[] = "@(#) DemoProcessor.cxx 1.4 05/05/20 18:31:09";

/*
 *  Copyright (C) 2004 eFunds Corporation ("eFunds").  All Rights Reserved.     
 *  eFunds Canada Corporation is an authorized user.                            
 *                                                                              
 *  IST is a registered trademark of eFunds Corporation.  Other brand or        
 *  product names are trademarks or registered trademarks of their respective   
 *  holders.                                                                    
 *                                                                              
 *  The information contained herein is the unpublished proprietary property    
 *  of eFunds.  Except as specifically authorized in writing by eFunds, the     
 *  holder of this document shall: i) keep all information contained herein     
 *  confidential, and ii) protect the information, in whole or in part, from    
 *  disclosure and dissemination to all third parties.                          
 *                                                                          
 *  This document and the software described in it are furnished under license  
 *  and may be used or copied only in accordance with the terms of such license.
 *  This document is supplied for information purposes only, is subject to      
 *  change without notice, and should not be construed as a commitment by       
 *  either eFunds Corporation or eFunds Canada Corporation. 
 *
 *
 *                        MODIFICATION HISTORY                  REVIEW
 *
 * SCR#     Who    Date  Description
 * ===========================================================================
 * R0xxxxx 
 */
 
 /* File Number 144 */
 
#include <ist_otrace.h>
#include <tm.h>
#include <shc.h>
#include <shcextbuf.h>
#include <shc_callback.h>
#include <ShcSender.h>
#include <ShcSdkCommon.h>
#include <CShcLog.h>
#include <ShcMsgCache.h>
#include <ShcTimerHelper.h>
#include <CShcNotify.h>
#include <ShcFinAuthReq.h>
#include <ShcFinAuthResp.h>
#include <ShcMacHelper.h>
#include <ShcnetEventMsg.h>
#include <ShcnetNetworkMsg.h>
#include <ShcTimerHelper.h>
#include <ShcNetworkMsgHelper.h>
#include <ShcApp.h>
#include <tmp_ShcOthers.h>

#include <ShcmsgHeader.h>
#include <ShcProcessorRegistration.h>
#include <DemoProcessorFactory.h>


//int shc_callback(ShcHeader *header,const char *processingPoint);

DemoProcessor::DemoProcessor(char *msgbuf)
{
	header = new ShcmsgHeader((struct shcmsg *)msgbuf);
}

ShcBaseTxn *DemoProcessor::classify()
{
	OTraceDebug("D-DEMOSDK-14401:In classify()\n");
	return NULL;
}

int DemoProcessor::getBINs()
{
	OTraceDebug("D-DEMOSDK-14402:This is getBINs()\n");
	return(0);

}

int DemoProcessor::log()
{
	OTraceDebug("D-DEMOSDK-14403:This is log()\n");
	return 0;
}

int DemoProcessor::route()
{
	OTraceDebug("D-DEMOSDK-14404:This is route()\n");
	return 0;
}

int DemoProcessor::process()
{
	ShcmsgHeader *thisHeader = (ShcmsgHeader *)header;
	
	
	getBINs();

	log();
	route();
	
	
	return(0);
	
}

#include <ShcmsgTxnFactory.h>

ShcProcessor *DemoProcessorFactory::getTargetObj(char *condition, void *msgBuf)
{
	OTraceDebug("D-DEMOSDK-14405:Creating DemoProcessor\n");
	return new DemoProcessor((char *)msgBuf);


}

extern "C"
int register_demoProcessor(ShcProcessorRegistration *registration, char *acceptableConditions)
{
	ShcProcessorFactory *shcProcessorFactory = new DemoProcessorFactory;
	shcProcessorFactory->setConditions(acceptableConditions);
	registration->registerTargetFactory(shcProcessorFactory);

	return 0;
}





