static char _unittest_cxx_what[] = "@(#) sendcardstatus.cxx 1.1 17/06/20 11:56:08";

/*
 *  Copyright (C) 2004 eFunds Corporation ("eFunds").  All Rights Reserved.     
 *  eFunds Canada Corporation is an authorized user.                            
 *                                                                              
 *  IST is a registered trademark of eFunds Corporation.  Other brand or        
 *  product names are trademarks or registered trademarks of their respective   
 *  holders.                                                                    
 *                                                                              
 *  The information contained herein is the unpublished proprietary property    
 *  of eFunds.  Except as specifically authorized in writing by eFunds, the     
 *  holder of this document shall: i) keep all information contained herein     
 *  confidential, and ii) protect the information, in whole or in part, from    
 *  disclosure and dissemination to all third parties.                          
 *                                                                          
 *  This document and the software described in it are furnished under license  
 *  and may be used or copied only in accordance with the terms of such license.
 *  This document is supplied for information purposes only, is subject to      
 *  change without notice, and should not be construed as a commitment by       
 *  either eFunds Corporation or eFunds Canada Corporation. 
 */
/*
 *
 *                        MODIFICATION HISTORY                  REVIEW
 *
 *	SPR#	Who	Date	Description			Who	Date   
 * ===========================================================================
 * R000000 ztang        Creation
 */

//File Number 137

#include <stdio.h>
#include <string.h>
#include <oasis.h>
#include <oasisenv.h>
#include<ic/ic_instid.h>
#include<ic/ic_bin.h>
#include <ist_otrace.h>
#include <util.h>
#include <mb.h>
#include <rules.h>

/* R002563 */
#include <DBM3.h>
#include <dbm.h>
#include <dbm_private.h>
#include <shc.h> 
#include <ShcApp.h>
#include <ShcHelper.h>
#include <ShcBin.h>
#include <ShcSafIOHelper.h>
#include <ist_argv0.h>
#include <ShcCamHelper.h>
#include <ShcFinAuthHelper.h>
#include <DNSegHelper.h>
#include <ist_seg_elf_id_map.h>
#include <ist_seg_name.h>
#include <ist_seg_shc300_req.h>

int main(int argc, char **argv)
{
	if (argc < 5)
	{
		printf("Usage: sendcardstatus <filename> <updatecode> <bin_internal_id> <flag> <pan> <from_mbid> <to_mbid> <txnSrc> <actionCode>\n"
			"filename: E2, E3, E4, A2, P2, MCC102, MCC103, MCCNEG, MCC107, MCC108, CG, NRT\n"
			"updatecode: 1(add), 2(update), 3(delete), 4(replace), 5(query)\n"
			"flag bits: 1(upd db), 2(route), 4(debit route)\n"
			"actionCode: any valid response code\n");
		return (0);
	}
	char answer[128];
	int ret;
	int len;
	printf("stage:%d\n",__LINE__);

	argv0 = *argv;
	catch_all_signals(NULL);

	OTraceOn(argv0);
	

	noBraodcastFlag = 1;
	mb_init();
	if(dbm_init() == -1)
		return(-1);

	thisShcApp = new ShcApp;

	dbmid = getpid();
	
	ShcmsgHeader h1;
	IstSegShc300Req req300;

	req300.setFilename(argv[1], strlen(argv[1]));
	req300.setFileupdatecode(argv[2], strlen(argv[2]));
	req300.setFlags(argv[3], strlen(argv[3]));
	req300.setActioncode(argv[9], strlen(argv[9]));
	
	h1.msg.msgtype = 302;
	strcpy(h1.msg.issuer, argv[4]);
	strcpy(h1.msg.pan, argv[5]);
	shc_normalizepan(h1.msg.pan);
	shc_normalizebin(h1.msg.issuer);
	strcpy(h1.msg.txnSrc, argv[8]);
	req300.setISO_RECEIVER(h1.msg.issuer, strlen(h1.msg.issuer));
	h1.msg.trace = time(NULL)%999999+1;
	
	char buf[4096] = { 0 };
	int buflen = sizeof(buf);
	printf("%d for bin(%s) pan(%s)\n", h1.msg.msgtype, h1.msg.issuer, h1.msg.pan);
	req300.flattenSegMemcpy(buf, &buflen);
	h1.setSegmentData(buf, buflen, ElfIdMap::elf_to_id(IST_SEG_SHC300_REQ), 0);
	mb_write(atoi(argv[7]), atoi(argv[6]), &h1.msg, h1.truelength());

	return 0;
}
