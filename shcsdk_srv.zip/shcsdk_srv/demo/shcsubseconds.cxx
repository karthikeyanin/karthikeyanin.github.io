//
// Copyright (C) 2004 eFunds Corporation ("eFunds").  All Rights Reserved.  
// eFunds Canada Corporation is an authorized user. 
// 
// IST is a registered trademark of eFunds Corporation.  Other brand or
// product names are trademarks or registered trademarks of their respective
// holders. 
// 
// The information contained herein is the unpublished proprietary property
// of eFunds.  Except as specifically authorized in writing by eFunds, the
// holder of this document shall: i) keep all information contained herein
// confidential, and ii) protect the information, in whole or in part, from
// disclosure and dissemination to all third parties. 
// 
// This document and the software described in it are furnished under license
// and may be used or copied only in accordance with the terms of such license.
// This document is supplied for information purposes only, is subject to
// change without notice, and should not be construed as a commitment by
// either eFunds Corporation or eFunds Canada Corporation. 
//

/*
 *	IST and IST/Share are registered trademarks of Oasis Technology Ltd.
 *
 *	Copyright (C) 1990 - 1999 Oasis Technology Ltd.
 *	All Rights Reserved
 *	This Module contains Proprietary Information of
 *	Oasis Technology Ltd., and should be treated as Confidential.
 *
 *	THIS IS UNPUBLISHED PROPRIETARY SOURCE CODE OF OASIS TECHNOLOGY LTD.
 *	The copyright notice above does not evidence any  
 *	actual or intended publication of such source code.
 */
/*
 *
 *                        MODIFICATION HISTORY                  REVIEW
 *
 *	SPR#	Who	Date		Description			Who	Date   
 * ===========================================================================
 * R008717 ztang 15May02	Creation
 */

#include <stdio.h>
#include <signal.h>
#include <stdlib.h>
#include <errno.h>
#include <oasis.h>
#include <mb.h>
#include <mb_umi.h>
#include <tsk.h>
#include <rules.h>
#include <config.h>
#include <string.h>
#include <shc.h>
#include <multi_institution.h>
#include <ist_otrace.h>
#include <InstProfile.h>
#include <BinRoute.h>
#include <CShcLog.h>
#include <iostream>
#include <vector>
#include <ShcmsgHeader.h>
#include<ist_seg_name.h>
#include<ist_seg_fn_data.h>
#include<ist_seg_elf_id_map.h>
#include <ShcmsgProcessor.h>
#include <Shc300Helper.h>
#include <ShcApp.h>
#include <ShcHelper.h>



using namespace std;

ShcLog *shcmsgLogObj = NULL;

//initDB();
//int prepareUpdateVoid();
//virtual int prepareUpdateReversal();
//virtual int prepareUpdateFinCapture();
//virtual int doUpdateVoid();
//virtual int doUpdateReversal();
//virtual int doUpdateFinCapture();

#include <Shc300Header.h>
#include <ShcTimerHelper.h>
#include <ShcmsgTxnHelper.h>

int  testshc300()
{
	struct shc300 oldmsg = { 0 };

	shc_get_current_date();
	Shc300Header *header = new Shc300Header(&oldmsg);



    header->msg.msgtype = 300;

	header->setIssShcBin("ztang_r1l2");
	header->setAcqShcBin("ztang_r1l2");
	thisShcApp->shcTimerObj->shc_set_timers(header);
	thisShcApp->shc300HelperObj->adjustTimer(header);
	thisShcApp->shcTimerObj->shc_time_message_300(header);
	printf("check shc for event time out.in(%ld) out(%ld)\n", header->time_in, header->time_out);

	return 1;
}

#include <ShcNetworkMsgHelper.h>
int  testshcCreateEvent()
{
	struct shcmsg oldmsg = { 0 };

	OTraceDebug("Current time\n");
	shc_get_current_date();
	ShcmsgHeader *header = new ShcmsgHeader(&oldmsg);



    header->msg.msgtype = 800;

	if (shcEnableSubssecondTimeout)
		header->time_out = shc_current_time*1000+ 2500;
	else
		header->time_out = shc_current_time+ 2;
	header->setIssShcBin("ztang_r1l2");
	header->setAcqShcBin("ztang_r1l2");
	thisShcApp->shcNetworkMsgHelperObj->shcCreateEvent(header);
	printf("check shc for event time out time_out(%ld).\n", header->time_out);

	return 1;
}

#include <ShcmsgFMHelper.h>
class TestShcmsgFMHelper : public ShcmsgFMHelper
{
	virtual int isFMenabled(char* instId) { return 1;}
};

int testFMEvent()
{
	struct shcmsg oldmsg = { 0 };

	OTraceDebug("Current time\n");
	shc_get_current_date();
	ShcmsgHeader *header = new ShcmsgHeader(&oldmsg);
	TestShcmsgFMHelper *myFMHelper = new TestShcmsgFMHelper();


    header->msg.msgtype = 200;

	header->time_in = shc_current_time*1000 + shc_current_millisecond;
	header->time_out = header->time_in+ 2500;
	header->setIssShcBin("ztang_r1l2");
	header->setAcqShcBin("ztang_r1l2");
	header->allocateAndCopyOrigMsg(&oldmsg);
	int mbid = mb_createmailbox("FMformatter", 0, 0);
	mb_duplicatemailbox(mbid);
	mbid = mb_createmailbox("LMformatter", 0, 0);
	mb_duplicatemailbox(mbid);
	myFMHelper->init_records(0);
	myFMHelper->sendTxnReq(header, TO_FM);
	myFMHelper->sendTxnReq(header, TO_LM);
	printf("FM:in(%ld) out(%ld) expire(%ld).\n", header->time_in, header->time_out, header->time_out+(header->time_out>10000000000?10000:10));
	printf("check shc for event time out.\n");

	return 1;
}

int test500Event()
{
	struct shcmsg oldmsg = { 0 };

	OTraceDebug("Current time\n");
	shc_get_current_date();
	ShcmsgHeader *header = new ShcmsgHeader(&oldmsg);

    header->msg.msgtype = 200;

	header->time_in = shc_current_time*1000 + shc_current_millisecond;
	header->setIssShcBin("ztang_r1l2");
	header->setAcqShcBin("ztang_r1l2");
	header->shcLogObj = new ShcLog();
	shcApp->issuerShcParamsList = (ShcInstParamsList *)thisShcApp->shcParams.getInst(header->issShcBin->binPkg->bin.institutionid);

	thisShcApp->shcmsgTxnHelperObj->setSettleReqAdviceFlags(header);
	printf("500txn: in(%ld) out(%ld)\n",  header->time_in ,  header->time_out);
	header->time_in = shc_current_time;
	thisShcApp->shcmsgTxnHelperObj->setSettleReqAdviceFlags(header);
	printf("500txn: in(%ld) out(%ld)\n",  header->time_in ,  header->time_out);

	return 1;
}

struct  shcoldbin {
    /*  Routing and config package package */
    bin_t           institutionid;      /*  institution id */
    bin_t           userbinid;          /*  user bin id */
    bin_t           networkid;          /*  internal bin id */
    bin_t           owner;              /*  owner network */
    int             mailbox;            /*  outbound route */
    int             port;               /*  outbound port id */
    int             netmgrid;           /*  net mgr. mail box id */
    int             bintype;            /*  type of entry */
    long            timeout;            /*  time out value as aquirer */
    unsigned long   flags;              /*  flags on type of entry */
    date_t          settle_date;        /*  current settlement date */
    int             pinparm;        /*  pin parm index */
//  int             keyparm;        /*  index to key parm index */
    short           country_code;
    short           currency_code;
    short           cvvdate;        /*  date after which CVV is valid */
    int             cardid;         /*  card type */
    int             statid;         /*  set >= 0 if stats being collected */
    long            last_online_activity;   /*  time of last on-line activity */
    char            bankname[SHC_BANKNAME_LEN + 1];
    int             cammailboxid;   /* Mch 18Feb00 -Card Authen. Mailbox ID */
    unsigned long   bin_cfg;        /*  R001835 Bin Level Configuration */
    char            node[sizeof(__tmpshcdb->node)];
};

int testBinSize()
{
	struct shcbin newbin;
	struct shcoldbin oldbin;
	printf("old: size(%d) cvvdate offset(%ld) cardid offset(%ld)\n", (int)sizeof(struct shcoldbin), 
		(long)((long)&oldbin.cvvdate-(long)&oldbin), (long)((long)&oldbin.cardid-(long)&oldbin));
	printf("new: size(%d) cvvdate offset(%ld) cardid offset(%ld)\n", (int)sizeof(struct shcbin), 
		(long)((long)&newbin.cvvdate-(long)&newbin), (long)((long)&newbin.cardid-(long)&newbin));
	return 0;
}

int main(int argc, char **argv)
{
	argv0 = *argv;
	char buf[200];
	char choice[10];

	OTraceOn(argv0);
	ist_otrace_set_level(OTRACE_DEBUG);

	mb_init();
	dbm_init();
	shcApp=thisShcApp= new ShcApp();
	shc_init();

	shcmid = mb_locatemailbox("SharedCash");
	thisShcApp->netid = mb_locatemailbox("ShcNetworkManager");

	testshc300();
	//testshcCreateEvent();
	//testFMEvent();
	//test500Event();
	//testBinSize();

	OTraceOff();
	
	return 0;
}

