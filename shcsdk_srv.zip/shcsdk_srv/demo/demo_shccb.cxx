//
// Copyright (C) 2004 eFunds Corporation ("eFunds").  All Rights Reserved.  
// eFunds Canada Corporation is an authorized user. 
// 
// IST is a registered trademark of eFunds Corporation.  Other brand or
// product names are trademarks or registered trademarks of their respective
// holders. 
// 
// The information contained herein is the unpublished proprietary property
// of eFunds.  Except as specifically authorized in writing by eFunds, the
// holder of this document shall: i) keep all information contained herein
// confidential, and ii) protect the information, in whole or in part, from
// disclosure and dissemination to all third parties. 
// 
// This document and the software described in it are furnished under license
// and may be used or copied only in accordance with the terms of such license.
// This document is supplied for information purposes only, is subject to
// change without notice, and should not be construed as a commitment by
// either eFunds Corporation or eFunds Canada Corporation. 
//
/*
 *  IST and IST/Share are registered trademarks of Oasis Technology Ltd.
 *
 *  Copyright (C) 1990 - 1999 Oasis Technology Ltd.
 *  All Rights Reserved
 *  This Module contains Proprietary Information of
 *  Oasis Technology Ltd., and should be treated as Confidential.
 *
 *  THIS IS UNPUBLISHED PROPRIETARY SOURCE CODE OF OASIS TECHNOLOGY LTD.
 *  The copyright notice above does not evidence any
 *  actual or intended publication of such source code.
 */
/*
#pragma ident "@(#)demo_shccb.cxx 1.5 20/07/08 00:37:20"
 *
 *                        MODIFICATION HISTORY                  REVIEW
 *
 *  SCR#    Who  Date    Description         Who Date
 * ===========================================================================
 * R009856 ztang 25Jun03 Creation
 * R023659 ram   19Jun08 Callback prototype changed to improve performance
 * R023762 ram   28Jun08 Callback changes enclosed inside DSWITCH macro
*/
/* File Number 102 */
#include <ist_otrace.h>
#include <shc_callback.h>
#include <demo_shccb.h>

scDemoCallBack*	scDemoCallBack::_instance = 0;
static int iiii=0;

scDemoCallBack*	scDemoCallBack::getInstance()
{
	if (_instance == 0)
		_instance = new scDemoCallBack;
	
	return _instance;
}
//	>>>	R023762
int scDemoCallBack::execute(ShcHeader *shcmsg, OCString& ProcessingPoint)	//	---	R023659
//	<<<	R023762
{
	OTraceInfo("I-SHC-10200:DEMO-CB: Begin Demo callback\n");


	int retVal = iiii%5;
	iiii++;
	OTraceInfo("I-SHC-10201:DEMO-CB: Return value is %d\n", retVal);
	return retVal;
}

int register_all (shcCallBackFactory* cbFactory)
{
	syslg("I-SHC-DEMO-CB-10202: register object.\n");

	cbFactory->register_callback(scDemoCallBack::getInstance(), "demo");

	return 0;
}
