//
// Copyright (C) 2004 eFunds Corporation ("eFunds").  All Rights Reserved.  
// eFunds Canada Corporation is an authorized user. 
// 
// IST is a registered trademark of eFunds Corporation.  Other brand or
// product names are trademarks or registered trademarks of their respective
// holders. 
// 
// The information contained herein is the unpublished proprietary property
// of eFunds.  Except as specifically authorized in writing by eFunds, the
// holder of this document shall: i) keep all information contained herein
// confidential, and ii) protect the information, in whole or in part, from
// disclosure and dissemination to all third parties. 
// 
// This document and the software described in it are furnished under license
// and may be used or copied only in accordance with the terms of such license.
// This document is supplied for information purposes only, is subject to
// change without notice, and should not be construed as a commitment by
// either eFunds Corporation or eFunds Canada Corporation. 
//
#include <stdio.h>
#include <signal.h>
#include <oasis.h>
#include <shc.h>


void fmtexit( int );

main( int argc, char **argv )
{
	struct shc	shc = {0};
	char	tmpbuf[100];
	int 		shcloginsertfd=-1;
	int 		shclogfd=-1;
	int 	choice;

	argv0 = *argv;
	ODebugOn(argv0);

	dbm_init();
	
	int trace = getpid()*1000;
	for (int i=0; i<1000; i++)
	{
		printf("*************************************************\n");
		printf("   l. log\n");
		printf("   u. update\n");
		printf("   c. commint\n");
		printf("*************************************************\n");

		while((choice = getchar()) == '\n');

		if( shcloginsertfd < 0 )
			if( (shcloginsertfd = dbm_open("shclog_1", dbmid)) < 0 )
			{
				return( -1 );
			}

   		if(shclogfd == -1)
       		if((shclogfd = dbm_open("shclog_1", dbmid)) < 0)
       		{
           		return(-1);
       		}

		switch(choice)
		{
		case	'l':
			trace++;
			shclog.trace = trace;
			printf("Logging recode with trace [%d]...\n", shclog.trace);
			dbm_insert(shcloginsertfd, (char *)&shclog, 0);
			printf("Logging...done\n");
			break;

		case	'u':
			printf("Reading record with trace [%d]...\n", shclog.trace);
			if (dbm_read(shclogfd, (char *)&shclog, DBM_REQUAL | DBM_RLOCK) < 0)
			{
				printf("dbm_read failed\n");
			}
			printf("Reading...Done\n");

			printf("Writing...\n");
    		if(dbm_write(shclogfd, (char *)&shclog, 0) < 0)
    		{
        		printf("F-SHC-0056: Error: %d on write\n", dbm_errno);
    		}
			printf("Writing...Done\n");
			break;
		
		case	'c':
			dbm_rewind(shclogfd);
			printf("Committing...\n");
			if (dbm_commit(getpid()) < 0)
			{
				printf("Rollback...\n");
				dbm_rollback(getpid());
			}
			printf("Comming...done\n");
		}
	}
	fmtexit(0);
}


void fmtexit( int n )
{
	printf("x Exit due to signal %d\n", n);

	ODebugOff();

	exit(n);
}



