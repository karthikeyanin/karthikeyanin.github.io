/*
 * Copyright (C) 2004 eFunds Corporation ("eFunds").  All Rights Reserved.  
 * eFunds Canada Corporation is an authorized user. 
 * 
 * IST is a registered trademark of eFunds Corporation.  Other brand or
 * product names are trademarks or registered trademarks of their respective
 * holders. 
 * 
 * The information contained herein is the unpublished proprietary property
 * of eFunds.  Except as specifically authorized in writing by eFunds, the
 * holder of this document shall: i) keep all information contained herein
 * confidential, and ii) protect the information, in whole or in part, from
 * disclosure and dissemination to all third parties. 
 * 
 * This document and the software described in it are furnished under license
 * and may be used or copied only in accordance with the terms of such license.
 * This document is supplied for information purposes only, is subject to
 * change without notice, and should not be construed as a commitment by
 * either eFunds Corporation or eFunds Canada Corporation. 
 */
#include <stdio.h>
#include <signal.h>
#include <oasis.h>
#include <mb.h>
#include <shc.h>


void fmtexit( int );

main( int argc, char **argv )
{
	struct shc	shc = {0};
	int			mbid = -1;

	argv0 = *argv;
	catch_all_signals(fmtexit);

	ODebugOn(argv0);

	mb_init();
	shc_init();
	dbm_init();

	if( argc != 2 )
	{
		printf("USAGE: %s {mailbox name}\n", argv[0]);
		printf("       (if the mailbox does not exist, it will be created.\n");
		fmtexit(1);
	}

	if( (mbid = mb_locateinbound(argv[1])) < 0 )
	{
		printf("* Unable to locate or create %s\n", argv[1]);
		fmtexit(1);
	}

	printf("  Located mailbox '%s[%d]'\n", mbMailBoxName(mbid), mbid); 

	shcmsg_process(&shc.msg, mbid);

	fmtexit(0);
}


void fmtexit( int n )
{
	printf("x Exit due to signal %d\n", n);

	ODebugOff();

	exit(n);
}

shcmsg_process( struct shcmsg *shcmsg, int mbid )
{
	char	xbuf[16];
	int		unit;

	for( ;; )
	{
		printf("\n  ----------------------------------------------------\n");
		printf(". Waiting for message in '%s[%d]'...\n", 
			mbMailBoxName(mbid), mbid);

		if( mb_read(mbid, shcmsg, sizeof(struct shcmsg)) < 0 )
			break;

    	unit = mbLastSenderId();

		printf("  m%04d/i%010s/t%06ld/p%06ld/r%02ld/%s[%d]\n",
			shcmsg->msgtype, shcmsg->issuer, shcmsg->trace,
			shcmsg->pcode, shcmsg->respcode, mbMailBoxName(unit), unit);

		/* Set return values
		*/
		shcmsg->msgtype = shc_get_return_msgno(shcmsg->msgtype);
		
		printf("> Enter response code: ");
		if( (shcmsg->respcode = atoi(gets(xbuf))) == -1 )
		{
			printf("! No response message sent.\n");
			continue;
		}

		/* Send message
		*/
		if( mb_write(unit, mbid, shcmsg, sizeof(struct shcmsg)) < 0 )
		{
			printf("* Unable to send mb_write(%d, %d, %p, %d)\n",
				unit, mbid, shcmsg, sizeof(struct shcmsg));
			break;
		}
		printf("  Sent message to '%s[%d]'\n", mbMailBoxName(unit), unit);
	}
}


