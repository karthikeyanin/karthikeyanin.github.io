#ifndef _SHCDEVICENAK_H_
#define _SHCDEVICENAK_H_

static char _ShcDeviceNak_h_what[] = "@(#) ShcDeviceNak.h 1.2 05/01/10 15:07:35";
/*
 *  Copyright (C) 2004 eFunds Corporation ("eFunds").  All Rights Reserved.     
 *  eFunds Canada Corporation is an authorized user.                            
 *                                                                              
 *  IST is a registered trademark of eFunds Corporation.  Other brand or        
 *  product names are trademarks or registered trademarks of their respective   
 *  holders.                                                                    
 *                                                                              
 *  The information contained herein is the unpublished proprietary property    
 *  of eFunds.  Except as specifically authorized in writing by eFunds, the     
 *  holder of this document shall: i) keep all information contained herein     
 *  confidential, and ii) protect the information, in whole or in part, from    
 *  disclosure and dissemination to all third parties.                          
 *                                                                          
 *  This document and the software described in it are furnished under license  
 *  and may be used or copied only in accordance with the terms of such license.
 *  This document is supplied for information purposes only, is subject to      
 *  change without notice, and should not be construed as a commitment by       
 *  either eFunds Corporation or eFunds Canada Corporation. 
 *
 *
 *                        MODIFICATION HISTORY                  REVIEW
 *
 * SCR#     Who    Date  Description
 * ===========================================================================
 * R0xxxxx 
 */

 
#include <ShcSdkCommon.h>
#include <ShcmsgBaseTxn.h>

class ShcDeviceNak : public ShcmsgBaseTxn
{
protected:
	int  enrich();
	int  doWork();

public:
	ShcDeviceNak(ShcmsgHeader* hd) { header=hd; }
	virtual ~ShcDeviceNak(){};

	
	int		save_revcode;
	int		save_respcode;
	dec_t	save_aval_bal;
	dec_t	save_new_amount;
};

#endif
