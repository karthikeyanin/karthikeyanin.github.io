#ifndef _SHCSAF_H_
#define _SHCSAF_H_

static char _ShcSaf_h_what[] = "@(#) ShcSaf.h 1.4 05/01/10 15:07:47";

/*
 *  Copyright (C) 2004 eFunds Corporation ("eFunds").  All Rights Reserved.     
 *  eFunds Canada Corporation is an authorized user.                            
 *                                                                              
 *  IST is a registered trademark of eFunds Corporation.  Other brand or        
 *  product names are trademarks or registered trademarks of their respective   
 *  holders.                                                                    
 *                                                                              
 *  The information contained herein is the unpublished proprietary property    
 *  of eFunds.  Except as specifically authorized in writing by eFunds, the     
 *  holder of this document shall: i) keep all information contained herein     
 *  confidential, and ii) protect the information, in whole or in part, from    
 *  disclosure and dissemination to all third parties.                          
 *                                                                          
 *  This document and the software described in it are furnished under license  
 *  and may be used or copied only in accordance with the terms of such license.
 *  This document is supplied for information purposes only, is subject to      
 *  change without notice, and should not be construed as a commitment by       
 *  either eFunds Corporation or eFunds Canada Corporation. 
 *
 *
 *                        MODIFICATION HISTORY                  REVIEW
 *
 * SCR#     Who    Date  Description
 * ===========================================================================
 * R0xxxxx ztang 05Nov03 Creation
 */
 

#include <shc.h>
#include <shcextbuf.h>
#include <ShcSdkCommon.h>
#include <ShcmsgHeader.h>
#include <ShcHelperBase.h>
#include <ShcApp.h>


class ShcSaf : public ShcHelperBase
{
public:
    const char *getName()
		{
				return (const char *)SHC_ShcSaf;
					}

	virtual int shc_general_saf_write(ShcBin *shcBin, ShcmsgHeader *header, int checkDuplicate);
	virtual int shc_saf(ShcmsgHeader *header, char safType = '\0');
	virtual int shc_saf_fin(ShcmsgHeader *header);
	virtual int shc_saf_resetlimits(ShcmsgHeader *header);
	virtual int shc_saf_rev(ShcmsgHeader *header);
	virtual int shc_saf_stlmt(ShcmsgHeader *header);

};

extern ShcSaf *shcSafObj;
#endif

