#ifndef _SHCIBFTHELPER_H_
#define _SHCIBFTHELPER_H_

static char _ShcIBFTHelper_h_what[] = "@(#) ShcIBFTHelper.h 1.5 16/12/14 07:41:53";

/*
 *  Copyright (C) 2004 eFunds Corporation ("eFunds").  All Rights Reserved.     
 *  eFunds Canada Corporation is an authorized user.                            
 *                                                                              
 *  IST is a registered trademark of eFunds Corporation.  Other brand or        
 *  product names are trademarks or registered trademarks of their respective   
 *  holders.                                                                    
 *                                                                              
 *  The information contained herein is the unpublished proprietary property    
 *  of eFunds.  Except as specifically authorized in writing by eFunds, the     
 *  holder of this document shall: i) keep all information contained herein     
 *  confidential, and ii) protect the information, in whole or in part, from    
 *  disclosure and dissemination to all third parties.                          
 *                                                                          
 *  This document and the software described in it are furnished under license  
 *  and may be used or copied only in accordance with the terms of such license.
 *  This document is supplied for information purposes only, is subject to      
 *  change without notice, and should not be construed as a commitment by       
 *  either eFunds Corporation or eFunds Canada Corporation. 
 *
 *
 *                        MODIFICATION HISTORY                  REVIEW
 *
 * SCR#     Who    Date  Description
 * ===========================================================================
 * R0xxxxx ztang 05Nov03 Creation
 */
 

#include <ShcSdkCommon.h>
#include <shcextbuf.h>
#include <ShcApp.h>
#include <ShcRevResp.h>
#include <ShcHelperBase.h>
#include <shcmsgdef.h>

class ShcIBFTHelper: public ShcHelperBase
{
public:
    const char *getName()
    {
        return (const char *)SHC_ShcIBFTHelper;
    }

	virtual int shc_advice_IBFT_send( ShcmsgHeader *header, ShcBin *shcBin );
	virtual int shc_reverse_IBFT_update( ShcmsgHeader *header );
	virtual int shc_create_IBFT( ShcmsgHeader *header, long type );
	virtual int shc_advice_IBFT( ShcmsgHeader *header, long type );
	virtual int shc_restore_IBFT( ShcmsgHeader *header);
	virtual int restoreCallback(ShcmsgHeader *header);
	virtual int setDoWorkRoutingInfo(ShcmsgHeader *header);
	virtual int doReplay(ShcmsgHeader *header);
	virtual int updateReqOriginal(ShcmsgHeader *header);
	virtual int routeReversal(ShcmsgHeader *header, int omsg_is_saf);
	virtual	int restoreBeforeRouting(ShcmsgHeader *header);
	virtual int setRoutingFlag(ShcmsgHeader *header);
	virtual int prepareRespLogMessage(ShcmsgHeader *header);
	virtual int processIBFT(ShcmsgHeader *header);
};

extern ShcIBFTHelper *shcIBFTHelperObj;
#endif

