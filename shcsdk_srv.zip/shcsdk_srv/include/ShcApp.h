#ifndef _SHCAPP_H_
#define _SHCAPP_H_

static char _ShcApp_h_what[] = "@(#) ShcApp.h 1.19.1.5 17/08/02 14:41:44";

/*
 *  Copyright (C) 2004 eFunds Corporation ("eFunds").  All Rights Reserved.     
 *  eFunds Canada Corporation is an authorized user.                            
 *                                                                              
 *  IST is a registered trademark of eFunds Corporation.  Other brand or        
 *  product names are trademarks or registered trademarks of their respective   
 *  holders.                                                                    
 *                                                                              
 *  The information contained herein is the unpublished proprietary property    
 *  of eFunds.  Except as specifically authorized in writing by eFunds, the     
 *  holder of this document shall: i) keep all information contained herein     
 *  confidential, and ii) protect the information, in whole or in part, from    
 *  disclosure and dissemination to all third parties.                          
 *                                                                          
 *  This document and the software described in it are furnished under license  
 *  and may be used or copied only in accordance with the terms of such license.
 *  This document is supplied for information purposes only, is subject to      
 *  change without notice, and should not be construed as a commitment by       
 *  either eFunds Corporation or eFunds Canada Corporation. 
 *
 *
 *                        MODIFICATION HISTORY                  REVIEW
 *
 * SCR#     Who    Date  Description
 * ===========================================================================
 * R0xxxxx ztang 05Nov03 Creation
 * R020052 spa	 21May07 Added FMBlockRegistration
 * R020524 jyang 04Jul07 Added dual-message transaction support
 */
 

#include <ShcSdkCommon.h>
#include <shcextbuf.h>
#include <Queue.h>
#include <shccard.h>
#include <ShcAppBase.h>
#include <DNSegHelper.h>
           
#define SHC_ShcPreauthHelper 			"ShcPreauthHelper" 		
#define SHC_ShcCamHelper			    "ShcCamHelper"			
#define SHC_ShcFinAuthHelper		    "ShcFinAuthHelper"		
#define SHC_ShcIBFTHelper			    "ShcIBFTHelper"			
#define SHC_ShcNetworkMsgHelper 	    "ShcNetworkMsgHelper" 	
#define SHC_ShcRevReqHelper			    "ShcRevReqHelper"			
#define SHC_ShcRevRespHelper		    "ShcRevRespHelper"		
#define SHC_ShcSaf					    "ShcSaf"					
#define SHC_ShcmsgEventHelper		    "ShcmsgEventHelper"		
#define SHC_ShcmsgTxnHelper 		    "ShcmsgTxnHelper" 		
#define SHC_ShcBackOfficeHelper		    "ShcBackOfficeHelper"		
#define SHC_Shc300Helper        	    "Shc300Helper"        	
#define SHC_ShcAdminReqHelper		    "ShcAdminReqHelper"		
#define SHC_ShcAdminRespHelper		    "ShcAdminRespHelper"		
#define SHC_ShcPreauthSvcHelper		    "ShcPreauthSvcHelper"		
#define SHC_ShcRetHelper			    "ShcRetHelper"			
#define SHC_Shc500Helper			    "Shc500Helper"			
#define SHC_ShcChargeBackHelper 	    "ShcChargeBackHelper" 	
#define SHC_ShcLogReqHelper 		    "ShcLogReqHelper" 		
#define SHC_ShcnetEventHelper		    "ShcnetEventHelper"		
#define SHC_ShcDeviceAckHelper		    "ShcDeviceAckHelper"		
#define SHC_ShcDeviceNakHelper		    "ShcDeviceNakHelper"		
#define SHC_ShcKeyTxnHelper			    "ShcKeyTxnHelper"			
#define SHC_ShcFRSReqHelper			    "ShcFRSReqHelper"			
#define SHC_ShcApp			    		"ShcApp"	
#define SHC_Shc300Log					"Shc300Log"	
#define SHC_ShcnetApp					"ShcnetApp"	
#define SHC_ShcDualMsgHelper			"ShcDualMsgHelper"
#define SHC_ShcCutoverHelper 			"ShcCutoverHelper"

           
class ShcmsgHelper;
class ShcmsgTxnHelper;
class ShcCamHelper;
class ShcFinAuthHelper;
class ShcIBFTHelper;
class ShcKeyHelper;
class ShcMacHelper;
class ShcBackOfficeHelper;
class ShcPreauthSvcHelper;
class ShcRetHelper;
class ShcAdminReqHelper;
class ShcAdminRespHelper;
class Shc500Helper;
class ShcNetworkMsgHelper;
class ShcChargeBackHelper;
class ShcnetEventHelper;
class ShcRevReqHelper;
class ShcLogReqHelper;
class ShcDeviceAckHelper;
class ShcDeviceNakHelper;
class ShcRevRespHelper;
class ShcPreauthHelper;
class ShcSaf;
class ShcTimerHelper;
class ShcMainLoop;
class ShcmsgEventHelper;
class Shc300Helper;
class ShcHelper;
class ShcDKEHelper;
class ShcKeyTxnHelper;
class Shc300Log;
class ShcProcessor;
class ShcmsgTxnRegistration;
class Shc300TxnRegistration;
class ShcnetTxnRegistration;
class ShcAdminTxnRegistration;
class ShcProcessorRegistration;
class ShcFRSReqHelper;
class FMBlockRegistration;	//	---	R020052
class ShcDualMsgHelper;
class Shc300ReqDB;
class SHC300;

/* The class that holds the global variables */
class ShcApp : public ShcAppBase
{
public:
	ShcApp();
	~ShcApp(){};
	Shc300Log *shc300LogObj;

    const char *getName()
    {
        return (const char *)SHC_ShcApp;
    }


	ShcPreauthHelper 		*shcPreauthHelperObj;
	ShcCamHelper			*shcCamHelperObj;
	ShcFinAuthHelper		*shcFinAuthHelperObj;
	ShcIBFTHelper			*shcIBFTHelperObj;
	ShcNetworkMsgHelper 	*shcNetworkMsgHelperObj;
	ShcRevReqHelper			*shcRevReqHelperObj;
	ShcRevRespHelper		*shcRevRespHelperObj;
	ShcSaf					*shcSafHelperObj;
	ShcmsgEventHelper		*shcmsgEventHelperObj;
	ShcmsgTxnHelper 		*shcmsgTxnHelperObj;
	ShcBackOfficeHelper		*shcBackOfficeHelperObj;
	Shc300Helper        	*shc300HelperObj;
	ShcAdminReqHelper		*shcAdminReqHelperObj;
	ShcAdminRespHelper		*shcAdminRespHelperObj;
	ShcPreauthSvcHelper		*shcPreauthSvcHelperObj;
	ShcRetHelper			*shcRetHelperObj;
	Shc500Helper			*shc500HelperObj;
	ShcChargeBackHelper 	*shcChargeBackHelperObj;
	ShcLogReqHelper 		*shcLogReqHelperObj;
	ShcnetEventHelper		*shcnetEventHelperObj;
	ShcDeviceAckHelper		*shcDeviceAckHelperObj;
	ShcDeviceNakHelper		*shcDeviceNakHelperObj;
	ShcKeyTxnHelper			*shcKeyTxnHelperObj;
	ShcFRSReqHelper			*shcFRSReqHelperObj;
	ShcDualMsgHelper		*shcDualMsgHelperObj;
	Shc300ReqDB				*shc300ReqDBObj;
	SHC300					*shc300Obj;
};

extern ShcApp *thisShcApp;
extern 	ShcmsgTxnRegistration	shcmsgTxnRegistration;
extern 	ShcnetTxnRegistration	shcnetTxnRegistration;
extern	Shc300TxnRegistration	shc300TxnRegistration;
extern	ShcAdminTxnRegistration	shcAdminTxnRegistration;
extern	ShcProcessorRegistration shcProcessorRegistration;

extern FMBlockRegistration FMBlockRegister;	//	---	R020052

class  ShcLateRespHelper;
extern ShcLateRespHelper *shcLateRespHelperObj;
class  DNSegHelper;							// R027759 -- use the one in shcsdk_lib
extern DNSegHelper*	DNSegHelperObj;
class  LCRHelper;							// R027759 -- new implementation
extern LCRHelper*	LCRHelperObj;			// R027759
class  TieBreaker;							// R027759 -- new implementation
extern TieBreaker*	TieBreakerObj;			// R027759
extern int processingDoneOnOtherNode;

extern int shcRevChangeAvalBal;
extern int processingDoneOnOtherNode;
extern int shcRevChangeAvalBal;
extern int ON_DOT_id;
extern int ON_DOT_LOG_id;

#endif

