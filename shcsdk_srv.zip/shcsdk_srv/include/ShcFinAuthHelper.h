#ifndef __SHC_FINAUTH_HELPER__
#define __SHC_FINAUTH_HELPER__

static char _ShcFinAuthHelper_h_what[] = "@(#) ShcFinAuthHelper.h 1.15 14/04/16 17:21:41";
/*
 *  Copyright (C) 2004 eFunds Corporation ("eFunds").  All Rights Reserved.     
 *  eFunds Canada Corporation is an authorized user.                            
 *                                                                              
 *  IST is a registered trademark of eFunds Corporation.  Other brand or        
 *  product names are trademarks or registered trademarks of their respective   
 *  holders.                                                                    
 *                                                                              
 *  The information contained herein is the unpublished proprietary property    
 *  of eFunds.  Except as specifically authorized in writing by eFunds, the     
 *  holder of this document shall: i) keep all information contained herein     
 *  confidential, and ii) protect the information, in whole or in part, from    
 *  disclosure and dissemination to all third parties.                          
 *                                                                          
 *  This document and the software described in it are furnished under license  
 *  and may be used or copied only in accordance with the terms of such license.
 *  This document is supplied for information purposes only, is subject to      
 *  change without notice, and should not be construed as a commitment by       
 *  either eFunds Corporation or eFunds Canada Corporation. 
 *
 *
 *                        MODIFICATION HISTORY                  REVIEW
 *
 * SCR#     Who    Date  Description
 * ===========================================================================
 * R0xxxxx 
 * R019631  spa	18Apr07	Add new method setBalances
 * R023659	ram 19Jun08 Callback prototype changed to improve performance
 * R027905  dipa 25Mar10 Reversal-Void Enhancement
 */

#include <shc.h>
#include <ShcApp.h>
#include <shc_callback.h>	//	---	R023659
#include <ShcHelperBase.h>
#define LOCATE_FOR_REPEAT 1 // --- R026977

class ShcFinAuthHelper: public ShcHelperBase
{
public:
    const char *getName()
    {
        return (const char *)SHC_ShcFinAuthHelper;
    }

	virtual int shc_return_finauth(ShcmsgHeader *header, int errcode);
	virtual short decideChipOption(ShcmsgHeader *header, emv *emvbuf);
//	virtual void setFlagForEDC(ShcmsgHeader *header);
//	virtual int getEDCKey(ShcmsgHeader *header);
	virtual int zeroAmountCheck(ShcmsgHeader *header);
	virtual int authorizeFloorLimit(ShcmsgHeader *header);
	virtual int decideConfProcess(ShcmsgHeader *header);
	virtual int decideSaf(ShcmsgHeader *header);
	virtual int translatePinBlock(ShcmsgHeader *header);
	virtual int exitForProagentReq(ShcmsgHeader *header);
	virtual void setOrigData(ShcmsgHeader *header);
	virtual int locateOrigForVoid(ShcmsgHeader *header);
	virtual int setNoPinFlag(ShcmsgHeader *header);
	virtual int checkRepeat(ShcmsgHeader *header);
	virtual int actionOnRepeat(ShcmsgHeader *header);
	virtual int checkPreauthAllowed(ShcmsgHeader *header);
	virtual int checkDupTxn(ShcmsgHeader *header);
	virtual int checkBinDown(ShcmsgHeader *header);
	virtual int checkPreauthTxn(ShcmsgHeader *header);
	virtual int checkTxnSet(ShcmsgHeader *header);
	virtual int checkAccountFundingTxn(ShcmsgHeader *header);
	virtual int verifyCheckDigit(ShcmsgHeader *header);
	virtual int checkEuroBinMbrTbl(ShcmsgHeader *header);
	virtual int checkTxnLimit(ShcmsgHeader *header);
	virtual int checkAccount(ShcmsgHeader *header);
	virtual int checkCamResult(ShcmsgHeader *header, int *errcode);
	virtual int setupReturnMsg(ShcmsgHeader *header, struct shcmsg *returnMsg, int errcode);
	virtual int denyUpdateLogReq(ShcmsgHeader *header);
	virtual int checkCamResult(ShcmsgHeader *header);
	virtual int checkEvent(ShcmsgHeader *header);
	virtual int setLogFlag(ShcmsgHeader *header);
	virtual int checkRespMac(ShcmsgHeader *header);
	virtual int checkNDKE(ShcmsgHeader *header);
//	virtual int updateEDC(ShcmsgHeader *header);
	virtual int encryptMsg(ShcmsgHeader *header);
	virtual int doAck(ShcmsgHeader *header);
	virtual int notifyPosAuth(ShcmsgHeader *header);
	virtual int writeSaf(ShcmsgHeader *header);
	virtual int updatePreauth(ShcmsgHeader *header);
	virtual int routeSettlement(ShcmsgHeader *header);
	virtual int shc_updateduptxn_info(ShcmsgHeader *header);
	virtual int shc_restore_fields(ShcmsgHeader *header);
	virtual int restoreCallback(ShcmsgHeader *header){ return shc_callback(header, "post_finauth_restore_event");}
	virtual int setDoWorkRoutingInfo(ShcmsgHeader *header);
	virtual int restoreForRepeat(ShcmsgHeader *header);
	virtual int visaSpecificChecking(ShcmsgHeader *header);
	virtual int mcSpecificChecking(ShcmsgHeader *header);
	virtual int setBalances(ShcmsgHeader *header);	//	---	R019631
	virtual int checkAndProcessVoid(ShcmsgHeader *header);   //R027905
	virtual int checkAndProcessRefund(ShcmsgHeader *header); //R027905
	virtual int checkRepeatFileUpdate(ShcmsgHeader *header);
	virtual int checkForMCTarTxn(ShcmsgHeader *header);
	virtual int checkForVisaTarTxn(ShcmsgHeader *header);
	virtual int checkBinDownForTarTxn(ShcmsgHeader *header);
	int verifyCompletionAmount(ShcmsgHeader *header);
	virtual int checkIsBillPayTxn(ShcmsgHeader *header);
	virtual int checkOriginalTxnIsOk(ShcmsgHeader *header);
protected:
	struct shc_data shc_data_rec;
	struct shc_data orig_shc_data_rec;

};

extern ShcFinAuthHelper *shcFinAuthHelperObj;

#endif

