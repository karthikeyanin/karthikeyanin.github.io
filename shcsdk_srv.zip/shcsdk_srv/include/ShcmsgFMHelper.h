/*
 *  Copyright (C) 2004 eFunds Corporation ("eFunds").  All Rights Reserved.
 *  eFunds Canada Corporation is an authorized user.
 *
 *  IST is a registered trademark of eFunds Corporation.  Other brand or
 *  product names are trademarks or registered trademarks of their respective
 *  holders.
 *
 *  The information contained herein is the unpublished proprietary property
 *  of eFunds.  Except as specifically authorized in writing by eFunds, the
 *  holder of this document shall: i) keep all information contained herein
 *  confidential, and ii) protect the information, in whole or in part, from
 *  disclosure and dissemination to all third parties.
 *
 *  This document and the software described in it are furnished under license
 *  and may be used or copied only in accordance with the terms of such license.
 *  This document is supplied for information purposes only, is subject to
 *  change without notice, and should not be construed as a commitment by
 *  either eFunds Corporation or eFunds Canada Corporation.
 *
 *
 *                        MODIFICATION HISTORY                  REVIEW
 *
 * SCR#     Who    Date  Description
 * ===========================================================================
 * R020052  spa	 21May07 New file created
 * R020818  emj  01Aug07 Fixed compile issue on HP
 * R020938	spa	 16Aug07 IST LM Bridge support
 * R021958	lee  13Nov07 Added a segment for Timestamps
 * R022681	lee  29Feb08 Functions in ShcmsgFMHelper class are declared as virtual
 * ITM-1560 sel	 07Jul08 call shc_route when sending reversal to LM and use SENDAPPLBIN flag
 * R025639  vmp	 16Jan09 Chnaged made for FM PhaseII enhancement
 * R027876  dipa 02Mar10 Segment changes
 * R028714  dipa 08Dec10 FN Enhancements(WR33726) 
 * R029287  dipa 30May11 New EMEA Rule Templates(WR33845) - old bug fixed for 'fmcmd request' command
 */

#ifndef __SHCMSGFMHELPER__
#define __SHCMSGFMHELPER__

static const char* _ShcmsgFMHelper_h_what = "@(#) ShcmsgFMHelper.h 1.12.1.2 16/10/21 08:07:25";

#include <shc.h>
#include <ShcApp.h>
#include <rules.h>
#include <ShcHelperBase.h>
#include <hotrange.h>
//#include <shccard.h>
#include <ShcProcessor.h>
#include <ShcmsgFMHeader.h>
#include <sys/timeb.h>	//	---	R021958

#define FM_ADD_INFO_EVENT_KEY	10
#define FM_MESSAGE_NAME		"fm-inst-stats"
#define SHC_ShcmsgFMHelper	"ShcmsgFMHelper"


#define FM_INST_ADD             0
//#define FM_INST_DELETE          1	//	---	R025639
#define FM_INST_REPLACE         2
//	>>>	R025639
#define FM_INST_ALL		        3
#define FM_INST_NONE			4
/* Broadcasting the institution list commands*/
#define FM_INST_ADD_FROM_BROADCAST             100
#define FM_INST_REPLACE_FROM_BROADCAST         102
#define FM_INST_ALL_FROM_BROADCAST           103
#define FM_INST_NONE_FROM_BROADCAST            104
//	<<<	R025639
//	>>>	R020938
#define TO_FM					1
#define TO_LM					2
//	<<<	R020938

#define SEND_REQUEST	1

extern int fmAppid;
extern struct rules_keytab *fmRuleKeyPtr;
extern char *fmInstKeys;

//R027876 >>>
//struct FM_seg_data
//{
//	int flipped_msgtype;//orig flipped msgtype	---	R020938
//	int	logFlag;		//Definitions are following the class
//	int	repeatFlag;
//	int	shcerr;			//flags of routing
//	long	time_in;		//Time the txn is in
//	long	time_out;		//Time the txn is out
//	int	req_eventId;
//	int	orig_eventId;
//};
//<<< R027876

//	>>>	R021958

struct ShcTimeStamp_seg
{
	int sendToLM_tme;	//time in HHMMSS Format
	int sendToLM_ms;	//Millisecond part
	int receiveFromLM_tme;
	int receiveFromLM_ms;
};

//	<<<	R021958

class ShcmsgFMHelper:public ShcHelperBase
{
public:
	const char *getName()
	{
		return (const char *)SHC_ShcmsgFMHelper;
	}

    	ShcmsgFMHelper();

	//	>>>	R022681

	virtual int isFMenabled(char* instId);

	//Send request message to FM/LM based on the route.
	//A flag in msg should be set to indicate the message it going to FM .A event needs to be set.
	virtual int sendTxnReq(ShcmsgHeader *header, int route);	//	---	R020938

	//Send block command response to FM to ack the block command is received.
	virtual int sendCmdResp(char *msg, int len);

	//Insert into hotrange table
	virtual int addHotRange(struct hotrange *newRange);

	//Insert into shcmerchant table
	virtual int addHotMerchant(struct shcmerchant *newHotMerchant);

	//Insert into shccard
	//virtual int addHotCard(struct shccard* card,int blkflg);	//	---	R025639

		//Check shcmerchant
	virtual int checkHotMerchant(ShcmsgHeader *header);

	//	>>>	R025639
	//virtual int unblockCard(struct shccard* card);

	virtual int unblockRange(struct hotrange *newRange);

	//Delete from shcmerchant table
	virtual int unblockMerchant(struct shcmerchant *newHotMerchant);

	//Insert into shcmerchant table
	virtual int suspendMerchant(struct shcmerchant *newHotMerchant);

	//To enable the Merchant
	virtual int IsMerchantSuspensionExpired(struct shcmerchant *newHotMerchant);

	virtual int SetRCIfMerchantBlocked(ShcmsgHeader *header);

	//	<<<	R025639

	//enqueues a message
	virtual ShcProcessor *enqueueInternalMsg(ShcmsgFMHeader *hd);

	//Update the fm keys shared memory with new institution list
	virtual int update_record(int action, char * fmblockInfo);

	//Sends a request to FM for new institution list
	virtual int init_records(int send_request = 0); //R029287

	//	>>>	R020938
	//get method for denyOnLMtimeout
	virtual int getShc_denyOnLMtimeout() { return denyOnLMTimeout; };

	virtual int getShc_denyOnFMtimeout() { return denyOnFMTimeout; };	//	---	R025639

	//send reversal update to FM/LM based on route
	virtual int sendReversal(ShcmsgHeader *header, int route);

	//Sends late response to FM/LM based on the route
	virtual int sendLateResponse(ShcmsgFMHeader *header, int route);
	//	<<<	R020938

	//	<<<	R022681

	//R028714 - Creates FN DATA SEGMENT
	void createFnDataSegment(ShcmsgHeader *header);

	int setRuleParam(); //R029951
	int loadRuleParam(); //R029951

private:
	float fm_timeout;
	//	>>>	R020938
	float lm_timeout;
	int denyOnLMTimeout;
	int enableLM;
	//	<<<	R020938
	//	>>>	ITM-1560
	char institutionId[MAX_TXN_DESTINATION_LEN+1];
	char userBinId[MAX_TXN_DESTINATION_LEN+1];
	char LMTxnBin[MAX_TXN_DESTINATION_LEN+1];
	//	<<<	ITM-1560
	int denyOnFMTimeout;//	---	R025639
	char FMTxnBin[MAX_TXN_DESTINATION_LEN+1];	//	---	R025639
	int fmAppid;
	struct rules_keytab *fmRuleKeyPtr;
	char *fmInstKeys;


};

extern ShcmsgFMHelper *shcmsgFMHelperObj;


#endif

