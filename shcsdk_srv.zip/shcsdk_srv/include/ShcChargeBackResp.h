#ifndef _SHCCHARGEBACKRESP_H_
#define _SHCCHARGEBACKRESP_H_

static char _ShcChargeBackResp_h_what[] = "@(#) ShcChargeBackResp.h 1.3 05/01/10 15:07:29";
/*
 *  Copyright (C) 2004 eFunds Corporation ("eFunds").  All Rights Reserved.     
 *  eFunds Canada Corporation is an authorized user.                            
 *                                                                              
 *  IST is a registered trademark of eFunds Corporation.  Other brand or        
 *  product names are trademarks or registered trademarks of their respective   
 *  holders.                                                                    
 *                                                                              
 *  The information contained herein is the unpublished proprietary property    
 *  of eFunds.  Except as specifically authorized in writing by eFunds, the     
 *  holder of this document shall: i) keep all information contained herein     
 *  confidential, and ii) protect the information, in whole or in part, from    
 *  disclosure and dissemination to all third parties.                          
 *                                                                          
 *  This document and the software described in it are furnished under license  
 *  and may be used or copied only in accordance with the terms of such license.
 *  This document is supplied for information purposes only, is subject to      
 *  change without notice, and should not be construed as a commitment by       
 *  either eFunds Corporation or eFunds Canada Corporation. 
 *
 *
 *                        MODIFICATION HISTORY                  REVIEW
 *
 * SCR#     Who    Date  Description
 * ===========================================================================
 * R0xxxxx jyang 21Nov03 Created
 */

 //File Number 126

#include <stdio.h>
#include <string.h>
#include <oasis.h>
#include <ist_otrace.h>
#include <shc.h>
#include <shcextbuf.h> /* Ssc 2007336 VSDC support */
#include <tm.h>
#include <CShcLog.h>
//#define SHC_REVRESP_SRC
//#include "shc_util_funcs.h"

#include <ShcSdkCommon.h>
#include <ShcmsgBaseTxn.h>
#include <ShcRevResp.h>

/*
 *	Financial reversal response
 */


class ShcChargeBackResp : public ShcRevResp
{
protected:
	int doWork();

public:

	ShcChargeBackResp(ShcmsgHeader *hd): ShcRevResp(hd) { OTraceDebug("D-SHC-126001:Enter function ShcChargeBackResp()\n"); };
	virtual ~ShcChargeBackResp() { OTraceDebug("D-SHC-126002:Leave ~ShcChargeBackResp()\n"); }

};

#endif

