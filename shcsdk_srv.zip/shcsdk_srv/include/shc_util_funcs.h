/*
 * Copyright (C) 2004 eFunds Corporation ("eFunds").  All Rights Reserved.  
 * eFunds Canada Corporation is an authorized user. 
 * 
 * IST is a registered trademark of eFunds Corporation.  Other brand or
 * product names are trademarks or registered trademarks of their respective
 * holders. 
 * 
 * The information contained herein is the unpublished proprietary property
 * of eFunds.  Except as specifically authorized in writing by eFunds, the
 * holder of this document shall: i) keep all information contained herein
 * confidential, and ii) protect the information, in whole or in part, from
 * disclosure and dissemination to all third parties. 
 * 
 * This document and the software described in it are furnished under license
 * and may be used or copied only in accordance with the terms of such license.
 * This document is supplied for information purposes only, is subject to
 * change without notice, and should not be construed as a commitment by
 * either eFunds Corporation or eFunds Canada Corporation. 
 */
#ifndef SHC_UTIL_FUNCS_H
#define SHC_UTIL_FUNCS_H

static char _shc_util_funcs_h_what[] = "@(#) shc_util_funcs.h 1.13 12/05/29 06:38:31";

/*
 *	IST and IST/Share are registered trademarks of Oasis Technology Ltd.
 *
 *	Copyright (C) 1990 - 2000 Oasis Technology Ltd.
 *	All Rights Reserved
 *	This Module contains Proprietary Information of
 *	Oasis Technology Ltd., and should be treated as Confidential.
 *
 *	THIS IS UNPUBLISHED PROPRIETARY SOURCE CODE OF OASIS TECHNOLOGY LTD.
 *	The copyright notice above does not evidence any  
 *	actual or intended publication of such source code.
 */
/*
 *
 *                        MODIFICATION HISTORY                  REVIEW
 *
 * SPR		Who		Date		Description
 * ========================================================================
 * R007062	gbeeng	27Nov2001	C++ Migration (created)
 *								To define function prototypes
 */

#include <shc.h>
class ShcmsgHeader;

#ifndef SHC_PROCESS_SRC
#define SHC_PROCESS_SRC extern
#endif

SHC_PROCESS_SRC int shc_process(register struct shc *shcmsg);
SHC_PROCESS_SRC int shc_check_ndke(struct shc *shcmsg);

#ifndef SHC_CARD_SRC
#define SHC_CARD_SRC extern
#endif

SHC_CARD_SRC int shc_writecard();
SHC_CARD_SRC int shc_iscardhot(struct shc *shcmsg);
SHC_CARD_SRC int shc_iscardexpired(register struct shc *shcmsg);
SHC_CARD_SRC int shc_validate_expdate(register struct shc *shcmsg);
SHC_CARD_SRC int shc_getcard(struct shc *shcmsg);
SHC_CARD_SRC int shc_updatecard();

#ifndef SHC_SERVICE_SRC
#define SHC_SERVICE_SRC extern
#endif

SHC_SERVICE_SRC int shc_service_request(struct shc *shcmsg);

#ifndef SHC_SAF_SRC
#define SHC_SAF_SRC extern
#endif

SHC_SAF_SRC int shc_saf(struct shc *shcmsg);
SHC_SAF_SRC int shc_saf_rev(register struct shc *shcmsg);

#ifndef SHC_FINREQ_SRC
#define SHC_FINREQ_SRC extern
#endif

SHC_FINREQ_SRC int shc_finreq(register struct shc *shcmsg);
SHC_FINREQ_SRC int shc_return_finauth(struct shc *shcmsg, int errcode);

#ifndef SHC_FINRESP_SRC
#define SHC_FINRESP_SRC extern
#endif

SHC_FINRESP_SRC int shc_finresp(register struct shc *shcmsg);


#ifndef SHC_AUTHREQ_SRC
#define SHC_AUTHREQ_SRC extern
#endif

SHC_AUTHREQ_SRC int shc_authreq(register struct shc *shcmsg);

#ifndef SHC_POSAUTH_SRC
#define SHC_POSAUTH_SRC extern
#endif

SHC_POSAUTH_SRC int shc_posauth(struct shc *shcmsg, int settimer);

#ifndef SHC_RESTORE_SRC
#define SHC_RESTORE_SRC extern
#endif

SHC_RESTORE_SRC int shc_restore_fields(register struct shc *shcmsg, register struct shc *omsg);

#ifndef SHC_STLMTREQ_SRC
#define SHC_STLMTREQ_SRC extern
#endif

SHC_STLMTREQ_SRC int shc_stlmtreq(struct shc *shcmsg);
SHC_STLMTREQ_SRC int shc_settle_edc(struct shc *shcmsg);

#ifndef SHC_STARTUP_SRC
#define SHC_STARTUP_SRC extern
#endif

SHC_STARTUP_SRC int shc_initialise_transaction(register struct shc *shcmsg);
SHC_STARTUP_SRC long shc_get_capture_date(struct shc *shcmsg);

#ifndef SHC_PIN_SRC
#define SHC_PIN_SRC extern
#endif

SHC_PIN_SRC int shc_checkpin(struct shc *shcmsg);
SHC_PIN_SRC int shc_cvv(struct shc *shcmsg);
SHC_PIN_SRC int shc_verify_cvv2(struct shc *shcmsg);
SHC_PIN_SRC int shc_translate_pinblk(register struct shc *shcmsg);
SHC_PIN_SRC int shcpin_ChgKey(struct shc *shcmsg);
SHC_PIN_SRC int shc_pinblk_ob2tb(register struct shc *shcmsg);
SHC_PIN_SRC int shc_txn_has_pin(register struct shc *shcmsg);
SHC_PIN_SRC int shc_pin(register struct shc *shcmsg);


#ifndef SHC_300_SRC
#define SHC_300_SRC extern
#endif

SHC_300_SRC int shc_300(struct shc *shcmsg);

#ifndef SHC_IBFT_SRC
#define SHC_IBFT_SRC extern
#endif

SHC_IBFT_SRC int shc_create_IBFT( struct shc* shcmsg, long type );
SHC_IBFT_SRC int shc_advice_IBFT( struct shc* shcmsg, long type );
SHC_IBFT_SRC int shc_restore_IBFT( struct shc *shc, struct shc *oshc );

#ifndef SHC_BACKOFFICE_SRC
#define SHC_BACKOFFICE_SRC extern
#endif

SHC_BACKOFFICE_SRC int shc_backoffice_resp(register struct shc *shcmsg);
SHC_BACKOFFICE_SRC int shc_backoffice_req(register struct shc *shcmsg);

#ifndef SHC_DEVICE_SRC
#define SHC_DEVICE_SRC extern
#endif

SHC_DEVICE_SRC int shc_device_nak(register struct shc *shcmsg);
SHC_DEVICE_SRC int shc_device_ack(struct shc *shcmsg);

#ifndef SHC_STLMTRSP_SRC
#define SHC_STLMTRSP_SRC extern
#endif

SHC_STLMTRSP_SRC int shc_stlmtresp(struct shc *shcmsg);

#ifndef SHC_CAM_SRC
#define SHC_CAM_SRC extern
#endif

SHC_CAM_SRC int shc_cam_request_start (struct shc *shcmsg);
SHC_CAM_SRC int shc_cam_stip_request_start (struct shc *shcmsg);
SHC_CAM_SRC int shc_cam_request_result (struct shc *shcmsg);
SHC_CAM_SRC int shc_cam_response_start (struct shc *shcmsg);
SHC_CAM_SRC int shc_cam_response_result (struct shc *shcmsg);


#ifndef SHC_EDIT_SRC
#define SHC_EDIT_SRC extern
#endif

SHC_EDIT_SRC int shc_pre_edit(register struct shc *shcmsg);
SHC_EDIT_SRC char shc_getCvvResultCode(struct shc *shcmsg );
SHC_EDIT_SRC int shc_setCvvResultCode( struct shc *shcmsg, char val );

#ifndef SHC_FLRLIM_SRC
#define SHC_FLRLIM_SRC extern
#endif

SHC_FLRLIM_SRC int shc_checkfloorlimit(struct shc *shcmsg);

#ifndef SHC_PREAUTH_SRC
#define SHC_PREAUTH_SRC extern
#endif

SHC_PREAUTH_SRC int shc_preauth_confirm(struct shc *shcmsg);
SHC_PREAUTH_SRC int shc_preauth_response(struct shc *shcmsg);
SHC_PREAUTH_SRC int shc_preauth_service(struct shc *shcmsg);

#ifndef SHC_KME_SRC
#define SHC_KME_SRC extern
#endif

SHC_KME_SRC int shckme_DecryptBalance( struct shc *shcmsg, struct shcpkg *pkg,
							char key_class, char index );
SHC_KME_SRC int shckme_EncryptBalance( struct shc *shcmsg, struct shcpkg *pkg,
							char key_class, char index );

#ifndef SHC_ADMIN_SRC
#define SHC_ADMIN_SRC extern
#endif

SHC_ADMIN_SRC int shc_adm_chkduplog(struct shc *shcmsg);
SHC_ADMIN_SRC int shc_admin_req(register struct shc *shcmsg);
SHC_ADMIN_SRC int shc_admin_resp(register struct shc *shcmsg);

#ifndef SHC_REVRESP_SRC
#define SHC_REVRESP_SRC extern
#endif

SHC_REVRESP_SRC int shc_revresp(struct shc *shcmsg);

#ifndef SHC_EVENT_SRC
#define SHC_EVENT_SRC extern
#endif

SHC_EVENT_SRC int shc_event(struct shc *shcmsg);

#ifndef SHC_AUTH_SRC
#define SHC_AUTH_SRC extern
#endif

SHC_AUTH_SRC int shc_continue_transaction(register struct shc *shcmsg);

#ifndef SHC_NETWORK_SRC
#define SHC_NETWORK_SRC extern
#endif

SHC_NETWORK_SRC int shc_network_event( struct shc *shcmsg );
SHC_NETWORK_SRC int shc_network(register struct shc *shcmsg);

#ifndef SHC_REVREQ_SRC
#define SHC_REVREQ_SRC extern
#endif

SHC_REVREQ_SRC int shc_revreq(register struct shc *shcmsg);
SHC_REVREQ_SRC int shc_return_reversal(struct shc *shcmsg);
SHC_REVREQ_SRC int shc_rev_updoriginal(struct shc *shcmsg, struct shc *omsg);

#ifndef SHC_500FUNC_SRC
#define SHC_500FUNC_SRC extern
#endif

SHC_500FUNC_SRC struct  shc500std_key   *shc500StdKey; 
SHC_500FUNC_SRC struct  shc500std_text  *shc500StdText;
SHC_500FUNC_SRC struct  rules_keytab    *shc500StdRuleKeyp;
SHC_500FUNC_SRC int                     shc500StdAppid;
SHC_500FUNC_SRC bin_t                   shc500SwitchId;

#define shc500StdNumKeys        shc500StdRuleKeyp->keysused
#define shc500StdNumText        shc500StdRuleKeyp->textused
#define shc500StdMaxKeys        shc500StdRuleKeyp->nkeys

#ifndef SHC_ORIGMSG_SRC
#define SHC_ORIGMSG_SRC extern
#endif

extern int gOmsgIsSaf;

SHC_ORIGMSG_SRC int shc_general_saf_write(struct shcpkg *pkg, struct shc *shcmsgP, int checkDuplicate); 
SHC_ORIGMSG_SRC int shc_restoreOriginal(register struct shc *shcmsg, register struct shc *omsg);

#endif

