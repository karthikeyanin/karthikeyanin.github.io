#ifndef _SHCMSGTXNFACTORY_H_
#define _SHCMSGTXNFACTORY_H_

static char _ShcmsgTxnFactory_h_what[] = "@(#) ShcmsgTxnFactory.h 1.2 05/05/20 18:31:06";
/*
 *  Copyright (C) 2004 eFunds Corporation ("eFunds").  All Rights Reserved.     
 *  eFunds Canada Corporation is an authorized user.                            
 *                                                                              
 *  IST is a registered trademark of eFunds Corporation.  Other brand or        
 *  product names are trademarks or registered trademarks of their respective   
 *  holders.                                                                    
 *                                                                              
 *  The information contained herein is the unpublished proprietary property    
 *  of eFunds.  Except as specifically authorized in writing by eFunds, the     
 *  holder of this document shall: i) keep all information contained herein     
 *  confidential, and ii) protect the information, in whole or in part, from    
 *  disclosure and dissemination to all third parties.                          
 *                                                                          
 *  This document and the software described in it are furnished under license  
 *  and may be used or copied only in accordance with the terms of such license.
 *  This document is supplied for information purposes only, is subject to      
 *  change without notice, and should not be construed as a commitment by       
 *  either eFunds Corporation or eFunds Canada Corporation. 
 *
 *                        MODIFICATION HISTORY                  REVIEW
 *
 * SCR#     Who    Date  Description
 * ===========================================================================
 * R0xxxxx 
 */


#include <oasis.h>
#include <ShcmsgBaseTxn.h>
#include <SdkTargetFactory.h>


class ShcmsgTxnFactory : public TargetFactory<ShcmsgBaseTxn>
{
public:
	virtual int createCondition(char *condition, const void *msg);
	virtual ShcmsgBaseTxn *getTargetObj(char *condition, const void *msg);
};

#endif
