#ifndef _SHCDUALFIRSTMSGREQ_H_
#define _SHCDUALFIRSTMSGREQ_H_

static char _ShcDualFirstMsgReq_h_what[] = "@(#) ShcDualFirstMsgReq.h 1.1 07/07/11 14:46:12";

/*
 *  Copyright (C) 2004 eFunds Corporation ("eFunds").  All Rights Reserved.     
 *  eFunds Canada Corporation is an authorized user.                            
 *                                                                              
 *  IST is a registered trademark of eFunds Corporation.  Other brand or        
 *  product names are trademarks or registered trademarks of their respective   
 *  holders.                                                                    
 *                                                                              
 *  The information contained herein is the unpublished proprietary property    
 *  of eFunds.  Except as specifically authorized in writing by eFunds, the     
 *  holder of this document shall: i) keep all information contained herein     
 *  confidential, and ii) protect the information, in whole or in part, from    
 *  disclosure and dissemination to all third parties.                          
 *                                                                          
 *  This document and the software described in it are furnished under license  
 *  and may be used or copied only in accordance with the terms of such license.
 *  This document is supplied for information purposes only, is subject to      
 *  change without notice, and should not be construed as a commitment by       
 *  either eFunds Corporation or eFunds Canada Corporation. 
 *
 *
 *
 *                        MODIFICATION HISTORY                  REVIEW
 *
 *	SPR#	Who	Date	Description			Who	Date   
 * ===========================================================================
 * R020524 jyang 04Jul07 Created for dual-message transaction support
 */

#include <ShcFinAuthReq.h>

class ShcDualFirstMsgReq : public ShcFinAuthReq
{
protected:
//	virtual int enrich();
//	virtual int restore();
//	virtual int edit();
//	virtual int verify();
//	virtual int doWork();
	
public:
	ShcDualFirstMsgReq(ShcmsgHeader *hd) : ShcFinAuthReq(hd) {};
	virtual ~ShcDualFirstMsgReq() {};
};


#endif
