#ifndef _SHCLOGREQHELPER_H_
#define _SHCLOGREQHELPER_H_

static char _ShcLogReqHelper_h_what[] = "@(#) ShcLogReqHelper.h 1.3 05/01/10 15:07:39";

/*
 *  Copyright (C) 2004 eFunds Corporation ("eFunds").  All Rights Reserved.     
 *  eFunds Canada Corporation is an authorized user.                            
 *                                                                              
 *  IST is a registered trademark of eFunds Corporation.  Other brand or        
 *  product names are trademarks or registered trademarks of their respective   
 *  holders.                                                                    
 *                                                                              
 *  The information contained herein is the unpublished proprietary property    
 *  of eFunds.  Except as specifically authorized in writing by eFunds, the     
 *  holder of this document shall: i) keep all information contained herein     
 *  confidential, and ii) protect the information, in whole or in part, from    
 *  disclosure and dissemination to all third parties.                          
 *                                                                          
 *  This document and the software described in it are furnished under license  
 *  and may be used or copied only in accordance with the terms of such license.
 *  This document is supplied for information purposes only, is subject to      
 *  change without notice, and should not be construed as a commitment by       
 *  either eFunds Corporation or eFunds Canada Corporation. 
 *
 *
 *                        MODIFICATION HISTORY                  REVIEW
 *
 * SCR#     Who    Date  Description
 * ===========================================================================
 * R0xxxxx ztang 05Nov03 Creation
 */
 

#include <ShcSdkCommon.h>
#include <shcextbuf.h>
#include <ShcApp.h>
#include <ShcHelperBase.h>

class ShcLogReqHelper: public ShcHelperBase
{
public:
    const char *getName()
    {
        return (const char *)SHC_ShcLogReqHelper;
    }

	virtual int setDefaultRespCode(ShcmsgHeader *header);


};

extern ShcLogReqHelper *shcLogReqHelperObj;
#endif

