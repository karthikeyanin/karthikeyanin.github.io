#ifndef _ShcRevReqHelper_H_
#define _ShcRevReqHelper_H_

static char _ShcRevReqHelper_h_what[] = "@(#) ShcRevReqHelper.h 1.5.1.1 15/12/15 07:23:57";
/*
 *  Copyright (C) 2004 eFunds Corporation ("eFunds").  All Rights Reserved.     
 *  eFunds Canada Corporation is an authorized user.                            
 *                                                                              
 *  IST is a registered trademark of eFunds Corporation.  Other brand or        
 *  product names are trademarks or registered trademarks of their respective   
 *  holders.                                                                    
 *                                                                              
 *  The information contained herein is the unpublished proprietary property    
 *  of eFunds.  Except as specifically authorized in writing by eFunds, the     
 *  holder of this document shall: i) keep all information contained herein     
 *  confidential, and ii) protect the information, in whole or in part, from    
 *  disclosure and dissemination to all third parties.                          
 *                                                                          
 *  This document and the software described in it are furnished under license  
 *  and may be used or copied only in accordance with the terms of such license.
 *  This document is supplied for information purposes only, is subject to      
 *  change without notice, and should not be construed as a commitment by       
 *  either eFunds Corporation or eFunds Canada Corporation. 
 *
 *
 *                        MODIFICATION HISTORY                  REVIEW
 *
 * SCR#     Who    Date  Description
 * ===========================================================================
 * R0xxxxx jyang 21Nov03 Created
 * R017392 rzhou 11Aug06 Added new member function
 */

#include <ShcmsgHeader.h>
#include <ShcHelperBase.h>
#include <ShcApp.h>


class ShcRevReqHelper: public ShcHelperBase
{
private:
	struct ShcmsgWithSegment tmpOrigmsg;

public:
    const char *getName()
    {
        return (const char *)SHC_ShcRevReqHelper;
    }

	virtual int setReqEmvFlag(ShcmsgHeader *header);
	virtual int returnReqAcqFirst(ShcmsgHeader *header, int omsg_is_saf);
	virtual int getReqReturnAcqFlag( ShcmsgHeader* header, int omsg_is_saf );
	virtual int returnReversal(ShcmsgHeader *header);
	virtual int returnReversal(ShcmsgHeader *header, struct shcmsg * oshcmsg);
	virtual int shc_return_reversal(ShcmsgHeader *hd){return returnReversal(hd);}
	virtual int updateOriginal(ShcmsgHeader *header);
	virtual int verifyReqRevMac( ShcmsgHeader *header );
//	virtual int logReqMessage(ShcmsgHeader *header, int flag);
	virtual int setReqReturnDestMsgno(ShcmsgHeader *header);
	virtual int needReqReversal(ShcmsgHeader *header);
//	virtual int updateReqOriginal(ShcmsgHeader *header);
	virtual int needReqUpdateLog(ShcmsgHeader *header);
	virtual int needUpdateRespcode(void);
	
	virtual int doReplay(ShcmsgHeader *header);
	virtual int routeReversal(ShcmsgHeader *header, int omsg_is_saf);
	virtual int setReplayRoutingFlag(ShcmsgHeader *header);
	virtual int setNormalRoutingFlag(ShcmsgHeader *header);
	virtual void resetOriginalBuffer() { memset((char *) &tmpOrigmsg, 0, sizeof(struct ShcmsgWithSegment)); }
	virtual int createDualSiteRetryTimer(ShcmsgHeader* header);

};

extern ShcRevReqHelper *ShcRevReqHelperObj;

#endif

