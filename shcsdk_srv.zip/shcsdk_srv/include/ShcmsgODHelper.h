/*
 *  Copyright (C) 2004 eFunds Corporation ("eFunds").  All Rights Reserved.
 *  eFunds Canada Corporation is an authorized user.
 *
 *  IST is a registered trademark of eFunds Corporation.  Other brand or
 *  product names are trademarks or registered trademarks of their respective
 *  holders.
 *
 *  The information contained herein is the unpublished proprietary property
 *  of eFunds.  Except as specifically authorized in writing by eFunds, the
 *  holder of this document shall: i) keep all information contained herein
 *  confidential, and ii) protect the information, in whole or in part, from
 *  disclosure and dissemination to all third parties.
 *
 *  This document and the software described in it are furnished under license
 *  and may be used or copied only in accordance with the terms of such license.
 *  This document is supplied for information purposes only, is subject to
 *  change without notice, and should not be construed as a commitment by
 *  either eFunds Corporation or eFunds Canada Corporation.
 *
 *
 *                        MODIFICATION HISTORY                  REVIEW
 *
 * SCR#     Who    Date  Description
 * ===========================================================================
 * R00000 ztang	25Jul17	 New file created
 */

#ifndef __SHCMSGODHELPER__
#define __SHCMSGODHELPER__

static const char* _ShcmsgODHelper_h_what = "@(#) ShcmsgODHelper.h 1.2 17/09/21 13:21:37";

#include <shc.h>
#include <ShcApp.h>
#include <rules.h>
#include <ShcHelperBase.h>
#include <ShcProcessor.h>
#include <ShcmsgODHeader.h>
#include <sys/timeb.h>

#define OD_ADD_INFO_EVENT_KEY	11
#define SHC_ShcmsgODHelper	"ShcmsgODHelper"


#define SEND_REQUEST	1


class ShcmsgODHelper:public ShcHelperBase
{
public:
	const char *getName()
	{
		return (const char *)SHC_ShcmsgODHelper;
	}

	ShcBin *getODBin()
	{
		return ODBin;
	}
   	ShcmsgODHelper();


	virtual unsigned long isODEnabled(ShcBin *issuerbin);

	//Send request message to OD/OD based on the route.
	//A flag in msg should be set to indicate the message it going to OD .A event needs to be set.
	virtual int sendTxnReq(ShcmsgHeader *header);
	virtual int sendRespToOD(ShcmsgHeader *header);


	//enqueues a message
	virtual ShcProcessor *enqueueInternalMsg(ShcmsgODHeader *hd);


	//Sends late response to OD/OD based on the route
	virtual int processLateResponse(ShcmsgODHeader *header);

	virtual int initODBin();


protected:
	ShcBin *ODBin;
};

extern ShcmsgODHelper *shcmsgODHelperObj;


#endif

