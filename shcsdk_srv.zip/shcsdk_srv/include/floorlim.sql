/*
 * Copyright (C) 2004 eFunds Corporation ("eFunds").  All Rights Reserved.  
 * eFunds Canada Corporation is an authorized user. 
 * 
 * IST is a registered trademark of eFunds Corporation.  Other brand or
 * product names are trademarks or registered trademarks of their respective
 * holders. 
 * 
 * The information contained herein is the unpublished proprietary property
 * of eFunds.  Except as specifically authorized in writing by eFunds, the
 * holder of this document shall: i) keep all information contained herein
 * confidential, and ii) protect the information, in whole or in part, from
 * disclosure and dissemination to all third parties. 
 * 
 * This document and the software described in it are furnished under license
 * and may be used or copied only in accordance with the terms of such license.
 * This document is supplied for information purposes only, is subject to
 * change without notice, and should not be construed as a commitment by
 * either eFunds Corporation or eFunds Canada Corporation. 
 */
/*
	Floor limits table
*/

create table floorlim (
	merchant_catagory	smallint,
	merchant_type		char(1) null,
	currency		smallint,
	visa_classic_amt		money,
	visa_gold_amt		money,
	mc_classic_amt  money,
	mc_gold_amt  money,

	/* --- Propriatary Cards --- */
	pro_classic_amt money,
	pro_gold_amt money,
	o_rowid	int
)

create index floorlim_1 on floorlim (merchant_catagory)
create index floorlim_rid on floorlim (o_rowid)

