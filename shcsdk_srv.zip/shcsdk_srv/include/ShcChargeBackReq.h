#ifndef _SHCCHARGEBACKREQ_H_
#define _SHCCHARGEBACKREQ_H_

static char _ShcChargeBackReq_h_what[] = "@(#) ShcChargeBackReq.h 1.4 05/01/10 15:07:28";
/*
 *  Copyright (C) 2004 eFunds Corporation ("eFunds").  All Rights Reserved.     
 *  eFunds Canada Corporation is an authorized user.                            
 *                                                                              
 *  IST is a registered trademark of eFunds Corporation.  Other brand or        
 *  product names are trademarks or registered trademarks of their respective   
 *  holders.                                                                    
 *                                                                              
 *  The information contained herein is the unpublished proprietary property    
 *  of eFunds.  Except as specifically authorized in writing by eFunds, the     
 *  holder of this document shall: i) keep all information contained herein     
 *  confidential, and ii) protect the information, in whole or in part, from    
 *  disclosure and dissemination to all third parties.                          
 *                                                                          
 *  This document and the software described in it are furnished under license  
 *  and may be used or copied only in accordance with the terms of such license.
 *  This document is supplied for information purposes only, is subject to      
 *  change without notice, and should not be construed as a commitment by       
 *  either eFunds Corporation or eFunds Canada Corporation. 
 *
 *
 *                        MODIFICATION HISTORY                  REVIEW
 *
 * SCR#     Who    Date  Description
 * ===========================================================================
 * R0xxxxx jyang 21Nov03 Created
 */

 //File Number 125

#include <stdio.h>
#include <string.h>
#include <oasis.h>
#include <mb.h>
#include <ist_otrace.h>
#include <shc.h>
//#include <shcextbuf.h>
//#include <termmgr.h>
//#include <tm.h>
#include <ShcRevReq.h>
#include <CShcLog.h>

//#define SHC_REVREQ_SRC
//#include <shc_util_funcs.h>

#include <ShcSdkCommon.h>
#include <ShcmsgBaseTxn.h>

class ShcChargeBackReq : public ShcRevReq
{
protected:
	int doWork();
	
public:
	ShcChargeBackReq(ShcmsgHeader* hd) :
						ShcRevReq(hd)
						{ OTraceDebug("D-SHC-125001: Enter ShcChargeBackReq()\n"); };
	virtual ~ShcChargeBackReq() { OTraceDebug("D-SHC-125002:Leave ~ShcChargeBackReq()\n"); }
	
};


#endif
