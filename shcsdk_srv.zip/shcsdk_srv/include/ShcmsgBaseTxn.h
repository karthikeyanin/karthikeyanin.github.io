#ifndef _SHCMSG_BASE_TXN_H_
#define _SHCMSG_BASE_TXN_H_

static char _ShcmsgBaseTxn_h_what[] = "@(#) ShcmsgBaseTxn.h 1.3 04/12/15 14:21:02";
/*
 *  Copyright (C) 2004 eFunds Corporation ("eFunds").  All Rights Reserved.     
 *  eFunds Canada Corporation is an authorized user.                            
 *                                                                              
 *  IST is a registered trademark of eFunds Corporation.  Other brand or        
 *  product names are trademarks or registered trademarks of their respective   
 *  holders.                                                                    
 *                                                                              
 *  The information contained herein is the unpublished proprietary property    
 *  of eFunds.  Except as specifically authorized in writing by eFunds, the     
 *  holder of this document shall: i) keep all information contained herein     
 *  confidential, and ii) protect the information, in whole or in part, from    
 *  disclosure and dissemination to all third parties.                          
 *                                                                          
 *  This document and the software described in it are furnished under license  
 *  and may be used or copied only in accordance with the terms of such license.
 *  This document is supplied for information purposes only, is subject to      
 *  change without notice, and should not be construed as a commitment by       
 *  either eFunds Corporation or eFunds Canada Corporation. 
 *
 *
 *                        MODIFICATION HISTORY                  REVIEW
 *
 * SCR#     Who    Date  Description
 * ===========================================================================
 * R0xxxxx 
 */

#include <ShcBaseTxn.h>
#include <ShcmsgHeader.h>

class ShcmsgBaseTxn : public ShcBaseTxn
{
protected:
	virtual int enrich();
//	virtual int restore(ShcHeader *header);
//	virtual int edit(ShcHeader *header);
//	virtual int verify(ShcHeader *header);
//	virtual int doWork(ShcHeader *header);
	
public:
	ShcmsgHeader *header;
	
	virtual int process();

	
	virtual ~ShcmsgBaseTxn(){};
};




#endif

