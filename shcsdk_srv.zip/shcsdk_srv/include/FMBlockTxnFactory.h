//
// Copyright (C) 2004 eFunds Corporation ("eFunds").  All Rights Reserved.
// eFunds Canada Corporation is an authorized user.
//
// IST is a registered trademark of eFunds Corporation.  Other brand or
// product names are trademarks or registered trademarks of their respective
// holders.
//
// The information contained herein is the unpublished proprietary property
// of eFunds.  Except as specifically authorized in writing by eFunds, the
// holder of this document shall: i) keep all information contained herein
// confidential, and ii) protect the information, in whole or in part, from
// disclosure and dissemination to all third parties.
//
// This document and the software described in it are furnished under license
// and may be used or copied only in accordance with the terms of such license.
// This document is supplied for information purposes only, is subject to
// change without notice, and should not be construed as a commitment by
// either eFunds Corporation or eFunds Canada Corporation.
//
 /*
 *  SCR     Who     Date	Description
 *  ===========================================================================
 *  R020052 spa	  21May07	New file created
 *
 */

/* File Number */
#ifndef __FMBLOCKTXNFACTORY__
#define __FMBLOCKTXNFACTORY__

static const char* _FMBlockTxnFactory_h_what = "@(#) FMBlockTxnFactory.h 1.1 07/05/21 07:49:44";

#include <SdkTargetFactory.h>
#include <ShcBaseTxn.h>


class FMBlockTxnFactory : public TargetFactory<ShcBaseTxn>
{
	public:
		virtual int createCondition(char *condition, const void *msg);
		virtual ShcBaseTxn *getTargetObj(char *condition, const void *msg);

};

#endif
