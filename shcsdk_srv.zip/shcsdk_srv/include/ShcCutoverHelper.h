/*
 *  Copyright (C) 2004 eFunds Corporation ("eFunds").  All Rights Reserved.
 *  eFunds Canada Corporation is an authorized user.
 *
 *  IST is a registered trademark of eFunds Corporation.  Other brand or
 *  product names are trademarks or registered trademarks of their respective
 *  holders.
 *
 *  The information contained herein is the unpublished proprietary property
 *  of eFunds.  Except as specifically authorized in writing by eFunds, the
 *  holder of this document shall: i) keep all information contained herein
 *  confidential, and ii) protect the information, in whole or in part, from
 *  disclosure and dissemination to all third parties.
 *
 *  This document and the software described in it are furnished under license
 *  and may be used or copied only in accordance with the terms of such license.
 *  This document is supplied for information purposes only, is subject to
 *  change without notice, and should not be construed as a commitment by
 *  either eFunds Corporation or eFunds Canada Corporation.
 */
/*
 *
 *  MODIFICATION HISTORY                              REVIEW
 *
 *      SPR#    Who     Date    Description                       Who   Date
 * ===========================================================================
 *    R027855   mm      10Apr10 cutover_srv updates IBD DB
 */

#ifndef _ShcCutoverHelper_H_
#define _ShcCutoverHelper_H_

#include <ist_otrace.h>
#include <oc/oc_datetime.h>
#include <shc.h>
#include <ShcApp.h>
#include <ShcmsgBaseTxn.h>
#include <ShcHelperBase.h>
#include <ShcmsgHeader.h>
#include <ShcBin.h>
#include <BusinessDay.h>

//!!! _what_

class IBDDrinkTime;

#define IS_CUTOVER_CMD_NO_DB 4
#define IS_CUTOVER_CMD_PHC   8
#define IS_CUTOVER_CMD_MSG_REPL 16

//cutover helper class
class ShcCutoverHelper : public ShcHelperBase{
public:
	const char *getName()
        {
		return (const char *)SHC_ShcCutoverHelper;
	}

	ShcCutoverHelper(){
		header=NULL;
		m_drink_before=0;
		m_drink_after=0;
		m_shcBin = NULL;
	};
	virtual ~ShcCutoverHelper(){
	};

	//initialization:
	virtual int initialize(ShcApp* aShcApp, ShcmsgHeader* aHeader);
	virtual void initialize_cfg();
	virtual void initialize_drink_time(IBDDrinkTime **pIBDDrinkTime);

	//shccmd:
	virtual int cmd_process_phc_cutover(int arg_c, char** arg_v);
	virtual int cmd_process_cutover_no_db(int arg_c, char** arg_v);

	virtual int cmd_parse_args_phc_cutover(int arg_c, char** arg_v);
	virtual int cmd_parse_args_cutover_no_db(int arg_c, char** arg_v);

	virtual void cmd_initialize();
	virtual int cmd_send_msg();
	virtual int check_cap_date(long cut_date);

	//set data to header:
	virtual void setTxnSrc(char* ptr);
	virtual void setEntityId(char* ptr);
	virtual void setCutoverDate(char* ptr);
	virtual void setCutoverTimeAt(char* ptr);
	virtual void setCutoverTimeAt(long aTimeAt);
	virtual void setDrinkTimeStart();
	virtual void setDrinkTimeEnd();
	virtual void setDrinkTimeStart(char* ptr);
	virtual void setDrinkTimeEnd(char* ptr);
	virtual void setCutoverTypeRole(char *ptr);
	virtual void setCutoverTypeRole(int flags);
	virtual void setStatus(char *ptr);
	virtual void setStatus(int aStatus);
	virtual void setUTCSeconds(char *ptr);
	virtual void setIBDLocalTime(char *ptr);
	virtual void setTimeZone(char* ptr);
	virtual void setConfig(char* ptr);
	virtual void setBatchId(char *ptr);
	virtual void setBatchId(long aBatchId);
	virtual void setShclogId(char *ptr);
	virtual void setCutoverCmdFlags(int flags);
	virtual void setInstType(char *ptr);

	//get data from header:
	virtual char* getTxnSrc();
	virtual char* getEntityId();
	virtual long  getCutoverDate();
	virtual long  getCutoverTimeAt();
	virtual long  getCutoverTypeRole();
	virtual char  getStatus();
	virtual char  getStatusForPrint();
	virtual long  getUTCSeconds();
	virtual long  getIBDLocalTime();
	virtual char* getTimeZone();
	virtual char* getConfig();
	virtual long  getBatchId();
	virtual char* getShclogId();
	virtual long  getDrinkTimeStart();
	virtual long  getDrinkTimeEnd();
	virtual int   getCutoverCmdFlags();
	virtual char* getInstType();
	virtual long  getCounter();

	//return adjusted time:
	virtual long addSeconds(long a_time, int a_seconds_diff);

	//debug:
	virtual void printHeader(const char *txt, int result=0);
	virtual void debugCutoverFlag();

	//conditions based on header:
	virtual int isATMCutover();
	virtual int isPOSCutover();
	virtual int isOtherCutover();
	virtual int isCombinedCutover();
	virtual int isDBUpdate();
	virtual int isAcquirerCutover();
	virtual int isIssuerCutover();
	virtual int isInstCutover();
	virtual int isCutoverCmdPHC();
	virtual int isSwitchCutover();
	virtual int isCutoverGroup();
	virtual int isCutoverPassive();
	virtual int getMainCutoverConfigPosition();
	virtual int getForceMemberCutoverConfigPosition();
	virtual int getCurrentBusinessDayType();

	//conditions based on header and current IBD record:
	virtual int needsBatchIdUpdate(InstBusinessDay * myBusinessDay);
	virtual int needsInstCutover(long limit_date, InstBusinessDay *tmpBusDay, int tmpCfgType, int tmpDateType);
	virtual int needsBroadcastMyCutover(InstBusinessDay *instBusinessDay,int tmpCfgType);

	virtual int needsCutoverMsgOnInstCutover(InstBusinessDay *tmpBusDay);
	virtual int needsCutoverMsgOnGroupCutover(InstBusinessDay *tmpBusDay);

	//
	virtual void getMySHMRecord(InstBusinessDay *businessDay);

	//shcnet processing of 800 message:
	virtual int processCutoverRequest();
	virtual int processCutoverRequestStandard();
	virtual int processCutoverRequestCmdPHC();

	//update SHM:
	virtual void update_SHM_group(InstBusinessDay * grpBusinessDay, long newDay);
	virtual void update_SHM_individual(InstBusinessDay * myBusinessDay, long newDay);
	virtual void update_SHM_batch_id(InstBusinessDay *tmpBusDay,int tmpDateType, IBDDrinkTime *pIBDDrinkTime = NULL);

	//notify cutover server and other nodes:
	virtual int notify_cutover_srv(InstBusinessDay * businessDay);
	virtual int notify_other_nodes(InstBusinessDay * businessDay);

	//send 800 message to member:
	virtual int memberCutover( InstBusinessDay *businessDay);
	//send 800 message to member's children and if required, call SHM update for them:
	virtual void broadcastCutover(InstBusinessDay *instBusinessDay);
	//message to network functions:
	virtual int shc_prepare_cut_over(InstBusinessDay * businessDay);
	virtual void send_msg_to_member(InstBusinessDay *tmpBusDay);
	virtual int set_issuer_info(InstBusinessDay * businessDay);
	ShcmsgHeader *getHeader();
	int isReplicationFromOtherSite();
	int notifyOtherSite(InstBusinessDay * businessDay);

protected:
	ShcmsgHeader *header;
	ShcBin *m_shcBin;
	int m_drink_before;
	int m_drink_after;
};
#endif
