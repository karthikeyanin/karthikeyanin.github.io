#ifndef _ShcRevRespHelper_H_
#define _ShcRevRespHelper_H_

static char _ShcRevRespHelper_h_what[] = "@(#) ShcRevRespHelper.h 1.5 19/06/17 10:26:29";
/*
 *  Copyright (C) 2004 eFunds Corporation ("eFunds").  All Rights Reserved.     
 *  eFunds Canada Corporation is an authorized user.                            
 *                                                                              
 *  IST is a registered trademark of eFunds Corporation.  Other brand or        
 *  product names are trademarks or registered trademarks of their respective   
 *  holders.                                                                    
 *                                                                              
 *  The information contained herein is the unpublished proprietary property    
 *  of eFunds.  Except as specifically authorized in writing by eFunds, the     
 *  holder of this document shall: i) keep all information contained herein     
 *  confidential, and ii) protect the information, in whole or in part, from    
 *  disclosure and dissemination to all third parties.                          
 *                                                                          
 *  This document and the software described in it are furnished under license  
 *  and may be used or copied only in accordance with the terms of such license.
 *  This document is supplied for information purposes only, is subject to      
 *  change without notice, and should not be construed as a commitment by       
 *  either eFunds Corporation or eFunds Canada Corporation. 
 *
 *
 *                        MODIFICATION HISTORY                  REVIEW
 *
 * SCR#     Who    Date  Description
 * ===========================================================================
 * R0xxxxx jyang 21Nov03 Created
 */

 
#include <stdio.h>
#include <string.h>
#include <oasis.h>
#include <ist_otrace.h>
#include <shc.h>
#include <shcextbuf.h> /* Ssc 2007336 VSDC support */
#include <tm.h>
#include <CShcLog.h>
#include <ShcApp.h>
#include <ShcHelperBase.h>

#include <ShcSdkCommon.h>
#include <ShcmsgBaseTxn.h>
#include <ShcRevResp.h>

/*
 *	Financial reversal response
 */


class ShcRevRespHelper: public ShcHelperBase
{
public:
    const char *getName()
    {
        return (const char *)SHC_ShcRevRespHelper;
    }

	virtual int doReplay(ShcmsgHeader *header);
	virtual int sendToPosauthSever(ShcmsgHeader *header);
	virtual int setRoutingFlag(ShcmsgHeader *header);
//	virtual int updateRespMessage(ShcmsgHeader *header, int logResponse);
	virtual int locateRevReqEvent(ShcmsgHeader *header);
	virtual int restoreRespReversal(ShcmsgHeader *header);
	virtual int verifyRespRevMac(ShcmsgHeader *header);
	virtual int updateRespOriginal( ShcmsgHeader *header);
	virtual int prepareLog(ShcmsgHeader *header);
	int writeSaf(ShcmsgHeader *header);

	
protected:

};

#endif

