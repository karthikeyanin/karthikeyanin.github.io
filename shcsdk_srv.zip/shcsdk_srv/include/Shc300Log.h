#ifndef _SHC300LOG_H_
#define _SHC300LOG_H_

static char _Shc300Log_h_what[] = "@(#) Shc300Log.h 1.7 15/04/27 14:08:29";

/*
 *  Copyright (C) 2004 eFunds Corporation ("eFunds").  All Rights Reserved.
 *  eFunds Canada Corporation is an authorized user.
 *
 *  IST is a registered trademark of eFunds Corporation.  Other brand or
 *  product names are trademarks or registered trademarks of their respective
 *  holders.
 *
 *  The information contained herein is the unpublished proprietary property
 *  of eFunds.  Except as specifically authorized in writing by eFunds, the
 *  holder of this document shall: i) keep all information contained herein
 *  confidential, and ii) protect the information, in whole or in part, from
 *  disclosure and dissemination to all third parties.
 *
 *  This document and the software described in it are furnished under license
 *  and may be used or copied only in accordance with the terms of such license.
 *  This document is supplied for information purposes only, is subject to
 *  change without notice, and should not be construed as a commitment by
 *  either eFunds Corporation or eFunds Canada Corporation.
 *
 *                        MODIFICATION HISTORY                  REVIEW
 *
 *  SPR#    Who Date    Description         Who Date
 * ===========================================================================
 *
 *
 */

#include <shc.h>
#include <shcextbuf.h>

#include <ShcApp.h>
#include <ShcSdkLog.h>
#include <ShcHelperBase.h>
#include <Shc3XX.h>

class Shc300Log : public ShcSdkLog
{
public:
    const char *getName()
    {
        return (const char *)SHC_Shc300Log;
    }
	virtual int logTxn(ShcHeader *header);
	struct shc300fileupdt *shc300data;
};

#endif

