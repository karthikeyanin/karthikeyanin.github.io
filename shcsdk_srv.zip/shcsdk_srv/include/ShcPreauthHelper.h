#ifndef _SHCPREAUTHHELPER_H_
#define _SHCPREAUTHHELPER_H_

static char _ShcPreauthHelper_h_what[] = "@(#) ShcPreauthHelper.h 1.3 05/02/23 11:27:02";
/*
 *  Copyright (C) 2004 eFunds Corporation ("eFunds").  All Rights Reserved.     
 *  eFunds Canada Corporation is an authorized user.                            
 *                                                                              
 *  IST is a registered trademark of eFunds Corporation.  Other brand or        
 *  product names are trademarks or registered trademarks of their respective   
 *  holders.                                                                    
 *                                                                              
 *  The information contained herein is the unpublished proprietary property    
 *  of eFunds.  Except as specifically authorized in writing by eFunds, the     
 *  holder of this document shall: i) keep all information contained herein     
 *  confidential, and ii) protect the information, in whole or in part, from    
 *  disclosure and dissemination to all third parties.                          
 *                                                                          
 *  This document and the software described in it are furnished under license  
 *  and may be used or copied only in accordance with the terms of such license.
 *  This document is supplied for information purposes only, is subject to      
 *  change without notice, and should not be construed as a commitment by       
 *  either eFunds Corporation or eFunds Canada Corporation. 
 *
 *
 *                        MODIFICATION HISTORY                  REVIEW
 *
 * SCR#     Who    Date  Description
 * ===========================================================================
 * R0xxxxx 
 */


#include <ShcApp.h>
#include <ShcmsgHeader.h>
#include <ShcHelperBase.h>


#define FULL	1	/* Full reversal */
#define PART	0	/* Partial reversal */

class ShcPreauthHelper : public ShcHelperBase
{

protected:
	static int mbPreauthAgtId;
	
public:
    const char *getName()
    {
        return (const char *)SHC_ShcPreauthHelper;
    }

	ShcPreauthHelper() {};
	virtual ~ShcPreauthHelper() {};
	
	virtual int find_preauth_agent();
	virtual int shc_preauth_confirm(ShcmsgHeader *header);
	virtual int shc_preauth_response(ShcmsgHeader *header);
//	virtual int shc_preauth_service(ShcmsgHeader *header);
	virtual int shc_conf_process(ShcmsgHeader *header);
	virtual int shc_advice(ShcmsgHeader *header);
};

extern ShcPreauthHelper *shcPreauthHelperObj;

#endif
