#ifndef _MR_CUTOVER_TAG_DEFS_H_
#define _MR_CUTOVER_TAG_DEFS_H_

static char _MRCutOverTagDefs_h_what[] = "@(#)MRCutoverTagDefs.h 1.3 20/07/08 00:37:20";

/*
 *  Copyright (C) 2004 eFunds Corporation ("eFunds").  All Rights Reserved.     
 *  eFunds Canada Corporation is an authorized user.                            
 *                                                                              
 *  IST is a registered trademark of eFunds Corporation.  Other brand or        
 *  product names are trademarks or registered trademarks of their respective   
 *  holders.                                                                    
 *                                                                              
 *  The information contained herein is the unpublished proprietary property    
 *  of eFunds.  Except as specifically authorized in writing by eFunds, the     
 *  holder of this document shall: i) keep all information contained herein     
 *  confidential, and ii) protect the information, in whole or in part, from    
 *  disclosure and dissemination to all third parties.                          
 *                                                                          
 *  This document and the software described in it are furnished under license  
 *  and may be used or copied only in accordance with the terms of such license.
 *  This document is supplied for information purposes only, is subject to      
 *  change without notice, and should not be construed as a commitment by       
 *  either eFunds Corporation or eFunds Canada Corporation. 
 *
 *
 *                        MODIFICATION HISTORY                  REVIEW
 *
 * SCR#     Who    Date  Description
 * ===========================================================================
 */
#include <ist_seg_msg_replication_data.h>
#define MR_TAG_INSTITUTION_ID 1
#define MR_TAG_CAPTURE_DATE 2
#define MR_TAG_INST_TYPE 3
#define MR_TAG_ROLE_TYPE 4				//P:POS; A:ATM; O:OTHER
#define MR_TAG_ENTITY_ID 5

#endif
