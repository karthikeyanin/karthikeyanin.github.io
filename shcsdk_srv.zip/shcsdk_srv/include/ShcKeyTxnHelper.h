#ifndef _ShcKeyTxnHelper_H_
#define _ShcKeyTxnHelper_H_

static char _ShcKeyTxnHelper_h_what[] = "@(#) ShcKeyTxnHelper.h 1.3 10/03/15 08:52:39";

/*
 *  Copyright (C) 2004 eFunds Corporation ("eFunds").  All Rights Reserved.     
 *  eFunds Canada Corporation is an authorized user.                            
 *                                                                              
 *  IST is a registered trademark of eFunds Corporation.  Other brand or        
 *  product names are trademarks or registered trademarks of their respective   
 *  holders.                                                                    
 *                                                                              
 *  The information contained herein is the unpublished proprietary property    
 *  of eFunds.  Except as specifically authorized in writing by eFunds, the     
 *  holder of this document shall: i) keep all information contained herein     
 *  confidential, and ii) protect the information, in whole or in part, from    
 *  disclosure and dissemination to all third parties.                          
 *                                                                          
 *  This document and the software described in it are furnished under license  
 *  and may be used or copied only in accordance with the terms of such license.
 *  This document is supplied for information purposes only, is subject to      
 *  change without notice, and should not be construed as a commitment by       
 *  either eFunds Corporation or eFunds Canada Corporation. 
 *
 *
 *                        MODIFICATION HISTORY                  REVIEW
 *
 * SCR#     Who    Date  Description
 * ===========================================================================
 * R0xxxxx 
 */
 
#include <ShcApp.h>
#include <ShcmsgHeader.h>
#include <Shc300Header.h>
#include <ShcHelperBase.h>
#include <mt_inst_profile.h>

class ShcKeyTxnHelper: public ShcHelperBase
{
public:
    const char *getName()
    {
        return (const char *)SHC_ShcKeyTxnHelper;
    }

	//virtual int resetInst(ShcBin *shcBin);
	virtual int shcmac_ChgKey( ShcmsgHeader *header );
	virtual int shcpin_ChgKey(ShcmsgHeader *header);
	virtual int shckeys_ChangeKey(ShcBin *shcBin, char key_class, char type, char idx, char *obin, InstitutionProfile *instProfile );

};

#endif

