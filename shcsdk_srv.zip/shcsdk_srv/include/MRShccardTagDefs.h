#ifndef _MR_SHCCARD_TAG_DEFS_H_
#define _MR_SHCCARD_TAG_DEFS_H_

static char _MRShccardTagDefs_h_what[] = "@(#)MRShccardTagDefs.h 1.3 20/07/08 00:37:20"; 

/*
 *  Copyright (C) 2004 eFunds Corporation ("eFunds").  All Rights Reserved.     
 *  eFunds Canada Corporation is an authorized user.                            
 *                                                                              
 *  IST is a registered trademark of eFunds Corporation.  Other brand or        
 *  product names are trademarks or registered trademarks of their respective   
 *  holders.                                                                    
 *                                                                              
 *  The information contained herein is the unpublished proprietary property    
 *  of eFunds.  Except as specifically authorized in writing by eFunds, the     
 *  holder of this document shall: i) keep all information contained herein     
 *  confidential, and ii) protect the information, in whole or in part, from    
 *  disclosure and dissemination to all third parties.                          
 *                                                                          
 *  This document and the software described in it are furnished under license  
 *  and may be used or copied only in accordance with the terms of such license.
 *  This document is supplied for information purposes only, is subject to      
 *  change without notice, and should not be construed as a commitment by       
 *  either eFunds Corporation or eFunds Canada Corporation. 
 *
 *
 *                        MODIFICATION HISTORY                  REVIEW
 *
 * SCR#     Who    Date  Description
 * ===========================================================================
 */

#include <ist_seg_msg_replication_data.h>
// BITMAP - 2 bytes in the message. Total of 16 bits. Of which the first 4 bits are reserved for custom replication update types.
#define UPDATE_SHCCARDSTATUS	0x00000001
#define INSERT_SHCCARDSTATUS	0x00000002
#define DELETE_SHCCARDSTATUS	0x00000004

//TAG defines - Tag IDs less than 5000 are reserved for core data elements. Tag IDs 5001-9999 are reserved for custom tags

#define TAG_INSTITUTION_ID		1
#define	TAG_PAN					2
#define TAG_CARD_STATUS			3
#define	TAG_EFFECTIVE_FROM		4
#define	TAG_EFFECTIVE_TO		5
#define	TAG_PRESTATUS			6
#define	TAG_SITE_ID				7
#define	TAG_UPDATED_DATE		8


#endif
