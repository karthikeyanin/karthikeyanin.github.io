/*
 *	IST and IST/Share are registered trademarks of Oasis Technology Ltd.
 *
 *	Copyright (C) 1990 - 2003 Oasis Technology Ltd.
 *	All Rights Reserved
 *	This Module contains Proprietary Information of
 *	Oasis Technology Ltd., and should be treated as Confidential.
 *
 *	THIS IS UNPUBLISHED PROPRIETARY SOURCE CODE OF OASIS TECHNOLOGY LTD.
 *	The copyright notice above does not evidence any  
 *	actual or intended publication of such source code.
 */
/*
#pragma ident "@(#) ShcLateRev.h 1.5 17/04/27 14:16:06"
 *
 *                        MODIFICATION HISTORY                  REVIEW
 *
 *	SCR#	Who		Date		Description			Who	Date   
 * ===========================================================================
 *   		mwang 	08Mar04 	Created for CUSC to generate reversal on late
 *								response 210 from MBbank
 */
#ifndef ShcLateRev_H
#define ShcLateRev_H

#include <shc.h>
#include <revlog.h>
#include <lateresplog.h>
#include <DBMWrapper.hxx>

/*----------------------------------------------------------------------------
 * IST Accumulator Class Declariation  Block
 *---------------------------------------------------------------------------*/
#ifdef __cplusplus

class ShcLateRev
{
	public:

		ShcLateRev();
    	~ShcLateRev();

		int rev_request(ShcmsgHeader  *shc_msg);
		int fin_request(ShcmsgHeader  *shc_msg);
		int rev_nooriginal(ShcmsgHeader  *shc_msg);
		int checkForOrig(int site_id, char *logid);
		int commandLine(int arg_c, char **arg_v);
	protected:
		int queryAndUpdateCounter(ShcmsgHeader *header);
		int denyRevNoOrig(ShcmsgHeader *header);

	private:
		int insert_rev(ShcmsgHeader  *shcP);
		int insert_210();
		int opendb(void);
		int checkdbrec(struct revlog *rev_log);
		int checkdb210();
		int generate_revreq(ShcmsgHeader  *shc_msg, struct revlog *rev_log);
		int write_saf(ShcmsgHeader  *shc_msg);
		int restoreReversal(ShcmsgHeader *header, struct revlog *rev_log);
		int updateRevLogStatus(struct revlog *rev_log, char newstatus);
		int updateLateRespLogStatus(char newstatus);
		int revCheckskip(struct revlog *rev_log);
		int prepareUpdateRevlogStatus();
		int prepareUpdateLateRespLogStatus();
		int checkOriginal(ShcmsgHeader *header, struct revlog *rev_log);
		int cmdInfo(int arg_c, char **arg_v);
		int cmdList(int arg_c, char **arg_v);
		int cmdScan(int arg_c, char **arg_v);
		int cmdMark(int arg_c, char **arg_v);
		long getCount(int site_id, char status);

		struct		shcmsg		*m_shcmsg;	 	 /* the message handle   */

		int	laterev_fd;
		int	late210_fd;

		struct		revlog		 _revlog;
		struct      lateresplog  _late210log;
		DBMConn *_dbConn;
		DBMStmt *_updateRevlogStatus;
		DBMStmt *_updateLateRespLogStatus;
		DBMStmt *_countRevlogStatus;
		DBMStmt *_listRevlog;
		DBMStmt *_listallRevlog;

};

#endif
extern char	LateRev_tab[20];
#endif
