#ifndef _SHCREVRESP_H_
#define _SHCREVRESP_H_

static char _ShcRevResp_h_what[] = "@(#) ShcRevResp.h 1.5 05/03/01 17:49:34";
/*
 *  Copyright (C) 2004 eFunds Corporation ("eFunds").  All Rights Reserved.     
 *  eFunds Canada Corporation is an authorized user.                            
 *                                                                              
 *  IST is a registered trademark of eFunds Corporation.  Other brand or        
 *  product names are trademarks or registered trademarks of their respective   
 *  holders.                                                                    
 *                                                                              
 *  The information contained herein is the unpublished proprietary property    
 *  of eFunds.  Except as specifically authorized in writing by eFunds, the     
 *  holder of this document shall: i) keep all information contained herein     
 *  confidential, and ii) protect the information, in whole or in part, from    
 *  disclosure and dissemination to all third parties.                          
 *                                                                          
 *  This document and the software described in it are furnished under license  
 *  and may be used or copied only in accordance with the terms of such license.
 *  This document is supplied for information purposes only, is subject to      
 *  change without notice, and should not be construed as a commitment by       
 *  either eFunds Corporation or eFunds Canada Corporation. 
 *
 *
 *                        MODIFICATION HISTORY                  REVIEW
 *
 * SCR#     Who    Date  Description
 * ===========================================================================
 * R0xxxxx jyang 21Nov03 Created
 */

 //File Number 130

#include <stdio.h>
#include <string.h>
#include <oasis.h>
#include <ist_otrace.h>
#include <shc.h>
#include <shcextbuf.h> /* Ssc 2007336 VSDC support */
#include <tm.h>
#include <CShcLog.h>
#include <ShcSdkCommon.h>
#include <ShcmsgBaseTxn.h>

/*
 *	Financial reversal response
 */


class ShcRevResp : public ShcmsgBaseTxn
{
public:

	ShcRevResp(ShcmsgHeader *hd) { header=hd; OTraceDebug("D-SHC-130001:Enter function ShcRevResp()\n"); };
	virtual ~ShcRevResp() { OTraceDebug("D-SHC-130002:Leave ~ShcRevResp()\n"); }
	
	int  logresponse;

	long save_trace;
	int	 save_msgno;

protected:
	int  enrich();
	int  restore();	
	int  edit();
	int  doWork();

};

#endif

