#ifndef _SHCMSGTXNHELPER_H_
#define _SHCMSGTXNHELPER_H_

static char _ShcmsgTxnHelper_h_what[] = "@(#) ShcmsgTxnHelper.h 1.8.1.2 15/02/05 08:19:32";

/*
 *  Copyright (C) 2004 eFunds Corporation ("eFunds").  All Rights Reserved.     
 *  eFunds Canada Corporation is an authorized user.                            
 *                                                                              
 *  IST is a registered trademark of eFunds Corporation.  Other brand or        
 *  product names are trademarks or registered trademarks of their respective   
 *  holders.                                                                    
 *                                                                              
 *  The information contained herein is the unpublished proprietary property    
 *  of eFunds.  Except as specifically authorized in writing by eFunds, the     
 *  holder of this document shall: i) keep all information contained herein     
 *  confidential, and ii) protect the information, in whole or in part, from    
 *  disclosure and dissemination to all third parties.                          
 *                                                                          
 *  This document and the software described in it are furnished under license  
 *  and may be used or copied only in accordance with the terms of such license.
 *  This document is supplied for information purposes only, is subject to      
 *  change without notice, and should not be construed as a commitment by       
 *  either eFunds Corporation or eFunds Canada Corporation. 
 *
 *
 *                        MODIFICATION HISTORY                  REVIEW
 *
 * SCR#     Who    Date  Description
 * ===========================================================================
 * R0xxxxx 
 * R012160 Emj    10Oct04 Support for processor Business Day
 * R019289 jyang  26Mar07 Switch suspend mode support
 */
 

#include <ShcApp.h>
#include <ShcmsgHeader.h>
#include <Shc300Header.h>
#include <ShcProcessor.h>
#include <ShcHelperBase.h>

class ShcmsgTxnHelper : public ShcHelperBase
{
public:
    const char *getName()
    {
        return (const char *)SHC_ShcmsgTxnHelper;
    }

	virtual int shc_posauth(ShcmsgHeader *header, int settimer);
	virtual int shc_checkfloorlimit(ShcmsgHeader *shcmsg);
	virtual void setDefaultKeyLen(ShcmsgHeader *shcmsgHeader);
	virtual void setOriginator(ShcmsgHeader *shcmsgHeader);
	virtual void setParamSet(ShcmsgHeader *shcmsgHeader);
	virtual void setCapDate(ShcmsgHeader *shcmsgHeader);
	virtual int verifyAcqMac(ShcmsgHeader *shcmsgHeader);
	virtual int verifyIssMac(ShcmsgHeader *shcmsgHeader);
	virtual void denyReturnMsg(ShcmsgHeader *shcmsgHeader);
	virtual void checkChgAcqKey(ShcmsgHeader *shcmsgHeader);
	virtual void checkChgIssKey(ShcmsgHeader *shcmsgHeader);
	virtual void setDefaultRoutingFlag(ShcmsgHeader *shcmsgHeader);
	virtual void setCurrencyCode(ShcmsgHeader *shcmsgHeader);
	virtual void initFromDevice(ShcmsgHeader *shcmsgHeader);
	virtual void initForInterac(ShcmsgHeader *shcmsgHeader);
	virtual void setAcqCountry(ShcmsgHeader *shcmsgHeader);
	virtual int decideTimeOutValue(ShcmsgHeader *shcmsgHeader);
	virtual void setOnlineActivity(ShcmsgHeader *shcmsgHeader);
	virtual void setFromToAccounts(ShcmsgHeader *shcmsgHeader);
	virtual int shc_send_keyxchg(ShcBin *shcBin, char key_class, char key_type, int idx);
	virtual int shc_check_ndke(ShcmsgHeader *header);
	virtual int setSettleReqAdviceFlags(ShcmsgHeader *header);
	virtual ShcProcessor *enqueueInternalMsg(struct shcmsg *msg);
	virtual ShcProcessor *enqueueInternalMsg(ShcmsgHeader *hd);
	virtual int shc_pin(ShcmsgHeader *header);
	virtual int shc_translate_pinblk(ShcmsgHeader *header);
	virtual int shc_checkpin(ShcmsgHeader *shcmsg);
	virtual void setProcessorBusDay(ShcmsgHeader *shcmsg);
	virtual int processLateResponse(ShcmsgHeader *header);
	virtual int initTransaction( ShcmsgHeader *hdr );
	virtual int isForwardOnlyMode(ShcmsgHeader *hdr);
};

#endif

