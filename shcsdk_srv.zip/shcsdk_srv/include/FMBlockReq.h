//
// Copyright (C) 2004 eFunds Corporation ("eFunds").  All Rights Reserved.
// eFunds Canada Corporation is an authorized user.
//
// IST is a registered trademark of eFunds Corporation.  Other brand or
// product names are trademarks or registered trademarks of their respective
// holders.
//
// The information contained herein is the unpublished proprietary property
// of eFunds.  Except as specifically authorized in writing by eFunds, the
// holder of this document shall: i) keep all information contained herein
// confidential, and ii) protect the information, in whole or in part, from
// disclosure and dissemination to all third parties.
//
// This document and the software described in it are furnished under license
// and may be used or copied only in accordance with the terms of such license.
// This document is supplied for information purposes only, is subject to
// change without notice, and should not be construed as a commitment by
// either eFunds Corporation or eFunds Canada Corporation.
//
 /*
 *  SCR     Who     Date 	Description
 *  ===========================================================================
 *  R020052 spa	  21May07	New file created
 *  R025639 vmp   16Jan09	Changes for FM 	PhaseII enhancement
 */

/* File Number */
#ifndef __FMBLOCKREQ__
#define __FMBLOCKREQ__

static const char* _FMBlockReq_h_what = "@(#) FMBlockReq.h 1.3.1.1 15/07/13 06:42:07";

#include <ShcProcessor.h>
#include <FMCMDHeader.h>
#include <hotrange.h>
#include <shcmerchant.h>
//#include <shccard.h>

#define	FM_BLOCK_CARD		0
#define	FM_BLOCK_MERCHANT	1
#define	FM_BLOCK_TERMINAL	2
#define FM_BLOCK_PREFIX		3
//	>>>	R025639
#define	FM_HOTBLOCK_CARD	4
#define	FM_UNBLOCK_CARD		5
#define	FM_UNBLOCK_MERCHANT	6
#define	FM_SUSPEND_MERCHANT	7

#define	FM_UNBLOCK_TERMINAL	8
#define	FM_SUSPEND_TERMINAL	9
#define FM_UNBLOCK_PREFIX	10
//	<<<	R025639


class FMBlockReq : public ShcBaseTxn
{
	protected:
		virtual int enrich();
		virtual int doWork();
		FMCMDHeader *header;

		struct hotrange hotrange;
		//struct shccard card;
		struct shcmerchant merchant;

	public:
		int process();
		FMBlockReq(ShcHeader *);

};

#endif
