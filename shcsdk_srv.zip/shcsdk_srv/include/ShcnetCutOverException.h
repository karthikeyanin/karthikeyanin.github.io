/*
 * Copyright (C) 2004 eFunds Corporation ("eFunds").  All Rights Reserved.  
 * eFunds Canada Corporation is an authorized user. 
 * 
 * IST is a registered trademark of eFunds Corporation.  Other brand or
 * product names are trademarks or registered trademarks of their respective
 * holders. 
 * 
 * The information contained herein is the unpublished proprietary property
 * of eFunds.  Except as specifically authorized in writing by eFunds, the
 * holder of this document shall: i) keep all information contained herein
 * confidential, and ii) protect the information, in whole or in part, from
 * disclosure and dissemination to all third parties. 
 * 
 * This document and the software described in it are furnished under license
 * and may be used or copied only in accordance with the terms of such license.
 * This document is supplied for information purposes only, is subject to
 * change without notice, and should not be construed as a commitment by
 * either eFunds Corporation or eFunds Canada Corporation. 
 */
#ifndef SHCCUTOVEREXCEPTION_INCLUDE
#define SHCCUTOVEREXCEPTION_INCLUDE
static char _shccutoverexception_include[] = "@(#) ShcnetCutOverException.h 1.2 04/05/10 09:34:12";

/*
 *	IST and IST/Share are registered trademarks of Oasis Technology Ltd.
 *
 *	Copyright (C) 1990 - 1997 Oasis Technology Ltd.
 *	All Rights Reserved
 *	This Module contains Proprietary Information of
 *	Oasis Technology Ltd., and should be treated as Confidential.
 *
 *	THIS IS UNPUBLISHED PROPRIETARY SOURCE CODE OF OASIS TECHNOLOGY LTD.
 *	The copyright notice above does not evidence any  
 *	actual or intended publication of such source code.
 *
 *                        MODIFICATION HISTORY                  REVIEW
 *
 *	SPR#	Who	Date	Description			Who	Date   
 * ===========================================================================
 *R007563 ztang 03Mar02 Added class for formating acceptor_name field in shcmsg
 *R009021 ztang 31Jan03	Seprated from shcfmt.h
 *
 */

#if !defined( ShcnetCutOverException_h_export_directive )
#   if defined( WIN32 )
#       define ShcnetCutOverException_h_export_directive __declspec(dllimport)
#   else
#       define ShcnetCutOverException_h_export_directive
#   endif
#endif

#include "ist_win32.h"
#include "string.h"

											//R007563 BEGIN
class ShcnetCutOverException_h_export_directive ShcnetCutOverException
{
};
#endif
