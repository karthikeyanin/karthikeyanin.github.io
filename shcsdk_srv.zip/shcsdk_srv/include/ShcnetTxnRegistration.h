#ifndef _SHCNETTXNREGISTRATION_H_
#define _SHCNETTXNREGISTRATION_H_

static char _ShcnetTxnRegistration_h_what[] = "@(#) ShcnetTxnRegistration.h 1.1 04/12/22 16:50:24";
/*
 *  Copyright (C) 2004 eFunds Corporation ("eFunds").  All Rights Reserved.     
 *  eFunds Canada Corporation is an authorized user.                            
 *                                                                              
 *  IST is a registered trademark of eFunds Corporation.  Other brand or        
 *  product names are trademarks or registered trademarks of their respective   
 *  holders.                                                                    
 *                                                                              
 *  The information contained herein is the unpublished proprietary property    
 *  of eFunds.  Except as specifically authorized in writing by eFunds, the     
 *  holder of this document shall: i) keep all information contained herein     
 *  confidential, and ii) protect the information, in whole or in part, from    
 *  disclosure and dissemination to all third parties.                          
 *                                                                          
 *  This document and the software described in it are furnished under license  
 *  and may be used or copied only in accordance with the terms of such license.
 *  This document is supplied for information purposes only, is subject to      
 *  change without notice, and should not be construed as a commitment by       
 *  either eFunds Corporation or eFunds Canada Corporation. 
 *
 *                        MODIFICATION HISTORY                  REVIEW
 *
 * SCR#     Who    Date  Description
 * ===========================================================================
 * R0xxxxx 
 */


#include <oasis.h>
#include <ShcBaseTxn.h>
#include <ShcnetTxnFactory.h>
#include <SdkRegistration.h>

class ShcnetTxnRegistration : public Registration <ShcmsgBaseTxn, ShcnetTxnFactory>
{
public:
	ShcnetTxnRegistration(char *objName):
		Registration <ShcmsgBaseTxn, ShcnetTxnFactory>(objName)
	{}
};

#endif
