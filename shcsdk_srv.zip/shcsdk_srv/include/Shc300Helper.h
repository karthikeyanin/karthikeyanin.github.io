#ifndef _SHC300HELPER_H_
#define _SHC300HELPER_H_

static char _Shc300Helper_h_what[] = "@(#) Shc300Helper.h 1.7 15/01/27 14:46:35"; 

/*
 *  Copyright (C) 2004 eFunds Corporation ("eFunds").  All Rights Reserved.
 *  eFunds Canada Corporation is an authorized user.
 *
 *  IST is a registered trademark of eFunds Corporation.  Other brand or
 *  product names are trademarks or registered trademarks of their respective
 *  holders.
 *
 *  The information contained herein is the unpublished proprietary property
 *  of eFunds.  Except as specifically authorized in writing by eFunds, the
 *  holder of this document shall: i) keep all information contained herein
 *  confidential, and ii) protect the information, in whole or in part, from
 *  disclosure and dissemination to all third parties.
 *
 *  This document and the software described in it are furnished under license
 *  and may be used or copied only in accordance with the terms of such license.
 *  This document is supplied for information purposes only, is subject to
 *  change without notice, and should not be construed as a commitment by
 *  either eFunds Corporation or eFunds Canada Corporation.
 *
 *
 *                        MODIFICATION HISTORY                  REVIEW
 *
 * SCR#     Who    Date  Description
 * ===========================================================================
 * R0xxxxx
 */


#include <ShcSdkCommon.h>
#include <ShcApp.h>
#include <ShcProcessor.h>
#include <ShcHelperBase.h>
#include <ShcmsgHeader.h>
class Shc300Header;


class Shc300Helper : public ShcHelperBase
{
public:
	const char *getName()
	{
		return (const char *)SHC_Shc300Helper;
	}

	virtual int shc_get_return_msgno(int msgno);
	virtual ShcProcessor *enqueueInternalMsg(ShcmsgHeader *hd);
	virtual int shc_deny_txn(ShcmsgHeader *header);
	virtual void shc_callback_log( ShcmsgHeader *header, int logType);
	virtual int shc_route(ShcmsgHeader *header);
	virtual int adjustTimer(Shc300Header *header);
	virtual int setDefaultTranDate(ShcmsgHeader *header);
	virtual int getEvent(ShcmsgHeader *header);



};


extern Shc300Helper *shc300HelperObj;

#endif

