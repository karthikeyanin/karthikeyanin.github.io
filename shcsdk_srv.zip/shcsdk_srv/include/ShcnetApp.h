#ifndef _SHCNETAPP_H_
#define _SHCNETAPP_H_

static char _ShcnetApp_h_what[] = "@(#) ShcnetApp.h 1.4 05/01/10 15:07:48";

/*
 *  Copyright (C) 2004 eFunds Corporation ("eFunds").  All Rights Reserved.     
 *  eFunds Canada Corporation is an authorized user.                            
 *                                                                              
 *  IST is a registered trademark of eFunds Corporation.  Other brand or        
 *  product names are trademarks or registered trademarks of their respective   
 *  holders.                                                                    
 *                                                                              
 *  The information contained herein is the unpublished proprietary property    
 *  of eFunds.  Except as specifically authorized in writing by eFunds, the     
 *  holder of this document shall: i) keep all information contained herein     
 *  confidential, and ii) protect the information, in whole or in part, from    
 *  disclosure and dissemination to all third parties.                          
 *                                                                          
 *  This document and the software described in it are furnished under license  
 *  and may be used or copied only in accordance with the terms of such license.
 *  This document is supplied for information purposes only, is subject to      
 *  change without notice, and should not be construed as a commitment by       
 *  either eFunds Corporation or eFunds Canada Corporation. 
 *
 *                        MODIFICATION HISTORY                  REVIEW
 *
 * SCR#     Who    Date  Description
 * ===========================================================================
 * R0xxxxx ztang 05Nov03 Creation
 */
 

#include <ShcSdkCommon.h>
#include <shcextbuf.h>
#include <Queue.h>
#include <ShcApp.h>

/* The class that holds the global variables */
class ShcnetApp : public ShcApp
{
public:
	static char *default_netmgr;
	char	*netname;
	int shcid;
	
	ShcnetApp() 
	{ 
		netname = NULL; 
		shcid = -1;
	};
    const char *getName()
    {
        return (const char *)SHC_ShcnetApp;
    }

};

#endif

