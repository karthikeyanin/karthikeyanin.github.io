#ifndef _SHCNET_MAIN_LOOP_H_
#define _SHCNET_MAIN_LOOP_H_

static char _ShcnetMainLoop_h_what[] = "@(#) ShcnetMainLoop.h 1.3 05/01/10 15:07:49";

/*
 *  Copyright (C) 2004 eFunds Corporation ("eFunds").  All Rights Reserved.     
 *  eFunds Canada Corporation is an authorized user.                            
 *                                                                              
 *  IST is a registered trademark of eFunds Corporation.  Other brand or        
 *  product names are trademarks or registered trademarks of their respective   
 *  holders.                                                                    
 *                                                                              
 *  The information contained herein is the unpublished proprietary property    
 *  of eFunds.  Except as specifically authorized in writing by eFunds, the     
 *  holder of this document shall: i) keep all information contained herein     
 *  confidential, and ii) protect the information, in whole or in part, from    
 *  disclosure and dissemination to all third parties.                          
 *                                                                          
 *  This document and the software described in it are furnished under license  
 *  and may be used or copied only in accordance with the terms of such license.
 *  This document is supplied for information purposes only, is subject to      
 *  change without notice, and should not be construed as a commitment by       
 *  either eFunds Corporation or eFunds Canada Corporation. 
 *
 *
 *                        MODIFICATION HISTORY                  REVIEW
 *
 * SCR#     Who    Date  Description
 * ===========================================================================
 * R0xxxxx ztang 05Nov03 Creation
 */
 

#include <ShcSdkCommon.h>
#include <shc.h>
#include <shcextbuf.h>

class ShcProcessor;

class ShcnetMainLoop 
{
	ShcnetMainLoop();
	
protected:
	static int  _initialized;
	static ShcnetMainLoop* _instance;
	
	static struct shcsegrec  shcsegrecbuf;
	
	ShcProcessor* shcProcessor;
	
	virtual int initialize();
	
public:
	
	virtual int process();		// main loop; (classify())->process();
	virtual int registerProcessors();
	virtual int registerBaseTxns();
	virtual ShcProcessor *processQueue();
	//virtual int initEnvForMsg(char *msg);	
	
	static ShcnetMainLoop* getInstance();
	static int call_dbm_init;
	
};

#endif

