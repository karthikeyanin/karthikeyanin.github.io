#ifndef _SHCREVREQ_H_
#define _SHCREVREQ_H_

static char _ShcRevReq_h_what[] = "@(#) ShcRevReq.h 1.6 05/01/10 15:07:42";
/*
 *  Copyright (C) 2004 eFunds Corporation ("eFunds").  All Rights Reserved.     
 *  eFunds Canada Corporation is an authorized user.                            
 *                                                                              
 *  IST is a registered trademark of eFunds Corporation.  Other brand or        
 *  product names are trademarks or registered trademarks of their respective   
 *  holders.                                                                    
 *                                                                              
 *  The information contained herein is the unpublished proprietary property    
 *  of eFunds.  Except as specifically authorized in writing by eFunds, the     
 *  holder of this document shall: i) keep all information contained herein     
 *  confidential, and ii) protect the information, in whole or in part, from    
 *  disclosure and dissemination to all third parties.                          
 *                                                                          
 *  This document and the software described in it are furnished under license  
 *  and may be used or copied only in accordance with the terms of such license.
 *  This document is supplied for information purposes only, is subject to      
 *  change without notice, and should not be construed as a commitment by       
 *  either eFunds Corporation or eFunds Canada Corporation. 
 *
 *
 *                        MODIFICATION HISTORY                  REVIEW
 *
 * SCR#     Who    Date  Description
 * ===========================================================================
 * R0xxxxx jyang 21Nov03 Created
 */

 //File Number 129

#include <ShcSdkCommon.h>
#include <ShcmsgBaseTxn.h>

class ShcRevReq : public ShcmsgBaseTxn
{
protected:
	int  enrich();
	int  restore();
	int  edit();
	int  verify();
	int  doWork();

	
public:
	ShcRevReq(ShcmsgHeader* hd) :
						 save_msgtype(hd->msg.msgtype)
						{ header=hd; OTraceDebug("D-SHC-129001: Enter ShcRevReq()\n"); };
	virtual ~ShcRevReq() { OTraceDebug("D-SHC-129002:Leave ~ShcRevReq()\n"); }
	

protected:
	int  save_msgtype;
	static int  dupRevCheckDone;
//	int  flagLogRequest;
};


#endif
