#ifndef _SHCNETWORKMSGHELPER_H_
#define _SHCNETWORKMSGHELPER_H_

static char _ShcNetworkMsgHelper_h_what[] = "@(#) ShcNetworkMsgHelper.h 1.14 19/09/27 09:44:44";

/*
 *  Copyright (C) 2004 eFunds Corporation ("eFunds").  All Rights Reserved.     
 *  eFunds Canada Corporation is an authorized user.                            
 *                                                                              
 *  IST is a registered trademark of eFunds Corporation.  Other brand or        
 *  product names are trademarks or registered trademarks of their respective   
 *  holders.                                                                    
 *                                                                              
 *  The information contained herein is the unpublished proprietary property    
 *  of eFunds.  Except as specifically authorized in writing by eFunds, the     
 *  holder of this document shall: i) keep all information contained herein     
 *  confidential, and ii) protect the information, in whole or in part, from    
 *  disclosure and dissemination to all third parties.                          
 *                                                                          
 *  This document and the software described in it are furnished under license  
 *  and may be used or copied only in accordance with the terms of such license.
 *  This document is supplied for information purposes only, is subject to      
 *  change without notice, and should not be construed as a commitment by       
 *  either eFunds Corporation or eFunds Canada Corporation. 
 *
 *
 *                        MODIFICATION HISTORY                  REVIEW
 *
 * SCR#     Who    Date  Description
 * ===========================================================================
 * R0xxxxx ztang 05Nov03 Creation
 * R011298 Emj   10Oct04 Support for Cutover and Recon at Entity Level
 * R022747 jyang 06Mar08 Support Bin Route
 */
 

#include <ShcSdkCommon.h>
#include <ShcApp.h>
#include <multi_institution.h>
#include <BusinessDay.h>
#include <ShcBin.h>
#include <ShcHelperBase.h>

#define KEY_GRACE_PEROID_EVENT_KEY 92000000

class ShcNetworkMsgHelper: public ShcHelperBase
{
public:
    const char *getName()
    {
        return (const char *)SHC_ShcNetworkMsgHelper;
    }


	virtual int setRoutingFlags(ShcmsgHeader *header);
	virtual int shc_send_keyxchg(ShcBin *shcBin, char key_class, char key_type);
	virtual int makeServiceIndicator(ShcmsgHeader *header);
	virtual int shc_euNetTimer( ShcmsgHeader *header, int iNetcode, int iDelay );
	virtual int net_signoff(ShcmsgHeader *header);
	virtual int net_signon(register ShcmsgHeader *header);
	virtual int net_setinstup(ShcmsgHeader *header);
	virtual int net_continue_signon(ShcmsgHeader *header);
	virtual int net_startreplay(register ShcmsgHeader *header);
	virtual int net_stopreplay(ShcmsgHeader *header);
	virtual int shcnet_exchange_request( ShcmsgHeader *header, char status );
	virtual int shcnet_keyxchg_request_2leg( ShcmsgHeader *header);
	virtual int net_send_enter_SI(ShcmsgHeader *header);
	virtual int net_send_exit_SI(ShcmsgHeader *header);
	virtual int net_echo_test(ShcmsgHeader *header);
	virtual int net_initialise_message(ShcmsgHeader *header);
	virtual int shc_network_xchg(ShcmsgHeader *header, char keyflag);
	virtual int shc_network_build_request(ShcmsgHeader *header);
	virtual int shcnet_continue_signon(ShcmsgHeader *header);
	virtual int shc_network_keys_req(ShcmsgHeader *header);
	virtual long shc_generate_uni_trace();
	virtual int istSelfResponse( ShcmsgHeader *header );
	virtual int shcnet_keys_response( ShcmsgHeader *header );
	virtual int shcnet_exchange_response( ShcmsgHeader *header, char status );
	virtual int shcCreateEvent(ShcmsgHeader *header);

	virtual int checkIssuer(ShcmsgHeader *header);
	virtual int setOrigData(ShcmsgHeader *header);
	virtual int processSignOn(ShcmsgHeader *header);
	virtual int do_key_exchange_as2805( ShcmsgHeader *header );
	virtual int processTwoWaySignOn(ShcmsgHeader *header);
	virtual int processDoneKey(ShcmsgHeader *header);
	virtual int processSignOff(ShcmsgHeader *header);
	virtual int processKeyStart(ShcmsgHeader *header);
	virtual int processKey(ShcmsgHeader *header);
	virtual int processKeyValidation(ShcmsgHeader *header);
	virtual int processStartSaf(ShcmsgHeader *header);
	virtual int processStopSaf(ShcmsgHeader *header);
	virtual int processEnterSI(ShcmsgHeader *header);
	virtual int processExitSI(ShcmsgHeader *header);
	virtual int processEcho(ShcmsgHeader *header);
	virtual int processAbortKey(ShcmsgHeader *header);
	virtual int processClose(ShcmsgHeader *header);
	virtual int processCutOver(ShcmsgHeader *header);
	virtual int processKeyReq(ShcmsgHeader *header);
//	virtual int processTermKey(ShcmsgHeader *header);
	virtual int processEuropayReject(ShcmsgHeader *header);
	virtual int processOtherMsg(ShcmsgHeader *header);
	virtual int removeEvent(ShcmsgHeader *header);

	virtual int shc_net(ShcmsgHeader *header);
	virtual int shc_groupdown(ShcmsgHeader *header, ShcBin *shcBin);
	virtual int shc_setdown(ShcmsgHeader *header, ShcBin *shcBin);
	virtual int shc_markdown(ShcmsgHeader *header, ShcBin *shcBin);
	virtual int shc_stopreplay(ShcmsgHeader *header, ShcBin *shcBin);
	virtual int shc_groupup(ShcmsgHeader *header, ShcBin *shcBin);
	virtual int shc_setup(ShcmsgHeader *header, ShcBin *shcBin);
	virtual int shc_echotest(ShcmsgHeader *header, ShcBin *shcBin);
	virtual int shc_generate_800( ShcmsgHeader *header, ShcBin *shcBin, int netcode );
	virtual int shc_build_800(ShcmsgHeader *header, struct shcmsg *msg, ShcBin *shcBin, int code);
	virtual int shc_send_800(ShcmsgHeader *h, ShcBin *shcBin);
	//R027855 moved to CutoverHelper virtual int MemberCutover(ShcmsgHeader *header, InstBusinessDay * businessDay);
	virtual int shc_send_endofday_recon( ShcmsgHeader *header);

	//R027855 >>
	virtual int processCutOverRequest(ShcmsgHeader *header);
	//R027855 <<
	virtual int prepareMsgFromBinRoute(ShcmsgHeader *tmpHeader, struct s_binroute *pBinRoute);
	virtual int getInstProfile(struct s_binroute *pBinRoute, NetworkInfo *networkInfo);
	int processKeyGracePeriod(ShcmsgHeader *header);
	int isOldKey( struct shckey_buf *keybufp, ShcmsgHeader *header );


	ShcNetworkMsgHelper();//int mid): netid(mid) {};

	int updateBinRoute( ShcmsgHeader *header );

protected:
	//R027855 moved to Cutoverhelper int shc_prepare_cut_over(ShcmsgHeader *header, InstBusinessDay *businessDay);
	//R027855 void BroadcastCutover(ShcmsgHeader *header);
	//R027855 moved to Cutoverhelper void BroadcastCutover(ShcmsgHeader *header, InstBusinessDay *businessDay);
	
	int netid;

};

extern ShcNetworkMsgHelper *shcNetworkMsgHelperObj;

const char* const SHC_KeyXchgMsgHelper = "ShcKeyXchgHelper";

class KeyXchgMsgHelper : public ShcHelperBase
{
public:
	const char *getName() { return(const char *)SHC_KeyXchgMsgHelper; }

	int collect( ShcNetworkMsgHelper &,ShcmsgHeader  *, char &, char &);
	int preProc( ShcNetworkMsgHelper &,ShcmsgHeader *,struct shckey_buf *,char &,char &);
	int proc(ShcNetworkMsgHelper &,ShcmsgHeader *,struct shckey_buf *,char &);
	//int resume(ShcNetworkMsgHelper &,ShcmsgHeader *,struct shckey_buf *,char &,char &, char &);
	int resume(ShcNetworkMsgHelper &,ShcmsgHeader *,struct shckey_buf *,char &,char &);
};

#endif

