#ifndef _SHCMSGEVENTHELPER_H_
#define _SHCMSGEVENTHELPER_H_

static char _ShcmsgEventHelper_h_what[] = "@(#) ShcmsgEventHelper.h 1.4 05/02/02 16:55:35";

/*
 *  Copyright (C) 2004 eFunds Corporation ("eFunds").  All Rights Reserved.     
 *  eFunds Canada Corporation is an authorized user.                            
 *                                                                              
 *  IST is a registered trademark of eFunds Corporation.  Other brand or        
 *  product names are trademarks or registered trademarks of their respective   
 *  holders.                                                                    
 *                                                                              
 *  The information contained herein is the unpublished proprietary property    
 *  of eFunds.  Except as specifically authorized in writing by eFunds, the     
 *  holder of this document shall: i) keep all information contained herein     
 *  confidential, and ii) protect the information, in whole or in part, from    
 *  disclosure and dissemination to all third parties.                          
 *                                                                          
 *  This document and the software described in it are furnished under license  
 *  and may be used or copied only in accordance with the terms of such license.
 *  This document is supplied for information purposes only, is subject to      
 *  change without notice, and should not be construed as a commitment by       
 *  either eFunds Corporation or eFunds Canada Corporation. 
 *
 *
 *
 *                        MODIFICATION HISTORY                  REVIEW
 *
 *	SPR#	Who	Date	Description			Who	Date   
 * ===========================================================================
 * R0xxxxx jyang 09Dec03 Created
 */

#include <ShcApp.h>
#include <ShcmsgEvent.h>
#include <ShcHelperBase.h>

class ShcmsgEventHelper: public ShcHelperBase
{
public:
    const char *getName()
    {
        return (const char *)SHC_ShcmsgEventHelper;
    }

	virtual int retryOnTimeout(ShcmsgHeader *header, ShcBin *shcBin);
	virtual int procAdviceEvent(ShcmsgHeader *header, ShcBin *shcBin);
	virtual int doPositiveAuth(ShcmsgHeader *header, ShcBin *shcBin, int timeout);
	virtual int generateInternalRev(ShcmsgHeader *header, ShcBin *shcBin);
	virtual int procFinAuthEvent(ShcmsgEvent *eventTxn, ShcmsgHeader *header);
	virtual int procRevEvent(ShcmsgHeader *header);
	virtual int checkAndSetSafType(ShcmsgEvent *eventTxn, ShcmsgHeader *header, ShcBin *shcBin);
	virtual int checkAndSetBinDown(ShcmsgHeader *header, ShcBin *shcBin);
	virtual int restoreOldPINBlock(ShcmsgHeader *header);
};


#endif
