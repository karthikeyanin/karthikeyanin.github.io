#ifndef _SHC_RET_SHC300_
#define _SHC_RET_SHC300_

static char _ShcRetShc300_h_what[] = "@(#) ShcRetShc300.h 1.0 03/10/17 16:49:20";
/*
 *  Copyright (C) 2004 eFunds Corporation ("eFunds").  All Rights Reserved.     
 *  eFunds Canada Corporation is an authorized user.                            
 *                                                                              
 *  IST is a registered trademark of eFunds Corporation.  Other brand or        
 *  product names are trademarks or registered trademarks of their respective   
 *  holders.                                                                    
 *                                                                              
 *  The information contained herein is the unpublished proprietary property    
 *  of eFunds.  Except as specifically authorized in writing by eFunds, the     
 *  holder of this document shall: i) keep all information contained herein     
 *  confidential, and ii) protect the information, in whole or in part, from    
 *  disclosure and dissemination to all third parties.                          
 *                                                                          
 *  This document and the software described in it are furnished under license  
 *  and may be used or copied only in accordance with the terms of such license.
 *  This document is supplied for information purposes only, is subject to      
 *  change without notice, and should not be construed as a commitment by       
 *  either eFunds Corporation or eFunds Canada Corporation. 
 *
 *
 *                        MODIFICATION HISTORY                  REVIEW
 *
 * SCR#     Who    Date  Description
 * ===========================================================================
 * R0xxxxx 
 */

#include <ShcmsgBaseTxn.h>
#include <Shc300BaseTxn.h>

class ShcRetShc300 : public Shc300BaseTxn 
{
protected:
	virtual int enrich();
	virtual int edit();
	virtual int doWork();
	
public:
	ShcRetShc300(ShcmsgHeader *newHeader) { header = newHeader; };
	virtual ~ShcRetShc300() {};
	
};




#endif


