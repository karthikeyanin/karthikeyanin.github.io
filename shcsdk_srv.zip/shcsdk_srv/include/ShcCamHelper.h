#ifndef _SHCCAMHELPER_H_
#define _SHCCAMHELPER_H_

static char _ShcCamHelper_h_what[] = "@(#) ShcCamHelper.h 1.3 05/01/10 15:07:26";

/*
 *  Copyright (C) 2004 eFunds Corporation ("eFunds").  All Rights Reserved.     
 *  eFunds Canada Corporation is an authorized user.                            
 *                                                                              
 *  IST is a registered trademark of eFunds Corporation.  Other brand or        
 *  product names are trademarks or registered trademarks of their respective   
 *  holders.                                                                    
 *                                                                              
 *  The information contained herein is the unpublished proprietary property    
 *  of eFunds.  Except as specifically authorized in writing by eFunds, the     
 *  holder of this document shall: i) keep all information contained herein     
 *  confidential, and ii) protect the information, in whole or in part, from    
 *  disclosure and dissemination to all third parties.                          
 *                                                                          
 *  This document and the software described in it are furnished under license  
 *  and may be used or copied only in accordance with the terms of such license.
 *  This document is supplied for information purposes only, is subject to      
 *  change without notice, and should not be construed as a commitment by       
 *  either eFunds Corporation or eFunds Canada Corporation. 
 *
 *
 *                        MODIFICATION HISTORY                  REVIEW
 *
 * SCR#     Who    Date  Description
 * ===========================================================================
 * R0xxxxx 
 */
 

#include <ShcSdkCommon.h>
#include <shcextbuf.h>
#include <ShcmsgHeader.h>
#include <ShcHelperBase.h>
#include <ShcApp.h>

class ShcCamHelper : public ShcHelperBase
{
public:
    const char *getName()
    {
        return (const char *)SHC_ShcCamHelper;
    }

	virtual emv *cam_get_emv_buf(struct shcmsg *msg);
	virtual int shc_cam_stip_request_start (ShcmsgHeader *header);
	virtual int shc_cam_request_start (ShcmsgHeader *header);
	virtual int shc_cam_request_result (ShcmsgHeader *header);
	virtual int shc_cam_response_start (ShcmsgHeader *header);
	virtual int shc_cam_response_result (ShcmsgHeader *header);
	virtual int check_auth_result (ShcmsgHeader *header);
	virtual void format_in_cryptogram(char *p, char *bp);
	virtual void format_out_cryptogram(char *p, char *bp);

};

#endif

