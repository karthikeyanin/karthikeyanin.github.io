#ifndef _SHC_LATERESP_HELPER_H
#define _SHC_LATERESP_HELPER_H

static char _ShcLateRespHelper_h_what[] = "@(#) ShcLateRespHelper.h 1.3 14/06/23 09:24:00";
/*
 *  Copyright (C) 2004 eFunds Corporation ("eFunds").  All Rights Reserved.     
 *  eFunds Canada Corporation is an authorized user.                            
 *                                                                              
 *  IST is a registered trademark of eFunds Corporation.  Other brand or        
 *  product names are trademarks or registered trademarks of their respective   
 *  holders.                                                                    
 *                                                                              
 *  The information contained herein is the unpublished proprietary property    
 *  of eFunds.  Except as specifically authorized in writing by eFunds, the     
 *  holder of this document shall: i) keep all information contained herein     
 *  confidential, and ii) protect the information, in whole or in part, from    
 *  disclosure and dissemination to all third parties.                          
 *                                                                          
 *  This document and the software described in it are furnished under license  
 *  and may be used or copied only in accordance with the terms of such license.
 *  This document is supplied for information purposes only, is subject to      
 *  change without notice, and should not be construed as a commitment by       
 *  either eFunds Corporation or eFunds Canada Corporation. 
 *
 *
 *                        MODIFICATION HISTORY                  REVIEW
 *
 * SCR#     Who    Date  Description
 * ===========================================================================
 * R0xxxxx 
 * R027905 dipa	25Mar10	Reversal-Void enhancements
 */

#include <ShcApp.h>
#include <ShcmsgBaseTxn.h>
#include <ShcHelperBase.h>

#define SHC_ShcLateRespHelper "ShcLateRespHelper"

class ShcLateRespHelper : public ShcHelperBase
{
public:
    const char *getName()
    {
        return (const char *)SHC_ShcLateRespHelper;
    }

	virtual int processLateResp(ShcHeader  *header);
	virtual int processTimeOutReversal(ShcmsgHeader  *header);
	virtual int processVoid(ShcmsgHeader  *header); //R027905	
	virtual int processRevNoOriginal(ShcmsgHeader  *header);
};




#endif

