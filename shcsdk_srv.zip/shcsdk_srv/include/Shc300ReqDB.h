/*
 *	IST and IST/Share are registered trademarks of Oasis Technology Ltd.
 *
 *	Copyright (C) 1990 - 2003 Oasis Technology Ltd.
 *	All Rights Reserved
 *	This Module contains Proprietary Information of
 *	Oasis Technology Ltd., and should be treated as Confidential.
 *
 *	THIS IS UNPUBLISHED PROPRIETARY SOURCE CODE OF OASIS TECHNOLOGY LTD.
 *	The copyright notice above does not evidence any
 *	actual or intended publication of such source code.
 */
/*
#pragma ident "@(#) ShcLateRev.h 1.4 14/07/10 15:32:03"
 *
 *                        MODIFICATION HISTORY                  REVIEW
 *
 *	SCR#	Who		Date		Description			Who	Date
 * ===========================================================================
 *   		mwang 	08Mar04 	Created for CUSC to generate reversal on late
 *								response 210 from MBbank
 */
#ifndef Shc300ReqDB_H
#define Shc300ReqDB_H

#include <shc.h>
#include <DBMWrapper.hxx>
#include <shccardstatus.h>
#include <shccardstatushist.h>
#include <dbm.h>
#include <dbm_private.h>
#include <auto_ptr.h>
#include <debug.h>
#include <ist_otrace.h>
#include <oc/oc_string.h>
#include <ShcmsgHeader.h>
#include <ShcHelperBase.h>
#include <ShcAppBase.h>
#include <ShcHelper.h>


/*----------------------------------------------------------------------------
 * IST Accumulator Class Declariation  Block
 *---------------------------------------------------------------------------*/
#ifdef __cplusplus

class Shc300ReqDB
{
	public:

		Shc300ReqDB();
    	~Shc300ReqDB();


		int update_shc300(ShcmsgHeader *header);
		int select_shc300(ShcmsgHeader *header);
		int delete_shc300(ShcmsgHeader *header);
		int add_shc300(ShcmsgHeader *header);

	protected:
		void dbInit();
		int prepareUpdateShcCardStatus();
		int prepareDeleteShcCardStatus();
		int deleteShcCardStatus(ShcmsgHeader *header);
		int updateShcCardStatus(ShcmsgHeader *header);
		int checkdbshccard(ShcmsgHeader *header);
		int prepareshccardstatusselect();
		int prepareInsertShcCardStatus();
		int insertShcCardStatusHist(ShcmsgHeader *header);
		int insertShcCardStatus(ShcmsgHeader *header);
		int	shccardstatus_fd;
		int	shccardstatushist_fd;
		int opendb(void);
		struct		shcmsg		*m_shcmsg;	 	 /* the message handle   */
		struct shccardstatus  _shccardstatus;
		struct shccardstatushist _shccardstatushist;
		//OCDateTime      updated;
		//OCDateTime      effectiveto;
		DBMDateTime updated;
		DBMDateTime effectiveto;
		DBMDateTime effectivefrom;
		DBMConn *_dbConn;
		DBMStmt *_updateShcCardStatus;
		DBMStmt *_deleteShcCardStatus;
		DBMStmt *_insertShcCardStatus;
		DBMStmt *_selectShcCardStatus;
		int _ind[50];
};

#endif
#endif
