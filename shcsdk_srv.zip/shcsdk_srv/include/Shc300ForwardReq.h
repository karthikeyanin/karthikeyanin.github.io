#ifndef _Shc300ForwardReq_h_
#define _Shc300ForwardReq_h_

static char _Shc300ForwardReq_h_what[] = "@(#) Shc300ForwardReq.h 1.1 18/05/17 07:07:17";

/*
 *  Copyright (C) 2004 eFunds Corporation ("eFunds").  All Rights Reserved.     
 *  eFunds Canada Corporation is an authorized user.                            
 *                                                                              
 *  IST is a registered trademark of eFunds Corporation.  Other brand or        
 *  product names are trademarks or registered trademarks of their respective   
 *  holders.                                                                    
 *                                                                              
 *  The information contained herein is the unpublished proprietary property    
 *  of eFunds.  Except as specifically authorized in writing by eFunds, the     
 *  holder of this document shall: i) keep all information contained herein     
 *  confidential, and ii) protect the information, in whole or in part, from    
 *  disclosure and dissemination to all third parties.                          
 *                                                                          
 *  This document and the software described in it are furnished under license  
 *  and may be used or copied only in accordance with the terms of such license.
 *  This document is supplied for information purposes only, is subject to      
 *  change without notice, and should not be construed as a commitment by       
 *  either eFunds Corporation or eFunds Canada Corporation. 
 *
 *
 *
 *                        MODIFICATION HISTORY                  REVIEW
 *
 *	SPR#	Who	Date	Description			Who	Date   
 * ===========================================================================
 * R0xxxxx jyang 09Dec03 Created
 */

#include <stdio.h>
#include <oasis.h>
#include <mb.h>
#include <tm.h>
#include <ist_otrace.h>
#include <shc.h>
#include <shcerror.h>

#include <ShcmsgEvent.h>
#include <ShcmsgBaseTxn.h>
#include <ShcSaf.h>
#include <Shc300BaseTxn.h>
 
class Shc300ForwardReq : public Shc300BaseTxn
{
public:
	Shc300ForwardReq(ShcmsgHeader *hd){ header = hd; }
protected:
	int enrich();
	int edit();
	int doWork();
	
};


#endif

