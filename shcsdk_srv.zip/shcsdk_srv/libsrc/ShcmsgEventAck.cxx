static char _ShcmsgEventAck_cxx_what[] = "@(#) ShcmsgEventAck.cxx 1.9 12/03/28 04:15:24";

/*
 *  Copyright (C) 2004 eFunds Corporation ("eFunds").  All Rights Reserved.     
 *  eFunds Canada Corporation is an authorized user.                            
 *                                                                              
 *  IST is a registered trademark of eFunds Corporation.  Other brand or        
 *  product names are trademarks or registered trademarks of their respective   
 *  holders.                                                                    
 *                                                                              
 *  The information contained herein is the unpublished proprietary property    
 *  of eFunds.  Except as specifically authorized in writing by eFunds, the     
 *  holder of this document shall: i) keep all information contained herein     
 *  confidential, and ii) protect the information, in whole or in part, from    
 *  disclosure and dissemination to all third parties.                          
 *                                                                          
 *  This document and the software described in it are furnished under license  
 *  and may be used or copied only in accordance with the terms of such license.
 *  This document is supplied for information purposes only, is subject to      
 *  change without notice, and should not be construed as a commitment by       
 *  either eFunds Corporation or eFunds Canada Corporation. 
 *
 *
 *
 *                        MODIFICATION HISTORY                  REVIEW
 *
 *	SPR#	Who	Date	Description			Who	Date   
 * ===========================================================================
 * R0xxxxx jyang 09Dec03 Created
 * R018276 pve	 27Nov06 Add new OTraceLog messages 
 * R028271 dipa  18Jun10 Txn Statistics 
 * R030381 dipa  02Mar12 Txn Statistics 
 */

//File Number 92
#include <ShcmsgEventAck.h>
#include <ShcApp.h>
#include <ShcBin.h>
#include <ShcmsgTxnHelper.h>

//R028271 >>>
#include <TxnStat.h>
//<<< R028271

int ShcmsgEventAck::enrich()
{
	shcBin = header->issShcBin;
	tm_dequeue(header->eventId);
	header->eventId = -1;
	return 0;
}

int ShcmsgEventAck::doWork()
{
	/*	waiting for a device to ACK: but we did not get it */
	/* 961115 drop message (issuer-specified) */
	if( !shcmsgHeaderAcqTOGenRev( header ) )
	{
		header->msg.respcode = SHC_RC_DeviceTimeOut;
		header->msg.revcode  = SHC_RR_HardwareError;
		header->msg.msgtype = SHC_DEVICE_NAK;
////////		shc_device_nak(header);
		if ( thisShcApp->shcmsgTxnHelperObj->enqueueInternalMsg( header ) == NULL )
			OTraceError("E-SHC-092001: Unable to enqueueInternalMsg() in ShcmsgEventAck::doWork()\n");;
	}
	else
	{
		/*OTraceInfo( "I-SHC-092002:no-reversal (issuer:%s), dropping msg (trace:%l)\n",
			header->msg.issuer, header->msg.trace );*/
		//      >>>     R018276
		OTraceLog("L-SHC-092002: No reversal Drop message ID[%s]/m%04d/t%06ld/p%06ld\n", header->msg.shclog_id,
			header->msg.msgtype, header->msg.trace, header->msg.pcode);
		//	<<<     R018276

		//R028271 >>>
		TxnStatReport(header->msg.shclog_id,TS_SHC,TSR_DROP,DROP_DEVACK_NOT_RECEIVED,0,0);
		//<<< R028271
	}

	header->shcerr = SH_IGNORE;

	return 0;
}
