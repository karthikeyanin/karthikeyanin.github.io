/*
 *	CUSC and CUSC/Share are registered trademarks of Oasis Technology Ltd.
 *
 *	Copyright (C) 1990 - 2003 Oasis Technology Ltd.
 *	All Rights Reserved
 *	This Module contains Proprietary Information of
 *	Oasis Technology Ltd., and should be treated as Confidential.
 *
 *	THIS IS UNPUBLISHED PROPRIETARY SOURCE CODE OF OASIS TECHNOLOGY LTD.
 *	The copyright notice above does not evidence any  
 *	actual or intended publication of such source code.
 *
 *                        MODIFICATION HCUSCORY                  REVIEW
 *
 *	SCR#	Who		Date	Description			Who	Date   
 * ===========================================================================
 *   		mwang 	03Mar04 Created for CUSC offline accumulator
 *  R024824 uhb 	26Sep08 outdated macro "shcLocateSegmentStart" is replaced with shcmsgLocateSegmentStart
 *  R025286	Sel		13Nov08 log 430 msg in shclog when late response server is used	
 *	R025325	Sel	 	18Nov08	use dbm_rewind after dbm_commit	
 *	R025643	sel		27Feb09	dbm_commit and dbm_rewind cannot be called within write_saf function		
 *  R026229 Ash     03Apr09 Load all institution level parameters
 *  R027905 Dipa	25Mar10 Reversal-Void Enhancement
 *  R031339 Dipa	07Mar13	Clone of SPR2025270-R028581 - Exit ShcLateRev when DB disconnects
 */

static const char* _ShcLateRev_cxx_what = "@(#) ShcLateRev.cxx 1.14.4.2 20/02/14 07:22:53";

/* File Number 164 */
#include <stdio.h>
#include <string.h>
#include <dbm.h>
#include <shc.h>
#include <shcseg.h>
#include <ist_otrace.h>
#include <ShcLateRev.h>
#include <revlog.h>
#include <ShcApp.h>
#include <lateresplog.h>
#include <ShcmsgHeader.h>
#include <ShcmsgHelper.h>
#include <ShcSafIOHelper.h>
#include <ic/ic_instid.h>
#include <ShcmsgTxnHelper.h>        //  --- R026229
#include <ShcRevReqHelper.h>

#include <DBM3.h> //R028581
#include <dbm_private.h> //R028581
#include <HaPtmCctHelper.h>
#include <istsafe.h>
#include <DBMWrapper.hxx>
#include <TxnStatSource.h>
#include <TxnStatReason.h>
#include <TxnStat.h>
#include <ist_seg_elf_id_map.h>
#include <ist_seg_id.h>


#define LATEREV_NOORIG_INSERT	1
#define LATEREV_NOORIG_DROP		2
#define LATEREV_NOORIG_DENY		3

void checkDbConn(); //R028581
int doDbCommit(); //R028581

DBMConn* dbConnLRS = NULL;

void handleDBMException(DBMConn* conObj, DBMStmt* stmt, const DBMException& e );

/**
 * Constructor
 */
ShcLateRev::ShcLateRev()
{
	OTraceDebug("D-SHC-164001: Constructor\n");
	_dbConn = NULL;
	_updateRevlogStatus = NULL;
	_updateLateRespLogStatus = NULL;
	_countRevlogStatus = NULL;
	_listRevlog = NULL;
	_listallRevlog = NULL;

	opendb();

}

/**
 * Destructor
 */
ShcLateRev::~ShcLateRev()
{
	OTraceDebug( "I-SHC-164002: Destructor\n");
	dbm_close_all(getpid());
}

int ShcLateRev::rev_request(ShcmsgHeader *header)
{
	int ret = 0;
	OTraceInfo("I-SHC-164003: %d process Start\n",header->msg.msgtype); //R027905
		OTraceInfo("I-SHC-164004: Open Database OK1-fd[%d]\n",laterev_fd);

	m_shcmsg = &header->msg;
		OTraceInfo("I-SHC-164004: Open Database OK2-fd[%d]\n",laterev_fd);
	ret = checkdb210();
	if(ret == 1)
	{
		// write saf directly
		OTraceInfo("I-SHC-164003a:approved late 0210/0110 \n");
		if(write_saf(header))
		{
			updateLateRespLogStatus('D');
		    doDbCommit();
		}
		
	}
	else if(ret == 2)
	{
		OTraceInfo("I-SHC-164003b:denied late 0210/0110 \n");
		updateLateRespLogStatus('D');
	    doDbCommit();
	}
	else if (ret == 0)
	{
		// R027905 >>>
		if (header->msg.msgtype == SHC_AUTHREQ)
			header->msg.msgtype = SHC_REVREQ;
		if (header->msg.msgtype == SHC_FINREQ)
			header->msg.msgtype = SHC_REVREQ_ADVICE;
		// <<< R027905
		ret =  insert_rev(header);
	}
	return ret;

}

int ShcLateRev::queryAndUpdateCounter(ShcmsgHeader *header)
{
	thisShcApp->shcmsgTxnHelperObj->setParamSet(header);   
	int counterCfg = thisShcApp->acquirerShcParamsList->GetNum((char *)"shc.drop_420NoOrigCounter");
	if (counterCfg <= 0)
		return LATEREV_NOORIG_INSERT;
	
	static int initialized = -1;
	static DBMStmt *selBrowse = NULL;
	static DBMStmt *upd = NULL;
	static DBMString logId(24);
	static DBMInt counter;
	static date_t localDate;
	static DBMInt localTime;
	static DBMInt trace;
	static DBMPanToken pan(24);
	static DBMString termId(24);
	static DBMInt pcode;
	int i=0;
	static char *sqlStmt = (char *) "SELECT counter,shclog_id from revlog where local_date = ? and pan = ? "
		" and trace = ? and local_time = ? and termid = ? and pcode = ?";
	static char *sqlUpdStmt = (char *) "UPDATE revlog set counter = ? where shclog_id  = ? ";
	int ret=LATEREV_NOORIG_INSERT;

	try
	{
		if (initialized < 0)
		{
			dbm_connect();
			if (!dbConnLRS)
				dbConnLRS = new DBMConn(dbm_dbconn);
			selBrowse = dbConnLRS->getStmt();
			upd = dbConnLRS->getStmt();
        	selBrowse->prepare(sqlStmt);
			upd->prepare(sqlUpdStmt);

			i=1;
       		selBrowse->bindParam( i++, DBM_DATETYPE, &localDate, sizeof(localDate), 0);
       		selBrowse->bindParam( i++, pan);
       		selBrowse->bindParam( i++, trace);
       		selBrowse->bindParam( i++, localTime);
       		selBrowse->bindParam( i++, termId);
       		selBrowse->bindParam( i++, pcode);
       		selBrowse->bindCol( 1, counter);
       		selBrowse->bindCol( 2, logId);

			upd->bindParam(1, counter);
			upd->bindParam(2, logId);
			initialized = 1;
		}



			
	
		localDate = header->msg.local_date;
		pan.setValue((OCString)header->msg.pan);
		trace.setValue(header->msg.trace);
		localTime.setValue(header->msg.local_time);
		termId.setValue((OCString)header->msg.termid);
		pcode.setValue(header->msg.pcode);

		selBrowse->execute();
		
		int retFetch=selBrowse->fetch();
		if (retFetch != DBM_SUCCESS && retFetch != DBM_SUCCESS_WITH_INFO)
		{
			OTraceInfo("I-SHCLRS-0014:Can't find an existing record, insert.\n");
			goto ret;
		}
	
		if ((long)counter >= counterCfg)
		{
			ret = LATEREV_NOORIG_DENY;
			goto ret;
		}


		long tmpCounter = (long)counter;
		tmpCounter++;
		counter.setValue(tmpCounter);

	
		upd->execute();
		selBrowse->close();
		upd->close();
		ret = LATEREV_NOORIG_DROP;
	}
	catch(const DBMException & e) 
	{
		OTraceError
			(
		 	"E-SHCLRS-0010:caught exception db operation, "
		 	"native error=%d, sqlstate=%.5s, msg=%s\n",
		 	e.getNativeError(), e.getSQLState().data(), e.getErrMsg().data()
			);
	}
	catch(...)
	{
		OTraceError("E-SHCLRS-0011:Error in executing DB statement.\n");
	}

ret:
	if (selBrowse)
		selBrowse->close();
	if (upd)
		upd->close();
	
	return ret;
}

int ShcLateRev::denyRevNoOrig(ShcmsgHeader *header)
{
    if (shcmid < 0)
        shcmid = mb_locatemailbox(SHC_SERVER_NAME);

	static int lSegMRId = ElfIdMap::elf_to_id(IST_SEG_MSG_REPLICATION_DATA);

	//Do not replicate the denied reversal
	IstSegList *segList = header->getSegList();
	if (segList)
		segList->deleteSegItem(lSegMRId);

	header->msg.msgtype = header->msg.msgtype%1000;
	shcApp->shcmsgHelperObj->shc_set_return_msgno(&header->msg);
	header->msg.respcode = SHC_RC_NoOriginal;
	if(mb_write(header->msg.senderid,shcmid, &header->msg, header->truelength())<0)
	{
		OTraceError("E-SHCLRS-0012:Unable to respond to  %d id[%s].\n", header->msg.senderid, header->msg.shclog_id);
		TxnStatReport(header->msg.shclog_id,TS_SHC,TSR_DROP,0,0,0);
		return -1;
	}
	else
	{
		OTraceLog("L-SHCLRS-0013:Denied the reversal respcode[%d], id[%s].\n", header->msg.respcode, header->msg.shclog_id);
		TxnStatReport(header->msg.shclog_id,TS_SHC,TSR_SEND,0,0,0);
	}
	thisShcApp->shcmsgLogObj->logTxn(header);
	return 0;
}

int ShcLateRev::rev_nooriginal(ShcmsgHeader *header)
{
	int ret = 0;
	OTraceInfo("I-SHCLRS-17000:rev_nooriginal  %d\n",header->msg.msgtype); 

	int counterRet = queryAndUpdateCounter(header);
	if (counterRet == LATEREV_NOORIG_DROP)
	{
		TxnStatReport(header->msg.shclog_id,TS_SHC,TSR_DROP,0,0,0);
		OTraceLog("L-SHC-9816: Drop message because < shc.drop_420NoOrigCounter [%s]/m%04d/t%06ld/p%06ld\n", header->msg.shclog_id,
            header->msg.msgtype, header->msg.trace, header->msg.pcode);
		return 0;
	}
	else if (counterRet == LATEREV_NOORIG_DENY)
	{
		denyRevNoOrig(header);
		return 0;
	}
	m_shcmsg = &header->msg;
	ret =  insert_rev(header);
	
	return ret;

}

int ShcLateRev::checkForOrig(int site_id, char *logid)
{
	ShcmsgHeader header;
	struct revlog rev_log;
	struct  shcseg  *seg=0;
	int 	seglength;
	int ret = 0;
	char  sqlstmt[1024];

	// First read from  revlog where  status  = 'U'
	memset((char *)&rev_log, 0, sizeof(struct revlog));

	rev_log.segdata = malloc(SHCSEG_MAX_SEGMENT);
	memset(rev_log.segdata,0,SHCSEG_MAX_SEGMENT);

	if (logid == NULL)
	{
		if (mbIsDualSite())
			snprintf(sqlstmt, sizeof(sqlstmt), "site_id = %d AND (status  = 'U' OR status = 'W')", mbGetSiteId());
		else
			sprintf(sqlstmt, "site_id = %d AND (status  = 'U' OR status = 'W')", mbGetSiteId());
	}
	else
	{
		snprintf(sqlstmt, sizeof(sqlstmt),"site_id = %d AND shclog_id = '%s' AND (status  = 'U' OR status  = 'S' OR status = 'W')", site_id, logid);
	}

	OTraceDebug("D-SHCLRS-17001:Select * from revlog where %s\n", sqlstmt);

	ret = dbm_selectfd_raw(laterev_fd, sqlstmt, NULL, 0, (char *)rev_log.segdata,10240);

    while(dbm_fetchfd (laterev_fd, (char *)&rev_log) == 0)
	{
		OTraceInfo("I-SHCLRS-17001:Found [%s], status[%c]\n", rev_log.shclog_id, rev_log.status);
		header.reset();
		restoreReversal(&header, &rev_log);
		header.shcLogObj = thisShcApp->shcmsgLogObj;

		//  could inmprove this check for response only

		thisShcApp->shcmsgTxnHelperObj->setParamSet(&header);
		if (rev_log.status == 'U')
		{
			if(thisShcApp->shcmsgHelperObj->locateOrigTxn(&header) < 0)
			{
				OTraceInfo("I-SHCLRS-17002:Not found[%s]\n", rev_log.shclog_id);
				revCheckskip(&rev_log);
			}
			else
			{
				OTraceInfo("I-SHCLRS-17003:found[%s]\n", rev_log.shclog_id);
				checkOriginal(&header, &rev_log);
			}
		}
		else if (rev_log.status == 'W')
		{
			int ret = 0;
			char buf = '\0';
			OTraceInfo("I-SHC-164039: %d process Start\n",header.msg.msgtype); //R027905

			m_shcmsg = &header.msg;
			ret = checkdb210();
			if(ret == 1)
			{
				buf = '1';
				// write saf directly
				header.msg.serial_1 |= 0x400000;
				header.setSegmentData((char*)&buf, 1, NETWORK_DATA_REQ_id, SHC_LATE_REV);
				OTraceInfo("I-SHC-164040:approved late 0210/0110 \n");
				if(write_saf(&header))
				{
					updateLateRespLogStatus('D');
					updateRevLogStatus(&rev_log, 'D');
		    		doDbCommit();
				}
				
			}
			else if(ret == 2)
			{
				OTraceInfo("I-SHC-164041:denied late 0210/0110 \n");
				updateLateRespLogStatus('D');
	    		doDbCommit();
			}
			else if (ret == 0)
			{
				//Do nothing, the reversal is in db already
			}
		}
	}

	free(rev_log.segdata);

	return (1);

}

int ShcLateRev::checkOriginal(ShcmsgHeader *header, struct revlog *rev_log)
{
	struct ShcmsgWithSegment tmpMsg;

	if (!header->origMsg)
	{
		return -1;
	}

	//Check  if original was already reversed
	if(header->origMsg->shcerror == SHC_IE_Reversed)
	{
		
		OTraceInfo("I-SHCLRS-17004:Original Already reversed\n");
		updateRevLogStatus(rev_log, 'D');
		doDbCommit();
		return 1;
	}

	if ((shcmsgIsResponse(header->origMsg)) &&
				(header->origMsg->respcode != SHC_RC_Approved)  &&
				(header->origMsg->respcode != SHC_RC_DeviceTimeOut) &&
				(header->origMsg->respcode != SHC_RC_IssuerTimeout) &&
				(header->origMsg->respcode != SHC_RC_ShcTimeout) &&
				(header->origMsg->respcode != SHC_RC_PurchaseAmountOnly))
	{
		
		OTraceInfo("I-SHCLRS-17005:Original Not Approved\n");
		updateRevLogStatus(rev_log, 'D');
		doDbCommit();
		return 1;
	}

	if (!shcmsgIsResponse(header->origMsg))
	{
		 OTraceInfo("I-SHCLRS-17006:Original is not response ignore for now\n");
		 return 1;
	}
    
	thisShcApp->shcmsgHelperObj->shcGetIssAcq(header, 0);

	if (header->setIssShcBin( header->msg.issuer) < 0 )
		OTraceError("E-SHC-1640037: Can not locate issuer[%s] \n", header->msg.issuer);

    if (header->setAcqShcBin(header->msg.acquirer) < 0 )
		OTraceError("E-SHC-1640038: Can not locate acquirer<%s>.\n", header->msg.acquirer);

	// Restore From original
	thisShcApp->shcmsgHelperObj->shc_restoreOriginal(header);

	// Update the Original message
	thisShcApp->shcRevReqHelperObj->updateOriginal(header);

	memcpy(&tmpMsg.msg, &header->msg, sizeof(tmpMsg));
	memcpy(&header->msg, header->origMsg, sizeof(tmpMsg));


	// Update Original in database
	((ShcLog *)header->shcLogObj)->doUpdateReversal(header);

	memcpy(&header->msg, &tmpMsg.msg, sizeof(tmpMsg));

	thisShcApp->shcmsgTxnHelperObj->setParamSet(header);    //  --- R026229
	thisShcApp->shcSafIOHelperObj->shc_saf_write_transaction(header);

	updateRevLogStatus(rev_log, 'D');
	doDbCommit();

	return 1;
}



int ShcLateRev::revCheckskip(struct revlog *rev_log)
{
	// function check if skip time has expired
	static int  skip_time = -1;

	if (skip_time == -1)
	{
		HaPtmCctHelper::addHandler( "system.dcs.shc" ) ;

		if (cf_open(u_constructfile("files/shc.cfg")) >= 0)
		{
			char buf[1024];
			memset(buf, 0, sizeof(buf));

		 	if ( cf_locate("shc.holdRevExpireTime", buf) > 0)
			{
				skip_time = atoi(buf);
				skip_time *= 60;
			}
		    cf_close();
		 }

		if (skip_time < 0)
		{
			skip_time = 3600; 

		}
		OTraceInfo("I-SHCLRS-17007:Skip Time mins[%d]\n", skip_time/60);
	}

	time_t curr_time = time(NULL);
	if ((curr_time - rev_log->sys_dt_time) > skip_time)
	{
		OTraceInfo("I-SHCLRS-17008:MarkSkipped[%s][%d][%d][%d]\n", rev_log->shclog_id, curr_time, rev_log->sys_dt_time, skip_time);
		updateRevLogStatus(rev_log, 'S');
		doDbCommit();
	}
		
	return 1;

}

int ShcLateRev::prepareUpdateRevlogStatus()
{
	
	if (!_updateRevlogStatus)
	{
		int i = 1;;
		_updateRevlogStatus = _dbConn->getStmt();

		try
		{
			_updateRevlogStatus->prepare ("update revlog set status = ? where site_id = ? AND shclog_id = ?");

			_updateRevlogStatus->bindParam(i++, DBM_CHARTYPE, &_revlog.status, sizeof(_revlog.status), NULL);

			_updateRevlogStatus->bindParam(i++, DBM_INTTYPE, &_revlog.site_id, sizeof(_revlog.site_id), NULL);
			_updateRevlogStatus->bindParam(i++, DBM_STRINGTYPE, _revlog.shclog_id, sizeof(_revlog.shclog_id), NULL);
		}

		catch( const DBMException& e )
		{
			handleDBMException( _dbConn, _updateRevlogStatus, e );
		 	OTraceError
			(
			     "E-SHCLRS-5128:caught exception in prepare update revlog status "
						 "native error=%d, sqlstate=%.5s, msg=%s\n",
						 e.getNativeError(), e.getSQLState().data(), e.getErrMsg().data()
			);
			return -1;
		}
	}

	return 1;
}


int ShcLateRev::updateRevLogStatus(struct revlog *rev_log, char newstatus)
{

	if (prepareUpdateRevlogStatus() < 0)
	{
		return -1;
	}

	memset (&_revlog, 0, sizeof(struct revlog));

	_revlog.status = newstatus;

	_revlog.site_id = rev_log->site_id;
	strcpy(_revlog.shclog_id, rev_log->shclog_id);


 	try
	{
		 _updateRevlogStatus->execute();
		 _updateRevlogStatus->close();
	}
	catch( const DBMException& e )
	{
		handleDBMException( _dbConn, _updateRevlogStatus, e );
		OTraceError
		(
			"E-SHCLRS:caught exception in update revlog"
			"native error=%d, sqlstate=%.5s, msg=%s\n",
			e.getNativeError(), e.getSQLState().data(), e.getErrMsg().data()
		);
		return -1;
	}

	return 1;

}

int ShcLateRev::prepareUpdateLateRespLogStatus()
{
	
	if (!_updateLateRespLogStatus)
	{
		int i = 1;;
		_updateLateRespLogStatus = _dbConn->getStmt();

		try
		{
			_updateLateRespLogStatus->prepare ("update lateresplog set status = ? where site_id = ? AND log_id = ?");

			_updateLateRespLogStatus->bindParam(i++, DBM_CHARTYPE, &_late210log.status, sizeof(_late210log.status), NULL);

			_updateLateRespLogStatus->bindParam(i++, DBM_INTTYPE, &_late210log.site_id, sizeof(_late210log.site_id), NULL);
			_updateLateRespLogStatus->bindParam(i++, DBM_STRINGTYPE, _late210log.log_id, sizeof(_late210log.log_id), NULL);
		}

		catch( const DBMException& e )
		{
			handleDBMException( _dbConn, _updateLateRespLogStatus, e );
		 	OTraceError
			(
			     "E-SHCLRS-5128:caught exception in prepare update lateresplog status "
						 "native error=%d, sqlstate=%.5s, msg=%s\n",
						 e.getNativeError(), e.getSQLState().data(), e.getErrMsg().data()
			);
			return -1;
		}
	}

	return 1;
}

int ShcLateRev::updateLateRespLogStatus(char newstatus)
{

	if (prepareUpdateLateRespLogStatus() < 0)
	{
		return -1;
	}

	_late210log.status = newstatus;

 	try
	{
		 _updateLateRespLogStatus->execute();
		 _updateLateRespLogStatus->close();
	}
	catch( const DBMException& e )
	{
		handleDBMException( _dbConn, _updateLateRespLogStatus, e );
		OTraceError
		(
			"E-SHCLRS:caught exception in update revlog"
			"native error=%d, sqlstate=%.5s, msg=%s\n",
			e.getNativeError(), e.getSQLState().data(), e.getErrMsg().data()
		);
		return -1;
	}

	return 1;

}

int ShcLateRev::restoreReversal(ShcmsgHeader *header, struct revlog *rev_log)
{
	struct  shcseg  *seg=0;

	header->msg.msgtype = rev_log->msgtype;
	strcpy(header->msg.pan, rev_log->pan);
	header->msg.pcode = rev_log->pcode; 

	header->msg.trace = rev_log->trace;

	header->msg.local_date = rev_log->local_date;
	header->msg.cap_date =  rev_log->cap_date;
	header->msg.local_time =  rev_log->local_time;
	strcpy(header->msg.termid,  rev_log->termid);
	strcpy(header->msg.termloc,  rev_log->termloc);

	strcpy(header->msg.acquirer,  rev_log->acquirer);
	strcpy(header->msg.issuer,  rev_log->issuer);
	ICInstId_pure(header->msg.txnSrc,  rev_log->txnsrc);
	ICInstId_pure(header->msg.txnDest,  rev_log->txndest);
	strcpy(header->msg.alternateAcquirer,  rev_log->alternateacquirer);

	strcpy(header->msg.entityId,  rev_log->entityid);
	strcpy(header->msg.iss_entityId,  rev_log->issentityid);
	strcpy(header->msg.cardProduct,  rev_log->cardproduct);
	strcpy(header->msg.member_ID,  rev_log->member_id);

	strcpy(header->msg.F_ID,  rev_log->f_id);

	header->msg.device_devcap =  rev_log->device_devcap;
	header->msg.device_cap =  rev_log->device_cap;
	header->msg.formatter_devcap =  rev_log->formatter_devcap;
	header->msg.shc_devcap =  rev_log->shc_devcap;
	header->msg.auth_devcap =  rev_log->auth_devcap;

	header->msg.pos_condition_code =  rev_log->pos_condition_code;
	header->msg.pos_pin_cap_code =  rev_log->pos_pin_cap_code;
	header->msg.pos_cap_code =  rev_log->pos_cap_code;
	header->msg.merchant_type =  rev_log->merchant_type;
	header->msg.iss_currency_code =  rev_log->iss_currency_code;
	strcpy(header->msg.shclog_id,  rev_log->shclog_id);

	
	memcpy(header->msg.filler1,  rev_log->filler1, sizeof( rev_log->filler1));
	memcpy(header->msg.filler2,  rev_log->filler2, sizeof( rev_log->filler2));
	memcpy(header->msg.filler3,  rev_log->filler3, sizeof( rev_log->filler3));
	//memcpy(header->msg.filler4,  rev_log->filler4, sizeof( rev_log->filler4));
	memcpy(header->msg.refnum, rev_log->filler4, sizeof(header->msg.refnum));
	memcpy(header->msg.acceptorname, rev_log->acceptorname, sizeof(rev_log->acceptorname));
	header->msg.site_id =  rev_log->site_id;

	if (shcHasSegment(header))
	{
		seg = shcmsgLocateSegmentStart(&header->msg);
		memcpy((char *)seg, rev_log->segdata,rev_log->segsize);
	}		
	return 1;
}


int ShcLateRev::fin_request(ShcmsgHeader *header)
{
	int ret = 0;
	char    *bin;

	struct  shcpkg *pkg;

    struct revlog rev_log;

	memset((char *)&rev_log, 0, sizeof(struct revlog));

	rev_log.segdata = malloc(SHCSEG_MAX_SEGMENT);
	memset(rev_log.segdata,0,SHCSEG_MAX_SEGMENT);

	OTraceInfo("I-SHC-164007: MBank late 110/210 process Start\n");

	m_shcmsg = &header->msg;

	// check if it's late response
	if (checkdbrec(&rev_log))
	{
		if (generate_revreq(header, &rev_log))
		{
			updateRevLogStatus(&rev_log, 'D');
			doDbCommit();
		}
	}
	else
	{
		// mwang fix on 04May04: we need to match the criterias for 0420 
		// generated by SHC.
		bin = header->msg.issuer;
		if(shc_locate_bin(&pkg, bin) == -1)
    	{
        	OTraceDebug("Unable to find message port for <%s>\n", bin);
        	return(-1);
    	}
		if(	(pkg->bin.flags & SH_SENDREV_ALWAYS)
			&& (!(header->msg.txntype & (SH_TX_AUTHENTICATE|SH_TX_BAL))))
			insert_210();
		else
        	OTraceDebug("No need to insert this %d message into Log.\n",header->msg.msgtype); 
			
	}

	if (rev_log.segdata)
		free(rev_log.segdata);

	OTraceInfo("I-SHC-164008: 110/210 process end\n");
	return ret;
}


int ShcLateRev::opendb(void)
{
	int ret = 0;

	laterev_fd = ist_dbm_open(dbm_getfirstindex("revlog"), getpid());

	if(laterev_fd < 0 )
	{
		OTraceError("E-SHC-164001: Open revlog Database Failed\n");
		ret = -1;
	}
	else
		OTraceInfo("I-SHC-164004: Open revlog Database OK-fd[%d]\n",laterev_fd);

	late210_fd = ist_dbm_open(dbm_getfirstindex("lateresplog"), getpid());

	if(late210_fd < 0 )
	{
		OTraceError("E-SHC-164001a: Open lateresplog Database Failed\n");
		ret = -1;
	}
	else
		OTraceInfo("I-SHC-164004a: Open lateresplog Database OK-fd[%d]\n",late210_fd);

	if(!_dbConn)
		 _dbConn= new DBMConn(dbm_dbconn);

	return ret;
}

int ShcLateRev::checkdbrec(struct revlog *rev_log)
{

	int ret = 0;


	rev_log->pcode = m_shcmsg->pcode;
	rev_log->trace = m_shcmsg->trace;
	rev_log->local_date = m_shcmsg->local_date;
	rev_log->local_time = m_shcmsg->local_time;
	strcpy(rev_log->pan, m_shcmsg->pan);
	strncpy(rev_log->termid, m_shcmsg->termid, 8 );
	OTraceInfo("I-SHC-1640111:Key for searching pcode[%d]=trace[%d]=local_date[%d]=local_time[%d]=pan[%s]=termid[%s]\n",
	 rev_log->pcode,rev_log->trace,rev_log->local_date,rev_log->local_time,shc_maskpan(rev_log->pan),rev_log->termid);

	if (!rev_log->segdata)
		rev_log->segdata = malloc(SHCSEG_MAX_SEGMENT);

	memset(rev_log->segdata,0,SHCSEG_MAX_SEGMENT);
	if(dbm_read_raw(laterev_fd, (char *)rev_log, (char *)rev_log->segdata,10240,DBM_RLOCK|DBM_REQUAL) <0)
	{
		checkDbConn(); //R028581
		OTraceInfo("I-SHC-1640016: Matched 420 has not come. err:%d \n", dbm_errno);
		ret = 0;
	}
	else
	{
		OTraceInfo("I-SHC-1640019: It's a matched late response\n");
		ret = 1;
	}

	return ret;
}

int ShcLateRev::checkdb210(void)
{

	int ret = 0;

	memset((char *)&_late210log, 0, sizeof(struct lateresplog));

	_late210log.pcode = m_shcmsg->pcode;
	_late210log.trace = m_shcmsg->trace;
	_late210log.local_date = m_shcmsg->local_date;
	_late210log.local_time = m_shcmsg->local_time;
	_late210log.trandate = m_shcmsg->trandate;
	_late210log.trantime = m_shcmsg->trantime;
	strcpy(_late210log.pan, m_shcmsg->pan);
	strncpy(_late210log.termid, m_shcmsg->termid, 8 );

	_late210log.status = 'W';

	OTraceInfo("I-SHC-1640100:Key for searching pcode[%d]=trace[%d]=local_date[%d]=local_time[%d]=pan[%s]=termid[%s]\n",
	 m_shcmsg->pcode,m_shcmsg->trace,m_shcmsg->local_date,m_shcmsg->local_time,shc_maskpan(m_shcmsg->pan),m_shcmsg->termid);

	if(dbm_read(late210_fd, (char *)&_late210log,DBM_RLOCK|DBM_REQUAL) <0)
	{
		checkDbConn(); //R028581
		OTraceInfo("I-SHC-1640016: Late %d has not come. err:%d \n", m_shcmsg->msgtype,dbm_errno);
		ret = 0;
	}
	else
	{
		OTraceInfo("I-SHC-1640019: It's a matched late reversal[%d]\n",_late210log.respcode);
		if(_late210log.authnum[0]!='\0')
			istsafe_strcpy(m_shcmsg->authnum, sizeof(m_shcmsg->authnum), _late210log.authnum);
		// mwang May1904: fix for SPR2018745 add 68 as approved.
		if(_late210log.respcode == 0 || _late210log.respcode == SHC_RC_LateResponse)
			ret = 1;
		else 
			ret = 2;
	}


	return ret;
}

int ShcLateRev::insert_rev(ShcmsgHeader *shcP)
{
	struct revlog rev_log;
	struct  shcseg  *seg=0;
	int 	seglength;

	int ret = 0;
		OTraceInfo("I-SHC-164004: Open Database OK3-fd[%d]\n",laterev_fd);

	memset((char *)&rev_log, 0, sizeof(struct revlog));

	// set date time
	time_t curr_time = time(NULL);
	rev_log.sys_dt_time = curr_time;
	if (m_shcmsg->msgtype == (SHC_REVREQ_ADVICE + 1000) || m_shcmsg->msgtype == (SHC_REVREQ + 1000))
	{
		m_shcmsg->msgtype -= 1000;
		rev_log.status = 'U';
	}
	else
	{
		rev_log.status = 'W';
	}

	rev_log.msgtype = m_shcmsg->msgtype;
	strcpy(rev_log.pan, m_shcmsg->pan);
	rev_log.pcode = m_shcmsg->pcode;

	//if(shcP->isVoidTxn()) //R027905
	if(shcP->msg.origtrace>0)       //      ---     IST_S770SP2-2 Use origtrace
		rev_log.trace = shcP->msg.origtrace;
	else
		rev_log.trace = m_shcmsg->trace;

	rev_log.local_date = m_shcmsg->local_date;
	rev_log.cap_date = m_shcmsg->cap_date;
	rev_log.local_time = m_shcmsg->local_time;
	strcpy(rev_log.termid, m_shcmsg->termid);
	strcpy(rev_log.termloc, m_shcmsg->termloc);

	strcpy(rev_log.acquirer, m_shcmsg->acquirer);
	strcpy(rev_log.issuer, m_shcmsg->issuer);
	strcpy(rev_log.txnsrc, m_shcmsg->txnSrc);
	strcpy(rev_log.txndest, m_shcmsg->txnDest);
	strcpy(rev_log.alternateacquirer, m_shcmsg->alternateAcquirer);

	strcpy(rev_log.entityid, m_shcmsg->entityId);
	strcpy(rev_log.issentityid, m_shcmsg->iss_entityId);
	strcpy(rev_log.cardproduct, m_shcmsg->cardProduct);
	strcpy(rev_log.member_id, m_shcmsg->member_ID);
	strcpy(rev_log.f_id, m_shcmsg->F_ID);

	rev_log.device_devcap = m_shcmsg->device_devcap;
	rev_log.device_cap = m_shcmsg->device_cap;
	rev_log.formatter_devcap = m_shcmsg->formatter_devcap;
	rev_log.shc_devcap = m_shcmsg->shc_devcap;
	rev_log.auth_devcap = m_shcmsg->auth_devcap;

	rev_log.pos_condition_code = m_shcmsg->pos_condition_code;
	rev_log.pos_pin_cap_code = m_shcmsg->pos_pin_cap_code;
	rev_log.pos_cap_code = m_shcmsg->pos_cap_code;
	rev_log.merchant_type = m_shcmsg->merchant_type;
	rev_log.iss_currency_code = m_shcmsg->iss_currency_code;
	strcpy(rev_log.shclog_id, m_shcmsg->shclog_id);

	
	memcpy(rev_log.filler1, m_shcmsg->filler1, sizeof(m_shcmsg->filler1));
	memcpy(rev_log.filler2, m_shcmsg->filler2, sizeof(m_shcmsg->filler2));
	memcpy(rev_log.filler3, m_shcmsg->filler3, sizeof(m_shcmsg->filler3));
	//memcpy(rev_log.filler4, m_shcmsg->filler4, sizeof(m_shcmsg->filler4));
	memcpy(rev_log.filler4, m_shcmsg->refnum, sizeof(m_shcmsg->refnum));
	memcpy(rev_log.authnum, m_shcmsg->authnum, sizeof(m_shcmsg->authnum));
	memcpy(rev_log.acceptorname, m_shcmsg->acceptorname, sizeof(m_shcmsg->acceptorname));
	rev_log.site_id = mbGetSiteId();
	OTraceInfo("I-SHC-1640101:fd[%d].\n",laterev_fd);
	// process segment data
	if (shcHasSegment(shcP))
	{

		OTraceInfo("I-SHC-1640102:process segment data.\n");
		//	>>> R024824
		//seg = shcLocateSegmentStart(shcP);
		seg = shcmsgLocateSegmentStart(&shcP->msg);
		//	<<< R024824	 
		seglength = shc_seglength(seg);
		rev_log.segsize = seglength;
		OTraceInfo("I-SHC-1640103:process segment data[%d].\n",rev_log.segsize);
		if(seg != NULL)
		{
			OTraceInfo("I-SHC-1640104:[%s]-[%d].\n",seg,seglength);
			rev_log.segdata = malloc(seglength+1);
			memset(rev_log.segdata,0,seglength+1);
			memcpy(rev_log.segdata, (char *)seg, seglength);
			OTraceInfo("I-SHC-1640105:add segment data[%d].\n",seglength);
		}
		
	}



	OTraceInfo("I-SHC-1640106:fd[%d].\n",laterev_fd);
	if(dbm_insert_raw(laterev_fd, (char *)&rev_log,(char *)rev_log.segdata,seglength, 0) <0)
	{
		OTraceError("E-SHC-1640012: Insert new %d record failed\n",rev_log.msgtype);
		checkDbConn(); //R028581
		ret = -1;
	}
	else
	{
	OTraceInfo("I-SHC-1640107:Insert pcode[%d]=trace[%d]=local_date[%d]=local_time[%d]=pan[%s]=termid[%s]\n",
	 rev_log.pcode,rev_log.trace,rev_log.local_date,rev_log.local_time,shc_maskpan(rev_log.pan),rev_log.termid);
		OTraceInfo("I-SHC-1640021: Insert new %d record OK:cap_date[%d]\n",rev_log.msgtype,rev_log.cap_date);
		doDbCommit(); //R028581
		if ( laterev_fd >= 0)
		dbm_rewind(laterev_fd);
	}
	if(rev_log.segdata != NULL)
		free(rev_log.segdata); 

	return ret;
}

int ShcLateRev::insert_210(void)
{
    struct      lateresplog      late210_log;
    int ret = 0;

    memset((char *)&late210_log, 0, sizeof(struct lateresplog));
    late210_log.msgtype = m_shcmsg->msgtype;
    strcpy(late210_log.pan, m_shcmsg->pan);
    late210_log.pcode = m_shcmsg->pcode;
    late210_log.trace = m_shcmsg->trace;
    strcpy(late210_log.termid, m_shcmsg->termid);
    strcpy(late210_log.acquirer, m_shcmsg->acquirer);
    strcpy(late210_log.issuer, m_shcmsg->issuer);
    late210_log.local_time = m_shcmsg->local_time;
    late210_log.local_date = m_shcmsg->local_date;
    late210_log.trandate = m_shcmsg->trandate;
    late210_log.trantime = m_shcmsg->trantime;
    late210_log.respcode = m_shcmsg->respcode;
	istsafe_strcpy(late210_log.authnum, sizeof(late210_log.authnum),  m_shcmsg->authnum);
    strcpy(late210_log.log_id,  m_shcmsg->shclog_id);
    late210_log.site_id = mbGetSiteId();

	late210_log.status = 'W';
	time_t curr_time = time(NULL);
	late210_log.sys_dt_time = curr_time;


    if(dbm_insert(late210_fd, (char *)&late210_log, 0) <0)
    {
        OTraceError("E-SHC-1640012a: Insert new %d record failed\n",late210_log.msgtype);
		checkDbConn(); //R028581
        ret = -1;
	}
	else
    {
        OTraceInfo("I-SHC-1640108:Insert pcode[%d]=trace[%d]=local_date[%d]=local_time[%d]=pan[%s]=termid[%s]\n",
     late210_log.pcode,late210_log.trace,late210_log.local_date,late210_log.local_time,shc_maskpan(late210_log.pan),late210_log.termid);
        OTraceInfo("I-SHC-1640021a: Insert new %d record OK:date[%d]\n",late210_log.msgtype,late210_log.local_date);
		doDbCommit(); //R02858
		if ( late210_fd >= 0)
        dbm_rewind(late210_fd);
    }

    return ret;

}


int ShcLateRev::generate_revreq(ShcmsgHeader *header, struct revlog *rev_log)
{
	struct  shcseg  *seg = NULL;
	// if (header->msg.respcode != SHC_RC_Approved)
	// mwang 2004/05/04: fix for SPR 2018644.
	if (header->msg.respcode != SHC_RC_Approved && header->msg.respcode != SHC_RC_LateResponse) // SHC can update Approved to LateResponse
	// end of mwang 2004/05/04: fix for SPR 2018644.
	{	
		OTraceInfo("I-SHC-1640033: the late %d is not approved'rc:%d'.\n",
			header->msg.msgtype,header->msg.respcode);
		return 1;
	}

	OTraceInfo("I-SHC-1640035: Generate a reversal on late %d.\n",header->msg.msgtype);

	header->msg.origtrace = header->msg.trace;
	header->msg.origmsg = header->msg.msgtype - 10;

	header->msg.msgtype = SHC_REVREQ_ADVICE;
	header->msg.respcode = SHC_RC_IssuerTimeout;
	header->msg.revcode = SHC_RR_TimeOut;

	header->msg.origdate = header->msg.trandate;
	header->msg.origtime = header->msg.trantime;

	header->msg.serial_1 |= 0x200000;
	header->msg.device_cap = rev_log->device_cap;
	header->msg.device_cap |= SH_DEVCAP_INTERNALREV;

	strcpy(header->msg.cardProduct, rev_log->cardproduct);
	header->msg.cap_date = rev_log->cap_date;

	// restore the some original information	
	strcpy(header->msg.acquirer, rev_log->acquirer);
	strcpy(header->msg.issuer, rev_log->issuer);
	ICInstId_pure(header->msg.txnSrc, rev_log->txnsrc);
	ICInstId_pure(header->msg.txnDest, rev_log->txndest);
	strcpy(header->msg.alternateAcquirer, rev_log->alternateacquirer);

	strcpy(header->msg.entityId, rev_log->entityid);
	strcpy(header->msg.iss_entityId, rev_log->issentityid);
	strcpy(header->msg.cardProduct, rev_log->cardproduct);
	strcpy(header->msg.termloc, rev_log->termloc);

	strcpy(header->msg.member_ID, rev_log->member_id);
	strcpy(header->msg.F_ID, rev_log->f_id);
	memcpy(header->msg.filler1, rev_log->filler1, sizeof(rev_log->filler1));
	memcpy(header->msg.filler2, rev_log->filler2, sizeof(rev_log->filler2));
	memcpy(header->msg.filler3, rev_log->filler3, sizeof(rev_log->filler3));
	//memcpy(header->msg.filler4, rev_log->filler4, sizeof(rev_log->filler4));
	memcpy(header->msg.refnum, rev_log->filler4, sizeof(header->msg.refnum));

	header->msg.device_devcap = rev_log->device_devcap;
	header->msg.formatter_devcap = rev_log->formatter_devcap;
	header->msg.shc_devcap = rev_log->shc_devcap;
	header->msg.auth_devcap = rev_log->auth_devcap;

	header->msg.pos_condition_code = rev_log->pos_condition_code;
	header->msg.pos_pin_cap_code = rev_log->pos_pin_cap_code;
	header->msg.pos_cap_code = rev_log->pos_cap_code;

	header->msg.merchant_type = rev_log->merchant_type;

	header->msg.iss_currency_code = rev_log->iss_currency_code;
	memcpy(header->msg.acceptorname, rev_log->acceptorname, sizeof(rev_log->acceptorname));

	// process segment data
	if (shcHasSegment(header))
	{

		OTraceInfo("I-SHC-1640109:process segment data.\n");
		//	>>>	R024824
		//seg = shcLocateSegmentStart(header);
		seg = shcmsgLocateSegmentStart(&header->msg);
		//	>>>	R024824
		memcpy((char *)seg, rev_log->segdata,rev_log->segsize);
		OTraceInfo("I-SHC-1640110: build segment data[%d].\n",
						rev_log->segsize);
		
	}

//	header->shcLogObj = thisShcApp->shcmsgLogObj;	//	---	R025286
	memset(header->msg.alpha_response_code, 0, sizeof(3));
	strcpy(header->msg.shclog_id, rev_log->shclog_id);
	write_saf(header);


	OTraceInfo("I-SHC-1640039: Write the reversal to SAF.\n");
	return 1;

}


int ShcLateRev::write_saf(ShcmsgHeader *header)
{
	//	>>>	R025286
	int msgtype = header->msg.msgtype;
	thisShcApp->shcmsgHelperObj->shc_set_return_msgno(&header->msg);
	thisShcApp->shcmsgLogObj->logTxn(header);
	thisShcApp->shcmsgLogObj->rewind();
	header->msg.msgtype = msgtype;
	/**	R025643
	header->shcLogObj->logTxn(header);
	header->msg.msgtype = msgtype;
	if (dbm_commit(getpid()) < 0)
		OTraceDebug("I-SHC-1640040: DBM Commit Failed\n");
	if ( laterev_fd >= 0)
	dbm_rewind(laterev_fd);	//	---	R025325
	//	<<<	R025286	
	**/
	thisShcApp->shcmsgHelperObj->shcGetIssAcq(header, 0);

	if (header->setIssShcBin( header->msg.issuer) < 0 )
		OTraceError("E-SHC-1640037: Can not locate issuer[%s] \n", header->msg.issuer);

    if (header->setAcqShcBin(header->msg.acquirer) < 0 )
		OTraceError("E-SHC-1640038: Can not locate acquirer<%s>.\n", header->msg.acquirer);

	thisShcApp->shcmsgTxnHelperObj->setParamSet(header);    //  --- R026229
	thisShcApp->shcSafIOHelperObj->shc_saf_write_transaction(header);
	return 1;
}

int ShcLateRev::commandLine(int arg_c, char **arg_v)
{
	OTraceDebug("E-SHCLRS-?????:Cmd %s  %s [%d]\n", arg_v[0], arg_v[1], arg_c);

	if (strcmp(arg_v[1], "info") == 0)
	{
		cmdInfo(arg_c, arg_v);
	}
	else if (strcmp(arg_v[1], "list") == 0)
	{
		cmdList(arg_c, arg_v);
	}
	else if (strcmp(arg_v[1], "scan") == 0)
	{
		cmdScan(arg_c, arg_v);
	}
	else if (strcmp(arg_v[1], "mark") == 0)
	{
		cmdMark(arg_c, arg_v);
	}
	else 
	{
		printf("Unknown Command: %s %s\n", arg_v[0], arg_v[1]);
	}

	return 1;
}

int ShcLateRev::cmdInfo(int arg_c, char **arg_v)
{
	// get  Counts
	long  statusU = 0;  //On Hold
	long  statusS = 0;  //Skipped
	long  statusD = 0;  //Done
	long  statusW = 0;  //Waiting

	statusU = getCount(1, 'U');
	statusS = getCount(1, 'S');
	statusD = getCount(1, 'D');
	statusW = getCount(1, 'W');

	printf("Site 1: U:%d | S:%d | D:%d | W:%d\n", statusU, statusS,  statusD,  statusW);
	statusU = getCount(2, 'U');
	statusS = getCount(2, 'S');
	statusD = getCount(2, 'D');
	statusW = getCount(2, 'W');

	printf("Site 2: U:%d | S:%d | D:%d | W:%d\n", statusU, statusS,  statusD,  statusW);

	return 1;
}

long ShcLateRev::getCount(int site_id, char status)
{

	static long 	reccount;
	static char  	lstatus;
	static short   	lsite_id; 	 

	if (!_countRevlogStatus)
	{
		
		int i = 1;

		_countRevlogStatus = _dbConn->getStmt();

		try
		{
			_countRevlogStatus->prepare ("Select count(*) from RevLog where status = ? AND site_id = ?");

			_countRevlogStatus->bindCol(i++, DBM_LONGTYPE, &reccount, sizeof(reccount), NULL);
			i = 1;
			_countRevlogStatus->bindParam(i++, DBM_CHARTYPE, &lstatus, sizeof(lstatus), NULL);
			_countRevlogStatus->bindParam(i++, DBM_INTTYPE, &lsite_id, sizeof(lsite_id), NULL);

		}

		catch( const DBMException& e )
		{
			handleDBMException( _dbConn, _countRevlogStatus, e );
		 	OTraceError
			(
			     "E-SHCLRS-5128:caught exception in prepare Select count(*) "
						 "native error=%d, sqlstate=%.5s, msg=%s\n",
						 e.getNativeError(), e.getSQLState().data(), e.getErrMsg().data()
			);
			return -1;
		}
	}

	lstatus = status;
	lsite_id = site_id;
	reccount = 0;

	try
	{
		_countRevlogStatus->execute();
		_countRevlogStatus->fetch();
		_countRevlogStatus->close();
	}
	catch( const DBMException& e )
	{
		handleDBMException( _dbConn, _countRevlogStatus, e );
		OTraceError
		(
			"E-SHCLRS:caught exception in select count(*) from  revlog"
			"native error=%d, sqlstate=%.5s, msg=%s\n",
			e.getNativeError(), e.getSQLState().data(), e.getErrMsg().data()
		);
		return -1;
	}

	return reccount;
}

	
int ShcLateRev::cmdList(int arg_c, char **arg_v)
{

	static char  	lstatus;
	int rc = 0;

	if (arg_c == 2 || (strcmp(arg_v[2], "A") == 0))
	{
		if (!_listallRevlog)
		{
			int i = 1;

			_listallRevlog = _dbConn->getStmt();

			try
			{
				_listallRevlog->prepare ("Select status, site_id, shclog_id, trace, pcode, pan, termid, local_time, local_date, sys_dt_time from RevLog order by sys_dt_time" );


				_listallRevlog->bindCol(i++, DBM_CHARTYPE, &_revlog.status, sizeof(_revlog.status), NULL);
				_listallRevlog->bindCol(i++, DBM_INTTYPE, &_revlog.site_id, sizeof(_revlog.site_id), NULL);
				_listallRevlog->bindCol(i++, DBM_STRINGTYPE, _revlog.shclog_id, sizeof(_revlog.shclog_id), NULL);
				_listallRevlog->bindCol(i++, DBM_LONGTYPE, &_revlog.trace, sizeof(_revlog.trace), NULL);
				_listallRevlog->bindCol(i++, DBM_LONGTYPE, &_revlog.pcode, sizeof(_revlog.pcode), NULL);
				_listallRevlog->bindCol(i++, DBM_PANTOKENTYPE, _revlog.pan, sizeof(_revlog.pan), NULL); 
				_listallRevlog->bindCol(i++, DBM_STRINGTYPE, _revlog.termid, sizeof(_revlog.termid), NULL);
				_listallRevlog->bindCol(i++, DBM_LONGTYPE, &_revlog.local_time, sizeof(_revlog.local_time), NULL);
				_listallRevlog->bindCol(i++, DBM_DATETYPE, &_revlog.local_date, sizeof(_revlog.local_date), NULL);
				_listallRevlog->bindCol(i++, DBM_DATETIMETYPE, &_revlog.sys_dt_time, sizeof(_revlog.sys_dt_time), NULL); 
	
			}

			catch( const DBMException& e )
			{
				handleDBMException( _dbConn, _listallRevlog, e );
			 	OTraceError
				(
				     "E-SHCLRS-5128:caught exception in prepare Select  from revlog "
							 "native error=%d, sqlstate=%.5s, msg=%s\n",
							 e.getNativeError(), e.getSQLState().data(), e.getErrMsg().data()
				);
				return -1;
			}
		}
	
		try
		{
			_listallRevlog->execute();
			while (!rc)
			{
				memset(&_revlog, 0, sizeof(_revlog));
				rc = _listallRevlog->fetch();
				if (!rc)
				{
					printf("%c %1d %16s ", _revlog.status, _revlog.site_id, _revlog.shclog_id);
					printf("%06d %06d %19s ", _revlog.trace, _revlog.pcode, shc_maskpan(_revlog.pan));
					printf("%9s %06d %06d ", _revlog.termid,  _revlog.local_time, _revlog.local_date);
					printf("%12d\n", _revlog.sys_dt_time);
				}
			}
	
	
			_listallRevlog->close();
		}
		catch( const DBMException& e )
		{
			handleDBMException( _dbConn, _listallRevlog,  e );
			OTraceError
			(
				"E-SHCLRS:caught exception in select  from  revlog"
				"native error=%d, sqlstate=%.5s, msg=%s\n",
				e.getNativeError(), e.getSQLState().data(), e.getErrMsg().data()
			);
			return -1;
		}
	}
	else
	{
		//Display for specific status	
		lstatus = arg_v[2][0];

		if (!_listRevlog)
		{
			int i = 1;

			_listRevlog = _dbConn->getStmt();

			try
			{
				_listRevlog->prepare ("Select status, site_id, shclog_id, trace, pcode, pan, termid, local_time, local_date, sys_dt_time from RevLog where status = ?  order by sys_dt_time" );


				_listRevlog->bindCol(i++, DBM_CHARTYPE, &_revlog.status, sizeof(_revlog.status), NULL);
				_listRevlog->bindCol(i++, DBM_INTTYPE, &_revlog.site_id, sizeof(_revlog.site_id), NULL);
				_listRevlog->bindCol(i++, DBM_STRINGTYPE, _revlog.shclog_id, sizeof(_revlog.shclog_id), NULL);
				_listRevlog->bindCol(i++, DBM_LONGTYPE, &_revlog.trace, sizeof(_revlog.trace), NULL);
				_listRevlog->bindCol(i++, DBM_LONGTYPE, &_revlog.pcode, sizeof(_revlog.pcode), NULL);
				_listRevlog->bindCol(i++, DBM_PANTOKENTYPE, _revlog.pan, sizeof(_revlog.pan), NULL); 
				_listRevlog->bindCol(i++, DBM_STRINGTYPE, _revlog.termid, sizeof(_revlog.termid), NULL);
				_listRevlog->bindCol(i++, DBM_LONGTYPE, &_revlog.local_time, sizeof(_revlog.local_time), NULL);
				_listRevlog->bindCol(i++, DBM_DATETYPE, &_revlog.local_date, sizeof(_revlog.local_date), NULL);
				_listRevlog->bindCol(i++, DBM_DATETIMETYPE, &_revlog.sys_dt_time, sizeof(_revlog.sys_dt_time), NULL); 
	
				i = 1;
	
				_listRevlog->bindParam(i++, DBM_CHARTYPE, &lstatus, sizeof(lstatus), NULL);
	
			}

			catch( const DBMException& e )
			{
				handleDBMException( _dbConn, _listRevlog, e );
			 	OTraceError
				(
				     "E-SHCLRS-5128:caught exception in prepare Select  from revlog "
							 "native error=%d, sqlstate=%.5s, msg=%s\n",
							 e.getNativeError(), e.getSQLState().data(), e.getErrMsg().data()
				);
				return -1;
			}
		}
	
		try
		{
			_listRevlog->execute();
			while (!rc)
			{
				memset(&_revlog, 0, sizeof(_revlog));
				rc = _listRevlog->fetch();
				if (!rc)
				{
					printf("%c %1d %16s ", _revlog.status, _revlog.site_id, _revlog.shclog_id);
					printf("%06d %06d %19s ", _revlog.trace, _revlog.pcode, shc_maskpan(_revlog.pan));
					printf("%9s %06d %06d ", _revlog.termid,  _revlog.local_time, _revlog.local_date);
					printf("%12d\n", _revlog.sys_dt_time);
				}
			}
	
	
			_listRevlog->close();
		}
		catch( const DBMException& e )
		{
			handleDBMException( _dbConn, _listRevlog,  e );
			OTraceError
			(
				"E-SHCLRS:caught exception in select  from  revlog"
				"native error=%d, sqlstate=%.5s, msg=%s\n",
				e.getNativeError(), e.getSQLState().data(), e.getErrMsg().data()
			);
			return -1;
		}
	}

	return 1;
}

int ShcLateRev::cmdScan(int arg_c, char **arg_v)
{
	static int laterrev_id = -1;
	char xbuf[1024];

	if (laterrev_id == -1)
	{
	 	laterrev_id = mb_locatemailbox("ShcLateRev");
		if( laterrev_id < 0 )
		{
		 	OTraceError("E-SHCLRS-163003:Unable to connect later reversal util srv\n");
			return -1;
		}
	}

	if (arg_c == 3 &&  (strcmp(arg_v[2], "all") == 0)) 
	{
		strcpy (xbuf, "SCANALL");
		if(mb_write(laterrev_id,laterrev_id, xbuf, strlen (xbuf))<0)
		{
			OTraceError("E-SHC-163005:Unable to write to late reversal srv %d.\n",
					laterrev_id );
			return -1;
		}
	}
	else if (arg_c == 4)
	{
		snprintf (xbuf, sizeof(xbuf), "SCANONE %s %s",  arg_v[2], arg_v[3]);
		if(mb_write(laterrev_id,laterrev_id, xbuf, strlen (xbuf))<0)
		{
			OTraceError("E-SHC-163005:Unable to write to late reversal srv %d.\n",
					laterrev_id );
			return -1;
		}

	}
	else
	{
		printf("Usage: revlog scan {Site_id log_id}| all\n");
	}

	return 1;
}


int ShcLateRev::cmdMark(int arg_c, char **arg_v)
{

	//  upadte the status of a record
	struct revlog rev_log;
	char lstatus;
	
	if (arg_c != 5)
	{
		printf("Usage:  revlog mark {Site_id log_id} {S|U}\n");
	}
	else 
	{
		rev_log.site_id = atoi(arg_v[2]);
		istsafe_strcpy(rev_log.shclog_id,sizeof(rev_log.shclog_id), arg_v[3]);
		lstatus = arg_v[4][0];

		if (lstatus == 'S' || lstatus == 'U' || lstatus == 'D')
		{
			updateRevLogStatus(&rev_log, lstatus);
		}
		else
		{
			printf("Usage:  revlog mark {Site_id log_id} {S|U}\n");
		}
	}

	return 1;
}




//R028581 >>>
void checkDbConn()
{
		int ind = 0;
		if(DBMGetConnectAttribute(dbm_dbconn, DBM_ATTR_CONNECTION_DEAD, &ind, sizeof(ind), 0) == DBM_SUCCESS)
		{
			if(ind)
			{
				OTraceFatal("F-SHC-1640016.1: disconnected from database, exiting\n");
				kill(getpid(),1);
			}
		}
		else
			OTraceFatal("F-SHC-1640016.2: Unable to detect db connection status, exiting\n");
		return;
}

int doDbCommit()
{
	if(dbm_commit(getpid()) < 0)
	{
		if (dbm_errno == DBME_DISCONNECT)
		{
			OTraceFatal("F-SHC-1640021.1: disconnected from database, exiting\n");
			kill(getpid(),1);
		}
		return(-1);
	}
	return(1);
}


void handleDBMException(DBMConn* conObj, DBMStmt* stmt, const DBMException& e )
{
	OTraceError
	(
		"E-SHCLRS-17009:Caught DBM Exception"
		"native error=%d, sqlstate=%.5s, msg=%s\n",
		e.getNativeError(), e.getSQLState().data(), e.getErrMsg().data()
	);

	try
	{
		if( stmt )
			stmt->close();
	}
	catch(const DBMException& se )
	{
	}
}






//<<< R028581
/*----------------------------------------------------------------------------
 * End of file 
 *---------------------------------------------------------------------------*/
