static char _ShcmsgBaseTxn_cxx_what[] = "@(#) ShcmsgBaseTxn.cxx 1.25 19/10/29 17:57:04";

/*
 *  Copyright (C) 2004 eFunds Corporation ("eFunds").  All Rights Reserved.
 *  eFunds Canada Corporation is an authorized user.
 *
 *  IST is a registered trademark of eFunds Corporation.  Other brand or
 *  product names are trademarks or registered trademarks of their respective
 *  holders.
 *
 *  The information contained herein is the unpublished proprietary property
 *  of eFunds.  Except as specifically authorized in writing by eFunds, the
 *  holder of this document shall: i) keep all information contained herein
 *  confidential, and ii) protect the information, in whole or in part, from
 *  disclosure and dissemination to all third parties.
 *
 *  This document and the software described in it are furnished under license
 *  and may be used or copied only in accordance with the terms of such license.
 *  This document is supplied for information purposes only, is subject to
 *  change without notice, and should not be construed as a commitment by
 *  either eFunds Corporation or eFunds Canada Corporation.
 *
 *
 *                        MODIFICATION HISTORY                  REVIEW
 *
 *	SPR#	Who	Date	Description			Who	Date
 * ===========================================================================
 *R00xxxx ztang 05Nov03	Creation
 *R012160 Emj   10Oct04 Set Processor Business day
 *R018276 pve	27Nov06	Add new OTraceLog messages
 *R020052 spa	21May07	call sendTxnReq to decide to send the txn to FM or not
 *R020938 spa	16Aug07	IST LM Bridge support
 *R025639 vmp	16Jan09	Added new static var to check initrecords loaded or not
 *R028271 dipa  18Jun10 Txn Statistics
 *R030381 dipa  02Mar12 Txn Statistics - changes
 */
/* File Number 90 */

#include <stdio.h>
#include <string.h>
#include <ctype.h>
#include <oasis.h>
#include <ist_otrace.h>
#include <shcdef.h>
#include <shc.h>
#include <shc_callback.h>
#include <ShcmsgHelper.h>
#include <ShcFinAuthReq.h>
#include <ShcMacHelper.h>
#include <ShcTimerHelper.h>
#include <ShcApp.h>
#include <ShcmsgTxnHelper.h>
#include <shc_callback.h>
#include <ShcmsgFMHelper.h>		//	---	R020052
#include <ShcmsgODHelper.h>		//	---	R020052

#include <TxnStat.h>

#include <ShcAsynchApi.h>

static int initrecords_loaded = 0;//	---	R025639
int processingDoneOnOtherNode = 0;

int ShcmsgBaseTxn::enrich()
{
	OTraceDebug("D-SHC-090001:ShcmsgBaseTxn::enrich begin\n");

	if (header->createdInternal())
		return 0;
	if (shcIsConfirmPending(header))
		return 0;

	thisShcApp->shcmsgTxnHelperObj->setDefaultKeyLen(header);
	thisShcApp->shcmsgTxnHelperObj->setOriginator(header);
	thisShcApp->shcmsgHelperObj->shc_normalizepan(header->msg.pan);

	if (!(header->issBinValid()) || !(header->acqBinValid()))
	{
		header->setReturnFlag(header->msg.respcode);
		return -1;
	}

//	thisShcApp->shcmsgTxnHelperObj->setParamSet(header);
	thisShcApp->shcmsgTxnHelperObj->setProcessorBusDay(header);
	thisShcApp->shcmsgTxnHelperObj->setCapDate(header);
	thisShcApp->shcmsgHelperObj->shc_get_pin_data(header);
	thisShcApp->shcmsgTxnHelperObj->setCurrencyCode(header);
	thisShcApp->shcmsgTxnHelperObj->initFromDevice(header);
	thisShcApp->shcmsgTxnHelperObj->setAcqCountry(header);
	thisShcApp->shcmsgTxnHelperObj->decideTimeOutValue(header);
	thisShcApp->shcmsgHelperObj->setPinParm(header);
	thisShcApp->shcmsgTxnHelperObj->setOnlineActivity(header);
	OTraceInfo("I-SHC-090002: (header) enrich(iss=%s, acq=%s),(txnSrc=%s, txnDest=%s)\n",
			header->msg.issuer, header->msg.acquirer,
			header->msg.txnSrc, header->msg.txnDest);

	OTraceInfo("I-SHC-090003: shc_startup(): Normal exit.\n");
	return 0;
}


int ShcmsgBaseTxn::process()
{
	int callbackRet;
	int goingToOtherModule;
	int ret=0;

	// ASynch Process: Skip flags are set based on specific SecSrv calls
	if (header->shouldContinue(TXN_PROC_SKIP_ENRICH))
		enrich();

	if(!(header->shcerr & SH_ASYNCH_RESUME))
	{
		callbackRet=shc_callback(header,"pre_edit");

		switch(callbackRet)
		{
			case SHCCALLBACKOVERRIDE:
				OTraceInfo("I-SHC-090004: Skipped as pre_edit callback function asked\n");
				return 0;
			case SHCCALLBACKDROP:
				thisShcApp->shcmsgHelperObj->shc_callback_log(header, SHCCALLBACKDROP);
				OTraceLog("L-SHC-090005: Drop message ID[%s]/m%04d/t%06ld/p%06ld\n", header->msg.shclog_id,
					header->msg.msgtype, header->msg.trace, header->msg.pcode);

				TxnStatReport(header->msg.shclog_id,TS_SHC,TSR_DROP,DROP_BY_CALLBACK_pre_edit,0,0);
				return(0);
			case SHCCALLBACKDENY:
				thisShcApp->shcmsgHelperObj->shc_deny_txn(header);
				{
					OTraceInfo("I-SHC-090006: Denied as pre_edit callback function asked\n");
					return 0;
				}
			case SHCCALLBACKCONTINUE:
			default:
				break;
		}
	}

	if (header->shouldContinue(TXN_PROC_SKIP_RESTORE))
		restore();

	if (header->shouldContinue(TXN_PROC_SKIP_EDIT))
		edit();

	if (header->shouldContinue(TXN_PROC_SKIP_VERIFY))
		verify();

	if(!(header->shcerr & SH_ASYNCH_RESUME))
	{
		goingToOtherModule = 0;
		if(!processingDoneOnOtherNode)
		{
			if(!shcmsgODHelperObj)
				shcmsgODHelperObj = (ShcmsgODHelper *)shcHelperRegister.getTargetObj(SHC_ShcmsgODHelper);
			if (shcmsgODHelperObj)
				goingToOtherModule = shcmsgODHelperObj->sendTxnReq(header);

			if (!goingToOtherModule)
			{
				if(!shcmsgFMHelperObj)
					shcmsgFMHelperObj = new ShcmsgFMHelper;
				if(initrecords_loaded == 0)
				{
					shcmsgFMHelperObj->init_records();
					OTraceInfo("I-SHC-090007: Init_Records are loaded\n");
					initrecords_loaded++;
				}

				shcmsgFMHelperObj->sendTxnReq(header, TO_FM);

				shcmsgFMHelperObj->sendTxnReq(header, TO_LM);
			}
		}
	}

	OTraceDebug("D-SHC-01212 6 ShcnetProcessor::process [0x%08x] ShcErr[0x%08x] Log[%08x]\n",
			header->procFlag,header->shcerr,header->logFlag);//,
	if (header->shouldContinue(TXN_PROC_SKIP_DOWORK))
		ret=doWork();

	if (!processingDoneOnOtherNode && !goingToOtherModule)
	{
		shcmsgFMHelperObj->sendReversal(header, TO_LM);
	}

	callbackRet = shc_callback(header,"post_edit");

	return ret;
}

