//
// Copyright (C) 2004 eFunds Corporation ("eFunds").  All Rights Reserved.
// eFunds Canada Corporation is an authorized user.
//
// IST is a registered trademark of eFunds Corporation.  Other brand or
// product names are trademarks or registered trademarks of their respective
// holders.
//
// The information contained herein is the unpublished proprietary property
// of eFunds.  Except as specifically authorized in writing by eFunds, the
// holder of this document shall: i) keep all information contained herein
// confidential, and ii) protect the information, in whole or in part, from
// disclosure and dissemination to all third parties.
//
// This document and the software described in it are furnished under license
// and may be used or copied only in accordance with the terms of such license.
// This document is supplied for information purposes only, is subject to
// change without notice, and should not be construed as a commitment by
// either eFunds Corporation or eFunds Canada Corporation.
//
 /*
 *  SCR     Who   Date	   Description
 *  ===========================================================================
 *  R020052 spa   21May07  New file created
 *	R025639 vmp   16Jan09	Changes made for FMPhaseII enhancement	
 */

/* File Number 157 */


#include <FMBlockReq.h>
#include <ShcApp.h>
#include <ShcmsgFMHelper.h>
#include <istsafe.h>

FMBlockReq :: FMBlockReq(ShcHeader *shcheader)
{
	header = (FMCMDHeader *)shcheader;
}

int FMBlockReq :: enrich()
{
	return 0;
}

int FMBlockReq :: doWork()
{
	int ret = 0;
	char *ptr, *ptr1;
	if(!shcmsgFMHelperObj)
		shcmsgFMHelperObj = new ShcmsgFMHelper;

	switch(header->blockCMD.action)
	{
		case FM_HOTBLOCK_CARD:	//	---	R025639
			break;

		//	>>>	R025639

		case FM_BLOCK_CARD:
			break;

		case FM_UNBLOCK_CARD:
			break;

			//	<<<	R025639

		case FM_BLOCK_MERCHANT:
			memset(&merchant, 0, sizeof(merchant));
			/*strcpy(merchant.institution, header->blockCMD.inst);
			strcpy(merchant.acceptor_id, header->blockCMD.blockInfo);*/
			ptr = strpbrk(header->blockCMD.blockInfo, ",");
			if( ptr )
			{
				strncpy(merchant.institution, header->blockCMD.blockInfo, std::min<int> ((ptr-header->blockCMD.blockInfo), sizeof merchant.institution ));
				ptr++;	//skip ','
				//strcpy(merchant.acceptor_id, ptr);
				istsafe_strcpy(merchant.acceptor_id, sizeof(merchant.acceptor_id), ptr);
			}
			else{
				//strcpy(merchant.acceptor_id, header->blockCMD.blockInfo);
				istsafe_strcpy(merchant.acceptor_id, sizeof(merchant.acceptor_id), header->blockCMD.blockInfo);
            }
			//	>>>	R025639
			shc_get_current_date();
			merchant.trandate = shc_local_currentdate();
			merchant.trantime = shc_local_currenttime();
			//	<<<	R025639
			merchant.respcode = SHC_RC_InvalidMerchant;
			ret = shcmsgFMHelperObj->addHotMerchant(&merchant);
			break;

			//	>>>	R025639

		case	FM_UNBLOCK_MERCHANT:
			memset(&merchant, 0, sizeof(merchant));
			/*strcpy(merchant.institution, header->blockCMD.inst);
			strcpy(merchant.acceptor_id, header->blockCMD.blockInfo);*/
			ptr = strpbrk(header->blockCMD.blockInfo, ",");
			if( ptr )
			{
				strncpy(merchant.institution, header->blockCMD.blockInfo, (ptr-header->blockCMD.blockInfo));
				ptr++;	//skip ','
				//strcpy(merchant.acceptor_id, ptr);
				istsafe_strcpy(merchant.acceptor_id, sizeof(merchant.acceptor_id), ptr);
			}
			else{
				//strcpy(merchant.acceptor_id, header->blockCMD.blockInfo);
				istsafe_strcpy(merchant.acceptor_id, sizeof(merchant.acceptor_id), header->blockCMD.blockInfo);
            }
			ret = shcmsgFMHelperObj->unblockMerchant(&merchant);
			break;

		case	FM_SUSPEND_MERCHANT:
			memset(&merchant, 0, sizeof(merchant));
			/*strcpy(merchant.institution, header->blockCMD.inst);
			strcpy(merchant.acceptor_id, header->blockCMD.blockInfo);*/
			ptr = strpbrk(header->blockCMD.blockInfo, ",");
			if( ptr )
			{
				strncpy(merchant.institution, header->blockCMD.blockInfo, std::min<int> ((ptr-header->blockCMD.blockInfo), sizeof merchant.institution ));
				ptr++;	//skip ','
				//strcpy(merchant.acceptor_id, ptr);
				istsafe_strcpy(merchant.acceptor_id, sizeof(merchant.acceptor_id), ptr);
			}
			else{
				//strcpy(merchant.acceptor_id, header->blockCMD.blockInfo);
				istsafe_strcpy(merchant.acceptor_id, sizeof(merchant.acceptor_id), header->blockCMD.blockInfo);
            } 
			shc_get_current_date();
			merchant.trandate = shc_local_currentdate();
			merchant.trantime = shc_local_currenttime();
			merchant.duration = atoi(header->blockCMD.dur);
			merchant.respcode = SHC_RC_InvalidMerchant;
			ret = shcmsgFMHelperObj->suspendMerchant(&merchant);
			break;

		//	<<<	R025639

		case FM_BLOCK_TERMINAL:
			memset(&merchant, 0, sizeof(merchant));
			memset(&merchant, 0, sizeof(merchant));
			ptr = strpbrk(header->blockCMD.blockInfo, ",");
			if( ptr )
			{
				//strncpy(merchant.acceptor_id, header->blockCMD.blockInfo, (ptr-header->blockCMD.blockInfo));
				strncpy(merchant.institution, header->blockCMD.blockInfo, (ptr-header->blockCMD.blockInfo));
				ptr++;	//skip ':'
				ptr1 = strpbrk(ptr, ",");
				strncpy(merchant.acceptor_id, ptr, std::min<int>(ptr1-ptr, sizeof(merchant.acceptor_id)));
				ptr1++;
				//strcpy(merchant.terminal_id, ptr1);
				istsafe_strcpy(merchant.terminal_id, sizeof(merchant.terminal_id), ptr1);
			}
			else{
				//strcpy(merchant.acceptor_id, header->blockCMD.blockInfo);
				istsafe_strcpy(merchant.acceptor_id, sizeof(merchant.acceptor_id), header->blockCMD.blockInfo);
            }
			//	>>>	R025639
			shc_get_current_date();
			merchant.trandate = shc_local_currentdate();
			merchant.trantime = shc_local_currenttime();
			//	<<<	R025639

			merchant.respcode = SHC_RC_InvalidMerchant;
			ret = shcmsgFMHelperObj->addHotMerchant(&merchant);
			break;


			//	>>>	R025639
		case	FM_UNBLOCK_TERMINAL:
			memset(&merchant, 0, sizeof(merchant));
			//strcpy(merchant.institution, header->blockCMD.inst);
			istsafe_strcpy(merchant.institution, sizeof(merchant.institution), header->blockCMD.inst);
			ptr = strpbrk(header->blockCMD.blockInfo, ",");
			if( ptr )
			{
				//strncpy(merchant.acceptor_id, header->blockCMD.blockInfo, (ptr-header->blockCMD.blockInfo));
				strncpy(merchant.institution, header->blockCMD.blockInfo, (ptr-header->blockCMD.blockInfo));
				ptr++;	//skip ':'
				ptr1 = strpbrk(ptr, ",");
				strncpy(merchant.acceptor_id, ptr, std::min<int>( ptr1-ptr, sizeof merchant.acceptor_id) );
				ptr1++;
				//strcpy(merchant.terminal_id, ptr1);
				istsafe_strcpy(merchant.terminal_id, sizeof(merchant.terminal_id), ptr1);
			}
			else{

				//strcpy(merchant.acceptor_id, header->blockCMD.blockInfo);
				istsafe_strcpy(merchant.acceptor_id, sizeof(merchant.acceptor_id), header->blockCMD.blockInfo);
            }
			ret = shcmsgFMHelperObj->unblockMerchant(&merchant);
			break;
		case	FM_SUSPEND_TERMINAL:
			memset(&merchant, 0, sizeof(merchant));
			//strcpy(merchant.institution, header->blockCMD.inst);
			istsafe_strcpy(merchant.institution, sizeof(merchant.institution), header->blockCMD.inst);
			ptr = strpbrk(header->blockCMD.blockInfo, ",");
			if( ptr )
			{
				//strncpy(merchant.acceptor_id, header->blockCMD.blockInfo, (ptr-header->blockCMD.blockInfo));
				strncpy(merchant.institution, header->blockCMD.blockInfo, (ptr-header->blockCMD.blockInfo));
				ptr++;	//skip ':'
				ptr1 = strpbrk(ptr, ",");
				strncpy(merchant.acceptor_id, ptr, std::min<int>( ptr1-ptr, sizeof merchant.acceptor_id));
				ptr1++;
				//strcpy(merchant.terminal_id, ptr1);
				istsafe_strcpy(merchant.terminal_id, sizeof(merchant.terminal_id), ptr1);
			}
			else{
				//strcpy(merchant.acceptor_id, header->blockCMD.blockInfo);
				istsafe_strcpy(merchant.acceptor_id, sizeof(merchant.acceptor_id), header->blockCMD.blockInfo);
            }
			shc_get_current_date();
			merchant.trandate = shc_local_currentdate();
			merchant.trantime = shc_local_currenttime();
			merchant.duration = atoi(header->blockCMD.dur);
			merchant.respcode = SHC_RC_InvalidMerchant;
			ret = shcmsgFMHelperObj->suspendMerchant(&merchant);
			break;
		//	<<<	R025639
		case FM_BLOCK_PREFIX:
			memset(&hotrange, 0, sizeof(hotrange));
			//strcpy(hotrange.pan_low, header->blockCMD.blockInfo);
			istsafe_strcpy(hotrange.pan_low, sizeof(hotrange.pan_low), header->blockCMD.blockInfo);
			strncat(hotrange.pan_low, (char *)"0000000000000000000", (SHC_PAN_LEN-strlen(header->blockCMD.blockInfo)));
			//strcpy(hotrange.pan_hi, header->blockCMD.blockInfo);
			istsafe_strcpy(hotrange.pan_hi, sizeof(hotrange.pan_hi), header->blockCMD.blockInfo);
			strncat(hotrange.pan_hi, (char *)"9999999999999999999", (SHC_PAN_LEN-strlen(header->blockCMD.blockInfo)));
			hotrange.status = SHC_RC_HotCard;
			hotrange.cardalert = 'Y';
			ret = shcmsgFMHelperObj->addHotRange(&hotrange);
			break;

		//	>>>	R025639
		case FM_UNBLOCK_PREFIX:
			memset(&hotrange, 0, sizeof(hotrange));
			//strcpy(hotrange.pan_low, header->blockCMD.blockInfo);
			istsafe_strcpy(hotrange.pan_low, sizeof(hotrange.pan_low), header->blockCMD.blockInfo);
			strncat(hotrange.pan_low, (char *)"0000000000000000000", (SHC_PAN_LEN-strlen(header->blockCMD.blockInfo)));
			//strcpy(hotrange.pan_hi, header->blockCMD.blockInfo);
			istsafe_strcpy(hotrange.pan_hi, sizeof(hotrange.pan_hi), header->blockCMD.blockInfo);
			strncat(hotrange.pan_hi, (char *)"9999999999999999999", (SHC_PAN_LEN-strlen(header->blockCMD.blockInfo)));
			ret = shcmsgFMHelperObj->unblockRange(&hotrange);
			break;
		//	<<<	R025639
		default:
			OTraceError("E-SHC-157001: Unknown command from FM, trace: %d\n", header->blockCMD.trace);
			ret = -2;
			break;
	}

	//send response back
	header->blockCMD.msgtype = SHC_FM_CMD_RESP;
	if( ret == 0 )
		strcpy(header->blockCMD.respcode, "00");	//	---	R025639
	else if( ret == -2 )
		strcpy(header->blockCMD.respcode, "99");//	---	R025639	//unknown command
	else
		strcpy(header->blockCMD.respcode, "10");//	---	R025639	//unable to insert record
	shcmsgFMHelperObj->sendCmdResp((char*)&header->blockCMD, sizeof(struct s_BlockCMD));

	return 0;
}

int FMBlockReq :: process()
{
	enrich();
	doWork();
	return 0;
}

