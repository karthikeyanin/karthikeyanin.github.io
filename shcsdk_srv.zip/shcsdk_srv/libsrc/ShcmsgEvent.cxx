static char _ShcmsgEvent_cxx_what[] = "@(#) ShcmsgEvent.cxx 1.4 04/08/24 17:54:03";

/*
 *  Copyright (C) 2004 eFunds Corporation ("eFunds").  All Rights Reserved.     
 *  eFunds Canada Corporation is an authorized user.                            
 *                                                                              
 *  IST is a registered trademark of eFunds Corporation.  Other brand or        
 *  product names are trademarks or registered trademarks of their respective   
 *  holders.                                                                    
 *                                                                              
 *  The information contained herein is the unpublished proprietary property    
 *  of eFunds.  Except as specifically authorized in writing by eFunds, the     
 *  holder of this document shall: i) keep all information contained herein     
 *  confidential, and ii) protect the information, in whole or in part, from    
 *  disclosure and dissemination to all third parties.                          
 *                                                                          
 *  This document and the software described in it are furnished under license  
 *  and may be used or copied only in accordance with the terms of such license.
 *  This document is supplied for information purposes only, is subject to      
 *  change without notice, and should not be construed as a commitment by       
 *  either eFunds Corporation or eFunds Canada Corporation. 
 *
 *
 *
 *                        MODIFICATION HISTORY                  REVIEW
 *
 *	SPR#	Who	Date	Description			Who	Date   
 * ===========================================================================
 * R0xxxxx jyang 09Dec03 Created
 */

//File Number 91

#include <ShcmsgEvent.h>
#include <shc_callback.h>
#include <ShcApp.h>
#include <ShcmsgEventHelper.h>

int ShcmsgEvent::enrich()
{

	OTraceInfo("I-SHC-091001: Time out of message: %d trace %d event %d unit %d\n",
		header->msg.msgtype, header->msg.trace, 
		header->eventId, header->msg.unit);

	/*
 	 *	Remove the message from the event queue
 	 */
	tm_dequeue(header->eventId);
	header->eventId = -1;

	shcBin = header->issShcBin;
		
	return 0;
}


int ShcmsgEvent::edit()
{
	
	thisShcApp->shcmsgEventHelperObj->checkAndSetBinDown(header, shcBin);

	thisShcApp->shcmsgEventHelperObj->checkAndSetSafType(this, header, shcBin);
	
	return 0;
}


int ShcmsgEvent::doWork()
{
	if ( ! header->shouldContinue(TXN_PROC_SKIP_DOWORK) )
		return False;
		
	if ( thisShcApp->shcmsgEventHelperObj->retryOnTimeout(header, shcBin) == True )
	{
		header->setSkipFlag();
		return False;
	}

		return True;
}



