static char _ShcProcessor_cxx_what[] = "@(#)ShcnetProcessor.cxx 1.19.1.10 20/07/08 00:37:23";

/*
 *  Copyright (C) 2004 eFunds Corporation ("eFunds").  All Rights Reserved.     
 *  eFunds Canada Corporation is an authorized user.                            
 *                                                                              
 *  IST is a registered trademark of eFunds Corporation.  Other brand or        
 *  product names are trademarks or registered trademarks of their respective   
 *  holders.                                                                    
 *                                                                              
 *  The information contained herein is the unpublished proprietary property    
 *  of eFunds.  Except as specifically authorized in writing by eFunds, the     
 *  holder of this document shall: i) keep all information contained herein     
 *  confidential, and ii) protect the information, in whole or in part, from    
 *  disclosure and dissemination to all third parties.                          
 *                                                                          
 *  This document and the software described in it are furnished under license  
 *  and may be used or copied only in accordance with the terms of such license.
 *  This document is supplied for information purposes only, is subject to      
 *  change without notice, and should not be construed as a commitment by       
 *  either eFunds Corporation or eFunds Canada Corporation. 
 *
 *
 *                        MODIFICATION HISTORY                  REVIEW
 *
 * SCR#     Who    Date  Description
 * ===========================================================================
 * R0xxxxx 
 * R030212	sks		03Jan12	Removed paramater 800settimer from xml
 */
 
 //File Number 105
#include <ist_otrace.h>
#include <tm.h>
#include <shc.h>
#include <shcextbuf.h>
#include <ShcSender.h>
#include <ShcSdkCommon.h>
#include <ShcMsgCache.h>
#include <ShcmsgHelper.h>
#include <ShcHelper.h>
#include <ShcmsgTxnHelper.h>
#include <ShcTimerHelper.h>
#include <ShcnetProcessor.h>
#include <CShcNotify.h>
#include <ShcFinAuthReq.h>
#include <ShcFinAuthResp.h>
#include <ShcMacHelper.h>
#include <ShcRevReq.h>
#include <ShcRevResp.h>
#include <ShcnetEventMsg.h>
#include <ShcnetNetworkMsg.h>
#include <ShcTimerHelper.h>
#include <ShcNetworkMsgHelper.h>
#include <ShcnetTxnRegistration.h>
#include <ShcApp.h>
#include <ShcBin.h>
#include <InstProfile.h>
#include <ist_seg_id.h>
#include <ist_seg_dn.h>
#include <ShcKeyHelper.h>
#include <rules.h>
#include <ShcAsynchApi.h>


ShcnetProcessor::ShcnetProcessor(char *msgbuf): ShcmsgProcessor(msgbuf)
{
}

ShcBaseTxn *ShcnetProcessor::classify()
{
return shcnetTxnRegistration.getTargetObj((void *)header);
}


int ShcnetProcessor::log()
{
	ShcmsgHeader *thisHeader = (ShcmsgHeader *)header;
        if (shcApp->acquirerShcParamsList->GetBool((char *)"shc.skip_network_msg_logging"))
         {
                      return 0;
         }
	if ( thisHeader->msg.netcode == SHC_NET_ECHO_START || 
		thisHeader->msg.netcode == SHC_NET_ECHO )
		return 0;

	if (thisHeader->logFlag & SHC_LOG_LATE_RESP)
	{
		thisHeader->logFlag |= SHC_LOG_LATE_RESP;
	}
	else
	{
		if ( shcIsAsynchSecMode() && thisHeader->msg.respcode == SEC_ASYNCH_WAIT )
		{ //Do Not Insert Now 	
		}
		else
			thisHeader->logFlag |= SHC_LOG_REQ;
	}

	thisHeader->msg.pcode = thisHeader->msg.netcode;//save netcode in pcode
	return ShcmsgProcessor::log();
}

int ShcnetProcessor::route()
{
	return thisShcApp->shcmsgHelperObj->shc_route((ShcmsgHeader *)header);
	
}

int ShcnetProcessor::process()
{
	int ret=0;

	ShcmsgHeader *thisHeader = (ShcmsgHeader *)header;

    if(	(getBINs()<0) ||
		(thisShcApp->shcmsgTxnHelperObj->initTransaction(thisHeader) < 0 ))
    {
        thisHeader->shcerr |= SH_IGNORE;
        OTraceDebug("D-SHC-9818: No txn classify needed\n");
    }
	else if (!shcIsRequest(thisHeader) && !thisHeader->reqMsg )
	{
		// Late response to netwrok message
		thisHeader->setSkipFlag(TXN_PROC_SKIP_RESTORE|TXN_PROC_SKIP_EDIT|TXN_PROC_SKIP_VERIFY|
							  TXN_PROC_SKIP_DOWORK);
		thisHeader->logFlag |= SHC_LOG_LATE_RESP;
		thisHeader->shcerr = SH_IGNORE;
                if(thisHeader->msg.from_acct & RETURN_RESP_TO_SENDER)
                {
                        thisHeader->shcerr = SH_RETURN;
                        thisHeader->msg.senderid =  thisHeader->msg.to_acct;
                }
	}
	else
	{

		// >>> R030141 Setting the keys after locate event
		struct shcsecurity *keyparam;
		int ikeyparam = -1;
		InstitutionProfile instProfile = { 0 };
		int len = sizeof(struct InstitutionProfile);
		if (shcIsRequest(thisHeader))
		{
			thisHeader->getSegmentData((char *)&instProfile, &len, NETWORK_DATA_REQ_id, ISS_INST_PROFILE_ENTRY);
		}
		else
		{
			thisHeader->getReqSegmentData((char *)&instProfile, &len, NETWORK_DATA_REQ_id, ISS_INST_PROFILE_ENTRY);
		}

		if (len <= 0)
		{
			NetworkInfo networkInfo;
			shcApp->instProfileObj->locateNetworkInfo(thisHeader->msg.txnSrc, thisHeader->msg.txnDest,
			thisHeader->msg.iss_entityId, thisHeader->msg.msgtype, thisHeader->msg.issuer, networkInfo);
			if (networkInfo.foundNetworkInfo())
			{
				thisHeader->setSegmentData((char *)networkInfo.getInstProfileEntry(),
					 sizeof(struct InstitutionProfile), NETWORK_DATA_REQ_id, ISS_INST_PROFILE_ENTRY);
				if(rm_isMultiVerSupported(0))
					keyparam = networkInfo.getKey();
				else
					ikeyparam = networkInfo.getKeyparam();
				thisShcApp->shcmsgHelperObj->addRoutingInfoSegment( thisHeader, networkInfo );
			}
		}
		else
		{
			if(rm_isMultiVerSupported(0))
				keyparam = shcApp->shcKeyObj->getKey(instProfile.instId, instProfile.keyparamStr);
			else
				ikeyparam = instProfile.keyparm;
		}
		
		if(rm_isMultiVerSupported(0))
		{
			if (thisHeader->issBinValid() && (keyparam))
			{
				thisHeader->issShcBin->setKey(keyparam);
			}
		}
		else
		{
			if (thisHeader->issBinValid() && (ikeyparam >= 0))
			{
				thisHeader->issShcBin->setKey(&shcSecurity[ikeyparam]);
			}
		}


		if (thisHeader->msg.acquirer[0])
		{
			InstitutionProfile instProfile = { 0 };
			int len = sizeof(struct InstitutionProfile);
			struct shcsecurity *acqKeyParm=NULL;

			if (shcIsRequest(thisHeader))
			{
				thisHeader->getSegmentData((char *)&instProfile, &len, NETWORK_DATA_REQ_id, ACQ_INST_PROFILE_ENTRY);
			}
			else
			{
				thisHeader->getReqSegmentData((char *)&instProfile, &len, NETWORK_DATA_REQ_id, ACQ_INST_PROFILE_ENTRY);
			}
			if (len <= 0)
			{
				OTraceDebug("E-SHC-9834.1:No acquirer side inst_profile entry in segment\n");
			}
			else
			{
				if(rm_isMultiVerSupported(0))
					acqKeyParm = shcApp->shcKeyObj->getKey(instProfile.instId, instProfile.keyparamStr);
				else
				{
					if ( thisHeader->acqBinValid() )
						thisHeader->acqShcBin->setKey(&shcSecurity[instProfile.keyparm]);
				}
			}
			if(rm_isMultiVerSupported(0))
			{
				if ((acqKeyParm) && ( thisHeader->acqBinValid() ))
					thisHeader->acqShcBin->setKey(shcApp->shcKeyObj->getKey(instProfile.instId, instProfile.keyparamStr));
				else
					OTraceDebug("E-SHC-9835:Can't find acquirer key(%s,%s)\n", instProfile.instId, instProfile.keyparamStr);
			}
	  	}	

		if ( (shcTxn=classify())!=NULL )
		{
			if ((thisHeader->msg.respcode == SHC_RC_Approved) &&
				(strncmp((char *)thisHeader->msg.formatter_use,"KEY_XCHG_SUCESS_1LEG",20)==0) &&
				thisHeader->msg.msgtype==SHC_NETWORK_RESPONSE && thisHeader->msg.netcode==SHC_NET_KEYS)
			{
				if ( log() < 0 )
				{
					OTraceWarning("W-SHC-105017:Log failed\n");
				}
			}
			ret = shcTxn->process();
			if(shcIsResponse(thisHeader))
			{
				if(thisHeader->msg.from_acct & RETURN_RESP_TO_SENDER)
				{
					thisHeader->shcerr = SH_RETURN;
					thisHeader->msg.senderid =  thisHeader->msg.to_acct;
				}
			}
		}
		else
		{
			OTraceDebug("D-SHC-105015:Can't classify\n");
		}
	
		thisShcApp->shcmsgHelperObj->shc_stats(thisHeader);
	}

	if ( log() < 0 ){
		OTraceWarning("W-SHC-105016:Log failed, messages will not be sent\n");
		thisShcApp->shcHelperObj->reset_mb_cache();
		return ret;
	}
	route();

	if(thisHeader->shcerr != SH_IGNORE && shcmsgIsRequest(&thisHeader->msg))	//	---	R030212
	{
		thisShcApp->shcNetworkMsgHelperObj->shcCreateEvent(thisHeader);
	}

	
	flush_mb_cache();
	
	return(ret);
	
}




