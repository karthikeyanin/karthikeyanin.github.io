static char _ShcDualSiteRetryReversalEvent_cxx_what[] = "@(#)ShcDualSiteRetryReversalEvent.cxx 1.1 20/07/08 00:37:22";

/*
 *  Copyright (C) 2004 eFunds Corporation ("eFunds").  All Rights Reserved.     
 *  eFunds Canada Corporation is an authorized user.                            
 *                                                                              
 *  IST is a registered trademark of eFunds Corporation.  Other brand or        
 *  product names are trademarks or registered trademarks of their respective   
 *  holders.                                                                    
 *                                                                              
 *  The information contained herein is the unpublished proprietary property    
 *  of eFunds.  Except as specifically authorized in writing by eFunds, the     
 *  holder of this document shall: i) keep all information contained herein     
 *  confidential, and ii) protect the information, in whole or in part, from    
 *  disclosure and dissemination to all third parties.                          
 *                                                                          
 *  This document and the software described in it are furnished under license  
 *  and may be used or copied only in accordance with the terms of such license.
 *  This document is supplied for information purposes only, is subject to      
 *  change without notice, and should not be construed as a commitment by       
 *  either eFunds Corporation or eFunds Canada Corporation. 
 *
 *
 *
 *                        MODIFICATION HISTORY                  REVIEW
 *
 *	SPR#	Who	Date	Description			Who	Date   
 * ===========================================================================
 */


#include <ShcDualSiteRetryReversalEvent.h>
#include <ShcApp.h>
#include <ShcmsgTxnHelper.h>

int ShcDualSiteRetryReversalEvent::enrich()
{
	return 0;
}

int ShcDualSiteRetryReversalEvent::doWork()
{
	OTraceDebug( "D-SHC-29001 dual site retry reversal event - queing message for a second pass\n" );
	header->msg.respcode = 0;
	if ( thisShcApp->shcmsgTxnHelperObj->enqueueInternalMsg(header) == NULL )
		OTraceError("E-SHC-29002 unable to enqueue message into internal queue\n");

	return 0;
}
