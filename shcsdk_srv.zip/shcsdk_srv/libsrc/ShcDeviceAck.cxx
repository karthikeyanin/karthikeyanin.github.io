static char _ShcDeviceAck_cxx_what[] = "@(#) ShcDeviceAck.cxx 1.2 04/08/24 17:53:48";

/*
 *  Copyright (C) 2004 eFunds Corporation ("eFunds").  All Rights Reserved.     
 *  eFunds Canada Corporation is an authorized user.                            
 *                                                                              
 *  IST is a registered trademark of eFunds Corporation.  Other brand or        
 *  product names are trademarks or registered trademarks of their respective   
 *  holders.                                                                    
 *                                                                              
 *  The information contained herein is the unpublished proprietary property    
 *  of eFunds.  Except as specifically authorized in writing by eFunds, the     
 *  holder of this document shall: i) keep all information contained herein     
 *  confidential, and ii) protect the information, in whole or in part, from    
 *  disclosure and dissemination to all third parties.                          
 *                                                                          
 *  This document and the software described in it are furnished under license  
 *  and may be used or copied only in accordance with the terms of such license.
 *  This document is supplied for information purposes only, is subject to      
 *  change without notice, and should not be construed as a commitment by       
 *  either eFunds Corporation or eFunds Canada Corporation. 
 */
/*
 *
 *                        MODIFICATION HISTORY                  REVIEW
 *
 *	SPR#	Who	Date	Description			Who	Date   
 * ===========================================================================
 *	ad		24nov92		Added logic to route an ACK
 *	ad		05mar94		If no 9000 pending then just stop processing.
 *  la      12may96     Patch recommened from support (dk) for mailbox events.
 *  wrg     961115      Added forward-NAK support
 *  wrg     961204      Added support for timer-segment ops 
 *  yh R001564 23Mar99  Also use new_amount for partial reversal
 *  R007062	gbeeng	26Nov2001	C++ Migration
 */

//File Number 68

#include <stdio.h>
#include <string.h>
#include <oasis.h>
#include <ist_otrace.h>
#include <mb.h>
#include <shc.h>
#include <tm.h>

#include <ShcDeviceAck.h>
#include <ShcDeviceAckHelper.h>
#include <ShcmsgHelper.h>
#include <ShcApp.h>


/*****************************************************************************/
int ShcDeviceAck::doWork()
{
	/*
	 *	The device has acked a transaction
	 *
	 *	1.	The transaction is still in queue
	 *	2.	The device is only capable of delivering a trace and a message type
	 *	3.	There is also an error code
	 */
	
	if ( thisShcApp->shcDeviceAckHelperObj->removeAckEvent(header) < 0 )
		return (-1);

	thisShcApp->shcDeviceAckHelperObj->sendAck2Issuer(header);

	thisShcApp->shcDeviceAckHelperObj->generate500Msg(header);
	
	return(0);
}

	



