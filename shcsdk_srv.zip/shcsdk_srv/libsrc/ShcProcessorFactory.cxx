static char _ShcProcessorFactory_cxx_what[] = "@(#) ShcProcessorFactory.cxx 1.9.1.5 19/10/25 22:00:28";

/*
 *  Copyright (C) 2004 eFunds Corporation ("eFunds").  All Rights Reserved.
 *  eFunds Canada Corporation is an authorized user.
 *
 *  IST is a registered trademark of eFunds Corporation.  Other brand or
 *  product names are trademarks or registered trademarks of their respective
 *  holders.
 *
 *  The information contained herein is the unpublished proprietary property
 *  of eFunds.  Except as specifically authorized in writing by eFunds, the
 *  holder of this document shall: i) keep all information contained herein
 *  confidential, and ii) protect the information, in whole or in part, from
 *  disclosure and dissemination to all third parties.
 *
 *  This document and the software described in it are furnished under license
 *  and may be used or copied only in accordance with the terms of such license.
 *  This document is supplied for information purposes only, is subject to
 *  change without notice, and should not be construed as a commitment by
 *  either eFunds Corporation or eFunds Canada Corporation.
 *
 *
 *                        MODIFICATION HISTORY                  REVIEW
 *
 * SCR#     Who    Date  Description
 * ===========================================================================
 * R0xxxxx
 * R020052  spa	   21May07 Added cases for FM messages
 * R020938	spa	   16Aug07 IST LM Bridge support
 * R023105	sel	   13May08 LM message routing between nodes
 */

//File Number 113

//#include <shc.h>
//#include <shcdef.h>
//#include <shcextbuf.h>
//
//#include <ShcSdkCommon.h>
//#include <ShcHeader.h>
#include <shc.h>
#include <Shc300Log.h>
#include <Shc600Log.h>
#include <ShcApp.h>
#include <ShcAdminProcessor.h>
#include <ShcnetProcessor.h>
#include <Shc300Processor.h>
#include <ShcmsgHeader.h>
#include <ShcProcessorFactory.h>
#include <ShcnetPortProcessor.h>
#include <ShcSdkLog.h>
#include <ShcFMDecisionProcessor.h>	//	---	R020052
#include <ShcODDecisionProcessor.h>
#include <FMCMDProcessor.h>		//	---	R020052

int ShcProcessorFactory::createCondition(char *condition, const void *msg)
{
	struct shcmsg *tmpmsg = (struct shcmsg *)msg;

	sprintf(condition, "%4.4d%c", tmpmsg->msgtype%10000, thisShcApp->shcIsSwitch?'Y':'N');
	OTraceDebug("D-SHC-113001:condition[%s]\n", condition);

	return 0;
}

ShcProcessor *ShcProcessorFactory::getTargetObj(char *condition, const void *msgBuf)
{
	ShcProcessor *newProcessor = NULL;

		struct shcmsg *msgP = (struct shcmsg *)msgBuf;

		switch( msgP->msgtype/100 )
		{
		case	SHC_FINREQ/100:				/*	financial request message */
		case	SHC_AUTHREQ/100:
		case	SHC_REVREQ/100:
		case	SHC_DEVICE_ACK/100:
		case	SHC_PREAUTH_REQ/100:
		case	SHC_SERVICE_REQUEST/100:
		case	(SHC_FINREQ+SHC_EVENT)/100:				/*	financial request message */
		case	(SHC_AUTHREQ+SHC_EVENT)/100:
		case	(SHC_REVREQ+SHC_EVENT)/100:
		case	(SHC_DEVICE_ACK+SHC_EVENT)/100:
		case	SHC_FRS_ADVICE/100:
		case	(SHC_FRS_ADVICE+SHC_EVENT)/100:
		case	(SHC_OD_REQ+SHC_EVENT)/100:	//	---	R020052
		case	(SHC_FM_REQ+SHC_EVENT)/100:	//	---	R020052
		case	(SHC_LM_REQ+SHC_EVENT)/100:	//	---	R020938
		case	SHC_STLMTREQ/100:
		case	(SHC_STLMTREQ+SHC_EVENT)/100:
			newProcessor = new ShcmsgProcessor((char *)msgP);
			if( newProcessor )
			{
				newProcessor->header->shcLogObj = thisShcApp->shcmsgLogObj; //new ShcSdkLog;
				OTraceDebug("D-SHC-113002: ShcProcessor::classify() newProcessor[%p], shcLogObj[%p]\n",
						newProcessor, newProcessor->header->shcLogObj );
			}
			else
				OTraceError("E-SHC-113003: Failed in classify() \n" );

			return newProcessor;
			break;

		case	SHC_ADMIN/100:
		case	(SHC_ADMIN+SHC_EVENT)/100:
			newProcessor = new ShcAdminProcessor((char *)msgBuf);
			if (newProcessor)
			{
				if (newProcessor->header)
				{
					msgP = &((ShcmsgHeader *)(newProcessor->header))->msg;
					if (msgP->netcode == 174)
						newProcessor->header->shcLogObj = thisShcApp->shcmsgLogObj;
					else
						newProcessor->header->shcLogObj = thisShcApp->shc600LogObj;
				}
			}
			return newProcessor;

		case	(SHC_NETWORK + SHC_EVENT)/100:
		case	(SHC_KEY_GRACE_PERIOD + SHC_EVENT)/100:
			if (thisShcApp->shcIsSwitch)
				newProcessor = new ShcmsgProcessor((char *)msgP);
			else
			{
				msgP->msgtype -= SHC_EVENT;
				msgP->shc_devcap |= SH_DEVCAP_SHC_EVENT;
				newProcessor = new ShcnetProcessor((char *)msgP);
				newProcessor->header->shcLogObj = thisShcApp->shcmsgLogObj; //new ShcSdkLog;
			}
			return newProcessor;

		case	SHC_NETWORK/100:
		case	SHC_KEY_GRACE_PERIOD/100:
			if (thisShcApp->shcIsSwitch)
				newProcessor = new ShcmsgProcessor((char *)msgP);
			else
				newProcessor = new ShcnetProcessor((char *)msgP);
			newProcessor->header->shcLogObj = thisShcApp->shcmsgLogObj; //new ShcSdkLog;
			return newProcessor;
		case	SHC_NETWORK_PORT_NOTIFICATION/100:
			newProcessor = new ShcnetPortProcessor((char *)msgP);
			
			return newProcessor;
			break;

		case	SHC_FILEUPD_ISSREQ/100:
		case	(SHC_FILEUPD_ISSREQ+SHC_EVENT)/100:
			newProcessor = new Shc300Processor((char *)msgP);
			if (newProcessor)
				newProcessor->header->shcLogObj = thisShcApp->shc300LogObj;
			return newProcessor;

		case	SHC_OD_RESP/100:
				newProcessor = new ShcODDecisionProcessor((char *)msgP);
			return newProcessor;

			break;
		//	>>>	R020052
		case	SHC_FM_RESP/100:
		case	SHC_LM_RESP/100:	//	---	R020938
			//	>>>	R023105
			if (shcmsgIsRequest(msgP))
				newProcessor = new ShcmsgProcessor((char *)msgP);
			else
				newProcessor = new ShcFMDecisionProcessor((char *)msgP);
			//	<<<	R023105
			if( newProcessor )
				OTraceDebug("D-SHC-113005: ShcProcessor::classify() newProcessor[%p]\n",
						newProcessor);
			return newProcessor;
			break;

		case	SHC_FM_CMD_REQ/100:
		case	SHC_FM_INST_REQ/100:
			newProcessor = new FMCMDProcessor((char *)msgP);
			return newProcessor;
		//	<<<	R020052
		case SHC_ISTAUTH_FILE_UPD_REQ/100:
		case (SHC_ISTAUTH_FILE_UPD_REQ+SHC_EVENT)/100:
			newProcessor = new ShcmsgProcessor((char *)msgP);
			if( newProcessor )
			{
				newProcessor->header->shcLogObj = thisShcApp->shcmsgLogObj;
				OTraceDebug("D-SHC-113006: ShcProcessor::classify() newProcessor[%p], shcLogObj[%p]\n",
						newProcessor, newProcessor->header->shcLogObj );
			}
			else
				OTraceError("E-SHC-113006: Failed in classify() \n" );
			return newProcessor;
		break;

		case SHC_STANDIN_DECISION_BY_ISS_RESP_NOTIFICATION_EVENT/100:
			newProcessor = new ShcmsgProcessor((char *)msgP);
			if( newProcessor )
			{
				newProcessor->header->shcLogObj = thisShcApp->shcmsgLogObj;
				OTraceDebug("D-SHC-113007: ShcProcessor::classify() newProcessor[%p], shcLogObj[%p]\n",
						newProcessor, newProcessor->header->shcLogObj );
			}
			else
				OTraceError("E-SHC-113007: Failed in classify() \n" );
			return newProcessor;
		break;

		default:
			OTraceDebug("D-SHC-113004: Can not classify processor for [%04d]\n", msgP->msgtype );
			return NULL;
			break;
		}


}


