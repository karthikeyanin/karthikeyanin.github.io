static char _Shc500Helper_cxx_what[] = "@(#) Shc500Helper.cxx 1.8 16/05/10 12:20:52";

/*
 *  Copyright (C) 2004 eFunds Corporation ("eFunds").  All Rights Reserved.     
 *  eFunds Canada Corporation is an authorized user.                            
 *                                                                              
 *  IST is a registered trademark of eFunds Corporation.  Other brand or        
 *  product names are trademarks or registered trademarks of their respective   
 *  holders.                                                                    
 *                                                                              
 *  The information contained herein is the unpublished proprietary property    
 *  of eFunds.  Except as specifically authorized in writing by eFunds, the     
 *  holder of this document shall: i) keep all information contained herein     
 *  confidential, and ii) protect the information, in whole or in part, from    
 *  disclosure and dissemination to all third parties.                          
 *                                                                          
 *  This document and the software described in it are furnished under license  
 *  and may be used or copied only in accordance with the terms of such license.
 *  This document is supplied for information purposes only, is subject to      
 *  change without notice, and should not be construed as a commitment by       
 *  either eFunds Corporation or eFunds Canada Corporation. 
 *
 *
 *                        MODIFICATION HISTORY                  REVIEW
 *
 * SCR#     Who    Date  Description
 * ===========================================================================
 * R0xxxxx 
 */
 
 //File Number 51

#include <stdio.h>
#include <oasis.h>
#include <mb.h>
#include <tm.h>
#include <ist_otrace.h>
#include <shc.h>
#include <shcerror.h>
#include <shc_callback.h>
#include <ShcAppBase.h>
#include <ShcBaseTxn.h>
#include <Shc500Helper.h>
#include <ShcSender.h>
#include <ShcMsgCache.h>
#include <ShcApp.h>
#include <ShcBin.h>
#include <ShcSaf.h>
#include <ShcmsgTxnHelper.h>



int Shc500Helper::procStlmtEvent(ShcmsgHeader *header)
{
	/*
	 *	Handle a stlmt time out
	 */
	
	/*
	 *	Write transaction to stfwd file
	 */
	thisShcApp->shcSafHelperObj->shc_general_saf_write(NULL, header, 0);

	/*
	 *	Process a stfwd 500 Message And send reply (if any)
	 */
	header->msg.msgtype = SHC_STLMTREQ_RESPONSE;
	
//////////	shc_stlmtresp(header);
//////////	shc_route(header);

	if ( thisShcApp->shcmsgTxnHelperObj->enqueueInternalMsg(header) == NULL )
		OTraceError("E-SHC-051001: Unable to enqueueInternalMsg() in Shc500Event::procStlmtEvent()\n");;
	
	header->shcerr = SH_IGNORE;
	OTraceDebug("D-SHC-051002: The [%04d] message is changed to response and queued\n"
		, header->msg.msgtype);
	
	/*
	 *	o	Decide if we re-send or not
	 */
	if(shc_isdown(header->acqShcBin->binPkg))
		header->shcerr = SH_IGNORE;
	else
	{
		header->msg.msgtype = SHC_STLMTREQ_ADVICE;
		header->shcerr = SH_SETTIMER | SH_SENDACQ;
		if (shcEnableSubssecondTimeout)
			header->time_out = header->time_in + 1000*shcApp->issuerShcParamsList->GetNum((char *)"shc.saf_timeout");
		else
			header->time_out = header->time_in + shcApp->issuerShcParamsList->GetNum((char *)"shc.saf_timeout");
	}
	
	return(0);
}




