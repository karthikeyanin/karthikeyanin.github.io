/*
 *  Copyright (C) 2004 eFunds Corporation ("eFunds").  All Rights Reserved.
 *  eFunds Canada Corporation is an authorized user.
 *
 *  IST is a registered trademark of eFunds Corporation.  Other brand or
 *  product names are trademarks or registered trademarks of their respective
 *  holders.
 *
 *  The information contained herein is the unpublished proprietary property
 *  of eFunds.  Except as specifically authorized in writing by eFunds, the
 *  holder of this document shall: i) keep all information contained herein
 *  confidential, and ii) protect the information, in whole or in part, from
 *  disclosure and dissemination to all third parties.
 *
 *  This document and the software described in it are furnished under license
 *  and may be used or copied only in accordance with the terms of such license.
 *  This document is supplied for information purposes only, is subject to
 *  change without notice, and should not be construed as a commitment by
 *  either eFunds Corporation or eFunds Canada Corporation.
 *
 *
 *                        MODIFICATION HISTORY                  REVIEW
 *
 *	SPR#	Who	Date	Description			Who	Date
 * ===========================================================================
 *	R020052	spa	21May07	New file created
 *  R025639 vmp	16Jan09	Changes for FM PhaseII enhancement
 */
/* File Number 159 */

static char _FMInstList_cxx_what[] = "@(#) FMInstList.cxx 1.6 15/12/09 11:45:49";

#include <stdio.h>
#include <string.h>
#include <ctype.h>
#include <oasis.h>
#include <ist_otrace.h>
#include <shcdef.h>
#include <shc.h>
#include <FMInstList.h>
#include <ShcmsgFMHelper.h>


int FMInstList::process()
{
	int ret = 0;
	char buf[256];

	enrich();

	OTraceDebug("D-SHC-159001:FMInstList::process\n");

	if(!shcmsgFMHelperObj)
		shcmsgFMHelperObj = new ShcmsgFMHelper;

	if(shcmsgFMHelperObj->update_record(header->blockCMD.action, header->blockCMD.blockInfo) == -1)
	{
		OTraceError("E-SHC-159002:update inst list failed\n");
		ret = 1;
	}

	restore();
	edit();
	doWork();

	if(header->blockCMD.msgtype == SHC_FM_INST_REQ)
	{
		//	>>>	R025639
		if (header->blockCMD.action < 100)
		{
			mcastHelperObj->setHandlerID("shc");

			header->blockCMD.action += 100;
			mcastHelperObj->broadcast("shc", 0, (char *)&header->blockCMD , sizeof(header->blockCMD), NULL,0);
			header->blockCMD.action -= 100;
			OTraceDebug("I-SHC-159003: Institution List Broadcasted to the Nodes\n");
		}
		else
		{
			header->blockCMD.action -= 100;
			return 0;
		}
		//	<<<R025639
		header->blockCMD.msgtype = SHC_FM_INST_RESP;
		sprintf(header->blockCMD.respcode, "%02d", ret);//	----	R025639
		shcmsgFMHelperObj->sendCmdResp((char*)&header->blockCMD, sizeof(struct s_BlockCMD));
	}

	return 0;
}










