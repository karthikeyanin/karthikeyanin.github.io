static char _ShcmsgEventBO_cxx_what[] = "@(#) ShcmsgEventBO.cxx 1.7 05/05/16 13:52:51";

/*
 *  Copyright (C) 2004 eFunds Corporation ("eFunds").  All Rights Reserved.     
 *  eFunds Canada Corporation is an authorized user.                            
 *                                                                              
 *  IST is a registered trademark of eFunds Corporation.  Other brand or        
 *  product names are trademarks or registered trademarks of their respective   
 *  holders.                                                                    
 *                                                                              
 *  The information contained herein is the unpublished proprietary property    
 *  of eFunds.  Except as specifically authorized in writing by eFunds, the     
 *  holder of this document shall: i) keep all information contained herein     
 *  confidential, and ii) protect the information, in whole or in part, from    
 *  disclosure and dissemination to all third parties.                          
 *                                                                          
 *  This document and the software described in it are furnished under license  
 *  and may be used or copied only in accordance with the terms of such license.
 *  This document is supplied for information purposes only, is subject to      
 *  change without notice, and should not be construed as a commitment by       
 *  either eFunds Corporation or eFunds Canada Corporation. 
 *
 *
 *
 *                        MODIFICATION HISTORY                  REVIEW
 *
 *	SPR#	Who	Date	Description			Who	Date   
 * ===========================================================================
 * R0xxxxx jyang 09Dec03 Created
 */

//File Number 93

#include <ShcmsgEventBO.h>
#include <ShcApp.h>
#include <ShcmsgTxnHelper.h>
#include <ShcProcessor.h>
#include <ShcmsgEventHelper.h>
#include <ShcmsgHelper.h>

int ShcmsgEventBO::doWork()
{
//	if (shcmsg->msg.shc_devcap & SH_DEVCAP_SHC_BO_MASK)
//	{
//		shc_set_return_msgno(header);
		thisShcApp->shcmsgHelperObj->shc_set_return_msgno(&header->msg);
		header->msg.respcode = SHC_RC_IssuerTimeout;
		
//////		shc_backoffice_resp(header);
		ShcProcessor *newProcessor;
		if ( (newProcessor = thisShcApp->shcmsgTxnHelperObj->enqueueInternalMsg( header )) == NULL )
			OTraceError("E-SHC-093001: Unable to enqueueInternalMsg() in ShcmsgEventBO::doWork()\n");
		else
		{
			newProcessor->header->setSkipFlag(TXN_PROC_SKIP_ENRICH|TXN_PROC_SKIP_RESTORE);
			newProcessor->header->shcerr = SH_NO_TIMER_PRESENT;
		}
		
		header->shcerr = SH_IGNORE;
//	}
	
	//ShcmsgEvent::doWork();
	if ( ! header->shouldContinue(TXN_PROC_SKIP_DOWORK) )
		return False;
		
	if ( thisShcApp->shcmsgEventHelperObj->retryOnTimeout(header, shcBin) == True )
	{
		header->setSkipFlag();
		return False;
	}
	return True;
}
