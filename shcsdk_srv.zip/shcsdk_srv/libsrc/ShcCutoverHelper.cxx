/*
 *  Copyright (C) 2004 eFunds Corporation ("eFunds").  All Rights Reserved.     
 *  eFunds Canada Corporation is an authorized user.                            
 *                                                                              
 *  IST is a registered trademark of eFunds Corporation.  Other brand or        
 *  product names are trademarks or registered trademarks of their respective   
 *  holders.                                                                    
 *                                                                              
 *  The information contained herein is the unpublished proprietary property    
 *  of eFunds.  Except as specifically authorized in writing by eFunds, the     
 *  holder of this document shall: i) keep all information contained herein     
 *  confidential, and ii) protect the information, in whole or in part, from    
 *  disclosure and dissemination to all third parties.                          
 *                                                                          
 *  This document and the software described in it are furnished under license  
 *  and may be used or copied only in accordance with the terms of such license.
 *  This document is supplied for information purposes only, is subject to      
 *  change without notice, and should not be construed as a commitment by       
 *  either eFunds Corporation or eFunds Canada Corporation. 
 */
/*
 *
 *  MODIFICATION HISTORY                              REVIEW
 *
 *	SPR#	Who	Date	Description	                  Who	Date   
 * ===========================================================================
 *    R027855   mm      10Apr10 cutover_srv updates IBD DB
 *    R028271   dipa    18Jun10 Txn Statistics
 *    USP-1267  mm      27Jul10 Drink time
 *    R030207	dipa	06Feb12	Clone of R030212
 *    R030381   dipa	02Mar12	Use mb_set_tid() when a new shclogid is created
 *    R032391   dipa    19Dec13 Set ISS_INST_PROFILE_ENTRY for each member during automatic cutover
 */
#include <ist_seg_id.h>
#include <ShcCutoverHelper.h>
#include <InstProfile.h>
#include <IbdDrinkTime.h>
#include <ShcTimerHelper.h>
#include <ShcmsgHelper.h>
#include <ShcNetworkMsgHelper.h>
#include <ShcnetCutOverException.h>
#include <mb_umi.h>
#include <multi_institution.h>
#include <McastHelper.h>
#include <algorithm>
//R028271 >>>
#include <TxnStat.h>
//<<< R028271
#include <MRApplHelper.h>
#include <MRCutoverTagDefs.h>
#include <ist_seg_msg_replication_data.h>


void ShcCutoverHelper::setTxnSrc(char* ptr){ snprintf(header->msg.txnSrc,sizeof(header->msg.txnSrc),"%s",ptr); }
void ShcCutoverHelper::setEntityId(char* ptr){ snprintf(header->msg.entityId,sizeof(header->msg.entityId),"%s",ptr); }
void ShcCutoverHelper::setCutoverDate(char* ptr){ header->msg.cap_date = atol(ptr);}
void ShcCutoverHelper::setCutoverTimeAt(char* ptr){ header->msg.local_time = atol(ptr);} //when to cut
void ShcCutoverHelper::setCutoverTimeAt(long aTimeAt){ header->msg.local_time = aTimeAt;} //when to cut
void ShcCutoverHelper::setCutoverTypeRole(char *ptr){header->msg.from_acct = atol(ptr);}
void ShcCutoverHelper::setCutoverTypeRole(int flags){header->msg.from_acct = flags;}
void ShcCutoverHelper::setStatus(char *ptr){header->msg.format_code[0] = atol(ptr);}
void ShcCutoverHelper::setStatus(int aStatus){header->msg.format_code[0] = aStatus;}
void ShcCutoverHelper::setUTCSeconds(char *ptr){header->msg.serial_1 = atol(ptr);}
void ShcCutoverHelper::setIBDLocalTime(char *ptr){header->msg.serial_2 = atol(ptr);} //time in IBD
void ShcCutoverHelper::setTimeZone(char* ptr){snprintf(header->msg.acquirer_data,sizeof(header->msg.acquirer_data),"%s",ptr);}
void ShcCutoverHelper::setConfig(char* ptr){snprintf((char*)header->msg.formatter_use,sizeof(header->msg.formatter_use),"%s",ptr);}
void ShcCutoverHelper::setBatchId(char *ptr){header->msg.batch_id = atol(ptr);}
void ShcCutoverHelper::setBatchId(long aBatchId){header->msg.batch_id = aBatchId;}
void ShcCutoverHelper::setShclogId(char *ptr){snprintf(header->msg.shclog_id,sizeof(header->msg.shclog_id),"%s",ptr);}
void ShcCutoverHelper::setDrinkTimeStart(){ header->msg.checker_id = addSeconds(header->msg.local_time,-1*m_drink_before); }
void ShcCutoverHelper::setDrinkTimeEnd(){ header->msg.supervisor = addSeconds(header->msg.local_time,m_drink_after); }
void ShcCutoverHelper::setCutoverCmdFlags(int flags){ header->msg.pos_condition_code = flags; }
void ShcCutoverHelper::setInstType(char *ptr){strcpy(header->msg.filler1,ptr);}

void ShcCutoverHelper::setDrinkTimeStart(char* ptr){ header->msg.checker_id =atol(ptr);} //USP-1267
void ShcCutoverHelper::setDrinkTimeEnd(char* ptr){ header->msg.supervisor = atol(ptr);} //USP-1267

char* ShcCutoverHelper::getTxnSrc(){ return header->msg.txnSrc; }
char* ShcCutoverHelper::getEntityId(){ return header->msg.entityId; }
long  ShcCutoverHelper::getCutoverDate(){return header->msg.cap_date;}
long  ShcCutoverHelper::getCutoverTimeAt(){return header->msg.local_time;} //when to cut
long  ShcCutoverHelper::getCutoverTypeRole(){return header->msg.from_acct;}
char  ShcCutoverHelper::getStatus(){return header->msg.format_code[0];} 
char  ShcCutoverHelper::getStatusForPrint(){return (getStatus()?getStatus():'?');}
long  ShcCutoverHelper::getUTCSeconds(){return header->msg.serial_1;}
long  ShcCutoverHelper::getIBDLocalTime(){return header->msg.serial_2;} //time in IBD
char* ShcCutoverHelper::getTimeZone(){return header->msg.acquirer_data;}
char* ShcCutoverHelper::getConfig(){return (char*)header->msg.formatter_use;}
long  ShcCutoverHelper::getBatchId(){return header->msg.batch_id;}
char* ShcCutoverHelper::getShclogId(){return header->msg.shclog_id;}
long  ShcCutoverHelper::getDrinkTimeStart(){ return header->msg.checker_id; }
long  ShcCutoverHelper::getDrinkTimeEnd(){ return header->msg.supervisor; }
int   ShcCutoverHelper::getCutoverCmdFlags(){return header->msg.pos_condition_code; }
char* ShcCutoverHelper::getInstType(){return header->msg.filler1;}
long ShcCutoverHelper::getCounter(){return header->msg.life_cycle;}
ShcmsgHeader *ShcCutoverHelper::getHeader(){return header;}

int ShcCutoverHelper::isATMCutover() { return (header->msg.from_acct & IST_ROLE_ATM);};
int ShcCutoverHelper::isPOSCutover() { return (header->msg.from_acct & IST_ROLE_POS);};
int ShcCutoverHelper::isOtherCutover() { return (header->msg.from_acct & IST_ROLE_OTHER);};
int ShcCutoverHelper::isCombinedCutover() { return (isATMCutover() && isPOSCutover() && isOtherCutover());};

//on inst. cutover
int ShcCutoverHelper::getMainCutoverConfigPosition()
{
	if (header->msg.from_acct & IST_ROLE_ATM)
		return (int) CT_ATM_SEND_MAIN_CUTOVER;
	else if (header->msg.from_acct & IST_ROLE_POS)
		return (int) CT_POS_SEND_MAIN_CUTOVER;
	else
		return (int) CT_OTHER_SEND_MAIN_CUTOVER;
}
//on my cutover
int ShcCutoverHelper::getForceMemberCutoverConfigPosition()
{
	if (isCombinedCutover())
		return (int) CT_SEND_MEMBER_COMBINED_CUTOVER;
	else if (isATMCutover())
		return (int) CT_ATM_SEND_FORCE_MEMBER_CUTOVER;
	else if (isPOSCutover())
		return (int) CT_POS_SEND_FORCE_MEMBER_CUTOVER;
	else 
		return (int) CT_OTHER_SEND_FORCE_MEMBER_CUTOVER;
}
int ShcCutoverHelper::getCurrentBusinessDayType()
{
	if (header->msg.from_acct & IST_ROLE_ATM)
		return DT_ATM_CURRENT_BUSINESS_DAY;
	else if (header->msg.from_acct & IST_ROLE_POS)
		return DT_POS_CURRENT_BUSINESS_DAY;
	else
		return DT_OTHER_CURRENT_BUSINESS_DAY;
}
int ShcCutoverHelper::needsBatchIdUpdate(InstBusinessDay * myBusinessDay)
{
	return (((header->msg.from_acct & IST_ROLE_POS ) && myBusinessDay->keepsBatchId())? 1 :0);
}
int ShcCutoverHelper::needsCutoverMsgOnGroupCutover(InstBusinessDay *tmpBusDay){ 
	return 0;
}
int ShcCutoverHelper::needsCutoverMsgOnInstCutover(InstBusinessDay *tmpBusDay){ 

	if(needsBatchIdUpdate(tmpBusDay) 	//Not for PHC
	|| tmpBusDay->getStatus() == ST_TYPE_PASSIVE) //Not for passive members
		return 0;
	return 1;
}
//param instBusinessDay is of Switch or institution
int ShcCutoverHelper::needsBroadcastMyCutover(InstBusinessDay *instBusinessDay,int tmpCfgType){

	if (isReplicationFromOtherSite())
	{
		OTraceDebug("D-CUTHLP-0055: Not broadcast replicate msg to member.\n");
		return 0;
	}
	if(instBusinessDay->getOneCfg(getMainCutoverConfigPosition()) != 'Y') //in switch/inst record
	{
		char institution_id[11]={0};
		instBusinessDay->getInstId(institution_id);
		OTraceDebug("D-CUTHLP-0022: Institution [%s] does not cutover members: [%c] at pos %d.\n",
			institution_id, instBusinessDay->getOneCfg(tmpCfgType), getMainCutoverConfigPosition());	
		return 0;
	}
	return 1;
}

//!tmpBusDay - member's IBD
int ShcCutoverHelper::needsInstCutover(long limit_date, InstBusinessDay *tmpBusDay, int tmpCfgType, int tmpDateType){

	if ( (tmpBusDay->getOneCfg(tmpCfgType) == 'Y') //Cutover all IBDs
		  || ((tmpBusDay->getOneCfg(tmpCfgType) == 'L')  
			&& (tmpBusDay->getOneDate(tmpDateType) < limit_date)) //R027855
		)
		return 1;

	return 0;
}
int ShcCutoverHelper::isDBUpdate(){

	return ((header->msg.pos_condition_code & IS_CUTOVER_CMD_NO_DB)?0:1);
}
int ShcCutoverHelper::isCutoverCmdPHC(){

	return ((header->msg.pos_condition_code & IS_CUTOVER_CMD_PHC) ? 1:0);
}
int ShcCutoverHelper::isReplicationFromOtherSite(){
	return ((header->msg.pos_condition_code & IS_CUTOVER_CMD_MSG_REPL) ? 1:0);
}
int ShcCutoverHelper::isCutoverGroup(){
	if(getStatus()==ST_TYPE_GROUP)
		return 1;
	return 0;
}
int ShcCutoverHelper::isCutoverPassive(){
	if(getStatus()==ST_TYPE_PASSIVE)
		return 1;
	return 0;
}
int ShcCutoverHelper::isAcquirerCutover(){

	OTraceDebug("D-CUTHLP-0037: isAcquirerCutover E:[%s] ACQ:%c, Status[%c]\n",
		header->msg.entityId,(header->msg.from_acct &IST_ROLE_ACQ)?'Y':'N',getStatusForPrint());

	if((strlen(header->msg.entityId)==0)
		&& (header->msg.from_acct &IST_ROLE_ACQ)
		&& (header->msg.format_code[0]!= ST_TYPE_GROUP && header->msg.format_code[0]!= ST_TYPE_PASSIVE))
		return 1;

	return 0;
}
int ShcCutoverHelper::isIssuerCutover(){

	OTraceDebug("D-CUTHLP-0038: isIssuerCutover E:[%s] ISS:%c, Status[%c]\n",
		header->msg.entityId,(header->msg.from_acct &IST_ROLE_ISS)?'Y':'N',getStatusForPrint());

	if((strlen(header->msg.entityId)==0)
		&& (header->msg.from_acct &IST_ROLE_ISS)
		&& (header->msg.format_code[0]!= ST_TYPE_GROUP && header->msg.format_code[0]!= ST_TYPE_PASSIVE))
		return 1;

	return 0;
}
int ShcCutoverHelper::isSwitchCutover(){

	return ((header->msg.from_acct & IST_ROLE_SW)?1:0);
}
int ShcCutoverHelper::isInstCutover(){
	if (isSwitchCutover() || isAcquirerCutover() || isIssuerCutover())
		return 1;
	return 0;
}
//-------------------------------------------------------------------------------------------------------
void ShcCutoverHelper::printHeader(const char *txt, int result)
{
	OTraceInfo("I-CUTHLP-0001: %s "
		"ID:%s,Inst:%s, Ent:%s, Date:%08ld, Type:%06x, Status:%c,UTC:%ld,IBD Time:%06ld,"
		"TZ:%s,Cfg:%s,Batch:%d,At time:%06ld, Drink<%06ld,%06ld> Result:%d"
		"\n",
		txt?txt:"",
		getShclogId(),
		getTxnSrc(),
		getEntityId(),
		getCutoverDate(),
		getCutoverTypeRole(),
		getStatusForPrint(),
		getUTCSeconds(),
		getIBDLocalTime(),
		getTimeZone(),
		getConfig(),
		getBatchId(),
		getCutoverTimeAt(),
		getDrinkTimeStart(),
		getDrinkTimeEnd(),
		result
		);
}
void ShcCutoverHelper::debugCutoverFlag(){

	OTraceDebug("D-CUTHLP-0002: 0x%0x = %s%s%s""%s%s%s""%s%s%s%s""%s%s\n",
		header->msg.from_acct,
		(header->msg.from_acct & IST_ROLE_SW)?"SWITCH + ":"",
		(header->msg.from_acct & IST_ROLE_ISS)?"ISS ":"",
		(header->msg.from_acct & IST_ROLE_ACQ)?"ACQ ":"",
		(header->msg.from_acct & IST_ROLE_ATM)?"ATM ":"",
		(header->msg.from_acct & IST_ROLE_POS)?"POS ":"",
		(header->msg.from_acct & IST_ROLE_OTHER)?"Other ":"",
		(header->msg.from_acct & T_ROLE_CUTOVER)?"Cutover ":"",
		(header->msg.from_acct & T_ROLE_RECON)?"Recon ":"",
		(header->msg.from_acct & T_ROLE_RECON_ISSUER_COMBINED)?"Recon_Issuer_Combined ":"",
		(header->msg.from_acct & T_ROLE_CUTOVER_RECON_COMBINED)?"Cutover_Recon_Combined ":"",
		(isDBUpdate())?"DB ":"",
		(isCutoverCmdPHC())?"PHC ":""
		);
}
//----------------------------------------------------------------------------------------------------------
void ShcCutoverHelper::initialize_cfg()
{
	try{
		m_drink_before = thisShcApp->shcParams.getInst(getTxnSrc())->GetNum((char *)"shc.cutover_drink_time_before");
		if(m_drink_before<0) 
			m_drink_before=0;
		m_drink_after = thisShcApp->shcParams.getInst(getTxnSrc())->GetNum((char *)"shc.cutover_drink_time_after");
		if(m_drink_after<0) 
			m_drink_after=0;
	}
	catch (...){
		OTraceError("E-CUTHLP-0039: drink time access exception - ignored\n");
	}

	OTraceDebug("D-CUTHLP-0040: Read Drink time before:%d, after:%d.\n",m_drink_before,m_drink_after);

}

//---------------------------------------------------------------------------------------------------------
int ShcCutoverHelper::initialize(ShcApp* aShcApp, ShcmsgHeader* pHeader){

	thisShcApp = aShcApp;
	if(!thisShcApp){
		OTraceFatal("F-CUTHLP-0003: ShcApp NULL\n");
		return -1;
	}

	header = pHeader;
	if(!header){
		OTraceFatal("F-CUTHLP-0004: ShcmsgHeader NULL\n");
		return -1;
	}

	shc_get_current_date();

	return 0;
}
//---------------------------------------------------------------------------------------------------------
/**returns new time 
*/
long ShcCutoverHelper::addSeconds(long a_time, int a_seconds_diff)
{
	if(a_seconds_diff==0)
		return a_time;
	OCDateTime aDT(a_time/10000,(a_time/100)%100,a_time%100);
	aDT.addSeconds(a_seconds_diff);
	long res = aDT.hour()*10000 +aDT.minute()*100 +aDT.second();
	OTraceDebug("D-CUTHLP-0005: Start=%d, Diff=%d, New=%06ld\n",a_time,a_seconds_diff,res);
	return res;
}
//---------------------------------------------------------------------------------------------------------
void ShcCutoverHelper::update_SHM_group(InstBusinessDay * grpBusinessDay, long newDay)
{
	OTraceDebug("D-CUTHLP-0041: update_SHM_group start--- limit_date=%ld\n",newDay);
	static InstBusinessDay tmpBusDay;
	int aCounter=0;

	int tmpDateType = getCurrentBusinessDayType();

	for (tmpBusDay.getFirstEntry();tmpBusDay.isValid();tmpBusDay.getNextEntry())
	{
		if (tmpBusDay.isSwitch() || tmpBusDay.isMAIN_INST())
			continue;

		//only 'P'
		if((grpBusinessDay->isMyGroupId(&tmpBusDay)==1) && (tmpBusDay.getOneDate(tmpDateType) < newDay)){
			update_SHM_individual(&tmpBusDay,newDay);
			aCounter++;
		}
	}
	if(grpBusinessDay->getOneDate(tmpDateType) < newDay){ //USP-1439
		update_SHM_individual(grpBusinessDay, newDay);
		aCounter++;
	}
	OTraceInfo("I-CUTHLP-0042: update_SHM_group end--- updated %d records\n",aCounter);
}

//---------------------------------------------------------------------------------------------------------
void ShcCutoverHelper::update_SHM_individual(InstBusinessDay * myBusinessDay, long newDay)
{
	OTraceDebug("D-CUTHLP-0043: update_SHM_individual start---\n");
	if (header->msg.from_acct & IST_ROLE_ATM)
	{
		if (myBusinessDay->setOneDate(DT_ATM_CURRENT_BUSINESS_DAY , newDay) < 0)
		{
			OTraceError("E-CUTHLP-0006:Can't change mem business day for inst[%s] Entity [%s]\n", 
						header->msg.txnDest,
						header->msg.iss_entityId);
			throw ShcnetCutOverException();
		}
	}
	if (header->msg.from_acct & IST_ROLE_POS) 
	{
		if (myBusinessDay->setOneDate(DT_POS_CURRENT_BUSINESS_DAY , newDay) < 0)
		{
			OTraceError("E-CUTHLP-0007:Can't change mem business day for inst[%s] Entity [%s]\n", 
						header->msg.txnDest,
						header->msg.iss_entityId);
			throw ShcnetCutOverException();
		}
	}
	if (header->msg.from_acct & IST_ROLE_OTHER)
	{
		if (myBusinessDay->setOneDate(DT_OTHER_CURRENT_BUSINESS_DAY , newDay) < 0)
		{
			OTraceError("E-CUTHLP-0008:Can't change mem business day for inst[%s] Entity [%s]\n", 
						header->msg.txnDest,
						header->msg.iss_entityId);
			throw ShcnetCutOverException();
		}
	}
	// R021833 >>>>
	if(needsBatchIdUpdate(myBusinessDay)) //R027855
	{
		long batchId=0;
		update_SHM_batch_id(myBusinessDay,DT_POS_CURRENT_BUSINESS_DAY, NULL);
		myBusinessDay->getBatchId(&batchId);
		setBatchId(batchId);
	}
	else
		header->msg.life_cycle += 1;
	/* R027855 Done by notify_cutover_srv:
	if (myBusinessDay->commitToDB() < 0)
	{
		OTraceError("E-CUTHLP-0009:Can't change db business day for inst[%s] Entity [%s]\n", 
					header->msg.txnDest,
					header->msg.iss_entityId);
		throw ShcnetCutOverException();
	}
	*/
	OTraceDebug("D-CUTHLP-0044: update_SHM_individual end %d---\n",header->msg.life_cycle);
}

//---------------------------------------------------------------------------------------------------------
//send msg to Cutover Server to update database - for all SHM updates
int ShcCutoverHelper::notify_cutover_srv(InstBusinessDay * businessDay)
{
	OTraceDebug("D-CUTHLP-0045: notify_cutover_srv start---\n");

	int err = set_issuer_info(businessDay);
	if(err <0)
		return err;

	header->shcerr &= ~(SH_STOP|SH_SENDACQ|SH_IGNORE|SH_RETURN|SH_SENDAPPL);

	char data[41];	
	char Status;	
	int cutover_srv_mbid;

	businessDay->getBatchId(&header->msg.batch_id);

	businessDay->getTimeZoneId(data);
	setTimeZone(data);
	businessDay->getConfig(data);
	setConfig(data);

	setStatus(businessDay->getStatus()); //header->msg.format_code[0] = Status;

	businessDay->getInstType(data);
	setInstType(data);

	header->shcerr &= ~SH_SENDISS;

	cutover_srv_mbid = mb_locateoutbound("CutoverSrv");
	if (cutover_srv_mbid < 0)
	{
		OTraceFatal("F-CUTHLP-0010: Unable to locate CutoverSrv mailbox\n");
		header->shcerr = SH_IGNORE;
		return -2;
	}
	else
	{
		header->shcerr = SH_SENDAPPL;
		header->applMailboxId = cutover_srv_mbid;
	}

	char tmpLogId[sizeof(header->msg.shclog_id)];
	int tmpTrace = header->msg.trace;
	memcpy(tmpLogId, header->msg.shclog_id, sizeof(tmpLogId));

	//Use new trace and new log id for cutover server to prevent confliction with msg to member
	header->msg.trace = (header->msg.trace+500000)%1000000;
	mb_getUmi(header->msg.shclog_id, sizeof(header->msg.shclog_id));
	thisShcApp->shcTimerObj->shc_time_message_x( header, NULL);

	thisShcApp->shcmsgHelperObj->shc_route(header); //no ack from CuroverServer
	header->msg.trace = tmpTrace;
	memcpy(header->msg.shclog_id, tmpLogId, std::min<size_t>(sizeof(tmpLogId),sizeof(header->msg.shclog_id)));

	//R027855 header->msg.trace = shc_gentrace();
	OTraceDebug("D-CUTHLP-0046: notify_cutover_srv end---\n");
 
	return 0;
}
//---------------------------------------------------------------------------------------------------------
int ShcCutoverHelper::shc_prepare_cut_over(InstBusinessDay * businessDay)
{
	int err = set_issuer_info(businessDay);
	if(err <0)
		return err;

	businessDay->getBatchId(&header->msg.batch_id);
	header->shcerr &= ~(SH_STOP|SH_SENDACQ|SH_IGNORE|SH_RETURN|SH_SENDAPPL);
   	header->shcerr |= SH_SENDISS;

	return 0;
}
//---------------------------------------------------------------------------------------------------------
int ShcCutoverHelper::set_issuer_info(InstBusinessDay * businessDay){

	IssuerInfo issuerInfo;
	char inst_id[11];
	char entityId[31];
	char instType[30];		// R021833

	businessDay->getInstId(inst_id);
	businessDay->getEntityId(entityId);
	businessDay->getInstType(instType);
	OTraceInfo("I-CUTHLP-0011: Prepare Cutover for Inst [%s] Entity [%s] InstType[%s]\n", inst_id, entityId, instType);

	thisShcApp->instProfileObj->locateIssuerFromInstitution(inst_id, entityId, header->msg.msgtype, issuerInfo );
	if (!issuerInfo.foundIssuer())
	{
        thisShcApp->instProfileObj->locateIssuerFromInstitution("SWITCH", "", header->msg.msgtype, issuerInfo);
        if (!issuerInfo.foundIssuer())
        {
			OTraceError("E-CUTHLP-0012: Can't find issuer for institution [%s] entity [%s]\n", inst_id, entityId);
			return-1;
        }
        OTraceDebug("D-CUTHLP-0022:Use SWITCH entry to find the issuer in inst_profile\n");
	}
	snprintf(header->msg.issuer, sizeof(header->msg.issuer), "%s", issuerInfo.getIssuerBin());
	header->setIssShcBin(header->msg.issuer);
	snprintf(header->msg.acquirer, sizeof(header->msg.acquirer), "%s", issuerInfo.getIssuerBin());
	snprintf(header->msg.txnDest, sizeof(header->msg.txnDest), "%s", inst_id);
	snprintf(header->msg.txnSrc, sizeof(header->msg.txnSrc), "%s", inst_id);
	snprintf(header->msg.iss_entityId, sizeof(header->msg.iss_entityId), "%s", entityId);

	//R032391 >>>
	NetworkInfo networkInfo;
	InstitutionProfile instProfile = { 0 }; 
	thisShcApp->instProfileObj->locateNetworkInfo(header->msg.txnSrc, header->msg.txnDest, header->msg.iss_entityId, 
				header->msg.msgtype, header->msg.issuer, networkInfo);
	if (networkInfo.foundNetworkInfo())
	{
		memcpy(&instProfile, networkInfo.getInstProfileEntry(), sizeof(instProfile));
		OTraceDebug("D-CUTHLP-0022.1: Found InstProfile txnSrc[%s] txnDest[%s] issEntId[%s] msgType[%s]\n",
				instProfile.m_txnSrc, instProfile.m_txnDest, instProfile.m_iss_entityId, instProfile.m_msgType);
		OTraceDebug("D-CUTHLP-0022.2: memId[%s] FId[%s] ID[%d] instId[%s] keyParamStr[%s]\n",
				instProfile.m_member_ID, instProfile.m_F_ID, instProfile.id, instProfile.instId, instProfile.keyparamStr);
		header->setSegmentData((char *)&instProfile,
			sizeof(struct InstitutionProfile), NETWORK_DATA_REQ_id, ISS_INST_PROFILE_ENTRY);
		thisShcApp->shcmsgHelperObj->addRoutingInfoSegment( header, networkInfo );
	}
	else
		OTraceDebug("D-CUTHLP-0022.3: InstProfile record not found for txnSrc[%s] txnDest[%s] issEntId[%s] msgType[%d] iss[%s]\n",
			header->msg.txnSrc, header->msg.txnDest, header->msg.iss_entityId,header->msg.msgtype, header->msg.issuer);
	//R032391 <<<

	return 0;
}
//!called from shccmd
int ShcCutoverHelper::cmd_send_msg()
{
	if(header->msg.shclog_id[0]=='\0')
	{
		mb_getUmi(header->msg.shclog_id, sizeof(header->msg.shclog_id));
		mb_set_tid(header->msg.shclog_id, strlen(header->msg.shclog_id));
	}
	OTraceLog("L-CUTHLP-0013: Created ID[%s]\n", header->msg.shclog_id);

	//R028271 >>>
	TxnStatReport(header->msg.shclog_id,TS_SHC,TSR_CREATE,header->msg.msgtype,0,0);
	//<<< R028271

	IssuerInfo issuerInfo;
	char instid[100];
	struct  shcpkg  *pkg;
	OTraceInfo("I-CUTHLP-0014: process in the cutover command \n");
	shc_locate_issuer_from_institution(header->msg.txnSrc, header->msg.entityId, SHC_NETWORK, issuerInfo);

	if (!issuerInfo.foundIssuer())
	{
        shc_locate_issuer_from_institution("SWITCH", "", SHC_NETWORK, issuerInfo);
        if (!issuerInfo.foundIssuer())
        {
			printf("%s: Can't find issuer for Inst[%s] Entity[%s]\n",  getTxnSrc(), header->msg.txnSrc, header->msg.entityId);
			return(-1);
        }
        OTraceDebug("D-SHC-135025:Use SWITCH entry to find the issuer in inst_profile\n");
	}

	if(shc_locate_bin(&pkg, (char *)issuerInfo.getIssuerBin()) < 0)
	{
		printf("%s: Institution <%s> Bin <%s>is not valid.\n", getTxnSrc(), instid, issuerInfo.getIssuerBin());
		return(-1);
	}

	snprintf(header->msg.txnDest,sizeof(header->msg.txnDest), "%s",  header->msg.txnSrc);
	snprintf(header->msg.iss_entityId, sizeof(header->msg.iss_entityId), "%s", header->msg.entityId);
	snprintf(header->msg.issuer, sizeof(header->msg.issuer), "%s", issuerInfo.getIssuerBin());
	snprintf(header->msg.acquirer, sizeof(header->msg.acquirer), "%s", issuerInfo.getIssuerBin());
	snprintf(header->msg.originator, sizeof(header->msg.originator), "%s", shc_orgid);

	OTraceLog("L-CUTHLP-0015: Sent message ID[%s] m%04d/n%d\n", 
		header->msg.shclog_id, header->msg.msgtype, header->msg.netcode);

	m_shcBin = (ShcBin *)shcHelperRegister.getTargetObj(SHC_ShcBin);
	m_shcBin->setBinPkg(pkg);

	thisShcApp->shcNetworkMsgHelperObj->shc_send_800(header, m_shcBin);

	return 0;
}

//---------------------------------------------------------------------------------------------------------
//broadcast message to shccmd on other nodes
//the command: _cutover_no_db - shccmd has to build this message based on the data passed
//cap_date = date to be -1
//batch_id = batch_id -1
int ShcCutoverHelper::notify_other_nodes(InstBusinessDay * businessDay)
{
	char instType[30];

	businessDay->getInstType(instType);

	businessDay->getBatchId(&header->msg.batch_id);

	if(getIBDLocalTime()<=0){ //USP-1439
		if(getStatus()==0)
			setStatus(businessDay->getStatus()); //header->msg.format_code[0] = Status;
		if(isCutoverGroup()){
			if(isPOSCutover())
				header->msg.serial_2 = businessDay->getOneTime(TT_POS_MEMBER_FORCE_CUTOVER);
			else if(isATMCutover())
				header->msg.serial_2 = businessDay->getOneTime(TT_ATM_MEMBER_FORCE_CUTOVER);
			else if(isOtherCutover())
				header->msg.serial_2 = businessDay->getOneTime(TT_OTHER_MEMBER_FORCE_CUTOVER);
		}
	}

	OTraceInfo("I-CUTHLP-0016: Broadcast Cutover for Inst [%s] Entity [%s] InstType[%s] [%06x]\n", 
	header->msg.txnSrc, getEntityId(), instType,header->msg.from_acct);

	//_cutover_no_db
	char buf[1024];
	snprintf(buf, sizeof(buf), "shccmd _cutover_no_db \""
		"IX%-20s,II%s,EI%s,FA%06ld,CD%08ld,ST%d,US%d,CT%d,TZ%s,CF%s,BI%d,TS%d,TE%d"
		"\"\n",
		getShclogId(),
		header->msg.txnSrc,
		getEntityId(),
		getCutoverTypeRole(),
		header->msg.cap_date,
		(int)getStatus(), //header->msg.format_code[0],
		getUTCSeconds(),
		getIBDLocalTime(),
		getTimeZone(),
		getConfig(),
		getBatchId(),
		getDrinkTimeStart(),
		getDrinkTimeEnd()
	);
	int iii;
	int iiilen=strlen(buf);
	for(iii = 22;iii<iiilen;iii++)
		if (buf[iii] == ' ')
			buf[iii] = '@';

	OTraceDebug("D-CUTHLP-0017: notify_other_nodes: [%s]\n",buf);

		
	if (mcastHelperObj && mcastHelperObj->ready())
	{
		int tmpret = mcastHelperObj->broadcast("shccmd", 0, buf , strlen(buf), NULL, 0); 
		if (tmpret < 0){
			OTraceError("E-CUTHLP-0018:Error sending broadcast message\n");
			return -1;
		}
	}
	else
		OTraceDebug("D-CUTHLP-0019:broadcast not ready, no broadcast\n");
	
	return 0;
}

//phc_cutover like USPS batchclose:
//cutover all records, which have business day <= Switch business day
//consider drink times
//header->msg.txnDest is institution_id of the MIDs
//---------------------------------------------------------------------------------------------------------
int ShcCutoverHelper::processCutoverRequestCmdPHC()
{
	static InstBusinessDay businessDay;
	OTraceDebug("D-CUTHLP-0020: Pure Host Capture\n");

	debugCutoverFlag();

	if (businessDay.getEntryFromMem(header->msg.txnDest, header->msg.iss_entityId) < 0)
	{
		OTraceError("E-CUTHLP-0021:Can't find PHC businessDay entry inst[%s] Entity [%s]\n", 
					header->msg.txnDest, header->msg.iss_entityId);
		throw ShcnetCutOverException();
	}

	if(isDBUpdate())
		notify_other_nodes(&businessDay);

	notifyOtherSite(&businessDay);
	int tmpCfgType = CT_POS_SEND_MAIN_CUTOVER;
	int tmpDateType = DT_POS_CURRENT_BUSINESS_DAY;

	long limit_date = header->msg.cap_date;

	IBDDrinkTime *pIBDDrinkTime=NULL;

	char tmp_inst_id[11];
	InstBusinessDay tmpBusDay;

	for (tmpBusDay.getFirstEntry();tmpBusDay.isValid();tmpBusDay.getNextEntry())
	{
		if (tmpBusDay.isSwitch() || tmpBusDay.isMAIN_INST())
			continue;

		tmpBusDay.getInstId(tmp_inst_id);

		if(strcmp(tmp_inst_id,header->msg.txnDest))
			continue;

		if(needsInstCutover(limit_date,&tmpBusDay, tmpCfgType, tmpDateType))
		{
			if(needsBatchIdUpdate(&tmpBusDay))
			{	
				if(pIBDDrinkTime==NULL) initialize_drink_time(&pIBDDrinkTime);
	
				update_SHM_batch_id(&tmpBusDay,tmpDateType, pIBDDrinkTime);

				continue;
			}
		}
	}

	delete pIBDDrinkTime;

	if(isDBUpdate()) 
		notify_cutover_srv(&businessDay);

	header->shcerr = SH_IGNORE;

	return 0;
} /* End of request processing */

//---------------------------------------------------------------------------------------------------------
//!!! There is a change: SWITCH cutover msg only if *_SEND_FORCE_MEMBER_CUTOVER turned on
//!!! SWITCH config *MAIN* drives if to cutover members or not!!!
//the same for ACQUIRER
int ShcCutoverHelper::memberCutover( InstBusinessDay *businessDay)
{
	OTraceDebug("D-CUTHLP-0047: memberCutover start---\n");
	int	msgPending = -1;
	int	position = -1;

	if(!isDBUpdate())
		return msgPending;

	//R027855 if (isSwitchCutover()) {
		//R027855 position = getMainCutoverConfigPosition();
	//R027855} else 
	//{
		/* member cutover */
		position = getForceMemberCutoverConfigPosition();
	//}

	switch (businessDay->getOneCfg(position))
	{
		case 'Y':
		case 'B':
			if (shc_prepare_cut_over(businessDay) >= 0)
				// header->shcerr = SH_SENDISS;
			msgPending = 1;
			break;
		default:
			break;
	}
	OTraceDebug("D-CUTHLP-0048: memberCutover end %d\n",msgPending);

	return (msgPending);
}

void ShcCutoverHelper::update_SHM_batch_id(InstBusinessDay *tmpBusDay,int tmpDateType, IBDDrinkTime *pIBDDrinkTime){

	if(pIBDDrinkTime){
		char a_tz[31]={0};
		tmpBusDay->getTimeZoneId(a_tz);
		long a_time=0;
		//PAI-744>>
		if(isPOSCutover())
			a_time = tmpBusDay->getOneTime(TT_POS_MEMBER_FORCE_CUTOVER);
		else if(isATMCutover())
			a_time = tmpBusDay->getOneTime(TT_ATM_MEMBER_FORCE_CUTOVER);
		else if(isOtherCutover())
			a_time = tmpBusDay->getOneTime(TT_OTHER_MEMBER_FORCE_CUTOVER);
		//PAI-744<<

		if(pIBDDrinkTime->isDrinkTime(a_tz,a_time))
			return;
	}

	long batchId=0;
	tmpBusDay->getBatchId(&batchId);
	batchId += mbIsDualSite() ? 2 : 1;
	tmpBusDay->setBatchId(&batchId);
	header->msg.life_cycle += 1;

	if(ist_otrace_get_level()>OTRACE_INFO){

		static char  institution_id[11]={0};
		tmpBusDay->getInstId(institution_id);
		static char entity_id[31]={0};
		tmpBusDay->getEntityId(entity_id);
		OTraceDebug("D-CUTHLP-0049: update_SHM_batch_id I[%s] E[%s] B[%ld] Count[%ld]\n",institution_id,entity_id,batchId,header->msg.life_cycle);
	}
}
//---------------------------------------------------------------------------------------------------------
/** This is MIAN_INST member cutover.
If Main institution MAIN_CUTOVER is on, then cutover members
//added param instBusinessDay
*/
void ShcCutoverHelper::broadcastCutover(InstBusinessDay *instBusinessDay)
{
	int tmpCfgType = getMainCutoverConfigPosition();

	if(!needsBroadcastMyCutover(instBusinessDay,tmpCfgType))
		return;

	OTraceDebug("D-CUTHLP-0050: broadcastCutover start---\n");
	InstBusinessDay tmpBusDay;
	int tmpDateType = getCurrentBusinessDayType();
	long trace_save = header->msg.trace;	//	R018093
	int is_acquirer_cutover = isAcquirerCutover();
	char tmp_inst_id[11];
	char acq_inst_id[11];
	if(is_acquirer_cutover)
		instBusinessDay->getInstId(acq_inst_id);

	IBDDrinkTime *pIBDDrinkTime=NULL;
	long limit_date = instBusinessDay->getOneDate(tmpDateType);
    
	for (tmpBusDay.getFirstEntry();tmpBusDay.isValid();tmpBusDay.getNextEntry())
	{
		if (tmpBusDay.isSwitch() || tmpBusDay.isMAIN_INST())
			continue;

		if(is_acquirer_cutover) {
			tmpBusDay.getInstId(tmp_inst_id);
			if(strcmp(tmp_inst_id,acq_inst_id))
				continue;
		}

		if(needsInstCutover(limit_date,&tmpBusDay, tmpCfgType, tmpDateType)){

			if(needsBatchIdUpdate(&tmpBusDay))
			{	
				if(pIBDDrinkTime==NULL ) initialize_drink_time(&pIBDDrinkTime);

				update_SHM_batch_id(&tmpBusDay,tmpDateType, pIBDDrinkTime);

			}
			if(needsCutoverMsgOnInstCutover(&tmpBusDay) && isDBUpdate()){

				 send_msg_to_member(&tmpBusDay);
			}
		 }
	 }

	header->shcerr = SH_IGNORE;	//	R018093
	header->msg.trace = trace_save;	//	R018093
	OTraceDebug("D-CUTHLP-0060: broadcastCutover end---\n");
}


void ShcCutoverHelper::send_msg_to_member(InstBusinessDay *tmpBusDay){

	if (shc_prepare_cut_over(tmpBusDay) >= 0)
	{
		char tmpLogId[sizeof(header->msg.shclog_id)];
		memcpy(tmpLogId, header->msg.shclog_id, sizeof(tmpLogId));

		//Use new trace and new log id for cutover server to prevent confliction with msg to member
		mb_getUmi(header->msg.shclog_id, sizeof(header->msg.shclog_id));

		struct RoutingInfo r={0};
		thisShcApp->shcmsgHelperObj->shc_route(header);
		header->setSegmentData((char*)&r, sizeof(r), NETWORK_DATA_REQ_id, ROUTING_INFO);
		
		if(shcIsRequest(header)) 
		{
			thisShcApp->shcTimerObj->shc_set_timers(header);
			thisShcApp->shcNetworkMsgHelperObj->shcCreateEvent(header);
		}
		//header->shcerr = SH_SENDISS;		//	R018093
		header->msg.trace = shc_gentrace();	//	R018093
	}
}

//---------------------------------------------------------------------------------------------------------
void ShcCutoverHelper::getMySHMRecord(InstBusinessDay *businessDay){
	if (isSwitchCutover())
	{
		if (businessDay->getMainInstEntryFromMem() < 0)
		{
			OTraceError("E-CUTHLP-0023:Can't find businessDay entry main inst\n");
			throw ShcnetCutOverException();
		}
	}
	else
	{
		if (businessDay->getEntryFromMem(header->msg.txnDest,
										header->msg.iss_entityId) < 0)
		{
			OTraceError("E-CUTHLP-0024:Can't find businessDay entry inst[%s] Entity [%s]\n", 
						header->msg.txnDest, header->msg.iss_entityId);
			throw ShcnetCutOverException();
		}
	}
}
//---------------------------------------------------------------------------------------------------------
	//get IBD SHM ptr
	//notify_other_nodes
	//update SHM
	//notify_cutover_srv
	//prepare my message to net
int ShcCutoverHelper::processCutoverRequestStandard()
{
	static InstBusinessDay businessDay;
	debugCutoverFlag(); //debug!!!

	getMySHMRecord(&businessDay);

	if(isDBUpdate())
		notify_other_nodes(&businessDay);

	notifyOtherSite(&businessDay);

	long origCapDate = header->msg.cap_date;
	long newDay = shc_adjust_date(header->msg.cap_date, 1);

	header->msg.cap_date = newDay; // watch out recon

	if(businessDay.getStatus() == ST_TYPE_GROUP)
		update_SHM_group(&businessDay, newDay);
	else //USP-1439
	update_SHM_individual(&businessDay, newDay);
	
	if(header->msg.netcode / 1000 != 9)
	{
		if(isDBUpdate()) {
			notify_cutover_srv(&businessDay);

			thisShcApp->shcmsgHelperObj->shc_set_return_msgno(&header->msg);
			if (header->msg.senderid > 0)
				header->shcerr = SH_RETURN;
			else
				header->shcerr = SH_IGNORE;
		}
		else
			header->shcerr = SH_IGNORE;
	}
	else
	{
		header->shcerr = SH_IGNORE;
		int msgPending = 0;

		if (isSwitchCutover()) {
			/* Institution cutover, may need to broadcast to everybody */
			broadcastCutover(&businessDay);	//cutover children
		}

		if(isDBUpdate()) 
			notify_cutover_srv( &businessDay);

		if ( isReplicationFromOtherSite() )
			header->shcerr = SH_IGNORE; //no need to send msg to net
		else if(memberCutover(&businessDay)!=1)
			header->shcerr = SH_IGNORE; //no need to send msg to net

	} /* End of cutover-start */

	return 0;
}
//---------------------------------------------------------------------------------------------------------
int ShcCutoverHelper::processCutoverRequest()
{
	header->msg.life_cycle=0;
	try
	{
		if(isCutoverCmdPHC()){
			OTraceDebug("D-CUTHLP-0025: Pure Host Capture\n");
			return processCutoverRequestCmdPHC();
		}
		else {
			//OTraceDebug("D-CUTHLP-0025: Cutover\n");
			return processCutoverRequestStandard();
		}

	} 
	catch (ShcnetCutOverException &e)
	{
		if (header->msg.senderid > 0)
		{
			header->msg.respcode = SHC_RC_InvalidTransaction;
			if(!shcIsResponse(header))
				thisShcApp->shcmsgHelperObj->shc_set_return_msgno(&header->msg);
			header->shcerr = SH_RETURN;
		}
		else
			header->shcerr = SH_IGNORE;
		return 0;
	}

	return 0;
} /* End of request processing */
//R027855>> }
//---------------------------------------------------------------------------------------------------------
//                                 SHCCMD
//---------------------------------------------------------------------------------------------------------
//!called from shccmd
int ShcCutoverHelper::cmd_process_cutover_no_db(int arg_c, char** arg_v)
{
	cmd_initialize();
	if(cmd_parse_args_cutover_no_db(arg_c, arg_v)<0)
		return -1;
	if(cmd_send_msg()<0)
		return -1;

	return (0);
}

//!called from shccmd
int ShcCutoverHelper::cmd_process_phc_cutover(int arg_c, char** arg_v)
{
	cmd_initialize();
	if(cmd_parse_args_phc_cutover(arg_c,arg_v)<0)
		return -1;
	if(cmd_send_msg()<0)
		return -1;

	return (0);
}

void ShcCutoverHelper::cmd_initialize(){

	static int init_cmd_cfg=0;
	if(init_cmd_cfg==0){
		ShcInstParamsList shcParamsList;
		shcParamsList.Add("shc.cutover_drink_time_before",PI_NUMBER);
		shcParamsList.Add("shc.cutover_drink_time_after",PI_NUMBER);
		thisShcApp->shcParams.Load(shcParamsList);
		init_cmd_cfg=1;
	}

	memset(&header->msg, 0, sizeof(struct shcmsg));
	memset(&header->segment, 0, sizeof(header->segment));
	header->msg.msgtype = SHC_NETWORK;
	header->msg.netcode = SHC_NET_CUTOVER_START;
}

//!called from shccmd
int ShcCutoverHelper::cmd_parse_args_phc_cutover(int arg_c, char** arg_v)
{
	char *usage = (char *)"phc_cutover -i InstId [-e EntityId] [-d Date {YYYYMMDD}] [-bt skip_seconds_before {SSS}] [-at skip_seconds_after {SSS}]";

	if(arg_c < 3)
	{
		printf("Usage: %s %s\n", arg_v[0], usage);
		return(-1);
	}

	char buffer[1024] = {0};
	snprintf(buffer, sizeof(buffer),"%s",arg_v[1]);
	char delim[]=" \t";

	char *p = strtok( buffer, delim );
	if(!p){
		OTraceError("E-CUTHLP-0026: Incorrect arg [%s]\n",buffer);
		printf("Usage: %s %s\n", arg_v[0], usage);
		return(-1);
	}
	int err = 0;
	initialize_cfg();

	int ix = 1;
	while(ix<arg_c)
	{
		//printf("My param: %s\n",arg_v[ix]);

		if(arg_v[ix][0]=='-' && arg_v[ix][1]=='a' && arg_v[ix][2]=='t'){
			p = arg_v[++ix];
			if(ix>=arg_c){
				err = -5;
				OTraceError("E-CUTHLP-0027: before time limit missing\n");
				break;
			}
			m_drink_after=atol(p);
		}
		else if(arg_v[ix][0]=='-' && arg_v[ix][1]=='b' && arg_v[ix][2]=='t'){
			p = arg_v[++ix];
			if(ix>=arg_c){
				err = -6;
				OTraceError("E-CUTHLP-0028: after time limit missing\n");
				break;
			}
			m_drink_before=atol(p);
		}
		else if(arg_v[ix][0]=='-' && arg_v[ix][1]=='i'){
			p = arg_v[++ix];
			if(ix>=arg_c){
				err = -1;
				OTraceError("E-CUTHLP-0029: Institution ID missing\n");
				break;
			}
			setTxnSrc(p);
		}
		else if(arg_v[ix][0]=='-' && arg_v[ix][1]=='e'){
			p = arg_v[++ix];
			if(ix>=arg_c){
				err = -2;
				OTraceError("E-CUTHLP-0030: Entity ID missing\n");
				break;
			}
			setEntityId(p);
		}
		else if(arg_v[ix][0]=='-' && arg_v[ix][1]=='d'){
			p = arg_v[++ix];
			if(ix>=arg_c){
				err = -3;
				OTraceError("E-CUTHLP-0031: Date missing\n");
				break;
			}
			setCutoverDate(p);
		}
		else 
			printf("Unsupported arg[%s]\n",arg_v[ix]);
		ix++;
	}

	if(err <0 || strlen(getTxnSrc())==0 )
	{
		printf("Usage: %s %s\n", arg_v[0], usage);
		OTraceError("E-CUTHLP-0033: phc_cutover err:%d.\n",err);
		return(-1);
	}


	if(header->msg.cap_date<=0)
		header->msg.cap_date = shc_local_currentdate();

	err = check_cap_date(header->msg.cap_date);
	if(err == -1)
		return err;

	header->msg.cap_date = shc_adjust_date(header->msg.cap_date, 1);

	setCutoverTimeAt(shc_local_currenttime());

	setDrinkTimeStart();
	setDrinkTimeEnd();

	setCutoverCmdFlags(IS_CUTOVER_CMD_PHC);
	setCutoverTypeRole(IST_ROLE_ACQ|IST_ROLE_POS); //or new role PHC?

	printHeader("cmd_parse_args_phc_cutover");

	return 0;
}
//!called from shccmd
int ShcCutoverHelper::cmd_parse_args_cutover_no_db(int arg_c, char** arg_v)
{
	char *usage = (char *)"_cutover_no_db command not to be used from the command line";
	//shccmd _cutover_no_db "IX12345678900987654321,IIUSPS,EItest_mm1,FA004114,CD20100304,ST0,US1267571825,CT171705,TZ,CFNNNNNNN XYXNNNNN                        ,BI0,TS121210,TE121425"

	setCutoverCmdFlags(IS_CUTOVER_CMD_NO_DB);

	if(arg_c != 2)
	{
		printf("Usage: %s %s\n", arg_v[0], usage);
		OTraceError("E-CUTHLP-xxxx:wrong command. 2[%s] 3[%s] 4[%s] 5[%s].\n", arg_c>2?arg_v[1]:"", arg_c>3?arg_v[2]:"", arg_c>4?arg_v[3]:"", arg_c>5?arg_v[4]:"");
		return(-1);
	}

	char buffer[1024] = {0};
	snprintf(buffer, sizeof(buffer),"%s",&arg_v[1][0]);
	char delim[]=",";

	int iii;
	int iiilen=strlen(buffer);
	for(iii = 0;iii<iiilen;iii++)
		if (buffer[iii] == '@')
			buffer[iii] = ' ';

	char *p = strtok( buffer, delim );
	if(!p){
		OTraceError("E-CUTHLP-0034: Incorrect arg [%s]\n",buffer);
	}

	do {
		//printf("My param: %s\n",p); 

		     if(p[0]=='I' && p[1]=='I') setTxnSrc(p+2); 
		else if(p[0]=='E' && p[1]=='I') setEntityId(p+2); 
		else if(p[0]=='F' && p[1]=='A') setCutoverTypeRole(p+2); 
		else if(p[0]=='C' && p[1]=='D') setCutoverDate(p+2); 
		else if(p[0]=='S' && p[1]=='T') setStatus(p+2); 
		else if(p[0]=='U' && p[1]=='S') setUTCSeconds(p+2); 
		else if(p[0]=='C' && p[1]=='T') setIBDLocalTime(p+2); 
		else if(p[0]=='T' && p[1]=='Z') setTimeZone(p+2); 
		else if(p[0]=='C' && p[1]=='F') setConfig(p+2); 
		else if(p[0]=='B' && p[1]=='I') setBatchId(p+2); 
		else if(p[0]=='T' && p[1]=='S') setDrinkTimeStart(p+2); 
		else if(p[0]=='T' && p[1]=='E') setDrinkTimeEnd(p+2); 
		else if(arg_v[1][0]=='I' && arg_v[1][1]=='X')
		{
			setShclogId(&p[2]);
		}
		else
			printf("Unsupported arg[%s]\n",p);
			

	} while ( (p = strtok( NULL, delim)) != NULL);

	OTraceLog("L-CUTHLP-0035: Received ID[%s]\n", header->msg.shclog_id);

	printHeader("cmd_parse_args_cutover_no_db");

	return 0;
}

//---------------------------------------------------------------------------------------------------------
void ShcCutoverHelper::initialize_drink_time(IBDDrinkTime **pIBDDrinkTime)
{
	if(*pIBDDrinkTime==NULL){
		*pIBDDrinkTime = new IBDDrinkTime;
		if(!*pIBDDrinkTime) {
			OTraceError("F-CUTHLP-0036: Unable create IBDDrinkTime\n");
			throw ShcnetCutOverException();
		}
	}
	initialize_cfg();
	if(getCutoverTimeAt()<=0)
		setCutoverTimeAt(shc_local_currenttime());

	if(getDrinkTimeStart()<=0)
		setDrinkTimeStart();
	if(getDrinkTimeEnd()<=0)
		setDrinkTimeEnd();

	(*pIBDDrinkTime)->initialize(
		header->msg.cap_date,	//date
		getDrinkTimeStart(),
		getDrinkTimeEnd()
	);
}

int ShcCutoverHelper::check_cap_date(long cut_date){

	shc_get_current_date();
	long today = shc_local_currentdate();
	long tomorrow = shc_adjust_date(today, 1);
	long yesterday = shc_adjust_date(today, -1);
	long yesterday2 = shc_adjust_date(today, -2);

	if( cut_date != tomorrow && cut_date != today && cut_date != yesterday && cut_date != yesterday2)
	{
		printf ("Invalid date: use %ld, %ld, %ld or %ld\n", yesterday2, yesterday, today, tomorrow );
		return(-1);
	}
	return 0;
}

int ShcCutoverHelper::notifyOtherSite(InstBusinessDay * businessDay){
	if( !isDBUpdate() )
		return 0;


	if ((header->msg.formatter_use[CT_DUAL_SITE_CUTOVER] != 'S') && 
		(businessDay->getOneCfg(CT_DUAL_SITE_CUTOVER) != 'S') &&
		(header->msg.netcode /1000 == 9))
	{
		OTraceDebug("D-CUTHLP-00:cutover config[%c], netcode[%d]. No replicate\n", 
			isalpha(header->msg.formatter_use[CT_DUAL_SITE_CUTOVER])?header->msg.formatter_use[CT_DUAL_SITE_CUTOVER]:'*', 
			header->msg.netcode);
		return 0;
	}

	if ( !isSwitchCutover() && !isAcquirerCutover() && !isIssuerCutover() && !isCutoverCmdPHC())
		return 0;

	if ( isReplicationFromOtherSite() ){
		OTraceDebug( "D-CUTHLP-0051 replication recieved from other site for inst[%s], entity[%s]. prevent loop back\n",
				header->msg.txnDest, header->msg.iss_entityId);
		return 0;
	}
	

	OTraceDebug( "D-CUTHLP-0051 notify cutover to other site for inst[%s], entity[%s]\n",
				header->msg.txnDest, header->msg.iss_entityId);

	OCString replService;
	OCString replData;
	MRApplHelper* mrHelper = MRApplHelper::getInstance(IST_MR_SERVICE_NAME_CUTOVER_SVC_TO_SW);
	mrHelper->reset();
	mrHelper->sendToSwitch = 1;
	mrHelper->setData(MR_TAG_INSTITUTION_ID, header->msg.txnDest);
	mrHelper->setData(MR_TAG_CAPTURE_DATE, header->msg.cap_date);
	if (isSwitchCutover())
	{
		mrHelper->setData(MR_TAG_INST_TYPE, "M");
	}
	else if ( isAcquirerCutover() && isIssuerCutover() ){
		mrHelper->setData(MR_TAG_INST_TYPE, "B");
	}else if ( isAcquirerCutover() ){
		mrHelper->setData(MR_TAG_INST_TYPE, "A");
	}else {
		mrHelper->setData(MR_TAG_INST_TYPE, "I");
	}

	if (header->msg.from_acct & IST_ROLE_ATM)
		mrHelper->setData(MR_TAG_ROLE_TYPE, "A");
	else if (header->msg.from_acct & IST_ROLE_POS)
		mrHelper->setData(MR_TAG_ROLE_TYPE, "P");
	else
		mrHelper->setData(MR_TAG_ROLE_TYPE, "O");

	if (isCutoverCmdPHC())
		mrHelper->setData(MR_TAG_ENTITY_ID, header->msg.entityId);

	mrHelper->getServiceName(replService);
	int ret = mrHelper->flattenData( replData);
	if ( ret < 0 ){
		OTraceError("E-CUTHLP-0050: replication failed. cannot flatten data for service[%s], inst[%s], entity[%s]\n",
			    IST_MR_SERVICE_NAME_CUTOVER, header->msg.txnDest, header->msg.iss_entityId );
		return -1;
	}
	OTraceDebug( "D-CUTHLP-0052 replication data prepared for cutover service [%s]\n", replService.data() );

	ret = header->appendReplicationData(replService.data(), replData.data(), replData.length() );
	if ( ret < 0 ){
		OTraceError("E-CUTHLP-0051: replication failed. cannot append data for service[%s], inst[%s], entity[%s]\n",
			    IST_MR_SERVICE_NAME_CUTOVER, header->msg.txnDest, header->msg.iss_entityId );
		return -1;
	}
	OTraceDebug( "D-CUTHLP-0052 replication data len[%d] added to segment cutover service [%s]\n", 
			replData.length(), replService.data() );

	return 0;
}

