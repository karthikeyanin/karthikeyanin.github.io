static char _Shc300Processor_cxx_what[] = "@(#) Shc300Processor.cxx 1.24.1.3 18/05/17 07:08:49";

/*
 *  Copyright (C) 2004 eFunds Corporation ("eFunds").  All Rights Reserved.
 *  eFunds Canada Corporation is an authorized user.
 *
 *  IST is a registered trademark of eFunds Corporation.  Other brand or
 *  product names are trademarks or registered trademarks of their respective
 *  holders.
 *
 *  The information contained herein is the unpublished proprietary property
 *  of eFunds.  Except as specifically authorized in writing by eFunds, the
 *  holder of this document shall: i) keep all information contained herein
 *  confidential, and ii) protect the information, in whole or in part, from
 *  disclosure and dissemination to all third parties.
 *
 *  This document and the software described in it are furnished under license
 *  and may be used or copied only in accordance with the terms of such license.
 *  This document is supplied for information purposes only, is subject to
 *  change without notice, and should not be construed as a commitment by
 *  either eFunds Corporation or eFunds Canada Corporation.
 *
 *
 *                        MODIFICATION HISTORY                  REVIEW
 *
 * SCR#     Who    Date  Description
 * ===========================================================================
 * R0xxxxx
 * R018276 pve	27Nov06	Add new OTraceLog messages
 * R028271 dipa 18Jun10 Txn Statistcis
 * R030381 dipa 02Mar12 Removed TXNSTAT macro
 */

 /* File Number 46 */

#include <stdio.h>
#include <string.h>
#include <ctype.h>
#include <oasis.h>
#include <shc.h>
#include <shc_callback.h>
#include <ShcSender.h>
#include <ShcSdkCommon.h>
#include <ShcmsgHelper.h>
#include <ShcTimerHelper.h>
#include <Shc300Processor.h>
#include <ShcMsgCache.h>
#include <Shc300Req.h>
#include <Shc300Resp.h>
#include <ShcnetEventMsg.h>
#include <ShcnetNetworkMsg.h>
#include <ShcNetworkMsgHelper.h>
#include <Shc300Event.h>
#include <ShcApp.h>
#include <Shc300Helper.h>
#include <ShcmsgProcessor.h>
#include <Shc3XX.h>

#include <Shc300TxnRegistration.h>
#include <ShcmsgTxnHelper.h>
#include <ShcHeader.h>

#include <ist_seg_elf_id_map.h>

Shc300Processor::Shc300Processor(char *msgbuf): ShcmsgProcessor(msgbuf)
{
}

ShcBaseTxn *Shc300Processor::classify()
{
	ShcmsgHeader *thisHeader = (ShcmsgHeader *)header;
	return shc300TxnRegistration.getTargetObj(thisHeader);
}

int Shc300Processor::getBINs()
{
	ShcmsgHeader *thisHeader = (ShcmsgHeader *)header;
	IstSegShc300Req *shc300req = NULL;
	shc300req = (IstSegShc300Req *)thisHeader->getSegmentObj(ElfIdMap::elf_to_id(IST_SEG_SHC300_REQ), 0);
	if(shc300req)
	{
		int len=25;
		shc300req->getISO_RECEIVER(thisHeader->msg.issuer, &len);
		if(len < 0)
			return -1;
	}

	if(thisHeader->setIssShcBin(thisHeader->msg.issuer) == -1)
	{
		OTraceError("E-SHC-4602:shc_300: Invalid issuer(%s)\n", thisHeader->msg.issuer);
		thisHeader->msg.respcode = SHC_RC_InvalidIssuer;
		thisHeader->shcerr	 = SH_RETURN;
		thisHeader->setReturnFlag(SHC_RC_InvalidIssuer);
		thisHeader->msg.msgtype = thisShcApp->shc300HelperObj->shc_get_return_msgno(thisHeader->msg.msgtype);

	}
	return(0);
}

int Shc300Processor::route()
{
	ShcmsgHeader *thisHeader = (ShcmsgHeader *)header;
	thisShcApp->shc300HelperObj->shc_route((Shc300Header *)header);

	return( 0 );

}

int Shc300Processor::process()
{
	int status	=	0;
	ShcmsgHeader *thisHeader = (ShcmsgHeader *)header;

	thisShcApp->shcmsgTxnHelperObj->setParamSet(thisHeader);

    	int callbackRet = shc_callback(thisHeader,"preprocess");

	thisShcApp->shcmsgHelperObj->dumpShcmsg( &thisHeader->msg );

	getBINs();

	if( (status=thisShcApp->shcmsgTxnHelperObj->initTransaction(thisHeader)) < 0 )
	{
		if (status == -2) //In forward only mode
			thisHeader->shcerr |= SH_RETURN;
		else
			thisHeader->shcerr |= SH_IGNORE;
		OTraceDebug("D-SHC-4606: No txn classify needed\n");
	}
	else if ( (shcTxn=classify())!=NULL )
	{
		shcTxn->process();
	}
	else
	{
		OTraceDebug("D-SHC-4607:Can't classify\n");
	}
	struct shcpkg *issPkg = header->issShcBin->binPkg;
	if (thisHeader->shcerr & SH_SETTIMER)
	{
		thisShcApp->shcTimerObj->shc_time_message_x(thisHeader,(unsigned char *)thisHeader->segment);
	}

	log();
	route();

	flush_mb_cache();

	return(0);

}
