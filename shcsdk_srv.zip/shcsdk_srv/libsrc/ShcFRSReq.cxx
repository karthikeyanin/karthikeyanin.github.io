static char _ShcFRSReq_cxx_what[] = "@(#) ShcFRSReq.cxx 1.4 16/05/10 12:20:41";

/*
 *  Copyright (C) 2004 eFunds Corporation ("eFunds").  All Rights Reserved.     
 *  eFunds Canada Corporation is an authorized user.                            
 *                                                                              
 *  IST is a registered trademark of eFunds Corporation.  Other brand or        
 *  product names are trademarks or registered trademarks of their respective   
 *  holders.                                                                    
 *                                                                              
 *  The information contained herein is the unpublished proprietary property    
 *  of eFunds.  Except as specifically authorized in writing by eFunds, the     
 *  holder of this document shall: i) keep all information contained herein     
 *  confidential, and ii) protect the information, in whole or in part, from    
 *  disclosure and dissemination to all third parties.                          
 *                                                                          
 *  This document and the software described in it are furnished under license  
 *  and may be used or copied only in accordance with the terms of such license.
 *  This document is supplied for information purposes only, is subject to      
 *  change without notice, and should not be construed as a commitment by       
 *  either eFunds Corporation or eFunds Canada Corporation. 
 *
 *
 *                        MODIFICATION HISTORY                  REVIEW
 *
 *	SPR#	Who	Date	Description			Who	Date   
 * ===========================================================================
 *R00xxxx
 */
/* File Number 77 */

#include <stdio.h>
#include <string.h>
#include <ctype.h>
#include <oasis.h>
#include <ist_otrace.h>
#include <shc.h>
#include <ShcFRSReq.h>
#include <ShcFRSReqHelper.h>
#include <ShcmsgHelper.h>
#include <ShcSaf.h>
#include <ShcApp.h>


int  ShcFRSReq::doWork()
{
	int ret = -1;

	OTraceInfo("I-SHC-077001: shc_frs_req():\n");
    header->shcerr = SH_SENDISS | SH_SETTIMER;
	header->msg.device_devcap |= SH_DEVICE_LOG_SHCLOG_VFRS;
	if(header->msg.device_cap & SH_DEVCAP_FROM_REPLAY)
    {
		if (header->time_in >=10000000000)
        	header->time_out = header->time_in + 1000*thisShcApp->issuerShcParamsList->GetNum("shc.saf_timeout");
		else
        	header->time_out = header->time_in + thisShcApp->issuerShcParamsList->GetNum("shc.saf_timeout");
       	header->shcerr = SH_SENDISS | SH_SETTIMER;
        return(0);
    }

	OTraceInfo("I-SHC-077002: Logging %d Message\n", header->msg.msgtype);
	header->logFlag = SHC_LOG_REQ;
	thisShcApp->shcFRSReqHelperObj->processFromNetwork(header);	
	
	return(0);
}




