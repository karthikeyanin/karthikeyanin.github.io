static char _ShcIBFTRevResp_cxx_what[] = "@(#) ShcIBFTRevResp.cxx 1.7 07/11/30 09:46:30";

/*
 *  Copyright (C) 2004 eFunds Corporation ("eFunds").  All Rights Reserved.     
 *  eFunds Canada Corporation is an authorized user.                            
 *                                                                              
 *  IST is a registered trademark of eFunds Corporation.  Other brand or        
 *  product names are trademarks or registered trademarks of their respective   
 *  holders.                                                                    
 *                                                                              
 *  The information contained herein is the unpublished proprietary property    
 *  of eFunds.  Except as specifically authorized in writing by eFunds, the     
 *  holder of this document shall: i) keep all information contained herein     
 *  confidential, and ii) protect the information, in whole or in part, from    
 *  disclosure and dissemination to all third parties.                          
 *                                                                          
 *  This document and the software described in it are furnished under license  
 *  and may be used or copied only in accordance with the terms of such license.
 *  This document is supplied for information purposes only, is subject to      
 *  change without notice, and should not be construed as a commitment by       
 *  either eFunds Corporation or eFunds Canada Corporation. 
 *
 *
 *
 *                        MODIFICATION HISTORY                  REVIEW
 *
 *	SPR#	Who	Date	Description			Who	Date   
 * ===========================================================================
 * R0xxxxx jyang 21Nov03 Created
 * R022100 sks   30Nov07 Use func issBinValid & acqBinValid to check validity of bin
 */

//File Number 85

#include <ShcRevReqHelper.h>
#include <ShcRevResp.h>
#include <ShcIBFTRevResp.h>
#include <ShcApp.h>
#include <ShcBin.h>
#include <ShcmsgTxnHelper.h>
#include <ShcRevRespHelper.h>
#include <ShcmsgHelper.h>
#include <ShcIBFTHelper.h>



/*****************************************************************************/

int ShcIBFTRevResp::enrich()
{
	save_pcode = header->msg.pcode;

	//return ShcRevResp::restore();
	if (header->createdInternal())
		return 0;
		
	thisShcApp->shcmsgTxnHelperObj->setDefaultKeyLen(header);
	thisShcApp->shcmsgTxnHelperObj->setOriginator(header);
	thisShcApp->shcmsgHelperObj->shc_normalizepan(header->msg.pan);
	
	if (!(header->issBinValid()) || !(header->acqBinValid()))	//	---	R022100
	{
		header->setReturnFlag(header->msg.respcode);
		return -1;
	}
	
//	thisShcApp->shcmsgTxnHelperObj->setParamSet(header);
	thisShcApp->shcmsgTxnHelperObj->setCapDate(header);
	thisShcApp->shcmsgHelperObj->shc_get_pin_data(header);
	thisShcApp->shcmsgTxnHelperObj->setCurrencyCode(header);
	thisShcApp->shcmsgTxnHelperObj->initFromDevice(header);
	thisShcApp->shcmsgTxnHelperObj->setAcqCountry(header);
	thisShcApp->shcmsgTxnHelperObj->decideTimeOutValue(header);
	thisShcApp->shcmsgHelperObj->setPinParm(header);
	thisShcApp->shcmsgTxnHelperObj->setOnlineActivity(header);
	OTraceInfo("I-SHC-085001: (header) enrich(iss=%s, acq=%s),(txnSrc=%s, txnDest=%s)\n",
			header->msg.issuer, header->msg.acquirer,
			header->msg.txnSrc, header->msg.txnDest);

	thisShcApp->shcRevRespHelperObj->locateRevReqEvent(header);

	return 0;
};


/*****************************************************************************/
int ShcIBFTRevResp::doWork()
{
	if( ! header->shouldContinue(TXN_PROC_SKIP_DOWORK) || header->createdInternal() )
		return 0;

	if ( thisShcApp->shcIBFTHelperObj->prepareRespLogMessage(header) == True )
		header->logFlag = SHC_LOG_UPD_REQ;

	thisShcApp->shcRevRespHelperObj->sendToPosauthSever(header);

	thisShcApp->shcIBFTHelperObj->setRoutingFlag(header);

	thisShcApp->shcIBFTHelperObj->restoreBeforeRouting(header);
	
//	Following function removed
//	thisShcApp->shcRevRespHelperObj->overrideRespRoutingFlag( header );

    /* 961108 */
	if( header->reqMsg->device_cap & SH_DEVCAP_FROM_REPLAY )
		header->msg.pcode = save_pcode;

	return(0);
}




