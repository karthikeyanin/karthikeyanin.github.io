static char _ShcmsgEventFinAuth_cxx_what[] = "@(#) ShcmsgEventFinAuth.cxx 1.12.1.1 17/09/21 13:25:49";

/*
 *  Copyright (C) 2004 eFunds Corporation ("eFunds").  All Rights Reserved.     
 *  eFunds Canada Corporation is an authorized user.                            
 *                                                                              
 *  IST is a registered trademark of eFunds Corporation.  Other brand or        
 *  product names are trademarks or registered trademarks of their respective   
 *  holders.                                                                    
 *                                                                              
 *  The information contained herein is the unpublished proprietary property    
 *  of eFunds.  Except as specifically authorized in writing by eFunds, the     
 *  holder of this document shall: i) keep all information contained herein     
 *  confidential, and ii) protect the information, in whole or in part, from    
 *  disclosure and dissemination to all third parties.                          
 *                                                                          
 *  This document and the software described in it are furnished under license  
 *  and may be used or copied only in accordance with the terms of such license.
 *  This document is supplied for information purposes only, is subject to      
 *  change without notice, and should not be construed as a commitment by       
 *  either eFunds Corporation or eFunds Canada Corporation. 
 *
 *
 *
 *                        MODIFICATION HISTORY                  REVIEW
 *
 *	SPR#	Who	Date	Description			Who	Date   
 * ===========================================================================
 * R0xxxxx jyang 09Dec03 Created
 * R023964 sks	 18Jul08 Check return value of tm_dequeue() in Event Processing
 * R027060 dipa  18Aug09 Include advice repeat messages to be processed by event manager during timeout cases
 */

//File Number 94

#include <ShcmsgEvent.h>
#include <ShcmsgEventFinAuth.h>
#include <ShcFinAuthHelper.h>
#include <ShcmsgEventHelper.h>
#include <ShcmsgTxnHelper.h>
#include <ShcApp.h>
#include <ShcBin.h>
#include <ShcmsgHelper.h>
#include <TxnStat.h>
#include <ShcSafIOHelper.h>
#include <ShcmsgODHelper.h>

int ShcmsgEventFinAuth::enrich()
{

	OTraceInfo("I-SHC-091001: Time out of message: %d trace %d event %d unit %d\n",
		header->msg.msgtype, header->msg.trace, 
		header->eventId, header->msg.unit);

	/*
 	 *	Remove the message from the event queue
 	 */
	//	>>>	R023964
	if( tm_dequeue(header->eventId) < 0 )
	{
		OTraceInfo("I-SHC-094003: Event not removed properly from event queue, message dropped\n");
		header->shcerr = SH_IGNORE;
		header->setIgnoreFlag();
		return 0;
	}
	else
	{
		TxnStatReport(header->msg.shclog_id, TS_SHC,TSR_TIMEOUT,header->msg.msgtype,0,mbLastSenderId());
	//	<<<	R023964
	header->eventId = -1;

	shcBin = header->issShcBin;


	//If it's On Dot notificatiion event and not from SAF, just send it to SAF
	//shc first send On Dot notification to On Dot directly, if it times out, 
	//put in SAF and send later
	if (header->issBinValid() && (strcmp(header->issShcBin->binPkg->bin.networkid, "     ONDOT")==0))
	{
		if (!(header->msg.device_cap & SH_DEVCAP_FROM_REPLAY))
		{
			OTraceDebug("D-SHC-094005:Send On Dot notification to SAF\n");
			thisShcApp->shcSafIOHelperObj->shc_saf_writefile(shcmsgODHelperObj->getODBin(), header);
			header->setSkipFlag();
			return 0;
		}
	}
	thisShcApp->shcmsgEventHelperObj->restoreOldPINBlock(header);
	thisShcApp->shcmsgHelperObj->shc_get_pin_data(header);		
	return 0;
	}	//	---	R023964
}

int ShcmsgEventFinAuth::edit()
{
	
	thisShcApp->shcmsgEventHelperObj->checkAndSetSafType(this, header, shcBin);

	switch(header->msg.msgtype)
	{
	case	SHC_FINREQ:
	case	SHC_AUTHREQ:
	case	SHC_FINREQ_REPEAT:
	case	SHC_AUTHREQ_REPEAT:
		if( posauth_failed )
		{
			if ((shcApp->issuerShcParamsList->getShcActionOnPosauthTimeout() != SHC_RC_Approved))
			{
				OTraceInfo("I-SHC-094001:Txn denied because positive auth time-out\n");
				header->msg.respcode = SHC_RC_IssuerTimeout;
				header->msg.revcode  = SHC_RR_TimeOut;
			   /* 
				* R001835
				*
				* SG added the line to stop the mac verification when
				*  message is routed internally 
				*/
				if(!(header->msg.device_cap & SH_DEVCAP_FROM_NETWORK))
						header->msg.device_cap|=SH_DEVCAP_INTERNALREV;
	
				thisShcApp->shcFinAuthHelperObj->shc_return_finauth(header, -1);
	
				/*	I can never have a balance at this point */
				header->msg.shcerror = SHC_IE_NoBalance;
	//////			shc_route(header);
	////// 
	//////			/*	17nov92 */
	//////			header->shcerr = SH_IGNORE;
				return 0;
			}			
		}
		break;
	}
	
	thisShcApp->shcmsgEventHelperObj->checkAndSetBinDown(header, shcBin);


	return 0;
}


int ShcmsgEventFinAuth::doWork()
{
	//ShcmsgEvent::doWork();
	if ( ! header->shouldContinue(TXN_PROC_SKIP_DOWORK) )
		return False;
		
	if ( thisShcApp->shcmsgEventHelperObj->retryOnTimeout(header, shcBin) == True )
	{
		header->setSkipFlag();
		return False;
	}
	
	switch(header->msg.msgtype)
	{
	case	SHC_FINREQ:
	case	SHC_AUTHREQ:
	case	SHC_FINREQ_REPEAT:
	case	SHC_AUTHREQ_REPEAT:
										/* R008224 BEGIN */
		if( header->msg.shc_devcap & SH_DEVCAP_SHC_VOID )
		{
			thisShcApp->shcFinAuthHelperObj->shc_return_finauth(header, SHC_RC_IssuerDown);
			break;
		}								/* R008224 END */

		if((!shcIsAdvice(header))&&(header->issShcBin->binPkg->bin.flags & SH_CHECKPIN_STAND_IN))
			if(thisShcApp->shcmsgTxnHelperObj->shc_checkpin(header) == -1)
			{
				thisShcApp->shcFinAuthHelperObj->shc_return_finauth(header, -1);
				return 0;
			}

		if ( posauth_failed  || (thisShcApp->shcmsgEventHelperObj->doPositiveAuth( header, shcBin, 1 )==FALSE) )
			thisShcApp->shcmsgEventHelperObj->procFinAuthEvent(this, header);
		break;
	
	case	SHC_FINREQ_ADVICE:
	case	SHC_AUTHREQ_ADVICE:
	case    SHC_FINREQ_ADVICE_REPEAT:  //R027060
	case    SHC_AUTHREQ_ADVICE_REPEAT:  //R027060
		thisShcApp->shcmsgEventHelperObj->procAdviceEvent(header, shcBin);
		/* For now we just drop it. */
//		header->shcerr = SH_IGNORE; //R027959 - handled in procAdviceEvent
		break;

	default:
		OTraceError("E-SHC-094002: Undefined msgtype[%04d]\n", header->msg.msgtype );
		
		break;
	}
	
	return 0;
}





