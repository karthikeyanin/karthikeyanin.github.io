static char _ShcLateShcmsgResp_cxx_what[] = "@(#) ShcLateShcmsgResp.cxx 1.4 12/05/29 06:39:23";

/*
 *  Copyright (C) 2004 eFunds Corporation ("eFunds").  All Rights Reserved.     
 *  eFunds Canada Corporation is an authorized user.                            
 *                                                                              
 *  IST is a registered trademark of eFunds Corporation.  Other brand or        
 *  product names are trademarks or registered trademarks of their respective   
 *  holders.                                                                    
 *                                                                              
 *  The information contained herein is the unpublished proprietary property    
 *  of eFunds.  Except as specifically authorized in writing by eFunds, the     
 *  holder of this document shall: i) keep all information contained herein     
 *  confidential, and ii) protect the information, in whole or in part, from    
 *  disclosure and dissemination to all third parties.                          
 *                                                                          
 *  This document and the software described in it are furnished under license  
 *  and may be used or copied only in accordance with the terms of such license.
 *  This document is supplied for information purposes only, is subject to      
 *  change without notice, and should not be construed as a commitment by       
 *  either eFunds Corporation or eFunds Canada Corporation. 
 *
 *
 *                        MODIFICATION HISTORY                  REVIEW
 *
 *	SPR#	Who	Date	Description			Who	Date   
 * ===========================================================================
 *R00xxxx ztang 16Jan03 Creation
 */
/* File Number 87 */

#include <stdio.h>
#include <string.h>
#include <ctype.h>
#include <oasis.h>
#include <ist_otrace.h>
#include <shc.h>
#include <shcdef.h>
#include <CShcLog.h>
#include <ShcLateShcmsgResp.h>
#include <ShcMacHelper.h>
#include <ShcFinAuthHelper.h>
#include <ShcmsgHelper.h>
#include <ShcCamHelper.h>
#include <ShcmsgProcessor.h>

#include <ShcLateRespHelper.h>

int ShcLateShcmsgResp::enrich()
{
	return 0;
}


int ShcLateShcmsgResp::doWork()
{
	if (shcLateRespHelperObj && shcLateRespHelperObj->processLateResp(header))
	{
		//Nothing to do
	}
	else
	header->logFlag = SHC_LOG_REQ;
	
	header->shcerr = SH_IGNORE;
	
	return 0;
}








