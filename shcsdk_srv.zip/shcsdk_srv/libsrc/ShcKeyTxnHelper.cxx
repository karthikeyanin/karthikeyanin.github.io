static char _ShcKeyTxnHelper_cxx_what[] = "@(#) ShcKeyTxnHelper.cxx 1.14 12/03/28 04:15:10";

/*
 *  Copyright (C) 2004 eFunds Corporation ("eFunds").  All Rights Reserved.     
 *  eFunds Canada Corporation is an authorized user.                            
 *                                                                              
 *  IST is a registered trademark of eFunds Corporation.  Other brand or        
 *  product names are trademarks or registered trademarks of their respective   
 *  holders.                                                                    
 *                                                                              
 *  The information contained herein is the unpublished proprietary property    
 *  of eFunds.  Except as specifically authorized in writing by eFunds, the     
 *  holder of this document shall: i) keep all information contained herein     
 *  confidential, and ii) protect the information, in whole or in part, from    
 *  disclosure and dissemination to all third parties.                          
 *                                                                          
 *  This document and the software described in it are furnished under license  
 *  and may be used or copied only in accordance with the terms of such license.
 *  This document is supplied for information purposes only, is subject to      
 *  change without notice, and should not be construed as a commitment by       
 *  either eFunds Corporation or eFunds Canada Corporation. 
 *
 *
 *                        MODIFICATION HISTORY                  REVIEW
 *
 *	SPR#	Who	Date	Description			Who	Date   
 * ===========================================================================
 *R00xxxx
 *R016250 Emj 11Apr06 Do not perform PIN key exchange if PIN key exchange 
 *                    is already in progress
 *R018276 pve 27Nov06 Add new OTraceLog messages
 *R026138 sks 04Mar09 Changes in shckeys_ChangeKey() to avoid segmentation fault
 *R028271 dipa 18Jun10 Txn Statistics
 *R030381 dipa 02Mar12 Txn Statistics changes
 */
/* File Number 86 */

#include <stdio.h>
#include <string.h>
#include <ctype.h>
#include <oasis.h>
#include <oasisenv.h>
#include <dbm.h>
#include <tm.h>
#include <dbm_private.h>
#include <oc/oc_string.h>
#include <ist_otrace.h>
#include <Ccard_scheme.h>
#include <Cinstitution.h>
#include <shc_callback.h>
#include <rules.h>
#include <shcmsgdef.h>
#include <security.h>
#include <shc.h>
#include <shcpreauth.h>
#include <ic/ic_shcmsg.h>
#include <ic/ic_instid.h>
#include <ic/ic_bin.h>
#include <ic/ic_pan.h>
#include <emvchipcond.h>
#include <ShcSender.h>
#include <istcurrency.h>
#include <shc500std.h>

#include <ShcSdkCommon.h>
#include <ShcKeyTxnHelper.h>
#include <ShcCamHelper.h>
#include <ShcKeyHelper.h>
#include <ShcTimerHelper.h>
#include <hotrange.h>
#include <ShcmsgProcessor.h>
#include <ShcDKEHelper.h>
#include <ShcApp.h>
#include <ShcSaf.h>
#include <ShcBin.h>
#include <ShcNetworkMsgHelper.h>
#include <mb_umi.h>     //      R018276
#include <mt_inst_profile.h>
#include <multi_institution.h>
#include <ist_seg_id.h>

//R028271 >>>
#include <TxnStat.h>
//<<< R028271

//int ShcKeyTxnHelper::resetInst(ShcBin *shcBin)
//{
//    thisShcApp->shcBinObj->clearInst();
//
//    shckeys_ChangeKey(shcBin, SH_KEYTYPE_PIN_ACQ, SH_KEYTYPE_MAC, '1', NULL);
//
//    return( 0 );
//}

/* R001072 > */
/*  R001654.  */
int ShcKeyTxnHelper::shckeys_ChangeKey(ShcBin *shcBin, char key_class, char type, char idx, char *obin, InstitutionProfile *instProfile )
{
	struct ShcmsgHeader	shcmsg;

	/* R004679 */
	struct shckey_buf	keybuf1 = {0};
	struct shckey_buf	keybuf2 = {0};

	OTraceDebug("D-SHC-086001: Change key for '%s'\n", shcBin->binPkg->bin.networkid);
	OTraceDebug("          :  Format code: %c%c%c\n", key_class, type, idx);
	//OTraceDebug("          :  Current key index is '%c'\n", (char)*keybuf1.aidxp+'0');	//	---	R026138

	if( shcBin->shckeys_GetKey(&keybuf1, key_class, type, idx) < 0 )
		return( -1 );

	OTraceDebug("          :  Current key index is '%c'\n", (char)*keybuf1.aidxp+'0');	//	---	R026138

	if( shcBin->shckeys_GetKey(&keybuf2, key_class, type, SH_KEYIDX_NEXT) < 0 )
		return( -1 );

	OTraceDebug("D-SHC-086002:key1: status = '%c'\n", *keybuf1.astatp);
	OTraceDebug("          :key2: status = '%c'\n", *keybuf2.astatp);

	/* R004679 Key is in use, do not initiate a new key exchange */
/* R004966
	if ( (*keybuf1.astatp != SH_KEYSTAT_ACTIVE) || 
	     (*keybuf2.astatp != SH_KEYSTAT_ACTIVE) )
*/

	if(obin == NULL) /* R005295 */
		if( *keybuf1.astatp == SH_KEYSTAT_EXCHANGE
			|| *keybuf1.astatp == SH_KEYSTAT_RETRY
			|| *keybuf1.astatp == SH_KEYSTAT_MARKED
			|| *keybuf2.astatp == SH_KEYSTAT_EXCHANGE
			|| *keybuf2.astatp == SH_KEYSTAT_RETRY
			|| *keybuf2.astatp == SH_KEYSTAT_MARKED )
		{
			OTraceDebug("D-SHC-086003: key is in use.\n");

			return( -1 );
		}

/* R004966
	if( *keybuf1.astatp != SH_KEYSTAT_EXCHANGE
		&& *keybuf1.astatp != SH_KEYSTAT_RETRY )
*/

	shcBin->shckeys_SetStatus(&keybuf1, SH_KEYSTAT_MARKED);

	/* Is this the current key
		Yes: Advance index to point to the next key
	*/
	if( keybuf1.index == (char)*keybuf1.aidxp + '0' )
	{
		OTraceDebug("D-SHC-086004:   Next key status %s.%c%c%c: '%c'\n", 
				keybuf2.keyp->k.bin, keybuf2.key_class, keybuf2.type, 
				keybuf2.index, *keybuf2.astatp);

		if( *keybuf2.astatp == SH_KEYSTAT_ACTIVE )
			*keybuf2.aidxp = (int)(keybuf2.index - '0');
	}

	/* Build message for network manager
	*/
	shcmsg.msg.msgtype = SHC_NETWORK;
	shcmsg.msg.netcode = SHC_NET_CONTINUE_SIGNON;
	strcpy(shcmsg.msg.issuer, shcBin->binPkg->bin.networkid);
    strcpy(shcmsg.msg.acquirer, shc_orgid);

	shcmsg.setSegmentData((char *)instProfile, 
				sizeof(struct InstitutionProfile), NETWORK_DATA_REQ_id, ISS_INST_PROFILE_ENTRY);
	//	>>>	R018276
	mb_getUmi(shcmsg.msg.shclog_id, sizeof(shcmsg.msg.shclog_id));
	mb_set_tid(shcmsg.msg.shclog_id, strlen(shcmsg.msg.shclog_id));
	OTraceLog("L-SHC-086005: Created message ID[%s] /m%04d/n%d\n", shcmsg.msg.shclog_id,
		shcmsg.msg.msgtype, shcmsg.msg.netcode);
	//	<<<	R018276

	//R028271 >>>
	TxnStatReport(shcmsg.msg.shclog_id,TS_SHC,TSR_CREATE,shcmsg.msg.msgtype,0,0);
	//<<< R028271

	return( thisShcApp->shcNetworkMsgHelperObj->shc_send_800(&shcmsg, shcBin) );
}

/* R001072 < */
int ShcKeyTxnHelper::shcmac_ChgKey( ShcmsgHeader *header )
{
    /*
     * yh: checking if it is time to do KMAC key change. ACXSYS. 1998/01/20.
     */

/*
	if( header->msg.respcode == SHC_RC_MACSyncError 
		&& ! (header->msg.device_cap & SH_DEVCAP_FROM_REPLAY 
			&& shcIsRequest(header)) )
*/
	InstitutionProfile instProfile = { 0 };
	int len = sizeof(struct InstitutionProfile);
	if( header->msg.respcode == SHC_RC_MACSyncError )
	{
		if( shcIsAdmIssResp(header) )
		{
			header->getSegmentData((char *)&instProfile, &len, NETWORK_DATA_REQ_id, ACQ_INST_PROFILE_ENTRY);
			if (len == 0)
			{
				OTraceError("E-SHC-086006:No acquire side inst_profile entry in segment, can't do key exchange for acquirer\n");
				return -1;
			}
			thisShcApp->shcKeyTxnHelperObj->shckeys_ChangeKey(header->acqShcBin, SH_KEYTYPE_PIN_ACQ,
				SH_KEYTYPE_MAC, SH_KEYIDX_CURRENT, NULL, &instProfile); /* R005295 */
		}
		else
		{
			header->getSegmentData((char *)&instProfile, &len, NETWORK_DATA_REQ_id, ISS_INST_PROFILE_ENTRY);
			if (len == 0)
			{
				OTraceError("E-SHC-086007:No issuer side inst_profile entry in segment, can't do key exchange for acquirer\n");
				return -1;
			}
			thisShcApp->shcKeyTxnHelperObj->shckeys_ChangeKey(header->issShcBin, SH_KEYTYPE_PIN_ACQ,
				SH_KEYTYPE_MAC, SH_KEYIDX_CURRENT, NULL, &instProfile); /* R005295 */
		}
	}
	else if( header->msg.respcode == SHC_RC_KMESyncError )
	{
		header->getSegmentData((char *)&instProfile, &len, NETWORK_DATA_REQ_id, ISS_INST_PROFILE_ENTRY);
		if (len == 0)
		{
			OTraceError("E-SHC-086008:No issuer side inst_profile entry in segment, can't do key exchange for acquirer\n");
			return -1;
		}
		thisShcApp->shcKeyTxnHelperObj->shckeys_ChangeKey(header->issShcBin, SH_KEYTYPE_PIN_ACQ,
			SH_KEYTYPE_KME, SH_KEYIDX_CURRENT, NULL, &instProfile); /* R005295 */
	}

	return( 0 );
}

int ShcKeyTxnHelper::shcpin_ChgKey(ShcmsgHeader *header)
{
	if(header->msg.respcode == SHC_RC_PINKeyError)
	{
		InstitutionProfile instProfile = { 0 };
		int len = sizeof(struct InstitutionProfile);

		header->getSegmentData((char *)&instProfile, &len, NETWORK_DATA_REQ_id, ISS_INST_PROFILE_ENTRY);
		if (len == 0)
		{
			OTraceError("E-SHC-086009:No issuer side inst_profile entry in segment, can't do key exchange for acquirer\n");
			return -1;
		}

		return (thisShcApp->shcKeyTxnHelperObj->shckeys_ChangeKey(header->issShcBin, SH_KEYTYPE_PIN_ACQ,
			SH_KEYTYPE_PIN, SH_KEYIDX_CURRENT, NULL, &instProfile));
	}
	return(0);
}






