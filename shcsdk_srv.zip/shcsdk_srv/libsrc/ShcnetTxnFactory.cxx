static char _ShcmsgTxnFactory_cxx_what[] = "@(#) ShcnetTxnFactory.cxx 1.6 16/12/07 03:13:22";

/*
 *  Copyright (C) 2004 eFunds Corporation ("eFunds").  All Rights Reserved.     
 *  eFunds Canada Corporation is an authorized user.                            
 *                                                                              
 *  IST is a registered trademark of eFunds Corporation.  Other brand or        
 *  product names are trademarks or registered trademarks of their respective   
 *  holders.                                                                    
 *                                                                              
 *  The information contained herein is the unpublished proprietary property    
 *  of eFunds.  Except as specifically authorized in writing by eFunds, the     
 *  holder of this document shall: i) keep all information contained herein     
 *  confidential, and ii) protect the information, in whole or in part, from    
 *  disclosure and dissemination to all third parties.                          
 *                                                                          
 *  This document and the software described in it are furnished under license  
 *  and may be used or copied only in accordance with the terms of such license.
 *  This document is supplied for information purposes only, is subject to      
 *  change without notice, and should not be construed as a commitment by       
 *  either eFunds Corporation or eFunds Canada Corporation. 
 *
 *
 *                        MODIFICATION HISTORY                  REVIEW
 *
 * SCR#     Who    Date  Description
 * ===========================================================================
 * R0xxxxx 
 */

//File Number 99

//#include <shc.h>
//#include <shcdef.h>
//#include <shcextbuf.h>
//
//#include <ShcSdkCommon.h>
//#include <ShcHeader.h>
#include <ShcBin.h>
#include <ShcnetEventMsg.h>
#include <ShcnetNetworkMsg.h>
#include <ShcnetKeyGracePeriodMsg.h>

/* File Number 152 */

#include <ShcnetTxnFactory.h>

int ShcnetTxnFactory::createCondition(char *condition, const void *header)
{
	ShcmsgHeader *thisHeader = (ShcmsgHeader *)header;
	
	sprintf(condition, "%4.4d%c%c%c%c%c", 
			thisHeader->msg.msgtype%10000,
			thisHeader->msg.shc_devcap & SH_DEVCAP_SHC_EVENT?'Y':'N',
			thisHeader->msg.formatter_devcap & SH_FORMATDEVCAP_RETURN?'Y':'N',
			shcIsIBFT(thisHeader)?'Y':'N',
			thisHeader->msg.shc_devcap & SH_DEVCAP_SHC_BO_MASK?'Y':'N',
			shcIsLogRequest(thisHeader)?'Y':'N'
			);
	return 0;
}

ShcmsgBaseTxn *ShcnetTxnFactory::getTargetObj(char *condition, const void *headerBuf)
{
	
	ShcmsgHeader *thisHeader = (ShcmsgHeader *)headerBuf;
	ShcmsgBaseTxn *obj;
	
	if ( condition[4] == 'Y' )
	{
	    switch(thisHeader->msg.msgtype%10000)
	    {
	    case    SHC_KEY_GRACE_PERIOD:
            obj = new ShcnetKeyGracePeriodMsg(thisHeader);
	        break;
	    default:
			obj = new ShcnetEventMsg(thisHeader);	
	    }
	}
	else
	{
	    switch(thisHeader->msg.msgtype)
	    {
	    case    SHC_NETWORK:
	    case    SHC_NETWORK_ADVICE:
	    case    SHC_NETWORK_ADVICE_REPEAT:
	    case    SHC_NETWORK_RESPONSE:
	    case    SHC_NETWORK_ADVICE_RESPONSE:
            obj = new ShcnetNetworkMsg(thisHeader);
	        break;
	    case    SHC_KEY_GRACE_PERIOD:
            obj = new ShcnetKeyGracePeriodMsg(thisHeader);
	        break;
	    default:
	    	obj = NULL;
	    }
    }
    
	if ( obj )
		OTraceDebug("D-SHC-15201:     Create a shcmsg txn [%s]\n", condition);
	else
		OTraceError("I-SHC-15202:     Not ShcHeader Instance[%s]\n", condition);
		
	return obj;
}


