/*
 *  Copyright (C) 2004 eFunds Corporation ("eFunds").  All Rights Reserved.
 *  eFunds Canada Corporation is an authorized user.
 *
 *  IST is a registered trademark of eFunds Corporation.  Other brand or
 *  product names are trademarks or registered trademarks of their respective
 *  holders.
 *
 *  The information contained herein is the unpublished proprietary property
 *  of eFunds.  Except as specifically authorized in writing by eFunds, the
 *  holder of this document shall: i) keep all information contained herein
 *  confidential, and ii) protect the information, in whole or in part, from
 *  disclosure and dissemination to all third parties.
 *
 *  This document and the software described in it are furnished under license
 *  and may be used or copied only in accordance with the terms of such license.
 *  This document is supplied for information purposes only, is subject to
 *  change without notice, and should not be construed as a commitment by
 *  either eFunds Corporation or eFunds Canada Corporation.
 *
 *
 *
 *                        MODIFICATION HISTORY                  REVIEW
 *
 *	SPR#	Who	Date	Description			Who	Date
 * ===========================================================================
 *R000000 ztang	27Jul17	New file created
 */

/* File Number 177 */
static char _ShcmsgODEvent_cxx_what[] = "@(#) ShcmsgODEvent.cxx 1.4 17/09/06 10:38:59";

#include <ShcmsgEvent.h>
#include <ShcmsgODEvent.h>
#include <ShcmsgTxnHelper.h>
#include <ShcApp.h>
#include <ShcBin.h>
#include <ShcmsgHelper.h>
#include <ShcmsgODHelper.h>
#include <ShcTimerHelper.h>
#include <ShcmsgHeader.h>
#include <ShcMsgCache.h>
#include <BinRoute.h>
#include <ist_seg_name.h> 
#include <ist_seg_elf_id_map.h>
#include <ist_seg_id.h>
#include <ist_seg_pdt_base.h>
#include <TxnStatSource.h>
#include <TxnStatReason.h>
#include <TxnStat.h>


int ShcmsgODEvent::enrich()
{
	return 0;
}

int ShcmsgODEvent::edit()
{
	return 0;
}

int ShcmsgODEvent::verify()
{

	IstSegPdtBase *ODData; //R027876

	struct ShcmsgWithSegment timerBuf;

	int origmti = header->msg.msgtype;

	if (tm_dequeue(header->eventId) < 0 )
	{
		OTraceDebug("D-SHC-177002:Event not removed properly from queue ,message dropped \n");
		header->shcerr = SH_IGNORE;
		header->setIgnoreFlag();

		TxnStatReport(header->msg.shclog_id,  TS_SHC,TSR_DROP,header->msg.msgtype,0,mbLastSenderId());
		return 0;
	}

	OTraceDebug("D-SHC-177004:OD msgtype [%d] flipped back to original msgtype [%d]\n",
		header->msg.msgtype, header->msg.flipped_msgtype);
	header->msg.msgtype = header->msg.flipped_msgtype;

	header->reqMsg = NULL;
	header->origMsg = NULL;

	ODData = (IstSegPdtBase *)header->getSegmentObj(ON_DOT_id);
	if (ODData)
		OTraceDebug("D-SHC-177006:OD_SEG_DATA segment found\n");

	ShcmsgODHeader *thisHeader = (ShcmsgODHeader *)header;
	int l;
	char buf[100];



	int eventId = -1;
	if(ODData)
	{
		memset(buf, 0x00, sizeof(buf)); l=sizeof(buf);
		if (ODData->getReqEventId(buf,&l) == IST_RET_OK)
		{
			eventId =atoi(buf);
			if (eventId >= 0)
			{
				if( tm_getdata(eventId, (char *)&timerBuf, sizeof(timerBuf)) > 0)
				{
					header->allocateAndCopyReqMsg(&(timerBuf.msg));
					OTraceDebug("D-SHC-177008: reqmsg restored from OD event\n");
				}
				tm_dequeue(atoi(buf));
			}
		}

		memset(buf, 0x00, sizeof(buf)); l=sizeof(buf);
		if (ODData->getOrigEventId(buf,&l) == IST_RET_OK)
		{
			eventId =atoi(buf);
			if (eventId >= 0)
			{
				if( tm_getdata(eventId, (char *)&timerBuf, sizeof(timerBuf)) > 0)
				{
					header->allocateAndCopyOrigMsg(&(timerBuf.msg));
					OTraceDebug("D-SHC-177010: origmsg restored from OD event\n");
				}
				tm_dequeue(eventId);
			}
		}

		memset(buf, 0x00, sizeof(buf)); l=sizeof(buf);
		if (ODData->getFlippedMsgType(buf,&l) == IST_RET_OK)
			header->msg.flipped_msgtype = atoi(buf);

		memset(buf, 0x00, sizeof(buf)); l=sizeof(buf);
		if (ODData->getLogFlag(buf,&l) == IST_RET_OK)
			header->logFlag = atoi(buf);

		memset(buf, 0x00, sizeof(buf)); l=sizeof(buf);
		if (ODData->getRepeatFlag(buf,&l) == IST_RET_OK)
			header->repeatFlag = atoi(buf);

		memset(buf, 0x00, sizeof(buf)); l=sizeof(buf);
		if (ODData->getShcerr(buf,&l) == IST_RET_OK)
			header->shcerr = atoi(buf);

		memset(buf, 0x00, sizeof(buf)); l=sizeof(buf);
		if (ODData->getTxnIn_time(buf,&l) == IST_RET_OK)
			header->time_in = atol(buf);
	}

	// clarify whether procFlag or skipFlag
	header->setSkipFlag(TXN_PROC_SKIP_ENRICH | TXN_PROC_SKIP_RESTORE | TXN_PROC_SKIP_EDIT | TXN_PROC_SKIP_VERIFY);

	if(!shcmsgODHelperObj)
		shcmsgODHelperObj = new ShcmsgODHelper;

	header->msg.auth_devcap &= ~SH_DEVCAP_AUTH_OD_MASK;//clear ON DOT flag
	header->msg.auth_devcap |= SH_DEVCAP_AUTH_ODTimeout;//continue on On Dot timeout
	if(thisHeader->issShcBin->binPkg->bin.bin_cfg & SH_CFG_ONDOT_DOWN_DENY)
	{
		header->msg.respcode = SHC_RC_Declined_On_ODTimeout;	
    	header->logFlag |= SHC_LOG_UPD_REQ;
    	header->setSkipFlag(TXN_PROC_SKIP_DOWORK);
    	header->shcerr = SH_RETURN;
    	shcApp->shcmsgHelperObj->shc_set_return_msgno(&header->msg);
		OTraceInfo("I-SHC-177011:Deny On Dot timeout txn.\n");
	}
	else
		OTraceInfo("I-SHC-177012:Continue On Dot timeout txn.\n");
		

	struct RoutingInfo s = {0};
	int len = sizeof(struct RoutingInfo);
	header->getSegmentData((char *)&s, &len, NETWORK_DATA_REQ_id,ROUTING_INFO);
	if (len)
	{
		binRouteObj->markRouteDown(NULL, &s, NULL);
		binRouteObj->tidyUpBinStatus();
	}
	len = sizeof(struct RoutingInfo);
	header->getSegmentData((char *)&s, &len, ON_DOT_id,ROUTING_INFO);
	if (len > 0)
		//Set original ROUTING_INFO back so round robin does not increase
		thisHeader->setSegmentData((char*)&s, sizeof(s), NETWORK_DATA_REQ_id, ROUTING_INFO);
	else
	{
		//Remove the On Dot routing info to prevent txn sent to On Dot again
		s.flag = 0;
		thisHeader->setSegmentData((char*)&s, sizeof(s), NETWORK_DATA_REQ_id, ROUTING_INFO);
	}

	shcmsgODHelperObj->enqueueInternalMsg((ShcmsgODHeader *)header);

	header->shcerr = SH_IGNORE;
	header->logFlag = 0;

	return 0;
}




int ShcmsgODEvent::doWork()
{
	return 0;
}

