static char _ShcProcessor_cxx_what[] = "@(#) ShcnetPortProcessor.cxx 1.2.1.5 20/02/27 06:05:45";

/*
 *  Copyright (C) 2004 eFunds Corporation ("eFunds").  All Rights Reserved.     
 *  eFunds Canada Corporation is an authorized user.                            
 *                                                                              
 *  IST is a registered trademark of eFunds Corporation.  Other brand or        
 *  product names are trademarks or registered trademarks of their respective   
 *  holders.                                                                    
 *                                                                              
 *  The information contained herein is the unpublished proprietary property    
 *  of eFunds.  Except as specifically authorized in writing by eFunds, the     
 *  holder of this document shall: i) keep all information contained herein     
 *  confidential, and ii) protect the information, in whole or in part, from    
 *  disclosure and dissemination to all third parties.                          
 *                                                                          
 *  This document and the software described in it are furnished under license  
 *  and may be used or copied only in accordance with the terms of such license.
 *  This document is supplied for information purposes only, is subject to      
 *  change without notice, and should not be construed as a commitment by       
 *  either eFunds Corporation or eFunds Canada Corporation. 
 *
 *
 *                        MODIFICATION HISTORY                  REVIEW
 *
 * SCR#     Who    Date  Description
 * ===========================================================================
 * R0xxxxx 
 */
 
 //File Number 171
#include <ist_otrace.h>
#include <tm.h>
#include <shc.h>
#include <TxnStat.h>
#include <shcextbuf.h>
#include <ShcSender.h>
#include <ShcSdkCommon.h>
#include <ShcMsgCache.h>
#include <ShcmsgHelper.h>
#include <ShcmsgTxnHelper.h>
#include <ShcTimerHelper.h>
#include <ShcnetPortProcessor.h>
#include <CShcNotify.h>
#include <ShcFinAuthReq.h>
#include <ShcFinAuthResp.h>
#include <ShcMacHelper.h>
#include <ShcRevReq.h>
#include <ShcRevResp.h>
#include <ShcnetEventMsg.h>
#include <ShcnetNetworkMsg.h>
#include <ShcTimerHelper.h>
#include <ShcNetworkMsgHelper.h>
#include <ShcnetTxnRegistration.h>
#include <ShcApp.h>
#include <ShcBin.h>
#include <BinRoute.h>
#include <istsafe.h>

ShcnetPortProcessor::ShcnetPortProcessor(char *msgbuf): ShcmsgProcessor(msgbuf)
{
}

ShcBaseTxn *ShcnetPortProcessor::classify()
{
return NULL;
}


int ShcnetPortProcessor::log()
{
	return 0;
}

int ShcnetPortProcessor::route()
{
	return 0;
	
}

static char staticBroadcastStr[16384];

int ShcnetPortProcessor::process()
{
	ShcmsgHeader *thisHeader = (ShcmsgHeader *)header;
	int j,ret;
	int isConn;
	struct RoutingInfo r =  { 0 };
	ShcBin shcBin;
	
	
	if (strncmp(thisHeader->msg.pan, "conn", 4)==0)
		isConn = 1;
	else
		isConn = 0;
	

	char *broadcastStrStart = staticBroadcastStr;
	char *broadcastStr;
	snprintf(staticBroadcastStr, sizeof(staticBroadcastStr), "shccmd  -s nodeupdate %s %s", mbcurrentnode, isConn?"-up ":"-down ");
	broadcastStr += strlen(staticBroadcastStr);

	strcpy(r.destNode, mbcurrentnode);
	r.siteId = mbGetSiteId();
	
   	strcpy(r.port, mbMailBoxName(mbLastSenderId()));

	int numOfRoute = binRouteObj ? binRouteObj->getRouteEntries( NULL, &r ) : 0;
	if ( numOfRoute > 0 )
	{
		struct s_binroute *pBinRoute = NULL;
		ShcmsgHeader tmpHeader;
		
		for ( j=0; j<numOfRoute; j++ )
		{
			broadcastStr = broadcastStrStart + strlen(broadcastStrStart);
			pBinRoute = binRouteObj->getRoute(j);

			if ( (!pBinRoute) || (pBinRoute->node[0] && strcmp(pBinRoute->node, mbcurrentnode)!=0) )
				continue;

	        shcBin.setBinPkg(pBinRoute->internalid);

			if (isConn)
			{
				switch(pBinRoute->cfg[BINROUTE_CFG_IDX_CONN_ACTION])
				{
				case BINROUTE_CFG_CONN_UP:
					ret=binRouteObj->changeRouteStatus(pBinRoute, BIN_ROUTE_STATUS_UP, broadcastStr, sizeof(staticBroadcastStr)-strlen(broadcastStr));
					if (ret)
					{
						//The route status is changed, may need to mark bin up as well
						int tmpFlag = noBraodcastFlag;
						noBraodcastFlag = 1; //prevent broadcast bin status change
						if (pBinRoute->cfg[BINROUTE_CFG_IDX_CONN_BINACTION]==BINROUTE_CFG_CONN_BIN_UP)
							binRouteObj->changeBinStatus(pBinRoute->internalid, 1);
						noBraodcastFlag = tmpFlag;
						OTraceLog("L-SHC-171005 : Put bin status braodcast message together with binroute broadcast message \n" );
						//put bin status braodcast message together with binroute broadcast message so they can go together.
						//strcat(broadcastStr, pBinRoute->internalid);
						istsafe_strcat(broadcastStr, sizeof(staticBroadcastStr), pBinRoute->internalid);
						OTraceDebug("D-SHC-171006: Broadcast message[%s] \n", staticBroadcastStr);	
					}
					break;
				case BINROUTE_CFG_CONN_ECHO:
					if (thisShcApp->shcNetworkMsgHelperObj->prepareMsgFromBinRoute(&tmpHeader, pBinRoute) < 0)
					{
						continue;
					}
				   (tmpHeader).msg.netcode = SHC_NET_ECHO_START;


					TxnStatReport(tmpHeader.msg.shclog_id,TS_SHC,TSR_CREATE,tmpHeader.msg.msgtype,0,0);
			        OTraceLog("L-SHC-171001: Created message ID[%s] m%04d/n%d\n",
			            tmpHeader.msg.shclog_id, tmpHeader.msg.msgtype, tmpHeader.msg.netcode);
			        thisShcApp->shcNetworkMsgHelperObj->shc_send_800(&tmpHeader, &shcBin);
			        break;
					
				case BINROUTE_CFG_CONN_SIGNON:
					if (thisShcApp->shcNetworkMsgHelperObj->prepareMsgFromBinRoute(&tmpHeader, pBinRoute) < 0)
					{
						continue;
					}
				   (tmpHeader).msg.netcode = SHC_NET_SIGNON_START;

					TxnStatReport(tmpHeader.msg.shclog_id,TS_SHC,TSR_CREATE,tmpHeader.msg.msgtype,0,0);
			        OTraceLog("L-SHC-171002: Created message ID[%s] m%04d/n%d\n",
			            tmpHeader.msg.shclog_id, tmpHeader.msg.msgtype, tmpHeader.msg.netcode);
			        thisShcApp->shcNetworkMsgHelperObj->shc_send_800(&tmpHeader, &shcBin);
					break;
				default:
					break;
				}

				switch(pBinRoute->cfg[BINROUTE_CFG_IDX_CONN_BINACTION])
				{
				case BINROUTE_CFG_CONN_BIN_ECHO:
					if (pBinRoute->cfg[BINROUTE_CFG_IDX_CONN_ACTION] == BINROUTE_CFG_CONN_ECHO)
					{
						//echo is down above, no echo for bin
						continue;
					}
					if (thisShcApp->shcNetworkMsgHelperObj->prepareMsgFromBinRoute(&tmpHeader, pBinRoute) < 0)
					{
						continue;
					}
				   (tmpHeader).msg.netcode = SHC_NET_ECHO_START;


					TxnStatReport(tmpHeader.msg.shclog_id,TS_SHC,TSR_CREATE,tmpHeader.msg.msgtype,0,0);
			        OTraceLog("L-SHC-171003: Created message ID[%s] m%04d/n%d\n",
			            tmpHeader.msg.shclog_id, tmpHeader.msg.msgtype, tmpHeader.msg.netcode);
			        thisShcApp->shcNetworkMsgHelperObj->shc_send_800(&tmpHeader, &shcBin);
			        break;
					
				case BINROUTE_CFG_CONN_BIN_SIGNON:
					if (pBinRoute->cfg[BINROUTE_CFG_IDX_CONN_ACTION] == BINROUTE_CFG_CONN_SIGNON)
					{
						//Signon is down above, no signon for bin
						continue;
					}
					if (thisShcApp->shcNetworkMsgHelperObj->prepareMsgFromBinRoute(&tmpHeader, pBinRoute) < 0)
					{
						continue;
					}
				   (tmpHeader).msg.netcode = SHC_NET_SIGNON_START;

					TxnStatReport(tmpHeader.msg.shclog_id,TS_SHC,TSR_CREATE,tmpHeader.msg.msgtype,0,0);
			        OTraceLog("L-SHC-171004: Created message ID[%s] m%04d/n%d\n",
			            tmpHeader.msg.shclog_id, tmpHeader.msg.msgtype, tmpHeader.msg.netcode);
			        thisShcApp->shcNetworkMsgHelperObj->shc_send_800(&tmpHeader, &shcBin);
					break;
				default:
					break;
				}
				
			}
			else
			{
				//Must be disconnect
				switch(pBinRoute->cfg[BINROUTE_CFG_IDX_DISC_ACTION])
				{
				case BINROUTE_CFG_DISC_DOWN:
					binRouteObj->changeRouteStatus(pBinRoute, BIN_ROUTE_STATUS_DOWN, broadcastStr, sizeof(staticBroadcastStr)-strlen(broadcastStr));
					break;
				}
				
				//Don't do anything for bin now, because the bin will be set down if all routes are down
				
			}
		}
		
		if (broadcastStrStart[0])
			mcastHelperObj->broadcast("shccmd", 3, staticBroadcastStr , strlen(staticBroadcastStr), NULL,0);
	        
		if (!isConn)
			binRouteObj->tidyUpBinStatus();
	}
	
	flush_mb_cache();
	return 0;
}




