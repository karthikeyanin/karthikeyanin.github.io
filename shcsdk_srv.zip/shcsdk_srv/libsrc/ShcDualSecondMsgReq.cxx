
static char _ShcDualSecondMsgReq_cxx_what[] = "@(#) ShcDualSecondMsgReq.cxx 1.3 08/04/21 14:00:22";

/*
 *  Copyright (C) 2004 eFunds Corporation ("eFunds").  All Rights Reserved.     
 *  eFunds Canada Corporation is an authorized user.                            
 *                                                                              
 *  IST is a registered trademark of eFunds Corporation.  Other brand or        
 *  product names are trademarks or registered trademarks of their respective   
 *  holders.                                                                    
 *                                                                              
 *  The information contained herein is the unpublished proprietary property    
 *  of eFunds.  Except as specifically authorized in writing by eFunds, the     
 *  holder of this document shall: i) keep all information contained herein     
 *  confidential, and ii) protect the information, in whole or in part, from    
 *  disclosure and dissemination to all third parties.                          
 *                                                                          
 *  This document and the software described in it are furnished under license  
 *  and may be used or copied only in accordance with the terms of such license.
 *  This document is supplied for information purposes only, is subject to      
 *  change without notice, and should not be construed as a commitment by       
 *  either eFunds Corporation or eFunds Canada Corporation. 
 *
 *
 *
 *                        MODIFICATION HISTORY                  REVIEW
 *
 *	SPR#	Who	Date	Description			Who	Date   
 * ===========================================================================
 * R020524 jyang 04Jul07 Created for dual-message transaction support
 */

/* File Number 161 */


#include <stdio.h>
#include <oasis.h>
#include <mb.h>
#include <tm.h>
#include <ist_otrace.h>
#include <shc.h>
#include <shcerror.h>
#include <ShcApp.h>
#include <ShcmsgHelper.h>
#include <ShcDualMsgHelper.h>
#include <ShcDualSecondMsgReq.h>

int ShcDualSecondMsgReq::edit()
{
	int ret = ShcFinAuthReq::edit();
	
	if ( ret < 0 || header->msg.respcode!=SHC_RC_Approved )
		return ret;
	
	if (!header->shouldContinue(TXN_PROC_SKIP_EDIT))
		return 0;
	
	memset( &shcmsgSeg, 0, sizeof(shcmsgSeg) );
	
	if ( retrieveFirstMsgRespResult() < 0 ) // no event found
	{
		OTraceInfo("I-SHC-16101: Denied - InterMsg event not found for dual msg\n");
		
//		if ( thisShcApp->shcDualMsgHelperObj->searchFirstMsgInDb( header, &shcmsgSeg ) < 0 ) // not found in db
		{
			if(header->msg.respcode != SHC_RC_DuplicateTransaction)
				header->msg.respcode = SHC_RC_NoOriginal;
		
			header->setReturnFlag( header->msg.respcode );
			thisShcApp->shcmsgHelperObj->shc_set_return_msgno(&header->msg);
			header->shcerr = SH_RETURN;
			header->setSkipFlag();
			return -1;
		}
	}
	
	return 0;
}



int ShcDualSecondMsgReq::retrieveFirstMsgRespResult()
{
	memset( &shcmsgSeg, 0, sizeof(shcmsgSeg) );
	int ret = thisShcApp->shcDualMsgHelperObj->retrieveFirstMsgResp( header, &shcmsgSeg );
	
	if ( ret < 0 )
	{
		OTraceInfo("I-SHC-16102: Not found first dual message response\n");
	}
	return ret;
}


