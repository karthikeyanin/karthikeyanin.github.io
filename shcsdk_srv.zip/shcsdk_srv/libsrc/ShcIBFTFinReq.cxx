static char _ShcIBFTFinReq_cxx_what[] = "@(#) ShcIBFTFinReq.cxx 1.10 16/05/10 12:20:55";

/*
 *  Copyright (C) 2004 eFunds Corporation ("eFunds").  All Rights Reserved.     
 *  eFunds Canada Corporation is an authorized user.                            
 *                                                                              
 *  IST is a registered trademark of eFunds Corporation.  Other brand or        
 *  product names are trademarks or registered trademarks of their respective   
 *  holders.                                                                    
 *                                                                              
 *  The information contained herein is the unpublished proprietary property    
 *  of eFunds.  Except as specifically authorized in writing by eFunds, the     
 *  holder of this document shall: i) keep all information contained herein     
 *  confidential, and ii) protect the information, in whole or in part, from    
 *  disclosure and dissemination to all third parties.                          
 *                                                                          
 *  This document and the software described in it are furnished under license  
 *  and may be used or copied only in accordance with the terms of such license.
 *  This document is supplied for information purposes only, is subject to      
 *  change without notice, and should not be construed as a commitment by       
 *  either eFunds Corporation or eFunds Canada Corporation. 
 *
 *
 *                        MODIFICATION HISTORY                  REVIEW
 *
 * SCR#     Who    Date  Description
 * ===========================================================================
 * R0xxxxx jyang 21Nov03 Created
 */
 
 //File Number 81

#include <stdio.h>
#include <string.h>
#include <ctype.h>
#include <oasis.h>
#include <ist_otrace.h>
#include <shc.h>
#include <ShcFinAuthReq.h>
#include <ShcFinAuthHelper.h>
#include <ShcmsgHelper.h>
#include <ShcCamHelper.h>
#include <ShcmsgProcessor.h>

#include <ShcIBFTFinReq.h>
#include <ShcRevReqHelper.h>
#include <ShcApp.h>
#include <ShcBin.h>
#include <ShcmsgTxnHelper.h>
#include <ShcIBFTHelper.h>
#include <shc_callback.h>


/*****************************************************************************/

int ShcIBFTFinReq::edit()
{
	int ret;

	//ShcFinAuthReq::edit()
	if(shcIsPassThrough(header->issShcBin->binPkg))
	{
		OTraceInfo("I-SHC-081001:shc_edit(): Exit because bin marked as passthrough.\n");
	   	return(SHC_RC_Approved);
	}

    /* 10002243 */
    if(header->msg.device_cap & SH_DEVCAP_FROM_REPLAY)
    {
        header->shcerr = SH_SENDISS | SH_SETTIMER;
		if (header->time_in >=10000000000)
        	header->time_out = header->time_in + 1000*shcApp->issuerShcParamsList->GetNum((char *)"shc.saf_timeout");
		else
        	header->time_out = header->time_in + shcApp->issuerShcParamsList->GetNum((char *)"shc.saf_timeout");
        header->setSkipFlag();
        return(0);
    }
    

	if (thisShcApp->shcFinAuthHelperObj->denyUpdateLogReq(header) < 0)
		return 0;

	if (!header->shouldContinue(TXN_PROC_SKIP_EDIT))
		return 0;

	OTraceInfo("I-SHC-081002: Continue ShcFinAuthReq::edit()\n");
		
	/* Authorize a financial request */
	int len;	


	/* Ssc - 28Jun00    R004671 integration to 7.2 */
	/* Ssc - 26Feb00    SPR # 2007336 VSDC enhancement */
    if( thisShcApp->shcCamHelperObj->shc_cam_request_start( header ) < 0 )
    {
        OTraceError("E-SHC-081003: Unable to start request to cam.\n");
        return(-1);
    }
    /* Ssc - 28Feb00    SPR # 2007336 */

	if (thisShcApp->shcFinAuthHelperObj->exitForProagentReq(header) < 0)
	{
		header->setSkipFlag();
		return 0;
	}

	int		isrepeat = 0;
		
	thisShcApp->shcmsgTxnHelperObj->setDefaultRoutingFlag(header);
	
											/* R007211 BEGIN */
	if (header->isrepeat())
	{
		if (thisShcApp->shcFinAuthHelperObj->actionOnRepeat(header) < 0)
			return 0;
	}		
	else	// R007615
		header->logFlag |= SHC_LOG_REQ;
										/* R007211 END */
	/*  22Jun93
		If the issuer does not support preauth no need to process a
		preauthorization request
	*/
	if (thisShcApp->shcFinAuthHelperObj->checkPreauthAllowed(header) < 0)
		return 0;
		
	if (thisShcApp->shcFinAuthHelperObj->checkDupTxn(header) < 0)
		return 0;
	
	/*	Check if the institution is up */
	if (thisShcApp->shcFinAuthHelperObj->checkBinDown(header) < 0)
		return 0;

//	if(!shcIsAdvice(header))
//		if(shc_edit_transaction(header) != SHC_RC_Approved)
//			return(header->msg.respcode);
///////////////////////////////////////////////////////////////////////////


	if (thisShcApp->shcFinAuthHelperObj->checkTxnSet(header) < 0)
		return 0;	

	if (thisShcApp->shcFinAuthHelperObj->checkAccountFundingTxn(header) < 0)
		return 0;
		

		/* R007206 & R007237 >> */
	if( thisShcApp->shcFinAuthHelperObj->checkEuroBinMbrTbl( header ) < 0 )
		return 0;
		/* << R007206 & R007237 */


	/*
	 *	Check transaction limits
	 */
	if (thisShcApp->shcFinAuthHelperObj->checkTxnLimit(header) < 0)
		return 0;

	
	/*
	 *	Check that the transaction is allowed on the card
	 */
	if (thisShcApp->shcFinAuthHelperObj->checkAccount(header) < 0)
		return 0;

	/*	Check for pre-authorization server */
	if (thisShcApp->shcFinAuthHelperObj->checkPreauthTxn(header) < 0)
		return 0;

	if (!header->shouldContinue(TXN_PROC_SKIP_EDIT))
	{
		OTraceInfo("I-SHC-081004:No further edit need to be done. respcode:%d\n", header->msg.respcode);
		return 0;
	}
	
	if (thisShcApp->shcFinAuthHelperObj->zeroAmountCheck(header) < 0)
	{
		thisShcApp->shcFinAuthHelperObj->shc_return_finauth(header, SHC_RC_InvalidAmount);
		return 0;
	}

	if (thisShcApp->shcFinAuthHelperObj->authorizeFloorLimit(header))	
		return(0);


	OTraceInfo("I-SHC-081005: ShcIBFTFinReq::edit(): Normal exit.\n");
	
	return 0;
}

int ShcIBFTFinReq::doWork()
{

	if (!header->shouldContinue(TXN_PROC_SKIP_DOWORK))
		return 0;

	if( shcIsIBFT(header) )
	{
		header->msg.origmsg = header->msg.msgtype;
		header->msg.origFlippedMsg = header->msg.flipped_msgtype;
		header->msg.origpcode = header->msg.pcode;
		if( shcmsgIsAdvice(&header->msg) )
		{
			thisShcApp->shcIBFTHelperObj->shc_advice_IBFT(header, SH_DEVCAP_SHC_IBFTW | SH_DEVCAP_SHC_IBFTD);
			header->logFlag = SHC_LOG_REQ;
			thisShcApp->shcFinAuthHelperObj->shc_return_finauth(header, SHC_RC_Approved);
			return( 0 );
		}

		thisShcApp->shcIBFTHelperObj->shc_create_IBFT(header, SH_DEVCAP_SHC_IBFTW);

		header->allocateAndCopyOrigMsg(&header->msg);
		header->origMsg->pcode = header->origMsg->origpcode;
		header->logFlag = SHC_LOG_ORIG;
	}
	

	if (thisShcApp->shcFinAuthHelperObj->decideSaf(header) < 0)
		return 0;

	if (thisShcApp->shcFinAuthHelperObj->translatePinBlock(header) < 0)
		return 0;
	
//	int callbackRet = shc_callback(header,"ibftauthout");
//	
//	switch(callbackRet)
//	{
//	case SHCCALLBACKDROP:
//		thisShcApp->shcmsgHelperObj->shc_callback_log(header, SHCCALLBACKDROP);
//		header->shcerr = SH_IGNORE;
//		OTraceInfo("I-SHC-081006: Dropped as ibftauthout callback function asked\n");
//		break;
//	case SHCCALLBACKDENY:
//		if (shcIsRequest(header))
//		{
//			if ( 	(header->msg.respcode == SHC_RC_Approved) ||
//					(header->msg.respcode == SHC_RC_PartialDispense) )
//				header->msg.respcode = SHC_RC_DoNotHonor;
//			OTraceInfo("I-SHC-081007: Denied as ibftauthout callback function asked\n");
//			return(thisShcApp->shcFinAuthHelperObj->shc_return_finauth(header, -1));
//		}
//	default:
//		break;
//	}
	
	return 0;

}
