static char _ShcRevResp_cxx_what[] = "@(#) ShcChargeBackResp.cxx 1.3 04/08/24 17:53:48";

/*
 *  Copyright (C) 2004 eFunds Corporation ("eFunds").  All Rights Reserved.     
 *  eFunds Canada Corporation is an authorized user.                            
 *                                                                              
 *  IST is a registered trademark of eFunds Corporation.  Other brand or        
 *  product names are trademarks or registered trademarks of their respective   
 *  holders.                                                                    
 *                                                                              
 *  The information contained herein is the unpublished proprietary property    
 *  of eFunds.  Except as specifically authorized in writing by eFunds, the     
 *  holder of this document shall: i) keep all information contained herein     
 *  confidential, and ii) protect the information, in whole or in part, from    
 *  disclosure and dissemination to all third parties.                          
 *                                                                          
 *  This document and the software described in it are furnished under license  
 *  and may be used or copied only in accordance with the terms of such license.
 *  This document is supplied for information purposes only, is subject to      
 *  change without notice, and should not be construed as a commitment by       
 *  either eFunds Corporation or eFunds Canada Corporation. 
 *
 *
 *                        MODIFICATION HISTORY                  REVIEW
 *
 *	SPR#	Who	Date	Description			Who	Date   
 * ===========================================================================
 * R0xxxxx jyang 21Nov03 Created
 */

//File Number 67

/*****************************************************************************/


#include <ShcRevRespHelper.h>
#include <ShcChargeBackResp.h>
#include <ShcApp.h>
#include <ShcChargeBackHelper.h>

	

/*****************************************************************************/
int ShcChargeBackResp::doWork()
{
	if( ! header->shouldContinue(TXN_PROC_SKIP_DOWORK) || header->createdInternal() )
		return 0;

	if ( thisShcApp->shcRevRespHelperObj->doReplay(header) == True )
		return 0;

	logresponse = thisShcApp->shcChargeBackHelperObj->prepareRespLogMessage(header);

//	Following function removed
//	thisShcApp->shcRevRespHelperObj->updateRespMessage( header, logresponse );

	thisShcApp->shcRevRespHelperObj->sendToPosauthSever(header);

	thisShcApp->shcRevRespHelperObj->setRoutingFlag(header);


//	Following function removed
//	thisShcApp->shcRevRespHelperObj->restoreBeforeRouting(header);
	
//	Following function removed
//	thisShcApp->shcRevRespHelperObj->overrideRespRoutingFlag( header );

	return(0);
}
		
