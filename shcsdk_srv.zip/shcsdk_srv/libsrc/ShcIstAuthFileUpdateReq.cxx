static char _ShcIstAuthFileUpdateReq_cxx_what[] = "@(#) ShcIstAuthFileUpdateReq.cxx 1.40.14.2 19/08/19 08:08:44";

/*
 *  Copyright (C) 2004 eFunds Corporation ("eFunds").  All Rights Reserved.
 *  eFunds Canada Corporation is an authorized user.
 *
 *  IST is a registered trademark of eFunds Corporation.  Other brand or
 *  product names are trademarks or registered trademarks of their respective
 *  holders.
 *
 *  The information contained herein is the unpublished proprietary property
 *  of eFunds.  Except as specifically authorized in writing by eFunds, the
 *  holder of this document shall: i) keep all information contained herein
 *  confidential, and ii) protect the information, in whole or in part, from
 *  disclosure and dissemination to all third parties.
 *
 *  This document and the software described in it are furnished under license
 *  and may be used or copied only in accordance with the terms of such license.
 *  This document is supplied for information purposes only, is subject to
 *  change without notice, and should not be construed as a commitment by
 *  either eFunds Corporation or eFunds Canada Corporation.
 *
 *
 *                        MODIFICATION HISTORY                  REVIEW
 *
 *	SPR#	Who	Date	Description			Who	Date
 * ===========================================================================
 *      sreeram 16mar20 istauth base global changes
 */
#include <ShcIstAuthFileUpdateReq.h>
#include <ShcApp.h>
#include <shc_callback.h>
#include <TxnStat.h>
#include <ShcFinAuthHelper.h>
#include <ShcmsgTxnHelper.h>
#include <ShcmsgHelper.h>
#include <ShcTimerHelper.h>

int ShcIstAuthFileUpdateReq::enrich()
{
	int len = 0;

	OTraceDebug("D-SHC-510001:ShcIstAuthFileUpdateReq::enrich begin\n");

	struct shc_data *pShcData = (struct shc_data *)&header->msg.shc_data_buffer;

	thisShcApp->shcmsgTxnHelperObj->setOriginator(header);
	thisShcApp->shcmsgHelperObj->shc_normalizepan(header->msg.pan);

	if ( !header->issBinValid() )
	{
		header->setReturnFlag(header->msg.respcode);
        OTraceError("E-SHC-510002: issuer bin is not valid\n");
		return -1;
	}

	thisShcApp->shcmsgTxnHelperObj->setProcessorBusDay(header);
	//thisShcApp->shcmsgHelperObj->setPinParm(header);
	OTraceInfo("I-SHC-074002: (istauth file update header) enrich(iss=%s)\n", header->msg.issuer );

    header->repeatFlag = thisShcApp->shcFinAuthHelperObj->checkRepeatFileUpdate(header);
	if ( header->repeatFlag > 0)
	{
        OTraceDebug("D-SHC-510002: this is a repeat message, original already processed\n" );
        header->msg.respcode = header->reqMsg->respcode;
        OTraceDebug("D-SHC-510003: returning original response code [%d]\n", header->msg.respcode );
		header->logFlag = 0;
		//header->setReturnFlag(header->reqMsg->respcode);
		thisShcApp->shcmsgHelperObj->shc_set_return_msgno(&header->msg);
		header->shcerr = SH_RETURN;
		header->setSkipFlag();
		return thisShcApp->shcFinAuthHelperObj->shc_return_finauth(header, header->msg.respcode );
	}
	return 0;
}

int ShcIstAuthFileUpdateReq::restore()
{
	if (!header->shouldContinue(TXN_PROC_SKIP_RESTORE))
		return 0;
	return 0;
}


int ShcIstAuthFileUpdateReq::edit()
{
	if (!header->shouldContinue(TXN_PROC_SKIP_EDIT)){
        OTraceDebug("I-SHC-510004: ShcIstAuthFileUpdateReq::edit skipped\n");
		return 0;
    }
	OTraceInfo("I-SHC-510005: edit(): Normal exit.\n");
	return(0);
}

int ShcIstAuthFileUpdateReq::verify()
{
	if (!header->shouldContinue(TXN_PROC_SKIP_VERIFY))
		return 0;


	int callbackRet = shc_callback(header, "shc_edit_transaction");
	switch(callbackRet)
	{
        case SHCCALLBACKDENY:
            if (shcIsRequest(header))
            {
                if ( 	(header->msg.respcode == SHC_RC_Approved) ||
                        (header->msg.respcode == SHC_RC_PartialDispense) )
                    header->msg.respcode = SHC_RC_DoNotHonor;
                OTraceInfo("I-SHC-074013: Denied as shc_edit_transaction callback function asked\n");
                thisShcApp->shcFinAuthHelperObj->shc_return_finauth(header, -1);
                return 0;
            }
            break;
        case SHCCALLBACKOVERRIDE:
            OTraceInfo("I-SHC-074014: Performed custom shc_edit_transaction\n");
            return 0;
            break;
        case SHCCALLBACKDROP:
            header->setIgnoreFlag();
            thisShcApp->shcmsgHelperObj->shc_callback_log(header, SHCCALLBACKDROP);
            OTraceLog("L-SHC-074015: Drop message ID[%s]/m%04d/t%06ld/p%06ld\n", header->msg.shclog_id,
                header->msg.msgtype, header->msg.trace, header->msg.pcode);
            TxnStatReport(header->msg.shclog_id,TS_SHC,TSR_DROP,DROP_BY_CALLBACK_shc_edit_transaction,0,0);
            return 0;
        case SHCCALLBACKCONTINUE:
        default:
            break;
	}

	return 0;
}

int ShcIstAuthFileUpdateReq::doWork()
{

	if (!header->shouldContinue(TXN_PROC_SKIP_DOWORK))
		return 0;

	int callbackRet = shc_callback(header,"finauthout");
	switch(callbackRet)
	{
        case SHCCALLBACKDROP:
            thisShcApp->shcmsgHelperObj->shc_callback_log(header, SHCCALLBACKDROP);
            header->shcerr = SH_IGNORE;
            OTraceLog("L-SHC-074020: Drop message ID[%s]/m%04d/t%06ld/p%06ld\n", header->msg.shclog_id,
                header->msg.msgtype, header->msg.trace, header->msg.pcode);
            TxnStatReport(header->msg.shclog_id,TS_SHC,TSR_DROP,DROP_BY_CALLBACK_finauthout,0,0);
            break;
        case SHCCALLBACKDENY:
            if (shcIsRequest(header))
            {
                if ( 	(header->msg.respcode == SHC_RC_Approved) ||
                        (header->msg.respcode == SHC_RC_PartialDispense) )
                    header->msg.respcode = SHC_RC_DoNotHonor;
                OTraceInfo("I-SHC-074021: Denied as finauthout callback function asked\n");
                return(thisShcApp->shcFinAuthHelperObj->shc_return_finauth(header, -1));
            }
        default:
            break;
	}

    header->applMailboxId = header->issShcBin->binPkg->auth.authserver;
    header->shcerr &=  ~SH_SENDISS;
    header->shcerr = SH_SENDAPPL|SH_SETTIMER;
    header->logFlag |= SHC_LOG_REQ;
    thisShcApp->shcTimerObj->shc_set_timers(header);
    header->setSkipFlag();
	return 0;
}
