static char _ShcFRSResp_cxx_what[] = "@(#) ShcFRSResp.cxx 1.2 05/01/10 15:05:49";

/*
 *  Copyright (C) 2004 eFunds Corporation ("eFunds").  All Rights Reserved.     
 *  eFunds Canada Corporation is an authorized user.                            
 *                                                                              
 *  IST is a registered trademark of eFunds Corporation.  Other brand or        
 *  product names are trademarks or registered trademarks of their respective   
 *  holders.                                                                    
 *                                                                              
 *  The information contained herein is the unpublished proprietary property    
 *  of eFunds.  Except as specifically authorized in writing by eFunds, the     
 *  holder of this document shall: i) keep all information contained herein     
 *  confidential, and ii) protect the information, in whole or in part, from    
 *  disclosure and dissemination to all third parties.                          
 *                                                                          
 *  This document and the software described in it are furnished under license  
 *  and may be used or copied only in accordance with the terms of such license.
 *  This document is supplied for information purposes only, is subject to      
 *  change without notice, and should not be construed as a commitment by       
 *  either eFunds Corporation or eFunds Canada Corporation. 
 *
 *
 *                        MODIFICATION HISTORY                  REVIEW
 *
 *	SPR#	Who	Date	Description			Who	Date   
 *===========================================================================
 *R00xxxx
 */
/* File Number 79 */

#include <stdio.h>
#include <string.h>
#include <ctype.h>
#include <oasis.h>
#include <ist_otrace.h>
#include <tm.h>
#include <shc.h>
#include <ShcSdkCommon.h>
#include <CShcLog.h>
#include <ShcTimerHelper.h>
#include <ShcFRSResp.h>
#include <ShcmsgHelper.h>
#include <ShcApp.h>
#include <ShcFinAuthHelper.h>


int ShcFRSResp::restore()
{
    thisShcApp->shcFinAuthHelperObj->shc_restore_fields(header);
    header->msg.senderid    = header->reqMsg->senderid;
    header->msg.unit        = header->reqMsg->unit;
    thisShcApp->shcFinAuthHelperObj->restoreCallback(header);
	return 0;
}

int  ShcFRSResp::doWork()
{
    struct  ShcWithSegment omsg;
	int ret = -1 ;
	int save_msgtype;
	int save_respcode, save_shcerror;


	if(!(header->shcerr & SH_NO_TIMER_PRESENT))
        tm_dequeue(header->eventId);


	header->logFlag = SHC_LOG_UPD_REQ;
	
	header->shcerr = SH_RETURN;

	return(0);
}







