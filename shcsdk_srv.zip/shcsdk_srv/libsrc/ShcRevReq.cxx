static char _ShcRevReq_cxx_what[] = "@(#) ShcRevReq.cxx 1.37 19/12/11 02:13:22";

/*
 *  Copyright (C) 2004 eFunds Corporation ("eFunds").  All Rights Reserved.     
 *  eFunds Canada Corporation is an authorized user.                            
 *                                                                              
 *  IST is a registered trademark of eFunds Corporation.  Other brand or        
 *  product names are trademarks or registered trademarks of their respective   
 *  holders.                                                                    
 *                                                                              
 *  The information contained herein is the unpublished proprietary property    
 *  of eFunds.  Except as specifically authorized in writing by eFunds, the     
 *  holder of this document shall: i) keep all information contained herein     
 *  confidential, and ii) protect the information, in whole or in part, from    
 *  disclosure and dissemination to all third parties.                          
 *                                                                          
 *  This document and the software described in it are furnished under license  
 *  and may be used or copied only in accordance with the terms of such license.
 *  This document is supplied for information purposes only, is subject to      
 *  change without notice, and should not be construed as a commitment by       
 *  either eFunds Corporation or eFunds Canada Corporation. 
 *
 *
 *
 *                        MODIFICATION HISTORY                  REVIEW
 *
 *	SPR#	Who	Date	Description			Who	Date   
 * ===========================================================================
 * R0xxxxx jyang 21Nov03 Created
 * R012160 Emj   10Oct04 Set Processor Business Day
 * R018276 pve	 27Nov06 Add new OTraceLog messages
 * R021068 Ash   31Aug07 Avoid SHC Restart When Reversal for  Partial Dispense is send
 * R027562 Dipa  27Nov09 Duplicate reversals will be inserted in SHCLOG with shcerror=7
 * R027663 Ash   17Dec09 Avoid shc replying to the 420 with a 420 back  to the atmserver during uncertain Dispense
 * R027906 las   03Mar09 update respcode on original for uncertain dispense reversals
 * R027905 Dipa  25Mar10 Reversal-Void Enhancement
 * R028271 Dipa  18Jun10 Txn Statistics
 * R030381 Dipa  02Mar12 Txn Statistics
 */

//File Number 116

#include <ShcRevReqHelper.h>
#include <ShcRevReq.h>
#include <ShcApp.h>
#include <ShcBin.h>
#include <ShcmsgTxnHelper.h>
#include <ShcTimerHelper.h>
#include <ShcmsgHelper.h>
#include <shc_callback.h>
#include <ShcChargeBackHelper.h>
#include <ShcRevMRHelper.h>

#include <asynchSecApi.h>
#include <ShcAsynchApi.h>

extern int setAsynchRespcode(ShcmsgHeader *,int,int);

//R028271 >>>
#include <TxnStat.h>
//<<< R028271

int ShcRevReq::dupRevCheckDone = 0;
/*****************************************************************************/

int ShcRevReq::enrich()
{
	/*
	 *	Financial Reversal
	 *
	 *	Please NOTE:		We do not expect a matching transaction on
	 *						the event QUEUE.
	 *
	 *						We reply to the acquirer immediatly without
	 *						waiting for host reply: Why?disableDuplicatCheckFlag Simple: We must
	 *						ALWAYS accept a reversal!!!!
	 */

	dupRevCheckDone = 0;
	int ret = 0;

	if(ist_otrace_get_level() >= OTRACE_DEBUG)
	{
		char	buf1[50];
		OTraceDebug("D-SHC-116001:  Process reverse request transaction\n");	
		OTraceDebug("D-SHC-116002:   response code        : %12d\n", header->msg.respcode);
		dbm_dectochar(&header->msg.aval_balance, buf1);
		OTraceDebug("D-SHC-116003:   available balance    : %12s\n", buf1);
		dbm_dectochar(&header->msg.new_setl_amount, buf1);
		OTraceDebug("D-SHC-116004:   new settlement amount: %12s\n", buf1);
	}
	
	//ShcmsgBaseTxn::enrich();
	if (header->createdInternal())
		return 0;
		
	if (header->msg.msgtype == SHC_AUTHCOMP)
	{
		header->msg.msgtype = SHC_REVREQ;
		struct shc_data *shc_data_ptr = (struct shc_data *)header->msg.shc_data_buffer;
		shc_setbiton(shc_data_ptr->device_cap,SHC_DATA_DEVICE_CAP_IS_AUTHCOMP);
		dbm_deccopy(&header->msg.new_amount, &header->msg.cash_back);
		header->msg.respcode = SHC_RC_PartialDispense;
		header->msg.revcode = SHC_RR_PartialDispense;			
	}
	thisShcApp->shcmsgTxnHelperObj->setDefaultKeyLen(header);
	thisShcApp->shcmsgTxnHelperObj->setOriginator(header);
	thisShcApp->shcmsgHelperObj->shc_normalizepan(header->msg.pan);
	
	if (!(header->issBinValid()) || !(header->acqBinValid()))
	{
		header->setReturnFlag(header->msg.respcode);
		return -1;
	}
	
//	thisShcApp->shcmsgTxnHelperObj->setParamSet(header);
	thisShcApp->shcmsgTxnHelperObj->setProcessorBusDay(header);
//	thisShcApp->shcmsgTxnHelperObj->setCapDate(header);
	thisShcApp->shcmsgHelperObj->shc_get_pin_data(header);
	thisShcApp->shcmsgTxnHelperObj->setCurrencyCode(header);
	thisShcApp->shcmsgTxnHelperObj->initFromDevice(header);
	thisShcApp->shcmsgTxnHelperObj->setAcqCountry(header);
	thisShcApp->shcmsgTxnHelperObj->decideTimeOutValue(header);
	thisShcApp->shcmsgHelperObj->setPinParm(header);
	thisShcApp->shcmsgTxnHelperObj->setOnlineActivity(header);

	if(header->msg.device_cap & SH_DEVCAP_FROM_REPLAY)
		return 0;

	/*
     * R001835 Checking the MAC for 420/422 from network (ACXSYS)
     */
	// Check if is a regular transaction validation
	if(!(header->shcerr & SH_ASYNCH_RESUME))
	{
		if((ret = thisShcApp->shcRevReqHelperObj->verifyReqRevMac(header)) < 0)
		{
			OTraceWarning("W-SHC-116005: MAC Reversal Request Not Verified\n");

			thisShcApp->shcmsgHelperObj->shc_set_return_msgno(header);
			header->shcerr = SH_RETURN;

			header->logFlag |= SHC_LOG_REQ;

			header->setReturnFlag(header->msg.respcode);
			return(-1);
		}
		if(ret==SEC_ASYNCH_WAIT)
		{
			OTraceDebug("D-SHC-001203 MAC Pending validation for Reversal Request\n");
			header->shcerr=SH_IGNORE;
			// Skip rest of the process and wait for SecSrv response
			header->setSkipFlag(TXN_PROC_SKIP_RESTORE|TXN_PROC_SKIP_EDIT|TXN_PROC_SKIP_VERIFY|TXN_PROC_SKIP_DOWORK);
			return(0);
		}
	}
	// MAC validation failed
	else if(header->msg.respcode)
	{	// Keep respcode from asynch resume result
		if(!(header->shcerr & SH_ASYNCH_RESUME))
		{
			// Clear respcode, will be set by shc_return_finauth
			header->msg.respcode=0;
		}
		else
		{
			// asynchSecResp is set on getAsynchEvent & is defined in SecSrv
			setAsynchRespcode(header,asynchSecResp.cmdId,asynchSecResp.respCode);
		}
		OTraceDebug("D-SHC-001204 Denied: Invalid MAC for Reversal Request\n");
		return(-1);
	}
    
	OTraceInfo("I-SHC-116006: (header) enrich(iss=%s, acq=%s),(txnSrc=%s, txnDest=%s)\n",
			header->msg.issuer, header->msg.acquirer,
			header->msg.txnSrc, header->msg.txnDest);

	
	thisShcApp->shcRevReqHelperObj->setReqEmvFlag(header);

	return 0;
}

/*****************************************************************************/

int ShcRevReq::restore()
{
	if( ! header->shouldContinue(TXN_PROC_SKIP_RESTORE) )
		return 0;

	if(header->msg.device_cap & SH_DEVCAP_FROM_REPLAY)
		return 0;

	save_msgtype = header->msg.msgtype;
	if(!shcIsReversal(header))
		header->msg.msgtype = SHC_REVREQ;
	
	OTraceDebug("D-SHC-116011: Check if already reversed.\n");
	
	dupRevCheckDone = 1;
		bool disableDuplicatCheckFlag=shcApp->issuerShcParamsList ->GetBool((char *)"shc.disableDuplicatCheckFlag");
	if(disableDuplicatCheckFlag)
		OTraceDebug("D-SHC-116019: Disable Duplicate Check Reversal flag is enabled.Skipping Duplicate Check\n");
	if(!(disableDuplicatCheckFlag) && (header->shcLogObj->locateTxn(header) == 0))
	{
		header->shcLogObj->rewind();
        int isContinueRespCode = (header->reqMsg->respcode == SHC_RC_IssuerTimeout) ||
                         	(header->reqMsg->respcode == SHC_RC_ShcTimeout) ||
                         	(header->reqMsg->respcode == SHC_RC_MACKeyError) ||
							(header->reqMsg->respcode == SHC_RC_IssuerDown) ||
                         	(header->reqMsg->respcode == SHC_RC_MACSyncError);
		/* We already have a reversal. Ignore this one */
		 if(shcmsgIsResponse(header->reqMsg) && !isContinueRespCode)
		 {
			OTraceError("E-SHC-116012: Duplicate reversal: %d\n", header->msg.trace);
			//header->shcerr = SH_NOREVUPD;   //R027562 - Duplicate reversals should be inserted in SHCLOG
			header->msg.msgtype = save_msgtype;
			header->msg.shcerror = SHC_IE_Duplicate; //R027562 - with shcerror=7
			
			/*
			 * R001835 Interac wants a Approve
			 */
			if(shcIsRevAdvice(header) && header->issShcBin->isInterac() ||
			   shcIsRevIssReq(header) && header->acqShcBin->isInterac()) 
			{
				header->msg.respcode = SHC_RC_Approved;
			}
			else if (header->msg.msgtype % 10 != 1)
			{	
				/* Not repeat message */
				header->msg.respcode = SHC_RC_DuplicateReversal;
			}
			else
			{
				/* Repeat message */
				header->msg.respcode = header->reqMsg->respcode;
			}
			
			if (header->msg.msgtype % 10 == 1)
			{
				/* Restore some information from last response or repeat message */
				strcpy(header->msg.alpha_response_code, header->reqMsg->alpha_response_code);
				header->msg.flipped_msgtype = header->reqMsg->flipped_msgtype;
			}
			
			thisShcApp->shcRevReqHelperObj->returnReversal(header);
			
			/* If Advice message should return to sender */
			if(header->msg.device_cap & SH_DEVCAP_UPDATE_LOGS)
			{
				header->shcerr = SH_RETURN;		/* 17Jun94 */
			}
			
			header->setReturnFlag(header->msg.respcode);
			header->shcerr = SH_RETURN;
			header->setSkipFlag();
			return(-1);
		}
		else
		{
			/* Found a request in shclog, need to decide the reversal request is still in process */
			if(thisShcApp->shcTimerObj->shc_locate_event_x(header, NULL, NULL) >= 0)
			{
				/* last reversal is still in process, drop this one */
				header->shcerr = SH_IGNORE;
				/*OTraceInfo("D-SHC-116013: Event for msg[%d] trace[%d] pending, repeat message dropped\n",
						header->msg.msgtype, header->msg.trace);*/
				//      >>>     R018276
				OTraceLog("L-SHC-116013: Drop repeat message ID[%s]/m%04d/t%06ld/p%06ld\n", header->msg.shclog_id,
					header->msg.msgtype, header->msg.trace, header->msg.pcode);
				//	<<<     R018276

				header->logFlag |= SHC_LOG_REQ; //R027562
				header->msg.shcerror = SHC_IE_Duplicate; //R027562

				header->setIgnoreFlag();
				return -1;
			}
		}
	}
	else
	{
		/*	Transaction does not exist: Log it */
		
		/*
		*	18Feb94
		*	If txn orignate from other ist machine
		*	log it as reponse rather then request.
		*/
		/* 10002243 */
		header->shcLogObj->rewind();
		if(header->msg.device_cap & SH_DEVCAP_UPDATE_LOGS)
		{
			//  >>> R027663 commented some lines and modified some lines
			header->logFlag |= SHC_LOG_REQ|SHC_LOG_UPD_REQ;
			OTraceDebug("D-SHC-116016:SET LOG_REQ AND LOG_UPD_REQ \n");
			thisShcApp->shcmsgHelperObj->shc_set_return_msgno(header);
			//	>>>	R027906
			//header->setSkipFlag();
			//header->shcerr = SH_RETURN;
			//return -1;
			//	<<<	R027906
			//  <<< R027663
		}
		else
//			flagLogRequest = True;								/* 10002243 */
			header->logFlag |= SHC_LOG_REQ;
	}


	/* 1. Locate the original transaction */
	int save_trace = header->msg.trace;

	OTraceDebug("D-SHC-116007:(%d)locate original transaction\n",__LINE__);

	int origFound = thisShcApp->shcmsgHelperObj->locateOrigTxn(header);

	// If original found and is daul site
	// If original is req   which was logged on other site handle as not found

	if (mbIsDualSite())
	{
		if(header->origMsg && (header->origMsg->msgtype % 20 != 10) && header->origMsg->site_id != mbGetSiteId())
		{

	 		OTraceDebug("D-SHC-17031:Original Req logged by other site, drop origMsg\n");
			delete header->origMsg;
			header->origMsg = NULL;
			if (header->origSegList)
			{
				delete header->origSegList;
				header->origSegList = NULL;
			}
			origFound = -1;
		}
	}


	if(origFound < 0)
	{

		
		if (mbIsDualSite())
		{
			ShcRevMRHelper::getInstance()->setSegmentRevNoOrig(header);
		}


		// R027905 >>>
		if (header->msg.respcode == SHC_RC_MismatchBatch)
		{
			header->setReturnFlag(header->msg.respcode);
			header->logFlag |= SHC_LOG_REQ;
			header->shcerr = SH_RETURN;
			header->shcLogObj->rewind();
			return ( -1 );
		}
		// <<< R027905

		OTraceError("E-SHC-116008: Unable to locate original trace %d for reversal\n",
			header->msg.trace);
		
		header->msg.auth_devcap |= SH_DEVCAP_AUTH_NO_ORIG;
		header->msg.msgtype	 = save_msgtype;
		header->msg.trace	 = save_trace;
		
		
		header->msg.shcerror = SHC_IE_NoMatch;
		header->msg.respcode = SHC_RC_NoOriginal;
		header->setReturnFlag(header->msg.respcode); // R031524
		if(shcIsRevIssReq(header)) 
			thisShcApp->shcChargeBackHelperObj->routeReversal(header, 0);
		else
			thisShcApp->shcRevReqHelperObj->routeReversal(header, 0 );
		
		//header->setReturnFlag(header->msg.respcode);
		header->logFlag |= SHC_LOG_REQ;
		if (mbIsDualSite() && header->msg.respcode == SHC_RC_NoOriginal && 
			!(header->msg.shc_devcap & SH_DEVCAP_SHC_EVENT) && header->shcerr == SH_IGNORE )
			header->logFlag = 0;
		header->shcLogObj->rewind();
		return(-1);
	}
	
			/* R007504 >> Searching & removing original message event */
	ShcmsgHeader tmpHeader(header->origMsg);
	
	thisShcApp->shcTimerObj->shc_locate_event(&tmpHeader);
	if( tmpHeader.eventId >= 0 )	//	---	R026142
	{
		if (!(header->msg.device_cap & SH_DEVCAP_FROM_REPLAY))
		{
			OTraceDebug("D-SHC-117009: Dequeued the orig txn event(%d)\n", tmpHeader.eventId );
			tm_dequeue( tmpHeader.eventId );
		}

		if (shcIsRequest(&tmpHeader))
		{
			//the original msg in shclog is request, use the msg from event because it contains more info
			header->allocateAndCopyOrigMsg(tmpHeader.reqMsg);
		}
	}
			/* R007504 << */
	
	header->msg.msgtype = save_msgtype;
	header->msg.trace	= save_trace;
	
	switch(thisShcApp->shcmsgHelperObj->shc_restoreOriginal(header))			/* R008224 */
	{
	case SHCCALLBACKDENY:
		if ( 	(header->msg.respcode == SHC_RC_Approved) ||
				(header->msg.respcode == SHC_RC_PartialDispense) )
			header->msg.respcode = SHC_RC_DoNotHonor;
		OTraceDebug("I-SHC-116009: Message denied required by restore original callback function\n");
		thisShcApp->shcRevReqHelperObj->returnReversal(header);
		header->setReturnFlag(header->msg.respcode);
		return (-1);
	case SHCCALLBACKDROP:
		//OTraceDebug("I-SHC-116010: Message dropped required by restore original callback function\n");
		//      >>>     R018276
		OTraceLog("L-SHC-116010: Drop message ID[%s]/m%04d/t%06ld/p%06ld\n", header->msg.shclog_id,
			header->msg.msgtype, header->msg.trace, header->msg.pcode);
		//	<<<     R018276
		thisShcApp->shcmsgHelperObj->shc_callback_log(header, SHCCALLBACKDROP);
		//R028271 >>>
		TxnStatReport(header->msg.shclog_id,TS_SHC,TSR_DROP,DROP_BY_CALLBACK_REV_shc_restoreOriginal,0,0);
		//<<< R028271
		header->setIgnoreFlag();
		return (-1);
	default:
		break;
	}
	header->shcLogObj->rewind();
	
	return 0;
}

/*****************************************************************************/

int ShcRevReq::edit()
{
    
    return 0;
}


/*****************************************************************************/

int ShcRevReq::verify()
{

	if( ! header->shouldContinue(TXN_PROC_SKIP_VERIFY) )
		return 0;
		
	if(header->msg.device_cap & SH_DEVCAP_FROM_REPLAY)
		return 0;
	
	//The check duplicate reversal should be done in restore, 
	//following code is for backward compatibility only. It should be removed 
	// in next major switch release e.g. 7.7
	if (dupRevCheckDone)
		return 0;

	/* Check if the reversal already exists */
	
//	int	 logrequest = False;									/* 10002243 */
	header->logFlag &= ~SHC_LOG_REQ;
	
	save_msgtype = header->msg.msgtype;
	if(!shcIsReversal(header))
		header->msg.msgtype = SHC_REVREQ;
	
	OTraceDebug("D-SHC-116011: Check if already reversed.\n");
	
	if(header->shcLogObj->locateTxn(header) == 0)
	{
		header->shcLogObj->rewind();
        int isContinueRespCode = (header->reqMsg->respcode == SHC_RC_IssuerTimeout) ||
                         	(header->reqMsg->respcode == SHC_RC_ShcTimeout) ||
                         	(header->reqMsg->respcode == SHC_RC_MACKeyError) ||
							(header->reqMsg->respcode == SHC_RC_IssuerDown) ||
                         	(header->reqMsg->respcode == SHC_RC_MACSyncError);
		/* We already have a reversal. Ignore this one */
		 if(shcmsgIsResponse(header->reqMsg) && !isContinueRespCode)
		 {
			OTraceError("E-SHC-116012: Duplicate reversal: %d\n", header->msg.trace);
			//header->shcerr = SH_NOREVUPD;  //R027562
			header->msg.msgtype = save_msgtype;
			header->msg.shcerror = SHC_IE_Duplicate; //R027562
			
			/*
			 * R001835 Interac wants a Approve
			 */
			if(shcIsRevAdvice(header) && header->issShcBin->isInterac() ||
			   shcIsRevIssReq(header) && header->acqShcBin->isInterac()) 
			{
				header->msg.respcode = SHC_RC_Approved;
			}
			else if (header->msg.msgtype % 10 != 1)
			{	
				/* Not repeat message */
				header->msg.respcode = SHC_RC_DuplicateReversal;
			}
			else
			{
				/* Repeat message */
				header->msg.respcode = header->reqMsg->respcode;
			}
			
			if (header->msg.msgtype % 10 == 1)
			{
				/* Restore some information from last response or repeat message */
				strcpy(header->msg.alpha_response_code, header->reqMsg->alpha_response_code);
				header->msg.flipped_msgtype = header->reqMsg->flipped_msgtype;
			}
			
			thisShcApp->shcRevReqHelperObj->returnReversal(header);
			
			/* If Advice message should return to sender */
			if(header->msg.device_cap & SH_DEVCAP_UPDATE_LOGS)
			{
				header->shcerr = SH_RETURN;		/* 17Jun94 */
			}
			
			header->setReturnFlag(header->msg.respcode);
			header->shcerr = SH_RETURN;
			header->setSkipFlag();
			return(-1);
		}
		else
		{
			/* Found a request in shclog, need to decide the reversal request is still in process */
			if(thisShcApp->shcTimerObj->shc_locate_event_x(header, NULL, NULL) >= 0)
			{
				/* last reversal is still in process, drop this one */
				header->shcerr = SH_IGNORE;
				/*OTraceInfo("D-SHC-116013: Event for msg[%d] trace[%d] pending, repeat message dropped\n",
						header->msg.msgtype, header->msg.trace);*/
				//      >>>     R018276
				OTraceLog("L-SHC-116013: Drop repeat message ID[%s]/m%04d/t%06ld/p%06ld\n", header->msg.shclog_id,
					header->msg.msgtype, header->msg.trace, header->msg.pcode);
				//	<<<     R018276

				header->logFlag |= SHC_LOG_REQ; //R027562
				header->msg.shcerror = SHC_IE_Duplicate; //R027562

				header->setIgnoreFlag();
				return -1;
			}
		}
	}
	else
	{
		/*	Transaction does not exist: Log it */
		
		/*
		*	18Feb94
		*	If txn orignate from other ist machine
		*	log it as reponse rather then request.
		*/
		/* 10002243 */
		header->shcLogObj->rewind();
		if(header->msg.device_cap & SH_DEVCAP_UPDATE_LOGS)
		{
			//  >>> R027663 commented some lines and modified some lines
			header->logFlag |= SHC_LOG_REQ|SHC_LOG_UPD_REQ;
			OTraceDebug("D-SHC-116016:SET LOG_REQ AND LOG_UPD_REQ \n");
			thisShcApp->shcmsgHelperObj->shc_set_return_msgno(header);
			//	>>>	R027906
			//header->setSkipFlag();
			//header->shcerr = SH_RETURN;
			//return -1;
			//	<<<	R027906
			//  <<< R027663
		}
		else
//			flagLogRequest = True;								/* 10002243 */
			header->logFlag |= SHC_LOG_REQ;
	}
	
	return 0;
}

/*****************************************************************************/

int ShcRevReq::doWork()
{
	if( ! header->shouldContinue(TXN_PROC_SKIP_DOWORK) )
		return 0;

	if ( thisShcApp->shcRevReqHelperObj->doReplay(header) == True )
		return 0;

	OTraceInfo("I-SHC-116014:(%d)reverse switch transaction\n",__LINE__);

//	if( flagLogRequest )									/* 10002243 */
//	if( header->logFlag & SHC_LOG_REQ )
//		shcLogObj->logTxn(header);							/* 10002243 */

	if ( thisShcApp->shcRevReqHelperObj->needReqReversal(header) == False )
		return (-1);
		
	if ( thisShcApp->shcRevReqHelperObj->updateOriginal(header) == False )
		return (-1);

	if ( thisShcApp->shcRevReqHelperObj->needReqUpdateLog(header) == False )
		return 0;

	//  >>>    R021068 

	if(header->origMsg)
		thisShcApp->shcRevReqHelperObj->routeReversal(header, header->origMsg->saf);
	else
		thisShcApp->shcRevReqHelperObj->routeReversal(header,0);
	//  <<<     R021068

	OTraceDebug("D-SHC-116015:Leave function ShcRevReq::doWork()\n");
	
	return(0);
}



/*****************************************************************************/
/*****************************************************************************/
/*****************************************************************************/

/*
 *                        MODIFICATION HISTORY                  REVIEW
 *
 *	SPR#	Who	Date	Description			Who	Date   
 * ===========================================================================
 *	ad		29jan92		created function shc_locate_original()
 *						which allows a reversal without the 'origmsg'
 *						field to be filled. The function attempts to
 *						locate a 100 and then 200.
 *	ad		29feb92		Added SHC_RC_DeviceTimeOut to list of codes which
 *						should be reversed.
 *	ad		18mar92		Use shc_set_return_msgno() in return_reversal()
 *	ad		24mar92		made slight adjustments for accepting advice
 *						transactions.
 *  bsa		30jul92  	added option to seek approval from issuer before
 *						replying to acq with reversal approval.
 *	bsa		30jul92		in return_rev() check if flag SH_NOREVUPD is
 *						set.
 *	ad		23oct92		Check for internal rev flag
 *	ss		27Nov92		Check for issbin flags for GETAPP_HOST instead
 *	MI		13Jul93		Reversals generated under preauth support.
 *	ad		17aug93		In route reversal: Was always setting message type
 *						to REVREQ. Changed to only do so if msgtype != 04xx
 *	ss		18Feb94		Log txn as response when update_log flag is on.
 *	ss		23Mar94		Let update the original message even we said
 *						reversal to issuer. It is because the shc_revresp.c
 *						need to locate the original revcode and update it.
 *	ss		17Jun94		If duplicate reversal and from istadvice, should
 *						reply to sender so that it will not re-saf again.
 *	ss		09mar95		Should update the 400 in db to 410 when we need to
 *						responde to 400 ourself.
 *  JSG-zm  10Apr96     Restore pos_condition_code from old message for EDC.
 *	zm		02jun96		Restore original pcode from old message for EDC
 * 10002022	zm  17May96	On EDC Reversal, update termtotals only once.
 * 10001371 la  20mar96 Update new amount field in original.
 * 10001856 la  12mar96	Set recon flag for reversal messages.
 * 10002113 la  01jun96 Correcy fix for SPR# 10001856.
 * 10002243 la  03jul96 Reverse totals for advice transactions.
 * 10002243 la  04jul96 Restore local date and time if not present.
 * 10002241 la  04jul96 Return approved for negative stand-in reversal.
 * 10002243 la  04jul96 Restore settlement date if not present.
 * 10002273 la  19aug96 Use new APIs and macros for IBFT processing.
 * 10002688 qd  21oct96 Keep respcode SHC_RC_PartialDispense for 04xx messages 
 * 10002675 jsg 961108  Send only IBFT deposit  
 * 2002016	jt	21nov96 Not send reversal for device time out if orig txn is 
 *						not approved.
 * 1002864  jt  13dec96 Added config for shcSendIss_420NoOrig.      
 * 2002240  qd  02jan97 Retore serial_1 and originator from the original
 * 			qd  02jan97 Get authnum from the original if it is not present  
 * 			qd  02jan97 Use origtrace to locate original if it is present  
 * 			qd  27may97 Added charge back related functionality  
 * xxxxxxx  yh  22sep97 Restore issuer_data from the original for reversal for SMS
 * R002035  qd  22sep98 Make sure reversal resonses go back to devices
 * R001835  qd  06may99 Interac Merge 
 * R002930	SG	30dec99	Interac requires 420 to be routed back to issuer rightaway
 * R004069	HJ	28Feb00	Move function shc_locate_original to shc_log.c
 * R004340	zt	17Apr00	Restore merchant_type for reversal request
 * 2009158  Rpc 01Apr00 VSDC assign chip_type for Full/Early Issuer.
 * 2007336  Ssc 02Jun00 Added emvbuf pointer to chip_type.
 * R004671(SPR2007336) Ssc 27Jun00 VSDC enhancement 
 * R004938 jsun 24Jul00 Replace origdate/time with trandate/time for Interac
 * R005208	jy	16Oct00 Change reversal condition.
 * R005129 jsun 30Oct00 For Interac bm90
 * R006640	jy	06Sep01	Keep certain respcode for reversal message
 * R007062	gbeeng	26Nov2001	C++ Migration
 *R007230 jyang 07Jan02 Restore field fee from original message
 *R007209 jyang	09Jan02	Update ch_new_amount and new_setl_fee for original message
 *R007335 ztang 16Jan02 Removing additional spaces in track2 when it's restored from original
 *R007504 jyang 15Feb02 Searching & Removing the original message event
 *R007349 emj   01May02 For interac saf 422 
 *R007781 ztang 02May02 Conditionally restore the filler fields
 *R007984 jyang 25Jun02 Restore original segment data from shclog_add table
 *R008041 jyang 12Jul02 Use the new macro has_shclog_add()
 *R008058 Emj   17Jul02 If original Txn was SAFed then SAF reversal
 *R008224 ztang 09Sep02 Make restoring original information an indepent function
 *R008353 Emj	28Oct02 If original Txn was SAFed by PosAuth then send reversal to PosAuth
 *R009706 ztang 07May03 Deal with repeat reversal
 *R010133 jyang 19Sep03 Routing IBFT message to correct host
 */
