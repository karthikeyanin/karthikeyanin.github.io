static char _ShcIstAuthFileUpdateResp_cxx_what[] = "@(#) ShcIstAuthFileUpdateResp.cxx 1.22 14/05/22 02:50:23";

/*
 *  Copyright (C) 2004 eFunds Corporation ("eFunds").  All Rights Reserved.     
 *  eFunds Canada Corporation is an authorized user.                            
 *                                                                              
 *  IST is a registered trademark of eFunds Corporation.  Other brand or        
 *  product names are trademarks or registered trademarks of their respective   
 *  holders.                                                                    
 *                                                                              
 *  The information contained herein is the unpublished proprietary property    
 *  of eFunds.  Except as specifically authorized in writing by eFunds, the     
 *  holder of this document shall: i) keep all information contained herein     
 *  confidential, and ii) protect the information, in whole or in part, from    
 *  disclosure and dissemination to all third parties.                          
 *                                                                          
 *  This document and the software described in it are furnished under license  
 *  and may be used or copied only in accordance with the terms of such license.
 *  This document is supplied for information purposes only, is subject to      
 *  change without notice, and should not be construed as a commitment by       
 *  either eFunds Corporation or eFunds Canada Corporation. 
 */
/*
 *
 *                        MODIFICATION HISTORY                  REVIEW
 *
 *	SPR#	Who	Date	Description			Who	Date   
 * ===========================================================================
 *      sreeram 16Mar20 File update support in istauth
 */

#include <ShcIstAuthFileUpdateResp.h>
#include <ShcApp.h>
#include <TxnStat.h>
#include <ShcmsgHelper.h>
#include <ShcTimerHelper.h>
#include <mb_umi.h>

int ShcIstAuthFileUpdateResp::enrich()
{
	return 0;
}


int ShcIstAuthFileUpdateResp::restore()
{
	int		save_msgno;	
	
    if(	header->msg.msgtype != SHC_ISTAUTH_FILE_UPD_REQ_REPEAT_RESP ){
		save_msgno = header->msg.msgtype;
		if(thisShcApp->shcTimerObj->shc_locate_event(header) < 0)
		{
			OTraceWarning("W-SHC-109001: No match for transaction: %d trace %d, Ignored\n", 
				header->msg.msgtype, header->msg.trace);
			header->setSkipFlag(TXN_PROC_SKIP_EDIT|TXN_PROC_SKIP_VERIFY|TXN_PROC_SKIP_DOWORK);
			header->logFlag |= SHC_LOG_LATE_RESP;
			char tmpLogId[sizeof(header->msg.shclog_id)];
			strcpy(tmpLogId, header->msg.shclog_id);
			mb_getUmi(header->msg.shclog_id, sizeof(header->msg.shclog_id));
			OTraceLog("L-SHC-109002: Replace ID [%s] with ID [%s]\n", tmpLogId, header->msg.shclog_id);
			TxnStatEquate(tmpLogId, header->msg.shclog_id);
			header->shcerr = SH_IGNORE;
			return ( -1 );
		}
		else
		{
			tm_dequeue(header->eventId);
			header->msg.senderid = header->reqMsg->senderid;
			if( ! (header->msg.device_cap & SH_DEVCAP_KEEP_FORMATTER_USE) )
				memcpy( header->msg.formatter_use, header->reqMsg->formatter_use
					, sizeof( header->msg.formatter_use) );	
		}
		
		header->msg.msgtype = save_msgno;
	}

	return 0;
}


int ShcIstAuthFileUpdateResp::doWork()
{
	int		save_respcode;
    //thisShcApp->shcmsgHelperObj->shc_set_return_msgno(&header->msg);
	header->logFlag = SHC_LOG_UPD_REQ;
	header->shcerr = SH_RETURN;
	return(0);
}
