/*
 *  Copyright (C) 2004 eFunds Corporation ("eFunds").  All Rights Reserved.     
 *  eFunds Canada Corporation is an authorized user.                            
 *                                                                              
 *  IST is a registered trademark of eFunds Corporation.  Other brand or        
 *  product names are trademarks or registered trademarks of their respective   
 *  holders.                                                                    
 *                                                                              
 *  The information contained herein is the unpublished proprietary property    
 *  of eFunds.  Except as specifically authorized in writing by eFunds, the     
 *  holder of this document shall: i) keep all information contained herein     
 *  confidential, and ii) protect the information, in whole or in part, from    
 *  disclosure and dissemination to all third parties.                          
 *                                                                          
 *  This document and the software described in it are furnished under license  
 *  and may be used or copied only in accordance with the terms of such license.
 *  This document is supplied for information purposes only, is subject to      
 *  change without notice, and should not be construed as a commitment by       
 *  either eFunds Corporation or eFunds Canada Corporation. 
 */
/*
#pragma ident "@(#) @(#) ShcSaf.cxx 1.26.4.3 20/07/08 00:37:22"
 *
 *                        MODIFICATION HISTORY                  REVIEW
 *
 *	SPR#	Who	Date	Description			Who	Date   
 * ===========================================================================
 * 10001959 la	10may96 Added function to SAF with a specific route.
 * 10002361 la  01jul96 Save and restore message type.
 * XXXXXXXX la  05jul96 Prevent saf messages from being saf'ed again.
 * XXXXXXXX la  07jul96 Determine whether to send SAF now or later based on
 * 10002358 la  24jul96 Test if response is < 0 instead of = -1
 * 10002676 jsg 961108  Check for IBFT on advice coerce 
 *                       the current bin status.
 *	ss		27Mar92		In locate_transaction route: 1) need to seek
 *						to start of file. 2) Don't need to call shc_makekey.
 *						3) Check Msgtype, 4) Correct a bug in stricmp
 *	
 *	aes		22Jul93		The amounts in the SAF file will be
 *						stored in the switch's currency.
 *	jt		22feb96		No longer write to saf file but msg is sent to istadvice
 *						instead, then let istadvice/istreplay handle or saf msg.
 *	wc		16dec97		Added more message types in shc_saf_determine_file
 *						(ACXSYS)
 *	R000818 wc	980224	Added header time.h.
 *  R000973 et  02may98 Changed stricmp to ICBin_cmp
 *  R001041 et  01jun98 Changed logic for safcutoffdate and cap_date   
 *  2005371 qd  31jul98 Reset SH_DEVCAP_FROM_NETWORK flag before store msg   
 *  R001794 qd  03feb99 Update saf status if posauth did not appove the transaction
 *  R001835 qd  18may99 Interac Merge
 * R003368	jsun	23Nov99	Fix core dump caused by ODebug
 *	R003631	HJ	02Dec99	Delete unnessary code which can create error message
 *	R004439	HJ	19Apr00	Fix bug in shc_saf_open_file
 *	R003895	rlo	20Apr00	Match the internal reversal flag when saf.
 *  R004761 fg  14Jun00 Change debug info    
 * R004938 jsun 21Jul00 Assign origdate/time with trandate/time for Interac
 * R005129 jsun 30Oct00 Undo the change of R004938 for Interac bm90
 * R005896 jy	07May01	Added a funtcion to convert response msg to advice msg 
 *						for SAF and changed function shc_saf_writefile()
 * R006621	hsh	05Sep01	Verify if the msg has a segment. If so, the size of the
 *						segment has to be included in the mb_write
 *R007617 jyang 19Mar02 Support to SAF approved advice message 
 *R008779 jyang 02Jan03 Multi-institution support
 *R011629 Emj   12Aug04 SAF Interleave merged R011312
 *R014598 jyang 31Aug05 leave flag SH_REPLAY alone
 *R016006 spa	27Mar06	Don't generate authnum for any advice message
 *R016540 Emj 12Jun06 Call emv_chip_cond_chk in emv_lib directly
 *R021024 bby 27Aug07 PAN/CVV/CVV2/Track2 Masking 
 *R021825 sks 24Oct07 Some changes in shc_saf function for ITMX 
 *R021843 bby   01Nov07 clone from R019906 and R021767 
 *R023310 Ram   27May08 SDK header should refer external header 
 *R025674 Sel	19Jan09	Fix SPR 2023996; SHC is clearing the PIN before sending  to istauth
 *R027876 dipa  02Mar10 Segment changes
 
 */

//File Number 120

#if defined( WIN32 )
#       define SHCDLLEXPORT __declspec(dllexport)
#else
#       define SHCDLLEXPORT
#endif


#include <stdio.h>
/* ACXSYS: wc R000818 */
#include <time.h>
#include <string.h>
#include <oasis.h>
#include <oasisenv.h>
#include <ist_otrace.h>
#include <fcntl.h>
#include <unistd.h>
#include <ShcMsgCache.h>
#include <shc.h>
#include <dirent.h> /* R001794 */
#include <ic/ic_bin.h>
#include <emvchipcond.h>

#include <ShcHelper.h>	//	---	R023310
#include <ShcmsgHelper.h>
#include <ShcSaf.h>
#include <ShcTimerHelper.h>
#include <ShcRevReqHelper.h>
#include <ShcCamHelper.h>
#include <ShcApp.h>
#include <ShcBin.h>
#include <ShcmsgTxnHelper.h>
#include <ShcSafIOHelper.h>
#include <shc_callback.h>
#include <shc_util_funcs.h>
#include <ShcFinAuthHelper.h>
#include <ShcNegativeAuth.h>
#include <MRApplHelper.h>
#include <MRShcNegAuthTagDefs.h>


/*
 *	File I/O routines for SAF module
 */

extern int errno;



/*********************************************
 * From old SHC shc_saf.cxx file
 *********************************************/

/*
 *	Store and forward module
 */

int ShcSaf::shc_general_saf_write(ShcBin *shcBin, ShcmsgHeader *header, int checkDuplicate)
{
	int callbackRet = shc_callback(header, "pre_saf_write");
	switch(callbackRet)
	{
	case SHCCALLBACKOVERRIDE:
		OTraceInfo("I-SHC-120001: Skipped standard saf_write as pre_saf_write callback function asked\n");
		return(0);
	default:
		if (checkDuplicate)
			thisShcApp->shcSafIOHelperObj->shc_saf_checkduplicate_write(header, shcBin);
		else if (shcBin)
			thisShcApp->shcSafIOHelperObj->shc_saf_writefile(shcBin, header);
		else
			thisShcApp->shcSafIOHelperObj->shc_saf_write_transaction(header);
	}
	
	return 0;
}

int ShcSaf::shc_saf(ShcmsgHeader *header, char safType)
{
	/*
	 *	Given a transaction determine the type of SAF processing and
	 *	then perform this processing
	 *
	 *	NOTE:	It is assumed that S&F is allowed
	 */
	
	ShcBin *shcBin;
	char	cvvResultCode;

	/*
	 *	Determine which bin to use
	 */
	shcBin = thisShcApp->shcSafIOHelperObj->shc_saf_determine_file(header);
//	shcBin->binPkg->bin.flags |= SH_REPLAY;    // -- R011312 --
	
	/*
	 *	o	Determine what to do
	 */
	/*SG R003443 no point is setting the saf flag to pending if there is
		no configuration for the saf file*/
	/* R005208 	if(!(shcBin->binPkg->saf.type & SH_SAF_NOFILE)) */
		header->msg.saf = SH_SAF_PENDING;

	switch(header->msg.msgtype){
	case	SHC_FINREQ:
	case	SHC_FINREQ_REPEAT:
	case	SHC_AUTHREQ:
	case	SHC_AUTHREQ_REPEAT:
	case	SHC_AUTHREQ_ADVICE:
	case	SHC_FINREQ_ADVICE:
	case	SHC_FILEUPD_ISSREQ:
	case	SHC_LOCAL_FILEUPD_ISSREQ:
		
		/*	R025674
		if(!shcApp->issuerShcParamsList->GetBool((char *)"shc.keep_pin"))
			memset(header->msg.pin, 0, sizeof(header->msg.pin));
		*/

		/*
		 * R001835 Special processing for Interac 120/220
		 */
		//	>>>	R021843
	    if(shcIsAdvice(header) && (shcBin->isInterac())) //	---	R022278	
		{
			//	>>>	R025674
			if(!shcApp->issuerShcParamsList->GetBool((char *)"shc.keep_pin"))
				memset(header->msg.pin, 0, sizeof(header->msg.pin));
			//	<<<	R025674
			shc_general_saf_write(shcBin, header, 1);
			header->shcerr = SH_RETURN | SH_CONTINUE;
		}
		//	<<<	R021843

		
		
		
		else 
		{
			/* R005887 >> */
//			cvvResultCode = thisShcApp->shcmsgHelperObj->shc_getCvvResultCode(header);
//			if( cvvResultCode == 'N' || cvvResultCode == 'M' )
//			{
//				thisShcApp->shcmsgHelperObj->shc_setCvvResultCode(header, 'P' );
//				OTraceInfo("I-SHC-120002:CVV/CVV2: ResultCode:[%c]->[P] in STIP.\n", cvvResultCode);
//			}
			/* R005887 << */
			
			if(	(safType == 'P') ||
				((shcBin->binPkg->saf.type & SH_SAF_POSFILE) && (safType == '\0'))
			  )
			{
				thisShcApp->shcmsgTxnHelperObj->shc_posauth(header, 1);
			}
			else
			{
				shc_saf_fin(header);
				header->shcerr = SH_RETURN | SH_CONTINUE;
			}
		}

		/*	now it's safe to zero the PIN */
		//	>>>	R021825
		//if(shcApp->issuerShcParamsList->GetBool((char *)"shc.keep_pin"))
		//	memset(header->msg.pin, 0, sizeof(header->msg.pin));
		if(!shcApp->issuerShcParamsList->GetBool((char *)"shc.keep_pin"))
			memset(header->msg.pin, 0, sizeof(header->msg.pin));
		//	<<<	R021825

		break;
	

	case	SHC_REVREQ:
	case	SHC_REVREQ_REPEAT:

	case	SHC_REVREQ_ADVICE:
		/* 29Mar95 */
 		/*if( (header->msg.respcode == SHC_RC_NoOriginal) &&*//* R001835 */
        if( (header->msg.respcode == SHC_RC_NoOriginal) && 
			shcApp->acquirerShcParamsList->GetBool((char *)"shc.sendIss_420NoOrig") &&  /* R001835 */
            (header->msg.device_cap & SH_DEVCAP_REV_REQUIREORIG))
        {/* R001835 */
            thisShcApp->shcRevReqHelperObj->shc_return_reversal(header);
			
            thisShcApp->shcmsgHelperObj->shc_route(header);
//            if( thisShcApp->shcmsgTxnHelperObj->enqueueInternalMsg(header) == NULL )
//            	OTraceError("E-SHC-120003: Unable to enqueueInternalMsg() in ShcSaf::shc_saf()\n");
				
            header->shcerr = SH_IGNORE;
        }/* R001835 */
		else
		{

			if(shcBin->binPkg->saf.type & SH_SAF_POSFILE)
			{
				// -R011312- 30Jun04  adding shc_isreplay
				if(shc_isdown(header->issShcBin->binPkg)|| (shcApp->saf_interleave&&shcIsReplay(header->issShcBin->binPkg,header->msg.iss_entityId)))                  /* R000591 */
					thisShcApp->shcmsgTxnHelperObj->shc_posauth(header, 1);			/* 10002113 */
				else if (gOmsgIsSaf)
					//Original message is safed, so this message should also go saf to guarentee correct sequence
					thisShcApp->shcmsgTxnHelperObj->shc_posauth(header, 1); 
			}
			else if(!(shcBin->binPkg->saf.type & SH_SAF_NOFILE))				/* 10002243 */
				shc_general_saf_write(shcBin, header, 1);		/* 10002243 */
		}
		break;

	case	SHC_STLMTREQ:
		if(shcBin->binPkg->saf.type & SH_SAF_POSFILE)
		{
			header->shcerr = SH_IGNORE;
			thisShcApp->shcmsgTxnHelperObj->shc_posauth(header, 1);
		}
		else
			shc_saf_stlmt(header);
		
		shc_general_saf_write(shcBin, header, 0);
		break;
	
	case	SHC_PREAUTH_RESP:
		/*	we simply write the transaction to the file. */
		header->msg.msgtype = header->msg.origmsg;
		shc_general_saf_write(shcBin, header, 0);
		break;

	/* wc	16dec97		R000586 ACXSYS--> start */

	case	SHC_CHARGE_BACK_ADVICE:
		shc_general_saf_write(shcBin, header, 0);
		break;

	case	SHC_ADMIN:
	case	SHC_ISS_ADMIN:
	case	SHC_ADMIN_ADVICE:
	case	SHC_ISS_ADMIN_ADVICE:
		shc_general_saf_write(shcBin, header, 0);
		break;

	/* wc	16dec97		R000586 ACXSYS--> end */
	default:
		break;
	}

	thisShcApp->shcSafIOHelperObj->shc_saf_close_file(shcBin);

	return(0);
}



int ShcSaf::shc_saf_fin(ShcmsgHeader *header)
{
	/*
	 *	Authorize a financial transaction in store and forward
	 */
	int		do_saf_update = 0;
	int ret = 0;
	int mrret;
	
	header->msg.shc_devcap |= SH_DEVCAP_SHC_STDIN;	/* R005896 */
	struct NegAuth negauth; 

	MRApplHelper *mrHelper =  MRApplHelper::getInstance(IST_MR_SERVICE_NAME_NEGAUTH);
	mrHelper->reset();

	int callbackRet = shc_callback(header, "negative_auth");
	switch(callbackRet)
	{
	case SHCCALLBACKOVERRIDE:
		OTraceInfo("I-SHC-120004:SAF: Performed Custom Negative Auth\n");
		return (0);
	case SHCCALLBACKDENY:
		if ( 	(header->msg.respcode == SHC_RC_Approved) ||
				(header->msg.respcode == SHC_RC_PartialDispense) )
			header->msg.respcode = SHC_RC_DoNotHonor;
		OTraceInfo("I-SHC-120005:SAF: Denied asked by negative_auth callback\n");
		return(0);
	default:
		break;
	}
	if ( thisShcApp->shcmsgHelperObj->performStandInOnlyChecks(header) < 0 )
	{
		OTraceError( "E-SHC-120012 negative auth: checks configured to be stand in only failed\n" );
		return( 0 );
	}

	/* R006940 */
	thisShcApp->shcCamHelperObj->shc_cam_stip_request_start (header);

	/* R001952  BEGIN
	 * Deny Authentication Request temporaryly
	 */
	if ( (shcIsAuthorizationRequest(header) ) &&
		 ( shcGetProcessCode(header->msg.pcode) == SH_ISO_SERVICE_REQUEST ) &&
		 (header->msg.txntype == SH_TX_AUTHENTICATE ) )
	{
		OTraceInfo("I-SHC-120006: shc_saf():Declining Authenticate Request.\n");
		header->msg.respcode = SHC_RC_UnableToProcess;
		return(0);
	}
	/* R001952  END */
	
									//R007502 BEGIN
	if ( shcIsAccountFunding(header->msg.pcode) )
	{
		OTraceInfo("I-SHC-120007: shc_saf(): Declining Account Funding Request.\n");
		header->msg.respcode = SHC_RC_UnableToProcess;
		return(0);
	}
	
	if ( (header->msg.pcode/10000) == SH_ISO_RECEIVE_PAYMENT )
	{
		OTraceInfo("I-SHC-120026: shc_saf(): Declining Receive Payment Request.\n");
		header->msg.respcode = SHC_RC_UnableToProcess;
		return(0);
	}

	
	if ((header->msg.shc_devcap & SH_DEVCAP_SHC_VOID) && !shcIsAdvice(header))
	{
		OTraceInfo("I-SHC-120008: Declining Void transaction when Negative auth.\n");
		header->msg.respcode = SHC_RC_UnableToProcess;
		return(0);
	}
	
									//R007502 END
	/*	We don't have an available balance */
	dbm_dbltodec(&header->msg.aval_balance, (double)0);
	header->msg.shcerror = SHC_IE_NoBalance;

	/* 10002457 */
	if( shcGetISOClass(header->msg.pcode) == SH_ISO_BALANCE_CLASS )
	{
		header->msg.respcode = SHC_RC_UnableToProcess;
		return( 0 );
	}

	// Adding Fallback Transaction for Chip Conditional Check
	if ( (shcmsgHeaderIsChipTxn(header) || (header->msg.shc_devcap & SH_DEVCAP_SHC_ICCFALLBACK)) &&
	     (header->msg.msgtype ==  SHC_FINREQ || header->msg.msgtype ==  SHC_AUTHREQ))
	{
		OTraceInfo("I-SHC-120009: shc_saf_fin(): Perform Chip Cond Check\n");
		ret = emv_chip_cond_chk(header, EMV_CHK_NEGATIVE);

		if ( ret == -1)
		{
			OTraceInfo("I-SHC-120010: shc_saf_fin(): Perform Chip Cond Check Failed\n");
			header->msg.respcode = SHC_RC_UnableToProcess;
			return( 0 );
		}
		else if (ret > 0)
		{
			OTraceInfo("I-SHC-120011: shc_saf_fin(): Perform Chip Cond Check Declined Txn [%d]\n",ret);
			header->msg.respcode = ret;
			return( 0 );
		}
	}


	/* R006940 */
	if (thisShcApp->shcCamHelperObj->shc_cam_request_result(header) <= 0)
	{
		header->msg.respcode = SHC_RC_UnableToProcess;
		return( 0 );
	}

	/*
	 *	o	Get an authorization number
	 */

    /* R007494 don't generate auth number if is advice preauth  completion message */
	//	---	R016006; Don't generate authnum for any advice message
	if (!(shcIsAllAdvice(header))) 
	{
		thisShcApp->shcmsgHelperObj->shc_generate_auth_number(header); //R027876
	}

	/*
	 *	o	Determine type of transaction
	 */
	do_saf_update = (header->msg.txntype == SH_TX_WD) || 
				( (header->issShcBin->binPkg->bin.flags & SH_SAFAUTH) && /* 23oct92 */
				  (header->msg.pcode / 100000 == SH_ISO_WITHDRAW_CLASS
				   || header->msg.pcode / 100000 == SH_ISO_WITHDRAW_CLASS2)
				);

	if ((!do_saf_update) && (header->msg.msgtype != SHC_FILEUPD_ISSREQ))
	{
		header->msg.respcode = 0;

		/*	Write to stfwd file */
		/* R005896 >> Don't SAF for request message - Commented 
		shc_general_saf_write(header->issShcBin, header, 0);
		 * R005896 << */

		return(0);
	}

    //	>>>	R022278

	if(shcIsAdvice(header) && (!(header->issShcBin->binPkg->saf.type&SH_SAF_NOFILE)))

	{
	shc_general_saf_write(header->issShcBin, header, 1);
	header->shcerr = SH_RETURN | SH_CONTINUE;
	return (0);
	}


	//	<<<	R022278

	/*	16nov92	ad
	*	If Issuer down, check if txn amount over max txn amount per
	*		transaction while in SAF mode.
	*	26Nov92 ss
	*		Skip Check if Advice message.	
	*/

	if(dbm_deccmp(&header->msg.amount,
		&header->issShcBin->binPkg->auth.floor_3) > 0 && !shcIsAdvice(header))
	{
		OTraceError("E-SHC-120012: shc_saf():Denied:SAF Transaction Limits exceeded.\n");
		header->msg.respcode = SHC_RC_ExceedsLimit;
		return(0);
	}


	if(ShcNegativeAuth::getInstance()->checkLimit(header,&negauth)<0)
	{
		if(shcIsAdvice(header))         /* 26Nov92. Sunny */
		{
			header->msg.respcode = SHC_RC_Approved;
			shc_general_saf_write(header->issShcBin, header, 0);
			return(0);
		}

		header->msg.respcode = SHC_RC_SystemError;

		return(-1);
	}

	if(header->msg.respcode == SHC_RC_Approved)
	{
		if(((header->msg.msgtype == SHC_AUTHREQ) || 
			(header->msg.msgtype == SHC_AUTHREQ_REPEAT) ||
			(header->msg.msgtype == SHC_AUTHREQ_ADVICE)) &&
		   !(header->issShcBin->binPkg->bin.flags & SH_SAFAUTH))
		{
			OTraceInfo("I-SHC-120016: Ignore accumlating 01xx SAF amount\n");
		}
		else
		{
			OTraceInfo("I-SHC-120017: Update SAF amount and SAF number\n");
			negauth.saf_num++;
			dbm_decadd(&negauth.saf_amount,
			&header->msg.amount, &negauth.saf_amount);
			int revflag = 0;
			mrHelper->setData(TAG_REVERSAL, revflag);		

			mrret = ShcNegativeAuth::getInstance()->updateLimit(header,&negauth);
			if( mrret == 1 )
			{
				OCString replService;
				OCString replData;
				mrHelper->getServiceName(replService);
				int val = mrHelper->flattenData(replData);
				if ( val != -1 )
					header->appendReplicationData(replService.data(), replData.data(), replData.length() );
			}
			else
				mrHelper->reset();
		}


		/*	Write to stfwd file */
		/* R005896 - Don't SAF for request message - Commented --> 
		shc_general_saf_write(header->issShcBin, header, 0);
		 * <-- R005896 */
	}


	/* 29apr93 */
	if(header->msg.respcode != SHC_RC_Approved)
		header->msg.authnum[0] = '\0';
	return(0);	
}

/*
 * R000601 qd 18feb98 Change the logic for limits reset
 */
int ShcSaf::shc_saf_resetlimits(ShcmsgHeader *header)
{
	ShcNegativeAuth::getInstance()->resetLimit(header);
	return(0);
}


int ShcSaf::shc_saf_rev(ShcmsgHeader *header)
{
	/*
	 *	Reverse a previous stfwd transacion
	 *
	 *	NOTE This is not the same as processing a STFWD reversal request
	 */
	

	/*
	 *	o	Determine type of transaction
	 */
	
	int ret;
	MRApplHelper *mrHelper =  MRApplHelper::getInstance(IST_MR_SERVICE_NAME_NEGAUTH);
	mrHelper->reset();
	if(header->msg.txntype != SH_TX_WD)
	{
		header->msg.respcode = 0;
		return(0);
	}

	ret =  ShcNegativeAuth::getInstance()->reverseLimit(header);

	if ( ret == 0 )
	{

		OCString replService;
		OCString replData;
		mrHelper->getServiceName(replService);
		int val = mrHelper->flattenData(replData);
		if ( val != -1 )
			header->appendReplicationData(replService.data(), replData.data(), replData.length() );
	}
	else
		mrHelper->reset();

	return(0);
}


int ShcSaf::shc_saf_stlmt(ShcmsgHeader *header)
{
	/*
	 *	Process a stfwd 500 Message
	 */

	header->msg.msgtype = SHC_STLMTREQ_RESPONSE;
	thisShcApp->shcTimerObj->shc_time_message(header);
//////////	shc_stlmtresp(header);
    if( thisShcApp->shcmsgTxnHelperObj->enqueueInternalMsg(header) == NULL )
    	OTraceError("E-SHC-120024: Unable to enqueueInternalMsg() in ShcSaf::shc_saf()\n");

	header->msg.msgtype = SHC_STLMTREQ;
	return(0);
}



