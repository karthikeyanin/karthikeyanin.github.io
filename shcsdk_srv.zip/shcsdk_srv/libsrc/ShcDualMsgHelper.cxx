
static char _ShcDualMsgHelper_cxx_what[] = "@(#) ShcDualMsgHelper.cxx 1.2 10/02/25 16:00:29";

/*
 *  Copyright (C) 2004 eFunds Corporation ("eFunds").  All Rights Reserved.     
 *  eFunds Canada Corporation is an authorized user.                            
 *                                                                              
 *  IST is a registered trademark of eFunds Corporation.  Other brand or        
 *  product names are trademarks or registered trademarks of their respective   
 *  holders.                                                                    
 *                                                                              
 *  The information contained herein is the unpublished proprietary property    
 *  of eFunds.  Except as specifically authorized in writing by eFunds, the     
 *  holder of this document shall: i) keep all information contained herein     
 *  confidential, and ii) protect the information, in whole or in part, from    
 *  disclosure and dissemination to all third parties.                          
 *                                                                          
 *  This document and the software described in it are furnished under license  
 *  and may be used or copied only in accordance with the terms of such license.
 *  This document is supplied for information purposes only, is subject to      
 *  change without notice, and should not be construed as a commitment by       
 *  either eFunds Corporation or eFunds Canada Corporation. 
 *
 *
 *
 *                        MODIFICATION HISTORY                  REVIEW
 *
 *	SPR#	Who	Date	Description			Who	Date   
 * ===========================================================================
 * R020524 jyang 04Jul07 Created for dual-message transaction support
 */

/* File Number 160 */


#include <stdio.h>
#include <oasis.h>
#include <mb.h>
#include <tm.h>
#include <ist_otrace.h>
#include <shc.h>
#include <shcerror.h>
#include <ShcApp.h>
#include <ShcmsgHelper.h>
#include <ShcDualMsgHelper.h>


ShcDualMsgHelper::ShcDualMsgHelper()
{
	memset((char*)&shcmsgWithSegment, 0, sizeof(shcmsgWithSegment));
	setInterMsgTimer( 60 );	// 60 seconds as default
};

long ShcDualMsgHelper::makeDualMsgEventKey(ShcmsgHeader *header)
{
	long eventKey = -1 ;
	if ( header )
	{
		eventKey = atoi( header->msg.refnum );
		if ( eventKey <=0 )
		{
			eventKey = header->msg.trace;
		}
		
		eventKey += (eventKey < 1000000L ? 1000000L : 10000000L) * 7L; // because msgtype 7xx not used yet
	}
	else{
		OTraceError("E-SHC-16001: Unable to create dualmsg event key\n");
	}
	
	return eventKey;
}


int ShcDualMsgHelper::createInterMsgEvent(ShcmsgHeader *header)
{
	long eventKey = makeDualMsgEventKey( header );
	if ( eventKey < 0 )
	{
		return eventKey;
	}
	
	int eventId = tm_enqueue(shcmid, shc_current_time+getInterMsgTimer(), TM_NOTIFY_ONCE, 
			eventKey, (char *)(&header->msg),
			header->truelength() );
	
	if ( eventId < 0 )
	{
		OTraceError("E-SHC-16002: Unable to create InterMsg event[%ld]\n", eventKey);
	}
	else
	{
		OTraceDebug("D-SHC-16003: InterMsg event created, key[%ld] Id[%d]\n", eventKey, eventId);
	}
	
	return eventId;
}


int ShcDualMsgHelper::procTimeoutInterMsgEvent(ShcmsgHeader *header)
{
	OTraceInfo("I-SHC-16004: nothing in ShcDualMsgHelper::procTimeoutInterMsgEvent()\n");
	return 0;
}


int ShcDualMsgHelper::retrieveFirstMsgResp(ShcmsgHeader *header, struct ShcmsgWithSegment *oShcmsgSeg)
{
	if ( header==NULL )
	{
		OTraceError("E-SHC-16005: retrieveFirstMsgResp()::ShcmsgHeader is empty\n");
		return (-1);
	}
	
	if ( locateInterMsgEvent(header, oShcmsgSeg, 1) < 0 )
	{
		if ( searchFirstMsgInDb( header, oShcmsgSeg ) < 0 )
		{
			OTraceDebug("D-SHC-16006: the 1st resp of dual msg not found\n");
			return (-2);
		}
		else
		{
			OTraceDebug("D-SHC-16007: found 1st resp of dual msg from the DB\n");
		}
	}
	else
	{
		OTraceDebug("D-SHC-16008: found InterMsg event, removed\n");
	}
	
	return 0;
}


int ShcDualMsgHelper::locateInterMsgEvent(ShcmsgHeader *header, struct ShcmsgWithSegment *oShcmsgSeg, int flagRemove)
{
	int  eventId = -1;
	long eventKey = makeDualMsgEventKey( header );
	
	memset( (char*)&shcmsgWithSegment, 0, sizeof(shcmsgWithSegment) );
	
	if ( eventKey < 0 )
	{
		OTraceError("E-SHC-16009: ignored locate inter-message event\n");
	}
	else
	{
		while ( (eventId=tm_locate_event(eventKey, eventId, shcmid, NULL))>=0 )
		{
			int retVal = tm_getdata( eventId, (char *)&shcmsgWithSegment, sizeof(shcmsgWithSegment) );
	        if( strcmp(shcmsgWithSegment.msg.pan, header->msg.pan) == 0 )
	        {
	        	OTraceDebug("D-SHC-16010: Found InterMsg event[%d], key[%ld]\n", eventId, eventKey);
	        	
				if ( flagRemove )
				{
					tm_dequeue( eventId );
				}
				
				if ( oShcmsgSeg )
				{
					memcpy( oShcmsgSeg, (char*)&shcmsgWithSegment, sizeof(struct ShcmsgWithSegment) );
				}
	        	break;
	        }
		};
	}
	
	if ( eventId < 0 )
	{
		OTraceDebug("D-SHC-16011: Unable to find InterMsg event, key[%ld]\n", eventKey);
	}
	
	return eventId;
}


int ShcDualMsgHelper::searchFirstMsgInDb( ShcmsgHeader *header, struct ShcmsgWithSegment *oShcmsgSeg )
{
	if (thisShcApp->shcmsgHelperObj->locateOrigTxn(header) < 0 )
	{
		OTraceDebug("D-SHC-16011: No original message found for dual 2nd msg,[m%04d/t%06ld]\n", header->msg.msgtype,header->msg.trace);
		return (-1);
	}
	
	if ( oShcmsgSeg )
	{
		memcpy( oShcmsgSeg, header->origMsg, sizeof(struct ShcmsgWithSegment) );
	}
	
	return 0;
}

