static char _ShcAdminTxnFactory_cxx_what[] = "@(#) ShcAdminTxnFactory.cxx 1.6 05/06/01 15:08:34";

/*
 *  Copyright (C) 2004 eFunds Corporation ("eFunds").  All Rights Reserved.     
 *  eFunds Canada Corporation is an authorized user.                            
 *                                                                              
 *  IST is a registered trademark of eFunds Corporation.  Other brand or        
 *  product names are trademarks or registered trademarks of their respective   
 *  holders.                                                                    
 *                                                                              
 *  The information contained herein is the unpublished proprietary property    
 *  of eFunds.  Except as specifically authorized in writing by eFunds, the     
 *  holder of this document shall: i) keep all information contained herein     
 *  confidential, and ii) protect the information, in whole or in part, from    
 *  disclosure and dissemination to all third parties.                          
 *                                                                          
 *  This document and the software described in it are furnished under license  
 *  and may be used or copied only in accordance with the terms of such license.
 *  This document is supplied for information purposes only, is subject to      
 *  change without notice, and should not be construed as a commitment by       
 *  either eFunds Corporation or eFunds Canada Corporation. 
 *
 *
 *                        MODIFICATION HISTORY                  REVIEW
 *
 * SCR#     Who    Date  Description
 * ===========================================================================
 * R0xxxxx 
 */

//File Number 58

//#include <shc.h>
//#include <shcdef.h>
//#include <shcextbuf.h>
//
#include <ShcSdkCommon.h>
#include <ShcmsgHeader.h>
#include <ShcmsgBaseTxn.h>
#include <ShcRetShcmsg.h>
#include <ShcAdminReq.h>
#include <ShcAdminResp.h>
#include <ShcAdminEvent.h>
#include <ShcAdminTxnFactory.h>
//#include <ShcAppBase.h>

int
ShcAdminTxnFactory::createCondition(char *condition, const void *header)
{
	ShcmsgHeader *thisHeader = (ShcmsgHeader *)header;
	
	sprintf(condition, "%4.4d", 
			thisHeader->msg.msgtype
			);
	return 0;
}

ShcmsgBaseTxn *ShcAdminTxnFactory::getTargetObj(char *condition, const void *headerBuf)
{
	
		ShcmsgHeader *thisHeader = (ShcmsgHeader *)headerBuf;
		
		if (!thisHeader->issBinValid() || !thisHeader->acqBinValid())
		{
			return new ShcRetShcmsg(thisHeader);
		}
		
		switch(thisHeader->msg.msgtype)
		{
		case	SHC_ADMIN:
		case	SHC_ADMIN_ADVICE:
		case	SHC_ISS_ADMIN:
		case	SHC_ISS_ADMIN_ADVICE:
			return new ShcAdminReq(thisHeader);
			break;
		case	SHC_ADMIN_RESPONSE:
		case	SHC_ADMIN_ADVICE_RESPONSE:
		case	SHC_ISS_ADMIN_RESPONSE:
		case	SHC_ISS_ADMIN_ADVICE_RESPONSE:
			return new ShcAdminResp(thisHeader);
		case	SHC_EVENT + SHC_ADMIN:
		case	SHC_EVENT + SHC_ADMIN_ADVICE:
		case	SHC_EVENT + SHC_ISS_ADMIN:
		case	SHC_EVENT + SHC_ISS_ADMIN_ADVICE:
			return new ShcAdminEvent(thisHeader);
			break;
		default:		return NULL;
		}
}


