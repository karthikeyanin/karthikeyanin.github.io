/*
 *  Copyright (C) 2004 eFunds Corporation ("eFunds").  All Rights Reserved.
 *  eFunds Canada Corporation is an authorized user.
 *
 *  IST is a registered trademark of eFunds Corporation.  Other brand or
 *  product names are trademarks or registered trademarks of their respective
 *  holders.
 *
 *  The information contained herein is the unpublished proprietary property
 *  of eFunds.  Except as specifically authorized in writing by eFunds, the
 *  holder of this document shall: i) keep all information contained herein
 *  confidential, and ii) protect the information, in whole or in part, from
 *  disclosure and dissemination to all third parties.
 *
 *  This document and the software described in it are furnished under license
 *  and may be used or copied only in accordance with the terms of such license.
 *  This document is supplied for information purposes only, is subject to
 *  change without notice, and should not be construed as a commitment by
 *  either eFunds Corporation or eFunds Canada Corporation.
 *
 *
 *                        MODIFICATION HISTORY                  REVIEW
 *
 * SCR#     Who    Date  Description
 * ===========================================================================
 * R000000 ztang 25Jul17 New file created
 */

 /* File Number 178 */

static char _ShcODDecisionProcessor_cxx_what[] = "@(#) ShcODDecisionProcessor.cxx 1.4 17/09/21 13:23:02";

#include <mb_umi.h>
#include <ist_otrace.h>
#include <shc_callback.h>
#include <shc.h>
#include <shcdef.h>
#include <ShcmsgHelper.h>
#include <ShcTimerHelper.h>
#include <ShcmsgProcessor.h>
#include <ShcApp.h>
#include <ShcmsgTxnRegistration.h>
#include <ShcHelper.h>
#include <ShcmsgTxnHelper.h>
#include <ShcBin.h>
#include <CShcLog.h>
#include <ShcHeaderRegistration.h>
#include <ShcAppBase.h>
#include <ShcODDecisionProcessor.h>
#include <ShcmsgODHelper.h>
#include <ShcmsgHeader.h>
#include <ShcMsgCache.h>
#include <BinRoute.h>
#include <ist_seg_name.h> 
#include <ist_seg_elf_id_map.h> 
#include <ist_seg_id.h> 
#include <ist_seg_pdt_base.h> 
#include <algorithm>


int ShcODDecisionProcessor::process()
{

	int tmstpLen;	
	int flag = 0;

	ShcmsgODHeader *thisHeader = (ShcmsgODHeader *)header;

	struct ShcmsgWithSegment timerBuf;

	struct ShcmsgWithSegment shcmsgSeg = {0} ;
	struct shcmsg *oReqMsg = &(shcmsgSeg.msg);

	struct s_ODDecision *decision = thisHeader->getDecision();

	int eventRet = tm_locate_eventid(decision->eventId);
	if(eventRet>=0)
	{
		tm_getdata(decision->eventId, (char *)&shcmsgSeg, sizeof(shcmsgSeg));
		//if tm_dequeue fails, the event is dequeued by other process already, lost in racing
		//treat as late response
		eventRet = tm_dequeue(decision->eventId);
	}

    if(!shcmsgODHelperObj)
        shcmsgODHelperObj = (ShcmsgODHelper *)shcHelperRegister.getTargetObj(SHC_ShcmsgODHelper);
	if (!shcmsgODHelperObj)
	{
		OTraceError("E-SHC-178002:Can't create ShcmsgODHelper. drop OnDot Response.\n");
		return 0;
	}

	/* Late response Start*/
	if(eventRet < 0)
	{
		OTraceDebug("D-SHC-178004:Late response from OD. Log and Drop\n");
		shcmsgODHelperObj->processLateResponse(thisHeader);
		return 0;
	}

	/* Normal Response start */

	int totalLen=thisHeader->truelength(oReqMsg);
	memcpy(&thisHeader->msg, oReqMsg, min<long>(sizeof(thisHeader->msg), totalLen));
	if (totalLen > sizeof(struct shcmsg)) //segments present
		memcpy(&thisHeader->segment, ((char *)oReqMsg)+sizeof(struct shcmsg), sizeof(thisHeader->segment));


	if (thisHeader->msg.msgtype == SHC_OD_REQ)
	{
		//Online message
		OTraceDebug("D-SHC-178006:OD msgtype [%d] flipped back to original msgtype[%d]\n",
			thisHeader->msg.msgtype, thisHeader->msg.flipped_msgtype);
		thisHeader->msg.msgtype = thisHeader->msg.flipped_msgtype;
	}
	else if (!(thisHeader->msg.device_cap & SH_DEVCAP_FROM_REPLAY))
	{
		//Response of On Dot notification msg on first try, 
		//just drop it as On Dot response received
		OTraceError("E-SHC-178008:Response of first On Dot notification. we are done\n");
		return 0;
	}
	else
		//SAFed On Dot message final response, should send back to replay
		thisShcApp->shcmsgHelperObj->shc_set_return_msgno(&thisHeader->msg);
		
	if (!(thisHeader->msg.device_cap & SH_DEVCAP_FROM_REPLAY))
	{
		IstSegPdtBase *ODData = (IstSegPdtBase *)thisHeader->getSegmentObj(ON_DOT_id);
		if(!ODData) 
		{
			OTraceError("E-SHC-178008:ON_DOT segment not found. drop\n");
			return 0;
		}
	
		char buf[100];
		int l=sizeof(buf);
	
		if (ODData->getReqEventId(buf,&l) == IST_RET_OK)
		{
			if( tm_getdata(atoi(buf), (char *)&timerBuf, sizeof(timerBuf)) > 0)
			{
				thisHeader->allocateAndCopyReqMsg(&(timerBuf.msg));
				OTraceDebug("D-SHC-178010: reqmsg restored from FM event\n");
			}
			tm_dequeue(atoi(buf));
		}
	
		memset(buf, 0x00, sizeof(buf)); l=sizeof(buf);
	
		l=sizeof(buf);
		if (ODData->getOrigEventId(buf,&l) == IST_RET_OK)
		{
			if( tm_getdata(atoi(buf), (char *)&timerBuf, sizeof(timerBuf)) > 0)
			{
				thisHeader->allocateAndCopyOrigMsg(&(timerBuf.msg));
				OTraceDebug("D-SHC-178012: origmsg restored from FM event\n");
			}
			tm_dequeue(atoi(buf));
		}
	
		memset(buf, 0x00, sizeof(buf)); l=sizeof(buf);
		if (ODData->getFlippedMsgType(buf,&l) == IST_RET_OK)
			thisHeader->msg.flipped_msgtype = atoi(buf);
		
		memset(buf, 0x00, sizeof(buf)); l=sizeof(buf);
		if (ODData->getLogFlag(buf,&l) == IST_RET_OK)
			thisHeader->logFlag = atoi(buf);
	
		memset(buf, 0x00, sizeof(buf)); l=sizeof(buf);
		if (ODData->getRepeatFlag(buf,&l) == IST_RET_OK)
			thisHeader->repeatFlag = atoi(buf);
	
		memset(buf, 0x00, sizeof(buf)); l=sizeof(buf);
		if (ODData->getShcerr(buf,&l) == IST_RET_OK)
			thisHeader->shcerr = atoi(buf);
	
		memset(buf, 0x00, sizeof(buf)); l=sizeof(buf);
		if (ODData->getTxnIn_time(buf,&l) == IST_RET_OK)
			thisHeader->time_in = atol(buf);
	
		memset(buf, 0x00, sizeof(buf)); l=sizeof(buf);
		if (ODData->getTxnOut_time(buf,&l) == IST_RET_OK)
			thisHeader->time_out = atol(buf);
			//      <<<     R160740849
	
		struct RoutingInfo routingInfo = {0};
		int routingInfoLen=sizeof(struct RoutingInfo);
	
		if (ODData->getRoutingInfo((char*)&routingInfo, &routingInfoLen)==IST_RET_OK)
			thisHeader->setSegmentData((char*)&routingInfo, sizeof(routingInfo), NETWORK_DATA_REQ_id,ROUTING_INFO);
		else
		{
			//Clear the flag in ROUTINGINFO segment
			thisHeader->setSegmentData((char*)&routingInfo, sizeof(routingInfo), NETWORK_DATA_REQ_id, ROUTING_INFO);
		}	
	
	
		/* OD Denial case start*/
	
		OTraceInfo("I-SHC-178014:OD DE39[%s] Vector[%s]\n", decision->DE39, decision->OnDotVector);
		if((decision->DE39[0] != '0') || (atoi(decision->DE39)!=0))
		{
			thisHeader->msg.respcode = SHC_RC_ODDeclined;
			thisHeader->logFlag |= SHC_LOG_UPD_REQ;
			thisHeader->setSkipFlag(TXN_PROC_SKIP_DOWORK);
			thisHeader->shcerr = SH_RETURN;
			shcApp->shcmsgHelperObj->shc_set_return_msgno(&thisHeader->msg);
		}
	}
	else
	{
		//response of "On Dot final response", just return to replay
		thisHeader->msg.respcode = SHC_RC_Approved;
		thisHeader->logFlag |= SHC_LOG_REQ|SHC_LOG_UPD_REQ;
		thisHeader->setSkipFlag(TXN_PROC_SKIP_DOWORK);
		thisHeader->shcerr = SH_RETURN;
		shcApp->shcmsgHelperObj->shc_set_return_msgno(&thisHeader->msg);
	}

	thisHeader->setSegmentData(decision->OnDotVector, sizeof(decision->OnDotVector), ON_DOT_LOG_id, ON_DOT_VECTOR);
	thisHeader->setSegmentData(decision->DE39, sizeof(decision->DE39), ON_DOT_LOG_id, ONDOT_DE39);


	// clarify whether procFlag or skipFlag
	thisHeader->setSkipFlag(TXN_PROC_SKIP_ENRICH | TXN_PROC_SKIP_RESTORE | TXN_PROC_SKIP_EDIT | TXN_PROC_SKIP_VERIFY);

	shcmsgODHelperObj->enqueueInternalMsg(thisHeader);

	return(0);

}
//	<<<	R020938


ShcODDecisionProcessor::ShcODDecisionProcessor(char *msgbuf)
{
	header = shcHeaderRegister.getTargetObj(msgbuf);

	if (!header)
	{
		OTraceError("E-SHC-178016: Can't create header\n");
		return;
	}

	shcTxn = NULL;
}
