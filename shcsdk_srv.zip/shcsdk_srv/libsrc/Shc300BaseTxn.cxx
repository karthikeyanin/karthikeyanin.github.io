static char _Shc300BaseTxn_cxx_what[] = "@(#) Shc300BaseTxn.cxx 1.13.1.2 15/04/27 16:11:29";

/*
 *  Copyright (C) 2004 eFunds Corporation ("eFunds").  All Rights Reserved.
 *  eFunds Canada Corporation is an authorized user.
 *
 *  IST is a registered trademark of eFunds Corporation.  Other brand or
 *  product names are trademarks or registered trademarks of their respective
 *  holders.
 *
 *  The information contained herein is the unpublished proprietary property
 *  of eFunds.  Except as specifically authorized in writing by eFunds, the
 *  holder of this document shall: i) keep all information contained herein
 *  confidential, and ii) protect the information, in whole or in part, from
 *  disclosure and dissemination to all third parties.
 *
 *  This document and the software described in it are furnished under license
 *  and may be used or copied only in accordance with the terms of such license.
 *  This document is supplied for information purposes only, is subject to
 *  change without notice, and should not be construed as a commitment by
 *  either eFunds Corporation or eFunds Canada Corporation.
 *
 *
 *                        MODIFICATION HISTORY                  REVIEW
 *
 *	SPR#	Who	Date	Description			Who	Date
 * ===========================================================================
 *R00xxxx ztang 05Nov03	Creation
 *R018276 pve	27Nov06	Add new OTraceLog messages
 *R028271 dipa  18Jun10 Txn Statistics
 *R030381 dipa  02Mar12 Removed TXNSTAT macro
 */
/* File Number 42 */

#include <stdio.h>
#include <string.h>
#include <ctype.h>
#include <oasis.h>
#include <ist_otrace.h>
#include <shcdef.h>
#include <shc.h>
#include <CShcLog.h>
#include <ShcmsgHelper.h>
#include <ShcFinAuthReq.h>
#include <ShcMacHelper.h>
#include <ShcTimerHelper.h>
#include <ShcApp.h>
#include <Shc300BaseTxn.h>
#include <Shc300Helper.h>
#include <shc_callback.h>

//R028271 >>>
#include <TxnStat.h>
//<<< R028271

int Shc300BaseTxn::process()
{
	enrich();

	/* R002797 */
    int callbackRet=shc_callback(header,"pre_edit");

	switch(callbackRet)
	{
	case SHCCALLBACKOVERRIDE:
		OTraceInfo("I-SHC-042001: Skipped as pre_edit callback function asked\n");
		return 0;
	case SHCCALLBACKDROP:
		thisShcApp->shc300HelperObj->shc_callback_log(header, SHCCALLBACKDROP);
		//	>>>	R018276
		OTraceLog("L-SHC-042002: Drop message ID[%s]/m%04d/t%06ld/p%06ld\n",
			header->msg.shclog_id, header->msg.msgtype, header->msg.trace, header->msg.pcode);

		//R028271 >>>
		TxnStatReport(header->msg.shclog_id,TS_SHC,TSR_DROP,DROP_BY_CALLBACK_SHC300_pre_edit,0,0);
		//<<< R028271
		//	<<<	R018276
		return(0);
	case SHCCALLBACKDENY:
		thisShcApp->shc300HelperObj->shc_deny_txn(header);
		{
			OTraceInfo("I-SHC-042003: Denied as pre_edit callback function asked\n");
			return 0;
		}
	case SHCCALLBACKCONTINUE:
	default:
		break;
	}

	restore();
	edit();
	doWork();

	callbackRet = shc_callback(header,"post_edit");

	return 0;
}










