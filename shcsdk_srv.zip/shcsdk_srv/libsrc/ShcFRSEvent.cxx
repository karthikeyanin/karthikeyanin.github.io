static char _ShcFRSEvent_cxx_what[] = "@(#) ShcFRSEvent.cxx 1.2 05/05/16 13:52:45";

/*
 *  Copyright (C) 2004 eFunds Corporation ("eFunds").  All Rights Reserved.     
 *  eFunds Canada Corporation is an authorized user.                            
 *                                                                              
 *  IST is a registered trademark of eFunds Corporation.  Other brand or        
 *  product names are trademarks or registered trademarks of their respective   
 *  holders.                                                                    
 *                                                                              
 *  The information contained herein is the unpublished proprietary property    
 *  of eFunds.  Except as specifically authorized in writing by eFunds, the     
 *  holder of this document shall: i) keep all information contained herein     
 *  confidential, and ii) protect the information, in whole or in part, from    
 *  disclosure and dissemination to all third parties.                          
 *                                                                          
 *  This document and the software described in it are furnished under license  
 *  and may be used or copied only in accordance with the terms of such license.
 *  This document is supplied for information purposes only, is subject to      
 *  change without notice, and should not be construed as a commitment by       
 *  either eFunds Corporation or eFunds Canada Corporation. 
 *
 *
 *
 *                        MODIFICATION HISTORY                  REVIEW
 *
 *	SPR#	Who	Date	Description			Who	Date   
 * ===========================================================================
 * R0xxxxx jyang 09Dec03 Created
 */

//File Number 76

#include <ShcApp.h>
#include <ShcFRSEvent.h>
#include <ShcmsgEventHelper.h>
#include <ShcmsgHelper.h>

int ShcFRSEvent::enrich()
{
	OTraceInfo("I-SHC-076001: Time out of message: %d trace %d event %d unit %d\n",
		header->msg.msgtype, header->msg.trace, 
		header->eventId, header->msg.unit);

	if ( header->msg.msgtype == SHC_ISS_ADMIN 
	  || header->msg.msgtype == SHC_ISS_ADMIN_ADVICE )
	{
		shcBin = header->acqShcBin;
	}
	else
	{
		//Form ShcmsgEvent:enrich
		/*
		*	Remove the message from the event queue
		*/
		tm_dequeue(header->eventId);
		header->eventId = -1;

		shcBin = header->issShcBin;
	}
	return 0;
}

int ShcFRSEvent::doWork()
{
	/*  Handle 06xx time out  */
	//ShcmsgEvent:doWork()
	if ( ! header->shouldContinue(TXN_PROC_SKIP_DOWORK) )
		return False;
		
	if ( thisShcApp->shcmsgEventHelperObj->retryOnTimeout(header, shcBin) == True )
	{
		header->setSkipFlag();
		return False;
	}
		
	switch(header->msg.msgtype)
	{
	case    SHC_FRS_ADVICE:
			thisShcApp->shcmsgHelperObj->shc_set_return_msgno(&header->msg);
	        header->msg.respcode = SHC_RC_IssuerTimeout;
	        header->logFlag = SHC_LOG_UPD_REQ;
           	header->shcerr = SH_RETURN;
        break;

	default:
	
		break;
	}
	
	OTraceDebug( "D-SHC-076002: Leave ShcFRSEvent::doWork()\n" );
	
	return 0;
}
