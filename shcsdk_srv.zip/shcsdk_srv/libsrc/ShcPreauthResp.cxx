static char _ShcPreauthResp_cxx_what[] = "@(#) ShcPreauthResp.cxx 1.22.3.1 20/05/21 04:59:26";

/*
 *  Copyright (C) 2004 eFunds Corporation ("eFunds").  All Rights Reserved.     
 *  eFunds Canada Corporation is an authorized user.                            
 *                                                                              
 *  IST is a registered trademark of eFunds Corporation.  Other brand or        
 *  product names are trademarks or registered trademarks of their respective   
 *  holders.                                                                    
 *                                                                              
 *  The information contained herein is the unpublished proprietary property    
 *  of eFunds.  Except as specifically authorized in writing by eFunds, the     
 *  holder of this document shall: i) keep all information contained herein     
 *  confidential, and ii) protect the information, in whole or in part, from    
 *  disclosure and dissemination to all third parties.                          
 *                                                                          
 *  This document and the software described in it are furnished under license  
 *  and may be used or copied only in accordance with the terms of such license.
 *  This document is supplied for information purposes only, is subject to      
 *  change without notice, and should not be construed as a commitment by       
 *  either eFunds Corporation or eFunds Canada Corporation. 
 */
/*
 *
 *                        MODIFICATION HISTORY                  REVIEW
 *
 *	SPR#	Who	Date	Description			Who	Date   
 * ===========================================================================
 *	ss		18Jun92		Set saf to SH_SAF_PENDING when preauth authorized txn.
 *	ad		28nov92		If txntype is ISO_CARDVALIDATE and the transaction
 *							was approved then do NOT send an advice to issuer.
 *	ss		12Jan93		Added locate and remove event for PREAUTH Message.
 *	ss		10May94		Added checking of SHC_RC_ApprovedNoForward to indicate
 *							not to forward advice message to host.
 *	MI		20Aug95     Txns being routed twice: once from here
 *							and once from shc_process()
 * R005901&5902	jy	12Apr01	Get resp msgtype and Set routing flag appropriately
 *						for SHC_RC_Approved and SHC_RC_ApprovedNoForward
 * R007062	gbeeng	26Nov2001	C++ Migration
 * R008038 jyang Restore formatter_use field in some condition
 * R010133 jyang Deny timeout IST preauth message
 * R011925 jyang 16Sep04 SAF Interleave support
 * R029309 dipa  21Apr11 Generate new chipindex to handle late response
 * R029402 dipa  13May11 Fix compilation bug for enable-txnstat
 * R030381 dipa  02Mar12 Txn statistics
 * IST_S761SP8-77	dipa	23May14	Clone of R028544[Call shc_cam_response_start() & shc_cam_response_result() when preauth response is sent back to acquirer]
 */

//File Number 109

#include <stdio.h>
#include <string.h>
#include <oasis.h>
#include <ist_otrace.h>
#include <ShcMsgCache.h>
#include <shc.h>
#include <shcpreauth.h>
#include <ShcmsgHeader.h>
#include <tm.h>
#include <istsafe.h>
#include <ShcFinAuthHelper.h>
#include <ShcmsgHelper.h>
#include <ShcTimerHelper.h>
#include <ShcPreauthResp.h>
#include <ShcApp.h>
#include <ShcBin.h>
#include <ShcmsgTxnHelper.h>
#include <ShcProcessor.h>
#include <ShcSaf.h>
#include <ShcPreauthHelper.h>
#include <mb_umi.h> 
#include <TxnStat.h> //R029402
#include <ShcCamHelper.h>

extern int shc_advice(ShcmsgHeader *header);
	
/*****************************************************************************/
int ShcPreauthResp::enrich()
{
//	struct	ShcWithSegment omsg;

	header->msg.msgtype = header->msg.origmsg;
	return 0;
}


/*****************************************************************************/
int ShcPreauthResp::restore()
{
	/*	12Jan93, SS added
	 *	Remove event and re-instated the event 
	 */
	int		save_msgno;	
	save_msgno = header->msg.msgtype;
	if(thisShcApp->shcTimerObj->shc_locate_event(header) < 0)
	{
		OTraceWarning("W-SHC-109001: No match for transaction: %d trace %d, Ignored\n", 
			header->msg.msgtype, header->msg.trace);
			
		header->setSkipFlag(TXN_PROC_SKIP_EDIT|TXN_PROC_SKIP_VERIFY|TXN_PROC_SKIP_DOWORK);
		header->logFlag |= SHC_LOG_LATE_RESP;

		//R029309 >>>
		char tmpLogId[sizeof(header->msg.shclog_id)];
		istsafe_strcpy(tmpLogId, sizeof(header->msg.shclog_id), header->msg.shclog_id);
		mb_getUmi(header->msg.shclog_id, sizeof(header->msg.shclog_id));
		OTraceLog("L-SHC-109002: Replace ID [%s] with ID [%s]\n", tmpLogId, header->msg.shclog_id);
		TxnStatEquate(tmpLogId, header->msg.shclog_id);
		//R029309 <<<

		header->shcerr = SH_IGNORE;     // R010133
		return ( -1 );                  // R010133
	}
	else
	{
		tm_dequeue(header->eventId);
		
		header->msg.senderid = header->reqMsg->senderid;
		
								/* R008038 >> */
		if( ! (header->msg.device_cap & SH_DEVCAP_KEEP_FORMATTER_USE) )
			memcpy( header->msg.formatter_use, header->reqMsg->formatter_use
				, sizeof( header->msg.formatter_use) );	
								/* R008038 << */
	}
	
	header->msg.msgtype = save_msgno;	
	
	return 0;
}


/*****************************************************************************/
int ShcPreauthResp::doWork()
{
	/*
	 *	Called when a pre-authorization server responds to a request.
	 */
	
	int		save_respcode;			/* 10May94 */
	
	header->shcerr |= ( SH_TIMER_PRESENT | SH_SETTIMER);

	switch(header->msg.respcode)
	{
	case	SHC_RC_Approved:
		/*	The pre-authorization module approved this transaction
			Our task is to send an approval to the acquirer and an advice
			to the issuer.
		*/

	case	SHC_RC_ApprovedNoForward:			/* 10May94 */
		/* 10May94 
		*	Add new respocde for SHC_RC_ApprovedNoForward to
		*	indicate no advice transaction to be forwarded to host
		*/
		save_respcode = header->msg.respcode ;
		if(header->msg.respcode == SHC_RC_ApprovedNoForward)
			header->msg.respcode = SHC_RC_Approved;

		if(shc_isdown(header->issShcBin->binPkg) ||
            (shcApp->saf_interleave&&shcIsReplay(header->issShcBin->binPkg,header->msg.iss_entityId)) )    // R011925
			/*
			 *	write to saf file 
			 *	Note:	we must call shc_saf() with msgtype == PREAUTH_RESP
			 *			since we want to avoid multiple authorizations.
			 *	Also:	We call shc_saf() before return_finauth() so it may
			 *			set up proper flags.
			 */
			if (save_respcode != SHC_RC_ApprovedNoForward)
				thisShcApp->shcSafHelperObj->shc_saf(header);

		header->msg.saf = SH_SAF_PENDING;	/* 18June92, Sunny */

		/*	reply to and route the response */
		header->msg.msgtype = header->msg.origmsg;

		/* R005901 & R005902 >> send back to original sender/acquirer */
		thisShcApp->shcmsgHelperObj->shc_set_return_msgno( &(header->msg) );
		header->msg.senderid = header->reqMsg->senderid;
		header->shcerr |= SH_RETURN;
		/* R005901 & R005902 << */

		// R028544 >>> 
		if( thisShcApp->shcCamHelperObj->shc_cam_response_start( header ) < 0 )
		{
			OTraceError("E-SHC-109001.1: Unable to send message to cam. \n");
		}
		if( thisShcApp->shcCamHelperObj->shc_cam_response_result( header ) < 0 )
		{
			OTraceError("E-SHC-109001.2: Unable to retrieve result from cam.\n");
		}
		//<<< R028544


		thisShcApp->shcmsgHelperObj->shc_route(header);
		if (!(header->shcerr&SH_IGNORE))
			header->logFlag |= SHC_LOG_UPD_REQ; 

//        if( thisShcApp->shcmsgTxnHelperObj->enqueueInternalMsg(header) == NULL )
//        	OTraceError("E-SHC-109002: Unable to enqueueInternalMsg() in ShcPreauthResp::doWork()\n");

		/* 10May94
		*	If save_respcode is equal ApprovedNoForward
		*	do not create advice message here.
		*/
		if(save_respcode == SHC_RC_ApprovedNoForward)
		{
			header->shcerr = SH_IGNORE;
			break;
		}

		/*	28nov92 */
		if( save_respcode == SHC_RC_Approved )
		{
			if(shcGetProcessCode(header->msg.pcode) == SH_ISO_CARDVALIDATE)
				header->shcerr = SH_IGNORE;
			else if(shc_isdown(header->issShcBin->binPkg)  || (shcApp->saf_interleave&&shcIsReplay(header->issShcBin->binPkg,header->msg.iss_entityId)) ) // R011925
				/*	There is no point sending an advice. 
				Simply put txn in saf file */
				header->shcerr		= SH_IGNORE;
			else
			{
				/*	create the advice */
				if(shcIsFinancialRequest(header))
					header->msg.msgtype = SHC_FINREQ_ADVICE;
				else
					header->msg.msgtype = SHC_AUTHREQ_ADVICE;

				thisShcApp->shcPreauthHelperObj->shc_advice(header);
			}
		}

		break;
	
	case	SHC_RC_Continue:
		/*
	 	 *	The pre-authorization module was not able to approve the transaction
	 	 *	but requires that it be forwaded to the issuer
	 	 */
	 	header->msg.msgtype = header->msg.origmsg;	// R017683
	 	
		ShcProcessor *tmpProcessor;
		header->truelength();
		if ((tmpProcessor = thisShcApp->shcmsgTxnHelperObj->enqueueInternalMsg(&header->msg)) == NULL)
		{
			header->shcerr = SH_IGNORE;
			return -1;
		}
		else
		{
			ShcmsgHeader *msgHeader = (ShcmsgHeader *)tmpProcessor->header;
			
			msgHeader->allocateAndCopyOrigMsg(&header->msg);
			msgHeader->origMsg->msgtype = SHC_PREAUTH_RESP;
			header->shcerr = SH_IGNORE;

		}

		break;
		
	default:
		/*
		 *	The pre-authorization module declined the transaction and the
		 *	response code is in 'respcode'.
		 */
		header->msg.msgtype = header->msg.origmsg;
		header->msg.saf = SH_SAF_PENDING;	/* 18June92, Sunny */
		//R028544 >>>
		thisShcApp->shcmsgHelperObj->shc_set_return_msgno(&header->msg);
		if( thisShcApp->shcCamHelperObj->shc_cam_response_start( header ) < 0 )
		{
			OTraceError("E-SHC-109003: Unable to send message to cam. \n");
		}
		if( thisShcApp->shcCamHelperObj->shc_cam_response_result( header ) < 0 )
		{
			OTraceError("E-SHC-109004: Unable to retrieve result from cam.\n");
		}
		header->msg.msgtype = header->msg.origmsg;
		//<<< R028544

		return thisShcApp->shcFinAuthHelperObj->shc_return_finauth(header, -1);
		break;
	}

	return(0);
	
}

/*****************************************************************************/


