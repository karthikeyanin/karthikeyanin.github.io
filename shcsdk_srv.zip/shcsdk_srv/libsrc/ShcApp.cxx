/*
 *  Copyright (C) 2004 eFunds Corporation ("eFunds").  All Rights Reserved.     
 *  eFunds Canada Corporation is an authorized user.                            
 *                                                                              
 *  IST is a registered trademark of eFunds Corporation.  Other brand or        
 *  product names are trademarks or registered trademarks of their respective   
 *  holders.                                                                    
 *                                                                              
 *  The information contained herein is the unpublished proprietary property    
 *  of eFunds.  Except as specifically authorized in writing by eFunds, the     
 *  holder of this document shall: i) keep all information contained herein     
 *  confidential, and ii) protect the information, in whole or in part, from    
 *  disclosure and dissemination to all third parties.                          
 *                                                                          
 *  This document and the software described in it are furnished under license  
 *  and may be used or copied only in accordance with the terms of such license.
 *  This document is supplied for information purposes only, is subject to      
 *  change without notice, and should not be construed as a commitment by       
 *  either eFunds Corporation or eFunds Canada Corporation. 
 */
/*
static char SCCSid[] = "@(#) ShcApp.cxx 1.23 17/08/02 14:43:27";
 *
 *  MODIFICATION HISTORY                              REVIEW
 *
 *	SPR#	Who	Date	Description	                  Who	Date   
 * ===========================================================================
 *R00xxxx ztang 05Nov03 Creation
 *	R020052	spa	21May07	Added FMBlockRegistration
 * R020524 jyang 04Jul07 Added dual-message transaction support
 */

//File Number 59

#if defined( WIN32 )
#       define SHCDLLEXPORT __declspec(dllexport)
#else
#       define SHCDLLEXPORT
#endif


#include <stdio.h>
#include <ist_cfg.h>
#include <oasis.h>
#include <ist_otrace.h>
#include <shc.h>
#include <string.h>
#include <security.h>	/* R005156 */
#include <CShcLog.h>
#include <ShcSdkCommon.h>
#include <ShcSaf.h>
#include <ShcDKEHelper.h>
#include <ShcmsgHelper.h>
#include <Shc300Log.h>
#include <IssProfile.h>
#include <ShcAppBase.h>
#include <ShcKeyTxnHelper.h>
#include <ShcApp.h>
#include <ShcProcessorRegistration.h>
#include <ShcmsgTxnRegistration.h>
#include <Shc300TxnRegistration.h>
#include <ShcAdminTxnRegistration.h>
#include <ShcFRSReqHelper.h>
#include <ShcmsgHelper.h>
#include <ShcmsgTxnHelper.h>
#include <ShcCamHelper.h>
#include <ShcFinAuthHelper.h>
#include <ShcIBFTHelper.h>
#include <ShcKeyHelper.h>
#include <ShcMacHelper.h>
#include <ShcBackOfficeHelper.h>
#include <ShcPreauthSvcHelper.h>
#include <ShcRetHelper.h>
#include <ShcAdminReqHelper.h>
#include <ShcAdminRespHelper.h>
#include <Shc500Helper.h>
#include <ShcNetworkMsgHelper.h>
#include <ShcChargeBackHelper.h>
#include <ShcnetEventHelper.h>
#include <CShcNotify.h>
#include <ShcRevReqHelper.h>
#include <ShcLogReqHelper.h>
#include <ShcDeviceAckHelper.h>
#include <ShcDeviceNakHelper.h>
#include <ShcRevRespHelper.h>
#include <ShcPreauthHelper.h>
#include <ShcSaf.h>
#include <ShcTimerHelper.h>
#include <ShcMainLoop.h>
#include <ShcmsgEventHelper.h>
#include <ShcnetApp.h>
#include <Shc300Helper.h>
#include <ShcHelper.h>
#include <IssProfile.h>
#include <AcqProfile.h>
#include <InstProfile.h>
#include <ShcDKEHelper.h>
#include <ShcKeyTxnHelper.h>
#include <Shc300Log.h>
#include <Shc600Log.h>
#include <ShcnetTxnRegistration.h>
#include <ShcAppBase.h>
#include <FMBlockRegistration.h>	//	---	R020052
#include <ShcDualMsgHelper.h>
#include <ShcLateRespHelper.h>
// #include <DNHelper.h>			// R027759 -- use one in shcsdk_lib
#include <DNSegHelper.h>			// R027759
#include <LCRHelper.h>				// R027759
#include <TieBreaker.h>				// R027759
#include <ist_seg_elf_id_map.h>
#include <ist_seg_id.h>
#include <ist_seg_name.h>

ShcLateRespHelper *shcLateRespHelperObj=NULL;



/*------------------------------------------------------------------------*/

ShcApp::ShcApp(): ShcAppBase()
{
	serverMailboxId = -1;
//	shcmsgLogObj = (ShcLog *)shcHelperRegister.getTargetObj(SHC_ShcLog);
//	shc600LogObj = (Shc600Log *)shcHelperRegister.getTargetObj(SHC_Shc600Log);
	shc300LogObj = (Shc300Log *)shcHelperRegister.getTargetObj(SHC_Shc300Log);
//	memset(&shccard, 0, sizeof(shccard));
	
	shcPreauthHelperObj = (ShcPreauthHelper *)shcHelperRegister.getTargetObj(SHC_ShcPreauthHelper);
	shcCamHelperObj = (ShcCamHelper *)shcHelperRegister.getTargetObj(SHC_ShcCamHelper);
	shcFinAuthHelperObj = (ShcFinAuthHelper *)shcHelperRegister.getTargetObj(SHC_ShcFinAuthHelper);
	shcIBFTHelperObj = (ShcIBFTHelper *)shcHelperRegister.getTargetObj(SHC_ShcIBFTHelper);
	shcNetworkMsgHelperObj = (ShcNetworkMsgHelper *)shcHelperRegister.getTargetObj(SHC_ShcNetworkMsgHelper);
	shcRevReqHelperObj = (ShcRevReqHelper *)shcHelperRegister.getTargetObj(SHC_ShcRevReqHelper);
	shcRevRespHelperObj = (ShcRevRespHelper *)shcHelperRegister.getTargetObj(SHC_ShcRevRespHelper);
	shcmsgEventHelperObj = (ShcmsgEventHelper *)shcHelperRegister.getTargetObj(SHC_ShcmsgEventHelper);
	shcmsgTxnHelperObj = (ShcmsgTxnHelper *)shcHelperRegister.getTargetObj(SHC_ShcmsgTxnHelper);
	shcBackOfficeHelperObj = (ShcBackOfficeHelper *)shcHelperRegister.getTargetObj(SHC_ShcBackOfficeHelper);
	shc300HelperObj = (Shc300Helper *)shcHelperRegister.getTargetObj(SHC_Shc300Helper);
	shcAdminReqHelperObj = (ShcAdminReqHelper *)shcHelperRegister.getTargetObj(SHC_ShcAdminReqHelper);
	shcAdminRespHelperObj = (ShcAdminRespHelper *)shcHelperRegister.getTargetObj(SHC_ShcAdminRespHelper);
	shcPreauthSvcHelperObj = (ShcPreauthSvcHelper *)shcHelperRegister.getTargetObj(SHC_ShcPreauthSvcHelper);
	shcRetHelperObj = (ShcRetHelper *)shcHelperRegister.getTargetObj(SHC_ShcRetHelper);
	shc500HelperObj = (Shc500Helper *)shcHelperRegister.getTargetObj(SHC_Shc500Helper);
	shcChargeBackHelperObj = (ShcChargeBackHelper *)shcHelperRegister.getTargetObj(SHC_ShcChargeBackHelper);
	shcLogReqHelperObj = (ShcLogReqHelper *)shcHelperRegister.getTargetObj(SHC_ShcLogReqHelper);
	shcnetEventHelperObj = (ShcnetEventHelper *)shcHelperRegister.getTargetObj(SHC_ShcnetEventHelper);
	shcDeviceAckHelperObj = (ShcDeviceAckHelper *)shcHelperRegister.getTargetObj(SHC_ShcDeviceAckHelper);
	shcDeviceNakHelperObj = (ShcDeviceNakHelper *)shcHelperRegister.getTargetObj(SHC_ShcDeviceNakHelper);
	shcKeyTxnHelperObj = (ShcKeyTxnHelper *)shcHelperRegister.getTargetObj(SHC_ShcKeyTxnHelper);
	shcSafHelperObj = (ShcSaf *)shcHelperRegister.getTargetObj(SHC_ShcSaf);
	shcFRSReqHelperObj = (ShcFRSReqHelper *)shcHelperRegister.getTargetObj(SHC_ShcFRSReqHelper);
	shcDualMsgHelperObj = (ShcDualMsgHelper *)shcHelperRegister.getTargetObj(SHC_ShcDualMsgHelper);
	shcLateRespHelperObj = (ShcLateRespHelper *)shcHelperRegister.getTargetObj(SHC_ShcLateRespHelper);
	DNSegHelperObj = (DNSegHelper*)shcHelperRegister.getTargetObj(SHC_DNSegHelper); // R027759
	LCRHelperObj   = (LCRHelper  *)shcHelperRegister.getTargetObj(SHC_LCRHelper);	// R027759
	TieBreakerObj  = (TieBreaker *)shcHelperRegister.getTargetObj(SHC_TieBreaker);	// R027759

	ON_DOT_id = ElfIdMap::elf_to_id(IST_SEG_ON_DOT);
	ON_DOT_LOG_id = ElfIdMap::elf_to_id(IST_SEG_ON_DOT_LOG);
}

ShcProcessorRegistration 	shcProcessorRegistration((char *)"ShcProcessor");
ShcAdminTxnRegistration  	shcAdminTxnRegistration ((char *)"ShcAdminTxn");
Shc300TxnRegistration  		shc300TxnRegistration ((char *)"Shc300Txn");
ShcmsgTxnRegistration  		shcmsgTxnRegistration ((char *)"ShcmsgTxn");
ShcnetTxnRegistration  		shcnetTxnRegistration ((char *)"ShcnetTxn");

FMBlockRegistration 		FMBlockRegister((char*)"ShcBaseTxn");     //	---	R020052


