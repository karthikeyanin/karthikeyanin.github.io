static char _ShcSrvHelperFactory_cxx_what[] = "@(#) ShcSrvHelperFactory.cxx 1.13 17/08/02 14:54:56";

/*
 *  Copyright (C) 2004 eFunds Corporation ("eFunds").  All Rights Reserved.     
 *  eFunds Canada Corporation is an authorized user.                            
 *                                                                              
 *  IST is a registered trademark of eFunds Corporation.  Other brand or        
 *  product names are trademarks or registered trademarks of their respective   
 *  holders.                                                                    
 *                                                                              
 *  The information contained herein is the unpublished proprietary property    
 *  of eFunds.  Except as specifically authorized in writing by eFunds, the     
 *  holder of this document shall: i) keep all information contained herein     
 *  confidential, and ii) protect the information, in whole or in part, from    
 *  disclosure and dissemination to all third parties.                          
 *                                                                          
 *  This document and the software described in it are furnished under license  
 *  and may be used or copied only in accordance with the terms of such license.
 *  This document is supplied for information purposes only, is subject to      
 *  change without notice, and should not be construed as a commitment by       
 *  either eFunds Corporation or eFunds Canada Corporation. 
 *
 *
 *                        MODIFICATION HISTORY                  REVIEW
 *
 * SCR#     Who    Date  Description
 * ===========================================================================
 * R0xxxxx 
 */

/* File Number 149 */

#include <ShcSdkCommon.h>
#include <ShcBin.h>          
#include <ShcPreauthHelper.h> 	
#include <ShcCamHelper.h>		
#include <ShcFinAuthHelper.h>	
#include <ShcIBFTHelper.h>		
#include <ShcNetworkMsgHelper.h> 
#include <ShcRevReqHelper.h>		
#include <ShcRevRespHelper.h>	
#include <ShcSaf.h>				
#include <ShcmsgEventHelper.h>	
#include <ShcmsgTxnHelper.h> 	
#include <ShcBackOfficeHelper.h>	
#include <Shc300Helper.h>        
#include <ShcAdminReqHelper.h>	
#include <ShcAdminRespHelper.h>
#include <ShcPreauthSvcHelper.h>
#include <ShcRetHelper.h>
#include <Shc500Helper.h>	
#include <ShcChargeBackHelper.h>
#include <ShcLogReqHelper.h>
#include <ShcnetEventHelper.h>
#include <ShcDeviceAckHelper.h>
#include <ShcDeviceNakHelper.h>
#include <ShcKeyTxnHelper.h>
#include <ShcFRSReqHelper.h>	
#include <ShcSrvHelperFactory.h>
#include <Shc600Log.h>
#include <Shc300Log.h>
#include <ShcnetApp.h>

#include <ShcDualMsgHelper.h>
#include <ShcLateRespHelper.h>
// #include <DNHelper.h>			// R027759--use one in shcsdk_lib
#include <DNSegHelper.h>			// R027759
#include <LCRHelper.h>				// R027759
#include <TieBreaker.h>				// R027759
#include <ShcCutoverHelper.h>                   // R027855
#include <ShcmsgODHelper.h>


ShcHelperBase *ShcSrvHelperFactory::createInstance(const char *condition, const void *msg)
{
	OTraceDebug("XXXXX: condition(%s)\n", condition ? condition : (char*)"NULL");
	ShcHelperBase *obj = NULL;
	if (strcmp(condition, SHC_ShcBin) == 0)
		obj = new ShcBin();    
	else if (strcmp(condition, SHC_ShcLog) == 0)
		obj = new ShcLog();
	else if (strcmp(condition, SHC_Shc600Log) == 0)
		obj = new Shc600Log();
	else if (strcmp(condition, SHC_ShcApp) == 0)
		obj = new ShcApp();
	else if (strcmp(condition, SHC_ShcPreauthHelper) == 0) 	
		obj = new ShcPreauthHelper();
	else if (strcmp(condition, SHC_ShcCamHelper) == 0)
		obj = new ShcCamHelper();
	else if (strcmp(condition, SHC_ShcFinAuthHelper) == 0)
		obj = new ShcFinAuthHelper();
	else if (strcmp(condition, SHC_ShcIBFTHelper) == 0)
		obj = new ShcIBFTHelper();
	else if (strcmp(condition, SHC_ShcNetworkMsgHelper) == 0)
		obj = new ShcNetworkMsgHelper();
	else if (strcmp(condition, SHC_ShcRevReqHelper) == 0)
		obj = new ShcRevReqHelper();
	else if (strcmp(condition, SHC_ShcRevRespHelper) == 0)
		obj = new ShcRevRespHelper();
	else if (strcmp(condition, SHC_ShcSaf) == 0)
		obj = new ShcSaf();
	else if (strcmp(condition, SHC_ShcmsgEventHelper) == 0)
		obj = new ShcmsgEventHelper();
	else if (strcmp(condition, SHC_ShcmsgTxnHelper) == 0)
		obj = new ShcmsgTxnHelper();
	else if (strcmp(condition, SHC_ShcBackOfficeHelper) == 0)
		obj = new ShcBackOfficeHelper();
	else if (strcmp(condition, SHC_Shc300Helper) == 0)
		obj = new Shc300Helper();
	else if (strcmp(condition, SHC_ShcAdminReqHelper) == 0)
		obj = new ShcAdminReqHelper();
	else if (strcmp(condition, SHC_ShcAdminRespHelper) == 0)
		obj = new ShcAdminRespHelper();
	else if (strcmp(condition, SHC_ShcPreauthSvcHelper) == 0)
		obj = new ShcPreauthSvcHelper();
	else if (strcmp(condition, SHC_ShcRetHelper) == 0)
		obj = new ShcRetHelper();
	else if (strcmp(condition, SHC_Shc500Helper) == 0)
		obj = new Shc500Helper();
	else if (strcmp(condition, SHC_ShcChargeBackHelper) == 0)
		obj = new ShcChargeBackHelper();
	else if (strcmp(condition, SHC_ShcLogReqHelper) == 0)
		obj = new ShcLogReqHelper();
	else if (strcmp(condition, SHC_ShcnetEventHelper) == 0)
		obj = new ShcnetEventHelper();
	else if (strcmp(condition, SHC_ShcDeviceAckHelper) == 0)
		obj = new ShcDeviceAckHelper();
	else if (strcmp(condition, SHC_ShcDeviceNakHelper) == 0)
		obj = new ShcDeviceNakHelper();
	else if (strcmp(condition, SHC_ShcKeyTxnHelper) == 0)
		obj = new ShcKeyTxnHelper();
	else if (strcmp(condition, SHC_ShcFRSReqHelper) == 0)
		obj = new ShcFRSReqHelper();
	else if (strcmp(condition, SHC_ShcnetApp) == 0)
		obj = new ShcnetApp();
	else if (strcmp(condition, SHC_Shc300Log) == 0)
		obj = new Shc300Log();
	else if (strcmp(condition, SHC_ShcDualMsgHelper) == 0)	// R020524
		obj = new ShcDualMsgHelper();
    else if (strcmp(condition, SHC_ShcLateRespHelper) == 0)
        obj = new ShcLateRespHelper();
    else if (strcmp(condition, SHC_DNSegHelper) == 0)
        obj = new DNSegHelper();
    else if (strcmp(condition, SHC_LCRHelper) == 0)			// R027759
        obj = new LCRHelper();
    else if (strcmp(condition, SHC_TieBreaker) == 0)		// R027759
        obj = new TieBreaker();
    else if (strcmp(condition, SHC_ShcCutoverHelper) == 0)
        obj = new ShcCutoverHelper();
    else if (strcmp(condition, SHC_ShcmsgODHelper) == 0)
        obj = new ShcmsgODHelper();

	else 
		obj = NULL;
	
	if ( obj )
		OTraceDebug("D-SHC-2301:     Create Instance[%s] name[%s]\n", 
			condition, obj->getName());
	else
		OTraceError("D-SHC-2302:     Unknown Object Name[%s]\n", condition);
		
	return obj;
}


