
static char _ShcDualMsgEvent_cxx_what[] = "@(#) ShcDualMsgEvent.cxx 1.1 07/07/11 14:44:45";

/*
 *  Copyright (C) 2004 eFunds Corporation ("eFunds").  All Rights Reserved.     
 *  eFunds Canada Corporation is an authorized user.                            
 *                                                                              
 *  IST is a registered trademark of eFunds Corporation.  Other brand or        
 *  product names are trademarks or registered trademarks of their respective   
 *  holders.                                                                    
 *                                                                              
 *  The information contained herein is the unpublished proprietary property    
 *  of eFunds.  Except as specifically authorized in writing by eFunds, the     
 *  holder of this document shall: i) keep all information contained herein     
 *  confidential, and ii) protect the information, in whole or in part, from    
 *  disclosure and dissemination to all third parties.                          
 *                                                                          
 *  This document and the software described in it are furnished under license  
 *  and may be used or copied only in accordance with the terms of such license.
 *  This document is supplied for information purposes only, is subject to      
 *  change without notice, and should not be construed as a commitment by       
 *  either eFunds Corporation or eFunds Canada Corporation. 
 *
 *
 *
 *                        MODIFICATION HISTORY                  REVIEW
 *
 *	SPR#	Who	Date	Description			Who	Date   
 * ===========================================================================
 * R020524 jyang 04Jul07 Created for dual-message transaction support
 */

/* File Number 162 */


#include <stdio.h>
#include <oasis.h>
#include <mb.h>
#include <tm.h>
#include <ist_otrace.h>
#include <shc.h>
#include <shcerror.h>
#include <ShcApp.h>
#include <ShcmsgHelper.h>
#include <ShcDualMsgHelper.h>
#include <ShcDualMsgEvent.h>


int ShcDualMsgEvent::enrich()
{
	OTraceInfo("I-SHC-16201: Time out of InterMsg event: %d trace %d event %d unit %d\n",
		header->msg.msgtype, header->msg.trace, 
		header->eventId, header->msg.unit);

	tm_dequeue(header->eventId);
	header->eventId = -1;

//	shcBin = header->issShcBin;
//	thisShcApp->shcmsgEventHelperObj->restoreOldPINBlock(header);
//	thisShcApp->shcmsgHelperObj->shc_get_pin_data(header);		
	return 0;
}


int ShcDualMsgEvent::edit()
{
	return 0;
}


int ShcDualMsgEvent::doWork()
{
	// drop timeout event message
	header->shcerr = SH_IGNORE;
	return 0;
}


