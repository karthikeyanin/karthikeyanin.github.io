static char _ShcRevReq_cxx_what[] = "@(#) ShcChargeBackReq.cxx 1.4 04/08/24 17:53:47";

/*
 *  Copyright (C) 2004 eFunds Corporation ("eFunds").  All Rights Reserved.     
 *  eFunds Canada Corporation is an authorized user.                            
 *                                                                              
 *  IST is a registered trademark of eFunds Corporation.  Other brand or        
 *  product names are trademarks or registered trademarks of their respective   
 *  holders.                                                                    
 *                                                                              
 *  The information contained herein is the unpublished proprietary property    
 *  of eFunds.  Except as specifically authorized in writing by eFunds, the     
 *  holder of this document shall: i) keep all information contained herein     
 *  confidential, and ii) protect the information, in whole or in part, from    
 *  disclosure and dissemination to all third parties.                          
 *                                                                          
 *  This document and the software described in it are furnished under license  
 *  and may be used or copied only in accordance with the terms of such license.
 *  This document is supplied for information purposes only, is subject to      
 *  change without notice, and should not be construed as a commitment by       
 *  either eFunds Corporation or eFunds Canada Corporation. 
 *
 *
 *
 *                        MODIFICATION HISTORY                  REVIEW
 *
 *	SPR#	Who	Date	Description			Who	Date   
 * ===========================================================================
 * R0xxxxx jyang 21Nov03 Created
 */

//File Number 66

#include <ShcRevReqHelper.h>
#include <ShcChargeBackReq.h>
#include <ShcApp.h>
#include <ShcChargeBackHelper.h>



/*****************************************************************************/

int ShcChargeBackReq::doWork()
{
	if( ! header->shouldContinue(TXN_PROC_SKIP_DOWORK) )
		return 0;

	if ( thisShcApp->shcChargeBackHelperObj->doReplay(header) == True )
		return 0;

	OTraceInfo("I-SHC-066001:(%d)reverse switch transaction\n",__LINE__);

//	if( flagLogRequest )									/* 10002243 */
//	if( header->logFlag & SHC_LOG_REQ )
//		shcLogObj->logTxn(header);							/* 10002243 */

	if ( thisShcApp->shcRevReqHelperObj->needReqReversal(header) == False )
		return (-1);
		
	if ( thisShcApp->shcRevReqHelperObj->needReqUpdateLog(header) == False )
		return 0;

	thisShcApp->shcChargeBackHelperObj->routeReversal(header, header->origMsg->saf);
	
	OTraceDebug("D-SHC-066002:Leave function ShcRevReq::doWork()\n");
	
	return(0);
}




