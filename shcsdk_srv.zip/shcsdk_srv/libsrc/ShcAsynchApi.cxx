static char _ShcFinAuthReq_cxx_what[] = "@(#) ShcAsynchApi.cxx 1.6 19/11/04 17:32:11";
/*
 *  Copyright (C) 2004 eFunds Corporation ("eFunds").  All Rights Reserved.
 *  eFunds Canada Corporation is an authorized user.
 *
 *  IST is a registered trademark of eFunds Corporation.  Other brand or
 *  product names are trademarks or registered trademarks of their respective
 *  holders.
 *
 *  The information contained herein is the unpublished proprietary property
 *  of eFunds.  Except as specifically authorized in writing by eFunds, the
 *  holder of this document shall: i) keep all information contained herein
 *  confidential, and ii) protect the information, in whole or in part, from
 *  disclosure and dissemination to all third parties.
 *
 *  This document and the software described in it are furnished under license
 *  and may be used or copied only in accordance with the terms of such license.
 *  This document is supplied for information purposes only, is subject to
 *  change without notice, and should not be construed as a commitment by
 *  either eFunds Corporation or eFunds Canada Corporation.
 *
 *
 *                        MODIFICATION HISTORY                  REVIEW
 *
 *	SPR#	Who	Date	Description			Who	Date
 * ===========================================================================
 */

#include <stdio.h>
#include <string.h>
#include <ctype.h>
#include <oasis.h>
#include <security.h>
#include <ist_otrace.h>
#include <shc.h>
#include <shc_callback.h>
#include <shc_util_funcs.h>
#include <ist_seg_id.h>
#include <ist_seg_emvbuf.h>
#include <ShcApp.h>
#include <ShcTimerHelper.h>

extern int isAsynchCmdTrnsltPin(int iCmd);

int setAsynchWait( ShcmsgHeader *header )
{
	static const char*	fnDesc = "setAsynchWait";
	int iRes=0;

	thisShcApp->shcTimerObj->shc_set_timers(header);
	// Creates event
	thisShcApp->shcTimerObj->shc_time_message_x( header, (unsigned char *)header->segment );
	OTraceDebug("D-SHC-001240 %s Event creation [%d]\n",fnDesc,header->eventId);

	return(iRes);
}

int setAsynchRespcode(ShcmsgHeader *header,int iCmd,int iRes)
{
	static const char*	fnDesc = "setAsynchRespcode";

	if(iRes>0)
	{
		switch(iCmd)
		{
			case VerifyVisaCvv:
				if(iRes==ESEC_INVALIDCVV)
					header->msg.respcode=SHC_RC_InvalidCVV;
				else
					header->msg.respcode=SHC_RC_UnableToProcess;
				break;
			case TranslatePinBlkBdkToNet:
			case TranslatePinBlkNetToNet:
			case TranslatePinBlkAtmToNet:
				{	
				switch(sec_error())
				{
					case ESEC_PINLENERR:
						header->msg.respcode = SHC_RC_PinLengthError;
						break;
					case ESEC_TIMEOUT:
						header->msg.respcode = SHC_RC_SystemError;
						break;
					default:
						header->msg.respcode = SHC_RC_InvalidPinBlock;
						break;
				}
				}
			break;
			case VerifyAtmPin:
			case VerifyAtmPinXt:
			case VerifyNetPin:
			case VerifyNetPinXt:
				{
				//char loginfo[] = "InvalidPinBlock shc_pin 1";
				switch(iRes)
				{
					case ESEC_PINLENERR:
						header->msg.respcode = SHC_RC_PinLengthError;
						break;
					case ESEC_SANITY_ERROR:
						header->msg.respcode = SHC_RC_InvalidPinBlock;
						// if(shcApp)
						// shcApp->shcDKEApiObj->shc_hsmerror_log( &header->msg, loginfo );
						break;
					case ESEC_TIMEOUT:
						header->msg.respcode = SHC_RC_SystemError;
						break;
					default:
						int retvalue=0;
						// if(shcPinTryCounterObj)
						// {
						// 	int retvalue=shcPinTryCounterObj->getCnt(header,unlockHrs);
						// 	shcPinTryCounterObj->incCnt(header);
						// }
						if(( iCmd ==VerifyAtmPin) || (iCmd == VerifyAtmPinXt) || 
  							(iCmd == VerifyNetPin) || (iCmd ==VerifyNetPinXt))
						{
							if(retvalue+1 >= abs(header->issShcBin->binPkg->txn.npintry))
							{
								header->msg.respcode = SHC_RC_ExceedsPINRetry;
							}
							else
							{
								header->msg.respcode = SHC_RC_IncorrectPIN;
							}
						}
						else
						{
							header->msg.respcode = SHC_RC_InvalidPinBlock;
						}
				}
				}
				break;
			case VerifyMac:
			case VerifyMacLarge:
				header->msg.respcode = SHC_RC_MACKeyError;
				break;
			default:
				header->msg.respcode=iRes;
		}
	}

	return(iRes);
}

int isAsynchCmdPinValidation(int iCmd)
{
	int iRes=0;

	if(	iCmd==VerifyAtmPin		||
		iCmd==VerifyAtmPinXt	||
		iCmd==VerifyNetPin		||
		iCmd==VerifyNetPinXt	)
		iRes=1;

	return(iRes);
}

int setAsynchSrcId(ShcmsgHeader *header,char *srcId,int srcLen)
{
	static const char*	fnDesc = "setAsynchSrcId";

	memset(srcId,0,srcLen);
	snprintf(srcId,srcLen,"%d-%s-%08d~%s",
		header->msg.msgtype,SHC_SERVER_NAME,header->eventId,header->msg.shclog_id);
	OTraceDebug("D-SHC-001101 %s Security SrcId [%s]\n",fnDesc,srcId);

	return(1);
}

