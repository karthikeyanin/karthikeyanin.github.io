/*
 *  Copyright (C) 2004 eFunds Corporation ("eFunds").  All Rights Reserved.
 *  eFunds Canada Corporation is an authorized user.
 *
 *  IST is a registered trademark of eFunds Corporation.  Other brand or
 *  product names are trademarks or registered trademarks of their respective
 *  holders.
 *
 *  The information contained herein is the unpublished proprietary property
 *  of eFunds.  Except as specifically authorized in writing by eFunds, the
 *  holder of this document shall: i) keep all information contained herein
 *  confidential, and ii) protect the information, in whole or in part, from
 *  disclosure and dissemination to all third parties.
 *
 *  This document and the software described in it are furnished under license
 *  and may be used or copied only in accordance with the terms of such license.
 *  This document is supplied for information purposes only, is subject to
 *  change without notice, and should not be construed as a commitment by
 *  either eFunds Corporation or eFunds Canada Corporation.
 *
 *
 *                        MODIFICATION HISTORY                  REVIEW
 *
 *	SPR#	Who	Date	Description			Who	Date
 * ===========================================================================
 *	R020052	spa	21May07	New file created
 *	R020938	spa	16Aug07	IST LM Bridge support
 *  R021024	bby	27Aug07	PAN/CVV/CVV2/Track2 Masking
 *	R021644	lee	04Oct07	IST LM Bridge Enhancement in Sending Late Response
 *	R021677	lee	06Oct07	Corrected Signal 11 error if issuer not found
 *  R021958 lee 13Nov07 Added a segment for Timestamps
 *  R022100 sks 30Nov07 Use func issBinValid & acqBinValid to check validity of bin
 *  R023105 sel 13May08 LM message routing between nodes
 *	R023376	sel	29May08	Debug line with timestamp in milliseconds
 *	R023394	sel	30May05	Debug line with timestamp in milliseconds-OTraceLog
 *  ITM-1560 sel 07Jul08 call shc_route when sending reversal to LM and use SENDAPPLBIN flag
 *  ITM-1567 ram 09Jul08 Set applMailboxId and call flush_mb_cache
 *  R023871 ram 15Jul08 Support LM Trial Mode
 *	R023933	sel	16Jul08	Response code is not altered while sending reversal to LM for issuer timout
 *	R023968 sel	18Jul08	clone from R022876, R023310, R023231
 *	R026365 vmp	13Apr09	Added dbm_rewind at the end of every FM related API's-FM PhaseII enhancement
 *  R027889 dipa 25Feb10 Added dbm_rewind to release locks, if any, for shccard table
 *  R027876 dipa 02Mar10 Segment changes
 *  R028104 dipa 29Apr10 routinInfo - fix
 *  R028747 dipa 17Nov10 Remove reference to rules_keytab[]
 *  R028777 dipa 30Nov10 Fix routing issue
 *  R028714 dipa 07Dec10 FM Enhancements
 *  R029951 dipa 09Dec11 Implement shared memory versioning
 *  R031154 dipa 21Dec12 Clone of R031032
 *  R032444 dipa 30Dec13 Avoid corrupting the value of msg->issuer_data in createFnDataSegment() API
 *  R161675717 IS 15Dec16 Setting up the timer after checking the FM bin up or down so that txn doesnt use the fm_timeout value if FM bin is down
 */

/* File Number 156 */

static char _ShcmsgFMHelper_cxx_what[] = "@(#) ShcmsgFMHelper.cxx 1.42.7.2 20/03/24 07:52:44";

#include <stdio.h>
#include <string.h>
#include <errno.h>
#include <ctype.h>
#include <oasis.h>
#include <dbm.h>
#include <mb.h>
#include <ist_otrace.h>
#include <shc.h>
#include <ShcApp.h>
#include <ShcSdkCommon.h>
#include <ShcProcessorRegistration.h>
#include <ShcmsgProcessor.h>
#include <ShcHelper.h>	//	---	R023968
#include <ShcmsgHelper.h>
#include <ShcBin.h>
#include <ShcmsgFMHelper.h>
#include <ShcmsgHeader.h>
#include <FMCMDHeader.h>
#include <shcmerchant.h>
//	>>>	R025639
#include <FMBlockReq.h>
#include <oc/oc_datetime.h>
//	<<<	R025639
#include <ist_seg_name.h> //R027876
#include <ist_seg_elf_id_map.h> //R027876
#include <ist_seg_id.h> //R027876
#include <ist_seg_pdt_base.h> //R027876
#include <ist_seg_fn_data.h> //R029287
#include <istsafe.h>

#include <HaPtmCctHelper.h>
#include <oc/oc_hires_timer.h>

static int merchantfd = (-1);
static int fmOut_mbId = (-1);
static struct shcmerchant shcmerchant = {0};
static ShcBin LMbin; // --- ITM-1567
static ShcBin FMbin;	//	---	R025639

ShcmsgFMHelper *shcmsgFMHelperObj = NULL;

ShcmsgFMHelper::ShcmsgFMHelper()
{
	fmRuleKeyPtr = NULL;
	fmInstKeys = NULL;

	int i = 0;
	char	buf[40];	//	---	R020938

	HaPtmCctHelper::addHandler( "system.dcs.shc" ) ;

	if(cf_open(NULL) < 0)
	{
		OTraceError("E-SHC-156002:Error in opening in istparam.cfg\n");
		fm_timeout = 10;        //      default value
		OTraceWarning("W-SHC-156003: Parameter shc.FMTimeout is not configured;using default value of 10\n");
		return;
	}

	if(cf_locate("shc.FMTimeout", buf) < 0 )
	{
		fm_timeout = 10;        //      default value
		OTraceWarning("W-SHC-156004: Parameter shc.FMTimeout is not configured;using default value of 10\n");
	}
	else
		fm_timeout = oc_conv_string_to_dbl(buf);

	//	>>>	R020938
	if(cf_locate("shc.LMTimeout", buf) < 0 )
	{
		lm_timeout = 10;        //      default value
		OTraceWarning("W-SHC-156045: Parameter shc.LMTimeout is not configured;using default value of 10\n");
	}
	else
		lm_timeout = oc_conv_string_to_dbl(buf);

	if(cf_locate("shc.denyOnLMTimeout", buf) < 0 )
	{
		denyOnLMTimeout = 0;        //      default value
		OTraceWarning("W-SHC-156046: Parameter shc.denyOnLMTimeout is not configured;using default value of 0\n");
	}
	else if( toupper(buf[0]) == 'Y' || buf[0] == '1' )
		denyOnLMTimeout = 1;
	else
		denyOnLMTimeout = 0;
		//	>>>	R025639
	if(cf_locate("shc.denyOnFMTimeout", buf) < 0 )
	{
		denyOnFMTimeout = 0;        //      default value
		OTraceWarning("W-SHC-156071: Parameter shc.denyOnFMTimeout is not configured;using default value of 0\n");
	}
	else if( toupper(buf[0]) == 'Y' || buf[0] == '1' )
		denyOnFMTimeout = 1;
	else
		denyOnFMTimeout = 0;
		//	<<<	R025639

	if(cf_locate("shc.enableLM", buf) < 0 )
	{
		enableLM = 0;        //      default value
		OTraceWarning("W-SHC-156054: Parameter shc.enableLM is not configured;using default value of 0\n");
	}
	else if( toupper(buf[0]) == 'Y' || buf[0] == '1' )
		enableLM = 1;
	else
		enableLM = 0;

	//	<<<	R020938
	//	>>>	R025639

	//	>>>	ITM-1560
	/*if( cf_locate("LM.TxnInstid", institutionId) <= 0 )
		OTraceWarning("W-SHC-156058: Unable to locate the parameter 'LM.TxnInstid'\n");
	if( cf_locate("LM.TxnUserbinid", userBinId) <= 0 )
		OTraceWarning("W-SHC-156059: Unable to locate the parameter 'LM.TxnUserbinid'\n");
	if (shc_externalBin2InternalBin(LMTxnBin, institutionId, userBinId) >= 0)
		OTraceDebug("D-SHC-156060:Internal ID for LM Bin:%s\n", LMTxnBin);
	else
		OTraceWarning("W-SHC-156061:Internal ID for LM Bin not found\n");*/
	//	<<<	ITM-1560
	//	<<<	R025639

	cf_close();

}

int ShcmsgFMHelper::isFMenabled(char *instId)
{
	int ret = 0;
	static int deb_log = 0;	//	---	R023968
	static int all_log = 0, none_log =0;	//	---	R025639

	setRuleParam(); //R029951
	if((fmInstKeys == NULL) || (fmRuleKeyPtr == NULL))
	{
		if (deb_log != 1)	//	---	R023968
		{
			OTraceError("E-SHC-156005:fm-inst-stats rule not initialised properly\n");
			deb_log = 1;	//	---	R023968
		}
		return (0);
	}
	char *ptr = fmInstKeys;
	//	>>>	R025639	Institutions in Shared Memory
	if(rm_waitForLockedShdMem(fmAppid))
	{
		OTraceWarning("W-SHC-156072: rm.fmAppid[%d] was locked. Go ahead\n", fmAppid);
	}
	if(strcmp(ptr, "all") == 0)
	{
		if(all_log != 1)
		{
			OTraceDebug("D-SHC-156073:All Institutions are enabled for FM Auth\n");
			all_log =1;
		}
		return 1;
	}
	else if(strcmp(ptr, "none") == 0)
	{
		if(none_log != 1)
		{
			OTraceDebug("D-SHC-156074:None of the Institutions are enabled for FM Auth\n");
			none_log = 1;
		}
		return 0;
	}
	//	<<<	R025639
	for(int i=0; i < fmRuleKeyPtr->keysused; i++)
	{
		if(strcmp(ptr, instId) == 0)
		{
			OTraceDebug("D-SHC-156006:Institution [%s] enabled for FM Auth\n", instId);
			ret = 1;
			break;
		}
		ptr += fmRuleKeyPtr->keysize;
	}

	return (ret);

}

//R028714 >>>
void ShcmsgFMHelper::createFnDataSegment(ShcmsgHeader *header)
{
	IstSegFNData *fnData = (IstSegFNData*)header->getSegmentObj(ElfIdMap::elf_to_id(IST_SEG_FN_DATA), IST_SEG_CREATE);

	char tmpBuf[50];
	int len=0;
	char dupIssuerData[128];


	//Field 1: Network Terminal Id
	int termidFound=0;
	memset(tmpBuf,0x00,sizeof(tmpBuf));
	memset(dupIssuerData,0x00,sizeof(dupIssuerData));
	memcpy(dupIssuerData,header->msg.issuer_data,sizeof(dupIssuerData)); //R032444

	if(strlen(dupIssuerData))
	{
		char *p; 
		int i;
		for(i=0, p=strtok(dupIssuerData, "|"); i<13; i++)
		{
			if(p==NULL)
				break;
			if(p[0] && i==12)
			{
				//strcpy(tmpBuf,p);
				istsafe_strcpy(tmpBuf, sizeof(tmpBuf), p);
				fnData->setNetworkTerminalId(tmpBuf);
				OTraceDebug("D-SHC-156075.1: FN_DATA_SEGMENT.network_terminal_id plugged-in [%s]\n",tmpBuf);
				termidFound=1;
			}
			p+=strlen(p)+1;
			if (*p == '|')
				*p = '\0';
			else
				p=strtok(p, "|");
		}
	}
	if(!termidFound && strlen(header->msg.termid))
	{
		istsafe_strcpy(tmpBuf, sizeof(tmpBuf), header->msg.termid);
		fnData->setNetworkTerminalId(tmpBuf);
		OTraceDebug("D-SHC-156075.2: FN_DATA_SEGMENT.network_terminal_id plugged-in [%s]\n",tmpBuf);
	}

}
//<<< R028714

//	>>>	R020938
int ShcmsgFMHelper::sendTxnReq(ShcmsgHeader *header, int route)
{
	int ready_to_RM = 0;
	/**	ITM-1560
	//	>>>	R023105
	char institutionId[MAX_TXN_DESTINATION_LEN+1];
	char userBinId[MAX_TXN_DESTINATION_LEN+1];
	char LMTxnBin[MAX_TXN_DESTINATION_LEN+1];
	//	<<<	R023105
	**/
	//struct FM_seg_data fmData;
	IstSegPdtBase *fmData; //R027876
	int segId; //R028777
	char tmpStr[100]; //R028777
	int saved_shcerr = header->shcerr;	//	---	ITM-1560

	struct RoutingInfo routingInfo = {0};
	int tmpFlag = 0;
	int routingInfoLen=sizeof(struct RoutingInfo);


	setRuleParam(); //R029951

	//Currently this check is only for FM
	if( ((header->issBinValid() && isFMenabled(header->issShcBin->binPkg->bin.institutionid)) ||
		 (header->acqBinValid() && isFMenabled(header->acqShcBin->binPkg->bin.institutionid))) ||
		 	isLMEnabled() )	//	---	R023968
	{
		if((route == TO_FM) && ((fmInstKeys == NULL) || (fmRuleKeyPtr == NULL)))
		{
			OTraceError("E-SHC-156007:fm-inst-stats rule not initialised properly\n");
			return (-1);
		}

		if(fmOut_mbId <= 0)
		{
			if((fmOut_mbId= mb_locateoutbound("FMformatter")) <= 0)
			{
				OTraceError("E-SHC-156008:No FMformatter mailbox available\n");
				return -1;
			}
		}
	}
	//Common conditions to be checked first
	if( (shcIsRequest(header) && (shcIsCustomerRequest(header) || shcIsReversal(header)))
	&& (header->repeatFlag != 1) && !(header->shcerr & SH_IGNORE)
		&& !(header->msg.shc_devcap & SH_DEVCAP_SHC_EVENT) )
	{
		switch(route)
		{
			case TO_FM:
						if (header->msg.device_cap & SH_DEVCAP_FROM_REPLAY)
							return 0;

						segId	= ElfIdMap::elf_to_id(IST_SEG_FM); //R028777
						//send 100/101/200/201/420/421 to LM
						if(	!(header->msg.auth_devcap & SH_DEVCAP_AUTH_FM) &&
							!(header->shcerr & SH_SENDAPPLBIN) &&	//	---	R023105

							//	>>>	R021677
							//	---	R022100
							(((header->issShcBin) && (header->issBinValid()) &&
							isFMenabled(header->issShcBin->binPkg->bin.institutionid)) ||
							//	---	R022100
							((header->acqShcBin) && (header->acqBinValid()) &&
							isFMenabled(header->acqShcBin->binPkg->bin.institutionid))) )

							//	<<<	R021677
						{
							// R027876 >>>
							fmData = (IstSegPdtBase *)header->getSegmentObj(segId,1);
							if (!fmData)
							{
								OTraceError("E-SHC-156009:Cannot create FM SEGMENT\n");
								return -1;
							}
							fmData->setProductName((char*)"FM");
							// <<< R027876

							ready_to_RM = 1;

							memset(tmpStr,0x00,sizeof(tmpStr));
							sprintf(tmpStr,"%d",header->msg.flipped_msgtype);
							header->setSegmentData(tmpStr,strlen(tmpStr),segId,FLIPPED_MSG_TYPE);
							header->msg.flipped_msgtype = header->msg.msgtype;

										//	>>>	R025639
							// Avoid the below commented operations if FM bin is down
							//header->setSegmentData((char *)FMTxnBin, strlen(FMTxnBin)+1,
							//			NETWORK_DATA_REQ_id,APPL_BIN); //R027876
							//header->shcerr = SH_SENDAPPLBIN;
							// R027876, R028104 >>>

							header->getSegmentData((char*)&routingInfo, &routingInfoLen, NETWORK_DATA_REQ_id,ROUTING_INFO);

							// <<< R027876, R028104

							if (routingInfoLen)
							{
								tmpFlag = routingInfo.flag;
								routingInfo.flag = 0;
								header->setSegmentData((char*)&routingInfo, sizeof(routingInfo), 
										NETWORK_DATA_REQ_id,ROUTING_INFO); //R027876, R028104
							}
							if(!FMbin.binPkg)
							if(FMbin.initShcBin(FMTxnBin) < 0)
							  return -1;
							if(shc_isdown(FMbin.binPkg))
							{
								OTraceLog("L-SHC-156075: FM Bin Down! Message Not sent to FM \n");
								header->msg.auth_devcap |=SH_DEVCAP_AUTH_FMTimeout;
								header->msg.auth_devcap |=SH_DEVCAP_AUTH_FM;
								return 0;
							}

							//R028777 & R161675717
                                                        memset(tmpStr,0x00,sizeof(tmpStr));
                                                        sprintf(tmpStr,"%ld",header->time_out);
                                                        header->setSegmentData(tmpStr,strlen(tmpStr),segId,TXNOUT_TIME);
                                                        if (shcEnableSubssecondTimeout)
                                                        {
                                                                header->time_in = (long)shc_current_time*1000L+shc_current_millisecond;
                                                                header->time_out = header->time_in + (long)(1000*fm_timeout);
                                                        }
                                                        else
                                                        {
                                                                header->time_in = (long)shc_current_time;
                                                                header->time_out = header->time_in + (long)(fm_timeout);
                                                        }
                                                        //R028777 & R161675717

							header->setSegmentData((char *)FMTxnBin, strlen(FMTxnBin)+1,
									NETWORK_DATA_REQ_id,APPL_BIN); //R027876
							header->shcerr = SH_SENDAPPLBIN;	
							header->msg.msgtype = SHC_FM_REQ;
							header->msg.auth_devcap |= SH_DEVCAP_AUTH_FM;
							//	<<<	R025639

							createFnDataSegment(header); //R028714
						}
						break;

			case TO_LM:
						segId	= ElfIdMap::elf_to_id(IST_SEG_LM); //R028777
						//send 100/101/200/201/220/221/420/421 to LM
						if(	!(header->msg.auth_devcap & SH_DEVCAP_AUTH_LM) &&
							!(header->shcerr & SH_SENDAPPLBIN) && (isLMEnabled()||isLMTrial()) && //enableLM &&	//	---	R023105,R023871
							(shcGetProcessCode(header->msg.pcode) != SH_ISO_BALANCE) )
						{
							if(shcIsAllAdvice(header) || shcIsReversal(header))
							{
								int saved_msgtype = header->msg.msgtype;
								int saved_flipped_msgtype = header->msg.flipped_msgtype;
								int saved_applMailboxId = header->applMailboxId;        //      ---     ITM-1567
								long saved_auth_devcap = header->msg.auth_devcap;

								header->msg.msgtype = SHC_LM_REVREQ;//reversal msgtype to be confirmed later
								header->msg.flipped_msgtype = saved_msgtype;//we need to store this 210/110 etc here

								header->msg.auth_devcap |= SH_DEVCAP_AUTH_LMForcePost;
								header->msg.auth_devcap &= ~SH_DEVCAP_AUTH_LMLateResp;

								//	>>>	ITM-1560,ITM-1567
								header->setSegmentData((char *)LMTxnBin, strlen(LMTxnBin)+1,
										ElfIdMap::elf_to_id(IST_SEG_NETWORK_DATA_REQ),APPL_BIN); //R027876

								header->shcerr = SH_SENDAPPLBIN;
								if(fmOut_mbId <= 0)
							    {
								   if((fmOut_mbId= mb_locateoutbound("FMformatter")) <= 0)
								   {
										   OTraceError("E-SHC-156065:No FMformatter mailbox available\n");
										   return -1;
								   }
							    }
								header->applMailboxId = fmOut_mbId;
								OTraceLog("L-SHC-156062:Reversal (Force post(update)) for [%d] sent to shc_route\n", saved_msgtype);
								thisShcApp->shcmsgHelperObj->shc_route(header);
								thisShcApp->shcHelperObj->flush_mb_cache(); 

								// R027876, R028104 >>>
								header->getSegmentData((char*)&routingInfo, &routingInfoLen, NETWORK_DATA_REQ_id,ROUTING_INFO);
								// <<< R027876, R028104

								if (routingInfoLen)
								{
									tmpFlag = routingInfo.flag;
									routingInfo.flag = 0;
									header->setSegmentData((char*)&routingInfo, sizeof(routingInfo), 
												NETWORK_DATA_REQ_id,ROUTING_INFO); //R027876, R028104
								}
								//	<<<	ITM-1560,ITM-1567
								/**	ITM-1560
								int totallen = header->truelength();

								sendCmdResp((char *)&header->msg, totallen);
								OTraceLog("L-SHC-156047:Force post(update)for [%d]sent to FMformatter[%d]\n",saved_msgtype, fmOut_mbId);
								**/
								header->msg.msgtype = saved_msgtype;
								header->msg.flipped_msgtype = saved_flipped_msgtype;
								header->msg.auth_devcap = saved_auth_devcap;
								header->msg.auth_devcap |= SH_DEVCAP_AUTH_LM;
								header->shcerr = saved_shcerr;	//	---	ITM-1560
								header->applMailboxId = saved_applMailboxId;    //      ---     ITM-1567

								return (0);//continue with normal message processing
							}
							//	>>>	ITM-1567,R023871
							if(!LMbin.binPkg)
							if(LMbin.initShcBin(LMTxnBin) < 0)
							  return -1;
							if(shc_isdown(LMbin.binPkg))
							{
								OTraceLog("L-SHC-156068: LM Bin Down! Message Not sent to LM \n");
								header->msg.auth_devcap |=SH_DEVCAP_AUTH_LMTimeout;
								header->msg.auth_devcap |=SH_DEVCAP_AUTH_LM;
								header->shcerr &= ~SH_SENDAPPLBIN;
								return 0;
							}
							header->msg.auth_devcap |= SH_DEVCAP_AUTH_LM;
							if(isLMTrial())
							{
								OTraceLog("L-SHC-156069:LM is in TRIAL MODE,Sending txn parallelly to Issuer \n");
								shcmsgFMHelperObj->enqueueInternalMsg((ShcmsgFMHeader *)header);
							}
							//	<<<	ITM-1567,R023871
							// R027876 >>>
							fmData = (IstSegPdtBase *)header->getSegmentObj(segId,1);
							if(!fmData)
							{
								OTraceError("E-SHC-156010:Cannot create LM SEGMENT\n");
								return -1;
							}
							// <<< R027876
							ready_to_RM = 1;
							//R02877
							memset(tmpStr,0x00,sizeof(tmpStr));
							sprintf(tmpStr,"%ld",header->time_out);
							header->setSegmentData(tmpStr,strlen(tmpStr),segId,TXNOUT_TIME);
							if (shcEnableSubssecondTimeout)
							{
								header->time_in = (long)shc_current_time*1000L + shc_current_millisecond;
								header->time_out = (long)header->time_in + 1000*(long)lm_timeout;
							}
							else
							{
								header->time_in = (long)shc_current_time;
								header->time_out = (long)header->time_in + (long)lm_timeout;
							}

							//R028777
							memset(tmpStr,0x00,sizeof(tmpStr));
							sprintf(tmpStr,"%d",header->msg.flipped_msgtype);
							header->setSegmentData(tmpStr,strlen(tmpStr),segId,FLIPPED_MSG_TYPE);
							header->msg.flipped_msgtype = header->msg.msgtype;
							header->msg.msgtype = SHC_LM_REQ;


						}
						break;

			default:
						OTraceWarning("W-SHC-156048:Invalid route in sendTxnReq\n");



		}

	}

//Add additional information as a segment to shcmsg for retrieval after FM response
	if(ready_to_RM)
	{
		//	>>>	R023871
		if(isLMTrial() && route==TO_LM)
		{
			OTraceLog("L-SHC-156070: LM is in TRIAL MODE,No LM event created \n");
		}
		else
		{
			int eventId; //R027876
			if(header->reqMsg)
			{
				if (header->time_out < 10000000000)
				{
					eventId = tm_enqueue(shcmid, (header->time_out+10), TM_NOTIFY_ONCE,
						FM_ADD_INFO_EVENT_KEY, (char *)header->reqMsg, sizeof(struct shcmsg));
				}
				else
				{
					eventId = tm_enqueue(shcmid, (header->time_out/1000+10), TM_NOTIFY_ONCE,
						FM_ADD_INFO_EVENT_KEY, (char *)header->reqMsg, sizeof(struct shcmsg));
				}
			}
			else
			{
				eventId = -1;
			}
			//R028777
			memset(tmpStr,0x00,sizeof(tmpStr));
			sprintf(tmpStr,"%d",eventId);
			header->setSegmentData(tmpStr,strlen(tmpStr),segId,REQ_EVENT_ID);

				if(header->origMsg)
				{
					if (header->time_out < 10000000000)
					{
						eventId = tm_enqueue(shcmid, (header->time_out+10), TM_NOTIFY_ONCE,
							FM_ADD_INFO_EVENT_KEY, (char *)header->origMsg, sizeof(struct shcmsg));
					}
					else
					{
						eventId = tm_enqueue(shcmid, (header->time_out/1000+10), TM_NOTIFY_ONCE,
							FM_ADD_INFO_EVENT_KEY, (char *)header->origMsg, sizeof(struct shcmsg));
					}
				}
			else
			{
				eventId = -1;
			}
			//R028777
			memset(tmpStr,0x00,sizeof(tmpStr));
			sprintf(tmpStr,"%d",eventId);
			header->setSegmentData(tmpStr,strlen(tmpStr),segId,ORIG_EVENT_ID);
		}
		//	<<<	R023871

		// R027876 >>>
		memset(tmpStr,0x00,sizeof(tmpStr));
		sprintf(tmpStr,"%d", header->logFlag);
		header->setSegmentData(tmpStr,strlen(tmpStr),segId,LOG_FLAG); //R028777

		memset(tmpStr,0x00,sizeof(tmpStr));
		sprintf(tmpStr,"%d", header->repeatFlag);
		header->setSegmentData(tmpStr,strlen(tmpStr),segId,REPEAT_FLAG); //R028777

		memset(tmpStr,0x00,sizeof(tmpStr));
		//sprintf(tmpStr,"%d", header->shcerr);
		sprintf(tmpStr,"%d", saved_shcerr);
		header->setSegmentData(tmpStr,strlen(tmpStr),segId,SHCERR); //R028777

		memset(tmpStr,0x00,sizeof(tmpStr));
		sprintf(tmpStr,"%ld", header->time_in);
		header->setSegmentData(tmpStr,strlen(tmpStr),segId,TXNIN_TIME); //R028777
		// <<< R027876

                if (routingInfoLen)
                {
                        routingInfo.flag = tmpFlag;
                        header->setSegmentData((char*)&routingInfo, sizeof(routingInfo),segId,ROUTING_INFO); //R027876, R028104
                }

		if(route == TO_FM)
		{
//			shc_segAppendNoOpt(&header->msg, (char *)"FM_SEG_DATA", (char *)&fmData, sizeof(fmData));
//			OTraceDebug("D-SHC-156009: FM_SEG_DATA segment has been added \n");
		}
		else if(route == TO_LM)
		{
//			shc_segAppendNoOpt(&header->msg, (char *)"LM_SEG_DATA", (char *)&fmData, sizeof(fmData));
//			OTraceDebug("D-SHC-156049: LM_SEG_DATA segment has been added \n");

			//	>>>	R021958

			ShcTimeStamp_seg tmstpReq;
			memset(&tmstpReq, 0, sizeof(struct ShcTimeStamp_seg));

			struct timeb tmpTime;
			ftime(&tmpTime);
			struct tm *tmReq;
			tmReq = localtime ( &tmpTime.time);

			char tme[10], dtme[20];
			sprintf(tme, "%02d%02d%02d", tmReq->tm_hour, tmReq->tm_min, tmReq->tm_sec);
			sprintf(dtme, "%02d:%02d:%02d:%02d", tmReq->tm_hour, tmReq->tm_min, tmReq->tm_sec, tmpTime.millitm); // --- R023376

			tmstpReq.sendToLM_tme = atoi(tme);
			tmstpReq.sendToLM_ms = tmpTime.millitm;
			OTraceLog("L-SHC-156055: Time in HH:MM:SS:ss when Sending Txn to LM: %s \n",dtme);	//	---	R023394

			header->setSegmentData((char*)&tmstpReq,sizeof(tmstpReq),segId,TIMESTAMP); //R028777
			OTraceDebug("D-SHC-156057: TIMESTAMP subelement has been added when sending txn to LM\n");

			HaPtmCctHelper::addHandler( "system.dcs.shc" ) ;

			/**	ITM-1560
			//	>>>	R023105
			if( cf_locate("LM.TxnInstid", institutionId) <= 0 )
				OTraceWarning("W-SHC-156058: Unable to locate the parameter 'LM.TxnInstid'\n");
			if( cf_locate("LM.TxnUserbinid", userBinId) <= 0 )
				OTraceWarning("W-SHC-156059: Unable to locate the parameter 'LM.TxnUserbinid'\n");
			if (shc_externalBin2InternalBin(LMTxnBin, institutionId, userBinId) >= 0)
				OTraceDebug("D-SHC-156060:Internal ID for LM Bin:%s\n", LMTxnBin);
			else
				OTraceWarning("W-SHC-156061:Internal ID for LM Bin not found\n");
			**/

			header->setSegmentData((char *)LMTxnBin, strlen(LMTxnBin)+1,
					ElfIdMap::elf_to_id(IST_SEG_NETWORK_DATA_REQ),APPL_BIN); //R027876

			//	<<<	R023105

			//	<<<	R021958
		}
		else
			OTraceError("E-SHC-156050: Invalid route option\n");

		//	>>>	R023871
        //if(isLMTrial() && route == TO_LM)
		//	header->shcerr = SH_SENDAPPLBIN;
		//else
		//	header->shcerr = SH_SENDAPPLBIN|SH_SETTIMER;	//	---	R023105
		//	<<<	R023871
		if ( ! (isLMTrial() && (route == TO_LM)) )
			header->shcerr |= SH_SETTIMER;

		header->applMailboxId = fmOut_mbId;

	        header->logFlag = 0;
        	header->setSkipFlag(TXN_PROC_SKIP_DOWORK); //skip doWork for now. we can resume if FM approves this Request

	    OTraceInfo("I-SHC-156010:Message will be sent to %s for auth\n",
	    	(route == TO_LM ? "LM" : (route == TO_FM ? "FM" : "None")));
	}

	return 0;
}
//	<<<	R020938

int ShcmsgFMHelper::sendCmdResp(char *msg, int len)
{

	if( fmOut_mbId <= 0 )
	{
		if((fmOut_mbId= mb_locateoutbound("FMformatter")) <= 0)
		{
			OTraceError("E-SHC-156011:Unable to locate outbound 'FMformatter' mailbox\n");
			return (-1);
		}
	}

	if( mb_write(fmOut_mbId, shcmid, msg, len) < 0 )
	{
		OTraceError("E-SHC-156012:Unable to write to a mailbox id: %d\n", fmOut_mbId);
		return (-1);
	}
	OTraceDebug("D-SHC-156013:Message sent to mailbox [%d]\n", fmOut_mbId);

	return 0;
}

int ShcmsgFMHelper::addHotRange(struct hotrange *newRange)
{
	static int rangefd = -1;

	if( rangefd <  0 )
	{
		if((rangefd = dbm_open("hotrange_1", getpid()))< 0)
		{
			OTraceError("E-SHC-156014:Unable to open hotrange_1 index, errno = %d\n", dbm_errno);
			return (-1);
		}
	}

	struct hotrange range;
	if ( rangefd >= 0)
	dbm_rewind(rangefd);
	strcpy(range.pan_low, newRange->pan_low);
	strcpy(range.pan_hi, newRange->pan_hi);
	if( (dbm_read(rangefd, (char *)&range, DBM_REQUAL | DBM_RLOCK)) < 0 )
	{
		if(dbm_insert(rangefd,(char*)newRange, 0) <0)
		{
			OTraceError("E-SHC-156015:Unable to insert record(%d) for the range :%s-%s\n",
							dbm_errno, newRange->pan_low, newRange->pan_hi);
			return (-1);
		}
		OTraceInfo("I-SHC-156016:New Hot range [%s-%s] inserted\n", newRange->pan_low, newRange->pan_hi);
	}
	else
	OTraceInfo("I-SHC-156016:New Hot range [%s-%s] is already present \n",newRange->pan_low, newRange->pan_hi);
	if ( rangefd >= 0)
	dbm_rewind(rangefd);	//	---	R026365

	return 0;
}

int ShcmsgFMHelper::addHotMerchant(struct shcmerchant *newHotMerchant)
{
	static int merchantfd = -1;

	if( merchantfd <  0 )
	{
		if((merchantfd = dbm_open("shcmerchant_1", getpid()))< 0)
		{
			OTraceError("E-SHC-156017:Unable to open shcmerchant_1 index, errno = %d\n", dbm_errno);
			return (-1);
		}
	}
	if ( merchantfd >= 0)
	dbm_rewind(merchantfd);
	strcpy(shcmerchant.institution, newHotMerchant->institution);
	strcpy(shcmerchant.acceptor_id, newHotMerchant->acceptor_id);
	if( (dbm_read(merchantfd, (char *)&shcmerchant, DBM_REQUAL | DBM_RLOCK)) < 0 )
	{
		if(dbm_insert(merchantfd,(char*)newHotMerchant, 0) <0)
		{
			OTraceError("E-SHC-156018:Unable to insert record(%d) for the acceptor_id :%s\n",
						dbm_errno, newHotMerchant->acceptor_id);
			return (-1);
		}
		OTraceInfo("D-SHC-156019: New Hot Merchant inserted: acceptor_id :%s, terminal_id: %s\n",
					newHotMerchant->acceptor_id, newHotMerchant->terminal_id);
	}
	else
	OTraceInfo("D-SHC-156019: New Hot Merchant is already present: acceptor_id :%s, terminal_id: %s\n",
				newHotMerchant->acceptor_id, newHotMerchant->terminal_id);
	if ( merchantfd >= 0)
	dbm_rewind(merchantfd);	//	---	R026365
	return 0;
}

/***** Commenting the below as the code as the shccard table is no more in usage ***/
//
//int ShcmsgFMHelper::addHotCard(struct shccard *newCard, int blkflg 	)//	---	R025639
//{
//	static int cardfd = -1;
//	struct shccard card;
//
//if( cardfd <  0 )
//	{
//		if((cardfd = dbm_open("shccard_1", getpid()))< 0)
//		{
//			OTraceError("E-SHC-156020:Unable to open shccard_1 index, errno = %d\n", dbm_errno);
//			return (-1);
		
//		}
//	}

	//check for the record in the table
//	dbm_rewind(cardfd);
//	strcpy(card.pan, newCard->pan);
//	shc_normalizepan(card.pan);
//	if( (dbm_read(cardfd, (char *)&card, DBM_REQUAL | DBM_RLOCK)) < 0 )
//	{
//		OTraceDebug("D-SHC-156021:No record for pan [%s], insert new record \n",
//		shcApp->shcHelperObj->shc_maskpan(card.pan));		//	---	R021024
//		dbm_rewind(cardfd); //R027889
//	}
//	else
//	{
		//update the record
		//	>>>	R025639
		/*if( (dbm_updatefd(cardfd, "status = 1, cardalert = 'Y'")) < 0)
		{
			OTraceError("E-SHC-156022:Unable to update record for pan [%s], dbm_errno: %d\n",
					shcApp->shcHelperObj->shc_maskpan(newCard->pan), dbm_errno);		//	---	R021024
			return (-1);

		}*/
//		if(blkflg == FM_HOTBLOCK_CARD)
//		{
			//if( (dbm_updatefd(cardfd, "status = 1, cardalert = 'Y'")) < 0)
			//{
		//	OTraceError("E-SHC-156022:Unable to update record for pan [%s], dbm_errno: %d\n",
		//				shcApp->shcHelperObj->shc_maskpan(newCard->pan), dbm_errno);		//	---	R021024
		//		dbm_rewind(cardfd); //R027889
//				return (-1);

//			}
//		}
		//else if(blkflg == FM_BLOCK_CARD)
		//{
		//	if(card.status == 1)
		//	{
		//		OTraceError("E-SHC-156076:Unable to block the card [%s] since it is marked as hotcard \n",
		//			shcApp->shcHelperObj->shc_maskpan(card.pan));
		//		dbm_rewind(cardfd); //R027889
		//		return (-3);
		//	}
//		if( (dbm_updatefd(cardfd, "status = 2, cardalert = 'Y'")) < 0)
//			{
//				OTraceError("E-SHC-156077:Unable to update record for pan [%s], dbm_errno: %d\n",
//					shcApp->shcHelperObj->shc_maskpan(newCard->pan), dbm_errno);		//	---	R021024
				//dbm_rewind(cardfd); //R027889
				//return (-1);
			//}
	//	}
			//	<<<	R025639
	//	OTraceDebug("D-SHC-156023:Updated record for pan [%s]\n",
	//	shcApp->shcHelperObj->shc_maskpan(card.pan));		//	---	R021024
	//	dbm_rewind(cardfd); //R027889
	//	return 0;
	//}

//	if(dbm_insert(cardfd,(char*)newCard, 0) <0)
//	{
//		OTraceError("E-SHC-156024:Unable to insert record(%d) for pan :%s\n", dbm_errno,
//		shcApp->shcHelperObj->shc_maskpan(newCard->pan));		//	---	R021024
		//dbm_rewind(cardfd); //R027889
//		return (-1);
//	}

//	OTraceInfo("I-SHC-156025:Record inserted/updated for hot card [%s]\n",
//				shcApp->shcHelperObj->shc_maskpan(newCard->pan));
//	dbm_rewind(cardfd);	//	---	R026365
//	return 0;
//}
//	>>>	R025639
int ShcmsgFMHelper::checkHotMerchant(ShcmsgHeader *header)
{
	int NoofDeletedRecords = 0;
	/*Now check if the merchant is hot */
	if(merchantfd < 0)
	{
		if((merchantfd = dbm_open("shcmerchant_1", dbmid)) < 0)
		{
			OTraceError("E-SHC-156026:Unable to open shcmerchant_1 index, errno = %d\n", dbm_errno);
			return(-1);
		}
	}

	memset(&shcmerchant, 0 ,sizeof(shcmerchant));

	//strcpy(shcmerchant.institution, header->msg.txnSrc);
	//strcpy(shcmerchant.acceptor_id, header->msg.termloc);
	istsafe_strcpy(shcmerchant.institution, sizeof(shcmerchant.institution), header->msg.txnSrc);
	istsafe_strcpy(shcmerchant.acceptor_id, sizeof(shcmerchant.acceptor_id), header->msg.termloc);


	if( (dbm_read(merchantfd, (char *)&shcmerchant, DBM_RFIRST | DBM_RLOCK )) < 0 )
	{
		OTraceDebug("D-SHC-156030:No record for Merchant [%s],No Need to Block\n",
		shcmerchant.acceptor_id);
		return (-2);
	}


	for(int i = 0;; i++)
	{
		if ( shcmsgFMHelperObj->IsMerchantSuspensionExpired(&shcmerchant) )
		{
			if(ist_dbm_delete(merchantfd, (char *)&shcmerchant, 0) >= 0)
					NoofDeletedRecords++;
			else
			{
				OTraceError("E-SHC-156031:Unable to delete record, errno = %d\n", dbm_errno);
				return (-1);
			}
		}
		else
		{
			if ( header->msg.respcode == 0 )
				shcmsgFMHelperObj->SetRCIfMerchantBlocked(header);
		}

		if( (dbm_read(merchantfd, (char *)&shcmerchant, DBM_RNEXT | DBM_RLOCK )) < 0 )
			break;
	}

	if( NoofDeletedRecords !=0 )

	if(!(dbm_errno == DBME_EOF || dbm_errno == DBME_NOTFOUND))
	{
		header->msg.respcode = SHC_RC_SystemError;
		return(-1);
	}
	if ( merchantfd >= 0)
	dbm_rewind(merchantfd);	//	---	R026365

	if(header->msg.respcode == SHC_RC_InvalidMerchant)
		return (1);
	else
		return (0);

}
//	<<<	R025639


ShcProcessor *ShcmsgFMHelper::enqueueInternalMsg(ShcmsgFMHeader *hd)
{

	ShcmsgHeader * hdr = (ShcmsgHeader *)hd;
	hdr->truelength();

	//R028777 - Calculate truelength() first to avoid miscalculating the segments
	ShcProcessor *newProcessor = shcProcessorRegistration.getTargetObj((char *)(&hd->msg));
	if (!newProcessor)
		return NULL;

	newProcessor->header->flag          = hdr->flag;
	newProcessor->header->shcerr        = hdr->shcerr;
	newProcessor->header->time_in       = hdr->time_in;
	newProcessor->header->time_out      = hdr->time_out;
	newProcessor->header->eventId       = hdr->eventId;
	newProcessor->header->applMailboxId = hdr->applMailboxId;

	newProcessor->header->repeatFlag    = hdr->repeatFlag;
	newProcessor->header->setSkipFlag(hdr->procFlag);
	newProcessor->header->logFlag       = hdr->logFlag;
	//    newProcessor->header->setSenderId   = hdr->senderId;
	((ShcmsgHeader *)(newProcessor->header))->allocateAndCopyOrigMsg(hdr->origMsg);
	((ShcmsgHeader *)(newProcessor->header))->allocateAndCopyReqMsg(hdr->reqMsg);

	OTraceDebug("D-SHC-156029: ShcmsgFMHelper::enqueueInternalMsg[%p]\n", newProcessor );
	newProcessor->header->flag |= MSG_CREATED_INTERNAL;
	shcApp->msgQueue.join(newProcessor);
	return newProcessor;

}


int ShcmsgFMHelper::update_record(int action, char * fmblockInfo)
{

    int key_count = 0,i = 0, found = 0, nkeys = 0;
	char *ptr;
	//	>>>	R025639
	char instbuf[256];
	memset(&instbuf, 0, sizeof(instbuf));
	//strcpy(instbuf,fmblockInfo);
	istsafe_strcpy(instbuf, sizeof(instbuf), fmblockInfo);
	char *p = NULL;
	//	<<<	R025639
	char inst_data[MAX_TXN_DESTINATION_LEN + 1];

	setRuleParam(); //R029951
	if((fmInstKeys == NULL) || (fmRuleKeyPtr == NULL))
	{
		OTraceError("E-SHC-156030:fm-inst-stats rule not initialised properly\n");
		return (-1);
	}


	int keysize = fmRuleKeyPtr->keysize;
	char *keyPtr = fmInstKeys;
	key_count = fmRuleKeyPtr->keysused;
	nkeys = fmRuleKeyPtr->nkeys;
	//	>>>	R025639
	p = (char *)calloc(nkeys, keysize);
	if ( p == NULL)
	{
		 OTraceDebug("D-SHC-156118: Unable to alocate memory\n");
		 return (-1);
	}
	//	<<<	R025639

	switch (action)
	{
	case FM_INST_ADD: //Add inst list

	//	>>>	R025639
	case FM_INST_ADD_FROM_BROADCAST:
		ptr = strtok(instbuf, ":");
	//	<<<	R025639
		OTraceDebug("D-SHC-156031:Actual Key count [%d] \n", key_count);
		while(ptr)
		{
			if(key_count >= fmRuleKeyPtr->nkeys)
			{
				OTraceDebug("D-SHC-156032:Key count for rule [%s] exceeded\n", fmRuleKeyPtr->name);
				return -1;
			}
			memset(&inst_data, 0, sizeof(inst_data));

			//strcpy(inst_data, ptr);
			istsafe_strcpy(inst_data, sizeof(inst_data), ptr);

			for(i=0; i < key_count; i++)
			{
				if(strcmp(keyPtr, ptr) == 0)
			        {
					found = 1;
					OTraceDebug("D-SHC-156033:Key already present \n");
					break;
				}
				keyPtr += (MAX_TXN_DESTINATION_LEN +1);
			}

			if(!found)
			{
				memcpy(fmInstKeys + (key_count * keysize), &inst_data, sizeof(inst_data));
				key_count++;
				OTraceDebug("D-SHC-156034:key [%s] added\n", ptr);
			}

			ptr = strtok(NULL, ":");
			found = 0;

		}

		fmRuleKeyPtr->keysused = key_count;
		OTraceDebug("D-SHC-156035:Now [%d] keys available\n", fmRuleKeyPtr->keysused);
		break;
	//	>>>	R025639
	//Removed case FM_INST_DELETE
	//	<<<	R025639
	case FM_INST_REPLACE: //Replace list
	case FM_INST_REPLACE_FROM_BROADCAST://	--	R025639
			key_count = 0;
			//	>>>	R025639
			ptr = strtok(instbuf, ":");
			memset(p, 0, (nkeys * keysize) );
			//	<<<	R025639
			while(ptr)
			{

				if(key_count >= fmRuleKeyPtr->nkeys)
				{
					OTraceDebug("D-SHC-156039:Key count for rule [%s] exceeded\n", fmRuleKeyPtr->name);
					return -1;
				}
				memset(&inst_data, 0, sizeof(inst_data));
				//strcpy(inst_data, ptr);
				istsafe_strcpy(inst_data,sizeof(inst_data), ptr);
				//	>>>	R025639
				memcpy(p + (key_count * keysize), &inst_data, sizeof(inst_data));
				//	<<<	R025639
				key_count++;
				OTraceDebug("D-SHC-156040:ptr value [%s] \n", ptr);
				ptr = strtok(NULL, ":");
			}
				//	>>>	R025639

			if ( rm_lockAppid(fmAppid) < 0 )
			{
				OTraceWarning("W-SHC-156078: rm.fmAppid[%d] locked by other, grab lock after 1 sec\n", fmAppid);
				sleep(1);
				rm_unlockAppid(fmAppid);
				rm_lockAppid(fmAppid);
			}
			else
			{
				OTraceDebug("D-SHC-156079: Locked fmAppid[%d] successfully,\n", fmAppid ); //---R028747
			}
			memcpy(fmInstKeys , p, (nkeys * keysize));
			rm_unlockAppid(fmAppid);
			OTraceDebug("D-SHC-156080: Unlocked rm.fmAppid[%d]\n", fmAppid);
				//	<<<	R025639
			fmRuleKeyPtr->keysused = key_count;
			OTraceDebug("D-SHC-156041:[%d] keys have been replaced\n", fmRuleKeyPtr->keysused);
		break;

		//	>>>	R025639
		case FM_INST_ALL:	//	All Institutions are participating in FM
		case FM_INST_ALL_FROM_BROADCAST:

			OTraceDebug("I-SHC-156081:Actual count = [%d]\n", key_count);
			if ( rm_lockAppid(fmAppid) < 0 )
			{
				OTraceWarning("W-SHC-156082: rm.fmAppid[%d] locked by other, grab lock after 1 sec\n", fmAppid);
				sleep(1);
				rm_unlockAppid(fmAppid);
				rm_lockAppid(fmAppid);
			}
			else
			{
				OTraceDebug("D-SHC-156083: Locked fmAppid[%d] successfully,\n", fmAppid); //---R028747
			}
			strcpy(fmInstKeys,"all");
			fmRuleKeyPtr->keysused = key_count = 1;

			rm_unlockAppid(fmAppid);
			OTraceDebug("D-SHC-156119: Unlocked rm.fmAppid[%d]\n", fmAppid);

			OTraceDebug("D-SHC-156084:All Institutions are participating in FM");
			break;


		case FM_INST_NONE:	//	None of the Institutions are participating in FM
		case FM_INST_NONE_FROM_BROADCAST:

			if ( rm_lockAppid(fmAppid) < 0 )
			{
				OTraceWarning("W-SHC-156085: rm.fmAppid[%d] locked by other, grab lock after 1 sec\n", fmAppid);
				sleep(1);
				rm_unlockAppid(fmAppid);
				rm_lockAppid(fmAppid);
			}
			else
			{
				OTraceDebug("D-SHC-156086: Locked fmAppid[%d] successfully,\n", fmAppid); //---R028747
			}
			strcpy(fmInstKeys,"none");
			fmRuleKeyPtr->keysused = key_count = 1;

			rm_unlockAppid(fmAppid);
			OTraceDebug("D-SHC-156120: Unlocked rm.fmAppid[%d]\n", fmAppid);

			OTraceDebug("D-SHC-156087:None of the Institutions are participating in FM");
			break;
		//	<<<	R025639

	default:
		;

	}

	return(0);
}

int ShcmsgFMHelper::init_records(int send_request /* = 0 */)
{
	/*
	 *	Now I can actualy initialise my table
	 */
	//	<<<	R025639

	//R029951 >>>
	if (shc_initsys() < 0)
	{
		OTraceFatal("F-SHC-156088.0: INITSYS Failed : Error: %d\n", errno);
		return(1);
	}
	//R029951 <<<

		HaPtmCctHelper::addHandler( "system.dcs.shc" ) ;

		if( cf_locate("LM.TxnInstid", institutionId) <= 0 )
			OTraceWarning("W-SHC-156088: Unable to locate the parameter 'LM.TxnInstid'\n");
		if( cf_locate("LM.TxnUserbinid", userBinId) <= 0 )
			OTraceWarning("W-SHC-156089: Unable to locate the parameter 'LM.TxnUserbinid'\n");
		if( cf_locate("FM.TxnInstid", institutionId) <= 0 )
			OTraceWarning("W-SHC-156090: Unable to locate the parameter'FM.TxnInstid'\n");
		if( cf_locate("FM.TxnUserbinid", userBinId) <= 0 )
			OTraceWarning("W-SHC-156091: Unable to locate the parameter 'FMTxnBin'\n");
		if (shc_externalBin2InternalBin(FMTxnBin, institutionId, userBinId) >= 0)
			OTraceDebug("D-SHC-156092:Internal ID for FM Bin:%s\n", FMTxnBin);
		else
			OTraceWarning("W-SHC-156093:Internal ID for FM Bin not found\n");
		if (shc_externalBin2InternalBin(LMTxnBin, institutionId, userBinId) >= 0)
			OTraceDebug("D-SHC-156094:Internal ID for LM Bin:%s\n", LMTxnBin);
		else
			OTraceWarning("W-SHC-156095:Internal ID for LM Bin not found\n");

	//	<<<	R025639

	if (send_request) //R029951
	{
		setRuleParam(); 
		if((fmInstKeys == NULL) || (fmRuleKeyPtr == NULL))
		{
			OTraceError("E-SHC-156042:fm-inst-stats rule not initialised properly\n");
			return (-1);
		}

		if( fmOut_mbId <= 0 )
		{
			if((fmOut_mbId = mb_locateoutbound("FMformatter")) <= 0)
			{
				OTraceError("E-SHC-156051:Unable to locate outbound 'FMformatter' mailbox\n");
				return (-1);
			}
		}

			int len = mb_write(fmOut_mbId, shcmid, (char*)"init_msg", 8); //R029287
			if(len < 0)
			{
				OTraceError("E-SHC-156043:mb_write failed to FMformatter\n");
				return(-1);
			}
			else
				OTraceLog("D-SHC-156044:mb_write sucessful to FMformatter[%d]len[%d]\n",fmOut_mbId, len);
	}
	else
	{
		//R029951 >>>
		loadRuleParam();

		//Check if this is an initial load of this rule table.
		if(rm_attachedcurrent(fmAppid)==0)
		{
			//This is initial loading....no more processing...
			//set to READY state, unset loading and just return.
			if (rm_setstate( fmAppid, RULES_VER_ATTACHED, RM_STATE_READY ) < 0)
				log_msg(FATAL, TO_CC, "F-SHC-156044.1: Unable to set READY state after rule[%s] is loaded\n",
					FM_MESSAGE_NAME	);

			//Unset loading
			rm_unsetloading(fmAppid);
			return(0);
		}

		//Attach to the current version of the table
		if ( rm_attach( fmAppid, RULES_VER_CURRENT ) != 0)
		{
			OTraceError("E-SHC-156044.2: Unable to attach to CURRENT version \n");
			return(-1);
		}
		fmRuleKeyPtr = rm_getapphead(fmAppid);
		int localMemSize = fmRuleKeyPtr->keysize*fmRuleKeyPtr->keysused;
		char *localMem = (char*)calloc(fmRuleKeyPtr->keysused,fmRuleKeyPtr->keysize);
		struct rules_keytab oldAppHead = { 0 };
		if (!localMem )
		{
			OTraceError("E-SHC-156044.2: can't allocate %d bytes\n",localMemSize);
			return(-1);
		}

		//Lock the rule table
		if ( rm_lockAppid(fmAppid) < 0 )
		{
			OTraceWarning("W-SHC-156044.3: rm.appid[%d] locked by other, grab lock after 1 sec\n", fmAppid);
			sleep(1);
			rm_unlockAppid(fmAppid);
			rm_lockAppid(fmAppid);
		}
		else
			OTraceDebug("D-SHC-156044.4: Locked appid[%d] successfully\n",fmAppid);

		//Copy existing rule table into memory buffer
		memcpy(localMem,rm_getappkey(fmAppid),localMemSize);
		memcpy(&oldAppHead,fmRuleKeyPtr,sizeof(oldAppHead));

		//Attach to the loading version of rule table
		if ( rm_attach( fmAppid, RULES_VER_LOADING ) != 0)
		{
			OTraceError("E-SHC-156044.5: Unable to attach to LOADING version \n");
			return(-1);
		}
		fmRuleKeyPtr = rm_getapphead(fmAppid);
		
		//Transfer data from localMem into loading version of the table
		int oldi;
		char *oldp = localMem;
		char *newp = rm_getappkey(fmAppid);
		for(oldi=0; oldi<oldAppHead.keysused && oldi < fmRuleKeyPtr->nkeys; oldi++,oldp+=oldAppHead.keysize,newp+=fmRuleKeyPtr->keysize)
		{
			memcpy(newp,oldp,oldAppHead.keysize);	
		}
		fmRuleKeyPtr->keysused = oldi;
		if(oldi == fmRuleKeyPtr->nkeys)
			OTraceWarning("W-SHC-156044.5a: Inst list [%d] exceeded the max keys[%d] allowed in Shm\n",oldAppHead.keysused,fmRuleKeyPtr->nkeys);

		//Set the attached version in READY state
		if (rm_setstate( fmAppid, RULES_VER_ATTACHED, RM_STATE_READY ) < 0)
			log_msg(FATAL, TO_CC, "F-SHC-156044.6: Unable to set READY state after rule[%s] is loaded\n",FM_MESSAGE_NAME);


		//Unset loading
		rm_unsetloading(fmAppid);

		//Make loading version the current version
		if ( rm_setcurrent( fmAppid, RULES_VER_ATTACHED ) != 0)
		{
			OTraceError("E-SHC-156044.7: Unable to make the LOADING version as the CURRENT version\n");
			return(-1);
		}

		//Unlock the rule table
		rm_unlockAppid(fmAppid);

		//R029951 <<<
	}
	return(0);
}


//	>>>	R020938
int ShcmsgFMHelper::sendReversal(ShcmsgHeader *header, int route)
{
	/*1.110 need to be sent to LM thou LM wudnot adjusted its totals during earlier 100
	  2.Send all issuer declined reponse to LM as LM had approved earlier
	  3.Send issuer approved response if configured to continue on LM timeout
			since LM might have missed to adjust totals during earlier request*/
	if( shcIsResponse(header) && (route == TO_LM) && (header->msg.auth_devcap & SH_DEVCAP_AUTH_LM) &&
		(header->msg.respcode != SHC_RC_LMDeclined) && (header->msg.respcode != SHC_RC_Declined_On_LMTimeout) &&
		//!(shcIsAdviceRespInclu(header)) &&
		!(header->msg.device_cap & SH_DEVCAP_FROM_REPLAY) &&
		!(header->shcerr & SH_IGNORE) && (header->shouldContinue(TXN_PROC_SKIP_DOWORK)) &&
		(  (!(header->msg.auth_devcap & SH_DEVCAP_AUTH_LMTimeout) && (header->msg.respcode != SHC_RC_Approved))
		|| ( (header->msg.auth_devcap & SH_DEVCAP_AUTH_LMTimeout) && (header->msg.respcode == SHC_RC_Approved))
		)
	  )
	{
		int saved_msgtype = header->msg.msgtype;
		int saved_flipped_msgtype = header->msg.flipped_msgtype;
		long saved_auth_devcap = header->msg.auth_devcap;
		int saved_shcerr = header->shcerr;	//	---	ITM-1560
		//int saved_respcode = header->msg.respcode;	//	---	ITM-1560	---	R023933
		int saved_applMailboxId = header->applMailboxId;        //      ---     ITM-1567

		//	>>>	ITM-1560
		struct RoutingInfo routingInfo = {0};
		int tmpFlag = 0;
		// R027876, R028104 >>>
		int len = sizeof(struct RoutingInfo);
		header->getSegmentData((char*)&routingInfo, &len, NETWORK_DATA_REQ_id,ROUTING_INFO);
		// <<< R027876, R028104

		if (len)
		{
			tmpFlag = routingInfo.flag;
			routingInfo.flag = 0;
			header->setSegmentData((char*)&routingInfo, sizeof(routingInfo), NETWORK_DATA_REQ_id,ROUTING_INFO); //R027876, R028104
		}
		//	<<<	ITM-1560

		header->msg.msgtype = SHC_LM_REVREQ;

		if(header->msg.respcode == SHC_RC_Approved)
			header->msg.flipped_msgtype = saved_msgtype - 10;	//LM needs request mti to be present if approved
		else
			header->msg.flipped_msgtype = saved_msgtype;//we need to store this 210/110 etc here

		header->msg.auth_devcap |= SH_DEVCAP_AUTH_LMForcePost;

		header->msg.auth_devcap &= ~SH_DEVCAP_AUTH_LMLateResp;
		//	>>>	ITM-1560
		header->setSegmentData((char *)LMTxnBin, strlen(LMTxnBin)+1,
				NETWORK_DATA_REQ_id,APPL_BIN); //R027876

		header->shcerr = SH_SENDAPPLBIN;
		if(fmOut_mbId <= 0)
		{
			if((fmOut_mbId= mb_locateoutbound("FMformatter")) <= 0)
			{
				OTraceError("E-SHC-156067:No FMformatter mailbox available\n");
				return -1;
			}
		}
		header->applMailboxId = fmOut_mbId;
		//header->msg.respcode = SHC_RC_Approved;	---	R023933
		OTraceLog("L-SHC-156063:Reversal (Force post(update)) for [%d] sent to shc_route\n", saved_msgtype);
		thisShcApp->shcmsgHelperObj->shc_route(header);
		thisShcApp->shcHelperObj->flush_mb_cache();
		//	<<<	ITM-1560

		/** ITM-1560
		int totallen = header->truelength();

		sendCmdResp((char *)&header->msg, totallen);

		OTraceLog("L-SHC-156052:Force post(update)for [%d]sent to FMformatter[%d]\n",saved_msgtype, fmOut_mbId);
		**/

		header->msg.msgtype = saved_msgtype;
		header->msg.flipped_msgtype = saved_flipped_msgtype;
		header->msg.auth_devcap = saved_auth_devcap;
		header->applMailboxId = saved_applMailboxId;    //      ---     ITM-1567
		//	>>>	ITM-1560
		header->shcerr = saved_shcerr;
		//header->msg.respcode = saved_respcode;	---	R023933
		if (len)
		{
			routingInfo.flag = tmpFlag;
			header->setSegmentData((char*)&routingInfo, sizeof(routingInfo), NETWORK_DATA_REQ_id,ROUTING_INFO); //R027876,R028104
		}

		//	<<<	ITM-1560

	}

	return (0);

}


int ShcmsgFMHelper::sendLateResponse(ShcmsgFMHeader *header, int route)
{

	int saved_msgtype = header->msg.msgtype;
	int saved_shcerr = header->shcerr;	//	---	ITM-1560
	int saved_applMailboxId = header->applMailboxId;	//	---	ITM-1567

	switch(header->FMMsg.msgtype)
	{
		case SHC_LM_RESP:

			//	>>>	R021644

			if(header->FMMsg.respcode == 0)
				header->msg.msgtype = SHC_LM_LATEREQ;
			else
				return (0);
			break;

			//	<<<	R021644

		case SHC_LM_REVRESP:
			header->msg.msgtype = SHC_LM_LATEREQ;
			break;

		case SHC_LM_LATERESP:
			header->msg.msgtype = SHC_LM_REVREQ;
			break;

		default:
			break;
	}



	header->msg.auth_devcap &= ~SH_DEVCAP_AUTH_LMForcePost;
	header->msg.auth_devcap |= SH_DEVCAP_AUTH_LMLateResp;

	//	>>>	ITM-1560,ITM-1567
	header->setSegmentData((char *)LMTxnBin, strlen(LMTxnBin)+1,
			NETWORK_DATA_REQ_id,APPL_BIN); //R027876

	header->shcerr = SH_SENDAPPLBIN;
    if(fmOut_mbId <= 0)
	{
		if((fmOut_mbId= mb_locateoutbound("FMformatter")) <= 0)
		{
			OTraceError("E-SHC-156066:No FMformatter mailbox available\n");
			return -1;
		}
	}
	header->applMailboxId = fmOut_mbId;
	OTraceLog("L-SHC-156064:Reversal (Unsolicited late response) for [%d][%d] sent to shc_route\n", header->msg.msgtype, header->msg.flipped_msgtype);
	thisShcApp->shcmsgHelperObj->shc_route(header);
	thisShcApp->shcHelperObj->flush_mb_cache();
	//	<<<	ITM-1560,ITM-1567
	/** ITM-1560
	int totallen = header->truelength();

	sendCmdResp((char *)&header->msg, totallen);

	OTraceLog("L-SHC-156053:Unsolicited late response for[%d][%d]sent to FMformatter[%d]\n",
				header->msg.msgtype, header->msg.flipped_msgtype, fmOut_mbId);
	**/

	header->msg.msgtype = saved_msgtype;
	header->shcerr = saved_shcerr;	//	---	ITM-1560
	header->applMailboxId = saved_applMailboxId;	//	---	ITM-1567

	return (0);

}
//	<<<	R020938
//	>>>	R025639
/***** Commenting the below as the code as the shccard table is no more in usage ***/
/*
int ShcmsgFMHelper::unblockCard(struct shccard *newCard)
{
	static int cardfd = -1;
	struct shccard card;

	if( cardfd <  0 )
	{
		if((cardfd = dbm_open("shccard_1", getpid()))< 0)
		{
			OTraceError("E-SHC-156096:Unable to open shccard_1 index, errno = %d\n", dbm_errno);
			return (-1);
		}
	}

	//check for the record in the table
	if ( cardfd >= 0)
	dbm_rewind(cardfd);
	strcpy(card.pan, newCard->pan);
	shc_normalizepan(card.pan);
	if( (dbm_read(cardfd, (char *)&card, DBM_REQUAL | DBM_RLOCK)) < 0 )
	{
		OTraceDebug("D-SHC-156097:No record for pan [%s],No Need to Insert a record\n",
		shcApp->shcHelperObj->shc_maskpan(card.pan));
	}
	else
	{
		if(card.status == 1)
		{
			OTraceError("E-SHC-156098:Unable to unblock the card [%s] since it is marked as hotcard \n",
			shcApp->shcHelperObj->shc_maskpan(card.pan));
			if ( cardfd >= 0)
			dbm_rewind(cardfd); //R027889
			return (-4);
		}
		//update the record
		if( (dbm_updatefd(cardfd, "status = 0, cardalert = ''")) < 0)
		{
			OTraceError("E-SHC-156099:Unable to update record for pan [%s], dbm_errno: %d\n",
				shcApp->shcHelperObj->shc_maskpan(newCard->pan), dbm_errno);
			if ( cardfd >= 0)
			dbm_rewind(cardfd); //R027889
			return (-1);
		}
		OTraceDebug("D-SHC-156100:Updated record for pan [%s]\n",
		shcApp->shcHelperObj->shc_maskpan(card.pan));
		if ( cardfd >= 0)
		dbm_rewind(cardfd); //R027889
		return 0;
	}

	OTraceInfo("I-SHC-156101:Record updated for unblock card [%s]\n",
				shcApp->shcHelperObj->shc_maskpan(newCard->pan));
	if ( cardfd >= 0)
	dbm_rewind(cardfd);	//	---	R026365
	return 0;
}
*/

int ShcmsgFMHelper::unblockRange(struct hotrange *newRange)
{
	static int rangefd = -1;
	struct hotrange range;

	if( rangefd <  0 )
	{
		if((rangefd = dbm_open("hotrange_1", getpid()))< 0)
		{
			OTraceError("E-SHC-156102:Unable to open hotrange_1 index, errno = %d\n", dbm_errno);
			return (-1);
		}
	}

	//check for the record in the table
	if ( rangefd >= 0)
	dbm_rewind(rangefd);
	strcpy(range.pan_low, newRange->pan_low);
	strcpy(range.pan_hi, newRange->pan_hi);

	if( (dbm_read(rangefd, (char *)&range, DBM_REQUAL | DBM_RLOCK)) < 0 )
	{
		OTraceDebug("D-SHC-156103:No record for pan_low: [%s] - pan_hi: [%s] ,No Need to UnBlock(delete) a record\n",
		range.pan_low,range.pan_hi);
	}
	else
	{
		if(ist_dbm_delete(rangefd,(char*)newRange, 0) <0)
		{
			OTraceError("E-SHC-156104:Unable to delete record(%d) for the range :%s-%s\n",
						dbm_errno, newRange->pan_low, newRange->pan_hi);
			return (-1);
		}
		OTraceInfo("I-SHC-156105:Hot range [%s-%s] is unblocked(deleted from hotrange table)\n", newRange->pan_low, newRange->pan_hi);
		if ( rangefd >= 0)
		dbm_rewind(rangefd);	//	---	R026365
		return 0;
	}
	return 0;

}

int ShcmsgFMHelper::unblockMerchant(struct shcmerchant *newHotMerchant)
{
	static int merchantfd = -1;
	struct shcmerchant merchant;

	if( merchantfd <  0 )
	{
		if((merchantfd = dbm_open("shcmerchant_1", getpid()))< 0)
		{
			OTraceError("E-SHC-156106:Unable to open shcmerchant_1 index, errno = %d\n", dbm_errno);
			return (-1);
		}
	}

	//check for the record in the table
	if ( merchantfd >= 0)
	dbm_rewind(merchantfd);
	strcpy(merchant.institution, newHotMerchant->institution);
	strcpy(merchant.acceptor_id, newHotMerchant->acceptor_id);

	if( (dbm_read(merchantfd, (char *)&merchant, DBM_REQUAL | DBM_RLOCK)) < 0 )
	{
		OTraceDebug("D-SHC-156107:No record for the Merchant [%s],No Need to UnBlock/Enable the Merchant\n",
		merchant.acceptor_id);
	}
	else
	{
		if(ist_dbm_delete(merchantfd,(char*)newHotMerchant, 0) <0)
		{
			OTraceError("E-SHC-156108:Unable to delete record(%d) for the Merchant :[%s]\n",
						dbm_errno, newHotMerchant->acceptor_id);
			return (-1);
		}
		OTraceInfo("I-SHC-156109:Merchant [%s] is unblocked(deleted from shcmerchant table)\n", newHotMerchant->acceptor_id);
	}
	if ( merchantfd >= 0)
	dbm_rewind(merchantfd);	//	---	R026365
	return 0;
}


int ShcmsgFMHelper::suspendMerchant(struct shcmerchant *newHotMerchant)
{
	static int merchantfd = -1;
	struct shcmerchant merchant;
	//	>>>	R025639
	char temp[100];
	char q_trandate[20];
	sprintf(q_trandate, "%u", newHotMerchant->trandate);
	sprintf(temp, "trandate = to_date('%s', 'YYMMDD'), trantime = %d, duration = %d", q_trandate,
			newHotMerchant->trantime, newHotMerchant->duration);
	OTraceDebug("D-SHC-Test: temp [%s]\n", temp);
	//	<<<	R025639

	if( merchantfd <  0 )
	{
		if((merchantfd = dbm_open("shcmerchant_1", getpid()))< 0)
		{
			OTraceError("E-SHC-156110:Unable to open shcmerchant_1 index, errno = %d\n", dbm_errno);
			return (-1);
		}
	}

	//check for the record in the table
	if ( merchantfd >= 0)
	dbm_rewind(merchantfd);
	strcpy(merchant.institution, newHotMerchant->institution);
	strcpy(merchant.acceptor_id, newHotMerchant->acceptor_id);

	if( (dbm_read(merchantfd, (char *)&merchant, DBM_REQUAL | DBM_RLOCK)) < 0 )
	{
		OTraceDebug("D-SHC-156111:No record for the Merchant [%s],Terminal [%s]Insert a new record for the Merchant\n",
		merchant.acceptor_id,merchant.terminal_id);
	}
	else
	{
		if( (dbm_updatefd(merchantfd, temp)) < 0)
		//if( (dbm_updatefd(merchantfd, "trandate = ?'newHotMerchant->trandate', trantime = ?newHotMerchant->trantime, duration = ?newHotMerchant->duration")) < 0)
		{
			OTraceError("E-SHC-156112:Unable to update record for Merchant [%s]Terminal[%s], dbm_errno: %d\n",
				newHotMerchant->acceptor_id,newHotMerchant->terminal_id, dbm_errno);
			return (-1);
		}

		OTraceDebug("D-SHC-156113:Updated record for Merchant [%s]\n",newHotMerchant->acceptor_id);
		return 0;
	}

	if(dbm_insert(merchantfd,(char*)newHotMerchant, 0) <0)
	{
		OTraceError("E-SHC-156114:Unable to insert record(%d) for the Merchant :%sTerminal:%s\n",
			dbm_errno, newHotMerchant->acceptor_id,newHotMerchant->terminal_id);
		return (-1);
	}

	OTraceInfo("I-SHC-156115:Record updated for suspending the Merchant[%s]Termianl[%s]\n", newHotMerchant->acceptor_id,newHotMerchant->terminal_id);
	if ( merchantfd >= 0)
	dbm_rewind(merchantfd);	//	---	R026365
	return 0;

}
int ShcmsgFMHelper:: IsMerchantSuspensionExpired(struct shcmerchant *merchant)
{
		int d_days, d_hrs, d_min, txn_hrs, txn_min, txn_sec, txn_yrs, txn_mon, txn_dte =0;
		char dur[8], txn_tme[7], dte[8];
		time_t c_time,ebl_time;
		struct tm txnInfo;
		c_time = time(NULL);
		if(!merchant->duration)
			return 0;

		memset(dur,0x00,sizeof(dur));
		memset(txn_tme,0x00,sizeof(txn_tme));
		memset(dte,0x00,sizeof(dte));
		OTraceInfo("I-SHC-156117:Current Time in Seconds: %ld\n",c_time);
		snprintf(dur, sizeof(dur),"%07d", shcmerchant.duration);
		sscanf(dur,"%03d%02d%02d", &d_days, &d_hrs, &d_min);
		snprintf(txn_tme, sizeof(txn_tme),"%06d", shcmerchant.trantime);
		sscanf(txn_tme,"%02d%02d%02d", &txn_hrs, &txn_min, &txn_sec);
		snprintf(dte,sizeof(dte), "%08d", shcmerchant.trandate);
		sscanf(dte,"%04d%02d%02d", &txn_yrs, &txn_mon, &txn_dte);
		txnInfo.tm_year	=	txn_yrs - 1900;
		txnInfo.tm_mon	=	txn_mon - 1;
		txnInfo.tm_mday	=	txn_dte + d_days;
		txnInfo.tm_hour	=	(txn_hrs + d_hrs);
		txnInfo.tm_min	=	(txn_min + d_min);
		txnInfo.tm_sec	=	txn_sec;
		txnInfo.tm_isdst=	-1;

		ebl_time = mktime(&txnInfo);

		OTraceInfo("I-SHC-156116:Enable Time in Seconds: %ld\n",ebl_time);

		if(difftime(c_time,ebl_time) >= 0)
		{
			OTraceInfo("I-SHC-156116:Merchant is enabled");
			return (1);
		}
	return 0;
}

int ShcmsgFMHelper:: SetRCIfMerchantBlocked(ShcmsgHeader *header)
{
	strtrim(shcmerchant.acceptor_id,shcmerchant.acceptor_id);
	strtrim(shcmerchant.institution,shcmerchant.institution);

	if( (!strcmp(header->msg.txnSrc,shcmerchant.institution)) && (!strcmp(header->msg.termloc,shcmerchant.acceptor_id )))
		{
			if( !shcmerchant.terminal_id[0] ||
				(header->msg.termid[0] && (strcmp(header->msg.termid, shcmerchant.terminal_id) == 0)) )
			{
				if(!shcmerchant.terminal_id[0])
					OTraceInfo("I-SHC-156027:Merchant[%s] is blocked for all terminals\n",
						shcmerchant.acceptor_id);
				else
					OTraceInfo("I-SHC-156028:Terminal[%s] is blocked for merchant[%s]\n",
						shcmerchant.terminal_id, shcmerchant.acceptor_id);
				header->msg.respcode = shcmerchant.respcode;
				return(shcmerchant.respcode);
			}
		}
return 0;
}
//	<<<	R025639

//R029951 >>>
int ShcmsgFMHelper::setRuleParam()
{
	rm_init();

	if((fmAppid = rm_getappid(FM_MESSAGE_NAME)) < 0)
	{
		OTraceDebug("D-SHC-156001:unable to locate message name: %s\n", FM_MESSAGE_NAME);
		return(-1);
	}
	else
	{
		if ( rm_attach( fmAppid, RULES_VER_CURRENT) != 0) //R029951
		{
			OTraceError("E-SHC-156001.1: Unable to attach to CURRENT version of %s\n",FM_MESSAGE_NAME);
			return(-1);
		}
		fmRuleKeyPtr = rm_getapphead(fmAppid);
		fmInstKeys = (char *)rm_getappkey(fmAppid);
	}
	return(0);
}


int ShcmsgFMHelper::loadRuleParam()
{
	rm_init();

	if((fmAppid = rm_getappid(FM_MESSAGE_NAME)) < -1)
	{
		OTraceDebug("D-SHC-156001:unable to locate message name: %s\n", FM_MESSAGE_NAME);
		return(-1);
	}
	else
	{
		if ( rm_attach( fmAppid, RULES_VER_LOADING) != 0) //R029951
		{
			OTraceError("E-SHC-156001.1: Unable to attach to LOADING version of %s\n",FM_MESSAGE_NAME);
			return(-1);
		}
		fmRuleKeyPtr = rm_getapphead(fmAppid);
		fmInstKeys = (char *)rm_getappkey(fmAppid);
	}
	return(0);
}
//R029951 <<<
