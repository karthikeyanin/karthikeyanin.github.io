static char _ShcRevRespHelper_cxx_what[] = "@(#) ShcRevRespHelper.cxx 1.43.1.9 20/02/27 06:05:29";

/*
 *  Copyright (C) 2004 eFunds Corporation ("eFunds").  All Rights Reserved.     
 *  eFunds Canada Corporation is an authorized user.                            
 *                                                                              
 *  IST is a registered trademark of eFunds Corporation.  Other brand or        
 *  product names are trademarks or registered trademarks of their respective   
 *  holders.                                                                    
 *                                                                              
 *  The information contained herein is the unpublished proprietary property    
 *  of eFunds.  Except as specifically authorized in writing by eFunds, the     
 *  holder of this document shall: i) keep all information contained herein     
 *  confidential, and ii) protect the information, in whole or in part, from    
 *  disclosure and dissemination to all third parties.                          
 *                                                                          
 *  This document and the software described in it are furnished under license  
 *  and may be used or copied only in accordance with the terms of such license.
 *  This document is supplied for information purposes only, is subject to      
 *  change without notice, and should not be construed as a commitment by       
 *  either eFunds Corporation or eFunds Canada Corporation. 
 *
 *
 *                        MODIFICATION HISTORY                  REVIEW
 *
 *	SPR#	Who	Date	Description			Who	Date   
 * ===========================================================================
 * R0xxxxx jyang 21Nov03 Created
 * R012134 Emj   04Oct04 Issuer Entity Support
 * R012160 Emj   10Oct04 Restore Processor Business Day
 * R012339 Emj   08Nov04 Emv Buffer Bitmap
 * R018729 spa	 22Jan07 Dont restore SH_DEVCAP_USER_SEGMENT flag from 400 to 410
 * R022997 jyang 02May08 Log respcode from revreq txn
 * R026138 sks	 04Mar09 MAC key exchange from verifyRespRevMac function
 * R028271 dipa  18Jun10 Txn Statistics
 * R029073 Emj   10Feb11 Remove Full restore of device_cap
 * R029849 sks	 08Sep11 Restore reference number,Visa Fall 2011 Compliance
 * R030381 dipa  02Mar12 Txn statistics changes
 * R030455 dipa  04Apr12 Do not log late rev response twice in DB
 */


//File Number 119

/*****************************************************************************/

#include <ShcRevRespHelper.h>
#include <ShcApp.h>
#include <ShcHelper.h>
#include <ShcBin.h>
#include <ShcmsgTxnHelper.h>
#include <ShcmsgHelper.h>
#include <ShcRevReqHelper.h>
//	>>>	R026138
#include <ShcDKEHelper.h>
#include <ShcKeyTxnHelper.h>
//	<<<	R026138

//R028271 >>>
#include <TxnStat.h>
//<<< R028271
#include <ShcSaf.h>
#include <ShcSafIOHelper.h>
#include <ist_seg_id.h>


/*****************************************************************************/
int ShcRevRespHelper::doReplay(ShcmsgHeader *header)
{
	/* If this is an advice response make sure we should log to the dbase */
	if(header->msg.device_cap & SH_DEVCAP_FROM_REPLAY)
	{
		/* 10002187 */
		OTraceDebug("D-SHC-119001:  Replay transaction\n");


		//IST_S770SP14-22 Setting SHCERROR as SHC_IE_SafReply all SAF Replayed Transactions
		header->msg.shcerror = SHC_IE_SafReply; //>>>IST_S770SP12-185>>>

		header->shcerr = SH_RETURN;
		
		header->logFlag |= SHC_LOG_UPD_REQ;
		
		OTraceDebug("D-SHC-119002: Leave function shc_revresp()\n");

		return True;
	}
	return False;
}	
	

/*****************************************************************************/

int ShcRevRespHelper::sendToPosauthSever(ShcmsgHeader *header)
{
	/*	Now determine if the transaction should be reversed to posauth */
	if(header->logFlag)
	{
		int save_respcode, save_revcode;
		
		if( /*	must allow pos'tve authorization */
	  		(header->issShcBin->binPkg->saf.type & SH_SAF_POSFILE)
			/*	the transaction should not have been saf already */
			&& (header->reqMsg->saf == 0))
		{
			save_respcode = header->msg.respcode;
			if ((save_respcode == SHC_RC_Approved) || (save_respcode == SHC_RC_PartialDispense))
			{
				save_revcode  = header->msg.revcode;
				header->msg.respcode = header->reqMsg->respcode;
				header->msg.revcode  = header->reqMsg->revcode;
				
				thisShcApp->shcmsgTxnHelperObj->shc_posauth(header, 0);
			
				header->msg.respcode = save_respcode;
				header->msg.revcode  = save_revcode;
			}
		}
	}
	return 0;
}
	
/*****************************************************************************/
int ShcRevRespHelper::setRoutingFlag(ShcmsgHeader *header)
{
	/*
	 *	We ignore the reply since the initial request sent a 410 to the
	 *	acquirer at the same time as sending the 400 to the issuer
	 *
	 *	SH_DEVCAP_SHC_MSG_REPLIED indicates reversal was already replied to acq
	 *	SH_GETAPP_HOST check can be removed in future
	 */
	if ( !(header->issShcBin->binPkg->bin.flags & SH_GETAPP_HOST) ||
		(header->msg.shc_devcap & SH_DEVCAP_SHC_MSG_REPLIED) )
	{
		header->shcerr = SH_IGNORE;
		return 0;
	}

	struct shc_data *shc_data_ptr = (struct shc_data *)header->msg.shc_data_buffer;
	
	if (shc_isbitset(shc_data_ptr->device_cap,SHC_DATA_DEVICE_CAP_IS_AUTHCOMP))
	{
		header->shcerr = SH_IGNORE;
		return 0;
	}

	/*	27Mar92
	*	If original message is from SHCREPLAY, need to return
	*	it back to him so that he can sent me the next message.
	*/
	if( header->issShcBin->binPkg->bin.flags & SH_GETAPP_HOST )		/* 10002273 */
	{
		/* 10002113 */
		if( header->reqMsg->msgtype==SHC_REVREQ_ADVICE && (header->issShcBin->binPkg->saf.type & SH_SAF_POSFILE) )
			header->shcerr = SH_RECON|SH_RETURN;
		else
			header->shcerr = SH_RETURN;

		header->msg.senderid	= header->reqMsg->senderid;
		header->msg.unit		= header->reqMsg->unit;
	}
	return 0;
}

/*****************************************************************************/
int ShcRevRespHelper::locateRevReqEvent(ShcmsgHeader *header)
{
	/*
	 *	1.	Get 400 from event queue
	 */
	if( header->reqMsg == NULL )
	{
		OTraceError("E-SHC-119003: Unmatched rev reply:trace: %d\n", header->msg.trace);
		header->shcerr = SH_IGNORE;
		header->msg.shcerror = SHC_IE_NoMatch;
		header->msg.shc_devcap |= SH_DEVCAP_SHC_LATE_RESPONSE;	/* R009856 */
		thisShcApp->shcmsgTxnHelperObj->processLateResponse(header);
		header->msg.msgtype += SHC_LATE_RESPONSE;				/* 10002243 */
		
		header->setIgnoreFlag();
		return (-1);
	}

	/* Remove from the queue */
	tm_dequeue(header->eventId);
	
	return 0;
}

/*****************************************************************************/
int ShcRevRespHelper::restoreRespReversal(ShcmsgHeader *header)
{
	/* Ssc - 28Jun00	R004671 Integration to 7.2 */
	/* Ssc - 11Apr00    SPR # 2007336 Chip Txn enhancement */
	emv         *oemvbuf=NULL;
	emv         tmpEmvBuf;
	emv         *emvbuf=NULL;
	int len;
	struct shc_data *ptr_shc_data, *ptr_shc_data_orig;	/* R006583 */
	
	if( !header->reqMsg )
	{
		OTraceWarning("W-SHC-119004: No request message data, restoreRespReversal() ignored!\n");
		return -1;
	}

	if ( header->msg.acctnum[0] == '\0' )
		strcpy(header->msg.acctnum, header->reqMsg->acctnum);     

	header->msg.site_id =  header->reqMsg->site_id;
	header->msg.version =  header->reqMsg->version;

	if (header->msg.src_node == 0)
		header->msg.src_node = header->reqMsg->src_node;

	if (header->msg.dest_node == 0)
		header->msg.dest_node = header->reqMsg->dest_node;

										/* R007953 BEGIN */
	/*	Make sure that we "remember" the device capability */
	//header->msg.device_cap	|= header->reqMsg->device_cap;
	header->msg.device_cap	|= (header->reqMsg->device_cap & (~SH_DEVCAP_USER_SEGMENT));	//	---	R018729

	header->msg.txntype = header->reqMsg->txntype;
	header->msg.from_acct = header->reqMsg->from_acct;
	header->msg.to_acct = header->reqMsg->to_acct;
	if (header->msg.iss_conv_date == 0)
		header->msg.iss_conv_date = header->reqMsg->iss_conv_date;
	if (header->msg.acq_conv_date == 0)
		header->msg.acq_conv_date = header->reqMsg->acq_conv_date;
	if (header->msg.tra_conv_date == 0)
		header->msg.tra_conv_date = header->reqMsg->tra_conv_date;
	if (header->msg.trandate == 0)
		header->msg.trandate = header->reqMsg->trandate;
	if (header->msg.trantime == 0)
		header->msg.trantime = header->reqMsg->trantime;
	if (header->msg.local_time == 0)
		header->msg.local_time = header->reqMsg->local_time;
	if (header->msg.local_date == 0)
		header->msg.local_date = header->reqMsg->local_date;
		
	if (header->msg.processor_busday == 0)
		header->msg.processor_busday = header->reqMsg->processor_busday;
	if (header->msg.settlement_date == 0)
		header->msg.settlement_date = header->reqMsg->settlement_date;
	if (header->msg.cap_date == 0)
		header->msg.cap_date = header->reqMsg->cap_date;
	if (header->msg.pos_pin_cap_code == 0)
		header->msg.pos_pin_cap_code = header->reqMsg->pos_pin_cap_code;
	if ((!header->msg.pos_geo_loc[0]) && header->reqMsg->pos_geo_loc[0])
		memcpy(header->msg.pos_geo_loc,header->reqMsg->pos_geo_loc, sizeof(header->msg.pos_geo_loc));
	if (header->msg.revcode == 0)
		header->msg.revcode = header->reqMsg->revcode;
	if (header->msg.shcerror == 0)
		header->msg.shcerror = header->reqMsg->shcerror;
		
		header->msg.merchant_type = header->reqMsg->merchant_type;
		header->msg.acq_country = header->reqMsg->acq_country;
		header->msg.card_seqno = header->reqMsg->card_seqno;
	if (header->msg.serial_1 == 0)
		header->msg.serial_1 = header->reqMsg->serial_1;
	if (header->msg.serial_2 == 0)
		header->msg.serial_2 = header->reqMsg->serial_2;
	//	>>>	R029849
	//if ((!header->msg.refnum[0]) && header->reqMsg->refnum[0])
	if (header->reqMsg->refnum[0])
		memcpy(header->msg.refnum, header->reqMsg->refnum, sizeof(header->msg.refnum));
	//	<<<	R029849
	if ((!header->msg.authnum[0]) && header->reqMsg->authnum[0])
		memcpy(header->msg.authnum, header->reqMsg->authnum, sizeof(header->msg.authnum));
		memcpy(header->msg.termid, header->reqMsg->termid, sizeof(header->msg.termid));
	if (header->msg.saf == 0)
		header->msg.saf = header->reqMsg->saf;
		header->msg.shc_devcap = header->reqMsg->shc_devcap;
		header->msg.auth_devcap = header->reqMsg->auth_devcap;
		header->msg.storeid = header->reqMsg->storeid;
		header->msg.lane = header->reqMsg->lane;
		header->msg.terminal_trace = header->reqMsg->terminal_trace;
		header->msg.checker_id = header->reqMsg->checker_id;
		header->msg.supervisor = header->reqMsg->supervisor;
		header->msg.shift_number = header->reqMsg->shift_number;
		header->msg.batch_id = header->reqMsg->batch_id;
	if (header->msg.origpcode == 0)
		header->msg.origpcode = header->reqMsg->origpcode;
	if ( dbm_decncmp(&header->msg.new_amount_equiv, (double)0) == 0 )
		dbm_deccopy(&header->msg.new_amount_equiv, &header->reqMsg->new_amount_equiv);	

	if ( dbm_decncmp(&header->msg.txn_amount, (double)0) == 0 )
		dbm_deccopy(&header->msg.txn_amount, &header->reqMsg->txn_amount);	
	if ( dbm_decncmp(&header->msg.txn_new_amount, (double)0) == 0 )
		dbm_deccopy(&header->msg.txn_new_amount, &header->reqMsg->txn_new_amount);	
	if (header->msg. txn_currency_code == 0)
		header->msg. txn_currency_code = header->reqMsg-> txn_currency_code;
	if (header->msg.txn_conv_date == 0)
		header->msg.txn_conv_date = header->reqMsg->txn_conv_date;

	// USP-1631
	// cash_back are not always echoed back in response
	if (dbm_cmpzero(&header->msg.cash_back) == 0)
		dbm_deccopy(&header->msg.cash_back, &header->reqMsg->cash_back);	

	if ( dbm_decncmp(&header->msg.ch_amount, (double)0) == 0 )
		dbm_deccopy(&header->msg.ch_amount, &header->reqMsg->ch_amount);	
	if (header->msg.ch_currency_code == 0)
		header->msg.ch_currency_code = header->reqMsg->ch_currency_code;

	if ( dbm_decncmp(&header->msg.ch_conv_rate, (double)0) == 0 )
		dbm_deccopy(&header->msg.ch_conv_rate, &header->reqMsg->ch_conv_rate);	
	if (header->msg.ch_conv_date == 0)
		header->msg.ch_conv_date = header->reqMsg->ch_conv_date;

	if ((!header->msg.forward_inst_id[0]) && header->reqMsg->forward_inst_id[0])
		memcpy(header->msg.forward_inst_id, header->reqMsg->forward_inst_id, sizeof(header->msg.forward_inst_id));
	if ((!header->msg.receive_inst_id[0]) && header->reqMsg->receive_inst_id[0])
		memcpy(header->msg.receive_inst_id, header->reqMsg->receive_inst_id, sizeof(header->msg.receive_inst_id));
	if (header->msg.slot_num == 0)
		header->msg.slot_num = header->reqMsg->slot_num;
	if (header->msg.origcapdate == 0)
		header->msg.origcapdate = header->reqMsg->origcapdate;
	if (header->msg.saf_devcap == 0)
		header->msg.saf_devcap = header->reqMsg->saf_devcap;



	header->msg.pos_condition_code = header->reqMsg->pos_condition_code;
	header->msg.pos_entry_code      = header->reqMsg->pos_entry_code;   /* R007209 */
	header->msg.formatter_devcap = header->reqMsg->formatter_devcap;
	header->msg.device_devcap = header->reqMsg->device_devcap;
	header->msg.pos_cap_code = header->reqMsg->pos_cap_code;

	if (header->msg.txn_start_time <= 0)
		header->msg.txn_start_time = header->reqMsg->txn_start_time;

	OTraceLog("L-SHC-119007: Replace ID [%s] with ID [%s]\n", header->msg.shclog_id, header->reqMsg->shclog_id);

	//R028271 >>>
	if(strcmp(header->msg.shclog_id,header->reqMsg->shclog_id))
		TxnStatEquate(header->reqMsg->shclog_id, header->msg.shclog_id);
	else
		OTraceDebug("L-SHC-119007.1: No need to Equate [%s] and [%s]\n",header->msg.shclog_id,header->reqMsg->shclog_id);
	//<<< R028271

	strcpy(header->msg.shclog_id, header->reqMsg->shclog_id);
										/* R007953 END */
	

	/* Ssc - 28Jun00	R004671 Integration to 7.2 */
	/* Ssc - 11Apr00    SPR # 2007336 Restore chip data */
		
		emv tmpOEmvBuf;
		len = sizeof(tmpOEmvBuf);
		header->getReqSegmentData((char *)&tmpOEmvBuf, &len, EMV_BUF_id, 0);
		if (len > 0)
			oemvbuf = &tmpOEmvBuf;
		
		
		if(oemvbuf)
		{
			len = sizeof(tmpEmvBuf);
			header->getSegmentData((char *)&tmpEmvBuf, &len, EMV_BUF_id, 0);
			emvbuf = &tmpEmvBuf;
			if (len <= 0)
				memset(emvbuf, 0, sizeof(tmpEmvBuf));

			
			emvbuf->chip_type           = oemvbuf->chip_type;
			header->msg.card_seqno          = header->reqMsg->card_seqno;
			strcpy(emvbuf->term_ser_num, oemvbuf->term_ser_num);
			strcpy(emvbuf->app_txn_counter, oemvbuf->app_txn_counter);
			strcpy(emvbuf->issuer_script_res,oemvbuf->issuer_script_res);

			if (shcApp->shcHelperObj->isEmvBitMap(oemvbuf, deri_key_idx_bit))
			{
				emvbuf->deri_key_idx            = oemvbuf->deri_key_idx;
				shcApp->shcHelperObj->setEmvBitMapOn(emvbuf, deri_key_idx_bit);
			}
			
			if (shcApp->shcHelperObj->isEmvBitMap(oemvbuf, crypto_version_bit))
			{
				emvbuf->crypto_version          = oemvbuf->crypto_version;
				shcApp->shcHelperObj->setEmvBitMapOn(emvbuf, crypto_version_bit);
			}

			strcpy(emvbuf->cvr, oemvbuf->cvr);
			strcpy(emvbuf->tvr, oemvbuf->tvr);
			/* R008083 */
			strcpy(emvbuf->issuer_app_data,oemvbuf->issuer_app_data);
			
			header->setSegmentData((char *)emvbuf, sizeof(*emvbuf), EMV_BUF_id, 0);
		}

	header->getSegList()->restore(header->getReqSegList());
	header->msg.merchant_type = header->reqMsg->merchant_type;

	if(header->msg.local_date == 0L || header->msg.local_time == 0L)
	{
		/* restore time and date from event */
		header->msg.local_date = header->reqMsg->local_date;
		header->msg.local_time = header->reqMsg->local_time;
	}

	/* 2009291  Rpc 10apr00 restore field acquirer_data on response for SMS */
	memcpy(header->msg.acquirer_data, header->reqMsg->acquirer_data,
			sizeof(header->msg.acquirer_data));                          // destination and source buffer size are same.
			                                                             // still changed to destination buffer size to avoid overflow.

	/* 22 Dec 92 */
	if(!(header->msg.device_cap & SH_DEVCAP_KEEP_FORMATTER_USE))
		memcpy(header->msg.formatter_use, header->reqMsg->formatter_use,
			sizeof(header->msg.formatter_use));

	/* R008717 BEGIN */
	if ((!header->msg.txnSrc[0]) && (header->reqMsg->txnSrc[0]))
		strcpy(header->msg.txnSrc, header->reqMsg->txnSrc);
	if ((!header->msg.txnDest[0]) && (header->reqMsg->txnDest[0]))
		strcpy(header->msg.txnDest, header->reqMsg->txnDest);
	if ((!header->msg.alternateAcquirer[0]) && (header->reqMsg->alternateAcquirer[0]))
		strcpy(header->msg.alternateAcquirer, header->reqMsg->alternateAcquirer);
	if ((!header->msg.entityId[0]) && (header->reqMsg->entityId[0]))
		strcpy(header->msg.entityId, header->reqMsg->entityId);
	if ((!header->msg.iss_entityId[0]) && (header->reqMsg->iss_entityId[0]))
		strcpy(header->msg.iss_entityId, header->reqMsg->iss_entityId);
	if ((!header->msg.cardProduct[0]) && (header->reqMsg->cardProduct[0]))
		strcpy(header->msg.cardProduct, header->reqMsg->cardProduct);
	if ((!header->msg.member_ID[0]) && (header->reqMsg->member_ID[0]))
		strcpy(header->msg.member_ID, header->reqMsg->member_ID);
	if ((!header->msg.F_ID[0]) && (header->reqMsg->F_ID[0]))
		strcpy(header->msg.F_ID, header->reqMsg->F_ID);
	if ((!header->msg.MVV[0]) && (header->reqMsg->MVV[0]))
		strcpy(header->msg.MVV, header->reqMsg->MVV);
	if ((!header->msg.invoice_number[0]) && (header->reqMsg->invoice_number[0]))
		strcpy(header->msg.invoice_number, header->reqMsg->invoice_number);
	if ((!header->msg.trans_id[0]) && (header->reqMsg->trans_id[0]))
		strcpy(header->msg.trans_id, header->reqMsg->trans_id);
	if ((!header->msg.FPI[0]) && (header->reqMsg->FPI[0]))
		strcpy(header->msg.FPI, header->reqMsg->FPI);
	/* R008717 END */
	
	/* R004684 >> restore the data of DE90 for Europay */
	/*if( shc_isEuroAcquirer( header ) ) */ /* R006477 For EMV*/
	{
		header->msg.origmsg = header->reqMsg->origmsg;
		header->msg.origFlippedMsg = header->reqMsg->origFlippedMsg;
		header->msg.origtrace = header->reqMsg->origtrace;
		header->msg.origdate = header->reqMsg->origdate;
		header->msg.origtime = header->reqMsg->origtime;
	} 
	/* R004684 << */

	/* 24Jun93:restore the acq_currency_code of the revreq msg. */
	header->msg.acq_currency_code = header->reqMsg->acq_currency_code;

	/* 03jun93 */
	strcpy(header->msg.termloc, header->reqMsg->termloc);

	/* 27Jul94 */
	if (( header->reqMsg->respcode == SHC_RC_PartialDispense )||
		( header->reqMsg->revcode == SHC_RR_PartialDispense ))

	{	/* 10002243 */
		dbm_deccopy(&header->msg.aval_balance, &header->reqMsg->aval_balance);

		/*
		 * R001564.
		 * Also use new_amount for partial reversal without removing
		 * aval_balance for compatibility reason.
		 */
		dbm_deccopy(&header->msg.new_amount, &header->reqMsg->new_amount);  

		//header->msg.respcode = header->reqMsg->respcode;	--- R027180
	}

	/* 1Jun94 */
	strcpy(header->msg.termid, header->reqMsg->termid);
	header->msg.cap_date = header->reqMsg->cap_date;
												/* R007781 BEGIN */
	if (shc_is_empty_buf(header->msg.filler1, sizeof(header->msg.filler1)))
		memcpy( header->msg.filler1, header->reqMsg->filler1, sizeof(header->msg.filler1) );
	if (shc_is_empty_buf(header->msg.filler2, sizeof(header->msg.filler2)))
		memcpy( header->msg.filler2, header->reqMsg->filler2, sizeof(header->msg.filler2) );
	if (shc_is_empty_buf(header->msg.filler3, sizeof(header->msg.filler3)))
		memcpy( header->msg.filler3, header->reqMsg->filler3, sizeof(header->msg.filler3) );
	if (shc_is_empty_buf(header->msg.filler4, sizeof(header->msg.filler4)))
		memcpy( header->msg.filler4, header->reqMsg->filler4, sizeof(header->msg.filler4) );
												/* R007781 END */
	header->msg.reason_code = header->reqMsg->reason_code;			/* R004488  */
			/* R006583 >> */
	ptr_shc_data=(struct shc_data *)header->msg.shc_data_buffer;
	ptr_shc_data_orig=(struct shc_data *)header->reqMsg->shc_data_buffer;
	memcpy(ptr_shc_data, ptr_shc_data_orig, sizeof(header->msg.shc_data_buffer));
			/* R006583 << */
	strncpy( header->msg.acceptorname, header->reqMsg->acceptorname, SHC_ACCEPT_LEN );	/* R007234 */
	if(header->reqMsg->device_cap & SH_DEVCAP_FROM_REPLAY)
	{
		if( !shcmsgIsIBFT( header->reqMsg ) )
		{
			strcpy (header->msg.acquirer, header->reqMsg->acquirer);
			header->msg.revcode = header->reqMsg->revcode;   /* R008061 */
			header->msg.senderid	= header->reqMsg->senderid;
			header->msg.unit		= header->reqMsg->unit;
		}	
	}
	
	/* 10002273 */
	if( shcmsgIsIBFTD(header->reqMsg) || shcmsgIsIBFTW(header->reqMsg ) )
	{
		header->msg.pcode = header->reqMsg->origpcode;
		header->msg.origFlippedMsg = header->reqMsg->flipped_msgtype;
		/* 961108 */
		header->msg.origpcode = header->reqMsg->origpcode;
		header->msg.origrespcode = header->reqMsg->respcode;
		/* 961108 */
		header->msg.revcode = header->reqMsg->revcode;
	}
	if ( header->issShcBin->isRestoreTranTime() == True )
	{
		char tbuf[14]={0};
		snprintf(tbuf, sizeof(tbuf), "%08d%06d", header->msg.trandate, header->msg.trantime);
		header->setSegmentData((char *)tbuf, sizeof(tbuf), 
			NETWORK_SETTLEMENT_DATA_RESP_id, ISSUER_TRANSACTION_DATE_TIME);
		header->msg.trantime = header->reqMsg->trantime;
		header->msg.trandate = header->reqMsg->trandate;
	}
	
	return 0;
}

/*****************************************************************************/
/*
 * R001835 Let Non-Interac BIN fall through this function
 */
int ShcRevRespHelper::verifyRespRevMac(ShcmsgHeader *header)
{
//	>>>	R026138
	if(header->msg.respcode == SHC_RC_MACSyncError)
		if(header->issShcBin->isInterac())
		{
			thisShcApp->shcDKEApiObj->shc_inc_ikmacsyncerrcnt_x(header);
			thisShcApp->shcKeyTxnHelperObj->shcmac_ChgKey(header);
			return (-1);
		}
//	<<<	R026138
	if(shcIsRevIssResp(header))
	{
		if( shcIsVerifyMac(header->acqShcBin->binPkg) )
		{
			header->acqShcBin->shcmac_verify(header, SHC_ISS_KEY);
			return( 0 );
		}
	}
	else
	{
		if( shcIsVerifyMac(header->issShcBin->binPkg)
			&& header->issShcBin->shcmac_verify(header, SHC_ACQ_KEY) < 0 )
		{
			if(header->issShcBin->isInterac()) /* R001835 */
			//	>>>	R026138
			{
				thisShcApp->shcKeyTxnHelperObj->shcmac_ChgKey(header);
				return( -1 );
			}
			//	<<<	R026138
			else
				return (0);
		}
	} /* for else */

	return( 0 );
}/* for verifyRespRevMac() */
	

/*****************************************************************************/


int ShcRevRespHelper::updateRespOriginal( ShcmsgHeader *header)
{

	if (header->msg.auth_devcap & SH_DEVCAP_AUTH_NO_ORIG)
	{
		OTraceDebug("D-SHC-119008:Didn't find orig msg when processing request, no orig msg update\n");
		return 0;
	}
	int orig_found = False;
	int save_respcode = header->msg.respcode;
	int save_trace = header->msg.trace;
		
	/* read original 01xx 02xx from database */
	if( thisShcApp->shcmsgHelperObj->locateOrigTxn(header) < 0 )
	{
		OTraceError("E-SHC-119005: Unable to locate orig 200/210 msg for update\n");
		return -1;
	}

	//Original message is found
	if(header->issShcBin->binPkg->bin.flags & SH_GETAPP_HOST)
	{
		/* R003895 Map respcode to 8 if it is an internal reversal. */
		/* 14Apr93. Need to update to the correct reason for reversal */
		if(	shc_internalrev(header) &&
			(header->msg.respcode == SHC_RC_Approved) &&
			(header->msg.revcode == 0)
		  )
			header->msg.revcode = SHC_RR_TimeOut;
			
		if(header->msg.respcode == SHC_RC_Approved)
		{
			if (header->msg.revcode == 0)
				header->msg.revcode  = header->origMsg->revcode;
			header->msg.respcode = header->origMsg->respcode;	// R022997
			thisShcApp->shcRevReqHelperObj->updateOriginal(header);		///////////////////////////
			header->msg.respcode = SHC_RC_Approved;
		}
		else 
		{
			thisShcApp->shcRevReqHelperObj->updateOriginal(header);		///////////////////////////
		}

		/* R004406 Adjust the message type because shc_return_reversal */
		/*         is using shc_set_return_msgno. */
//		if(shcIsResponse(header))
//			header->msg.msgtype -= 10;
		/* End R004406 */

		if(thisShcApp->shcRevReqHelperObj->returnReversal(header) < 0)			
			OTraceError("E-SHC-119006: error in returning reversal to acquirer");
		
		/* End R003895 */
	}
//	else
//		header->logFlag =  header->logFlag & (~SHC_LOG_UPD_REQ);
	else
		thisShcApp->shcRevReqHelperObj->updateOriginal(header);	//	---	IST_S770SP10-462


	header->logFlag = (header->logFlag | SHC_LOG_UPD_ORIG) & (~SHC_LOG_REQ);	
	return 0;
}
	

/*****************************************************************************/
int ShcRevRespHelper::prepareLog(ShcmsgHeader *header)
{

	if (!(header->msg.shc_devcap & SH_DEVCAP_SHC_MSG_REPLIED))
		//First time got the response must update request in db
		//If not first time, the msg in db is already response, no need to update
		header->logFlag |= SHC_LOG_UPD_REQ;
	else
	{
		OTraceDebug("D-SHC-119009:reversal is replied to acquirer already, no need to log again\n");
		if (!(header->issShcBin->binPkg->bin.flags & SH_GETAPP_HOST))
		{
			OTraceDebug ("D-SHC-119010: Updating the reversal response from Issuer in DB.SHCLOG \n");
			((ShcLog *)header->shcLogObj)->doUpdateReversal(header);
		}
	}
	
	updateRespOriginal(header);

	return 0;
}

int ShcRevRespHelper::writeSaf(ShcmsgHeader *header)
{
         int save_msgtype;
 
          // >> For approved transaction from Posauth/Negative and Issuer is down, create SAF.
          if( (header->msg.shc_devcap & SH_DEVCAP_SHC_STDIN) &&
                  (header->msg.respcode == SHC_RC_Approved) &&
                  !(header->msg.device_cap & SH_DEVCAP_FROM_REPLAY) )
                  // R007617              !(shcIsAdviceResp(header)) )
          {
                  save_msgtype = header->msg.msgtype;
                  thisShcApp->shcSafIOHelperObj->shc_saf_resp_convertmsg(header);
                  thisShcApp->shcSafHelperObj->shc_general_saf_write(header->issShcBin, header, 0);
                  header->msg.msgtype = save_msgtype;
          }
          return 0;
}

