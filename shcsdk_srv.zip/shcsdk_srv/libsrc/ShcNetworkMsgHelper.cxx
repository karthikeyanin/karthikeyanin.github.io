
/*
 *  Copyright (C) 2004 eFunds Corporation ("eFunds").  All Rights Reserved.     
 *  eFunds Canada Corporation is an authorized user.                            
 *                                                                              
 *  IST is a registered trademark of eFunds Corporation.  Other brand or        
 *  product names are tradeMarks or registered trademarks of their respective   
 *  holders.                                                                    
 *                                                                              
 *  The information contained herein is the unpublished proprietary property    
 *  of eFunds.  Except as specifically authorized in writing by eFunds, the     
 *  holder of this document shall: i) keep all information contained herein     
 *  confidential, and ii) protect the information, in whole or in part, from    
 *  disclosure and dissemination to all third parties.                          
 *                                                                          
 *  This document and the software described in it are furnished under license  
 *  and may be used or copied only in accordance with the terms of such license.
 *  This document is supplied for information purposes only, is subject to      
 *  change without notice, and should not be construed as a commitment by       
 *  either eFunds Corporation or eFunds Canada Corporation. 
 */
/*
static char SCCSid[] = "@(#) ShcNetworkMsgHelper.cxx 1.40.35.12 20/05/15 16:58:48";
 *
 *  MODIFICATION HISTORY                              REVIEW
 *
 *	SPR#	Who	Date	Description	                  Who	Date   
 * ===========================================================================
 *R00xxxx ztang 05Nov03 Creation
 *R011298 Emj   10Oct04 Support for Cutover and Recon at Entity Level
 *R014598 jyang 31Aug05 leave flag SH_REPLAY alone
 *R016386 spa	11May06	Restore txnSrc, txnDest for echo response
 *R016425 Emj   17May06 Set bin status UP/Down using shcbin class
 *R018093 pve	02Nov06	Generate and use unique trace for cutover broadcast message
 *R020635 spa	14Jul07	Send 800 messages even for unrecognized netcode
 *R020782 emj   27Jul07 Set key class default value from configuration
 *R027124 vmp	21Aug09 Added code to reset trigger counter after successful 810 Key exchange response
 *R027876 dipa  02Mar10 Segment Changes
 *R027855 mm    10Apr10 Cutover moved to ShcCutoverHelper.cxx
 *R027876 dipa  22Apr10 Segment Changes - fix
 *R028104 dipa  29Apr10 routingInfo - fix
 *R028271 dipa  18Jun10 Txn Statistics
 *R029938 sks	26Sep11	Don't mark bin up for SHC_NET_GROUPSIGNON_START
 *R030207 dipa	06Feb12 Clone of R030235,R029678,R029545,R029300
 *R030xxx dipa	01Mar12 Txnstat changes
 *R030424 dipa	20Mar12 Do not set bin up if signon response is declined
 *R032382 dipa  16Dec13 Update binroute for echo response(initiated manually thru shccmd)
 */
//File Number 107

#if defined( WIN32 )
#       define SHCDLLEXPORT __declspec(dllexport)
#else
#       define SHCDLLEXPORT
#endif


#include <stdio.h>
#include <rules.h>
#include <oasis.h>
#include <ist_otrace.h>
#include <mb_umi.h>
#include <shc.h>
#include <tm.h>
#include <string.h>
#include <security.h>	/* R005156 */
#include <ShcnetCutOverException.h>
#include <ShcSdkCommon.h>
#include <ShcMacHelper.h>
#include <ShcTimerHelper.h>
#include <ShcSaf.h>
#include <multi_institution.h>
#include <BusinessDay.h>
#include <ShcDKEHelper.h>
#include <ShcmsgHelper.h>
#include <ShcKeyHelper.h>
#include <ShcMsgCache.h>
#include <ShcNetworkMsgHelper.h>
#include <ShcnetApp.h>
#include <ShcApp.h>
#include <shc500std.h>		/* R010436 */
#include <ic/ic_bin.h>
#include <ic/ic_instid.h>
#include <InstProfile.h>
#include <ShcBin.h>
#include <BinRoute.h>
#include <ShcmsgTxnHelper.h>
#include <ShcCutoverHelper.h>
#include <Cglobal_seq_ctrl.h>

#include <ist_seg_name.h> //R027876
#include <ist_seg_elf_id_map.h> //R027876
#include <ist_seg_id.h> //R027876

#include <ist_seg_msg_replication_data.h>
//R028271 >>>
#include <TxnStat.h>
#include <ist_rand.h>
//<<< R028271

#include <MRApplHelper.h>
#include <MRShckeysTagDefs.h>
#include<switch_state_apis.h>
#include <ShcKeysMRHelper.h>
#include <istsafe.h>

#include <asynchSecApi.h>
#include <ShcAsynchApi.h>
#include <istsafe2.h>
#include <algorithm>

/*------------------------------------------------------------------------*/

ShcCutoverHelper * shcCutoverHelper = NULL;

KeyXchgMsgHelper *keyXchgMsgHelpObj=NULL;
ist_ElfId_t NetDataRqid=ist_ElfId_t(-1);

//int shc_route(ShcmsgHeader *header);
//int shc_edc_updatekey(ShcmsgHeader *header);
//int shc_edc_generatekey(ShcmsgHeader *header);


ShcNetworkMsgHelper::ShcNetworkMsgHelper()
{
	netid = mb_locatemailbox(SHC_SERVER_NAME);
}

int ShcNetworkMsgHelper::setRoutingFlags(ShcmsgHeader *header)
{
	/*
	 *	Interface to the network dirver
	 */

	/*
	 *	o	Determine routing
	 */
	if (header->issBinValid())
	{
		header->shcerr = SH_SENDAPPL;
	
		header->applMailboxId = header->issShcBin->binPkg->bin.netmgrid;
	}
	else
	{
		OTraceDebug("D-SHC-107001:No issuer bin, 8xx message ignored\n");
		header->shcerr = SH_IGNORE;
	}

	if( mbIsDualSite() )
	{
		if (mbGetSiteId() == 2 && (header->msg.storeid > 0 || header->msg.lane > 0)) 
		{
			if ((header->msg.msgtype == SHC_NETWORK_RESPONSE ||  header->msg.msgtype == SHC_NETWORK_ADVICE_RESPONSE )  &&  (header->msg.netcode ==  161))
			{
					header->msg.senderid = header->msg.storeid;
					header->msg.unit = header->msg.lane;
					header->shcerr |= SH_RETURN;
			}
		}
	}

	return 0;

}


#define euNetTimerFlag	"euNetTimerFlag"		// R008781

/*
 *	Network handler for the shared cash system
 *
 *	ALL Network Actions occure against the issuer!!!!!!
 */

ShcmsgHeader *_headerFor_shc_send_keyxchg = NULL;

int ShcNetworkMsgHelper::shc_send_keyxchg(ShcBin *shcBin, char key_class, char key_type)
{
	ShcmsgHeader tmpHeader;
	struct  shcsecurity *keyp = NULL;

	if(!(shcBin->binPkg->bin.bintype & SH_ALLOW_KEY_EXCHANGE))
		return (-1);

	if(shcBin->binPkg->bin.flags & SH_KEY_EXCHANGE)
		return(-1);
	if(!shcBin->key)
		return (-1);
	else
		keyp = shcBin->key;

	tmpHeader.msg.msgtype = SHC_NETWORK;
	tmpHeader.msg.netcode = SHC_NET_KEYS_START;
	tmpHeader.msg.trace   = (-1); /* trace will be generated later. */
	strcpy(tmpHeader.msg.originator, shc_orgid);
	strcpy(tmpHeader.msg.txnSrc, shcBin->binPkg->bin.institutionid);
	strcpy(tmpHeader.msg.issuer, shcBin->binPkg->bin.networkid);
	strcpy(tmpHeader.msg.acquirer, shcBin->binPkg->bin.networkid);

	NetworkInfo networkInfo;
	if (_headerFor_shc_send_keyxchg)
	{
		int len = sizeof(struct InstitutionProfile);
		_headerFor_shc_send_keyxchg->getSegmentData((char *)networkInfo.getInstProfileEntry(), &len, 
			NETWORK_DATA_REQ_id, ISS_INST_PROFILE_ENTRY);
		_headerFor_shc_send_keyxchg = NULL;
		if (len > 0)
		{
			tmpHeader.setSegmentData((char *)networkInfo.getInstProfileEntry(), sizeof(struct InstitutionProfile), 
				NETWORK_DATA_REQ_id, ISS_INST_PROFILE_ENTRY);
		}
		else
		{
			OTraceError("E-SHC-107028:Can't find ISS_INST_PROFILE_ENTRY. Key exchange failed.\n");
			return -1;
		}
	}
	else if (rm_isMultiVerSupported(0) && shcBin->key)
	{
		shcApp->instProfileObj->locateNetworkInfoByKeyParamStr(shcBin->key->k.institutionid, shcBin->key->k.userbinid, 
								networkInfo, shcBin->binPkg->bin.networkid);
		if (networkInfo.foundNetworkInfo())
		{
			tmpHeader.setSegmentData((char *)networkInfo.getInstProfileEntry(), sizeof(struct InstitutionProfile), 
								NETWORK_DATA_REQ_id, ACQ_INST_PROFILE_ENTRY);
			tmpHeader.setSegmentData((char *)networkInfo.getInstProfileEntry(), sizeof(struct InstitutionProfile), 
								NETWORK_DATA_REQ_id, ISS_INST_PROFILE_ENTRY);
		}
		else
		{
			OTraceError("E-SHC-107069:Can't find inst_profile entry for i(%s),b(%s),k(%s)\n", shcBin->key->k.institutionid,
								shcBin->binPkg->bin.networkid, shcBin->key->k.userbinid);
			return -1;
		}
	}
	else
	{
		OTraceError("E-SHC-107070:Can't find inst_profile entry for i(%s),b(%s),k(%s)\n", shcBin->key->k.institutionid,
					shcBin->binPkg->bin.networkid, shcBin->key->k.userbinid);
		return -1;
	}

	tmpHeader.msg.format_code[0]= key_class;
	tmpHeader.msg.format_code[1]= key_type;
	if (tmpHeader.msg.format_code[1] == SH_KEYTYPE_PIN)
	{
		if (tmpHeader.msg.format_code[0] == SH_KEYTYPE_PIN_ISS)
			tmpHeader.msg.pin_index = '0' + keyp->k.isspinidx;
		else
			tmpHeader.msg.pin_index = '0' + keyp->k.acqpinidx;
		shcApp->shcKeyObj->shckeys_getnext_index(shcBin->binPkg->bin.institutionid, &tmpHeader.msg.pin_index);
	}
	else if (tmpHeader.msg.format_code[1] == SH_KEYTYPE_MAC)
	{
		if (tmpHeader.msg.format_code[0] == SH_KEYTYPE_PIN_ISS)
			tmpHeader.msg.mac_index = '0' + keyp->k.issmacidx;
		else
			tmpHeader.msg.mac_index = '0' + keyp->k.acqmacidx;
		thisShcApp->shcKeyObj->shckeys_getnext_index(shcBin->binPkg->bin.institutionid, &tmpHeader.msg.mac_index);
	}

	mb_getUmi(tmpHeader.msg.shclog_id, sizeof(tmpHeader.msg.shclog_id));
	mb_set_tid(tmpHeader.msg.shclog_id, strlen(tmpHeader.msg.shclog_id));
	OTraceLog("L-SHC-107053: Created message ID[%s] m%04d/n%d\n", 
		tmpHeader.msg.shclog_id, tmpHeader.msg.msgtype, tmpHeader.msg.netcode);

	//R028271 >>>
	TxnStatReport(tmpHeader.msg.shclog_id,TS_SHC,TSR_CREATE,tmpHeader.msg.msgtype,0,0);
	//<<< R028271

	tmpHeader.truelength();
	shc_send_800(&tmpHeader, shcBin);

	return (1);
}




/* 7oct97 > */
//This function has been converted to ShcnetEventMsg Base Txn,
//So it should be removed
// 
// int ShcNetworkMsgHelper::shc_network_event( ShcmsgHeader *header)
// {
// 	/*
// 	 *	Initialise the structures
// 	 */
// 	if(thisShcApp->shcmsgHelperObj->shcGetIssAcq(header, 0) == -1)
// 	{
// 		OTraceError("E-SHCNET-107003: Invalid network transaction: Code: %d issuer %s\n", 
// 			header->msg.respcode, header->msg.issuer);
// 		return(0);
// 	}
// 	
// 	header->shcerr = SH_IGNORE;
// 
// 	OTraceInfo("I-SHCNET-107004:  Time-out Network Message:\n");
// 	OTraceInfo("          :    msgtype   : %04d\n", header->msg.msgtype);
// 	OTraceInfo("          :    netcode   : %d\n", header->msg.netcode);
// 	OTraceInfo("          :    trace     : %06ld\n", header->msg.trace);
// 	OTraceInfo("          :    originator: %s\n", header->msg.originator);
// 	OTraceInfo("          :    acquirer  : %s\n", header->msg.acquirer);
// 
// 	switch( header->msg.netcode )
// 	{
// 		case	SHC_NET_KEYS:
// 		case	SHC_NET_KEYS_START:
// 			header->msg.respcode = SHC_RC_IssuerTimeout; /*R002203*/
// 			shcnet_exchange_response(header, SH_KEYSTAT_INACTIVE);
// 			break;
// 	}
// 
// 	/* R008781 >> */ 
// 	if ( thisShcApp->shcmsgHelperObj->shc_isEuroNet(header) )		/* Only for Europay */
// 	{
// 		/* Only Processing one time for auto network event */
// 		if ( strncmp( header->msg.acquirer_data	\
// 			, euNetTimerFlag, sizeof(euNetTimerFlag) ) == 0 )
// 		{
// 			strcpy( header->msg.acquirer_data, "Processed!" );	/* set processed flag */
// 	
// 			return( 1 ); 	
// 		}
// 		else
// 		{
// 			switch( header->msg.netcode )
// 			{
// 			case	SHC_NET_SIGNON_START:
// 			
// 				/* if the Europay Member fails to respond to 800 within 15 seconds,
// 				 *	HOST must send a 0800 Sign-off Request to the Europay Member (P4.4~5) */
// 				/*	Create sign-off immediately by event(0 Sec)	*/
// 				OTraceInfo( "I-SHCNET-107005: Created sign-off immediately by event(0 Sec),"
// 							" due to no response for sign-on\n"); 
// 				header->msg.reason_code = 3;
// 				shc_euNetTimer(header, SHC_NET_SIGNOFF_START, 0);  
// 				break;
// 				
// 			case	SHC_NET_SIGNOFF_START:
// 				/* if no 0800 Sign-off Response from EM, HOST should clear */
// 				/*	the line and then re-open the X.25 connection (P4.4~5) */
// 				// OTraceInfo( "Pending: Host should clear the line and re-open the X.25 connection. Line:(%d)\n", __LINE__ ); 
// 				break;
// 			}
// 		}
// 	}
// 	/* R008781 << */
// 	
// 	return( 0 );
// }


/* 7oct97 < */
int    ShcNetworkMsgHelper::makeServiceIndicator(ShcmsgHeader *header)  /* R006087,R006073 Begin*/
{
	ShcBin 				*shcBin;
	struct shc_data     *shc_data;
	char                avs_flag = '0';
	char                acq_iss_flag    =   'B';
	int   				ia;					/* R006134 */ 
	int     			flag = 0;

	shc_data = (struct shc_data*)header->msg.shc_data_buffer;

//	for(ia=0;ia<sizeof(header->msg.issuer) - 1; ia++)
//	{
//		if(header->msg.issuer[ia] != ' ')
//		{
//			flag = 1;
//			break;
//		}
//	}

	if(header->issBinValid())
	{
	
//		if(header->setIssShcBin(header->msg.issuer) < 0)
//   		{
//	    	OTraceError("E-SHCNET-107006:%s@%d -- unable to find networkid '%s'\n",__FILE__, __LINE__, header->msg.issuer);
//        	return(-1);
//    	}

		shcBin = header->issShcBin;


		if((shcBin->binPkg->bin.bin_cfg & 0x1c0) == SH_CONDENSED4_AVS)
	   		avs_flag='4';
		else if((shcBin->binPkg->bin.bin_cfg & SH_CONDENSED3_AVS) == SH_CONDENSED3_AVS)
	   		avs_flag='3';
    	else if(shcBin->binPkg->bin.bin_cfg & SH_NONCONDENSED_AVS)
   			avs_flag='1';
    	else if(shcBin->binPkg->bin.bin_cfg & SH_CONDENSED2_AVS)
    		avs_flag='2';

		/* R007010 Begin */
		if((shcBin->binPkg->bin.bin_cfg & SH_ISSUER_ACQURIER ) == SH_ISSUER_ACQURIER)
				acq_iss_flag='B';
		else if(shcBin->binPkg->bin.bin_cfg & SH_ACQUIRER_ONLY)
				acq_iss_flag='A';
		else if(shcBin->binPkg->bin.bin_cfg & SH_ISSUER_ONLY)
				acq_iss_flag='I';
		/* R007010 END */

		memset(shc_data->avs_data, 0, sizeof(shc_data->avs_data));
		sprintf(shc_data->avs_data,"C%c%c    ", acq_iss_flag, avs_flag);

	}

	return(0);

}  /* R006087 R006273 End*/

/* R008781 >> */
/* Create an event for Europay auto SignOn in iDelay seconds after 
 *	force sign-off by Europay - R004833 */
int ShcNetworkMsgHelper::shc_euNetTimer( ShcmsgHeader *header, int iNetcode, int iDelay)
{
	struct ShcmsgWithSegment networkMsg;
	int eventId;

	int totalLen = header->truelength();
	memcpy(&networkMsg.msg, &(header->msg), sizeof(struct shcmsg));
	if (totalLen > sizeof(struct shcmsg)) //segments present
		memcpy(&networkMsg.segmentData, &(header->segment), sizeof(networkMsg.segmentData));
	
	//strcpy(networkMsg.msg.issuer, header->msg.acquirer);
	//strcpy(networkMsg.msg.acquirer, header->msg.acquirer);
	//strcpy(networkMsg.msg.originator, shc_orgid);
	istsafe_strcpy(networkMsg.msg.issuer, sizeof(networkMsg.msg.issuer), header->msg.acquirer);
	istsafe_strcpy(networkMsg.msg.acquirer, sizeof(networkMsg.msg.acquirer), header->msg.acquirer);
	istsafe_strcpy(networkMsg.msg.originator, sizeof(networkMsg.msg.originator), shc_orgid);
	networkMsg.msg.netcode = iNetcode;
	networkMsg.msg.msgtype = SHC_NETWORK;
	networkMsg.msg.trace = header->msg.trace+100000;
	
	networkMsg.msg.format_code[0]='B';
	networkMsg.msg.format_code[1]='P';
	networkMsg.msg.pin_index='1';

	strcpy(networkMsg.msg.acquirer_data, euNetTimerFlag);
	eventId = tm_enqueue(netid, time(0)+iDelay, TM_NOTIFY_ONCE, 1,	
					 (char *)&networkMsg, 
					 header->truelength(&networkMsg.msg));
	tm_setflags(eventId, TM_NOSAVE, 1);
	mb_getUmi(networkMsg.msg.shclog_id, sizeof(networkMsg.msg.shclog_id));
	mb_set_tid(networkMsg.msg.shclog_id, strlen(networkMsg.msg.shclog_id));
	OTraceLog("L-SHC-10754: Created message ID[%s] m%04d/n%d\n", 
		networkMsg.msg.shclog_id, networkMsg.msg.msgtype, networkMsg.msg.netcode);
	OTraceInfo( "I-SHCNET-107007: A 0800 message[%d] created for sending after %d sec. EventId=%d\n" \
			, iNetcode, iDelay, eventId);

	//R028271 >>>
	TxnStatReport(networkMsg.msg.shclog_id,TS_SHC,TSR_CREATE,networkMsg.msg.msgtype,0,0);
	//<<< R028271
	return 0;
}
/* R008781 << */

/*
 *	Network handler for the shared cash system
 *
 *	ALL Network Actions occure against the issuer!!!!!!
 */
 
#define KEY_LEN			16
#define CHK_LEN			4

extern	struct tm shc_local_date;	


/*
 *	Functional routines
 */
int ShcNetworkMsgHelper::net_signoff(ShcmsgHeader *header)
{
	/*
	 *	o	Kill any stfwd replay currently happening
	 */
	net_stopreplay(header);										/* 10002243 */

	/*
	 *	o	Unset any key exchange flags
	 */
	/*
	 *	o	Set him down
	 */
	if (header->msg.auth_devcap | NET_DEVCAP_AUTH_SIGNOFF_TYPE_BIN)
	{
		header->issShcBin->setInstDown();
		OTraceDebug("D-SHC-107077:Mark bin (%s) down\n", header->issShcBin->binPkg->bin.networkid);
		return (0);
	}

    struct RoutingInfo routingInfo = {0};
    int len = sizeof(struct RoutingInfo);
    header->getSegmentData((char *)&routingInfo, &len, NETWORK_DATA_REQ_id,ROUTING_INFO);
	if ((len <= 0)&&(header->msg.unit > 0))
	{
		char *p = mbMailBoxName(header->msg.unit);
		if (p)
		{
			strcpy(routingInfo.port, p);
			OTraceDebug("D-SHC-107060:set route[%s] down\n", p);
		}
		else
			OTraceError("D-SHC-107059:unit[%d] is not a valid mailbox down\n", header->msg.unit);
	}
	else
	{
		OTraceDebug("D-SHC-107061:set route[%s] down\n", routingInfo.port);
	}

	struct InstitutionProfile ip = { 0 };
	len = sizeof(ip);
	header->getSegmentData((char *)&ip, &len, NETWORK_DATA_REQ_id, ISS_INST_PROFILE_ENTRY);
	if (len > 0)
	{
		istsafe_strcpy(getRouteEntriesBinrouteGroup, sizeof(getRouteEntriesBinrouteGroup),ip.binrouteGroup);
	}
	else
		OTraceDebug("D-SHC-107071:No binroute group info found.\n");



	int ret=binRouteObj->markRouteDown(header->issShcBin->binPkg->bin.networkid, &routingInfo, NULL);
	if (ret<=0)
		header->issShcBin->setInstDown();

	/*
	 *	o	Now send a message asking to shut down
	 */
	return(0);
}


int ShcNetworkMsgHelper::net_signon(register ShcmsgHeader *header)
{

	int ret=0;
	/*
	 *	Start the sign on procedure for this institution
	 */
	
	/*
	 *	Check if up or down
	 */
	if(!shc_isdown(header->issShcBin->binPkg))
		/*	Not down: We have nothing to do */
		return(0);

	/*
	 *	Check if already in the sign on phase
	 */
	if((header->issShcBin->binPkg->bin.flags & SH_KEY_EXCHANGE) && shcIsRequest(header))
		/*
		 *		Already attempting sign on 
		 */
		return(0);
	
	/*
	 *	o	Check if keys must be exchanged
	 */
	/* LS R002195 to inherit the function from IST 3.1.1 */
	/* R005616 Added check if key exchange allowed */

	if(header->reqMsg != NULL)
	{
		if(header->reqMsg->to_acct != 0)
			header->msg.to_acct = header->reqMsg->to_acct;
		if(header->reqMsg->from_acct != 0)
			header->msg.from_acct = header->reqMsg->from_acct;
		if(header->reqMsg->unit != 0)
			header->msg.unit = header->reqMsg->unit;
	}
	OTraceDebug("D-SHC-107099: In net_signon : unit value is [%d] \n",header->msg.unit);

	if((header->issShcBin->binPkg->bin.bintype & SH_USES_KEYS) &&
	   (header->issShcBin->binPkg->bin.bintype & SH_ALLOW_KEY_EXCHANGE))
	{
		if( shcIsRequest(header) || ((shcIsResponse(header)) && 
				header->msg.respcode == SHC_RC_Approved ))
		{
			if (header->msg.from_acct & RETURN_RESP_TO_SENDER)
			{
				header->shcerr = SH_RETURN;
				header->msg.senderid =  header->msg.to_acct;
			}
			if (header->issShcBin->binPkg->bin.bintype	& SH_USES_PIN_KEY)
			{	
				if( (ret = shc_network_xchg(header, SH_KEYTYPE_PIN)) <= 0)
					return 0;
				else if(shcIsAsynchSecMode() && (ret==SEC_ASYNCH_WAIT))
				{	// Asynchronous Response
					return(SEC_ASYNCH_WAIT);
				} 
			} 
			else if (header->issShcBin->binPkg->bin.bintype & SH_USES_MAC_KEY) 
			{ 	
				if(( ret = shc_network_xchg(header, SH_KEYTYPE_MAC)) <= 0)
					return 0;
				else if(shcIsAsynchSecMode() && (ret==SEC_ASYNCH_WAIT))
				{	
					// Asynchronous Response
					return(SEC_ASYNCH_WAIT);
				}
			}
			else if( header->msg.respcode == SHC_RC_Approved )
			{
				header->msg.netcode = SHC_NET_DONE_KEY;
				net_continue_signon(header);
				return 0;
			}
		}
	}
	//R030424 >>>
	if(header->msg.respcode != SHC_RC_Approved )
	{
		OTraceDebug("D-SHC-107002.0: Declined Signon response received. Do not bring the bin(route) UP.\n");
		if(header->msg.from_acct & RETURN_RESP_TO_SENDER)
		{
			header->shcerr = SH_RETURN;
			header->msg.senderid = header->msg.to_acct;
		}
		return(0);
	}
	//R030424 <<<

	if(net_startreplay(header) > 0 ) /* R001283 */
	{
			OTraceDebug("D-SHC-107002: Start Replay\n");
	}

	/*	Bring up the Bin, R004294 */
	net_setinstup(header);

	return(0);
}


int ShcNetworkMsgHelper::net_setinstup(ShcmsgHeader *header)
{
	header->issShcBin->setInstUp();
	return ( 0 );
}





int ShcNetworkMsgHelper::net_continue_signon(ShcmsgHeader *header)
{
	/*
	 *	The process of sign on requires several steps.
	 *	As each step is finished the task responsible sends us an 800
	 *	telling us to continue with the next step
	 */
	int	next_step;	

	/*
	 *	o	Determine the current state and from this the next state
	 */
	if(header->msg.netcode == SHC_NET_DONE_KEY ||
	   header->issShcBin->binPkg->bin.flags & SH_KEY_EXCHANGE)
		next_step = 0;
	else
		return(0);
	
	header->issShcBin->binPkg->bin.flags &= ~SH_KEY_EXCHANGE;
	net_setinstup(header);

	return( 0 );
}


int ShcNetworkMsgHelper::net_startreplay(register ShcmsgHeader *header)
{
	/*
	 *	Start replay for an institution
	 *	Note that the institution does NOT need to be down for this to
	 *	happen.
	 */

	char 	buf[128];

	
	/*
	 *	o	Replay for those institutions not in interleave allowed
	 *		only when they are down. This is because the switch is not
	 *		prepared to handle SAF transactions for this type of institution
	 *		while it is still up.
	 */
	if(!shc_isdown(header->issShcBin->binPkg) &&
					(header->issShcBin->binPkg->saf.type & SH_SAF_FORCE_DOWN))
		return(0);
	
	/*
	 *	Otherwise start the replay
	 */


	/*
	 *	o	Mark the bin as in replay
	 */
//	header->issShcBin->binPkg->bin.flags |= SH_REPLAY;

	return( 1 );
}


int ShcNetworkMsgHelper::net_stopreplay(ShcmsgHeader *header)
{
	/*
	 *	o	Kill any stfwd replay currently happening
	 */
	char	buf[128];

	return(0);
}


/* 7oct97 > */
int ShcNetworkMsgHelper::shcnet_exchange_request( ShcmsgHeader *header, char status )
{
	struct shckey_buf keybuf = {0};
	static const char* fnDesc = "ShcNetworkMsgHelper::shcnet_exchange_request";
	struct shckey_buf *ptrKey;
	char savclass = 0;
	int ret=0;

	if(keyXchgMsgHelpObj==NULL)
		keyXchgMsgHelpObj = new KeyXchgMsgHelper();

	savclass = header->msg.format_code[0];
	OTraceDebug( "D-SHC-027042 shcnet_exchange_request value of class =%c\n", savclass );
    /*
     *  Generate the proper key exchange process
     */

    ptrKey=&keybuf;
    ret=keyXchgMsgHelpObj->collect(*this,header,status,savclass);
	if (ret < 0)
		goto final;
    if((ret=keyXchgMsgHelpObj->preProc(*this,header,ptrKey,status,savclass))!=-1)
    {
        if(!(header->shcerr & SH_ASYNCH_RESUME))
        {
            ret=keyXchgMsgHelpObj->proc(*this,header,ptrKey,status);
            if(shcIsAsynchSecMode() && (ret==SEC_ASYNCH_WAIT))
            {
                return(ret);
            }
        }
    }

    if((ret!=-1) && (ret!=SHC_RC_MessageFormatError))
        ret=keyXchgMsgHelpObj->resume(*this,header,ptrKey,status,savclass);

	final:
    return( ret < 0? -1:0 );
}

int ShcNetworkMsgHelper::shcnet_exchange_response( ShcmsgHeader *header, char status )
{
	struct shckey_buf keybuf = {0};
	char savclass = 0;
	int  as2805_flag = 0;

	/*
	 *	Accept new key
	 */

	 /* R010153 >>>>>>> */
 	if (header->msg.format_code[0] == SH_KEYTYPE_PIN_ISS)
	{
		savclass = header->msg.format_code[0];
		header->msg.format_code[0] = SH_KEYTYPE_PIN_ACQ;
	}
	else if (header->msg.format_code[0] == SH_KEYTYPE_PIN_ACQ)
	{
		savclass = header->msg.format_code[0];
		header->msg.format_code[0] = SH_KEYTYPE_PIN_ISS;
	}
	/* <<<<<< R010153 */

	if( header->issShcBin->shcnet_keys_init(header, &keybuf) < 0 )
		return( -1 );

	if (header->issShcBin->binPkg->bin.bintype & SH_KEYS_AS2805)
		as2805_flag = 1;

	if( header->msg.respcode != SHC_RC_Approved )
	{
		thisShcApp->shcKeyObj->shc_keys_set_status_as2805(&keybuf, SH_KEYSTAT_INACTIVE, as2805_flag);

		//   EwenJ Message replicate  key is  not active  + new KEY
		if (mbIsDualSite())
		{
			MRApplHelper *mrHelper = NULL;
			if (keybuf.keyp->k.flags[1] == 'S') 
			{
				mrHelper = MRApplHelper::getInstance(IST_MR_SERVICE_NAME_SHCKEYS_SHARED);
			}
			else
			{
				mrHelper = MRApplHelper::getInstance(IST_MR_SERVICE_NAME_SHCKEYS_UNIQUE);
			}
			OCString replService;
			OCString replData;
			mrHelper->getServiceName(replService);
			mrHelper->setData(TAG_SHCKEYS_NEW_STATUS, status);
			if ( mrHelper->flattenData(replData) == -1 )
			{
				mrHelper->reset();
			}
			else
			{
				header->appendReplicationData(replService.data(), replData.data(), replData.length() );
			}
		}

		if (savclass == SH_KEYTYPE_PIN_ISS || savclass == SH_KEYTYPE_PIN_ACQ)
		{
			header->msg.format_code[0] = savclass;
		}
		else
		{
			header->msg.format_code[0] = keybuf.key_class;
		}
		return( 0 );
	}
	//	>>>	R027124
	else
	{
		char key_type;
		key_type = header->msg.format_code[1];
		thisShcApp->shcDKEApiObj->shc_reset_dynamic_keys(header->issShcBin->binPkg->bin.networkid, key_type);
	}
	//	<<<	R027124

	/* R002203 */
	if( keybuf.akeyp )
	{
		*keybuf.aidxp = keybuf.index - '0';
		keybuf.change = 'T';
	}

	/* R002203 */
	if( keybuf.ikeyp )
	{
		*keybuf.iidxp = keybuf.index - '0';
		keybuf.change = 'T';
	}

	//  EwenJ Message replcaie status active and new key

	thisShcApp->shcKeyObj->shc_keys_set_status_as2805(&keybuf, status, as2805_flag);

	if (mbIsDualSite())
	{
		MRApplHelper *mrHelper = NULL;
		if (keybuf.keyp->k.flags[1] == 'S') 
		{
			ShcKeysMRHelper::getInstance()->setMRDataShared(&keybuf, NULL, NULL, status);
			mrHelper = MRApplHelper::getInstance(IST_MR_SERVICE_NAME_SHCKEYS_SHARED);
		}
		else
		{
			ShcKeysMRHelper::getInstance()->setMRDataUnique(&keybuf, status);
			mrHelper = MRApplHelper::getInstance(IST_MR_SERVICE_NAME_SHCKEYS_UNIQUE);
		}

		OCString replService;
		OCString replData;
		mrHelper->getServiceName(replService);
		mrHelper->setData(TAG_SHCKEYS_NEW_STATUS, status);
		if ( mrHelper->flattenData(replData) == -1 )
		{
			mrHelper->reset();
		}
		else
		{
			header->appendReplicationData(replService.data(), replData.data(), replData.length() );
		}
	}

	/* R010153 >>>>> */
	if (savclass == SH_KEYTYPE_PIN_ISS || savclass == SH_KEYTYPE_PIN_ACQ)
	{
		header->msg.format_code[0] = savclass;
	}
	else
	{
		header->msg.format_code[0] = keybuf.key_class;
	}
	/* <<<<< R010153 */
	return( 0 );
}
/* 7oct97 < */


/*	----------- Essa:	17Feb93 ---------------- */
int ShcNetworkMsgHelper::net_send_enter_SI(ShcmsgHeader *header)
{
	if(header->msg.netcode == SHC_NET_ENTER_SI)
		/*	setup needed values */
		thisShcApp->shcNetworkMsgHelperObj->net_initialise_message(header);
	return ( 0 );
}

int ShcNetworkMsgHelper::net_send_exit_SI(ShcmsgHeader *header)
{
	if(header->msg.netcode == SHC_NET_EXIT_SI)
		/*	setup needed values */
		net_initialise_message(header);

	return ( 0 );
}
/*	-------------------------------------------- */


int ShcNetworkMsgHelper::net_echo_test(ShcmsgHeader *header)
{
	if(header->msg.netcode == SHC_NET_ECHO_START)
		/*	setup needed values */
		net_initialise_message(header);
		
	return ( 0 );	
}


int ShcNetworkMsgHelper::net_initialise_message(ShcmsgHeader *header)
{

	if (header->msg.trandate <= 0)
	{
		header->msg.trandate = shc_gmt_currentdate();
		header->msg.trantime = shc_gmt_currenttime();
	}

	int recreateRefnum = 0;
	if(header->msg.trace <= 0)
	{
		header->msg.trace = shc_generate_uni_trace();
		recreateRefnum = 1;
	}
//		header->msg.trace = time( NULL ) % 1000000L;
//		header->msg.trace = time((long *)0) % 1000000L;
	
	if(header->msg.settlement_date == 0)
		header->msg.settlement_date = shc_local_currentdate();

	if((header->msg.refnum[0] == '\0')||recreateRefnum)
		snprintf(header->msg.refnum, sizeof(header->msg.refnum),"%01d%03d%02d%06ld", 
			shc_local_date.tm_year % 10,
			(shc_local_date.tm_yday + 1) % 1000, /* R002193 */
			header->msg.trantime / 10000,
			header->msg.trace % 1000000L);
		
	return ( 0 );	
}

/* LS R002195 to simulate the same function with IST 3.1.1*/
int ShcNetworkMsgHelper::shc_network_xchg(ShcmsgHeader *header, char keyflag)
{
	struct  shcsecurity *keyp = NULL; 
	int keytype;
	int ret=0;

	static const char* fnDesc = "ShcNetworkMsgHelper::shc_network_xchg";
	OTraceDebug("D-SHC-027042 %s KeyFlag[%d]\n", fnDesc, keyflag );

	header->shcerr = SH_IGNORE;

	ShcmsgHeader tmpHeader(*header);

	shcApp->shcKeyObj->shc_keys_init();

	shcApp->shckeyParamsList = (ShckeyParamsList *)shcApp->shckeyParams.getInst(
		tmpHeader.issShcBin->binPkg->bin.institutionid);

	if(shcApp->shcKeyObj->shc_keys_set_class(tmpHeader.msg.format_code[0], tmpHeader.msg.format_code) <0)
	{
		OTraceError("E-SHC-107094: Invalid key class [x%X]\n", (int)tmpHeader.msg.format_code[0]);
		return -1;
	}
	if(!(tmpHeader.issShcBin->binPkg->bin.bintype & SH_ALLOW_KEY_EXCHANGE))
	{
		OTraceError("E-SHC-107004: The BIN:(%s) does not support dynamic key exchange\n", tmpHeader.issShcBin->binPkg->bin.networkid);
			return (-1);
    	}

	if(tmpHeader.issShcBin->binPkg->bin.flags & SH_KEY_EXCHANGE)
    	{
			OTraceError("E-SHC-107005: the BIN %s is currently in key exchange [%x]\n", header->issShcBin->binPkg->bin.networkid,
				(tmpHeader.issShcBin->binPkg->bin.flags & SH_KEY_EXCHANGE));
        	return(-1);
    	}

	if(!tmpHeader.issShcBin->key)
    	{
			OTraceError("E-SHC-107006:  BIN:(%s) does not have any key parm configured\n", tmpHeader.issShcBin->binPkg->bin.networkid);
			return (-1);
    	}
	else
		keyp = tmpHeader.issShcBin->key;
		keytype = tmpHeader.issShcBin->binPkg->bin.bintype;

	shc_get_current_date();

	InstitutionProfile instProfile = { 0 };
	int len = sizeof(struct InstitutionProfile);
	header->getSegmentData((char *)&instProfile, &len, NETWORK_DATA_REQ_id, ISS_INST_PROFILE_ENTRY);
	if (len <= 0)
	{
		len = sizeof(struct InstitutionProfile);
		header->getReqSegmentData((char *)&instProfile, &len, NETWORK_DATA_REQ_id, ISS_INST_PROFILE_ENTRY);
	}
	if (len > 0)
	{
		tmpHeader.setSegmentData((char *)&instProfile, len, NETWORK_DATA_REQ_id, ISS_INST_PROFILE_ENTRY);
	}

	struct RoutingInfo r = {0};
	len = sizeof(r);
	header->getSegmentData((char *)&r, &len,  NETWORK_DATA_REQ_id, ROUTING_INFO);
	if (len <= 0)
	{
		len = sizeof(r);
		header->getReqSegmentData((char *)&r, &len,  NETWORK_DATA_REQ_id, ROUTING_INFO);
	}
	if (len > 0)
		tmpHeader.setSegmentData((char*)&r, sizeof(r), NETWORK_DATA_REQ_id, ROUTING_INFO);


   	if((keytype & SH_USES_PIN_KEY)&&(keyflag==SH_KEYTYPE_PIN))
   	{

		OTraceDebug("D-SHC-107007: Change PIN Key\n");

		if (tmpHeader.msg.format_code[0] == SH_KEYTYPE_PIN_ACQ)   /* R010153 */
			tmpHeader.msg.pin_index = '0' + keyp->k.isspinidx;
		else
			tmpHeader.msg.pin_index = '0' + keyp->k.acqpinidx;

		thisShcApp->shcKeyObj->shckeys_getnext_index(tmpHeader.issShcBin->binPkg->bin.institutionid, &(tmpHeader.msg.pin_index));


		tmpHeader.msg.format_code[1] = SH_KEYTYPE_PIN;

		ret=shcnet_exchange_request(&tmpHeader, SH_KEYSTAT_EXCHANGE);
		if(shcIsAsynchSecMode() && (ret==SEC_ASYNCH_WAIT))
		{	// Asynchronous Response
			return(SEC_ASYNCH_WAIT);
		}
		if (ret>=0)
			shc_network_build_request(&tmpHeader);


   	}
   	else if((keytype & SH_USES_MAC_KEY)&&(keyflag==SH_KEYTYPE_MAC))
   	{
		OTraceDebug("D-SHC-107008: Change MAC Key\n");

		
		if ( tmpHeader.msg.format_code[0] == SH_KEYTYPE_PIN_ACQ )   /* R010153 */
			tmpHeader.msg.mac_index = '0' + keyp->k.issmacidx;
		else
			tmpHeader.msg.mac_index = '0' + keyp->k.acqmacidx;

		thisShcApp->shcKeyObj->shckeys_getnext_index(tmpHeader.issShcBin->binPkg->bin.institutionid, &(tmpHeader.msg.mac_index));

		tmpHeader.msg.format_code[1] = SH_KEYTYPE_MAC;	

		ret = shcnet_exchange_request(&tmpHeader, SH_KEYSTAT_EXCHANGE);
		if(shcIsAsynchSecMode() && (ret==SEC_ASYNCH_WAIT))
		{	// Asynchronous Response
			return(SEC_ASYNCH_WAIT);
		}
		if (ret>=0)
			shc_network_build_request(&tmpHeader);

   	}
	return(-1);
}

/* LS R002195 */
int ShcNetworkMsgHelper::shc_network_build_request(ShcmsgHeader *header)
{

#if 0
// Commented this code to avoid duplicate response for sign-on message  
	if( shcIsRequest(header) && header->msg.netcode == SHC_NET_SIGNON)
	{
		OTraceDebug("D-SHC-107075: In shc_network_build_request \n");	
		/* return signon message regardless */
		thisShcApp->shcmsgHelperObj->shc_set_return_msgno(&header->msg);

		if(cache_mb_write(header->msg.senderid, netid, (char *)&header->msg,
			header->truelength()) < 0)    // R010418
		{
			OTraceLog("L-SHC-107048: Failed to send msg ID[%s] /m%04d/n%d to %s\n",
				header->msg.shclog_id, header->msg.msgtype, header->msg.netcode, mbMailBoxName(header->msg.senderid));
			//R028271 >>>
			//TxnStatReport(header->msg.shclog_id,TS_SHC,TSR_DROP,DROP_MBWRITE_ERROR,0,header->msg.senderid);
			//<<< R028271
			return(-1);
		}
		else
			OTraceLog("L-SHC-107050: Sent msg ID[%s] /m%04d/n%d to %s\n",
				header->msg.shclog_id, header->msg.msgtype, header->msg.netcode, mbMailBoxName(header->msg.senderid));
	}
#endif
	OTraceDebug("D-SHC-107075: In shc_network_build_request \n");	
	if( header->msg.respcode == SHC_RC_Approved )	/* LS 25nov98 */
	{
		/*	Create an 800 message to hold the key */
		header->msg.msgtype = SHC_NETWORK;
		header->msg.netcode = SHC_NET_KEYS_START;
		header->msg.origtrace = header->msg.trace;
		header->msg.origtrace = header->msg.trace;
		header->msg.trace = shc_generate_uni_trace();   // R010489
		mb_getUmi(header->msg.shclog_id, sizeof(header->msg.shclog_id));
		mb_set_tid(header->msg.shclog_id, strlen(header->msg.shclog_id));
		OTraceLog("L-SHC-10755: Created message ID[%s] m%04d/n%d\n", 
			header->msg.shclog_id, header->msg.msgtype, header->msg.netcode);
		//R028271 >>>
		TxnStatReport(header->msg.shclog_id,TS_SHC,TSR_CREATE,header->msg.msgtype,0,0);
		//<<< R028271
		if ( thisShcApp->shcmsgTxnHelperObj->enqueueInternalMsg(header) == NULL )
			OTraceError("E-SHC-107076: Unable to enqueueInternalMsg() 800 Message, SHC_NET_KEYS_START\n");
	}
	else
		header->shcerr = SH_IGNORE;
	return(0);
}

/* LS R002195 */
int ShcNetworkMsgHelper::shcnet_continue_signon(ShcmsgHeader *header)
{
	header->shcerr = SH_IGNORE;
	if( header->msg.respcode == SHC_RC_Approved )
	{
		header->msg.netcode = SHC_NET_DONE_KEY;
		net_continue_signon(header);
		shcnet_exchange_response(header, SH_KEYSTAT_ACTIVE);
	}
	else
		shcnet_exchange_response(header, SH_KEYSTAT_INACTIVE);
	return(0);
}


/* R002195 to allow to send key request from switch */
int ShcNetworkMsgHelper::shc_network_keys_req(ShcmsgHeader *header)
{
	char fn[30]="shc_network_keys_req";
	ShcBin *shcBin;

	if(!(header->issShcBin->binPkg->bin.bintype & SH_ALLOW_KEY_EXCHANGE))
	{
		OTraceError("E-SHC-107010: The BIN:(%s) does not support dynamic key exchange\n", header->issShcBin->binPkg->bin.networkid);
			return (-1);
    	}

	shc_get_current_date();

	if( shcIsRequest(header) && header->msg.netcode == SHC_NET_SIGNON)
	{
		/* return signon message regardless */
		thisShcApp->shcmsgHelperObj->shc_set_return_msgno(&header->msg);
		shcBin = header->issShcBin;

		if(cache_mb_write(shcBin->binPkg->bin.mailbox, netid, (char *)&header->msg,
			header->truelength()) < 0)    // R010418
		{
			OTraceLog("L-SHC-107051: Failed to send msg ID[%s] /m%04d/n%d to %s\n",
				header->msg.shclog_id, header->msg.msgtype, header->msg.netcode, mbMailBoxName(shcBin->binPkg->bin.mailbox));
			return(-1);
		}
		else
			OTraceLog("L-SHC-107052: Sent msg ID[%s] /m%04d/n%d to %s\n",
				header->msg.shclog_id, header->msg.msgtype, header->msg.netcode, mbMailBoxName(shcBin->binPkg->bin.mailbox));
	}
	/*	Create an 800 message to initialise the request */
	header->msg.msgtype = SHC_NETWORK;
	header->msg.netcode = SHC_NET_KEYREQ_START;
	header->msg.trace = shc_generate_uni_trace();
	mb_getUmi(header->msg.shclog_id, sizeof(header->msg.shclog_id));
	mb_set_tid(header->msg.shclog_id, strlen(header->msg.shclog_id));
	OTraceLog("L-SHC-10756: Created message ID[%s] m%04d/n%d\n", 
		header->msg.shclog_id, header->msg.msgtype, header->msg.netcode);

	//R028271 >>>
	TxnStatReport(header->msg.shclog_id,TS_SHC,TSR_CREATE,header->msg.msgtype,0,0);
	//<<< R028271
	return(0);
}

#define SMGTRACE "GTRC"
#define SMGTRACE_SIZE sizeof(int);
/* R002397 This function can only be used when ONLY one shcnet process is running*/
long ShcNetworkMsgHelper::shc_generate_uni_trace()
{
	static int trace_gen_method = -1;

	if (trace_gen_method < 0)
	{
		char        xbuf[256]= { 0 };
		trace_gen_method = 1;

		if( cf_openfile("...") < 0 )
		{
			OTraceWarning("W-SHC-10758: Configuration file not present.\n");
		}
		else
		{
			 if (cf_locate("shc.800trace_gen_method_frm_SHM_Counter", xbuf) >= 0)
			 {
				if ( toupper(xbuf[0]) == 'Y' || xbuf[0] == '1' )
					trace_gen_method = 1;
				else	
					trace_gen_method = 0;
			 }
			 else
				trace_gen_method = 0;

			 OTraceInfo("I-SHC-10759:shc.800trace_gen_method_frm_SHM_Counter <%d>\n", trace_gen_method);
			 cf_close();
		}
	}

	if ( trace_gen_method)
	{
		OTraceDebug("D-SHC-10757:Trace generation using SHM counter \n");
		static  unsigned int *uni_trace = NULL;
		static int initialized = 0;
		static int gentrace_semid;
		static int gentrace_smid;
		static int nodeId;

		if (!initialized)
		{
			if((gentrace_semid = sem_create(SMGTRACE, 1)) == -1)
			gentrace_semid = sem_connect(SMGTRACE, 1);
			if(gentrace_semid == -1)
			{
				log_msg(FATAL, TO_CC | TO_STDOUT,
				"Unable to create/connect to GENTRACE semaphore %s\n", SMGTRACE);
			}
			sem_acquire(gentrace_semid);

			int totalShmSize = SMGTRACE_SIZE;
			gentrace_smid = sh_getmem(SMGTRACE, totalShmSize, 1);
			if(gentrace_smid == -1)
			{
				sleep(1);
				gentrace_smid = sh_getmem(SMGTRACE, 0, 0);
			}
			if( gentrace_smid == -1)
			{
				log_msg(FATAL,TO_CC|TO_STDOUT,
				"Unable to create/attach to memory:%s Errno:%d\n", SMGTRACE, errno);
			}

			/* Attached to share memory. */
			uni_trace = (unsigned int *)sh_attach(gentrace_smid);

			if( ! uni_trace )
			{
				log_msg(FATAL,TO_CC|TO_STDOUT,
				"Unable to attach to memory:%s Errno:%d\n"
				"Check if memory was created by another user.\n", SMGTRACE, errno);

			}
			nodeId = getNodeId_mb();
			if (nodeId <= 0)
			nodeId = 1;
			initialized = 1;
		}
		else
			sem_acquire(gentrace_semid);

		int trace = nodeId%10*100000 + (*uni_trace)%100000;
		*uni_trace = *uni_trace + 1;
		sem_release(gentrace_semid);

		return(trace);
		}
		else
		{
			static int tracePrefix = -1;
			static int lastTrace = -1;
			if ((tracePrefix < 0)||(lastTrace%10000==0))
			{
				tracePrefix = Cglobal_seq_ctrl::Instance()->get_next_seq ( "TraceNumberPrefix", 1 );
				tracePrefix = tracePrefix%100;
				lastTrace = tracePrefix*10000+1;
			}
			return(lastTrace++);
		}
}



/* R004557 test if this message generated by current switch */
int ShcNetworkMsgHelper::istSelfResponse( ShcmsgHeader *header )
{
	if( shcIsResponse(header) )
	{
		struct	ShcWithSegment onetmsg = {0}; 
		if( (header->eventId = tm_locate(shcApp->shcmsgHelperObj->shcMakeKey(header), -1)) >= 0 )
		{
			tm_getdata(header->eventId, (char *)&(onetmsg.shc).msg, sizeof((onetmsg.shc).msg));
			strcpy(header->msg.originator, (onetmsg.shc).msg.originator );
			header->msg.senderid = (onetmsg.shc).msg.senderid;			/* R007395 */

			if( strcmp((onetmsg.shc).msg.originator, shc_orgid) != 0 )
				return ( -1 );
		}
	}
	return ( 0 );
}

int ShcNetworkMsgHelper::isOldKey( struct shckey_buf *keybufp, ShcmsgHeader *header )
{
	int i;
	if (header->msg.mac.chk[0] && (memcmp(&header->msg.acquirer_data[(header->msg.pin_index-'1')*4], header->msg.mac.chk, 4)==0))
	{
		OTraceDebug("D-SHC-107073:index[%c] is new key.\n", header->msg.pin_index);
		//This is the new key just changed
		return 0;
	}
	if (header->msg.mac.chk[0] && (memcmp(&header->msg.issuer_data[(header->msg.pin_index-'1')*4], header->msg.mac.chk, 4)==0))
	{
		OTraceDebug("D-SHC-107074:index[%c] is new key.\n", header->msg.pin_index);
		//This is the new key just changed
		return 0;
	}
	if (keybufp->aidxp)
	{
	if (keybufp->achkp && (memcmp(&header->msg.acquirer_data[(header->msg.pin_index-'1')*4], keybufp->achkp, 4)==0))
		return 1;
	}
	if (keybufp->iidxp)
	{
		if (keybufp->ichkp && (memcmp(&header->msg.issuer_data[(header->msg.pin_index-'1')*4], keybufp->ichkp, 4)==0))
			return 1;
	}
	return 0;
}

int ShcNetworkMsgHelper::processKeyGracePeriod( ShcmsgHeader *header )
{
	if (header->msg.format_code[0] == SH_KEYTYPE_PIN_ISS)
	{
		header->msg.format_code[0] = SH_KEYTYPE_PIN_ACQ;
	}
	else if (header->msg.format_code[0] == SH_KEYTYPE_PIN_ACQ)
	{
		header->msg.format_code[0] = SH_KEYTYPE_PIN_ISS;
	}

	if ((header->msg.pin_index >=1) && (header->msg.pin_index <=3))
		header->msg.pin_index += '0';
	else if ((header->msg.pin_index <'0') || (header->msg.pin_index >'3'))
		header->msg.pin_index = '1';
	OTraceDebug("D-SHC-107098:new key has index[%c]\n", header->msg.pin_index);
	int i;
	int as2805_flag = 0;
	struct shckey_buf keybuf = {0};
	char acqCheckDigit[sizeof(header->msg.acquirer_data)];
	char issCheckDigit[sizeof(header->msg.issuer_data)];
	memcpy(acqCheckDigit, header->msg.acquirer_data, 12);
	memcpy(issCheckDigit, header->msg.issuer_data, 12);

	if (header->issShcBin->binPkg->bin.bintype & SH_KEYS_AS2805)
		as2805_flag = 1;

	for(i=0;i<3;i++)
	{
		header->msg.pin_index--;
		if (header->msg.pin_index < '1')
		header->msg.pin_index = '3';
		header->msg.mac_index = header->msg.pin_index;
		header->issShcBin->shcnet_keys_init(header, &keybuf);
		if ( 	(keybuf.astatp && (*keybuf.astatp == SH_KEYSTAT_ACTIVE)) ||
				(keybuf.istatp && (*keybuf.istatp == SH_KEYSTAT_ACTIVE))
		)
		{
			//copy the old check digits back
			memcpy(header->msg.acquirer_data, acqCheckDigit,  min((unsigned long)12, sizeof(header->msg.acquirer_data)));
			memcpy(header->msg.issuer_data, issCheckDigit, min((unsigned long)12, sizeof(header->msg.issuer_data)));
			if (isOldKey(&keybuf, header))
			{
				shcApp->shcKeyObj->shc_keys_set_status_as2805(&keybuf, SH_KEYSTAT_INACTIVE, as2805_flag);
				if (mbIsDualSite())
				{
					if (keybuf.keyp->k.flags[1] == 'S')
						ShcKeysMRHelper::getInstance()->sendKey(&keybuf, keybuf.akeyp?keybuf.akeyp:keybuf.ikeyp,
							keybuf.achkp?keybuf.achkp:keybuf.ichkp, keybuf.astatp?*keybuf.astatp:*keybuf.istatp);
					else
					{
						MRApplHelper *mrHelper = MRApplHelper::getInstance(IST_MR_SERVICE_NAME_SHCKEYS_UNIQUE);
						OCString replService;
						OCString replData;
						mrHelper->getServiceName(replService);
						if ( mrHelper->flattenData(replData) == -1 )
						{
							mrHelper->reset();
						}
						else
						{
							header->appendReplicationData(replService.data(), replData.data(), replData.length() );
						}
					}

				}

				OTraceDebug("D-SHC-107097:changing KEY status to inactive for index[%c] type[%c]\n", header->msg.pin_index, header->msg.format_code[0]);
			}
		}
	}

	return( 0 );
}


/* R004833 --> */
int ShcNetworkMsgHelper::shcnet_keys_response( ShcmsgHeader *header )
{
	struct	ShcWithSegment onetmsg = {0}; /* LS R002185 */
	int ret=0;
	OTraceDebug( "D-SHC-107098 shcnet_keys_response begin processing\n");
	if( (header->eventId = tm_locate(shcApp->shcmsgHelperObj->shcMakeKey(header), -1)) >= 0 )
	{
		OTraceDebug( "D-SHC-107098 shcnet_keys_response event located respcode=%d, uses_pin_key=%d, uses_mac=%d\n",
						header->msg.respcode,
						(header->issShcBin->binPkg->bin.bintype & SH_USES_PIN_KEY),
						(header->issShcBin->binPkg->bin.bintype & SH_USES_MAC_KEY)
					);
		/* LS R002185 */
		tm_getdata(header->eventId,(char *) &(onetmsg.shc).msg, sizeof((onetmsg.shc).msg));
		header->msg.format_code[0] = (onetmsg.shc).msg.format_code[0];
		header->msg.format_code[1] = (onetmsg.shc).msg.format_code[1];
		header->msg.pin_index = (onetmsg.shc).msg.pin_index;
		header->msg.mac_index = (onetmsg.shc).msg.mac_index;
		//tm_dequeue(header->eventId);

		if ( ( (header->issShcBin->binPkg->bin.bintype & SH_USES_PIN_KEY) && 
			(header->issShcBin->binPkg->bin.bintype & SH_USES_MAC_KEY) ) || 
			header->issShcBin->binPkg->bin.bintype & SH_KEYS_AS2805
		)	
		{
			if (header->msg.format_code[1] == SH_KEYTYPE_PIN )
			{
				if (header->msg.respcode == SHC_RC_Approved )
				{
					OTraceDebug( "D-SHC-107098 shcnet_keys_response marking key as active\n");
					shcnet_exchange_response(header, SH_KEYSTAT_ACTIVE);
					if( !(header->issShcBin->binPkg->bin.bintype & SH_KEYS_AS2805) )
						ret = shc_network_xchg(header, SH_KEYTYPE_MAC);
					if(shcIsAsynchSecMode() && (ret==SEC_ASYNCH_WAIT))
					{	// Asynchronous Response
						return(SEC_ASYNCH_WAIT);
					}
					header->shcerr = SH_IGNORE;
				}
				else
				{
					shcnet_exchange_response(header, SH_KEYSTAT_INACTIVE);
					header->shcerr = SH_IGNORE;
				}
			}
			else if (header->msg.format_code[1] == SH_KEYTYPE_MAC)
			{
				/* continue signon */
					shcnet_continue_signon(header);
			}
		}
		else if  (header->issShcBin->binPkg->bin.bintype & SH_USES_PIN_KEY)  
		{
			if (header->msg.format_code[1] =='P')
			{
					shcnet_continue_signon(header);
			}
		}
		else if  (header->issShcBin->binPkg->bin.bintype & SH_USES_MAC_KEY)  
		{
				shcnet_continue_signon(header);
		}
		/* end of R002185 */	
	}
	return ( 0 );
}
/* <-- R004833 */

int ShcNetworkMsgHelper::shcCreateEvent(ShcmsgHeader *header)
{
	//Setting Timers for Asynch Mode Request
	if ( header->time_out == 0 )
	{
		thisShcApp->shcTimerObj->shc_set_timers(header);
	}

	if (header->time_out < 10000000000)
	{
        header->eventId = tm_enqueue(thisShcApp->netid,
				     header->time_out,
           			     TM_NOTIFY_ONCE,
				     shcApp->shcmsgHelperObj->shcMakeKey(header),
           			     (char *)&header->msg,
				     header->truelength() + CAM_RESULT_LEN );
 	}
	else
	{
		 header->eventId = tm_hires_enqueue(thisShcApp->netid,
			header->time_out/1000, header->time_out%1000*1000000,
           			     TM_NOTIFY_ONCE,
				     shcApp->shcmsgHelperObj->shcMakeKey(header),
           			     (char *)&header->msg,
				     header->truelength() + CAM_RESULT_LEN );
	}
	tm_setflags(header->eventId, TM_NOSAVE, 1);
	return(0);
}

int ShcNetworkMsgHelper::checkIssuer(ShcmsgHeader *header)
{
	if (header->acqBinValid() && header->issBinValid())
		return 0;
	if (header->msg.issuer[0])
	{
		if(thisShcApp->shcmsgHelperObj->shcGetIssAcq(header, 0) < 0)
		{
			OTraceError("E-SHCNET-107008: Invalid network transaction: Code: %d issuer %s\n", 
				header->msg.respcode, header->msg.issuer);
			return(-1);
		}
	}
	return 0;
}

int ShcNetworkMsgHelper::setOrigData(ShcmsgHeader *header)
{
	if(!shcIsResponse(header))
	{
		header->msg.origtime = header->msg.trantime;
		header->msg.origdate = header->msg.trandate;
	}
	return 0;
}

int ShcNetworkMsgHelper::processTwoWaySignOn(ShcmsgHeader *header)
{

	/*
		*	Two way key signon is initiated by the other party
		*		1.	Issuer sends a 800 signon
		*		2.	IST responds with 810 and initiates an 800 signon
		*		3.	Issuer responds with 810 approved. This marks the end of signon
		*  The bin cannot be brought up still as key exchange is pending.
	*/
	int ret = -1;

	OTraceDebug("D-SHCNET-107013: processing two way signon\n" );
	//only as2805 is supported
	if( !(header->issShcBin->binPkg->bin.bintype & SH_KEYS_AS2805) )
	{
		OTraceDebug("D-SHCNET-107014: two way key signon only supported for AS2805 keys\n" );
		return -1;
	}

	if ( shcIsRequest(header) && header->msg.netcode == SHC_NET_SIGNON )
	{
		OTraceInfo("I-SHCNET-107015: Routing response to SENDER, formatter_use [%s]\n", header->msg.formatter_use );
		char krs[MAX_KEYLEN+1] = {0};
		char krr[MAX_KEYLEN+1] = {0};
		int formatter_use_len = 0;

		strncpy(krs, (const char *)header->msg.formatter_use, 16);
		strncpy(krr, (const char *)header->msg.formatter_use + 16, 16);

		/* Prepare Random KRs and KRr */
		struct shcsecurity *keyparam;
		int ikeyparam = -1;
		InstitutionProfile instProfile = { 0 };
		int len = sizeof(struct InstitutionProfile);

		strcpy(instProfile.keyparamStr,  header->issShcBin->binPkg->bin.networkid );
		header->getReqSegmentData((char *)&instProfile, &len, NETWORK_DATA_REQ_id, ISS_INST_PROFILE_ENTRY);

		if (len <= 0)
		{
			NetworkInfo networkInfo;
			shcApp->instProfileObj->locateNetworkInfo(header->msg.txnSrc, header->msg.txnDest,
					header->msg.iss_entityId, header->msg.msgtype, header->msg.issuer, networkInfo);

			if (networkInfo.foundNetworkInfo())
			{
				header->setSegmentData((char *)networkInfo.getInstProfileEntry(),
						sizeof(struct InstitutionProfile), NETWORK_DATA_REQ_id, ISS_INST_PROFILE_ENTRY);
				if(rm_isMultiVerSupported(0))
					keyparam = networkInfo.getKey();
				else
					ikeyparam = networkInfo.getKeyparam();
				thisShcApp->shcmsgHelperObj->addRoutingInfoSegment( header, networkInfo );
			}
			else
				keyparam = shcApp->shcKeyObj->getKey(instProfile.instId, instProfile.keyparamStr);
		}
		else
		{
			if(rm_isMultiVerSupported(0))
				keyparam = shcApp->shcKeyObj->getKey(instProfile.instId, instProfile.keyparamStr);
			else
				ikeyparam = instProfile.keyparm;
		}

		if(keyparam == NULL)
		{
			OTraceError("E-SHC-107029: keyparam value is NULL.Can't proceed further..\n");
			header->msg.respcode = SHC_RC_SystemError;
			header->shcerr = SH_IGNORE;
			return -1;
		}
		/* In response 0810, send KRr in formatter_use */
		strncpy( (char *)krs,   (char *)header->msg.formatter_use,      16);
		OTraceInfo("I-SHCNET-107264: Processing AS2805 SignOn Request from Network to IST krs[%s], krs_len[%d]\n",
								krs, strlen(krs) );
		OTraceInfo("I-SHCNET-107270: call verify_as2805randomkey_by_kekr()\n");
		if(verify_as2805randomkey_by_kekr(keyparam->k.acqkek, keyparam->k.kek_len, krs, strlen(krs), krr)<=0)
		{
			OTraceError("E-SHC-107030: verify_as2805randomkey_by_kekr verification failed.\n");
			header->msg.respcode = SHC_RC_SystemError;
			header->shcerr = SH_IGNORE;
			return -1;
		}
//		call verify_as2805randomkey_by_kekr is not async. verify_as2805randomkey_by_kekr does not have a return statement.
//      cannot check return.
//		if( shcIsAsynchSecMode() && (ret == SEC_ASYNCH_WAIT) )
//			return ret;

		memcpy((char *)header->msg.formatter_use, krr, 16);
		memcpy((char *)header->msg.formatter_use + 16, krs, 16);
		formatter_use_len = strlen((char *)header->msg.formatter_use);
		header->setSegmentData((char *)header->msg.formatter_use, formatter_use_len, ElfIdMap::elf_to_id(IST_SEG_NETWORK_DATA_REQ), KEYBLOCK_KEY);

		//enqueue SHC_NET_SIGNON_START
		ShcmsgHeader tmpHeader(*header);
		if( header->issShcBin )
			strcpy(tmpHeader.msg.txnSrc, header->issShcBin->binPkg->bin.institutionid);
		else
			tmpHeader.msg.txnSrc[0] = '\0';
	    tmpHeader.msg.msgtype = SHC_NETWORK;
	    tmpHeader.msg.netcode = SHC_NET_SIGNON_START;
		tmpHeader.msg.origtrace = header->msg.trace;
	    tmpHeader.msg.origtrace = header->msg.trace;
		tmpHeader.msg.pan[0] = '\0';
	    tmpHeader.msg.trace = shc_generate_uni_trace();   // R010489
		mb_getUmi(tmpHeader.msg.shclog_id, sizeof(tmpHeader.msg.shclog_id));
		mb_set_tid(tmpHeader.msg.shclog_id, strlen(tmpHeader.msg.shclog_id));
		OTraceDebug("D-SHCNET-107301: two way signon message - created message ID[%s] m%04d/n%d\n",
					tmpHeader.msg.shclog_id, tmpHeader.msg.msgtype, tmpHeader.msg.netcode);
		TxnStatReport(tmpHeader.msg.shclog_id,TS_SHC,TSR_CREATE,tmpHeader.msg.msgtype,0,0);
		if ( thisShcApp->shcmsgTxnHelperObj->enqueueInternalMsg( &tmpHeader ) == NULL )
			OTraceError("E-SHCNET-107302: Unable to enqueue internal message, SHC_NET_SIGNON_START\n");

		header->shcerr = SH_RETURN;
		thisShcApp->shcmsgHelperObj->shc_set_return_msgno(&header->msg);
		header->msg.respcode = SHC_RC_Approved;
	}
	else if ( shcIsRequest(header) && header->msg.netcode == SHC_NET_SIGNON_START )
	{
		OTraceDebug("I-SHCNET-107303: two way signon message initiate from IST to network\n" );
		char krs[MAX_KEYLEN+1] = {0};
		char krr[MAX_KEYLEN+1] = {0};
		int formatter_use_len = 0;

		/* Prepare Random KRs and KRr */
		struct shcsecurity *keyparam;
		int ikeyparam = -1;
		InstitutionProfile instProfile = { 0 };
		int len = sizeof(struct InstitutionProfile);

		strcpy(instProfile.keyparamStr,  header->issShcBin->binPkg->bin.networkid );
		header->getSegmentData((char *)&instProfile, &len, NETWORK_DATA_REQ_id, ISS_INST_PROFILE_ENTRY);

		if (len <= 0)
		{
			NetworkInfo networkInfo;
			shcApp->instProfileObj->locateNetworkInfo(header->msg.txnSrc, header->msg.txnDest,
					header->msg.iss_entityId, header->msg.msgtype, header->msg.issuer, networkInfo);

			if (networkInfo.foundNetworkInfo())
			{
				header->setSegmentData((char *)networkInfo.getInstProfileEntry(),
						sizeof(struct InstitutionProfile), NETWORK_DATA_REQ_id, ISS_INST_PROFILE_ENTRY);
				if(rm_isMultiVerSupported(0))
					keyparam = networkInfo.getKey();
				else
					ikeyparam = networkInfo.getKeyparam();
				thisShcApp->shcmsgHelperObj->addRoutingInfoSegment( header, networkInfo );
			}
			else
				keyparam = shcApp->shcKeyObj->getKey(instProfile.instId, instProfile.keyparamStr);
		}
		else
		{
			if(rm_isMultiVerSupported(0))
				keyparam = shcApp->shcKeyObj->getKey(instProfile.instId, instProfile.keyparamStr);
			else
				ikeyparam = instProfile.keyparm;
		}
		OTraceDebug("D-SHCNET-107262: Starting to call generate_as2805randomkey_by_keks kek = [%s]\n", keyparam->k.kek);
		generate_as2805randomkey_by_keks(keyparam->k.kek, keyparam->k.kek_len, krs, krr);
//
// 		generate_as2805randomkey_by_keks has no return statement. This needs to be fixed! We cannot check for return value.
//		if( shcIsAsynchSecMode() && (ret == SEC_ASYNCH_WAIT) )
//			return ret;
//
		if( krs[0] == '\0' || krr[0] == '\0' )
		{
			OTraceError( "E-SHCNET-107321 generate_as2805randomkey_by_keks failed\n" );
			header->msg.respcode = SHC_RC_SystemError;
			header->shcerr = SH_IGNORE;
			return -1;
		}

		header->shcerr = SH_SENDISS;
		strncpy( (char *)(header->msg.formatter_use),           krs,    16);
		strncpy( (char *)(header->msg.formatter_use + 16),      krr,    16);

		formatter_use_len = strlen((char *)header->msg.formatter_use);
		header->setSegmentData((char *)header->msg.formatter_use, formatter_use_len, ElfIdMap::elf_to_id(IST_SEG_NETWORK_DATA_REQ), KEYBLOCK_KEY);

		OTraceDebug("D-SHCNET-107322: save send kr and receive kr in formatter_use [%s], krs=[%s], krr[%s]\n",
                                               header->msg.formatter_use, krs, krr );
	}
	else if ( shcIsResponse(header) && header->msg.netcode == SHC_NET_SIGNON )
	{
		if ( header->msg.respcode == SHC_RC_Approved )
		{
			char krr_orig[MAX_KEYLEN+1] = {0};
			char krr[MAX_KEYLEN+1] = {0};
			int krr_len = sizeof(krr);

			header->getSegmentData((char *)krr, &krr_len,  ElfIdMap::elf_to_id(IST_SEG_NETWORK_DATA_RESP), KEYBLOCK_KEY);
			if( krr_len > 0 )
			{
				istsafe2_strcpy( krr_orig, sizeof(krr_orig), (const char*)header->msg.formatter_use+16 );
				if ( strcmp( krr_orig, krr) != 0 )
				{
					header->msg.respcode = SHC_RC_KeyValidationError;
				}
			}
			else
			{
				header->msg.respcode = SHC_RC_KeyValidationError;
			}

			OTraceDebug("D-SHCNET-107322: validate krr with orig krr, formatter_use [%s], krr_orig=[%s], krr[%s]\n",
						header->msg.formatter_use, krr_orig, krr );

			if( header->msg.respcode == SHC_RC_KeyValidationError )
			{
				OTraceDebug("D-SHCNET-107310: two way signon, proof of endpoint failed. initiate sign off\n");
				header->shcerr = SH_IGNORE;

				//enqueue SHC_NET_SIGNOFF_START
				ShcmsgHeader tmpHeader(*header);
				if( header->issShcBin )
					strcpy(tmpHeader.msg.txnSrc, header->issShcBin->binPkg->bin.institutionid);
				else
					tmpHeader.msg.txnSrc[0] = '\0';
				tmpHeader.msg.msgtype = SHC_NETWORK;
				tmpHeader.msg.netcode = SHC_NET_SIGNOFF_START;
				tmpHeader.msg.origtrace = header->msg.trace;
				tmpHeader.msg.origtrace = header->msg.trace;
				tmpHeader.msg.from_acct = 0;
				istsafe2_strcpy( tmpHeader.msg.originator, sizeof(tmpHeader.msg.originator), shc_orgid );
				tmpHeader.msg.pan[0] = '\0';
				tmpHeader.msg.trace = shc_generate_uni_trace();   // R010489
				mb_getUmi(tmpHeader.msg.shclog_id, sizeof(tmpHeader.msg.shclog_id));
				mb_set_tid(tmpHeader.msg.shclog_id, strlen(tmpHeader.msg.shclog_id));
				OTraceDebug("D-SHCNET-107311: two way signon failure, signoff created, message ID[%s] m%04d/n%d\n",
							tmpHeader.msg.shclog_id, tmpHeader.msg.msgtype, tmpHeader.msg.netcode);
				TxnStatReport(tmpHeader.msg.shclog_id,TS_SHC,TSR_CREATE,tmpHeader.msg.msgtype,0,0);
				if ( thisShcApp->shcmsgTxnHelperObj->enqueueInternalMsg( &tmpHeader ) == NULL )
					OTraceError("E-SHCNET-107312: Unable to enqueue internal message, SHC_NET_SIGNOFF_START\n");
				return 0;
			}
			OTraceDebug("D-SHCNET-107310: two way signon completed. proof of endpoint done. initiate key exchange\n");

			ShcmsgHeader tmpHeader(*header);
			tmpHeader.msg.msgtype = SHC_NETWORK;
			tmpHeader.msg.netcode = SHC_NET_KEYS_START;
			tmpHeader.msg.origtrace = header->msg.trace;
			tmpHeader.msg.origtrace = header->msg.trace;
			tmpHeader.msg.format_code[0] = SH_KEYTYPE_PIN_ISS;
			tmpHeader.msg.format_code[1] = SH_KEYTYPE_PIN;
			tmpHeader.msg.pan[0] = '\0';
			if( header->issShcBin )
				strcpy(tmpHeader.msg.txnSrc, header->issShcBin->binPkg->bin.institutionid);
			else
				tmpHeader.msg.txnSrc[0] = '\0';
			tmpHeader.msg.trace = shc_generate_uni_trace();   // R010489
			mb_getUmi(tmpHeader.msg.shclog_id, sizeof(tmpHeader.msg.shclog_id));
			mb_set_tid(tmpHeader.msg.shclog_id, strlen(tmpHeader.msg.shclog_id));
			OTraceDebug("D-SHCNET-107320: two way signon message - created message ID[%s] m%04d/n%d\n",
						tmpHeader.msg.shclog_id, tmpHeader.msg.msgtype, tmpHeader.msg.netcode);
			TxnStatReport(tmpHeader.msg.shclog_id,TS_SHC,TSR_CREATE,tmpHeader.msg.msgtype,0,0);
			if( shc_send_800(&tmpHeader, header->issShcBin) < 0 )
				OTraceError("D-SHCNET-107321: Unable to send message, SHC_NET_SIGNON_START\n");
		}
		else if(header->msg.respcode != SHC_RC_Approved )
		{
			OTraceDebug("D-SHCNET-107311: two way signon failed. Response declined respcode=[%d]\n",
						header->msg.respcode );
		}

		header->shcerr = SH_IGNORE;
	}

	return 0;
}

int ShcNetworkMsgHelper::processSignOn(ShcmsgHeader *header)
{
	/*
	 *	Sign on is a three part process
	 *		1.	perform key exchange if needed
	 *		2.	perform replay if needed
	 *		3.	mark him as up
	 */
	OTraceInfo("I-SHCNET-107009: Sign on %s for %s\n",
		(shcIsResponse(header) ? "response" : "request"),
		header->issShcBin->binPkg->bin.networkid);

	if(shcIsResponse(header))
	{
		if (header->msg.from_acct & RETURN_RESP_TO_SENDER)
		{
			header->shcerr = SH_RETURN;
			header->msg.senderid =  header->msg.to_acct;
		}
	}

	//	>>>	R029938
	//if( header->msg.netcode != SHC_NET_SIGNON_START )
	if(!((header->msg.netcode)/1000 == 9))
		net_signon(header);
	//	<<<	R029938

	/* This is for a AS2805 signon request from network  */
	if ( !shcIsResponse(header) && (header->issShcBin->binPkg->bin.bintype & SH_KEYS_AS2805) )
	{
		OTraceInfo("I-SHCNET-107015: Routing response to SENDER, formatter_use [%s]\n", header->msg.formatter_use );
		char krs[MAX_KEYLEN+1] = {0};
		char krr[MAX_KEYLEN+1] = {0};
		int formatter_use_len = 0;

		strncpy(krs, (const char *)header->msg.formatter_use, 16);
		strncpy(krr, (const char *)header->msg.formatter_use + 16, 16);

		/* Prepare Random KRs and KRr */
		struct shcsecurity *keyparam;
		int ikeyparam = -1;
		InstitutionProfile instProfile = { 0 };
		int len = sizeof(struct InstitutionProfile);

		strcpy(instProfile.keyparamStr,  header->issShcBin->binPkg->bin.networkid );

		if (shcIsRequest(header))
			header->getSegmentData((char *)&instProfile, &len, NETWORK_DATA_REQ_id, ISS_INST_PROFILE_ENTRY);
		else
			header->getReqSegmentData((char *)&instProfile, &len, NETWORK_DATA_REQ_id, ISS_INST_PROFILE_ENTRY);

		if (len <= 0)
		{
			NetworkInfo networkInfo;
			shcApp->instProfileObj->locateNetworkInfo(header->msg.txnSrc, header->msg.txnDest,
					header->msg.iss_entityId, header->msg.msgtype, header->msg.issuer, networkInfo);

			if (networkInfo.foundNetworkInfo())
			{
				header->setSegmentData((char *)networkInfo.getInstProfileEntry(),
						sizeof(struct InstitutionProfile), NETWORK_DATA_REQ_id, ISS_INST_PROFILE_ENTRY);
				if(rm_isMultiVerSupported(0))
					keyparam = networkInfo.getKey();
				else
					ikeyparam = networkInfo.getKeyparam();
				thisShcApp->shcmsgHelperObj->addRoutingInfoSegment( header, networkInfo );
			}
			else
				keyparam = shcApp->shcKeyObj->getKey(instProfile.instId, instProfile.keyparamStr);
		}
		else
		{
			if(rm_isMultiVerSupported(0))
				keyparam = shcApp->shcKeyObj->getKey(instProfile.instId, instProfile.keyparamStr);
			else
				ikeyparam = instProfile.keyparm;
		}

		// >>>> AS2805 Signon

		header->shcerr = SH_SENDISS;
		net_initialise_message(header);

		if (header->msg.netcode == SHC_NET_SIGNON_START)
		{
			/* in request 0800, send KRs and KRr in formatter_use */
			OTraceInfo("I-SHCNET-107264: Processing AS2805 SignOn from IST to Network\n");
			OTraceInfo("I-SHCNET-107262: Starting to call generate_as2805randomkey_by_keks kek = [%s]\n", keyparam->k.kek);
			generate_as2805randomkey_by_keks(keyparam->k.kek, keyparam->k.kek_len, krs, krr);

			strncpy( (char *)(header->msg.formatter_use),           krs,    16);
			strncpy( (char *)(header->msg.formatter_use + 16),      krr,    16);

		}
		else if (header->msg.netcode == SHC_NET_SIGNON)
		{
			/* In response 0810, send KRr in formatter_use */
			strncpy( (char *)krs,   (char *)header->msg.formatter_use,      16);
			OTraceInfo("I-SHCNET-107264: Processing AS2805 SignOn Request from Network to IST.\n");
			OTraceInfo("I-SHCNET-107270: call verify_as2805randomkey_by_kekr()\n");
			verify_as2805randomkey_by_kekr(keyparam->k.acqkek, keyparam->k.kek_len, krs, strlen(krs), krr);
			memcpy((char *)header->msg.formatter_use, krr, 16);
			memcpy((char *)header->msg.formatter_use + 16, krs, 16);
		}
		formatter_use_len = strlen((char *)header->msg.formatter_use);
		header->setSegmentData((char *)header->msg.formatter_use, formatter_use_len, ElfIdMap::elf_to_id(IST_SEG_NETWORK_DATA_REQ), KEYBLOCK_KEY);
	}
	// <<<< AS2805

	/*	in all cases this transaction gets routed to the inst. */
	if( ! shcIsResponse(header) )
	{
                    /* 10002122 */
		if( strcmp(header->issShcBin->binPkg->bin.networkid, shc_orgid) != 0 
			&& (header->msg.netcode == SHC_NET_SIGNON_START
				|| header->msg.netcode == SHC_NET_GROUPSIGNON_START
				|| header->msg.netcode == SHC_NET_SIGNON_ISSUER 
			/* LS 9nov98 to handle key exchange after signon*/
			|| header->msg.netcode == SHC_NET_KEYREQ_START
			|| header->msg.netcode == SHC_NET_KEYS_START) )
		{
			/*	signon start implies request from switch */
			header->shcerr = SH_SENDISS;
			net_initialise_message(header);
		}
		else
		{
  			header->shcerr = SH_RETURN;
			thisShcApp->shcmsgHelperObj->shc_set_return_msgno(&header->msg);
		}

		header->msg.respcode = 0;
	}
	else if( istSelfResponse(header) < 0 )  /* R004557 */
	{
		OTraceInfo("I-SHCNET-107010: Routing response to SENDER\n" );
		header->shcerr = SH_RETURN;		/* R007395 */
	}
	
	return 0;
}

int ShcNetworkMsgHelper::processDoneKey(ShcmsgHeader *header)
{
	OTraceInfo("I-SHCNET-107011:  Key exchange (%s) done for %s\n",
		(shcIsResponse(header) ? "response" : "request"),
		 header->issShcBin->binPkg->bin.networkid);
	return 0;
}

int ShcNetworkMsgHelper::processSignOff(ShcmsgHeader *header)
{
	OTraceInfo("I-SHCNET-107012:  Sign off %s for %s\n",
		(shcIsResponse(header) ? "response" : "request"),
		header->issShcBin->binPkg->bin.networkid);

	net_signoff(header);

	if(header->msg.netcode == SHC_NET_MARKDOWN)
		header->shcerr = SH_IGNORE;

	else if(!shcIsResponse(header))
	{
		/* 27Sep94 */
		/* 10002122 */
		if( strcmp(header->issShcBin->binPkg->bin.networkid, shc_orgid) != 0 
			&& ( header->msg.netcode == SHC_NET_SIGNOFF_START
				|| header->msg.netcode == SHC_NET_GROUPSIGNOFF_START || header->msg.netcode == SHC_NET_SIGNOFF_ISSUER || header->msg.netcode == SHC_NET_HOST_SESSION_DEACT ) )
		{
			header->shcerr = SH_SENDISS;
			net_initialise_message(header);
		}
		else
		{
  			header->shcerr = SH_RETURN;
			thisShcApp->shcmsgHelperObj->shc_set_return_msgno(&header->msg);

			/* Europay auto SignOn at 30 seconds after force sign-off by Europay - R004833 */
			if ( thisShcApp->shcmsgHelperObj->shc_isEuroNet(header) \
				&& strcmp(header->msg.originator, shc_orgid) != 0 \
				&& header->msg.netcode == SHC_NET_SIGNOFF )	
			{
				shc_euNetTimer(header, SHC_NET_SIGNON_START, 1);
				ODebug( "I-SHCNET-107013: Got Forced signoff from EPS-Net, auto signon in 30 Sec.\n" );
			}
		}
	}
	else if( istSelfResponse(header) < 0 ) 	/* R004557 */
	{
		OTraceInfo("I-SHCNET-107014: Routing response to SENDER\n" );
		header->shcerr = SH_RETURN;		/* R007395 */
	}
	
	if (header->msg.from_acct & RETURN_RESP_TO_SENDER)
	{
		header->shcerr = SH_RETURN;
		header->msg.senderid =  header->msg.to_acct;
	}
	
	return 0;
}

int ShcNetworkMsgHelper::processKeyStart(ShcmsgHeader *header)
{	
	int ret=0;
	OTraceInfo("I-SHCNET-107015: Network keys internal %s for %s\n",
		(shcIsResponse(header) ? "response" : "request"),
		header->issShcBin->binPkg->bin.networkid);

	if( shcIsRequest(header) && !header->createdInternal())
	{
		/* R002397 >> */
		if (header->msg.trace== (-1))
			header->msg.trace = shc_generate_uni_trace(); 
		/* R002397 << */

        /* R009651 */
		if(header->msg.settlement_date == 0)
			header->msg.settlement_date = shc_local_currentdate();

		ret = shcnet_exchange_request(header, SH_KEYSTAT_EXCHANGE);
		if (ret < 0)
		{
			OTraceError("E-SHC-107100:Key exchange dropped\n");
			header->shcerr = SH_IGNORE;
			return 0;
		}
		if(shcIsAsynchSecMode())
		{	// Asynchronous Response
			if(ret==SEC_ASYNCH_WAIT)
			{
				return(SEC_ASYNCH_WAIT);
			}
			// Asynchronous Resume
			else if(header->shcerr & SH_ASYNCH_RESUME)
			{ // M0800 was logged, no need to log it again
				 header->logFlag = 0;
			}
		}

		if( header->msg.respcode == SHC_RC_Approved )
		{
			header->msg.netcode = SHC_NET_KEYS;

			// Keep flags for Asynch Mode
			if(header->shcerr & SH_ASYNCH_RESUME)
				header->shcerr |= SH_SENDISS;

			// If not use regular flag
			else
				header->shcerr = SH_SENDISS;
		}
		else  //  This is  to log 810  on error
		{
			thisShcApp->shcmsgHelperObj->shc_set_return_msgno(&header->msg);
			header->shcerr = SH_IGNORE;
			if(header->msg.from_acct & RETURN_RESP_TO_SENDER)
			{
				header->shcerr = SH_RETURN;
				header->msg.senderid = header->msg.to_acct;
			}
		}
	}
	else if (header->createdInternal())
	{
		header->msg.netcode = SHC_NET_KEYS;
		header->shcerr = SH_SENDISS;
	}
	return 0;
}

int ShcNetworkMsgHelper::processKey(ShcmsgHeader *header)
{
	int ret=0;
	OTraceInfo("I-SHCNET-107016: Network keys %s for %s\n",
		(shcIsResponse(header) ? "response" : "request"),
		header->issShcBin->binPkg->bin.networkid);

	if(header->reqMsg != NULL)
	{
		if(header->reqMsg->to_acct != 0)
			header->msg.to_acct = header->reqMsg->to_acct;
		if(header->reqMsg->from_acct != 0)
			header->msg.from_acct = header->reqMsg->from_acct;
		if(header->reqMsg->unit != 0)
			header->msg.unit = header->reqMsg->unit;
	}
	OTraceDebug("D-SHC-107100: In processKey : unit value is [%d] \n",header->msg.unit);

	if( shcIsRequest(header) )
	{
		ret = shcnet_exchange_request(header, SH_KEYSTAT_ACTIVE);
		if(shcIsAsynchSecMode() && (ret==SEC_ASYNCH_WAIT))
		{	// Asynchronous Response
			return(SEC_ASYNCH_WAIT);
		}
		thisShcApp->shcmsgHelperObj->shc_set_return_msgno(&header->msg);
		header->shcerr = SH_RETURN;
		if( (header->issShcBin->binPkg->bin.bintype & SH_KEYS_AS2805) && (header->msg.respcode == SHC_RC_Approved) )
		{
			OTraceDebug("D-SHC-107100: two way signon: network's key exchange request is good, bring bin up\n" );
			if(net_startreplay(header) > 0 ) /* R001283 */
			{
				OTraceDebug("D-SHC-107002: start replay for bin\n");
			}
			net_setinstup(header);
		}
		if( (ret == SHC_RC_Approved) && (header->msg.respcode == SHC_RC_Approved) && (header->msg.netcode == SHC_NET_KEYS || header->msg.netcode == SHC_NET_DONE_KEY))
		{
			OTraceDebug("D-SHC-107104: Key exchange request handled successfully, PIN Key timer reset.\n" );
			thisShcApp->shcDKEApiObj->shc_reset_pinkey_timer(header->issShcBin->binPkg->bin.networkid);
		}
	}
	else if( shcIsResponse(header) )
	{
		if ((header->msg.respcode == SHC_RC_Approved) && 
			(strncmp((char *)header->msg.formatter_use,"KEY_XCHG_SUCESS_1LEG",20)==0))
		{
			shcnet_keyxchg_request_2leg(header);
		}
		else
		{
			if (header->msg.netcode == SHC_NET_KEYS_REQ_SINGLE_LEG && header->msg.respcode == SHC_RC_Approved )
			{
				ret = shcnet_exchange_request(header, SH_KEYSTAT_ACTIVE);
				if(shcIsAsynchSecMode() && (ret==SEC_ASYNCH_WAIT))
				{	// Asynchronous Response
					return(SEC_ASYNCH_WAIT);
				}
			}
			else
				shcnet_keys_response(header);		/* R004833 composed a new function and moved to shc_netmgr.cxx */
			if (header->msg.from_acct & RETURN_RESP_TO_SENDER)
			{
				header->shcerr = SH_RETURN;
				header->msg.senderid =  header->msg.to_acct;
			}
		}
		if (
			(header->issShcBin->binPkg->bin.bintype & SH_KEYS_AS2805)  &&
			(header->msg.respcode == SHC_RC_Approved) &&
			(header->msg.netcode == SHC_NET_KEYS)
		)
		{
			char kvc_resp[12+1] = {0};
			char kvc_req[12+1] = {0};

			OTraceDebug( "D-SHC-107103 contents of response kvc= %s, len=%d\n", header->msg.filler3,
							istsafe2_strlen(header->msg.filler3, sizeof(header->msg.filler3)) );

			OTraceDebug( "D-SHC-107103 contents of request kvc = %s, len=%d\n", header->msg.filler4,
							istsafe2_strlen(header->msg.filler4, sizeof(header->msg.filler4)) );


			if( istsafe2_strlen(header->msg.filler3, sizeof(header->msg.filler3)) >= 12 )
			{
				strncpy( kvc_resp, header->msg.filler3, 12 );
				kvc_resp[12] = '\0';
			}

			if( istsafe2_strlen(header->msg.filler4, sizeof(header->msg.filler4)) >= 12 )
			{
				strncpy( kvc_req, header->msg.filler4, 12 );
				kvc_req[12] = '\0';
			}

			if( strncmp(kvc_req, kvc_resp, 12) == 0  )
			{
				OTraceDebug("D-SHC-107100: two way signon: got approval for ist's key, wait for key exchange from network\n" );
				thisShcApp->shcDKEApiObj->shc_reset_pinkey_timer(header->issShcBin->binPkg->bin.networkid);
				thisShcApp->shcDKEApiObj->shc_reset_mackey_timer(header->issShcBin->binPkg->bin.networkid);
			}
			else
			{
				OTraceDebug("D-SHCNET-107310: key exchange kvc validaition failed. initiate sign off\n");
				header->shcerr = SH_IGNORE;
				shcnet_exchange_response(header, SH_KEYSTAT_INACTIVE);
				//enqueue SHC_NET_SIGNOFF_START
				ShcmsgHeader tmpHeader(*header);
				if( header->issShcBin )
					strcpy(tmpHeader.msg.txnSrc, header->issShcBin->binPkg->bin.institutionid);
				else
					tmpHeader.msg.txnSrc[0] = '\0';
				tmpHeader.msg.msgtype = SHC_NETWORK;
				tmpHeader.msg.netcode = SHC_NET_SIGNOFF_START;
				tmpHeader.msg.origtrace = header->msg.trace;
				tmpHeader.msg.from_acct = 0;
				istsafe2_strcpy( tmpHeader.msg.originator, sizeof(tmpHeader.msg.originator), shc_orgid );
				tmpHeader.msg.origtrace = header->msg.trace;
				tmpHeader.msg.pan[0] = '\0';
				tmpHeader.msg.trace = shc_generate_uni_trace();   // R010489
				mb_getUmi(tmpHeader.msg.shclog_id, sizeof(tmpHeader.msg.shclog_id));
				mb_set_tid(tmpHeader.msg.shclog_id, strlen(tmpHeader.msg.shclog_id));
				OTraceDebug("D-SHCNET-107101: key exchange key validation failure, signoff created, message ID[%s] m%04d/n%d\n",
							tmpHeader.msg.shclog_id, tmpHeader.msg.msgtype, tmpHeader.msg.netcode);
				TxnStatReport(tmpHeader.msg.shclog_id,TS_SHC,TSR_CREATE,tmpHeader.msg.msgtype,0,0);
				if ( thisShcApp->shcmsgTxnHelperObj->enqueueInternalMsg( &tmpHeader ) == NULL )
					OTraceError("E-SHCNET-107102: Unable to enqueue internal message, SHC_NET_SIGNOFF_START\n");
				return 0;
			}
		}
		else if((header->msg.respcode == SHC_RC_Approved) && (header->msg.netcode == SHC_NET_KEYS || header->msg.netcode == SHC_NET_DONE_KEY))
		{
			OTraceDebug("D-SHC-107105: Key exchange request handled successfully, PIN Key timer reset.\n" );
			thisShcApp->shcDKEApiObj->shc_reset_pinkey_timer(header->issShcBin->binPkg->bin.networkid);
		}
	}

	int gracePeriod = header->msg.acceptorname[4] - '0';	//In minutes
	if ((header->msg.respcode == SHC_RC_Approved ) && (gracePeriod >  0))
	{
		//Enqueue a event for grace period
		int tmpMsgType = header->msg.msgtype;
		header->msg.msgtype = SHC_KEY_GRACE_PERIOD;
		if (header->reqMsg && header->reqMsg->mac.chk[0])
			memcpy(header->msg.mac.chk, header->reqMsg->mac.chk, sizeof(header->msg.mac.chk));
		int eventId = tm_enqueue(thisShcApp->netid, time(0)+(gracePeriod)*60, TM_NOTIFY_ONCE, KEY_GRACE_PEROID_EVENT_KEY,
		(char *)&header->msg,
		header->truelength());
		OTraceDebug("D-SHC-:event(%d) minutes(%d)created for grace period.\n", eventId,gracePeriod); 
		header->msg.msgtype = tmpMsgType;
	}

	return 0;
}

int ShcNetworkMsgHelper::processKeyValidation(ShcmsgHeader *header)
{
	net_initialise_message(header);
  	if( shcIsResponse(header) )
		OTraceInfo("I-SHCNET-107017: KEY-ON-Demand-Request for inst [%s] will so on start\n", header->issShcBin->binPkg->bin.networkid);
	else
	{
  		OTraceInfo("I-SHCNET-107018: KEY-On-Demand-Request for inst [%s]\n", header->issShcBin->binPkg->bin.networkid);
		if (header->msg.trace== (-1))
			header->msg.trace = shc_generate_uni_trace(); 
		if( strcmp(header->msg.originator, shc_orgid) == 0 )
		{
  			header->shcerr = SH_SENDISS;
		}
		else
		{
			/* this request came from network */
			/* Start key exchanges */
			 if (header->issShcBin->binPkg->bin.bintype & SH_USES_PIN_KEY)
			 {
				_headerFor_shc_send_keyxchg = header;
			 	shc_send_keyxchg(header->issShcBin,
							  SH_KEYTYPE_PIN_BOTH, SH_KEYTYPE_PIN);
			 }
			 if (header->issShcBin->binPkg->bin.bintype & SH_USES_MAC_KEY)
			 {
				_headerFor_shc_send_keyxchg = header;
			 	shc_send_keyxchg(header->issShcBin,
							  SH_KEYTYPE_PIN_BOTH, SH_KEYTYPE_MAC);
			 }
			/* send response */
			thisShcApp->shcmsgHelperObj->shc_set_return_msgno(&header->msg);
			header->shcerr = SH_RETURN;
		}

	}
	return 0;
}

int ShcNetworkMsgHelper::processStartSaf(ShcmsgHeader *header)
{
	net_initialise_message(header);
	if( shcIsResponse(header) )
	{
		OTraceInfo("I-SHCNET-107019: SAF-Request for inst [%s] will soon start\n",
				header->issShcBin->binPkg->bin.networkid);
	}
	else
	{
		OTraceInfo("I-SHCNET-107020: Start SAF for inst [%s] \n",
				header->issShcBin->binPkg->bin.networkid);
		header->shcerr = SH_SENDISS;
	}
	return 0;
}

int ShcNetworkMsgHelper::processStopSaf(ShcmsgHeader *header)
{
	OTraceInfo("I-SHCNET-107021: Stop SAF for inst [%s]\n", 
			header->issShcBin->binPkg->bin.networkid);
	net_initialise_message(header);
	if( !shcIsResponse(header) )
		header->shcerr = SH_SENDISS;
	return 0;
}

int ShcNetworkMsgHelper::processEnterSI(ShcmsgHeader *header)
{
	OTraceInfo("I-SHCNET-107022: Start SI for inst [%s]\n",
			header->issShcBin->binPkg->bin.networkid);
	net_send_enter_SI(header);
	if(!shcIsResponse(header))
		header->shcerr = SH_SENDISS;	/*	same as in ECHO */
	return 0;
}


int ShcNetworkMsgHelper::processExitSI(ShcmsgHeader *header)
{
	OTraceInfo("I-SHCNET-107023: Stop SI for [%s]\n",
			header->issShcBin->binPkg->bin.networkid);

	net_send_exit_SI(header);
	if(!shcIsResponse(header))
		header->shcerr = SH_SENDISS;	/*	same as in ECHO */
	return 0;
}

int ShcNetworkMsgHelper::processEcho(ShcmsgHeader *header)
{
	OTraceInfo("I-SHCNET-107024: Echo test (%s) for %s\n",
		(shcIsResponse(header) ? "response" : "request"),
		header->issShcBin->binPkg->bin.networkid);

	net_echo_test(header);

	if(!shcIsResponse(header))
	{
		/* 10002122 */
		if( strcmp(header->issShcBin->binPkg->bin.networkid, shc_orgid) != 0 
			&& (header->msg.netcode == SHC_NET_ECHO_START || header->msg.netcode == SHC_NET_ECHO_ISSUER) )
		{
			header->shcerr = SH_SENDISS;
		}
		else
		{
			thisShcApp->shcmsgHelperObj->shc_set_return_msgno(&header->msg);
			header->shcerr = SH_RETURN;
		}
	}

	/*	03mar93 */
	else
	{
		/*	Is this from the echo manager ? */
		struct	ShcWithSegment omsg;
		if(header->msg.trace == USE_REFUM_FOR_EVENT_KEY)
		{
			OTraceDebug("I-SHCNET-107094: Event lookup by decomposing refnum to fetch transaction trace. \n");
			char tmp_refnum[7] = {0};
			istsafe_strcpy(tmp_refnum, sizeof(tmp_refnum), &header->msg.refnum[6]);
			header->msg.trace = atoi(tmp_refnum);
		}

		if((header->eventId = tm_locate(header->msg.trace, -1)) >= 0)
		{
			tm_getdata(header->eventId, (char *)&(omsg.shc).msg, sizeof((omsg.shc).msg));
			header->allocateAndCopyReqMsg(&omsg.shc.msg);
			struct RoutingInfo routingInfo = {0};
			int len = sizeof(routingInfo);
			header->getSegmentData((char *)&routingInfo, &len, NETWORK_DATA_REQ_id,ROUTING_INFO);
			if(len <= 0)
			{
				len = sizeof(routingInfo);
				header->getSegmentData((char *)&routingInfo, &len, NETWORK_DATA_REQ_id,ROUTING_INFO);
			}
			strtrim(routingInfo.port, routingInfo.port);
			if ((len > 0) && (strncmp(routingInfo.port,  mbMailBoxName(header->msg.unit), istsafe_strlen(routingInfo.port, sizeof(routingInfo.port)))!=0))
			{
				OTraceInfo("I-SHC-107094:port name mismatch, routing_info[%s], unit[%s], drop echo msg.\n",
					routingInfo.port, mbMailBoxName(header->msg.unit));
				header->shcerr = SH_IGNORE;
			}
			else
			{
				if(len > 0)
				{
					header->setSegmentData((char*)&routingInfo, sizeof(struct RoutingInfo), NETWORK_DATA_REQ_id,ROUTING_INFO);
				}

				header->msg.senderid = (omsg.shc).msg.senderid;
				//	>>>	R016386
				strcpy(header->msg.txnSrc , (omsg.shc).msg.txnSrc);
				strcpy(header->msg.txnDest , (omsg.shc).msg.txnDest);
				//	<<<	R016386
				header->shcerr = SH_RETURN;
			}
		}
		else //R032382
		{
			//Echo response for an echo initiated manually thru shccmd
			updateBinRoute(header);
		}
	}
	return 0;
}

int ShcNetworkMsgHelper::processAbortKey(ShcmsgHeader *header)
{
	OTraceError("E-SHCNET-107025:  Key exchange failed for %s\n", header->issShcBin->binPkg->bin.networkid);
	header->issShcBin->binPkg->bin.flags &= ~SH_KEY_EXCHANGE;
	return 0;
}

int ShcNetworkMsgHelper::processClose(ShcmsgHeader *header)
{
	OTraceInfo("I-SHCNET-107026: Close request for %s\n", header->issShcBin->binPkg->bin.networkid);

	if(!shcIsResponse(header))
	{
		if(header->msg.netcode == SHC_NET_CLOSE_DAY
		   || header->msg.netcode == SHC_NET_CLOSE_BATCH
		   || header->msg.netcode == SHC_NET_GET_TOTALS)
		{
			thisShcApp->shcmsgHelperObj->shc_set_return_msgno(&header->msg);
			header->shcerr = SH_RETURN;
		}
		else
		{
			net_initialise_message(header);
			header->shcerr = SH_SENDISS;
		}
	}
	return 0;
}

//R027855>>
/**processCutOverRequest:
- broadcast cutover to other nodes ("_cutover_no_db")
- get businessDay record
- update SHM for this record
	- set date by shcmsg
	- set batch ID if (PHC & POS) cutover (=needsBatchIdUpdate())
	- if switch/institution cutover:
		- change batch ID in all IBDs which have MAIN_CUTOVER ='Y' or 'L'
		- send msgs to network, if it is not (POS & PHC) record
- send update DB command to CutoverServer
- if this is force cutover, and is set to 'Y' or 'B', send cutover msg to network 
*/
int ShcNetworkMsgHelper::processCutOverRequest(ShcmsgHeader *header)
{
	if(!shcCutoverHelper)
		shcCutoverHelper = (ShcCutoverHelper *)shcHelperRegister.getTargetObj(SHC_ShcCutoverHelper);
	if(!shcCutoverHelper)
		OTraceFatal("F-SHCNET-0000: Out of memory\n");

	shcCutoverHelper->initialize(thisShcApp, header);

	return shcCutoverHelper->processCutoverRequest();

} /* End of request processing */

int ShcNetworkMsgHelper::processCutOver(ShcmsgHeader *header)
{

	//OTraceInfo("I-SHCNET-107027: Cutover for institution : %s\n", header->msg.txnDest);
	/* Cutover needs following information:
	 * 		1. institution id: in header->msg.txnDest
	 *		2. institution type and device type: in from_acct
	 *		3. new business day: in cap_date
	 *		4. receiving bin (if need to be routed to): in issuer
	 */
	/* FIST_S_072528-19  Create an Signal Event to ISTAUTH for P1C */
	
	if( header->msg.netcode == 202 )
	{
		char IST_S1[128] = {0};
		strcpy(IST_S1, "start to run ist accum");
		int eventId = tm_enqueue(
                                thisShcApp->netid,
                                time(NULL) + 300,
                                TM_NOTIFY_ONCE,
                                97770001L,
                                (char *)IST_S1,
                                strlen(IST_S1) );

        if (eventId >= 0)
                OTraceInfo("I-SHCNET-%04d: shc Network creates event to notify SHC process, eventId=[%d]\n", __LINE__, eventId);
	}

	int tmpFlag = 0;
	if(header->msg.from_acct & RETURN_RESP_TO_SENDER)
	{
		tmpFlag = header->msg.from_acct;
		header->msg.from_acct &= ~RETURN_RESP_TO_SENDER;
	}

	if (header->msg.from_acct == 0)
	{

		net_initialise_message(header);
		if(!shcIsResponse(header))
		{
			if(header->msg.netcode / 1000 != 9)
			{
				thisShcApp->shcmsgHelperObj->shc_set_return_msgno(&header->msg);
				header->shcerr = SH_RETURN;
			}
			else
				header->shcerr = SH_SENDISS;
		}
		if(tmpFlag & RETURN_RESP_TO_SENDER)
		{
			header->msg.from_acct |= RETURN_RESP_TO_SENDER;
		}
	}
	else
	{
		OTraceInfo("I-SHCNET-107027: Cutover for institution [%s] Entity [%s]\n", header->msg.txnDest, header->msg.iss_entityId);
			
		net_initialise_message(header);
		if(tmpFlag & RETURN_RESP_TO_SENDER)
		{
			header->msg.from_acct |= RETURN_RESP_TO_SENDER;
		}
		if(!shcIsResponse(header))
		{
			return processCutOverRequest(header); //R027855 moved to processCutOverRequest
					}
		/* R010436 >> */
		else
		{
		/* Response processing for combined cutover and reconcile message */
			//Remove replicatiion data from cutover response
			if(header->msg.from_acct & RETURN_RESP_TO_SENDER)
			{
				header->shcerr = SH_RETURN;
				header->msg.senderid =  header->msg.to_acct;
			}

			if (header->msg.netcode%1000 == 201)
			{
				IstSegList *sl = header->getSegList();
				static int segid = ElfIdMap::elf_to_id(IST_SEG_MSG_REPLICATION_DATA);
				sl->deleteSegItem(segid);
			}
			try
			{
				if (!(header->msg.from_acct & IST_ROLE_SW))
				{
					shc_send_endofday_recon(header);
				}
			}
			catch (ShcnetCutOverException &e)
			{
				OTraceError("E-SHCNET-107035: Reconcile after cutover interrupted for inst[%s]\n",  header->msg.txnDest);
				return 0;
			}
		}
	}
	/* << R010436 */
	/* Cutover response is just ignored, no need to process */		
	return 0;
}
int ShcNetworkMsgHelper::processKeyReq(ShcmsgHeader *header)
{

    net_initialise_message(header);
    if(!shcIsResponse(header))
    {
        if(header->msg.netcode / 1000 != 9)
        {
            thisShcApp->shcmsgHelperObj->shc_set_return_msgno(&header->msg);
            header->shcerr = SH_SENDACQ;
        }
        else
            header->shcerr = SH_SENDISS;
    }
	return 0;
}

//int ShcNetworkMsgHelper::processTermKey(ShcmsgHeader *header)
//{
//
//	/*  Terminal download request */
//	OTraceInfo("I-SHCNET-107036: Terminal Key Load for %s\n", header->msg.termloc);
//	net_initialise_message(header);
//	if(!shcIsEDC(header))
//	{
//		OTraceError("E-SHCNET-107037: Terminal Key Load: Not EDC Terminal\n");
//		header->msg.respcode = SHC_RC_InvalidTransaction;
//	}
//	else if(header->msg.device_cap & SH_DEVCAP_UPDATE_LOGS)
//		shc_edc_updatekey(header);
//	else
//		shc_edc_generatekey(header);
//
//	thisShcApp->shcmsgHelperObj->shc_set_return_msgno(&header->msg);
//	header->shcerr = SH_RETURN;
//	return 0;
//}

int ShcNetworkMsgHelper::processEuropayReject(ShcmsgHeader *header)
{
	OTraceError( "I-SHCNET-107038: 'SHC_NET_EU_REJECT' reject message.\n" );
	thisShcApp->shcmsgHelperObj->shc_set_return_msgno(&header->msg);
	header->shcerr = SH_RETURN;
	return 0;
}
int ShcNetworkMsgHelper::processOtherMsg(ShcmsgHeader *header)
{
	//	>>>	R020635
	OTraceInfo("I-SHCNET-107039: Unrecognized network code: %d\n", header->msg.netcode);
	if((header->msg.netcode/1000 == 9) && shcIsRequest(header))
	{
		header->shcerr = SH_SENDISS;
	}
	else if(shcIsRequest(header))
	{
		header->msg.respcode = SHC_RC_InvalidTransaction;
		thisShcApp->shcmsgHelperObj->shc_set_return_msgno(&header->msg);
		header->shcerr = SH_RETURN;
	}
	else if(istSelfResponse(header) < 0 )
	{
		OTraceInfo("I-SHCNET-107058: Routing response to SENDER\n" );
		header->shcerr = SH_RETURN;     /* R007395 */
	}
	//	<<<	R020635
	return 0;
}
int ShcNetworkMsgHelper::removeEvent(ShcmsgHeader *header)
{
	if( shcIsResponse(header) )
    {
       if((header->eventId = tm_locate(shcApp->shcmsgHelperObj->shcMakeKey(header), -1)) >= 0)
           tm_dequeue(header->eventId);
	}
	else if (header->msg.origtrace > 0)
	{
		int tmpTrace = header->msg.trace;
		header->msg.trace = header->msg.origtrace;
		if((header->eventId = tm_locate(shcApp->shcmsgHelperObj->shcMakeKey(header), -1)) >= 0)
           tm_dequeue(header->eventId);
		header->msg.trace = tmpTrace;
	}
	return 0;
}



/*------------------------------------------------------------------------*
 * End of file
 *------------------------------------------------------------------------*/


/*
 *	Interface routines to the Network driver
 */

int ShcNetworkMsgHelper::shc_net(ShcmsgHeader *header)
{
	/*
	 *	Interface to the network dirver
	 */
	/*
	 *	o	Determine routing
	 */
	header->shcerr = SH_IGNORE;
	if(thisShcApp->shcmsgHelperObj->shcGetIssAcq(header, 0) == -1)
	{
		OTraceError("E-SHC-107013:Invalid network transaction: Code: %d: iss(%s) acq(%s) org(%s)\n", header->msg.respcode,
			header->msg.issuer, header->msg.acquirer, header->msg.originator);
		return(0);
	}
	shc_send_800(header, header->issShcBin);
	return(0);
}

	
int ShcNetworkMsgHelper::shc_groupdown(ShcmsgHeader *header, ShcBin *shcBin)
{
	/*
	 *	Send a message to the network mail box to
	 *	set this institution down
	 */
	
	if(shc_isdown(shcBin->binPkg))
		return(0);

	shcBin->setInstDown();
	
	return shc_generate_800(header, shcBin, SHC_NET_GROUPSIGNOFF_START);
}

	
int ShcNetworkMsgHelper::shc_setdown(ShcmsgHeader *header, ShcBin *shcBin)
{
	/*
	 *	Send a message to the network mail box to
	 *	set this institution down
	 */
	
	OTraceDebug("D-SHC-107014:  setting bin down\n");
	OTraceDebug("D-SHC-107015:   bin status: %s\n", 
		(shc_isdown(shcBin->binPkg) ? "down" : "up"));

	if(shc_isdown(shcBin->binPkg))
		return(0);

	shcBin->setInstDown();

	return shc_generate_800(header, shcBin, SHC_NET_SIGNOFF_START);
}

int ShcNetworkMsgHelper::shc_markdown(ShcmsgHeader *header, ShcBin *shcBin)
{
	/*
	 *	set this institution down
	 */
	
	OTraceDebug("D-SHC-107017:  marking bin down\n");
	OTraceDebug("D-SHC-107018:   bin status: %s\n", 
		(shc_isdown(shcBin->binPkg) ? "down" : "up"));

	int binStatusChanged = 1;
	
	// R027876 , R028104 >>>
	struct RoutingInfo routingInfo = {0};
	int len = sizeof(struct RoutingInfo);
	header->getSegmentData((char *)&routingInfo, &len, NETWORK_DATA_REQ_id,ROUTING_INFO);
	// <<< R027876, R028104


	
	struct InstitutionProfile ip = { 0 };
	len = sizeof(ip);
	header->getSegmentData((char *)&ip, &len, NETWORK_DATA_REQ_id, ISS_INST_PROFILE_ENTRY);
	if (len > 0)
	{
		istsafe_strcpy(getRouteEntriesBinrouteGroup, sizeof(getRouteEntriesBinrouteGroup),ip.binrouteGroup);
	}
	else
		OTraceDebug("D-SHC-107072:No binroute group info found.\n");

	if (binRouteObj && len )
	{
		binRouteObj->markRouteDown(shcBin->binPkg->bin.networkid, &routingInfo, &binStatusChanged);
		if (binStatusChanged && (!shc_isdown(shcBin->binPkg)))
		{
			shcBin->setInstDown();
		}
	}
	else if ( ! shc_isdown(shcBin->binPkg) )
	{
		shcBin->setInstDown();
	}
	
	return shc_generate_800(header, shcBin, SHC_NET_MARKDOWN);
}

int ShcNetworkMsgHelper::shc_stopreplay(ShcmsgHeader *header, ShcBin *shcBin)
{
	/*
	 *	set this institution down
	 */
	
	OTraceDebug("D-SHC-107020:  stopping replay\n");
	OTraceDebug("D-SHC-107021:   replay status: %s\n", 
		(shcBin->binPkg->bin.flags & SH_REPLAY ? "active" : "stopped"));

	if(!(shcBin->binPkg->bin.flags & SH_REPLAY) )
		return(0);

	return shc_generate_800(header, shcBin, SHC_NET_STOPREPLAY);
}

/* 27Sep94 */
int ShcNetworkMsgHelper::shc_groupup(ShcmsgHeader *header, ShcBin *shcBin)
{
	/*
	 *	Send a message to the network mail box to set the institution up
	 */
	
	return shc_generate_800(header, shcBin, SHC_NET_GROUPSIGNON_START);

}

int ShcNetworkMsgHelper::shc_setup(ShcmsgHeader *header, ShcBin *shcBin)
{
	/*
	 *	Send a message to the network mail box to set the institution up
	 */
	
	return shc_generate_800(header, shcBin, SHC_NET_SIGNON_START);
}


int ShcNetworkMsgHelper::shc_echotest(ShcmsgHeader *header, ShcBin *shcBin)
{
	return shc_generate_800(header, shcBin, SHC_NET_ECHO_START);
}

int ShcNetworkMsgHelper::shc_generate_800( ShcmsgHeader *header, ShcBin *shcBin, int netcode )
{
	ShcmsgHeader h;
	shc_build_800(header, &h.msg, shcBin, netcode);
	shc_send_800(&h, shcBin);
	return(0);
}

int ShcNetworkMsgHelper::shc_build_800(ShcmsgHeader *header, struct shcmsg *msg , ShcBin *shcBin, int code)
{
	/*
	 *	Build an 800 message for transport to the network manager
	 */
	if(header)
	{
		struct RoutingInfo routingInfo = {0};
		int len=sizeof(struct RoutingInfo);
		header->getReqSegmentData((char*)&routingInfo, &len, NETWORK_DATA_REQ_id,ROUTING_INFO);
		if (len > 0)
		{
			header->setSegmentData((char*)&routingInfo, len, NETWORK_DATA_REQ_id,ROUTING_INFO);
		}
		
		InstitutionProfile instProfile = { 0 };
		len = sizeof(struct InstitutionProfile);
		header->getReqSegmentData((char *)&instProfile, &len, NETWORK_DATA_REQ_id, ISS_INST_PROFILE_ENTRY);
		if (len > 0)
		{
			header->setSegmentData((char *)&instProfile, len, NETWORK_DATA_REQ_id, ISS_INST_PROFILE_ENTRY);
		}

		int totalLen=header->truelength();
		memcpy(msg, &header->msg, sizeof(struct shcmsg));
		if (totalLen > sizeof(struct shcmsg)) //segments present
			memcpy(((char *)msg)+sizeof(struct shcmsg), &header->segment, sizeof(header->segment));
		
	}

	strcpy(msg->issuer, shcBin->binPkg->bin.networkid);
	strcpy(msg->acquirer, shcBin->binPkg->bin.networkid);
	msg->netcode = code;
	msg->msgtype = SHC_NETWORK;
	strcpy( msg->originator, shc_orgid );	/* R007395 */
	mb_getUmi(msg->shclog_id, sizeof (msg->shclog_id));
	mb_set_tid( msg->shclog_id, strlen(msg->shclog_id) ) ;
	OTraceLog("L-SHC-107045: Created msg ID[%s] /m%04d/n%d\n",
		msg->shclog_id, msg->msgtype, msg->netcode);
	//R028271 >>>
	TxnStatReport(msg->shclog_id,TS_SHC,TSR_CREATE,msg->msgtype,0,0);
	//<<< R028271
	return(0);
}


int ShcNetworkMsgHelper::shc_send_800(ShcmsgHeader *h, ShcBin *shcBin)
{
	int ret;

	mb_savepacket();
	
	if (!h->msg.shclog_id[0])
	{
		mb_getUmi(h->msg.shclog_id, sizeof(h->msg.shclog_id));
		mb_set_tid( h->msg.shclog_id, strlen(h->msg.shclog_id) ) ;
	}
	if(cache_mb_write(shcBin->binPkg->bin.netmgrid, shcmid, (char *)&h->msg, 
			h->truelength()) < 0) // R010415
	{
		OTraceLog("L-SHC-107047: Failed to send msg ID[%s] /m%04d/n%d to %s\n",
			h->msg.shclog_id, h->msg.msgtype, h->msg.netcode, mbMailBoxName(shcBin->binPkg->bin.netmgrid));

//		TxnStatReport(h->msg.shclog_id,TS_SHC,TSR_DROP,DROP_MBWRITE_ERROR,0,shcBin->binPkg->bin.netmgrid);
		ret = -1;
	}
	else
	{
		ret = 0;
		OTraceLog("L-SHC-107046: Sent msg ID[%s] /m%04d/n%d to %s\n",
			h->msg.shclog_id, h->msg.msgtype, h->msg.netcode, mbMailBoxName(shcBin->binPkg->bin.netmgrid));
	}	
	mb_restorepacket();
	return(ret);
}

/* R010436 >> */

int ShcNetworkMsgHelper::shc_send_endofday_recon( ShcmsgHeader *header)
{
	struct	shc500std	reconcile500;
	int			mbidDest;
	int			merchanttype;
	struct  shcpkg 		*pkg;
	int result = -1;
	int position = -1;
	InstBusinessDay  businessDay;
	char inst_id[11];
	char entityId[11];

	/* First Check if recon is required */
	if (businessDay.getEntryFromMem(header->msg.txnDest,
									header->msg.iss_entityId) < 0)
	{
		OTraceError("E-SHCNET-9540:Can't find businessDay entry inst[%s] Entity[%s]\n",
										header->msg.txnDest,
										header->msg.iss_entityId);
		return (-1);
	}

	businessDay.getInstId(inst_id);
	businessDay.getEntityId(entityId);

	if(!shcCutoverHelper)
		shcCutoverHelper = (ShcCutoverHelper *)shcHelperRegister.getTargetObj(SHC_ShcCutoverHelper);

	shcCutoverHelper->initialize(thisShcApp, header);

	/* member cutover */
	position = shcCutoverHelper->getForceMemberCutoverConfigPosition();

    if (businessDay.getOneCfg(position) == 'B')
	{
		memset( (char *)&reconcile500, 0, sizeof(struct shc500std) );
		reconcile500.msgtype = SHC500_MSG_DAYEND;
		//reconcile500.settlement_date = header->msg.cap_date;
		reconcile500.settlement_date = shc_adjust_date(header->msg.cap_date, -1);
	
		reconcile500.flags = (header->msg.from_acct&IST_ROLE_TYPE_MASK)
			  | (header->msg.from_acct&IST_ROLE_DEVICE_MASK);

		ICInstId_pure(reconcile500.institution_id, header->msg.txnDest);
		//strcpy(reconcile500.entityId , header->msg.iss_entityId );
		istsafe_strcpy(reconcile500.entityId, sizeof(reconcile500.entityId), header->msg.iss_entityId );

		reconcile500.trace = shc_gentrace();
		reconcile500.trandate = shc_local_currentdate();
		reconcile500.trantime = shc_local_currenttime();
    	
		// To Lookup Inst Profile
		IssuerInfo issInfo;
		shc_locate_issuer_from_institution( reconcile500.institution_id, reconcile500.msgtype, issInfo );
		if (!issInfo.foundIssuer())
		{
			OTraceError("E-SHCNET-107040: Can't find issuer for Inst[%s]Entity[%s], dropped!\n", reconcile500.institution_id, reconcile500.entityId);
			return( -1 );
		}
		ICBin_rjfy(reconcile500.issuer, (char *)issInfo.getIssuerBin());
		ICBin_rjfy(reconcile500.acquirer, reconcile500.issuer );
		OTraceDebug("D-SHCNET-107041: Recon: flags[0x%x], networkid[%s] for Inst[%s] Entity [%s]\n", 
				reconcile500.flags, reconcile500.issuer, reconcile500.institution_id,
				reconcile500.entityId);

		if( shc_locate_bin(&pkg, reconcile500.issuer) == -1 ) 
			mbidDest = -1;
		else
			mbidDest = pkg->bin.mailbox;

		if (mbidDest < 0)
		{
			OTraceWarning("W-SHCNET-107042: Unable to locate issuer BIN [%s]\n", reconcile500.issuer);
			return (-2);
		}
	
		mb_getUmi(reconcile500.shclog_id, sizeof (reconcile500.shclog_id));
		mb_set_tid(reconcile500.shclog_id, strlen(reconcile500.shclog_id));

		//R028271 >>>
		TxnStatReport(reconcile500.shclog_id,TS_SHC,TSR_CREATE,reconcile500.msgtype,0,0);
		TxnStatReport(reconcile500.shclog_id,TS_SHC,TSR_SEND,reconcile500.msgtype,0,mbidDest);
		//<<< R028271
		if (mb_write_nothrottle(mbidDest, netid, (char *)&reconcile500, sizeof(struct shc500std))< 0)
		{
			OTraceLog("L-SHC-107049: Failed Sending msg ID[%s] /m%04d to %s\n",
				reconcile500.shclog_id, reconcile500.msgtype, mbMailBoxName(netid));
			return (-3);
		}
		else
		{
			OTraceLog("L-SHC-107057: Sent msg ID[%s] /m%04d to %s\n",
				reconcile500.shclog_id, reconcile500.msgtype, mbMailBoxName(netid));
		}
		return (mbidDest);
	}
	return (1);
}
/* << R010436 */


int ShcNetworkMsgHelper::updateBinRoute( ShcmsgHeader *header )
{
	struct shcmsg *pShcmsg;
	struct RoutingInfo routingInfo = {0};
	int len = 0;
	int needBinUp = 0;
	
	if ( ! header )
		return (-1);
		
	pShcmsg = &header->msg;
	
	switch( pShcmsg->netcode )
	{
		case	SHC_NET_SIGNON_START:
		case	SHC_NET_GROUPSIGNON_START:
		case	SHC_NET_ECHO_START:
		case    SHC_NET_SIGNON_ISSUER:
			if ( !shcIsResponse(header) )
			{
				return 0;
			}
			// fall through
		case	SHC_NET_SIGNON:
		case	SHC_NET_GROUP_SIGNON:
		case	SHC_NET_CONTINUE_SIGNON:
		case	SHC_NET_ECHO:
			// R027876, R028104 >>>
			len = sizeof(struct RoutingInfo);
			header->getSegmentData((char *)&routingInfo, &len, NETWORK_DATA_REQ_id,ROUTING_INFO);
			if(len)
			{
				OTraceDebug("D-SHC-107065: Found 'ROUTING_INFO' segment\n");
				struct InstitutionProfile ip = { 0 };
				len = sizeof(ip);
				header->getSegmentData((char *)&ip, &len, NETWORK_DATA_REQ_id, ISS_INST_PROFILE_ENTRY);
				if (len > 0)
				{
 			                istsafe_strcpy(getRouteEntriesBinrouteGroup, sizeof(getRouteEntriesBinrouteGroup),ip.binrouteGroup);
				}
				else
					OTraceDebug("D-SHC-107071:No binroute group info found.\n");

			}

			// <<< R027876, R028104
			else if ( pShcmsg->unit > 0 )
			{
				strncpy( routingInfo.port, mbMailBoxName(pShcmsg->unit), sizeof(routingInfo.port)-1 );
				strncpy( routingInfo.destNode, mbcurrentnode, sizeof(routingInfo.destNode)-1 );
				
				OTraceDebug("D-SHC-107066: RoutingInfo from port[%s] mbid[%d]\n", routingInfo.port, pShcmsg->unit);
			}
			else
			{
				OTraceWarning("W-SHC-107067: RoutingInfo and incoming port mbid are empty\n");
				return (-2);
			}

			header->setSegmentData((char*)&routingInfo, sizeof(struct RoutingInfo), 
						NETWORK_DATA_REQ_id,ROUTING_INFO); //R027876,R028104

			binRouteObj->markRouteUp( pShcmsg->issuer, &routingInfo, &needBinUp);	
			//IST_S761SP7-152 >>>
//			if (needBinUp)
//			{
//				binRouteObj->changeBinStatus( pShcmsg->issuer,1);
//			}
			//IST_S761SP7-152 <<<
			break;
			
		default :
			OTraceDebug("D-SHC-107068: ignored binroute status update for netcode[%d]\n", pShcmsg->netcode);
			break;
	}
	
	return 0;
}


int ShcNetworkMsgHelper::getInstProfile(struct s_binroute *pBinRoute, NetworkInfo *networkInfo)
{
	InstitutionProfile *ip = NULL;
	if (pBinRoute->binrouteGroup[0])
	{
		//Use the binroute group to find the inst_profile entry
		ip = shcApp->instProfileObj->locateByBinroute(pBinRoute);
		if (ip)
		{
			networkInfo->putInstProfileEntry(ip);
			return 0;
		}
		else
		{
			OTraceError("E-SHC-107062:inst_profile for bin(%s,%s) group(%s)not exist\n", pBinRoute->institutionid, pBinRoute->userbinid, pBinRoute->binrouteGroup);
			return -1;
		}
	}
	else
	{
		InstProfileList ipList;
		InstitutionProfile *ii=NULL;
		int found = 0;
		found = shcApp->instProfileObj->getInstProfileList(NULL, NULL, NULL, ipList, pBinRoute->internalid);
		if (found)
		{
			networkInfo->putInstProfileEntry((InstitutionProfile *)ipList[0].getInstProfileEntry()); 
			return 0;
		}
		else
		{
			OTraceError("E-SHC-107063:No inst_profile for bin[%s]\n", pBinRoute->internalid);
			return -1;
		}
	}
}

int ShcNetworkMsgHelper::prepareMsgFromBinRoute(ShcmsgHeader *tmpHeader, struct s_binroute *pBinRoute)
{
	NetworkInfo networkInfo;
	struct RoutingInfo r = { 0 };


	if (thisShcApp->shcNetworkMsgHelperObj->getInstProfile(pBinRoute, &networkInfo)<0)
	{
		OTraceInfo("I-SHC-107064:Can't find inst_profile for binroute(i:%s,b:%s,g:%s,p:%s)\n",
				pBinRoute->institutionid, pBinRoute->userbinid, pBinRoute->binrouteGroup, pBinRoute->port);
		return -1;
	}
													
	//strcpy(tmpHeader->msg.txnSrc, networkInfo.getTxnSrc());
	//strcpy(tmpHeader->msg.txnDest, networkInfo.getTxnDest());
	snprintf(tmpHeader->msg.txnSrc, sizeof(tmpHeader->msg.txnSrc), "%s", networkInfo.getTxnSrc());
	snprintf(tmpHeader->msg.txnDest, sizeof(tmpHeader->msg.txnDest), "%s", networkInfo.getTxnDest());
	//Don't fill entity id because entity id can be an regular expression.
	//As we will put this inst_profile entry in msg, inst_profile should surely be used
	tmpHeader->setSegmentData((char *)networkInfo.getInstProfileEntry(), sizeof(InstitutionProfile), NETWORK_DATA_REQ_id, ISS_INST_PROFILE_ENTRY);

//	struct  shcpkg 		*pkg = NULL;
//	shc_locate_bin(&pkg, pBinRoute->internalid);
//	strcpy(r.mailbox, mbMailBoxName(pkg->bin.mailbox));

	r.siteId = pBinRoute->siteId;
																			
	strcpy(r.destNode, pBinRoute->node);
	istsafe_strcpy(r.mailbox, sizeof(r.mailbox), pBinRoute->mailbox);
	strcpy(r.srcNode, mbcurrentnode);
	strcpy(r.port, mbMailBoxName(mbLastSenderId()));
	r.flag |= ROUTE_INFO_FLAG_USE_FOR_REQ | ROUTE_INFO_FLAG_USE_BINROUTE;

	r.time_out = 0;		//time_out is for corss node use only
	//r.port is set already
	tmpHeader->setSegmentData((char *)&r, sizeof(r), NETWORK_DATA_REQ_id, ROUTING_INFO);
	strcpy(tmpHeader->msg.acquirer, pBinRoute->internalid);
	strcpy(tmpHeader->msg.issuer, pBinRoute->internalid);
	strcpy(tmpHeader->msg.originator, shc_orgid);
	tmpHeader->msg.msgtype = SHC_NETWORK;
	tmpHeader->msg.trace = thisShcApp->shcNetworkMsgHelperObj->shc_generate_uni_trace();
	mb_getUmi(tmpHeader->msg.shclog_id, sizeof(tmpHeader->msg.shclog_id));
	mb_set_tid(tmpHeader->msg.shclog_id, strlen(tmpHeader->msg.shclog_id));
	return 0;
}

int ShcNetworkMsgHelper::shcnet_keyxchg_request_2leg(ShcmsgHeader *header)
{
	struct  ShcWithSegment onetmsg = {0};
	if( (header->eventId = tm_locate(shcApp->shcmsgHelperObj->shcMakeKey(header), -1)) >= 0 )
	{
		tm_getdata(header->eventId,(char *) &(onetmsg.shc).msg, sizeof((onetmsg.shc).msg));
		header->msg.format_code[0] = (onetmsg.shc).msg.format_code[0];
		header->msg.format_code[1] = (onetmsg.shc).msg.format_code[1];
		header->msg.pin_index = (onetmsg.shc).msg.pin_index;
		header->msg.mac_index = (onetmsg.shc).msg.mac_index;
	}
	removeEvent(header);
	int len = sizeof(struct InstitutionProfile);
	InstitutionProfile instProfile = { 0 };
	header->getSegmentData((char *)&instProfile, &len, NETWORK_DATA_REQ_id, ISS_INST_PROFILE_ENTRY);
	if(len<=0)
	{
		len = sizeof(struct InstitutionProfile);
		header->getReqSegmentData((char *)&instProfile, &len, NETWORK_DATA_REQ_id, ISS_INST_PROFILE_ENTRY);
		if (len>0)
			header->setSegmentData((char *)&instProfile, len, NETWORK_DATA_REQ_id, ISS_INST_PROFILE_ENTRY);
	}
	net_initialise_message(header);

	header->msg.trandate = shc_gmt_currentdate();
	header->msg.trantime = shc_gmt_currenttime();
	header->msg.trace = shc_generate_uni_trace();
	header->msg.settlement_date = shc_local_currentdate();

	mb_getUmi(header->msg.shclog_id, sizeof(header->msg.shclog_id));
	mb_set_tid(header->msg.shclog_id, strlen(header->msg.shclog_id));
	header->msg.msgtype = SHC_NETWORK;
	header->msg.netcode = SHC_NET_KEYS_START_2LEG;
	header->shcerr = SH_SENDISS;
	memset((char *)header->msg.formatter_use, 0x00, 20);

	OTraceInfo("I-SHCNET-107029: Network keys 2leg request with netcode %d\n", header->msg.netcode);
	return (0);
}

int KeyXchgMsgHelper::collect(ShcNetworkMsgHelper &netMsgHlpr,ShcmsgHeader *header, char &status, char &savclass)
{
	static const char* fnDesc = "KeyXchgMsgHelper::collect";
	int ret=0;

	savclass = header->msg.format_code[0];
	if (status == SH_KEYSTAT_EXCHANGE)
	{
		if (header->msg.format_code[0] == SH_KEYTYPE_PIN_ISS)
		{
			header->msg.format_code[0] = SH_KEYTYPE_PIN_ACQ;
		}
		else if (header->msg.format_code[0] == SH_KEYTYPE_PIN_ACQ)
		{
			header->msg.format_code[0] = SH_KEYTYPE_PIN_ISS;
		}
	}
	OTraceDebug("D-SHC-107091 %s Status[%c], key_class[%c]\n", fnDesc, status, savclass );
	return(ret);
}

int KeyXchgMsgHelper::preProc(ShcNetworkMsgHelper &netMsgHlpr,ShcmsgHeader *header,struct shckey_buf *keybuf,char &status,char &savclass)
{
	static const char* fnDesc = "KeyXchgMsgHelper::preProc";
	int ret=0;
	int as2805_flag = 0;

	char keytype;
	char keyidx;

	OTraceDebug("D-SHC-107092 %s Status[%c], key_class=%c\n",fnDesc,status, savclass);
	if((ret=header->issShcBin->shcnet_keys_init(header,keybuf))<0)
		return(-1);

	if (header->issShcBin->binPkg->bin.bintype & SH_KEYS_AS2805)
		as2805_flag = 1;

	if (keybuf->keyp->k.flags[1] == 'S')
	{
		if( mbIsDualSite() )
		{
			if( mbGetSiteId() == 2 )
			{
				try
				{
					if(IST_MR::check_if_site_is_up(1))
					{
						OTraceError("E-SHC-107095: site 1 is up, ignore key exchange.\n");
						header->msg.respcode = SHC_RC_UnableToProcess;
						return(-1);
					}
				}
				catch(...)
				{
					OTraceError("E-SHC-107096: Caught exception when checking site 1 state(state invalid?), ignore key exchange.\n");
					header->msg.respcode = SHC_RC_UnableToProcess;
					return(-1);
				}
			}
		}
	}
	
	OTraceDebug("D-SHC-107092 %s format_code[%c], key_class=[%c]\n",fnDesc, header->msg.format_code[0], savclass);
	if (savclass==SH_KEYTYPE_PIN_ISS || savclass==SH_KEYTYPE_PIN_ACQ)
		header->msg.format_code[0] = savclass; // Not related to this SCR. Type has been recitified.

	// Status was set if this is Asynch SecSrv Request
	if(!(header->shcerr & SH_ASYNCH_RESUME))
	{	/* Set and check busy status */
		switch( status )
		{
			case SH_KEYSTAT_ACTIVE:
				ret = thisShcApp->shcKeyObj->shc_keys_set_status_as2805(keybuf, SH_KEYSTAT_EXCHANGE, as2805_flag);
				break;

			case SH_KEYSTAT_EXCHANGE:
				if(	(keybuf->akeyp && *keybuf->astatp == SH_KEYSTAT_EXCHANGE) ||
					(keybuf->ikeyp && *keybuf->istatp == SH_KEYSTAT_EXCHANGE) )
				{
					keytype=header->msg.format_code[1];
					switch(keytype)
					{
						case    'P': keyidx = header->msg.pin_index; break;
						case    'M': keyidx = header->msg.mac_index; break;
						default    : keyidx = header->msg.pin_index; break;
					}

					OTraceError("E-SHC-107003: Key is busy - %c%c%c\n",header->msg.format_code[0],keytype,keyidx);
					header->msg.respcode = SHC_RC_UnableToProcess;
					return( -1 );
				}
				break;
		}
	}

	return(ret);
}

extern char __keycnt_setMRDataShared[20+1];
int KeyXchgMsgHelper::proc(ShcNetworkMsgHelper &netMsgHlpr,ShcmsgHeader *header,struct shckey_buf *keybuf,char &status)
{
	static const char* fnDesc = "KeyXchgMsgHelper::proc";
	int ret=0;
	int keyType = 0;
	char keyVersion = 'A';

	char mac_key[MAX_KEYLEN+1]	= {0};
	char mac_chk[24+1]	= {0};
	char kme_key[MAX_KEYLEN+1]	= {0};
	char kme_chk[24+1]	= {0};

	char seg_key[150]	= {0};
	int  seg_key_len	= -1;
	int  atalla_var	= 0;

	OTraceDebug("D-SHC-107093 %s ret[%d]\n", fnDesc, ret );
	if(shcIsAsynchSecMode())
		setAsynchHeader(header);

	if (header->setIssShcBin(header->msg.issuer) > 0)
	{
		struct InstitutionProfile ip;
		int len = sizeof(ip);
		header->getSegmentData((char *)&ip, &len, NETWORK_DATA_REQ_id, ISS_INST_PROFILE_ENTRY);
		if ( len > 0 )
			header->issShcBin->setKey ( &ip );

		if((header->issShcBin->binPkg->bin.bin_cfg & SH_CFG_KPE_KEYBLOCK) || (header->issShcBin->binPkg->bin.bin_cfg & SH_KB_VERSIONID_A))
		{
			keyType = 1;
			keyVersion = 'A';
		}
		else if((header->issShcBin->binPkg->bin.bin_cfg & SH_KB_VERSIONID_B))
		{
			keyType = 1;
			keyVersion = 'B';
		}
		else if((header->issShcBin->binPkg->bin.bin_cfg & SH_KB_VERSIONID_C))
		{
			keyType = 1;
			keyVersion = 'C';
		}
		else if((header->issShcBin->binPkg->bin.bin_cfg & SH_KB_VERSIONID_D))
		{
			keyType = 1;
			keyVersion = 'D';
		}

		if(header->issShcBin->binPkg->bin.bin_cfg & SH_KB_RACL_ATL_VAR)
		{
			OTraceDebug("D-SHC-107106: BIN has Thales Atalla Variant enabled\n");
			atalla_var = 1;
		}
	}

	char macKey[999];
	int macKeyLen=0;
	memset(macKey, 0x00, sizeof(macKey));
	header->getSegmentData((char *)&macKey, &macKeyLen, NETWORK_DATA_REQ_id, KEYBLOCK_KEY);

	char macChk[10];
	int macChkLen = 0;
	memset(macChk, 0x00, sizeof(macChk));
	header->getSegmentData((char *)&macChk, &macChkLen, NETWORK_DATA_REQ_id, KEYBLOCK_KEY_CHK_VALUE);

	strcpy(__keycnt_setMRDataShared, header->msg.kpe_kekcnt);	//pass keycnt to MR data
	if (header->issShcBin->binPkg->bin.bintype & SH_KEYS_AS2805)
	{
		// >>>> AS2805 payShield 10K, below for future use
		memcpy(mac_key,			macKey,		32);
		memcpy(mac_chk,			macKey+64,	6);
		memcpy(header->msg.mac.key,	macKey+32,	32);
                memcpy(header->msg.mac.chk, macKey+70, min<long>(sizeof(header->msg.mac.chk), 6));
		*(header->msg.mac.key + 32) = '\0';
		*(header->msg.mac.chk + 6 ) = '\0';
		ret = thisShcApp->shcKeyObj->shc_keys_xchg_as2805_td(	keybuf,
									header->msg.mac.key,
									header->msg.mac.chk,
									mac_key,
									mac_chk,
									kme_key,
									kme_chk,
									status,
									&header->msg.keylen );

		memset(macKey, 0, sizeof(macKey));
       		snprintf(macKey, sizeof(macKey), "%32s%32s%6s%6s", mac_key, header->msg.mac.key, mac_chk, header->msg.mac.chk ); 
		snprintf( header->msg.filler4, sizeof(header->msg.filler4), "%s%s", mac_chk, header->msg.mac.chk );
		OTraceDebug( "D-SHC-027042 add check value for kvc validation in filler4 %s\n", header->msg.filler4 );

		macKeyLen = strlen(macKey);;
		header->setSegmentData(macKey, macKeyLen, ElfIdMap::elf_to_id(IST_SEG_NETWORK_DATA_REQ), KEYBLOCK_KEY);
	}
	else if ((macKeyLen>0) && macKey)
	{
		if(FullCheckDigit)
		{
			ret=thisShcApp->shcKeyObj->shc_keys_xchg_td_xt_xt(keybuf, macKey, macChk, status,&header->msg.keylen,keyType,keyVersion,atalla_var);
			strncpy(header->msg.filler4, macChk, sizeof(header->msg.filler4));
		}
		else
		{
			ret=thisShcApp->shcKeyObj->shc_keys_xchg_td_xt_xt(keybuf,macKey,header->msg.mac.chk,status,&header->msg.keylen,keyType,keyVersion,atalla_var);
		}
	}
	else
	{	//incoming key exchange with Variant key copied in macKey
		if(strlen(header->msg.mac.key) > 0)
		{
			strncpy(macKey,header->msg.mac.key,strlen(header->msg.mac.key));
		}
		if(FullCheckDigit)
		{
			ret=thisShcApp->shcKeyObj->shc_keys_xchg_td_xt_xt(keybuf, macKey, header->msg.filler4,status,&header->msg.keylen,keyType,keyVersion,atalla_var);
		}
		else
		{
			ret=thisShcApp->shcKeyObj->shc_keys_xchg_td_xt_xt(keybuf, macKey, header->msg.mac.chk,status,&header->msg.keylen,keyType,keyVersion,atalla_var);
		}
		if(keyType == 1)
		{
			if (strlen(macKey) > header->msg.keylen)
			{
				header->msg.keylen = strlen(macKey);
			}
			header->setSegmentData(macKey, header->msg.keylen, ElfIdMap::elf_to_id(IST_SEG_NETWORK_DATA_REQ), KEYBLOCK_KEY);
		}
		else
		{
			header->msg.keylen = strlen(macKey);
			strncpy(header->msg.mac.key, macKey, header->msg.keylen);
		}

	}

	__keycnt_setMRDataShared[0] = 0;
	header->msg.respcode=ret;

	return(ret);
}

int KeyXchgMsgHelper::resume(ShcNetworkMsgHelper &netMsgHlpr,ShcmsgHeader *header,struct shckey_buf *keybuf,char &status,char &savclass)
{
	static const char* fnDesc = "KeyXchgMsgHelper::resume";
	int keyBufLen;
	int ret=0;
	int keyType=0;
	char macKey[999];
	int macKeyLen=0;
	int as2805_flag=0;
	char keyVersion = 'A';
	int atalla_var = 0;

	OTraceDebug("D-SHC-027043 %s InitBuf RespCode[%d], key_class=[%c]\n",fnDesc,header->msg.respcode, savclass);


	if (header->issShcBin->binPkg->bin.bintype & SH_KEYS_AS2805)
		as2805_flag = 1;

	OTraceDebug("D-SHC-027043 set key pointers called type = %c, class = %c\n", keybuf->type, keybuf->key_class );
	header->issShcBin->shc_keys_set_pointers(keybuf);

	//OTraceDebug("D-SHC-027043 %s InitBuf RespCode[%d]\n",fnDesc,header->msg.respcode);
	if(header->shcerr & SH_ASYNCH_RESUME)
	{
		OTraceDebug("D-SHC-001214 %s KEY_MANAGEMENT_DATA\n",fnDesc);
		// We need to resume shc_keys_xchg_td to finish process
		if (header->setIssShcBin(header->msg.issuer) > 0)
		{
			struct InstitutionProfile ip;
			int len = sizeof(ip);
			header->getSegmentData((char *)&ip, &len, NETWORK_DATA_REQ_id, ISS_INST_PROFILE_ENTRY);
			if ( len > 0 )
			{
				header->issShcBin->setKey ( &ip );
				OTraceInfo( "D-SHC-027043 set key pointers called type = %c, class = %c\n", keybuf->type, keybuf->key_class );
				header->issShcBin->shc_keys_set_pointers(keybuf);
			}
			if((header->issShcBin->binPkg->bin.bin_cfg & SH_CFG_KPE_KEYBLOCK) || (header->issShcBin->binPkg->bin.bin_cfg & SH_KB_VERSIONID_A))
			{
				keyType = 1;
				keyVersion = 'A';
			}
			else if((header->issShcBin->binPkg->bin.bin_cfg & SH_KB_VERSIONID_B))
			{
				keyType = 1;
				keyVersion = 'B';
			}
			else if((header->issShcBin->binPkg->bin.bin_cfg & SH_KB_VERSIONID_C))
			{
				keyType = 1;
				keyVersion = 'C';
			}
			else if((header->issShcBin->binPkg->bin.bin_cfg & SH_KB_VERSIONID_D))
			{
				keyType = 1;
				keyVersion = 'D';
			}

			if(header->issShcBin->binPkg->bin.bin_cfg & SH_KB_RACL_ATL_VAR)
			{
				OTraceDebug("D-SHC-001216: BIN has Thales Atalla Variant enabled\n");
				atalla_var = 1;
			}
		}
		memset(macKey, 0x00, sizeof(macKey));
		header->getSegmentData((char *)&macKey, &macKeyLen, NETWORK_DATA_REQ_id, KEYBLOCK_KEY);

		if ((macKeyLen>0) && macKey)
			ret=thisShcApp->shcKeyObj->shc_keys_xchg_td_xt_xt(keybuf,macKey,header->msg.mac.chk,status,&header->msg.keylen,keyType,keyVersion,atalla_var);
		else
			ret=thisShcApp->shcKeyObj->shc_keys_xchg_td_xt_xt(keybuf,header->msg.mac.key,header->msg.mac.chk,status,&header->msg.keylen,keyType,keyVersion,atalla_var);

		if(NETWORK_SETTLEMENT_DATA_id==-1)
			NETWORK_SETTLEMENT_DATA_id = ElfIdMap::elf_to_id("NETWORK_SETTLEMENT_DATA");
		header->setSegmentData((char *)&asynchSecResp.checkVal,sizeof(asynchSecResp.checkVal),NETWORK_SETTLEMENT_DATA_id,AMEX_CHECK_DIGIT);
	}

	// key counters for chevron
	if( header->msg.respcode == SHC_RC_Approved )
	{
		if( keybuf->acntp  || (strlen(header->msg.kpe_kekcnt)== 0) )
		{
			OTraceDebug("D-SHC-001215-before: Switch counter(%s) Counter in msg(%s)\n", keybuf->acntp, header->msg.kpe_kekcnt);
			istsafe_strcpy( keybuf->acntp, sizeof(header->msg.kpe_kekcnt), header->msg.kpe_kekcnt );
			OTraceDebug("D-SHC-001215-after: Switch counter(%s) Counter in msg(%s)\n", keybuf->acntp, header->msg.kpe_kekcnt);
		}
		else
		{
			OTraceDebug("D-SHC-001215: update of switch counters not done [%s]\n", header->msg.kpe_kekcnt );
		}
	}
	else
	{
		istsafe_strcpy( header->msg.expected_kekcnt, sizeof(header->msg.expected_kekcnt), keybuf->acntp );
		OTraceDebug("D-SHC-001215: declined key exchange, set original kekcnt value [%s]\n", header->msg.expected_kekcnt );
	}

	if( header->msg.respcode == SHC_RC_Approved )
	{
		if (savclass == SH_KEYTYPE_PIN_ISS || savclass == SH_KEYTYPE_PIN_ACQ)
		{
			header->msg.format_code[0] = savclass;
		}
		else
		{
			header->msg.format_code[0] = keybuf->key_class;
		}
		header->msg.format_code[1] = keybuf->type;
		switch(header->msg.format_code[1])
		{
		    case    'P': header->msg.pin_index = keybuf->index; break;
		    case    'M': header->msg.mac_index = keybuf->index; break;
		    default    : header->msg.pin_index = keybuf->index; break;
		}

		// AS2805- Key Exchange from EFTPOS to IST
		if ( (header->msg.netcode == SHC_NET_KEYS) &&
			( (header->issShcBin->binPkg->bin.bintype & SH_KEYS_REQUIRED) ||
			  (header->issShcBin->binPkg->bin.bintype & SH_KEYS_AS2805) ) )
			thisShcApp->shcKeyObj->shc_keys_set_status_as2805(keybuf, SH_KEYSTAT_ACTIVE, as2805_flag);
	}
	else if ( (header->issShcBin->binPkg->bin.bintype & SH_KEYS_REQUIRED) && 
			(header->msg.respcode == SHC_RC_PINKeyError) )
	{
		OTraceDebug("D-SHC-027049 %s PIN KEY Failed RespCode[%d], Key Status no Change.\n",fnDesc, header->msg.respcode);
		if( (keybuf->akeyp && *keybuf->astatp == SH_KEYSTAT_EXCHANGE) ||
		    (keybuf->ikeyp && *keybuf->istatp == SH_KEYSTAT_EXCHANGE) )
		{
			thisShcApp->shcKeyObj->shc_keys_set_status_as2805(keybuf, SH_KEYSTAT_ACTIVE, as2805_flag);
			OTraceDebug("D-SHC-027050 %s PIN KEY Failed RespCode[%d], Key Status resumed to ACTIVE.\n", fnDesc, header->msg.respcode);
		}


	}
	else if ( (header->issShcBin->binPkg->bin.bintype & SH_KEYS_REQUIRED) ||
			(header->issShcBin->binPkg->bin.bintype & SH_KEYS_AS2805) )
	{
		thisShcApp->shcKeyObj->shc_keys_set_status_as2805(keybuf, SH_KEYSTAT_INACTIVE, as2805_flag);
	}
	else if ( !(header->issShcBin->binPkg->bin.bintype & SH_KEYS_REQUIRED) &&
			!(header->issShcBin->binPkg->bin.bintype & SH_KEYS_AS2805) )
	{
		OTraceDebug("D-SHC-027044 shcbin->usekeys not configured properly, key exchange not allowed.\n");
		header->msg.respcode = SHC_RC_TransactionNotAllowed;
		return(-1);
	}

	if	((keybuf->keyp->k.flags[1]!='S') &&
		((status==SH_KEYSTAT_ACTIVE) || (status==SH_KEYSTAT_EXCHANGE)))
	{
		// This is a exchange from  external will   be turned into aresponse messsage
		MRApplHelper *mrHelper = MRApplHelper::getInstance(IST_MR_SERVICE_NAME_SHCKEYS_UNIQUE);
		OCString replService;
		OCString replData;
		mrHelper->getServiceName(replService);
		if ( mrHelper->flattenData(replData) == -1 )
		{
			mrHelper->reset();
		}
		else
		{
			header->appendReplicationData(replService.data(), replData.data(), replData.length() );
		}
	}

	return( 0 );
}
int ShcNetworkMsgHelper::do_key_exchange_as2805( ShcmsgHeader *header )
{
	if( !(header->issShcBin->binPkg->bin.bintype & SH_KEYS_AS2805) )
		return 0;
	// paypal change
	// this needs to be in its own function
	// There must be a better way of doing this
	ShcmsgHeader tmpHeader(*header);
	tmpHeader.msg.msgtype = SHC_NETWORK;
	tmpHeader.msg.netcode = SHC_NET_KEYS_START;
	tmpHeader.msg.origtrace = header->msg.trace;
	tmpHeader.msg.origtrace = header->msg.trace;
	tmpHeader.msg.format_code[0] = SH_KEYTYPE_PIN_ISS;
	tmpHeader.msg.format_code[1] = SH_KEYTYPE_PIN;
	tmpHeader.msg.pan[0] = '\0';
	if( header->issShcBin )
		strcpy(tmpHeader.msg.txnSrc, header->issShcBin->binPkg->bin.institutionid);
	else
		tmpHeader.msg.txnSrc[0] = '\0';
	tmpHeader.msg.trace = shc_generate_uni_trace();   // R010489
	mb_getUmi(tmpHeader.msg.shclog_id, sizeof(tmpHeader.msg.shclog_id));
	mb_set_tid(tmpHeader.msg.shclog_id, strlen(tmpHeader.msg.shclog_id));
	OTraceDebug("D-SHCNET-172056: mac key sync error - created message ID[%s] m%04d/n%d\n",
				tmpHeader.msg.shclog_id, tmpHeader.msg.msgtype, tmpHeader.msg.netcode);
	TxnStatReport(tmpHeader.msg.shclog_id,TS_SHC,TSR_CREATE,tmpHeader.msg.msgtype,0,0);
	if( shc_send_800(&tmpHeader, header->issShcBin) < 0 )
	{
		OTraceError("D-SHCNET-172055: mac key sync error, send key exchange failed\n");
		return -1;
	}


	return 0;
}
