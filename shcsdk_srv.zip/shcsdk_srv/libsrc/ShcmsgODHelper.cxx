/*
 *  Copyright (C) 2004 eFunds Corporation ("eFunds").  All Rights Reserved.
 *  eFunds Canada Corporation is an authorized user.
 *
 *  IST is a registered trademark of eFunds Corporation.  Other brand or
 *  product names are trademarks or registered trademarks of their respective
 *  holders.
 *
 *  The information contained herein is the unpublished proprietary property
 *  of eFunds.  Except as specifically authorized in writing by eFunds, the
 *  holder of this document shall: i) keep all information contained herein
 *  confidential, and ii) protect the information, in whole or in part, from
 *  disclosure and dissemination to all third parties.
 *
 *  This document and the software described in it are furnished under license
 *  and may be used or copied only in accordance with the terms of such license.
 *  This document is supplied for information purposes only, is subject to
 *  change without notice, and should not be construed as a commitment by
 *  either eFunds Corporation or eFunds Canada Corporation.
 *
 *
 *                        MODIFICATION HISTORY                  REVIEW
 *
 *	SPR#	Who	Date	Description			Who	Date
 * ===========================================================================
 *	R000000	ztang	24Jul17	New file created
 */

/* File Number 176 */

static char _ShcmsgODHelper_cxx_what[] = "@(#) ShcmsgODHelper.cxx 1.10.1.1 19/11/07 08:37:31";

#include <stdio.h>
#include <string.h>
#include <errno.h>
#include <ctype.h>
#include <oasis.h>
#include <dbm.h>
#include <mb_umi.h>
#include <mb.h>
#include <ist_otrace.h>
#include <shc.h>
#include <ShcApp.h>
#include <ShcSdkCommon.h>
#include <ShcProcessorRegistration.h>
#include <ShcmsgProcessor.h>
#include <ShcHelper.h>
#include <ShcmsgHelper.h>
#include <ShcBin.h>
#include <ShcmsgODHelper.h>
#include <ShcmsgHeader.h>
#include <shcmerchant.h>
#include <oc/oc_datetime.h>
#include <ist_seg_name.h>
#include <ist_seg_elf_id_map.h>
#include <ist_seg_id.h>
#include <ist_seg_pdt_base.h>
#include <ist_seg_fn_data.h>

#include <HaPtmCctHelper.h>
#include <oc/oc_hires_timer.h>
#include <istsafe.h>
#include <ShcSafIOHelper.h>
#include <ShcFinAuthHelper.h>
#include <InstProfile.h>
#include <ShcTimerHelper.h>

static int ODOut_mbId = (-1);

ShcmsgODHelper *shcmsgODHelperObj = NULL;

ShcmsgODHelper::ShcmsgODHelper()
{
	ODBin = NULL;
}

unsigned long  ShcmsgODHelper::isODEnabled(ShcBin *issuerBin)
{
	unsigned long ret = 0;
	if (issuerBin && issuerBin->binPkg)
		ret = issuerBin->binPkg->bin.bin_cfg & SH_CFG_ONDOT_MASK;
	if(initODBin() < 0)
	{
		ret = 0;
	}
	else if (ON_DOT_id < 0)
	{
		ret = 0;
	}
	else if (ON_DOT_LOG_id < 0)
	{
		ret = 0;
	}
		
	return (ret);
}


int ShcmsgODHelper::sendTxnReq(ShcmsgHeader *header)
{
	int ready_to_OD = 0;
	char tmpStr[100]; 
	int saved_shcerr = header->shcerr;	

	if (header->msg.auth_devcap & SH_DEVCAP_AUTH_OD_MASK)
	{
		//message has been to On Dot, don't go again
		return 0;
	}

	struct RoutingInfo routingInfo = {0};
	int routingInfoLen=sizeof(struct RoutingInfo);

	unsigned long ODConfig = isODEnabled(header->issShcBin);
	if (!ODConfig) 
	{
		return 0;
	}

	
	//Common conditions to be checked first
	if( (	(header->msg.msgtype == SHC_AUTHREQ) ||
			(header->msg.msgtype == SHC_AUTHREQ_REPEAT) ||
			(header->msg.msgtype == SHC_FINREQ) ||
			(header->msg.msgtype == SHC_FINREQ_REPEAT)
		) &&
	 	(!header->repeatFlag) && !(header->shcerr & SH_IGNORE)
		&& !(header->msg.shc_devcap & SH_DEVCAP_SHC_EVENT) )
	{
		//send 100/101/200/201 to OnDot
		if(ODBin->binPkg->bin.flags & SH_DOWN)
		{
			header->msg.auth_devcap |=SH_DEVCAP_AUTH_ODDown;
			if (header->issShcBin->binPkg->bin.bin_cfg & SH_CFG_ONDOT_DOWN_CONT)
			{
				OTraceLog("L-SHC-176004: OnDot Bin Down! Message Not sent to On Dot \n");
				header->shcerr &= ~SH_SENDAPPLBIN;
				return 0;
			}
			else
			{
				//SH_CFG_ONDOT_DOWN_DENY is set, deny txn
				thisShcApp->shcFinAuthHelperObj->shc_return_finauth(header, SHC_RC_Declined_On_ODDown);
				return 0;
			}
		}
		header->msg.auth_devcap |= SH_DEVCAP_AUTH_OD;

		ready_to_OD = 1;
		memset(tmpStr,0x00,sizeof(tmpStr));
		sprintf(tmpStr,"%ld",header->time_out);
		header->setSegmentData(tmpStr,strlen(tmpStr),ON_DOT_id,TXNOUT_TIME);


		memset(tmpStr,0x00,sizeof(tmpStr));
		sprintf(tmpStr,"%d", header->logFlag);
		header->setSegmentData(tmpStr,strlen(tmpStr),ON_DOT_id,LOG_FLAG); //R028777

		memset(tmpStr,0x00,sizeof(tmpStr));
		sprintf(tmpStr,"%d", header->repeatFlag);
		header->setSegmentData(tmpStr,strlen(tmpStr),ON_DOT_id,REPEAT_FLAG); //R028777

		memset(tmpStr,0x00,sizeof(tmpStr));
		sprintf(tmpStr,"%d", saved_shcerr);
		header->setSegmentData(tmpStr,strlen(tmpStr),ON_DOT_id,SHCERR); //R028777

		memset(tmpStr,0x00,sizeof(tmpStr));
		sprintf(tmpStr,"%ld", header->time_in);
		header->setSegmentData(tmpStr,strlen(tmpStr),ON_DOT_id,TXNIN_TIME); //R028777

		header->getSegmentData((char*)&routingInfo, &routingInfoLen, NETWORK_DATA_REQ_id, ROUTING_INFO);
        if (routingInfoLen)
		{
			header->setSegmentData((char*)&routingInfo, sizeof(routingInfo),ON_DOT_id,ROUTING_INFO);
		}

		memset(tmpStr,0x00,sizeof(tmpStr));
		sprintf(tmpStr,"%d",header->msg.flipped_msgtype);
		header->setSegmentData(tmpStr,strlen(tmpStr),ON_DOT_id,FLIPPED_MSG_TYPE);
		header->msg.flipped_msgtype = header->msg.msgtype;
		header->msg.msgtype = SHC_OD_REQ;

		long issuerTimeOut = 0;
		if (shcEnableSubssecondTimeout)
		{
			if (ODBin->binPkg->bin.addflag & SH_ADDFLAG_TIMEOUT_DECISECOND)
				issuerTimeOut = ODBin->binPkg->bin.timeout*100;
			else
				issuerTimeOut = ODBin->binPkg->bin.timeout*1000;
		}
		else
		{
			if (ODBin->binPkg->bin.addflag & SH_ADDFLAG_TIMEOUT_DECISECOND)
				issuerTimeOut = ODBin->binPkg->bin.timeout/10;
			else
				issuerTimeOut = ODBin->binPkg->bin.timeout;
		}

		if (shcEnableSubssecondTimeout)
		{
			header->time_in = (long)shc_current_time*1000L + shc_current_millisecond;
			header->time_out = (long)header->time_in + issuerTimeOut;
		}
		else
		{
			header->time_in = (long)shc_current_time;
			header->time_out = (long)header->time_in + issuerTimeOut;
		}

	}

	//Add additional information as a segment to shcmsg for retrieval after OD response
	if(ready_to_OD)
	{
		int eventId; //R027876
		if(header->reqMsg)
		{
			if (header->time_out < 10000000000)
			{
				eventId = tm_enqueue(shcmid, (header->time_out+10), TM_NOTIFY_ONCE,
					OD_ADD_INFO_EVENT_KEY, (char *)header->reqMsg, sizeof(struct shcmsg));
			}
			else
			{
				eventId = tm_enqueue(shcmid, (header->time_out/1000+10), TM_NOTIFY_ONCE,
					OD_ADD_INFO_EVENT_KEY, (char *)header->reqMsg, sizeof(struct shcmsg));
			}
		}
		else
		{
			eventId = -1;
		}

		memset(tmpStr,0x00,sizeof(tmpStr));
		sprintf(tmpStr,"%d",eventId);
		header->setSegmentData(tmpStr,strlen(tmpStr),ON_DOT_id,REQ_EVENT_ID);

		if(header->origMsg)
		{
			if (header->time_out < 10000000000)
			{
				eventId = tm_enqueue(shcmid, (header->time_out+10), TM_NOTIFY_ONCE,
					OD_ADD_INFO_EVENT_KEY, (char *)header->origMsg, sizeof(struct shcmsg));
			}
			else
			{
				eventId = tm_enqueue(shcmid, (header->time_out/1000+10), TM_NOTIFY_ONCE,
					OD_ADD_INFO_EVENT_KEY, (char *)header->origMsg, sizeof(struct shcmsg));
			}
		}
		else
		{
			eventId = -1;
		}
		memset(tmpStr,0x00,sizeof(tmpStr));
		sprintf(tmpStr,"%d",eventId);
		header->setSegmentData(tmpStr,strlen(tmpStr),ON_DOT_id,ORIG_EVENT_ID);

       	routingInfo.flag = 0;
       	header->setSegmentData((char*)&routingInfo, sizeof(routingInfo), NETWORK_DATA_REQ_id ,ROUTING_INFO);
	
	
		header->setSegmentData((char *)ODBin->binPkg->bin.networkid, sizeof(ODBin->binPkg->bin.networkid),
						 NETWORK_DATA_REQ_id,APPL_BIN); 
	
		header->shcerr = SH_SETTIMER|SH_SENDAPPLBIN;
		header->msg.auth_devcap |= SH_DEVCAP_AUTH_OD;
	
		header->logFlag = 0;
    	header->setSkipFlag(TXN_PROC_SKIP_DOWORK); //skip doWork for now. we can resume if OD approves this Request
	
    	OTraceInfo("I-SHC-176006:Message will be sent to On Dot for auth\n");
		return 1;
	}
	
	return 0;
}

int ShcmsgODHelper::initODBin()
{
	if (!ODBin)
	{
		ODBin = (ShcBin *)shcHelperRegister.getTargetObj(SHC_ShcBin);
		if (!ODBin)
			return -1;
	}

	if (!ODBin->binPkg)
		if (ODBin->setBinPkg("ONDOT", "     ONDOT")<0)
			return -1;
	return 0;
}

int ShcmsgODHelper::sendRespToOD(ShcmsgHeader *header)
{
	long ODConfig = isODEnabled(header->issShcBin);
	if (!ODConfig) 
		return 0;
	switch(header->msg.msgtype)
	{
	case 110:
	case 130:
	case 210:
	case 230:
	case 410:
	case 430:
		break;
	default:
		return 0;
	}
	if( (!header->repeatFlag) && (header->shcerr & SH_RETURN)
		&& !(header->msg.device_cap & SH_DEVCAP_FROM_REPLAY) )
	
	{
		int tmpMsgtype = header->msg.flipped_msgtype;
		header->msg.flipped_msgtype = header->msg.msgtype;
		header->msg.msgtype = 120;

    	header->setSegmentData(header->msg.issuer, sizeof(header->msg.issuer), ON_DOT_LOG_id, ON_DOT_SAVED_ISSUER);
		bin_t tmpIssuer;
		istsafe_strcpy(tmpIssuer, sizeof(tmpIssuer), header->msg.issuer);
		istsafe_strcpy(header->msg.issuer, sizeof(header->msg.issuer), ODBin->binPkg->bin.networkid);
		ShcBin *origIssuerBin = header->issShcBin;
		header->issShcBin = getODBin();
        InstitutionProfile instProfile = { 0 };
		struct RoutingInfo r = {0};

		IstSegList *sl = header->getSegList();
        int ipLen = sizeof(struct InstitutionProfile);
		int rLen = sizeof(struct RoutingInfo);
		int ondotRouteAdded = 0;
        header->getSegmentData((char *)&instProfile, &ipLen, NETWORK_DATA_REQ_id, ISS_INST_PROFILE_ENTRY);
        header->getSegmentData((char *)&r, &rLen, NETWORK_DATA_REQ_id, ROUTING_INFO);
		if (ipLen > 0)
		{
        	NetworkInfo networkInfo;
        	thisShcApp->instProfileObj->locateNetworkInfo(header->msg.txnSrc, header->msg.txnDest,
            	header->msg.iss_entityId, header->msg.msgtype, header->msg.issuer, networkInfo);
        	if (networkInfo.foundNetworkInfo())
			{
            	header->setSegmentData((char *)networkInfo.getInstProfileEntry(),
                	sizeof(struct InstitutionProfile), NETWORK_DATA_REQ_id, ISS_INST_PROFILE_ENTRY);
				if (thisShcApp->shcmsgHelperObj->addRoutingInfoSegment( header, networkInfo )>=0)
					ondotRouteAdded = 1;
			}
			else
				OTraceError("E-SHC-176007:ON DOT inst_profile not found.\n");
		}

		if ((rLen>0)&&!ondotRouteAdded)
		{
			int flag = r.flag;
			r.flag = 0;
			header->setSegmentData((char *)&r, sizeof(r), NETWORK_DATA_REQ_id, ROUTING_INFO);
			r.flag = flag;
		}


		if(ODBin->binPkg->bin.flags & SH_DOWN)
		{
			OTraceDebug("D-SHC-176012:Send On Dot notification to SAF becasue On Dot bin is down.\n");
			thisShcApp->shcSafIOHelperObj->shc_saf_writefile(ODBin, header);
		}
		else
		{
			long issuerTimeOut = 0;
			if (shcEnableSubssecondTimeout)
			{
				if (ODBin->binPkg->bin.addflag & SH_ADDFLAG_TIMEOUT_DECISECOND)
					issuerTimeOut = ODBin->binPkg->bin.timeout*100;
				else
					issuerTimeOut = ODBin->binPkg->bin.timeout*1000;
			}
			else
			{
				if (ODBin->binPkg->bin.addflag & SH_ADDFLAG_TIMEOUT_DECISECOND)
					issuerTimeOut = ODBin->binPkg->bin.timeout/10;
				else
					issuerTimeOut = ODBin->binPkg->bin.timeout;
			}
	
			if (shcEnableSubssecondTimeout)
			{
				header->time_in = (long)shc_current_time*1000L + shc_current_millisecond;
				header->time_out = (long)header->time_in + issuerTimeOut;
			}
			else
			{
				header->time_in = (long)shc_current_time;
				header->time_out = (long)header->time_in + issuerTimeOut;
			}
	
	
			char tmpLogId[sizeof(header->msg.shclog_id)];
			istsafe_strcpy(tmpLogId, sizeof(tmpLogId), header->msg.shclog_id);
			mb_getUmi(header->msg.shclog_id, sizeof(header->msg.shclog_id));
			thisShcApp->shcTimerObj->shc_time_message_x( header, (unsigned char *)header->segment );
        	header->msg.netcode = header->eventId;
			int tmpShcerr = header->shcerr;
			header->shcerr = SH_SENDISS;
			OTraceDebug("D-SHC-176011:Send On Dot notification to On Dot directly.\n");
			thisShcApp->shcmsgHelperObj->shc_route(header);	
	
			istsafe_strcpy(header->msg.shclog_id, sizeof(header->msg.shclog_id), tmpLogId);
			header->shcerr = tmpShcerr;
		}
		if (ipLen > 0)
			header->setSegmentData((char*)&instProfile, ipLen, NETWORK_DATA_REQ_id, ISS_INST_PROFILE_ENTRY);
		if (rLen > 0)
			header->setSegmentData((char*)&r, rLen, NETWORK_DATA_REQ_id, ROUTING_INFO);
		istsafe_strcpy(header->msg.issuer, sizeof(header->msg.issuer), tmpIssuer);
		header->issShcBin = origIssuerBin;
		header->msg.msgtype = header->msg.flipped_msgtype;
		header->msg.flipped_msgtype = tmpMsgtype;
	}
	return 0;
}



ShcProcessor *ShcmsgODHelper::enqueueInternalMsg(ShcmsgODHeader *hd)
{

	ShcmsgHeader * hdr = (ShcmsgHeader *)hd;
	hdr->truelength();

	//R028777 - Calculate truelength() first to avoid miscalculating the segments
	ShcProcessor *newProcessor = shcProcessorRegistration.getTargetObj((char *)(&hd->msg));
	if (!newProcessor)
		return NULL;

	newProcessor->header->flag          = hdr->flag;
	newProcessor->header->shcerr        = hdr->shcerr;
	newProcessor->header->time_in       = hdr->time_in;
	newProcessor->header->time_out      = hdr->time_out;
	newProcessor->header->eventId       = hdr->eventId;
	newProcessor->header->applMailboxId = hdr->applMailboxId;

	newProcessor->header->repeatFlag    = hdr->repeatFlag;
	newProcessor->header->setSkipFlag(hdr->procFlag);
	newProcessor->header->logFlag       = hdr->logFlag;
	//    newProcessor->header->setSenderId   = hdr->senderId;
	((ShcmsgHeader *)(newProcessor->header))->allocateAndCopyOrigMsg(hdr->origMsg);
	((ShcmsgHeader *)(newProcessor->header))->allocateAndCopyReqMsg(hdr->reqMsg);

	OTraceDebug("D-SHC-176009: ShcmsgODHelper::enqueueInternalMsg[%p]\n", newProcessor );
	newProcessor->header->flag |= MSG_CREATED_INTERNAL;
	shcApp->msgQueue.join(newProcessor);
	return newProcessor;

}

int ShcmsgODHelper::processLateResponse(ShcmsgODHeader *header)
{

	struct s_ODDecision *decision = header->getDecision();
	header->msg.msgtype = SHC_OD_LATERESP;

	header->logFlag  = SHC_LOG_LATE_RESP;
	header->shcerr = SH_IGNORE;
	istsafe_strcpy(header->msg.shclog_id, sizeof(header->msg.shclog_id),header->ODMsg.logId);
	OTraceInfo("I-SHC-176010: On Dot Late Response:[%s/%d/%s/%s]\n", decision->logId, decision->eventId, decision->DE39,decision->OnDotVector);
	syslg("I-SHC-176010: On Dot Late Response:[%s/%d/%s/%s]\n", decision->logId, decision->eventId, decision->DE39,decision->OnDotVector);
	return (0);

}
