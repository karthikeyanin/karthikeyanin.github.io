static char _ShcmsgEventRev_cxx_what[] = "@(#) ShcmsgEventRev.cxx 1.6 12/05/14 07:50:23";

/*
 *  Copyright (C) 2004 eFunds Corporation ("eFunds").  All Rights Reserved.     
 *  eFunds Canada Corporation is an authorized user.                            
 *                                                                              
 *  IST is a registered trademark of eFunds Corporation.  Other brand or        
 *  product names are trademarks or registered trademarks of their respective   
 *  holders.                                                                    
 *                                                                              
 *  The information contained herein is the unpublished proprietary property    
 *  of eFunds.  Except as specifically authorized in writing by eFunds, the     
 *  holder of this document shall: i) keep all information contained herein     
 *  confidential, and ii) protect the information, in whole or in part, from    
 *  disclosure and dissemination to all third parties.                          
 *                                                                          
 *  This document and the software described in it are furnished under license  
 *  and may be used or copied only in accordance with the terms of such license.
 *  This document is supplied for information purposes only, is subject to      
 *  change without notice, and should not be construed as a commitment by       
 *  either eFunds Corporation or eFunds Canada Corporation. 
 *
 *
 *
 *                        MODIFICATION HISTORY                  REVIEW
 *
 *	SPR#	Who	Date	Description			Who	Date   
 * ===========================================================================
 * R0xxxxx jyang 09Dec03 Created
 */

//File Number 96

#include <ShcmsgEvent.h>
#include <ShcRevReqHelper.h>
#include <ShcSaf.h>
#include <ShcmsgEventRev.h>
#include <ShcApp.h>
#include <ShcmsgEventHelper.h>



int g_failed_posauth = 0;

int ShcmsgEventRev::doWork()
{
//	ShcmsgEvent::doWork();
	int tmpMsgtype; //R030474
	if ( ! header->shouldContinue(TXN_PROC_SKIP_DOWORK) )
		return False;
		
	if ( thisShcApp->shcmsgEventHelperObj->retryOnTimeout(header, shcBin) == True )
	{
		header->setSkipFlag();
		return False;
	}
	
	if ( !header->shouldContinue(TXN_PROC_SKIP_DOWORK) )
		return 0;

	switch(header->msg.msgtype)
	{
	case	SHC_REVREQ:
	case	SHC_REVREQ_REPEAT:
		tmpMsgtype = header->msg.msgtype; //R030474
		if( posauth_failed || thisShcApp->shcmsgEventHelperObj->doPositiveAuth( header, shcBin, 1 )==False )
			thisShcApp->shcmsgEventHelperObj->procRevEvent(header);
		if (header->shcerr & SH_RETURN)
		{
			thisShcApp->shclog_specified_msgtype = tmpMsgtype; //R030474
			header->logFlag |= SHC_LOG_UPD_REQ;
		}
		break;

	case	SHC_REVREQ_ADVICE:
		g_failed_posauth = posauth_failed;
		thisShcApp->shcmsgEventHelperObj->procAdviceEvent(header, shcBin);
		g_failed_posauth = 0;
		/* For now we just drop it. */
		header->shcerr = SH_IGNORE;
		break;

	default:
		OTraceError("E-SHC-096001: Undefined msgtype[%04d]\n", header->msg.msgtype );

		break;
	}
	
	
	
	return 0;
}





