static char _ShcAdminEvent_cxx_what[] = "@(#) ShcAdminEvent.cxx 1.4 04/12/20 15:55:32";

/*
 *  Copyright (C) 2004 eFunds Corporation ("eFunds").  All Rights Reserved.     
 *  eFunds Canada Corporation is an authorized user.                            
 *                                                                              
 *  IST is a registered trademark of eFunds Corporation.  Other brand or        
 *  product names are trademarks or registered trademarks of their respective   
 *  holders.                                                                    
 *                                                                              
 *  The information contained herein is the unpublished proprietary property    
 *  of eFunds.  Except as specifically authorized in writing by eFunds, the     
 *  holder of this document shall: i) keep all information contained herein     
 *  confidential, and ii) protect the information, in whole or in part, from    
 *  disclosure and dissemination to all third parties.                          
 *                                                                          
 *  This document and the software described in it are furnished under license  
 *  and may be used or copied only in accordance with the terms of such license.
 *  This document is supplied for information purposes only, is subject to      
 *  change without notice, and should not be construed as a commitment by       
 *  either eFunds Corporation or eFunds Canada Corporation. 
 *
 *
 *
 *                        MODIFICATION HISTORY                  REVIEW
 *
 *	SPR#	Who	Date	Description			Who	Date   
 * ===========================================================================
 * R0xxxxx jyang 09Dec03 Created
 */

//File Number 52

#include <ShcApp.h>
#include <ShcAdminEvent.h>
#include <ShcmsgEventHelper.h>

//The original message came from istreplay. So just remove event and drop the msg.
int ShcAdminEvent::enrich()
{
	
	tm_dequeue(header->eventId);
	header->eventId = -1;

	if ( header->msg.msgtype == SHC_ISS_ADMIN 
	  || header->msg.msgtype == SHC_ISS_ADMIN_ADVICE )
	{
		shcBin = header->acqShcBin;
	}
	else
	{
		//Form ShcmsgEvent:enrich
		/*
		*	Remove the message from the event queue
		*/
		shcBin = header->issShcBin;
	}
	return 0;
}

int ShcAdminEvent::doWork()
{
	/*  Handle 06xx time out  */
	//ShcmsgEvent:doWork()
	if ( ! header->shouldContinue(TXN_PROC_SKIP_DOWORK) )
		return False;
		
	if ( thisShcApp->shcmsgEventHelperObj->retryOnTimeout(header, shcBin) == True )
	{
		header->setSkipFlag();
		return False;
	}
		
	switch(header->msg.msgtype)
	{
	case	SHC_ISS_ADMIN:
	case	SHC_ISS_ADMIN_ADVICE:
	case	SHC_ADMIN:
	case	SHC_ADMIN_ADVICE:
		header->shcerr = SH_IGNORE;
		break;

	default:
	
		break;
	}
	
	header->shcerr = SH_IGNORE;
	OTraceDebug( "D-SHC-052001: Leave ShcAdminEvent::doWork()\n" );
	
	return 0;
}
