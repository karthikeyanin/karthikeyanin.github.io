static char _ShcPreauthHelper_cxx_what[] = "@(#) ShcPreauthHelper.cxx 1.11 17/03/08 15:07:26";

/*
 *  Copyright (C) 2004 eFunds Corporation ("eFunds").  All Rights Reserved.     
 *  eFunds Canada Corporation is an authorized user.                            
 *                                                                              
 *  IST is a registered trademark of eFunds Corporation.  Other brand or        
 *  product names are trademarks or registered trademarks of their respective   
 *  holders.                                                                    
 *                                                                              
 *  The information contained herein is the unpublished proprietary property    
 *  of eFunds.  Except as specifically authorized in writing by eFunds, the     
 *  holder of this document shall: i) keep all information contained herein     
 *  confidential, and ii) protect the information, in whole or in part, from    
 *  disclosure and dissemination to all third parties.                          
 *                                                                          
 *  This document and the software described in it are furnished under license  
 *  and may be used or copied only in accordance with the terms of such license.
 *  This document is supplied for information purposes only, is subject to      
 *  change without notice, and should not be construed as a commitment by       
 *  either eFunds Corporation or eFunds Canada Corporation. 
 */
/*
 *
 *                        MODIFICATION HISTORY                  REVIEW
 *
 *	SPR#	Who	Date	Description			Who	Date   
 * ===========================================================================
 * R021024 bby   27Aug07 PAN/CVV/CVV2/Track2 Masking
 * R023310 Ram   27May08 SDK header should refer external header
 */

//File Number 108

#include <shc.h>
#include <shcdef.h>
#include <ShcSdkCommon.h>
#include <ShcPreauthHelper.h>
#include <ShcTimerHelper.h>
#include <ShcmsgHelper.h>
#include <ShcHelper.h>	//	---	R023310
#include <ShcFinAuthHelper.h>
#include <ShcApp.h>
#include <shcpreauth.h>
#include <ShcMsgCache.h>
#include <ShcBin.h>
#include <tm.h>



int ShcPreauthHelper::mbPreauthAgtId = (-1);

int ShcPreauthHelper::find_preauth_agent()
{
	if( mbPreauthAgtId < 0 )
		mbPreauthAgtId = mb_locatemailbox( PREAUTH_AGENT_NAME );
	return ( mbPreauthAgtId );
}

int ShcPreauthHelper::shc_preauth_confirm(ShcmsgHeader *header)
{
	int o_netcode, o_msgtype, o_origmsg;

	header->msg.device_cap |= SH_DEVCAP_PREAGENT_STATE;
	
	/* Check if the confirmed amount is greater than that preauthorized */
	if(dbm_deccmp(&header->msg.amount, &header->msg.aval_balance) > 0)
		return(SHC_RC_PreauthAmtExceeded);

	if(find_preauth_agent() < 0)
	{
		OTraceFatal("F-SHC-108001:Err locating preauth agent.\n");
		return(SHC_RC_SystemError);
	}
	else
	{
		/* Put the message on the event queue */
		if(thisShcApp->shcTimerObj->shc_time_message(header) < 0)
		{
			/* Deny transaction */
			OTraceFatal("F-SHC-108002:Err placing preauth conf req on queue.\n");
			return(SHC_RC_SystemError);
		}
		else
			OTraceInfo("I-SHC-108003:Placed preauth conf req in event queue.\n");
	}

	/*
		Send the message to the agent to get needed indexes.
		The message type has to be SHC_PREAUTH_SERVICEREQ 
		and the netcode has to be of the "return" type
	*/
	o_origmsg = header->msg.origmsg;
	o_msgtype = header->msg.msgtype;
	o_netcode = header->msg.netcode;

	header->msg.msgtype = SHC_PREAUTH_SERVICEREQ;
	header->msg.netcode = PreauthServRetRec;
	header->msg.origmsg = o_msgtype;

	if(cache_mb_write(mbPreauthAgtId, shcmid, (char *)&header->msg, sizeof(header->msg))<0)
	{
		OTraceFatal("F-SHC-108004:Err writing srv-ret msg to preauth agent.\n");
		tm_dequeue(header->eventId);

		/* Restore confirmation request message */
		header->msg.msgtype = o_msgtype;
		header->msg.netcode = o_netcode;
		header->msg.origmsg = o_origmsg;
		OTraceLog("L-SHC-10813: Failed to send msg ID[%s] /m%04d/t%d/p%06d to %s\n",
			header->msg.shclog_id, header->msg.msgtype, header->msg.trace, 
			header->msg.pcode, mbMailBoxName(mbPreauthAgtId));

		return(SHC_RC_SystemError);
	}
	else
		OTraceLog("L-SHC-10814: Sent msg ID[%s] /m%04d/t%d/p%06d to %s\n",
			header->msg.shclog_id, header->msg.msgtype, header->msg.trace, 
			header->msg.pcode, mbMailBoxName(mbPreauthAgtId));

	/* Restore confirmation request message */
	header->msg.msgtype = o_msgtype;
	header->msg.netcode = o_netcode;
	header->msg.origmsg = o_origmsg;

	return(SHC_RC_Approved);
}

int ShcPreauthHelper::shc_preauth_response(ShcmsgHeader *header)
{
	int o_netcode,o_msgtype, o_origmsg;

	/*	Change the preauth response to preauth service request:
			- The netcode should be set for insert
			- the message type should be a service request
		Change back to originals afterward
	*/

	OTraceDebug("D-SHC-108005:Save the following message:\n");
	OTraceDebug("D-SHC-108006:t(%ld),ld(%ld),lt(%ld),t(%s),p(%s),a(%s)\n", header->msg.trace,
	   header->msg.local_date, header->msg.local_time, header->msg.termid,
	   shcApp->shcHelperObj->shc_maskpan(header->msg.pan), header->msg.acquirer);		//	---	R021024

	o_origmsg = header->msg.origmsg;
	o_msgtype = header->msg.msgtype;
	o_netcode = header->msg.netcode;

	header->msg.origmsg = o_msgtype;
	header->msg.msgtype = SHC_PREAUTH_SERVICEREQ;
	header->msg.netcode = PreauthServInsRec;

	/*
	 * 10002264 qd 22jul96 Send message to preauth agent only if it is up
	 */
	if(find_preauth_agent() < 0)
	{
		OTraceWarning("W-SHC-108007: Preauth Agent is not running\n"); 
	}
	else
	{
		OTraceDebug("D-SHC-108008:I-SHC-PREAUTH: Sending message to Preauth Agent\n"); 
		if (cache_mb_write(mbPreauthAgtId, shcmid, (char *)&header->msg, sizeof(header->msg))< 0)
		{
			OTraceLog("L-SHC-10811: Failed to send msg ID[%s] /m%04d/t%d/p%06d to %s\n",
				header->msg.shclog_id, header->msg.msgtype, header->msg.trace, 
				header->msg.pcode, mbMailBoxName(mbPreauthAgtId));
		}
		else
			OTraceLog("L-SHC-10812: Sent msg ID[%s] /m%04d/t%d/p%06d to %s\n",
				header->msg.shclog_id, header->msg.msgtype, header->msg.trace, 
				header->msg.pcode, mbMailBoxName(mbPreauthAgtId));

	}

	header->msg.origmsg = o_origmsg;
	header->msg.msgtype = o_msgtype;
	header->msg.netcode = o_netcode;
	return(0);
}



int ShcPreauthHelper::shc_conf_process(ShcmsgHeader *header)
{
	int ret;

	/* 22Jun93: Check for pre-auth confirmation */
	if(shcmsgIsProAgentConfReq(&header->msg))
	{
		thisShcApp->shcTimerObj->shc_set_timers(header);

		if(shcmsgHeaderIsFullAuth(header) || shcmsgHeaderPreauthForwardAllowed(header))
			header->shcerr |= SH_SENDISS;
		else	
		{
			OTraceInfo("I-SHC-108009:Conf response to acquirer.\n"); 
			thisShcApp->shcFinAuthHelperObj->shc_return_finauth(header, -1);
			return(0);
		}
	}
	else
	{
		/* This is the message first time around */
		if((ret=shc_preauth_confirm(header)) != SHC_RC_Approved)
		{
			header->msg.respcode = ret;
			if(shcmsgHeaderIsFullAuth(header))
				header->shcerr |= SH_SENDISS;       /* SPR#10002264 */ 
			else
			{
				if(shcmsgHeaderPreauthForwardAllowed(header))
					header->shcerr |= SH_SENDISS;   /* SPR#10002264 */ 
				else /* Forward not allowed : Respond to request */
				{									/* SPR#10002264 */
					thisShcApp->shcFinAuthHelperObj->shc_return_finauth(header, ret);/* SPR#10002264 */
					return(0);                      /* SPR#10002264 */
				}                                   /* SPR#10002264 */
			}
		}
		else
		{
			/* Drop msg if approved: we have it on the event queue*/
			header->shcerr = SH_IGNORE;
			return(0);
		}
	}
	return(1);
}

int ShcPreauthHelper::shc_advice(ShcmsgHeader *header)
{
	/*
	 *	o	We perform very little checking:	This routine
	 *		is strictly to route s&f replay transactions.
	 */
	struct ShcmsgWithSegment omsg = {0};

	/*
	 *	o	Determine routining paramaters
	 */
	header->shcerr = SH_SENDISS | SH_SETTIMER;
	

	/*
	 *	o	Determine time out value
	 */
	if (header->time_in >=10000000000)
		header->time_out = header->time_in + 1000*shcApp->issuerShcParamsList->GetNum("shc.saf_timeout");
	else
		header->time_out = header->time_in + shcApp->issuerShcParamsList->GetNum("shc.saf_timeout");

	/*
	 *	o	Determine if original transaction was rejected or not
	 */
	if(((ShcLog *)header->shcLogObj)->locateTxn(header, &(omsg.msg), NULL) >= 0)
	{
		/* 
		*	If original txn is rejected  and
		*		txn is not reversed and
		*		txn is not a reversal type of txn
		*	THEN
		*		skip it.
		*/
		if(omsg.msg.respcode != SHC_RC_Approved  && 
		   omsg.msg.shcerror != SHC_IE_Reversed &&
		   !shcmsgIsReversal(&(omsg.msg))	)
		{
			OTraceInfo("I-SHC-108010:Orignal txn (%d %ld) Respcode:%d. Return to sender\n",
				omsg.msg.msgtype, omsg.msg.trace, omsg.msg.respcode);
			header->shcerr = SH_RETURN;
			thisShcApp->shcmsgHelperObj->shc_set_return_msgno(&header->msg);
		}
	}
	((ShcLog *)header->shcLogObj)->rewind();

	/*
	 *	Route the message
	 */
	return(0);
}



