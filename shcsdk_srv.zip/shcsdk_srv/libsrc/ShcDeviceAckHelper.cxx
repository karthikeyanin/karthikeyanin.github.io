static char _ShcDeviceAckHelper_cxx_what[] = "@(#) ShcDeviceAckHelper.cxx 1.7 12/03/28 04:14:29";

/*
 *  Copyright (C) 2004 eFunds Corporation ("eFunds").  All Rights Reserved.     
 *  eFunds Canada Corporation is an authorized user.                            
 *                                                                              
 *  IST is a registered trademark of eFunds Corporation.  Other brand or        
 *  product names are trademarks or registered trademarks of their respective   
 *  holders.                                                                    
 *                                                                              
 *  The information contained herein is the unpublished proprietary property    
 *  of eFunds.  Except as specifically authorized in writing by eFunds, the     
 *  holder of this document shall: i) keep all information contained herein     
 *  confidential, and ii) protect the information, in whole or in part, from    
 *  disclosure and dissemination to all third parties.                          
 *                                                                          
 *  This document and the software described in it are furnished under license  
 *  and may be used or copied only in accordance with the terms of such license.
 *  This document is supplied for information purposes only, is subject to      
 *  change without notice, and should not be construed as a commitment by       
 *  either eFunds Corporation or eFunds Canada Corporation. 
 */
/*
 *
 *                        MODIFICATION HISTORY                  REVIEW
 *
 *	SPR#	Who	Date	Description			Who	Date   
 * ===========================================================================
 *	ad		24nov92		Added logic to route an ACK
 *	ad		05mar94		If no 9000 pending then just stop processing.
 *  la      12may96     Patch recommened from support (dk) for mailbox events.
 *  wrg     961115      Added forward-NAK support
 *  wrg     961204      Added support for timer-segment ops 
 *  yh R001564 23Mar99  Also use new_amount for partial reversal
 *  R007062	gbeeng	26Nov2001	C++ Migration
 *  R018276	pve	27Nov06		Add new OTraceLog messages
 *  R028271     dipa    18Jun10		Txn Statistics
 *  R030381		dipa	02Mar12		Remove TXNSTAT macro
 */

//File Number 69

#include <stdio.h>
#include <string.h>
#include <oasis.h>
#include <ist_otrace.h>
#include <mb.h>
#include <shc.h>
#include <tm.h>

#include <ShcDeviceAckHelper.h>
#include <ShcmsgHelper.h>
#include <ShcApp.h>
#include <ShcBin.h>
#include <ShcmsgTxnHelper.h>
#include <mb_umi.h>	//	R018276

//R028271 >>>
#include <TxnStat.h>
//<<< R028271

	
/*****************************************************************************/
int ShcDeviceAckHelper::removeAckEvent(ShcmsgHeader *header)
{

	if(!shcIsConfirmPending(header))
		if(thisShcApp->shcmsgHelperObj->shc_locate_device_message(header) < 0)
			return(-1);
	
	/*	Remove from the event queue */
	if(!shcIsConfirmPending(header))
		tm_dequeue(header->eventId);
	
	return 0;
}

/*****************************************************************************/
int ShcDeviceAckHelper::sendAck2Issuer(ShcmsgHeader *header)
{
	/*	24nov92 */
	/*	Check if we need to send an ACK to the issuer */
	if((header->issShcBin->binPkg->bin.flags & SH_SENDACK) && !shc_isdown(header->issShcBin->binPkg))
	{
		header->shcerr = SH_SENDISS;
		header->msg.msgtype = SHC_FINREQ_ACK;
		thisShcApp->shcmsgHelperObj->shc_dispmsg(header);
		
		thisShcApp->shcmsgHelperObj->shc_route(header);
		
		header->msg.msgtype = SHC_DEVICE_ACK;
	}
	
	return 0;
}

/*****************************************************************************/
int ShcDeviceAckHelper::generate500Msg(ShcmsgHeader *header)
{
	if(!shcIsConfirmPending(header))
	{
		header->shcerr = SH_IGNORE;
		return -1;
	}
	
	/*	Send a 500 message */
	if(
		/*	Institution requires a 500 */
		(header->acqShcBin->binPkg->bin.flags & SH_SEND500) && 

		/*	Transaction moved cash from the device */
	   	(header->msg.txntype & (SH_TX_DEP | SH_TX_WD)) &&

		/*	The transaction was successful */
		(header->msg.respcode == 0)	&&

		/*	and the acquirer NOT equal to the issuer */
		(stricmp(header->issShcBin->binPkg->bin.networkid, header->acqShcBin->binPkg->bin.networkid) != 0)
	  )
	{

		/*	Change the message type appropriatly */
		header->msg.msgtype = SHC_STLMTREQ;

		/*	Then format and send a 500 */
///////////////////		shc_stlmtreq(header);
		
		//	>>>	R018276
		mb_getUmi(header->msg.shclog_id, sizeof(header->msg.shclog_id));
		mb_set_tid(header->msg.shclog_id, strlen(header->msg.shclog_id));
		OTraceLog("L-SHC-069001: Created message ID[%s] /m%04d\n", header->msg.shclog_id, header->msg.msgtype);
		//R028271 >>>
		TxnStatReport(header->msg.shclog_id,TS_SHC,TSR_CREATE,header->msg.msgtype,0,0);
		//<<< R028271
		//	>>>	R018276

		if (thisShcApp->shcmsgTxnHelperObj->enqueueInternalMsg(&header->msg) == NULL)
			return -1;
	}
	else
		header->shcerr = SH_IGNORE;

	return 0;
}


/*****************************************************************************/

