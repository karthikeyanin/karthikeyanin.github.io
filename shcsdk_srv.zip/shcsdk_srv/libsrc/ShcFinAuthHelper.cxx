static char _ShcFinAuthHelpercxx_what[] = "@(#) ShcFinAuthHelper.cxx 1.87.29.3 19/11/20 07:00:17";

/*
 *  Copyright (C) 2004 eFunds Corporation ("eFunds").  All Rights Reserved.     
 *  eFunds Canada Corporation is an authorized user.                            
 *                                                                              
 *  IST is a registered trademark of eFunds Corporation.  Other brand or        
 *  product names are trademarks or registered trademarks of their respective   
 *  holders.                                                                    
 *                                                                              
 *  The information contained herein is the unpublished proprietary property    
 *  of eFunds.  Except as specifically authorized in writing by eFunds, the     
 *  holder of this document shall: i) keep all information contained herein     
 *  confidential, and ii) protect the information, in whole or in part, from    
 *  disclosure and dissemination to all third parties.                          
 *                                                                          
 *  This document and the software described in it are furnished under license  
 *  and may be used or copied only in accordance with the terms of such license.
 *  This document is supplied for information purposes only, is subject to      
 *  change without notice, and should not be construed as a commitment by       
 *  either eFunds Corporation or eFunds Canada Corporation. 
 *
 *
 *                        MODIFICATION HISTORY                  REVIEW
 *
 *	SPR#	Who	Date	Description			Who	Date   
 * ===========================================================================
 *R00xxxx ztang 05Nov03 Creation
 *R012134 Emj   04Oct04 Issuer Entity Support
 *R012160 Emj   10Oct04 Restore Processor Business Day
 *R012339 Emj   08Nov04 Emv Buffer Bitmap
 *R012381 Emj   12Nov04 New Field tvr_cvr_status in emvbuf
 *R011629 emj   12Aug04 SAF Interleave merged R011312
 *R013872 Emj   20Apr05 Restore Application Transaction counter in response
 *R011836 ztang 03Sep04 Restore track3 conditionally
 *R014738 Emj   28Sep05 Restore Arpc responsecode
 *R015826 pve	03Mar06	Support for Generic Log
 *R016038 pve	21Mar06 Avoid sendding 120/220 messages to issuer when 'reversal to issuer' set to N
 *R016293 Emj   20Apr06 Log No Key Error in security error log (interac)
 *R016396 pve	12May06	Fix the problem of mixing trandate with local_date for void Txn
 *R017683 jyang 11Sep06 Set time_out for timing event
 *R018579 pve	03Jan06	Copy respcode from original txn for repeat msg
 *R018609 spa	09Jan07	When origmsg is null, assign cap_date to origdate only for interac, else assign trandate to origdate
 * R018754 Emj   21Jan07 Restore EMV_BUf if orignal had EMV_BUF
 * R018276 pve	 05Feb07 Use numeric only unique debug id
 *R019631 spa	18Apr07	Add new method setBalances
 *R021843 bby   01Nov07 clone from R019906 and R021767 
 *R023310 Ram   27May08 SDK header should refer external header
 *R023574 lee   11Jun08 Restoring auth_devcap flag
 *R023962 sks   18Jul08 Check the return value of tm_dequeue() in Event Processing
 * R025674 sel	19Jan09	Avoid pin translation when txn is not routed to destination
 *R025796 sks	30Jan09	Modify checkRespMac function,change respcode when denied 210/110 has mac error
 *R026319 Dipa  07Apr09 Check done for 0130 in addition to 0230 advice message
 *R026484 Emj   07May09 restore the card_seqno from the original message
 *R026976 Dipa  21Jul09 Advice Repeat message not to be considered as duplicate message
 *R026977 Dipa  21Jul09 While processing repeat txn, loop for approved txn ignoring duplicate txn response
 *R027060 Dipa  18Aug09 Advice repeat txns included in decideSaf()
 *R027311 Dipa  05Oct09 Skip zero amount check for preauth completion txns
 *R027338 sks	09Oct09	Restore cash_back amount from the original message
 *R027355 Dipa  19Oct09 Restore authnum from original preauth completion 120 txn
 *R027543 Dipa  17Nov09	Set shcerror to Void and set flag to update original txn for void txn
 *R027320 Dipa  17Nov09 Log all repeat txn in SHCLOG with shcerror=7, skip duplicate checking for all advice messages
 *R027562 Dipa  27Nov09 Log all Saf replies in SHCLOG with shcerror=8
 *R027868 vmp	22Feb10	Allow Zero amount for Account verification msgs
 *R027876 Dipa  02Mar10 Segment Changes
 *R027905 Dipa  25Mar10 Reversal-Void Enhancement
 *R028031 Dipa	09Apr10	Clone of R027963
 *R028209 Dipa	28May10	Clone of R029198 - Set respcode to SHC_RC_ChipArqcFail for ARQC Verification failure
 *R028265 Dipa	16Jun10 Do not restore chip index for repeat auth txns.
 *R028271 Dipa  18Jun10 Txn Statistics
 *R028735 Dipa  15Nov10 Generate authnum for refund txns approved by SHC.
 *R028735 Dipa  15Nov10 Initialise alpha_resp_code to zero for refund txns approved by SHC.
 *R028745 Dipa  17Nov10 Clone of R028674, R028675, R028676
 *R028735 Dipa  24Nov10 Remove the change - Initialise alpha_resp_code to zero for refund txns approved by SHC.
 *R028735 Dipa  24Nov10 Skip sending the void of SHC-approved-txns to LRS
 *R028810 Dipa  13Dec10 Restore request msgtype after enqueuing, for refund txns
 *R028908 Dipa  18Jan11 Use shc.response_on_duplicate to respond for duplicate transactions
 *R030046 Dipa  19Oct11 Retrieve origseglist and store as current seglist in restoreForRepeat()
 *R030207 Dipa  23Feb12 Clone of R030323 -  Set shcerror = SHC_IE_SafReply only for Replay txns
 *R030381 Dipa	02Mar12	Remove TXNSTAT macro
 *R030940 Anil  10Oct12 Removed R030046 changes no need to restore the segments for repeat
 *R031154 Dipa 	21Dec12	Clone of R031066
 *IST_S761SP8-47	Dipa	17Apr14	Clone of R031927, R032323
 *IST_S770SP0-88	Dipa	15Jul14	Clone of IST_S761SP8-129 - Restore EMVBUF.cvv_res_code from request msg, if not set by issuer
 *IST_S770SP5-147 IS 03JUN16 Copying the iss_entityId from request message in shc_restore_fields()
 *IST_S770SP4-292 IS 15SEP16 Restoring device_fee from request to response if device_fee is negative
*/
/* File Number 73 */

#include <stdio.h>
#include <string.h>
#include <ctype.h>
#include <sys/timeb.h>
#include <oasis.h>
#include <oasisenv.h>
#include <dbm.h>
#include <mb.h>
#if !defined(TM_MULTI_Q)
#include <mem.h>
#endif
#include <tm.h>
#include <dbm_private.h>
#include <oc/oc_string.h>
#include <ist_otrace.h>
#include <Ccard_scheme.h>
#include <Cinstitution.h>
#include <rules.h>
#include <shcmsgdef.h>
//#include <security.h> --Commented for Asynch Implementation
#include <shc.h>
#include <shcpreauth.h>
#include <ic/ic_shcmsg.h>
#include <ic/ic_instid.h>
#include <ic/ic_bin.h>
#include <ic/ic_pan.h>
#include <emvchipcond.h>
#include <ShcSender.h>
#include <istcurrency.h>
#include <shc500std.h>
#include <ShcmsgHelper.h>
#include <ShcCamHelper.h>
#include <hotrange.h>
#include <CShcLog.h>
#include <ShcmsgProcessor.h>
#include <ShcHelper.h>	//	---	R023310	
#include <ShcFinAuthHelper.h>
#include <ShcmsgHelper.h>
#include <ShcDKEHelper.h>
#include <ShcTimerHelper.h>
#include <ShcMacHelper.h>
#include <ShcIBFTHelper.h>
#include <ShcSaf.h>
#include <ShcPreauthHelper.h>
#include <ShcApp.h>
#include <ShcBin.h>
#include <ShcmsgTxnHelper.h>
#include <ShcKeyTxnHelper.h>
#include <ShcSafIOHelper.h>
#include <CShcGenericLog.h>		//	R015826
#include <ist_seg_name.h> //R027876
#include <ist_seg_elf_id_map.h> //R027876
#include <ist_seg_id.h> //R027876
#include <ShcLateRespHelper.h>	//R027905
#include <ShcNetworkMsgHelper.h>

//R028271 >>>
#include <TxnStat.h>
//<<< R028271
#include <ShcDuplicateChk.h>


int shc_edc_getworkingkey(ShcmsgHeader *header);
int shc_edc_update(ShcmsgHeader *header);

extern int defaultlasttxnrespcode=99;

#define P1C_DEST "50"

short ShcFinAuthHelper::decideChipOption(ShcmsgHeader *header, emv *emvbuf)
{
	/* Ssc 28Jun00  R004671 integration to 7.2 */
	/* Ssc 17Mar00  SPR # 2007336 set the chip type */
    if (header->issShcBin->isFullEntry())
    {
        return SHC_CHIP_TYPE_FULL;
    }
    else
    {
        return SHC_CHIP_TYPE_EARLY;
    }
}

//void ShcFinAuthHelper::setFlagForEDC(ShcmsgHeader *header)
//{
//	/* R006339  >>>>>>> */
//	if(shcmsgIsEDC(&header->msg))
//	header->msg.device_cap |= SH_DEVCAP_FROMDEVICE;
//}

//int ShcFinAuthHelper::getEDCKey(ShcmsgHeader *header)
//{
//	if(shcmsgIsEDC(&header->msg) && header->msg.mac.key[0] == '\0')
//		if(shc_edc_getworkingkey(header) != SHC_RC_Approved)
//		/* R006789  	 return(-1);	*/
//	  	{
//			shc_return_finauth(header, -1);		/* R006789 */
//			return -1;
//	  	}
//	return 0;
//}

int ShcFinAuthHelper::zeroAmountCheck(ShcmsgHeader *header)
{
	/*	28nov96	for adjustment from pos, don't check for 0 amt	*/
	if (   (header->msg.msgtype == SHC_FINREQ_ADVICE || header->msg.msgtype == SHC_AUTHREQ_ADVICE)&&
		  (shcGetProcessCode(header->msg.pcode) == SH_ISO_CREDIT_ADJUST ||
		   shcGetProcessCode(header->msg.pcode) == SH_ISO_DEBIT_ADJUST  ||
		   shcGetProcessCode(header->msg.pcode) == SH_ISO_PREAUTHCONF )  ) //R027311
		{ OTraceInfo("I-SHC-073001:msgtype='%d',and pcode='%d',no 0 amt check\n",	SHC_FINREQ_ADVICE,header->msg.pcode);}

		//	>>>	R027868
		//Check account verification for Zero amount txns
	else if ( (header->msg.pos_condition_code & SH_POS_COND_AVS) && 
			(dbm_decncmp(&header->msg.amount, (double)0) == 0) )
	{
		OTraceDebug("I-SHC-073049: Account verification for 0 amt transactions. No need to deny the txn\n");

	}
	else if ( ( header->issShcBin->binPkg->bin.bin_cfg & SH_CFG_ALLOW_ZERO_AMT_PREAUTH ) &&
		  ( header->msg.pos_condition_code & SH_POS_COND_REQ_PREAUTH ) &&
		  (dbm_decncmp(&header->msg.amount, (double)0) == 0)
		 )
	{
		OTraceInfo("I-SHC-073099: Pre Auth with 0 amt transactions, for extending chargeback protection period. No need to deny the txn\n" );
	}
		//	<<<	R027868
	/*	check for zero amounts */
	else if( header->msg.txntype & 
		(SH_TX_WD | SH_TX_TSF | SH_TX_CC
		| SH_TX_SERVICES))
	{
		if(ist_otrace_get_level() >= OTRACE_DEBUG)
		{
			char	buf1[50], buf2[50];
			dbm_dectochar(&header->msg.amount, buf1);
			dbm_dectochar(&header->msg.cash_back, buf2);
			OTraceInfo("I-SHC-073002: finreq():check for 0 amt (%s, %s).\n",buf1,buf2);
		}

		if(dbm_decncmp(&header->msg.amount, (double)0) == 0
		   && dbm_decncmp(&header->msg.cash_back, (double)0) == 0)
		{
			OTraceError("E-SHC-073003: Amount is zero: Not Allowed.\n");
			return(-1);
		}
	}
	return 0;
}

int ShcFinAuthHelper::authorizeFloorLimit(ShcmsgHeader *header)
{
	/*	23oct92 */
	if(header->issShcBin->binPkg->bin.flags & SH_CHKFLRLIM)
	{
		if(thisShcApp->shcmsgTxnHelperObj->shc_checkfloorlimit(header) != SHC_RC_Continue)
		{
			OTraceDebug("I-SHC-073004:authorised on floor limit\n");
			/*	authorized on floor limit */
			shc_return_finauth(header, SHC_RC_Approved);
			return(-1);
		}
	}
	
	return 0;
}

int ShcFinAuthHelper::decideConfProcess(ShcmsgHeader *header)
{
	/* Is the institution currently down */
	if(!(header->msg.device_cap & SH_DEVCAP_FROM_REPLAY))
	{
 		/*
		 * R001835 More control of preauth
		 *
         * Added one more constraint (PreAuth Server exists) to go further
         * for confirmation message 0220. ACXSYS. 1998/01/14.
         */
		if( shcmsgIsPreAuthConfReq(&header->msg) )
		{
			if( checkIsBillPayTxn(header) )
			{
				OTraceDebug("D-SHC-073067: decideConfProcess billPay_txn header->msg.origrespcode %d\n",header->msg.origrespcode);
				if( SHC_RC_Approved == header->msg.origrespcode )
				{
					header->msg.respcode = header->msg.origrespcode;
					thisShcApp->shcFinAuthHelperObj->shc_return_finauth(header, header->msg.origrespcode);
					header->setSkipFlag();
					return(-1);
				}
			
			}
			else if( shcRequiresPreAuthorization(header->issShcBin->binPkg) )
			{
				if(thisShcApp->shcPreauthHelperObj->shc_conf_process(header) == 0)
				{
					header->setSkipFlag();
					return(-1);
				}
			}
		}
	}
	return 0;
}

int ShcFinAuthHelper::decideSaf(ShcmsgHeader *header)
{
	struct shcpkg *issPkg = header->issShcBin->binPkg;
	/* Is the institution currently down */
	if(!(header->msg.device_cap & SH_DEVCAP_FROM_REPLAY))
	{

		/*
		 * R001835 SAF 120/220 for Interac
		 */
		 /* R007472 */
    //	>>>	R021843	  

	if ( shcIsAllAdvice(header) && (!shc_isdown(issPkg)) //R027060
	&& (!(header->issShcBin->binPkg->bin.flags & SH_GETAPP_HOST))		// -> acquirer -> issuer -> saf
	&& (!(shcApp->saf_interleave&&shc_isreplay(issPkg))) )
	{
	OTraceInfo("I-SHC-8709.2: Respond advice txn to acquirer first, then issuer\n");
	int msgtypeOrig  = header->msg.msgtype;
	int respcodeOrig = header->msg.respcode;
	int ret = shc_return_finauth(header, SHC_RC_Approved);
	if ( ret != SHC_RC_Approved )
	{
	OTraceInfo("I-SHC-8709.3: Direct response advice message was denied.[%d]\n", ret);
	return ret;
	}
	header->msg.msgtype  = msgtypeOrig;
	header->msg.respcode = respcodeOrig;
	header->shcerr = SH_SENDISS | SH_SETTIMER;

	}


	else //	<<<	R021843 
	if(shc_isdown(issPkg) ||	



					(shcApp->saf_interleave&&shcIsReplay(issPkg,header->msg.iss_entityId)) || //--R011312--
					(shcmsgIsAdvice(&header->msg) && 
					(header->issShcBin->isInterac()|| header->acqShcBin->isInterac())) ||
					(shcIsAllAdvice(header) &&				//      R016038 , R027060
					!(header->issShcBin->binPkg->bin.flags & SH_GETAPP_HOST)))	//	R016038
		{
			if (!shc_safallowed(issPkg) && !shcIsAllAdvice(header)) //R027060
			{
				OTraceError("E-SHC-073043: Failed because issuer down and no SAF\n");
				/*	No store and forward allowed */
				thisShcApp->shcFinAuthHelperObj->shc_return_finauth(header, SHC_RC_IssuerDown);
				return -1;
			}
			
			if(issPkg->bin.flags & SH_CHECKPIN_STAND_IN)
				if(thisShcApp->shcmsgTxnHelperObj->shc_checkpin(header) == -1)
				{
					thisShcApp->shcFinAuthHelperObj->shc_return_finauth(header, -1);
					return -1;
				}
			/*	Then we must authorize the transaction on his behalf */
			thisShcApp->shcSafHelperObj->shc_saf(header);
			if(header->shcerr & SH_CONTINUE)
/* R004960				shc_return_finauth(header, -1); */
			{
				shc_return_finauth(header, -1);
				// R027963 >>>
				if (shcIsAllAdvice(header))
					header->logFlag &= ~SHC_LOG_REQ;
				// <<< R027963
				return -1;
			}
		}
	}
	return 0;
}

int ShcFinAuthHelper::translatePinBlock(ShcmsgHeader *header)
{
	int iRes=0;
	//	>>>	R025674
	OTraceDebug("D-SHC-073048 PIN translation\n");
	if(header->shcerr == SH_IGNORE)
	{
		OTraceInfo("I-SHC-073048: Skip Pin translation as txn not sent to destination\n");
		return 0;
	}
	//	<<<	R025674
	/* Create network pin block if needed */
	if(!shcmsgIsAdvice(&header->msg))
	{
		if ( (iRes = thisShcApp->shcmsgTxnHelperObj->shc_translate_pinblk(header)) < 0 )
		{
		/* R004989 >> */
			if (header->msg.respcode == SHC_RC_PINKeyError)
			{
				OTraceInfo("I-SHC-073006: Inc acq kpe sync counter\n");
				thisShcApp->shcDKEApiObj->shc_inc_akpesyncerrcnt_x(header);
			}
		/* << R004989 */
			shc_return_finauth(header, -1);
			return -1;
		}
		else if(iRes==SEC_ASYNCH_WAIT)
		{
			OTraceDebug("D-SHC-001231 PIN Block Translation Pending\n");
			header->shcerr=SH_IGNORE;
			header->setSkipFlag(TXN_PROC_SKIP_DOWORK);
			return SEC_ASYNCH_WAIT;
		}
		else
			OTraceDebug("D-SHC-073048 PIN translation shc_translate_pinblk<0 \n");
	}
	return 0;
}

int ShcFinAuthHelper::exitForProagentReq(ShcmsgHeader *header)
{
	/*	26Jul93
		No need to do any editing on a proagent conf request */
	if(shcIsPreAuthConfReq(header) && shcIsProAgentConfReq(header) 
		&& !shcIsAdvice(header))
		return -1;
	return 0;
}

void ShcFinAuthHelper::setOrigData(ShcmsgHeader *header)
{

	if(header->msg.origtrace == 0)	/*	support of preauth confirm's */
	{
		if( (header->msg.msgtype == SHC_FINREQ_ADVICE) && ((header->msg.pcode/10000) == SH_ISO_PREAUTHCONF))
		{
			header->msg.origtrace = atoi(header->msg.refnum+6);
			OTraceDebug("D-SHC-073059: Original trace for Pre-Auth Completion[%ld]\n", header->msg.origtrace);
		}
		else
			header->msg.origtrace	= header->msg.trace;
	}
	/*
	 * 2002847 Set origmsg, origdate and origtime iff origmsg is zero 
	 */
	if(header->msg.origmsg == 0)
	{
		if (!(header->msg.shc_devcap & SH_DEVCAP_SHC_VOID))  // R010133
			header->msg.origmsg		= header->msg.msgtype;   // R010133
		if( (header->msg.msgtype == SHC_FINREQ_ADVICE) && ((header->msg.pcode/10000) == SH_ISO_PREAUTHCONF))
		{
			header->msg.origmsg = 0;
		}
		/*header->msg.origdate	= header->msg.trandate;		R004595 */
		/*header->msg.origdate	= header->msg.cap_date;	//	---	R018609 */
		header->msg.origtime	= header->msg.trantime;
		//	>>>	R018609
		if(header->issShcBin->isInterac())
			header->msg.origdate  = header->msg.cap_date;
		else
			header->msg.origdate = header->msg.trandate;
		//	<<<	R018609
	}
}

int ShcFinAuthHelper::locateOrigForVoid(ShcmsgHeader *header)
{

	if (	(header->msg.shc_devcap & SH_DEVCAP_SHC_VOID) ||
			(header->msg.pcode/10000 == SH_ISO_PREAUTHCONF)||
			(header->reqMsg && (header->reqMsg->shc_devcap & SH_DEVCAP_SHC_VOID))
		)
	{
		int savedTrace;
		long savedTranDate;
		int savedMsgType;
		int foundOriginal = 0;
		struct ShcmsgWithSegment omsg = { 0 };
		int savedPcode = header->msg.pcode;
		int savedReqPcode = -1;
		int isVoid = 0;

		if (    (header->msg.shc_devcap & SH_DEVCAP_SHC_VOID) ||
				(header->reqMsg && (header->reqMsg->shc_devcap & SH_DEVCAP_SHC_VOID))
			)
			isVoid = 1;

		if (header->reqMsg)
		{
			savedReqPcode = header->reqMsg->pcode;
			if (header->origMsg)
				header->reqMsg->pcode = header->origMsg->pcode;
			if ((header->msg.local_date <= 0) && (header->reqMsg->local_date>0))
			{
				header->msg.local_date = header->reqMsg->local_date;
				header->msg.local_time = header->reqMsg->local_time;
			}
		}

		savedTrace = header->msg.trace;
		savedTranDate = header->msg.local_date;		//	R016396
		if (header->msg.pcode/10000 == SH_ISO_PREAUTHCONF)
		{
			static int x =0 ;
			static bool flag = false; 	
			if(!x++){
				char buf[2] = {'\0'}; 
				if( cf_openfile("...") < 0 )
				{
					OTraceWarning("W-SHC-073058: Configuration file not present.\n");
				}
				else if( cf_locate("shc.allow_local_date_zero_locate_orig", buf) <= 0 )
					flag = false; //      default value
				else if( toupper(buf[0]) == 'Y' || buf[0] == '1' )
					flag = true;
				else
					flag = false; 
			} 

			OTraceDebug("D-SHC-073059: shc.allow_local_date_zero_locate_orig[%d] \n", flag); 

			if(flag)
			header->msg.local_date = 0;	

			if(header->msg.origpcode == 0)
			{
				header->msg.pcode = header->msg.pcode - 10000;
				OTraceDebug("D-SHC-073060: Original pcode for Pre-Auth completion[%ld]\n", header->msg.pcode);
			}
			else
				header->msg.pcode = header->msg.origpcode;
		}
		else if ((header->msg.pcode != header->msg.origpcode)&& (shcIsResponse(header)))
		{
			//A site original and void have same trace number
			header->msg.pcode = header->msg.origpcode;
		}
		else
		{
			header->msg.local_time = 0;
			header->msg.local_date = 0;
		}
		
		savedMsgType = header->msg.msgtype;
		if (header->msg.origtrace > 0)
			header->msg.trace = header->msg.origtrace;
		
		if (header->reqMsg && (header->reqMsg->origmsg > 0))
			header->msg.origmsg = header->reqMsg->origmsg;

		foundOriginal = thisShcApp->shcmsgHelperObj->locateOrigTxn(header);
		// R027905 >>>
		if( foundOriginal < 0 && header->msg.respcode == SHC_RC_MismatchBatch)
		{
			header->shcerr = SH_NO_TIMER_PRESENT;
			if (thisShcApp->shcmsgTxnHelperObj->enqueueInternalMsg(header) == NULL)
				return -1;
			header->shcerr = SH_IGNORE;
			header->setSkipFlag();
			header->msg.pcode = savedPcode;
			header->msg.trace = savedTrace;
			header->msg.local_date = savedTranDate;
			header->msg.msgtype = savedMsgType;
			if (savedReqPcode>=0)
				header->reqMsg->pcode = savedReqPcode;
			((ShcLog *)header->shcLogObj)->rewind();
			return ( -1 );
		}
		// <<< R027905

		
		header->msg.pcode = savedPcode;
		header->msg.trace = savedTrace;
		header->msg.local_date = savedTranDate;
		header->msg.msgtype = savedMsgType;
		if (savedReqPcode>=0)
			header->reqMsg->pcode = savedReqPcode;


		if( foundOriginal < 0)
		{
			if ( shcIsRequest(header))
			{
				if (!shcApp->acquirerShcParamsList->GetBool((char *)"shc.sendIss_VoidNoOrig"))
				{
					OTraceError("E-SHC-073007:Can't find original txn for void or completion txn\n");
					shc_return_finauth(header, SHC_RC_NoOriginal);
					// R027963 >>>
					if (shcIsAllAdvice(header))
						header->logFlag &= ~SHC_LOG_REQ;
					// <<< R027963
					((ShcLog *)header->shcLogObj)->rewind();
					return ( -1 );
				}
			}
		}
		// R027543 >>>
        else if (shcIsResponse(header)&&(header->msg.respcode == SHC_RC_Approved)&&
			isVoid) //R027320	
		{
			//Needs to update the original
			header->origMsg->shcerror = SHC_IE_Voided;
			header->logFlag |= SHC_LOG_UPD_ORIG;
		}
		// <<< R027543
		else if ( shcIsRequest(header) && (header->msg.shc_devcap & SH_DEVCAP_SHC_VOID))
		{
			if ((header->origMsg->msgtype % 20 != 10)||  //if original msg is a request OR
				(header->origMsg->alpha_response_code[0] == '\0')) //if original msg is an SHC timeout txn
			{
				//R028735 - Skip original txns approved by SHC
				if(header->origMsg->msgtype % 20 == 10 && 
					header->origMsg->respcode==SHC_RC_Approved && 
					header->origMsg->alpha_response_code[0] == '\0')
						return(0);

				OTraceDebug("D-SHC-073008: Orig txn is in flight (or) its SHC timed-out\n");
				// Send to LRS, if enabled.
				if( (header->issShcBin->binPkg->bin.bin_cfg & SH_REV_LATERESP) || 
					(shcApp->issuerShcParamsList->GetBool((char *)"shc.reversalOnLateResp")) )
				{
					OTraceDebug("D-SHC-073009: Sending to LRS\n");
					if(shcLateRespHelperObj)
						shcLateRespHelperObj->processVoid(header);
					else
						OTraceError("E-SHC-073010:Unable to send this void message to LateRespServer.\n");
				}
			}
			if ((header->origMsg->msgtype % 20 != 10))  //if original msg is a request
			{
				OTraceDebug("D-SHC-073011: Original request message found in SHCLOG. header->origMsg->msgtype[%d]\n",
																header->origMsg->msgtype);
				// Step:1 - Remove original request message event
				struct ShcmsgWithSegment tmpMsg;
				int tmpEventId = header->eventId;

				memcpy(&tmpMsg.msg, &header->msg, sizeof(struct shcmsg));
				memcpy(&tmpMsg.segmentData, &header->segment, sizeof(tmpMsg.segmentData));

				memcpy(&header->msg, header->origMsg, sizeof(tmpMsg));

				thisShcApp->shcTimerObj->shc_locate_event(header);
				if( header->eventId >= 0 )
				{
					OTraceDebug("D-SHC-073012: Dequeued the orig txn event(%d)\n", header->eventId );
					tm_dequeue( header->eventId );
				}
				header->eventId = tmpEventId;
				memcpy(&header->msg, &tmpMsg.msg, sizeof(struct shcmsg));
				memcpy(&header->segment, &tmpMsg.segmentData, sizeof(header->segment));

				// Step:2 - Update Original message parameters
				header->origMsg->shcerror = SHC_IE_Voided;
				header->origMsg->msgtype = thisShcApp->shcmsgHelperObj->shc_get_return_msgno(header->origMsg->msgtype);
				header->origMsg->respcode = SHC_RC_VoidedByAcquirer;
				header->logFlag |= SHC_LOG_UPD_ORIG;
			}
		}
		// <<< R027905
		((ShcLog *)header->shcLogObj)->rewind();
	}

	return 0;
}

int ShcFinAuthHelper::setNoPinFlag(ShcmsgHeader *header)
{
					/* R009100 >> */
	if( strlen(header->msg.pin) > 0 )
		header->msg.device_cap &= ~SH_DEVCAP_NOPIN;
	else
		header->msg.device_cap |= SH_DEVCAP_NOPIN;
					/* R009100 << */
	return 0;
}

int ShcFinAuthHelper::checkRepeat(ShcmsgHeader *header)
{	
	int isrepeat = 0;


	if(header->msg.msgtype == SHC_FINREQ_REPEAT 
	   || header->msg.msgtype == SHC_AUTHREQ_REPEAT
	   || header->msg.msgtype == SHC_AUTHREQ_ADVICE_REPEAT  //R026976
	   || header->msg.msgtype == SHC_FINREQ_ADVICE_REPEAT 
	   || (shcmsgIsAdvice(&header->msg) && (!(header->msg.auth_devcap & SH_DEVCAP_AUTH_ADVICE_INCREMENT)))) 
	{
//		if((isrepeat = header->shcLogObj->logRepeat(header)) < 0)
//		{
//			OTraceError("E-SHC-073008: pre-edit(): failed because logRepeate < 0\n");
//			isrepeat = -1;
//		}
		/*
		 *	Check if a transaction exists and if so do not log it
		 *	otherwise log the new transaction
		 */
		struct	ShcmsgWithSegment omsg;
		int ret;
	
		/* R002017 */
	    if ( !((ShcLog *)(header->shcLogObj))->use_log(header) )
	        return 0;

		memset(&omsg, 0, sizeof(omsg));
		locate_for_repeat = 1;
		if(((ShcLog *)header->shcLogObj)->locateTxn(header, &(omsg.msg), NULL) < 0) //R026977
		{
			locate_for_repeat = 0;
			OTraceDebug("D-SHC-073042: Repeat Msg not found, Creating transaction.\n");
			header->logFlag |= SHC_LOG_REQ;
			((ShcLog *)header->shcLogObj)->rewind();	
			return 0;
		}
		locate_for_repeat = 0;
		
		header->allocateAndCopyReqMsg(&omsg.msg);

		//To restore segments from original message for repeat msg
		header->allocateAndCopyOrigMsg(&omsg.msg);
		char tmplogid[sizeof(header->msg.shclog_id)];
		strcpy (tmplogid, header->msg.shclog_id);
		strcpy(header->msg.shclog_id, header->origMsg->shclog_id);
		IstSegList *origSegList = 
			((ShcLog *)header->shcLogObj)->restoreGenericLog(shcGenericLogObj, header, 'B');
		strcpy(header->msg.shclog_id, tmplogid);
		if (origSegList)
			header->setOrigSegList(origSegList);

		if(omsg.msg.settlement_date)
			header->msg.settlement_date = omsg.msg.settlement_date;	//restoring for repeat	
	
		((ShcLog *)header->shcLogObj)->rewind();
										/* R007672 >> */
		if( shcIsAdvice(header) && (omsg.msg).shcerror==SHC_IE_Reversed )
		{
			return( 3 );
		}								/* R007672 << */

								/* R007211 BEGIN*/
		if (!shcmsgIsResponse(&(omsg.msg)))
		{
			static int     intervalToApproveAdvice=-1;
			if(intervalToApproveAdvice == -1)
			{
				intervalToApproveAdvice=0;
				int i;
				if( cf_openfile("...") < 0 )
				{
					OTraceWarning("W-SHC-073058: Configuration file not present.\n");
				}
				else if (cf_locatenum("shc.intervalToApproveAdvice", &i) >=0)
				{
					intervalToApproveAdvice = i;
				}
				OTraceInfo("I-SHC-073057:shc.intervalToApproveAdvice <%d>\n", intervalToApproveAdvice);
				cf_close();
			}
			if (intervalToApproveAdvice > 0)
			{
				//if found an request and current message is advice and
				//number of seconds in intervalToApproveAdvice has passed
				//Just assume the original message has been approved
				if ( shcIsAllAdvice(header) )
				{
					int secondsSinceOrigTxn = (header->msg.txn_start_time - omsg.msg.txn_start_time)/1000;
					if (secondsSinceOrigTxn < 0)
						secondsSinceOrigTxn += 24*3600;	//cross day already, add seconds of a day
					if (secondsSinceOrigTxn >= intervalToApproveAdvice)
					{
						defaultlasttxnrespcode=SHC_RC_Approved;
						return 1;
					}
				}
			}
			return 2;
		}
		if ((header->msg.msgtype % 10 == 1) && !shcIsAllAdvice(header))  //R027320
		{
			header->msg.respcode=(omsg.msg).respcode;	//	R018579, line uncommented
			//header->msg.msgtype=(omsg.msg).msgtype;
		}
		else
		{
			OTraceDebug("D-SHC-073043: Repeat Msg found, taking response code from orig transaction respcode.\n");
			defaultlasttxnrespcode=(omsg.msg).respcode;
		}	
		//else
		//	thisShcApp->shccard.lasttxnrespcode=(omsg.msg).respcode;
								/* R007211 END */
	
		return(1);
	}
	
	return isrepeat;
}

int ShcFinAuthHelper::actionOnRepeat(ShcmsgHeader *header)
{
	if (!header->repeatFlag)
		return 0;

	if (shcIsAllAdvice(header))  //R027320
	{
		if ( header->repeatFlag == 3 ||	/* R007672 Advice's Orig txn has been reversed */
			 (	header->msg.respcode == SHC_RC_Approved && 
				header->reqMsg->respcode != SHC_RC_Approved && header->repeatFlag == 1) )
		{
			/* Continue as if it's a new advice, but don't log it
			 * when the 130 come back, the 110 will be updated to 130.
			 */
			//R027562 - 110 response and 120/121 response differs. 
			//          Send this txn to issuer. Set logflag to insert 120/121.
			header->logFlag |= SHC_LOG_REQ;  
		}
		// R027320 >>>
		else if (header->repeatFlag == 2) 
		{
			/* There is a request for this txn, but no response,
			 * This may happen when acquierer send repeat message before shc
			 * finished processing the original message. So just Ignor this
			 * repeat.
			 */
			header->shcerr = SH_IGNORE;
			header->logFlag |= SHC_LOG_REQ; 
			header->msg.shcerror = SHC_IE_Duplicate; 
			header->setIgnoreFlag();
			return -1;
		}
		// <<< R027320
		else 
		{
			// R027320 >>>
			header->msg.shcerror = SHC_IE_Duplicate;
			if (header->isrepeat())
				shc_return_finauth(header,header->msg.respcode );
			else
				shc_return_finauth(header, shcApp->issuerShcParamsList->getShcDuplicateResponse());
			// <<< R027320
			return -1;
		}
	}
	else if(header->repeatFlag==1)
	{
		/* This txn's response already exists in database, just return 
		 * the original response code.
		 * The message type has been set to response by shc_logRepeat
		 * The response code has been set to original response code 
		 */
		header->logFlag |= SHC_LOG_REQ; //R027320
		header->msg.shcerror = SHC_IE_Duplicate; //R027320
		header->setReturnFlag(header->reqMsg->respcode);
		thisShcApp->shcmsgHelperObj->shc_set_return_msgno(&header->msg);
		restoreForRepeat(header);
		header->shcerr = SH_RETURN;
		header->setSkipFlag();
		return -1;
	}
	else if (header->repeatFlag==2)
	{
		/* There is a request for this txn, but no response,
		 * This may happen when acquierer send repeat message before shc
		 * finished processing the original message. So just Ignor this
		 * repeat.
		 */
		header->shcerr = SH_IGNORE;
		header->logFlag |= SHC_LOG_REQ; //R027320
		header->msg.shcerror = SHC_IE_Duplicate; //R027320
		header->setIgnoreFlag();
		return -1;
	}
	return 0;
}

int ShcFinAuthHelper::restoreForRepeat(ShcmsgHeader *header)
{
	if (!header->reqMsg)
		return 0;
	
	strcpy(header->msg.alpha_response_code, header->reqMsg->alpha_response_code);
	strcpy(header->msg.authnum, header->reqMsg->authnum);
	if (!header->msg.trandate)
	{
		header->msg.trandate = header->reqMsg->trandate;
		header->msg.trantime = header->reqMsg->trantime;
	}
	header->msg.flipped_msgtype = header->reqMsg->flipped_msgtype;
	dbm_deccopy(&header->msg.aval_balance, &header->reqMsg->aval_balance);
	dbm_deccopy(&header->msg.ledger_balance, &header->reqMsg->ledger_balance);
	if (!header->msg.settlement_date)
		header->msg.settlement_date = header->reqMsg->settlement_date;
	strcpy(header->msg.iss_entityId, header->reqMsg->iss_entityId);

	if (!header->msg.invoice_number)
		strcpy(header->msg.invoice_number, header->reqMsg->invoice_number);
	strcpy(header->msg.trans_id, header->reqMsg->trans_id);
	strcpy(header->msg.issuer_data, header->reqMsg->issuer_data);
	//R028265 - Do not restore shclog_id for repeat txns
//	OTraceLog("L-SHC-073045: Replace ID [%s] with ID [%s]\n", header->msg.shclog_id, header->reqMsg->shclog_id);
//	strcpy(header->msg.shclog_id, header->reqMsg->shclog_id);

	//R028271 >>>
	if(strcmp(header->msg.shclog_id,header->reqMsg->shclog_id))
		TxnStatEquate(header->reqMsg->shclog_id, header->msg.shclog_id);
	else
		OTraceDebug("D-SHC-073045: No need to Equate [%s] and [%s]\n",header->msg.shclog_id,header->reqMsg->shclog_id);
	//<<< R028271


	header->msg.processor_busday = header->reqMsg->processor_busday;
	header->msg.seq_trace_no = header->reqMsg->seq_trace_no;
	if (shc_is_empty_buf(header->msg.filler1, sizeof(header->msg.filler1)))
		memcpy( header->msg.filler1, header->reqMsg->filler1, sizeof(header->msg.filler1) );
	if (shc_is_empty_buf(header->msg.filler2, sizeof(header->msg.filler2)))
		memcpy( header->msg.filler2, header->reqMsg->filler2, sizeof(header->msg.filler2) );
	if (shc_is_empty_buf(header->msg.filler3, sizeof(header->msg.filler3)))
		memcpy( header->msg.filler3, header->reqMsg->filler3, sizeof(header->msg.filler3) );
	if (shc_is_empty_buf(header->msg.filler4, sizeof(header->msg.filler4)))
		memcpy( header->msg.filler4, header->reqMsg->filler4, sizeof(header->msg.filler4) );
	if( header->msg.issuer_data[0] == '\0' )
		memcpy( header->msg.issuer_data, header->reqMsg->issuer_data
				, sizeof(header->msg.issuer_data) );

	//	>>>	R015826
	char tmplogid[sizeof(header->msg.shclog_id)];
	strcpy (tmplogid, header->msg.shclog_id);
	strcpy(header->msg.shclog_id, header->reqMsg->shclog_id);

	strcpy(header->msg.shclog_id, tmplogid);
	//	<<<	R015826

	struct shc_data *p_shc_data = (struct shc_data *)header->msg.shc_data_buffer;
	struct shc_data *old_shc_data = (struct shc_data *)header->reqMsg->shc_data_buffer;
	if (!p_shc_data->cvv2_resultcode)
		p_shc_data->cvv2_resultcode = old_shc_data->cvv2_resultcode;
	if (!p_shc_data->avs_resultcode)
		p_shc_data->avs_resultcode = old_shc_data->avs_resultcode;
	if (!p_shc_data->cvv_resultcode)
		p_shc_data->cvv_resultcode = old_shc_data->cvv_resultcode;

    //R026796 - Restore addresponse(DE44) for repeat response messages >>>>
	strncpy(header->msg.addresponse,header->reqMsg->addresponse,sizeof(header->msg.addresponse));
	strtrim(header->msg.addresponse,header->msg.addresponse);
	// <<<< R026796

	dbm_deccopy(&header->msg.amount, &header->reqMsg->amount); //R028674

	header->msg.shc_devcap |= header->reqMsg->shc_devcap & SH_DEVCAP_SHC_PARTIAL_AUTH; //R028675

	//R028676 >>>
	dbm_deccopy(&header->msg.acq_aval_balance, &header->reqMsg->acq_aval_balance);
	dbm_deccopy(&header->msg.acq_ledger_balance, &header->reqMsg->acq_ledger_balance);
	header->msg.aval_balance_type = header->reqMsg->aval_balance_type;
	header->msg.ledger_balance_type = header->reqMsg->ledger_balance_type;
	//<<< R028676

	return 0;
}

int ShcFinAuthHelper::checkPreauthAllowed(ShcmsgHeader *header)
{
	/*  22Jun93
		If the issuer does not support preauth no need to process a
		preauthorization request
	*/

	if((shcIsPreAuthConfReq(header) || shcIsPreAuthReq(header)) &&
		!shcbinPreauthAllowed(header->issShcBin->binPkg))
	{
		OTraceError("E-SHC-073009:Preauth is not allowed for this bin.\n");
		header->msg.shcerror = SHC_RC_InvalidTransaction;
		shc_return_finauth(header, header->msg.shcerror);
		return -1;
	}	
	return 0;
}

int ShcFinAuthHelper::checkDupTxn(ShcmsgHeader *header)
{
	/*	29apr93: Check for dup. transaction */
	if((header->issShcBin->binPkg->bin.flags & SH_CHECKDUP) 
		&& ( shcIsAuthorizationRequest(header)
			|| header->msg.msgtype==SHC_FINREQ )		// R009807
		&& !(shcIsAllAdvice(header))     //R027320
		&& thisShcApp->shcmsgHelperObj->shc_checkduptxn(header) == True )
	{
		shc_return_finauth(header, shcApp->issuerShcParamsList->getShcDuplicateResponse()); //---R028908
		return -1;
	}
	else
		return 0;
}

int ShcFinAuthHelper::checkBinDown(ShcmsgHeader *header)
{
	/*	Check if the institution is up */
	if(shc_isdown(header->issShcBin->binPkg)|| (shcApp->saf_interleave&&shcIsReplay(header->issShcBin->binPkg,header->msg.iss_entityId)))
		/*if(!shc_safallowed(header->issShcBin->binPkg))  980824*/
		if ( shcmsgIsAdvice( &header->msg ) &&
         shcApp->issuerShcParamsList->GetBool( ( char * )"shc.decline_advice_when_timeout_issdown" ) )
		{
			OTraceError("E-SHC-073010a: Failed because issuer down and no SAF\n");
			/*      No store and forward allowed */
			shc_return_finauth(header, SHC_RC_IssuerDown);
			return -1;
		}
		else if(!shc_safallowed(header->issShcBin->binPkg) && !shcmsgIsAdvice(&header->msg))
		{
			OTraceError("E-SHC-073010: Failed because issuer down and no SAF\n");
			/*	No store and forward allowed */
			shc_return_finauth(header, SHC_RC_IssuerDown);
			return -1;
		}
		else if ( ( header->origMsg ) && 
			 ( header->origMsg->respcode == SHC_RC_IssuerDown )  &&
			 ( shcmsgIsAdvice( &header->msg ) ) )
		{
			OTraceError("E-SHC-073077: Original txn declined due to Issuer down. No SAF required. \n");
			/*	No store and forward allowed */
			shc_return_finauth(header, SHC_RC_IssuerDown);
			return -1;
		}
	return 0;
}

int ShcFinAuthHelper::checkPreauthTxn(ShcmsgHeader *header)
{
	if (header->origMsg && header->origMsg->msgtype == SHC_PREAUTH_RESP)
	{
		OTraceInfo("I-SHC-073046: Exit because msg is preauth_resp.\n");	//	R018276
		return 0;
	}
	
	/*	Check for pre-authorization server */
	if( shcRequiresPreAuthorization(header->issShcBin->binPkg))
	{
		/*	26nov92 */
		if(
			(header->issShcBin->binPkg->bin.flags & SH_PREAUTH_ON_VALIDATE)
			&& header->msg.pcode / 10000 != SH_ISO_CARDVALIDATE
		  )
		   ;	/* Do nothing: This is NOT a card validation request and
							   this bin only does pre-auth on card-validation
				*/
		else
		{
			/*	We should send this transaction to a pre-authorization server */

			/*	o	Determine mail box */
			header->applMailboxId = header->issShcBin->binPkg->auth.authserver;


			/*	o	Re-route to this server by setting routing flags */
			header->shcerr &=  ~SH_SENDISS;
			header->shcerr |= SH_SENDAPPL;
			
			/*	Change message type so server understands what is requested */
			header->msg.origmsg = header->msg.msgtype;
			header->msg.msgtype = SHC_PREAUTH_REQ;

			/*	let auth. module know that we require authorization */
			header->msg.respcode = SHC_RC_PreAuthRequired;

			/*	26nov92 : Set SAF flag to let pre-auth know iss. is down */
			if(shc_isdown(header->issShcBin->binPkg)|| (shcApp->saf_interleave&&shcIsReplay(header->issShcBin->binPkg,header->msg.iss_entityId)))
				header->msg.saf = SH_SAF_PENDING;
				
			thisShcApp->shcmsgHelperObj->shc_route((ShcmsgHeader *)header);
			
			header->msg.msgtype = header->msg.origmsg;
			header->msg.origmsg = 0;
			
			thisShcApp->shcTimerObj->shc_set_timers(header);  // R017683
			
			header->shcerr = SH_SETTIMER|SH_IGNORE;
			
			header->setSkipFlag();
			OTraceInfo("I-SHC-073011:Pre-Auth. required.\n");
			return -1;
		}
	}
	return 0;
}

int ShcFinAuthHelper::checkTxnSet(ShcmsgHeader *header)
{
	/*
	 *	1.	check if the transactions are valid for the all participants
	 */
	if(!(header->issShcBin->binPkg->txn.txnset & header->msg.txntype))
	{
		OTraceError("E-SHC-073012: Transaction denied: invalid txntype for issuer.\n");
		shc_return_finauth(header, SHC_RC_InvalidTransaction);
		return -1;
	}
	return 0;
}

int ShcFinAuthHelper::checkAccountFundingTxn(ShcmsgHeader *header)
{
									//R007502 BEGIN
	//Check whether bin support account funding transactions
	if (	shcIsAccountFunding(header->msg.pcode) && 
			!(header->issShcBin->binPkg->bin.bin_cfg & SH_CFG_ACCOUNT_FUNDING) )
	{
		OTraceError("E-SHC-073013: Transaction denied: issuer doesn't support account funding.\n");
		shc_return_finauth(header, SHC_RC_InvalidTransaction);
		return -1;
	}
	return 0;								//R007502 END
}

int ShcFinAuthHelper::verifyCheckDigit(ShcmsgHeader *header)
{
	/*
	 *	Verify check digit
	 */
	if(header->issShcBin->binPkg->bin.flags & SH_VERIFY_CHECK_DIGIT)
		if(!thisShcApp->shcmsgHelperObj->shc_verify_check_digit(header))
		{
			OTraceError("E-SHC-073014: Denied: Check digit does not verify.\n");
			shc_return_finauth(header, SHC_RC_InvalidCheckDigit);
			return -1;
		}
	return 0;
}

int ShcFinAuthHelper::checkEuroBinMbrTbl(ShcmsgHeader *header)
{
		/* R007206 & R007237 >> */
	struct shc_data *ptr_shc_data = (struct shc_data *)header->msg.shc_data_buffer;
	char *network_data = ptr_shc_data->network_data;
	unsigned long lNetworkData = 0L;
	int ret = 0;

	/* As europay acquirer - send txn to EPS-NET */
	if( thisShcApp->shcmsgHelperObj->shc_isEuroIssuer(header) 
	  && strncmp(network_data, EU_BIN_HEADER, strlen(EU_BIN_HEADER))==0 )
	{
		char *endptr;
		lNetworkData = strtoul( network_data+strlen(EU_BIN_HEADER), &endptr, 16 );
		OTraceDebug( "D-SHC-073015: network_data=[0x%04x]\n", lNetworkData );
		
		if( ( (lNetworkData & EU_BIN_NOTERM) && (header->msg.pos_condition_code&SH_POS_COND_NOTERM) ) /* NO_TERMINAL allowed */
		 || ( (lNetworkData & EU_BIN_ATM) && shcIsATM(header) ) 	/* ATM allowed */
		 ||  (lNetworkData & EU_BIN_POS) && (!shcIsATM(header)) )	/* POS transaction allowed */
		{
		}
		else
		{
			OTraceError( "E-SHC-073016: Failed in 'Terminal Acceptance' checking\n" );
			ret = SHC_RC_TxnNotPermittedOnTerm ;
		}
		
		if( thisShcApp->shcmsgHelperObj->checkEuAcquirerProfile( header, lNetworkData ) < 0 )
		{
			OTraceError( "E-SHC-073017: Failed in 'Acquirer Profiles' checking\n" );
			ret = SHC_RC_TxnNotPermittedOnTerm ;
		}
	}
	
	if (ret != 0)
	{
		OTraceError("E-SHC-073018: Denied: Failed in Europay BIN/MBR checking.\n");
		shc_return_finauth(header, ret);
		return -1;
	}
		/* << R007206 & R007237 */
	return 0;
}
int ShcFinAuthHelper::checkTxnLimit(ShcmsgHeader *header)
{
	/*
	 *	Check transaction limits
	 */
	OTraceDebug("D-SHC-073019: acq ccy: %03d  issbin ccy: %03d\n", 	/* 19970108 */
			header->msg.acq_currency_code,					/* 19970108 */
			header->issShcBin->binPkg->bin.currency_code);				/* 19970108 */

	if(shcIsRequest(header) && header->msg.pcode / 10000 < 20 	/* 16Nov92 */
		&& header->msg.acq_currency_code == header->issShcBin->binPkg->bin.currency_code )
		/* 10001592 */
	{
		if(dbm_deccmp(&header->msg.amount, &header->issShcBin->binPkg->txn.amount) > 0)
		{
			OTraceError("E-SHC-073020: Denied: Transaction Limits exceeded.\n");
			shc_return_finauth(header, SHC_RC_ExceedsLimit);
			return -1;
		}

		/* 05Nov92. Sunny Added. 
		*	If Issuer down, check if txn amount over max txn amount per
		*		transaction while in SAF mode.
		*/
		if(	(shc_isdown(header->issShcBin->binPkg) && !shcbinIsFullAuth(header->issShcBin->binPkg))||
			(shcApp->saf_interleave&&shcIsReplay(header->issShcBin->binPkg,header->msg.iss_entityId)))
		{
			if(dbm_deccmp(&header->msg.amount,
				&header->issShcBin->binPkg->auth.floor_3) > 0)
			{
				OTraceInfo("E-SHC-073021: Denied: SAF Transaction Limits exceeded.\n");
				shc_return_finauth(header, SHC_RC_ExceedsLimit);
				return -1;
			}
		}

		/* End 05Nov92 */
	
		/* 09Mar95
		*	If Not advice message
		*		Check if below iss min. amount
		*		and if below acq min. amount.
		*/
		if(!shcIsAllAdvice(header)) //R027060
		{
			if(dbm_deccmp(&header->msg.amount, 
				&header->issShcBin->binPkg->auth.iss_minamount) < 0)
			{
				OTraceError("E-SHC-073022: Denied:Below Issuer Minimum Amount.\n");
				shc_return_finauth(header,SHC_RC_TransactionNotAllowed);
				return -1;
			}

			if(dbm_deccmp(&header->msg.amount, 
				&header->acqShcBin->binPkg->auth.acq_minamount) < 0)
			{
				OTraceError("E-SHC-073023: Denied:Below Acquirer Minimum Amount.\n");
				shc_return_finauth(header,SHC_RC_TransactionNotAllowed);
				return -1;
			}
		}
		/* End 09Mar95 */
	}
	else if(shcIsRequest(header) && header->msg.pcode / 10000 < 20 && header->msg.iss_currency_code == header->issShcBin->binPkg->bin.currency_code )
	{
		if (dbm_decncmp(&header->msg.ch_amount, (double)0) != 0)
		{
	        	if(dbm_deccmp(&header->msg.ch_amount, &header->issShcBin->binPkg->txn.amount) > 0)
                	{
                        	OTraceError("E-SHC-074020: Denied: Transaction Limits exceeded.\n");
                       		shc_return_finauth(header, SHC_RC_ExceedsLimit);
                        	return -1;
                	}
		}
		else
		{
			OTraceDebug("D-SHC-074024: No data available in CardHolder Amount. So, per transaction limit check ignored.\n");
		}

                /* 05Nov92. Sunny Added.
                *       If Issuer down, check if txn amount over max txn amount per
                *               transaction while in SAF mode.
                */
                if(     (shc_isdown(header->issShcBin->binPkg) && !shcbinIsFullAuth(header->issShcBin->binPkg))||
                        (shcApp->saf_interleave&&shcIsReplay(header->issShcBin->binPkg,header->msg.iss_entityId)))
                {
                        if(dbm_deccmp(&header->msg.ch_amount, &header->issShcBin->binPkg->auth.floor_3) > 0)
                        {
                                OTraceInfo("E-SHC-074021: Denied: SAF Transaction Limits exceeded.\n");
                                shc_return_finauth(header, SHC_RC_ExceedsLimit);
                                return -1;
                        }
                }
                /* 05Nov92. Sunny Added.
                *       If Issuer down, check if txn amount over max txn amount per
                *               transaction while in SAF mode.
                */
		//	commenting below code ,as it seems duplicate code
                //if(     (shc_isdown(header->issShcBin->binPkg) && !shcbinIsFullAuth(header->issShcBin->binPkg))||
                //       (shcApp->saf_interleave&&shcIsReplay(header->issShcBin->binPkg,header->msg.iss_entityId)))
                //{
                //       if(dbm_deccmp(&header->msg.amount, &header->issShcBin->binPkg->auth.floor_3) > 0)
                //      {
                 //             OTraceInfo("E-SHC-074021: Denied: SAF Transaction Limits exceeded.\n");
                 //            shc_return_finauth(header, SHC_RC_ExceedsLimit);
                 //           return -1;
                    //  }
                //}


                /* 09Mar95
                *       If Not advice message
                *               Check if below iss min. amount
                *               and if below acq min. amount.
                */
                if(!shcIsAllAdvice(header))
                {
                        if(dbm_deccmp(&header->msg.amount, &header->issShcBin->binPkg->auth.iss_minamount) < 0)
                        {
                                OTraceError("E-SHC-074022: Denied:Below Issuer Minimum Amount.\n");
                                shc_return_finauth(header,SHC_RC_TransactionNotAllowed);
                                return -1;
                        }

                        if(dbm_deccmp(&header->msg.amount, &header->acqShcBin->binPkg->auth.acq_minamount) < 0)
                        {
                                OTraceError("E-SHC-074023: Denied:Below Acquirer Minimum Amount.\n");
                                shc_return_finauth(header,SHC_RC_TransactionNotAllowed);
                                return -1;
                        }
                }
        }
	else 
		 { OTraceDebug("D-SHC-073024: Ignoring transaction limit checks. \n"); }

	return 0;
}

int ShcFinAuthHelper::checkAccount(ShcmsgHeader *header)
{
	/*
	 *	Check that the transaction is allowed on the card
	 */
	int		acct;

	if(shcIsCredit(header->msg.pcode))
		acct = header->msg.to_acct;
	else
		acct = header->msg.from_acct;
	
	if(acct == SH_ACCT_CC)
	{
		if(!(header->issShcBin->binPkg->bin.flags & SH_CREDIT_CARD))
		{
			OTraceError("E-SHC-073025: Denied: Credit Txn not allowed for BIN.\n");
			shc_return_finauth(header, SHC_RC_TransactionNotAllowed);
			return -1;
		}
	}
	else if(!(header->issShcBin->binPkg->bin.flags & SH_DEBIT_CARD))
	{
		OTraceError("E-SHC-073026: Denied: Debit Transaction not allowed for BIN.\n");
		shc_return_finauth(header, SHC_RC_TransactionNotAllowed);
		return -1;
	}
	return 0;
}
int ShcFinAuthHelper::checkCamResult(ShcmsgHeader *header, int *errcode)
{
	int		ret;

	/* Ssc - 28Jun00    R004671 integration to 7.2 */
	/* Ssc - 26Feb00    SPR # 2007336 Get and check request results from cam.*/

    ret = thisShcApp->shcCamHelperObj->shc_cam_request_result( header );
    if (ret == 0)
    {   /* Card Authentication Failed and Decline for Issuer*/
        //*errcode=SHC_RC_UnableToProcess;
        *errcode=SHC_RC_ChipArqcFail; //R028209
    }
    else if (ret < 0)
    {
        OTraceError("I-SHC-073027: Unable to get request result from cam.\n");
        return(-1);
    }
    /* Ssc - 28Feb00    SPR # 2007336 */
    return 0;
}


int ShcFinAuthHelper::setupReturnMsg(ShcmsgHeader *header, struct shcmsg *returnMsg, int errcode)
{
	/* R006237 */
	returnMsg->device_cap |= SH_DEVCAP_INTERNALREV;
	/*	Setup error code */
	if(errcode >= 0)
		returnMsg->respcode = errcode;
	
	
	/*	Set return message type */
	thisShcApp->shcmsgHelperObj->shc_set_return_msgno(returnMsg);
    
//	/*	Reply */
//	shc_finresp(header);

	/* 29apr93: if code is dup transaction then do special processing */
	if(header->msg.respcode == SHC_RC_DuplicateTransaction)
	{
		if( header->acqShcBin->isInterac() || header->issShcBin->isInterac() )	/* R007527 */
		{
			OTraceDebug("D-SHC-073027-a: In SetupReturnMsg Last Response code[%d]\n",shcDuplicateChkObj->lasttxnrespcode);	
	
			if(header->acqShcBin->isInterac() && shcmsgIsAdviceResp(&header->msg))
		 		header->msg.respcode = SHC_RC_DuplicateTransaction; 	
			else
				header->msg.respcode = shcDuplicateChkObj->lasttxnrespcode;
	
			errcode = SHC_RC_DuplicateTransaction;
		}
		else		/* R007527 >> */
		{
			if((header->issShcBin->binPkg->bin.flags & SH_CHECKDUP))
			{
				OTraceDebug("D-SHC-073027-b: In SetupReturnMsg Last Response code[%d]\n",shcDuplicateChkObj->lasttxnrespcode);
				if( shcDuplicateChkObj->lasttxnrespcode != SHC_RC_Approved )
				{
					header->msg.respcode = shcDuplicateChkObj->lasttxnrespcode;
					errcode = header->msg.respcode;
				}
			}
			else
			{
				OTraceDebug("D-SHC-073027-c: In SetupReturnMsg Last Response code[%d]\n",defaultlasttxnrespcode);
				header->msg.respcode = defaultlasttxnrespcode;
				errcode = header->msg.respcode ;
			}
		}			/* R007527 << */
	}
	else
		errcode = header->msg.respcode;
		
	return 0;
}
int ShcFinAuthHelper::denyUpdateLogReq(ShcmsgHeader *header)
{
	/*	NEW */
	if(header->msg.device_cap & SH_DEVCAP_UPDATE_LOGS)
	{
		/*	turn off all timers and flags */
		header->shcerr = 0;
		shc_return_finauth(header, -1);
		return -1;
	}
	return 0;
}
int ShcFinAuthHelper::checkCamResult(ShcmsgHeader *header)
{
	/* R006940 Move request result to before STIP */
	/* Ssc - 28Jun00    R004671 integration to 7.2 */
	/* Ssc - 26Feb00    SPR # 2007336 Get and check request results from cam.*/
	int ret = thisShcApp->shcCamHelperObj->shc_cam_request_result( header );

	if (ret == 0)
	{   /* Card Authentication Failed and Decline for Issuer*/
		//shc_return_finauth( header, SHC_RC_UnableToProcess);
		shc_return_finauth( header, SHC_RC_ChipArqcFail); //R028209
		return -1;
	}
	else if (ret < 0)
	{
		OTraceError("I-SHC-073028: Unable to get request result from cam.\n");
		return(-1);
	}
	return 0;
}
int ShcFinAuthHelper::shc_return_finauth(ShcmsgHeader *header, int errcode)
{
	/*
	 *	Set up the return values for a transaction
	 *	Log out the database
	 *	Set the error code
	 */
	int tmpMsgType = header->msg.msgtype;
	ShcmsgProcessor *p=NULL;

	if ((header->issShcBin->binPkg->bin.flags & SH_FLIP_MSGTYPE) && (shcIsRefund(header->msg.pcode)) && (header->msg.flipped_msgtype==0))
	{
		header->msg.flipped_msgtype = SHC_FINREQ;
	}
	
	header->setSkipFlag();
	
	if (thisShcApp->shcFinAuthHelperObj->checkCamResult(header, &errcode) < 0)
		return -1;
		    
	struct ShcmsgWithSegment newMsg;
	
	thisShcApp->shcFinAuthHelperObj->setupReturnMsg(header, &header->msg, errcode);

	/* R007795 */
	header->shcerr = SH_NO_TIMER_PRESENT;

	if ((p=(ShcmsgProcessor *)thisShcApp->shcmsgTxnHelperObj->enqueueInternalMsg(header)) == NULL)
		return -1;
	
	//For advice msg, it will be logged when processing its response
	//We should do this to all msg, but don't want to impact too much
	if (shcIsAdviceRespInclu(header))
	{
		((ShcmsgHeader *)p->header)->logFlag = SHC_LOG_REQ;//Ensure it will be logged when response is processed
		header->logFlag &= ~SHC_LOG_REQ;
	}

	header->shcerr = SH_IGNORE;
	header->msg.msgtype = tmpMsgType;
	((ShcmsgHeader *)p->header)->allocateAndCopyReqMsg(&header->msg);
	
	/* 29apr93: Minor change unrelated to dup. txn: Display outgoing txn */
	OTraceDebug("D-SHC-073029:The message is changed to response and queued\n");

	return(errcode);
}


int ShcFinAuthHelper::checkEvent(ShcmsgHeader *header)
{
//	struct ShcmsgWithSegment tmpBuf;
//	struct shcmsg *omsg = &tmpBuf.msg;
	/* 1. Locate original */
	if(header->shcerr & SH_NO_TIMER_PRESENT)
		return 0;

	/* 961115 */
//	else if(thisShcApp->shcTimerObj->shc_locate_event_x(header, omsg, (unsigned char *)tmpBuf.segmentData) < 0)
	else if( header->reqMsg == NULL )
	{

		OTraceWarning("W-SHC-073030:No match for transaction: %d trace %d\n", 
				header->msg.msgtype, header->msg.trace);
		
		thisShcApp->shcmsgTxnHelperObj->processLateResponse(header);
		return -1;
	}
//	else
//		header->allocateAndCopyReqMsg(omsg);
		
	if(!(header->shcerr & SH_NO_TIMER_PRESENT) && header->msg.respcode == SHC_RC_Approved) /* R001835 */
	{
		#if defined(TM_MULTI_Q)
			if( tm_is_eventid_expired(header->eventId) != 0 )
		#else
		register  struct  memhead   *q;   /* R001563 */
		register  struct  mbbufhead *h;   /* R001563 */
		register  long    t;              /* R001563 */

		q = MEM_GETHEADADDR(mbbuf, header->eventId); 
		h = (struct mbbufhead *)MEM_GETHEADDATA(q); 
		struct timeb tmpTime;
    	ftime(&tmpTime);

		/*
		 * Event is already expired, let the event handler handle it
		 */
		if( (h->flags & TM_DID_NOTIFY ) || 
			(	( h->expire < tmpTime.time )||
				( (h->expire == tmpTime.time) && (h->hires_expire/1000000 < tmpTime.millitm))
			)
		  )
		#endif
		{
			OTraceWarning("W-SHC-073031:Late Resopnse %d trace %d\n",
					header->msg.msgtype, header->msg.trace);

			thisShcApp->shcmsgTxnHelperObj->processLateResponse(header);

			return(-1);
		}
	}

	/*
	 * Event is NOT expired, remove it quickly from the event queue to avoid race condtion
	 */
	if(!(header->shcerr & SH_NO_TIMER_PRESENT))
	//	>>>	R023962
	{
		/* Add a conditon for p1c enhancement to not dequeue the event here, will be done in doWork*/
		OCString issuerResponseListRegularExp = thisShcApp->issuerShcParamsList->Get( (char *)"shc.stand_in_decision_rc_list" ); 
		OCString issuerResponseCode = header->msg.alpha_response_code;
		issuerResponseListRegularExp.strtrim(' ');
		issuerResponseCode.strtrim(' ');
		int responseCodeMatch = ist_regexpcv( (char*)issuerResponseListRegularExp.data(), (char*)issuerResponseCode.data(), 0 );
		OTraceInfo("D-SHC-073075 Response code is [%s] \n", issuerResponseCode.data());
		OTraceInfo("D-SHC-073075a stand_in_decision_rc_list: [%s] \n", issuerResponseListRegularExp.data());
		int timeoutValueInSeconds = shcApp->issuerShcParamsList->GetNum( (char*) "shc.stand_in_decision_timeout" );
		OTraceInfo("D-SHC-073075b stand_in_decision_timeout: [%d]\n", timeoutValueInSeconds);
		if(responseCodeMatch && issuerResponseListRegularExp.length()!=0 && !shcmsgIsAdviceResp(&header->msg) && 
			timeoutValueInSeconds > 0 && !(checkForMCTarTxn(header) || checkForVisaTarTxn(header)))
		{
			OTraceInfo("D-SHC-073074: Response from P1C/AUTH event. Will be removed later \n");
		}
		else
		{
			OTraceDebug("D-SHC-073076 Event [%d] is sent for expiration here \n", header->eventId);
			if(tm_dequeue(header->eventId) < 0 )
			{
				OTraceInfo("I-SHC-073047: Event not removed properly from queue ,message dropped \n");
				header->shcerr = SH_IGNORE;
				header->setIgnoreFlag();
				return 0;
			}
		}
	}
	//	<<<	R023962
	return 0;
}
int ShcFinAuthHelper::setLogFlag(ShcmsgHeader *header)
{
	if(header->msg.device_cap & SH_DEVCAP_FROM_REPLAY)
	{
		if(!header->issShcBin->isInterac()) /* R001835 */
			return 0;
	}

	/* 2. Update the database to indicate that the transaction took place */
	if(header->msg.msgtype == SHC_FINREQ_ADVICE_RESPONSE
	   || header->msg.msgtype == SHC_AUTHREQ_ADVICE_RESPONSE)
	{
		if (header->msg.respcode == SHC_RC_ApproveDeniedAdvice)
		{
			header->logFlag |= SHC_LOG_REQ;
			return 0;
		}

		//R027562 >>>
//		if (header->createdInternal()) //If its a SAF reply
		if (header->msg.device_cap & SH_DEVCAP_FROM_REPLAY) //If its a SAF reply
		{
				// This is an internal msg...set logflag to SHC_LOG_REQ
				header->logFlag |= SHC_LOG_REQ;  //insert this resp msg as a new record
				if (header->msg.shcerror != SHC_IE_Duplicate) //if resp msg is already marked as duplicate, do not override
				{
					OTraceDebug("D-SHC-073055.1: Setting shcerror to SHC_IE_SafReply\n");
					header->msg.shcerror = SHC_IE_SafReply; //mark this resp msg as saf reply
				}
				return 0;
		}
		//<<< R027562

		struct ShcmsgWithSegment tmpMsg;
		/*
		 *	If the original database txn is 210 or 110 then we
		 *	have already posted the response to the database and
		 *	we just need to respond.
		 */
		
		// R027320 >>>
        if ((header->reqMsg) && (header->msg.msgtype != header->reqMsg->msgtype))
			thisShcApp->shclog_specified_msgtype = header->reqMsg->msgtype;
		// <<< R027320

		if(!(header->issShcBin->binPkg->bin.flags & SH_GETAPP_HOST))
		{
			OTraceDebug ("D-SHC-073056: Locate Transaction [%d] for SH_GETAPP_HOST value N\n", header->msg.msgtype); 
			thisShcApp->shclog_specified_msgtype = header->msg.msgtype;
		}

		if(((ShcLog *)header->shcLogObj)->locateTxn(header, &tmpMsg.msg, NULL) >= 0)
		{
			/*
			 * Record exists. Related record of this advice msg was 
			 * already logged so avoid logging it again
			 */
			((ShcLog *)header->shcLogObj)->rewind();
			header->logFlag &= ~SHC_LOG_REQ;
									/* R007672 >> */
			if ( tmpMsg.msg.shcerror == SHC_IE_Reversed )
			{
				header->msg.shcerror = 0;	// Clear SHC_IE_Reversed flag
			}						/* R007672 << */
			
			else if(shcmsgIsResponse(&(tmpMsg.msg)) )
			{									/* R007211 BEGIN */
				if (header->msg.respcode == SHC_RC_Approved && 
					tmpMsg.msg.respcode != SHC_RC_Approved)
				{}
				else
				{
					thisShcApp->shclog_specified_msgtype = 0; //R027320
					return 0;
				}
												/* R007211 END */
			}
		}
		((ShcLog *)header->shcLogObj)->rewind();
	}
	thisShcApp->shclog_specified_msgtype = 0; //R027320

	if (header->isVoidTxn())
	{
		header->logFlag |= SHC_LOG_UPD_ORIG;
		// R027905 >>>
		//If original txn for void not found, we need to log the void txn atleast.
		if ((header->issShcBin->binPkg->bin.bin_cfg & SH_CFG_ReturnVoid) &&	
			(header->msg.respcode != SHC_RC_NoOriginal)) 
				return 0;
		// <<< R027905
	}

	//R027562 >>>
	if (header->msg.device_cap & SH_DEVCAP_FROM_REPLAY)
	{
		//For interac txns
		header->logFlag |= SHC_LOG_REQ;
		OTraceDebug("D-SHC-073055.2: Setting shcerror to SHC_IE_SafReply\n");
		header->msg.shcerror = SHC_IE_SafReply; //mark this resp msg as saf reply
	}
	else
		header->logFlag |= SHC_LOG_UPD_REQ;
	//<<< R027562

	return 0;
}

int ShcFinAuthHelper::checkRespMac(ShcmsgHeader *header)
{
	OTraceDebug( "D-SHC-073056 checking response MAC response cod is %d\n", header->msg.respcode );
    /*
     * R001835 do MACing for response messages 1998/01/16.
     */
    if ( ! shc_internalrev(header) && shcIsVerifyMac(header->issShcBin->binPkg))
	{
		int tmpRespCode = header->msg.respcode;	//	---	R025796
		if(header->msg.respcode == SHC_RC_PINKeyError)
		{
			if(header->issShcBin->isInterac())
			{
				thisShcApp->shcDKEApiObj->shc_inc_ikpesyncerrcnt_x(header);
				thisShcApp->shcKeyTxnHelperObj->shcpin_ChgKey(header);
			}
		}
		else if(header->msg.respcode == SHC_RC_MACSyncError)
		{
			if(header->issShcBin->isInterac())
			{
				thisShcApp->shcDKEApiObj->shc_inc_ikmacsyncerrcnt_x(header);
				thisShcApp->shcKeyTxnHelperObj->shcmac_ChgKey(header);
			}
		}
		else if( ! (header->msg.shc_devcap & SH_DEVCAP_SHC_EVENT)
				    && header->issShcBin->shcmac_verify(header,SHC_ACQ_KEY) < 0 )
		{
			if(header->issShcBin->isInterac())
				thisShcApp->shcKeyTxnHelperObj->shcmac_ChgKey(header);

			/*
		  	 * Send reversal 420 for 0110/0210 Security Failure,
		 	 * but not for 0230.
		 	 */	
			 //	>>>	R025796
			 if (    (!shcIsAdviceResp(header)) &&
					(tmpRespCode ==SHC_RC_Approved)
				)
				thisShcApp->shcMacObj->shc_saf_reversal(header);
		}
		if (tmpRespCode !=SHC_RC_Approved)
			//Denied msg, keep old response code
			header->msg.respcode = tmpRespCode;
		//	<<<	R025796
	}
    	else
	{
		if( header->issShcBin->binPkg->bin.bintype & SH_KEYS_AS2805 )
		{
			if( header->msg.respcode == SHC_RC_MACSyncError )
			{
				thisShcApp->shcDKEApiObj->shc_inc_ikmacsyncerrcnt_x(header);
				thisShcApp->shcNetworkMsgHelperObj->do_key_exchange_as2805(header);
			}
		}
	}
	return 0;
}

int ShcFinAuthHelper::checkNDKE(ShcmsgHeader *header)
{
	/*
	 * qd 15oct97 Update counter values for PIN errors
	 */


     if (!shc_internalrev(header) &&
		 header->msg.respcode == SHC_RC_NoKeysToUse &&
		 (header->issShcBin->isInterac() || header->acqShcBin->isInterac()))
	 {
		thisShcApp->shcDKEApiObj->shc_hsmerror_log(&header->msg, "No Keys to use shc_finresp");
	 }

 								/* R004989 >> */	
	if ( header->issShcBin->isNDKE() )
	{
		char loginfo[] = "PinLengthError shc_finresp.c 1";
		
		if (header->msg.respcode == SHC_RC_InvalidPinBlock)
		{
			OTraceInfo("I-SHC-073032: Inc PIN error counter\n");
			thisShcApp->shcDKEApiObj->shc_inc_pinerrcnt_x(header);
		}
		else if (header->msg.respcode == SHC_RC_PinLengthError)
		{
			OTraceError("E-SHC-073033: Invalid PIN length\n");
			thisShcApp->shcDKEApiObj->shc_hsmerror_log(&header->msg, loginfo);
		}
	}
 								/* << R004989 */	

	return 0;
}

//int ShcFinAuthHelper::updateEDC(ShcmsgHeader *header)
//{
//	/*	Do EDC here so we can get the key and the batch no. */
//	if(shcIsEDC(header))
//	{
//		shc_edc_update(header);
//	}
//	return 0;
//}

int ShcFinAuthHelper::encryptMsg(ShcmsgHeader *header)
{
	int ret = 0;
	char      zerokey[32] = {0}; /* R001835 */
	
	/*
	 * R001835  do message encryption if configured to do so. ACXSYS. 1997/12/17.
	 */
	 /* R007363 */
    if( ! shcIsAdviceResp(header) && header->msg.respcode == SHC_RC_Approved) 
	{
		ret = 0;
		if (header->issBinValid())
		{
			if( shcUseKme(header->issShcBin->binPkg) && memcmp(header->msg.pin, zerokey, IST_SECURITY_KEY_SZ) != 0)
			{
				ret = header->issShcBin->shckme_DecryptBalance(header, SHC_ACQ_KEY,
											header->msg.kme_index);
			}
		}
	
		if (header->acqBinValid())
		{
			if( ret == 0 && shcUseKme(header->acqShcBin->binPkg) )
			{
				header->acqShcBin->shckme_EncryptBalance(header, SHC_ISS_KEY,
					SH_KEYIDX_CURRENT);
			}
			else if( ret < 0 )
				thisShcApp->shcMacObj->shc_saf_reversal(header);
		}
	}
	
	return 0;

}
int ShcFinAuthHelper::doAck(ShcmsgHeader *header)
{
	int save_msgtype;

	 /* 25Mar92: Determine if an ACK is expected from the device */
	if(shc_excpect_ack(header) &&
	  !(header->msg.device_cap & SH_DEVCAP_FROM_REPLAY) )
	{
		/*	Do not remove the entry: Update it instead since device will ack */
		save_msgtype = header->msg.msgtype;
		header->msg.msgtype += SHC_DEVICE_ACK;
		header->time_out = time(0) + shcApp->acquirerShcParamsList->GetNum((char *)"shc.device_timeout");
	
		/* 961115 */
		if(thisShcApp->shcTimerObj->shc_time_message_x(header, (unsigned char *)header->segment) < 0)
			OTraceError("E-SHC-073034: Unable to requeue message for device\n");
		header->msg.msgtype = save_msgtype;
	}

	return 0;
}
int ShcFinAuthHelper::notifyPosAuth(ShcmsgHeader *header)
{
	/*
	 *		Check if pos authorization is used and if so notify the
	 *		positive authorization module
	 *		Do it here because there is no ack from device expected.
	 */
	if((header->logFlag) && (header->repeatFlag != 1))
		if	( /*	must allow pos'tve authorization */
				(header->issShcBin->binPkg->saf.type & SH_SAF_POSFILE) &&
				(
					(
					/*	should have been a successful transaction */
						(header->msg.respcode == 0) &&
					/*	the transaction should not have been saf already */
						(header->msg.saf == 0)
					)
				)
			)
		{
			thisShcApp->shcmsgTxnHelperObj->shc_posauth(header, 0);
		}
	return 0;
}
int ShcFinAuthHelper::writeSaf(ShcmsgHeader *header)
{
	int save_msgtype;
	
	/* R005896 >> For approved transaction from Posauth/Negative and Issuer is down, create SAF. */
	if( (header->msg.shc_devcap & SH_DEVCAP_SHC_STDIN) &&  
		(header->msg.respcode == SHC_RC_Approved) &&
		!(header->msg.device_cap & SH_DEVCAP_FROM_REPLAY) )
		// R007617		!(shcIsAdviceResp(header)) )
	{
		save_msgtype = header->msg.msgtype;
		thisShcApp->shcSafIOHelperObj->shc_saf_resp_convertmsg(header);
		thisShcApp->shcSafHelperObj->shc_general_saf_write(header->issShcBin, header, 0);
		header->msg.msgtype = save_msgtype;
	}
	/* R005896 << */
	return 0;
}
int ShcFinAuthHelper::updatePreauth(ShcmsgHeader *header)
{
	/*  20May93
		Before routing the message to the acquirer, shc_preauth_response would
	   	insert a skeleton copy of the message in preauthlog providing
	   	it has an approval and it is not a duplicate or a late response
	*/

//	if(shcIsPreAuthRsp(header) && shcRequiresPreAuthorization(header->issShcBin->binPkg) && /* R001835 */
//	  (header->msg.respcode == SHC_RC_Approved) && (header->logFlag))
//		thisShcApp->shcPreauthHelperObj->shc_preauth_response(header);
	return 0;
}

int ShcFinAuthHelper::routeSettlement(ShcmsgHeader *header)
{
	/*	Route the settlement transaction */
//	if(header->logFlag)   shc_route_settlement is empty, so this code is commented out
//		shc_route_settlement(header);
	return 0;
}

int ShcFinAuthHelper::shc_updateduptxn_info(ShcmsgHeader *header)
{
	/*	29apr93: Update shccard with transaction specifics */
	if( (shcIsAuthorizationRequest(header) || shcIsFinancialRequest(header)) // R009807
	   && header->msg.respcode != SHC_RC_DuplicateTransaction)
	{
		/*	1.	Should we maintain dup txn. info */
		if( !(header->issShcBin->binPkg->bin.flags & SH_CHECKDUP) )
			return(0);
	
		/*	2. Update the card record */
		if(thisShcApp->shcmsgHelperObj->shc_updateduptxn_info(header) < 0)
		{
			OTraceError("E-SHC-073035: Unable to update shcduplicatechk for '%s'\n",shcApp->shcHelperObj->shc_maskpan(header->msg.pan));
			return(-1);
		}
	}
	return(0);

}

int ShcFinAuthHelper::shc_restore_fields(ShcmsgHeader *header)
{

	static const char*	fnDesc="ShcFinAuthHelper";

	/* Ssc - 28Jun00	R004671 Integration to 7.2 */
	/* Ssc - 26Feb00    SPR # 2007336 Restore the chip data
     *                  into response message
     */
    emv     *oemvbuf = NULL;
    emv     *emvbuf;
    emv		tmpEmvBuf, tmpOEmvBuf;
    int 	len;
	
	if (!header->reqMsg)
		return 0;
		
	
	/*	3003337		24feb97		*/
	if(header->msg.device_cap & SH_DEVCAP_KEEP_DEVCAP)
	{
		header->msg.device_cap |= header->reqMsg->device_cap & ~SH_DEVCAP_USER_SEGMENT;
		header->msg.device_cap &= ~(SH_DEVCAP_KEEP_DEVCAP);
	}
	else
		header->msg.device_cap = 	(header->reqMsg->device_cap & ~SH_DEVCAP_USER_SEGMENT) |
									(header->msg.device_cap & SH_DEVCAP_USER_SEGMENT);
	
	OTraceLog("L-SHC-073044: Replace ID [%s] with ID [%s]\n", header->msg.shclog_id, header->reqMsg->shclog_id);

	//R028271 >>>
	if(strcmp(header->msg.shclog_id,header->reqMsg->shclog_id))
		TxnStatEquate(header->reqMsg->shclog_id, header->msg.shclog_id);
	else
		OTraceDebug("D-SHC-073044.1: No need to Equate [%s] and [%s]\n",header->msg.shclog_id,header->reqMsg->shclog_id);
	//<<< R028271

	header->msg.site_id =  header->reqMsg->site_id; 
	header->msg.version =  header->reqMsg->version; 


  	if (header->msg.src_node == 0)
		header->msg.src_node = header->reqMsg->src_node;

	if (header->msg.dest_node  == 0)
		header->msg.dest_node = header->reqMsg->dest_node;

	strcpy(header->msg.shclog_id, header->reqMsg->shclog_id);

	len = sizeof(tmpEmvBuf);
	header->getReqSegmentData((char *)&tmpOEmvBuf, &len, EMV_BUF_id, 0);
	if (len > 0)
		oemvbuf = &tmpOEmvBuf;
//	oemvbuf = (emv *)get_seg_from_shcmsg(header->reqMsg, (char *)"EMV_BUF", &len);	/* R008717 */
	
	/* Ssc - 28Jun00	R004671 Integration to 7.2 */
	/*  Rpc 2009271 VSDC change shcIsChipTxn to check with omsg instead of
    shcmsg so F137 app_txn_counter can be restored on response with SMS */

    if(oemvbuf)
	{
			
			len = sizeof(tmpEmvBuf);
			header->getSegmentData((char *)&tmpEmvBuf, &len, EMV_BUF_id, 0);
				
//			emvbuf = (emv *)get_seg_from_shcmsg(&(header->msg), (char *)"EMV_BUF", &len);	/* R008717 */

			if (len <= 0)
			{
				memset(&tmpEmvBuf, 0, sizeof(tmpEmvBuf));
			}
			emvbuf = &tmpEmvBuf;
			

			emvbuf->term_txn_date      = oemvbuf->term_txn_date;
            if (!header->issShcBin->isFullEntry()
                || header->issShcBin->isVerifyARQCReq())
                emvbuf->card_auth_res_code = oemvbuf->card_auth_res_code;

            emvbuf->term_type          = oemvbuf->term_type;
            emvbuf->term_entry_cap     = oemvbuf->term_entry_cap;
            emvbuf->chip_cond_code     = oemvbuf->chip_cond_code;
            emvbuf->ccps_txn_ind       = oemvbuf->ccps_txn_ind;
            emvbuf->card_auth_rel_ind  = oemvbuf->card_auth_rel_ind;
            emvbuf->msg_reason_code    = oemvbuf->msg_reason_code;
            emvbuf->deri_key_idx       = oemvbuf->deri_key_idx;
            emvbuf->crypto_version     = oemvbuf->crypto_version;
            emvbuf->crypto_txn_type    = oemvbuf->crypto_txn_type;
            emvbuf->term_country_code  = oemvbuf->term_country_code;
            emvbuf->crypto_curr_code   = oemvbuf->crypto_curr_code;
            emvbuf->neg_file_version   = oemvbuf->neg_file_version;
            emvbuf->ccard_pa_trace     = oemvbuf->ccard_pa_trace;
            emvbuf->ccard_purch_trace  = oemvbuf->ccard_purch_trace;
            emvbuf->ccard_crypto_trace = oemvbuf->ccard_crypto_trace;
            emvbuf->mcard_batch_trace  = oemvbuf->mcard_batch_trace;
            emvbuf->mcard_txn_trace    = oemvbuf->mcard_txn_trace;
			if (emvbuf->cvv_res_code == 0) //if cvv_res_code is not set by issuer
				emvbuf->cvv_res_code = oemvbuf->cvv_res_code; //IST_S770SP0-88

			dbm_deccopy(&emvbuf->crypto_amount,
                        &oemvbuf->crypto_amount);
            dbm_deccopy(&emvbuf->crypto_cb_amount,
                        &oemvbuf->crypto_cb_amount);
            strcpy(emvbuf->srv_restrict_code,
                   oemvbuf->srv_restrict_code);
            strcpy(emvbuf->term_cap_profile,
                   oemvbuf->term_cap_profile);
            strcpy(emvbuf->tvr,    oemvbuf->tvr);
            strcpy(emvbuf->unpredictable_num,
                   oemvbuf->unpredictable_num);
            strcpy(emvbuf->term_ser_num,
                   oemvbuf->term_ser_num);
            strcpy(emvbuf->cvr,    oemvbuf->cvr);
            strcpy(emvbuf->issuer_discre_data,
                   oemvbuf->issuer_discre_data);
            strcpy(emvbuf->cryptogram, oemvbuf->cryptogram);
            strcpy(emvbuf->ccard_sch_crypto,
                   oemvbuf->ccard_sch_crypto);
            strcpy(emvbuf->app_ichg_profile,
                   oemvbuf->app_ichg_profile);
 			/* R007416 */
            strcpy(emvbuf->issuer_app_data,
                   oemvbuf->issuer_app_data);
           
		   header->msg.card_seqno = header->reqMsg->card_seqno;

			/* R0013872 */
			if (!emvbuf->app_txn_counter[0])
			{
				strcpy(emvbuf->app_txn_counter,
			           oemvbuf->app_txn_counter);
			}

			/* R008083 */
            strcpy(emvbuf->cvm_results,
                   oemvbuf->cvm_results);
            emvbuf->trans_seq_counter    = oemvbuf->trans_seq_counter;

            emvbuf->bitmap    |= oemvbuf->bitmap;

            emvbuf->chip_type  = oemvbuf->chip_type;

			emvbuf->tvr_cvr_status = oemvbuf->tvr_cvr_status;

			/* R014738 restore arpc respcode if no arpc in response */
			if (!emvbuf->arpc_cryptogram[0])
			{
				memcpy(emvbuf->arpc_respcode, oemvbuf->arpc_respcode, 3);
			}
            header->setSegmentData((char *)&tmpEmvBuf, sizeof(tmpEmvBuf), EMV_BUF_id, 0);
	}
	/* Ssc - 26Feb00    SPR # 2007336 End of chip data restore */

	/* R008717 BEGIN */
	if ((!header->msg.txnSrc[0]) && (header->reqMsg->txnSrc[0]))
		strcpy(header->msg.txnSrc, header->reqMsg->txnSrc);
	if ((!header->msg.txnDest[0]) && (header->reqMsg->txnDest[0]))
		strcpy(header->msg.txnDest, header->reqMsg->txnDest);
	if ((!header->msg.alternateAcquirer[0]) && (header->reqMsg->alternateAcquirer[0]))
		strcpy(header->msg.alternateAcquirer, header->reqMsg->alternateAcquirer);
	if ((!header->msg.entityId[0]) && (header->reqMsg->entityId[0]))
		strcpy(header->msg.entityId, header->reqMsg->entityId);
	if (header->reqMsg->iss_entityId[0]) 					/* IST_S770SP5-147 */
		strcpy(header->msg.iss_entityId, header->reqMsg->iss_entityId);
	if ((!header->msg.cardProduct[0]) && (header->reqMsg->cardProduct[0]))
		strcpy(header->msg.cardProduct, header->reqMsg->cardProduct);
	if (shcApp->acquirerShcParamsList->GetBool((char *)"shc.restoreAcqInstIDCode"))
	{
		if (header->reqMsg->member_ID[0])
			strcpy(header->msg.member_ID, header->reqMsg->member_ID);
	}
	else 
	{
		if ((!header->msg.member_ID[0]) && (header->reqMsg->member_ID[0]))
			strcpy(header->msg.member_ID, header->reqMsg->member_ID);
	}
	if ((!header->msg.F_ID[0]) && (header->reqMsg->F_ID[0]))
		strcpy(header->msg.F_ID, header->reqMsg->F_ID);
	if ((!header->msg.MVV[0]) && (header->reqMsg->MVV[0]))
		strcpy(header->msg.MVV, header->reqMsg->MVV);
	if ((!header->msg.invoice_number[0]) && (header->reqMsg->invoice_number[0]))
		strcpy(header->msg.invoice_number, header->reqMsg->invoice_number);
	if ((!header->msg.trans_id[0]) && (header->reqMsg->trans_id[0]))
		strcpy(header->msg.trans_id, header->reqMsg->trans_id);
	if ((!header->msg.FPI[0]) && (header->reqMsg->FPI[0]))
		strcpy(header->msg.FPI, header->reqMsg->FPI);
	/* R008717 END */
	
	if (header->msg.txn_start_time <= 0)
		header->msg.txn_start_time = header->reqMsg->txn_start_time;

	if (header->msg.iss_conv_date == 0)
		header->msg.iss_conv_date = header->reqMsg->iss_conv_date;	/* R003818 */

	if( header->msg.acq_currency_code <= 0 )				/* 10001663 */
		header->msg.acq_currency_code = header->reqMsg->acq_currency_code;
	header->msg.acq_country	= header->reqMsg->acq_country;	/* ss:10mar95 */

	header->msg.local_time = header->reqMsg->local_time;
	header->msg.local_date = header->reqMsg->local_date;

 	/* R003308 */ 
    if ( header->issShcBin->isRestoreTranTime() == True )   /* R000960 */
    {
        header->msg.trantime = header->reqMsg->trantime;
        header->msg.trandate = header->reqMsg->trandate;
    }
	header->msg.merchant_type = header->reqMsg->merchant_type;
	if(header->msg.origmsg == 0) /* R005129 */
	{
		header->msg.origmsg = header->reqMsg->origmsg;
		header->msg.origtrace = header->reqMsg->origtrace;
		header->msg.origdate = header->reqMsg->origdate;
		header->msg.origtime = header->reqMsg->origtime;
	}
	header->msg.storeid = header->reqMsg->storeid;					/* 2002563 */
	header->msg.batch_id = header->reqMsg->batch_id;
	header->msg.origpcode = header->reqMsg->origpcode;				/* 10002273 */
	header->msg.origFlippedMsg = header->reqMsg->origFlippedMsg;
	header->msg.shc_devcap |= header->reqMsg->shc_devcap;				/* 10002273 */

	/* R001731. 
	 * restore the acctnum only if there is nothing in it in response msg. 
	 */
	if ( header->msg.acctnum[0] == '\0' )
		strcpy(header->msg.acctnum, header->reqMsg->acctnum); 		/* 2002587 */

    /* R001657.
     * restore the amount only if there is nothing in it in response msg.
     */
    if ( dbm_decncmp(&header->msg.amount, (double)0) == 0 )
        dbm_deccopy(&header->msg.amount, &header->reqMsg->amount);

	/* R027338
	 * Restore cash_back amount
	 */
	if(dbm_decncmp(&header->msg.cash_back,(double)0) == 0)
		dbm_deccopy(&header->msg.cash_back, &header->reqMsg->cash_back);

	if(dbm_cmpzero(&header->reqMsg->device_fee) != 0)	/* R002421 */  //IST_S770SP4-292
		dbm_deccopy(&header->msg.device_fee, &header->reqMsg->device_fee);	/* R002421 */

	if(header->msg.device_cap & SH_DEVCAP_INGORE_SERIAL)
	{
		OTraceDebug("D-SHC-073036: Keep serial_1 and originator fields\n");
	}
	else
	{
		strcpy(header->msg.originator, header->reqMsg->originator);
		header->msg.serial_1 = header->reqMsg->serial_1;
	}


	/*  11Apr96 */ 
	header->msg.pos_condition_code = header->reqMsg->pos_condition_code; /* R007953 */
					/* R008041 >> */
	header->msg.device_devcap = header->reqMsg->device_devcap 
				| (SH_DEVICE_TABLES_MASK & header->msg.device_devcap);
					/* R008041 << */
	header->msg.formatter_devcap = header->reqMsg->formatter_devcap; /* R007953 */
	header->msg.auth_devcap |= header->reqMsg->auth_devcap; //  --- R023574
	header->msg.pos_cap_code = header->reqMsg->pos_cap_code; /* R007953 */

	if(!(header->msg.device_cap & SH_DEVCAP_KEEP_PCODE))
		header->msg.pcode	 = header->reqMsg->pcode;
	if (!header->msg.from_acct)
		header->msg.from_acct = header->reqMsg->from_acct;
	if (!header->msg.to_acct)
		header->msg.to_acct = header->reqMsg->to_acct;

	header->msg.unit		= header->reqMsg->unit;

        if(header->msg.device_cap & SH_DEVCAP_SAVE_CAP_DATE)
	{
		OTraceDebug("D-SHC-073037:Before restoring: SAVE flag is set\n");
				header->reqMsg->device_cap |= SH_DEVCAP_SAVE_CAP_DATE;
	}
	else
	{
		OTraceDebug("D-SHC-073038:Before restoring: SAVE flag is NOT set\n");
	}

	header->msg.terminal_trace = header->reqMsg->terminal_trace;

	/* MI - 13Aug95: Added flag to not restore capture date from orig req */
	if(!(header->msg.device_cap & SH_DEVCAP_SAVE_CAP_DATE))
	{
		OTraceDebug("D-SHC-073039:Restore cap_date RESP[%ld] - REQ[%ld]\n",
				header->msg.cap_date, header->reqMsg->cap_date);
								
		header->msg.cap_date	   = header->reqMsg->cap_date;
	}

	/* 
 	 * R002139.
	 * Restore settlement_date from the request message if it is
	 * empty in response message.
	 */ 
    if ( header->msg.settlement_date == 0 ) 
	{
       	OTraceDebug("D-SHC-073040:Restored settlement from: [%ld] to [%ld]\n",
				header->msg.settlement_date, header->reqMsg->settlement_date);
		header->msg.settlement_date = header->reqMsg->settlement_date;
	}


    if ( header->msg.processor_busday == 0 ) 
	{
		header->msg.processor_busday = header->reqMsg->processor_busday;
	}

	strcpy(header->msg.acquirer, header->reqMsg->acquirer);

	if(!(header->msg.device_cap & SH_DEVCAP_KEEP_ACCEPTORNAME))
		strcpy(header->msg.acceptorname, header->reqMsg->acceptorname);

	
	memcpy(header->msg.termid, header->reqMsg->termid, sizeof(header->msg.termid));

	if(!(header->msg.device_cap & SH_DEVCAP_KEEP_FORMATTER_USE))
		memcpy(header->msg.formatter_use, header->reqMsg->formatter_use,
			sizeof(header->reqMsg->formatter_use));
	
	
	/*	16apr93:	Restore termloc */
	strcpy(header->msg.termloc, header->reqMsg->termloc);

	/* 05Oct94 - Just added a debug line for bin mapping */
	OTraceDebug("D-SHC-073041:I-SHC-%s-%d - a%s - o%s\n", fnDesc, __LINE__, 
			header->msg.acquirer, header->msg.originator);

	if (header->reqMsg->refnum[0])
		strcpy(header->msg.refnum, header->reqMsg->refnum);				/* 31may96 */

	header->msg.pos_entry_code = header->reqMsg->pos_entry_code;		/* R004419 */

    /* 
     * yh: 1997/09/22. R001858.
     *    restore acquirer_data for SMS when the response comes back.
     */
     memcpy(header->msg.acquirer_data, header->reqMsg->acquirer_data, 
            sizeof(header->reqMsg->acquirer_data));

	/*
	 * Restore security related information from the original request message
	 * when the response message comes back. ACXSYS. 1997/01/16.
	 */
    header->msg.pin_index = header->reqMsg->pin_index;  
	/* header->msg.mac_index = header->reqMsg->mac_index;  R001835 */
    /* 
     * ACXSYS   1998/03/24  et
     */
    if ( header->msg.track2[0] == '\0' )
         strcpy(header->msg.track2,  header->reqMsg->track2);
	

    if ( header->msg.track3[0] == '\0' )
         strcpy(header->msg.track3,  header->reqMsg->track3);

	/*R003928 SG*/
	/*Restore sub field by sub field Currently assuming that only finreq 
		is filling up the fields in future will need some of this field 
		restored in shc_revresp.c*/
	memcpy(&shc_data_rec ,header->msg.shc_data_buffer,sizeof(struct shc_data));
	memcpy(&orig_shc_data_rec,header->reqMsg->shc_data_buffer,sizeof(struct shc_data));
	/*Check first element of the data instead of using strlen as strlen can 
	  result in coredumps if the given data structre is not null terminated*/
	if(!(shc_data_rec.cvv2_resultcode))
		shc_data_rec.cvv2_resultcode=orig_shc_data_rec.cvv2_resultcode;
	if(!(shc_data_rec.cvv_resultcode))
		shc_data_rec.cvv_resultcode=orig_shc_data_rec.cvv_resultcode;
	if(!(shc_data_rec.cvv2_indicator))
		shc_data_rec.cvv2_indicator=orig_shc_data_rec.cvv2_indicator;
	if(!(shc_data_rec.issuer_country_code[0]))
		memcpy(shc_data_rec.issuer_country_code,orig_shc_data_rec.issuer_country_code,4);
	if(!(shc_data_rec.mcard_sno[0]))
		memcpy(shc_data_rec.mcard_sno,orig_shc_data_rec.mcard_sno,33);
	if(!(shc_data_rec.ccard_sno[0]))
		memcpy(shc_data_rec.ccard_sno,orig_shc_data_rec.ccard_sno,33);
	if(!(shc_data_rec.expiry_date[0]))
		memcpy(shc_data_rec.expiry_date,orig_shc_data_rec.expiry_date,5);
	if(!(shc_data_rec.trans_id[0]))
		memcpy(shc_data_rec.trans_id,orig_shc_data_rec.trans_id,41);
	if(!(shc_data_rec.trans_stain[0]))
		memcpy(shc_data_rec.trans_stain,orig_shc_data_rec.trans_stain,41);
										/* R007197 BEGIN */
	if ( !shc_data_rec.networkCAVVResult)
		shc_data_rec.networkCAVVResult = orig_shc_data_rec.networkCAVVResult;
	if ( !shc_data_rec.issuerCAVVResult)
		shc_data_rec.issuerCAVVResult = orig_shc_data_rec.issuerCAVVResult;
	shc_data_rec.device_cap[0] |= orig_shc_data_rec.device_cap[0] & SHC_DATA_DEVICE_CAP_RESTORE_MASK1;
	shc_data_rec.device_cap[1] |= orig_shc_data_rec.device_cap[1] & SHC_DATA_DEVICE_CAP_RESTORE_MASK1;
	shc_data_rec.device_cap[2] |= orig_shc_data_rec.device_cap[2] & SHC_DATA_DEVICE_CAP_RESTORE_MASK1;
										/* R007197 END */

	//pos_condigition is decided by acquirer, so it should alwasy be restored
	shc_data_rec.pos_condition_code_x = orig_shc_data_rec.pos_condition_code_x;
	//Set repeat flag
	if (header->reqMsg->msgtype%2 == 1)
		header->msg.shc_devcap |= SH_DEVCAP_SHC_REQ_REPEAT;
		

	if(!(shc_data_rec.service_code[0]))
		memcpy(shc_data_rec.service_code,orig_shc_data_rec.service_code,sizeof(shc_data_rec.service_code));

	OTraceDebug("D-SHC-073050: cvv2 resultcode : [%c] \n", shc_data_rec.cvv2_resultcode);
	OTraceDebug("D-SHC-073050.1: reqMsg-addresponse : [%s] \n", header->reqMsg->addresponse);
	OTraceDebug("D-SHC-073050.2: resp-addresponse : [%s] \n", header->msg.addresponse);

    /* JIRA # ISTSWITCH-185 Restoring Visa DE44.10 cvv2_resultcode if not received in response */
    if( header->msg.addresponse[0] == '\0' && header->reqMsg->addresponse[0] != '\0' && (strcmp(header->msg.txnDest, visaInst)==0|| strcmp(header->msg.txnSrc, visaInst)==0) )
    {
         char cvv2buf[4];
         int cvv2 = -1;
         memset(cvv2buf, 0, sizeof(cvv2buf));
         cvv2buf[0] = shc_data_rec.cvv2_resultcode;
         cvv2buf[1] = '\0';
         //cvv2 = atoi(cvv2buf) ;
         //if(cvv2 == 0)
	cvv2 = strlen(cvv2buf);
	if ((cvv2 == 0 || cvv2buf[0] == ' '))
         {
              OTraceDebug("D-SHC-073051:Setting cvv2_resultcode from reqMsg->addresponse : [%c]\n", header->reqMsg->addresponse[10]);
              shc_data_rec.cvv2_resultcode = header->reqMsg->addresponse[10];
         }
    }
	
	memcpy(header->msg.shc_data_buffer,&shc_data_rec,sizeof(struct shc_data));

	/* R005515 Restore filler1 for MasterCard pass back the Acquirer */
														/* R007781 BEGIN */
	if (shc_is_empty_buf(header->msg.filler1, sizeof(header->msg.filler1)))
		memcpy( header->msg.filler1, header->reqMsg->filler1, sizeof(header->msg.filler1) );
	if (shc_is_empty_buf(header->msg.filler2, sizeof(header->msg.filler2)))
		memcpy( header->msg.filler2, header->reqMsg->filler2, sizeof(header->msg.filler2) );
	if (shc_is_empty_buf(header->msg.filler3, sizeof(header->msg.filler3)))
		memcpy( header->msg.filler3, header->reqMsg->filler3, sizeof(header->msg.filler3) );
	if (shc_is_empty_buf(header->msg.filler4, sizeof(header->msg.filler4)))
		memcpy( header->msg.filler4, header->reqMsg->filler4, sizeof(header->msg.filler4) );
														/* R007781 END */

			/* R007209 >> */	
	if ( dbm_decncmp(&header->msg.txn_conv_rate, (double)0) == 0 )
		dbm_deccopy(&header->msg.txn_conv_rate, &header->reqMsg->txn_conv_rate);
		
	if ( dbm_decncmp(&header->msg.new_amount, (double)0) == 0 )
		dbm_deccopy(&header->msg.new_amount, &header->reqMsg->new_amount);

												/* R007205 BEGIN */
	if ( dbm_decncmp(&header->msg.ch_new_amount, (double)0) == 0 )
		dbm_deccopy(&header->msg.ch_new_amount, &header->reqMsg->ch_new_amount);
												/* R007205 END */
		
	if ( dbm_decncmp(&header->msg.new_setl_fee, (double)0) == 0 )
		dbm_deccopy(&header->msg.new_setl_fee, &header->reqMsg->new_setl_fee);
			/* << R007209 */
	
			/* R008059 >> */
	if ( dbm_decncmp(&header->msg.iss_conv_rate, (double)0) == 0 )
		dbm_deccopy(&header->msg.iss_conv_rate, &header->reqMsg->iss_conv_rate);
		
	if ( dbm_decncmp(&header->msg.amount_equiv, (double)0) == 0 )
		dbm_deccopy(&header->msg.amount_equiv, &header->reqMsg->amount_equiv);
	
	if( header->msg.iss_currency_code == 0 )
		header->msg.iss_currency_code = header->reqMsg->iss_currency_code;
	
	if( header->msg.issuer_data[0] == '\0' )
		memcpy( header->msg.issuer_data, header->reqMsg->issuer_data
				, sizeof(header->msg.issuer_data) );

	if( header->msg.cvv2[0] == '\0' )
		memcpy( header->msg.cvv2, header->reqMsg->cvv2, sizeof(header->msg.cvv2) );

	if( header->msg.sec_fmt_code[0] == '\0' )
		memcpy( header->msg.sec_fmt_code, header->reqMsg->sec_fmt_code
				, sizeof(header->msg.sec_fmt_code) );
			/* R008059 << */
			
	thisShcApp->pcode_req = header->reqMsg->pcode;	// R010134

	//R027355 >>>
	if (header->msg.authnum[0] == '\0')
		memcpy(header->msg.authnum,header->reqMsg->authnum,sizeof(header->msg.authnum));
	//<<< R027355

	if(header->reqMsg->shcerror==10)
	{
		OTraceDebug("D-SHC-073065: Response is Auth Capture Transaction\n");
		header->msg.shcerror = header->reqMsg->shcerror;
		header->msg.shift_number = header->reqMsg->shift_number;
	}
	header->getSegList()->restore(header->getReqSegList());
		
	return(0);
}

int ShcFinAuthHelper::setDoWorkRoutingInfo(ShcmsgHeader *header)
{
	/* All messages at this point should be routed back to Original sender */
	if (header->reqMsg)
	{
		header->msg.senderid	= header->reqMsg->senderid;
		header->msg.unit		= header->reqMsg->unit;
	}

	header->shcerr			= SH_RETURN;
	//	>>>	R021843	
	
	//	 Check done for 0130 in addition to 0230 advice message
	if (!(header->issShcBin->binPkg->bin.flags & SH_GETAPP_HOST) && shcIsFinOrAuthAdviceResp(header) &&!(header->msg.device_cap & SH_DEVCAP_FROM_REPLAY) && !(header->createdInternal()))	//	---	R026319
	header->shcerr = SH_IGNORE;

	//	<<<	R021843
	return 0;
}

//      >>>     R019631
int ShcFinAuthHelper::setBalances(ShcmsgHeader *header)
{
	// R027876 >>>
	char curp[19];
	int curlen = sizeof(curp);
	memset(curp,0x00,sizeof(curp));
	header->getSegmentData(curp, &curlen, ElfIdMap::elf_to_id(IST_SEG_NETWORK_DATA_RESP), SMS_ADD_AMT_CURR_CODE);
	//---R032323 Use NETWORK_DATA_RESP instead of NETWORK_DATA_REQ
	// <<< R027876

	if ((dbm_cmpzero(&header->msg.aval_balance)!=0) &&
		(dbm_cmpzero(&header->msg.acq_aval_balance)==0) &&
		(curlen) // R027876
		)
	{
		char curbuf[4];
		if (curlen > 3)
			curlen = 3;
		memcpy(curbuf, curp, curlen);
		curbuf[curlen] = '\0';
		int bal_cur = atoi(curbuf);
		if (bal_cur == header->msg.acq_currency_code)
		{
			dbm_deccopy(&header->msg.acq_aval_balance, &header->msg.aval_balance);
			dbm_deccopy(&header->msg.acq_ledger_balance, &header->msg.ledger_balance);
		}
	}

	return 0;
}
//      <<<     R019631

// >>> R027905
int ShcFinAuthHelper::checkAndProcessVoid(ShcmsgHeader *header)
{
	if (header->isVoidTxn() &&
		(header->issShcBin->binPkg->bin.bin_cfg & SH_CFG_ReturnVoid) )
	{
		ShcmsgProcessor *p=NULL;

		if(header->origMsg->shcerror == SHC_IE_Voided)
		{
			if(header->msg.msgtype % 10 == 1)
				header->msg.origFlippedMsg = header->msg.msgtype;
			thisShcApp->shcmsgHelperObj->shc_set_return_msgno(&header->msg);
			header->shcerr = SH_NO_TIMER_PRESENT;
			OTraceDebug("D-SHC-073043: Duplicate Void will be rejected by SHC...not sent to issuer\n");
			header->msg.respcode = SHC_RC_DuplicateTransaction;
			if ((p=(ShcmsgProcessor *)thisShcApp->shcmsgTxnHelperObj->enqueueInternalMsg(header)) == NULL)
				return -1;
			header->shcerr = SH_IGNORE;
			((ShcmsgHeader *)p->header)->allocateAndCopyOrigMsg(header->origMsg);

			return -1;

		}

		OTraceDebug("D-SHC-073043: Void will be approved directly by SHC...not sent to issuer\n");

		header->origMsg->shcerror = SHC_IE_Voided;
		thisShcApp->shcmsgHelperObj->shc_set_return_msgno(&header->msg);
		header->shcerr = SH_NO_TIMER_PRESENT;
		if ((p=(ShcmsgProcessor *)thisShcApp->shcmsgTxnHelperObj->enqueueInternalMsg(header)) == NULL)
			return -1;
		header->shcerr = SH_IGNORE;
		((ShcmsgHeader *)p->header)->allocateAndCopyOrigMsg(header->origMsg);

		return -1;
	}
	return 0;
}

int ShcFinAuthHelper::checkAndProcessRefund(ShcmsgHeader *header)
{
	if (shcIsRefund(header->msg.pcode) &&
		(header->issShcBin->binPkg->bin.bin_cfg & SH_CFG_ReturnRefund) )
	{
		int old_msgtype = header->msg.msgtype;
		OTraceDebug("D-SHC-073043: Refund will be approved directly by SHC...not sent to issuer\n");
		thisShcApp->shcmsgHelperObj->shc_set_return_msgno(&header->msg);
		header->shcerr = SH_RETURN;
		thisShcApp->shcmsgHelperObj->shc_generate_auth_number(header); //R028735
		OTraceDebug("D-SHC-073043.1: Authnum generated for refund [%s]\n",header->msg.authnum);

		if (thisShcApp->shcmsgTxnHelperObj->enqueueInternalMsg(header) == NULL)
			return -1;
		header->msg.msgtype = old_msgtype; //R028810
		header->shcerr = SH_IGNORE;
		return -1;
	}
	return 0;
}
// <<< R027905
int ShcFinAuthHelper::checkRepeatFileUpdate(ShcmsgHeader *header)
{
	int isrepeat = 0;
	int saved_msgtype = 0;

	if(
		header->msg.msgtype == SHC_ISTAUTH_FILE_UPD_REQ_REPEAT
	)
	{

		saved_msgtype = header->msg.msgtype;
		struct	ShcmsgWithSegment omsg;
		int ret;

		memset(&omsg, 0, sizeof(omsg));
		locate_for_repeat = 1;
		if(((ShcLog *)header->shcLogObj)->locateTxn(header, &(omsg.msg), NULL) < 0)
		{
			locate_for_repeat = 0;
			OTraceDebug("D-SHC-073050: Repeat Msg not found, Creating transaction.\n");
			header->logFlag |= SHC_LOG_REQ;
			((ShcLog *)header->shcLogObj)->rewind();
			header->msg.msgtype = saved_msgtype;
			return 0;
		}
		locate_for_repeat = 0;		
		header->allocateAndCopyReqMsg(&omsg.msg);
		header->allocateAndCopyOrigMsg(&omsg.msg);
		char tmplogid[sizeof(header->msg.shclog_id)];
		strcpy (tmplogid, header->msg.shclog_id);
		strcpy(header->msg.shclog_id, header->origMsg->shclog_id);
		IstSegList *origSegList = 
			((ShcLog *)header->shcLogObj)->restoreGenericLog(shcGenericLogObj, header, 'B');
		strcpy(header->msg.shclog_id, tmplogid);
		if (origSegList)
			header->setOrigSegList(origSegList);

		if(omsg.msg.settlement_date)
			header->msg.settlement_date = omsg.msg.settlement_date;
	
		((ShcLog *)header->shcLogObj)->rewind();
		header->msg.msgtype = saved_msgtype;
		isrepeat = 1;
		return(1);
	}
	return isrepeat;
}
int ShcFinAuthHelper::checkBinDownForTarTxn(ShcmsgHeader *header)
{
	char p1cInst[MAX_TXN_DESTINATION_LEN+1];
	int ret = shc_getInstitutionIdFromCardScheme(p1cInst, P1C_DEST);
	OTraceDebug("D-SHC-073065: Check for Destination [%s]\n",p1cInst);
        if(shc_isdown(header->issShcBin->binPkg) && (strcmp(header->msg.txnDest, p1cInst)==0))
        {
                if(checkForMCTarTxn(header) || checkForVisaTarTxn(header))
                {
                        OTraceDebug("D-SHC-073064: Standin Authorization not permitted for P1C VIsa/MC Token Authorisation Transaction\n");
                        shc_return_finauth(header, SHC_RC_IssuerTimeout);
                        return -1;
                }
        }
        return 1;
}

int ShcFinAuthHelper::checkForMCTarTxn(ShcmsgHeader *header)
{
	char xbuf[256];
        int len = sizeof(xbuf);
        memset(xbuf,0x00,sizeof(xbuf));
        header->getSegmentData(xbuf, &len, ElfIdMap::elf_to_id(IST_SEG_NETWORK_SETTLEMENT_DATA), MC_MONEYSEND_SENDER_ID);
       	if(strncmp(xbuf,"TA",2) == 0)
       	{
               	OTraceDebug("D-SHC-073061: Standin Authorisation not permitted for MC 0100 TAR\n");
               	return 1;
       	}
       	return 0;
}

int ShcFinAuthHelper::checkForVisaTarTxn(ShcmsgHeader *header)
{
        switch(header->msg.reason_code)
        {
                case 3700:
                case 3701:
                case 3702:
                case 3703:
                case 3711:
                case 3712:
                case 3713:
                case 3714:
                        OTraceDebug("D-SHC-073062: Standin Authorisation not permitted for VISA 0100 TAR\n");
                        return 1;
                default :
                        OTraceDebug("D-SHC-073063:: Transaction is not VISA 0100 TAR\n");
                        break;
        }
        return 0;
}
int ShcFinAuthHelper::verifyCompletionAmount(ShcmsgHeader *header)
{
	/*
 *   	 *	Verify the completion amount with pre-auth amount.
 *   	   	 */
	if(shcApp->issuerShcParamsList->GetBool((char *)"shc.validate_preauth_completion_amt"))
	{
		if (header->origMsg!=NULL )
		{
			if(dbm_deccmp(&header->msg.amount, &header->origMsg->amount)<=0)
			{
				return 0;
			}
			else
			{
				OTraceError("E-SHC-073024: completion transaction amount:[%f] should be lessthan or equal to pre-auth amount:[%f]\n",
						dbm_dectodbl(&header->msg.amount),dbm_dectodbl(&header->origMsg->amount));
				shc_return_finauth(header, SHC_RC_PreauthAmtExceeded);
				return -1;
			}
		}
	}
	return 0;
}

int ShcFinAuthHelper::checkIsBillPayTxn(ShcmsgHeader *header)
{
	struct shc_data *ptr_shc_data = (struct shc_data *)header->msg.shc_data_buffer;
	char *netData = ptr_shc_data->network_data;
	int isBillPayTxn = 0;

	if( !(netData[RAFT_NET_DATA_FLAG] & RAFT_ECOMMERCE_FLAG_BILLPAY) && (netData[RAFT_NET_DATA_FLAG] & RAFT_PINLESS_BILL_PAY_FLAG) )
	{
		isBillPayTxn = 1;
	}

	OTraceDebug("D-SHC-073066: billPay_txn PINLESS_BILL_PAY_FLAG [%d].\n", isBillPayTxn );

	return isBillPayTxn;
}

int ShcFinAuthHelper::checkOriginalTxnIsOk(ShcmsgHeader *header)
{
	if ( ( header->origMsg ) && 
		 ( header->origMsg->respcode == SHC_RC_IssuerTimeout ) )
	{
		header->msg.respcode = header->origMsg->respcode;
		header->msg.revcode = header->origMsg->reason_code;
		OTraceError("E-SHC-073078: Original txn declined due to Issuer Timeout. No SAF required. \n");
		/*	No store and forward allowed */
		shc_return_finauth( header, SHC_RC_IssuerTimeout );
		return -1;
	}
	return 0;
}
