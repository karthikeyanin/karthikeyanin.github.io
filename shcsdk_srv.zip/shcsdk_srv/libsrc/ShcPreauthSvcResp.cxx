static char _ShcPreauthSvcResp_cxx_what[] = "@(#) ShcPreauthSvcResp.cxx 1.4 04/11/26 15:56:16";

/*
 *  Copyright (C) 2004 eFunds Corporation ("eFunds").  All Rights Reserved.     
 *  eFunds Canada Corporation is an authorized user.                            
 *                                                                              
 *  IST is a registered trademark of eFunds Corporation.  Other brand or        
 *  product names are trademarks or registered trademarks of their respective   
 *  holders.                                                                    
 *                                                                              
 *  The information contained herein is the unpublished proprietary property    
 *  of eFunds.  Except as specifically authorized in writing by eFunds, the     
 *  holder of this document shall: i) keep all information contained herein     
 *  confidential, and ii) protect the information, in whole or in part, from    
 *  disclosure and dissemination to all third parties.                          
 *                                                                          
 *  This document and the software described in it are furnished under license  
 *  and may be used or copied only in accordance with the terms of such license.
 *  This document is supplied for information purposes only, is subject to      
 *  change without notice, and should not be construed as a commitment by       
 *  either eFunds Corporation or eFunds Canada Corporation. 
 */
/*
 *
 *                        MODIFICATION HISTORY                  REVIEW
 *
 *	SPR#	Who	Date	Description			Who	Date   
 * ===========================================================================
 * 10002264 qd 22jul96  Do not send messages to preauth agent if it is not up 
 * R007062	gbeeng	26Nov2001	C++ Migration
 */

//File Number 111

#include <stdio.h>
#include <string.h>
#include <oasis.h>
#include <ist_otrace.h>
#include <ShcMsgCache.h>
#include <shc.h>
#include <tm.h>
#include <shcpreauth.h>

#include <ShcPreauthHelper.h>
#include <ShcPreauthSvcResp.h>
#include <ShcApp.h>
#include <ShcPreauthSvcHelper.h>

int ShcPreauthSvcResp::doWork()
{
	switch(header->msg.netcode) 
	{
		case PreauthServInsRec :
			/* These messages are not going to be routed anywhere */
			header->shcerr = SH_IGNORE;
			OTraceInfo("I-SHC-111001:Rcvd preauth srv-ins rcrd resp.\n");
			break;

		case PreauthServRetRec :
			OTraceInfo("I-SHC-111002:Rcvd preauth srv-ret rcrd resp.\n");
			thisShcApp->shcPreauthSvcHelperObj->preauth_service_return(header);
			break;

		default:	
			header->shcerr = SH_IGNORE;
			break;
	}	
	return(0);
}





