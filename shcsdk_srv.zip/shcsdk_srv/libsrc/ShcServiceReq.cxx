static char _ShcServiceReq_cxx_what[] = "@(#) ShcServiceReq.cxx 1.8.1.3 17/03/08 15:07:37";
/*
 *  Copyright (C) 2004 eFunds Corporation ("eFunds").  All Rights Reserved.     
 *  eFunds Canada Corporation is an authorized user.                            
 *                                                                              
 *  IST is a registered trademark of eFunds Corporation.  Other brand or        
 *  product names are trademarks or registered trademarks of their respective   
 *  holders.                                                                    
 *                                                                              
 *  The information contained herein is the unpublished proprietary property    
 *  of eFunds.  Except as specifically authorized in writing by eFunds, the     
 *  holder of this document shall: i) keep all information contained herein     
 *  confidential, and ii) protect the information, in whole or in part, from    
 *  disclosure and dissemination to all third parties.                          
 *                                                                          
 *  This document and the software described in it are furnished under license  
 *  and may be used or copied only in accordance with the terms of such license.
 *  This document is supplied for information purposes only, is subject to      
 *  change without notice, and should not be construed as a commitment by       
 *  either eFunds Corporation or eFunds Canada Corporation. 
 */
/*
 *
 *                        MODIFICATION HISTORY                  REVIEW
 *
 *	SPR#	Who	Date	Description			Who	Date   
 * ===========================================================================
 *	ad		03mar92		Created
 *	ad		07mar92		Added 'GetRoute' request
 *	ad		09mar92		Added 'ReadRefnum' request
 *	ss		19mar92		Added 'ShclogMatch' request.
 *	ad		02apr92		Added Invalid PIN Request
 *	ad		11apr92		Added code for shcServiceRouteIssuer/Acquirer
 *	ss		29Apr92		Added code for shcServiceRouteToSender
 *	ad/ss	02may92		Added code for shcServiceManageTo... and
 *						code for shcRespondToSender
 *	ad		27may92		Added service shcServiceMarkCardStatus
 *	ad		03jun92		Modified ServiceMarkCardStatus so that correct error
 *						codes are returned and the message is logged.
 *	ad		05jul93		Added code to support RouteToOnUsIssuer
 *	LS		05Jun95		Added abs() to handle negative pin tries numbers 
 *	la		15jul95		Added new service to update response code is shclog.
 *  0001015 qd 15may98  Added support for forward mode processing 
 * R003163 HJ	10Nov99
 * R006700 jy	27Sep01	Initilising the omsg and shclogmatch buffer
 * R007062	gbeeng	26Nov2001	C++ Migration
 *R008717 ztang 18Nov02	Multi-institution support. Keep only one mailbox route and one port
 *R012160 Emj 10Oct04  Set Processor Business Day
 *R022100 sks 30Nov07 Use func issBinValid & acqBinValid to check validity of bin
 */

 //File Number 121

#include <stdio.h>
#include <string.h>
#include <sys/types.h>
#include <oasis.h>
#include <ist_otrace.h>
#include <mb.h>
#include <tm.h>
#include <ShcMsgCache.h>
#include <CShcLog.h>
#include <shc.h>

#include <ShcmsgHelper.h>
#include <ShcServiceReq.h>
#include <ShcApp.h>
#include <ShcmsgTxnHelper.h>
#include <ShcBin.h>
#include<ShcPinTryCounter.h>

int ShcServiceReq::enrich()
{
	int		save_msgtype;
	
	thisShcApp->shcmsgHelperObj->shc_normalizebin(header->msg.acquirer); /* R003163 */
	OTraceInfo("I-SHC-121001: Received Reqest with code[%d]\n", header->msg.netcode);
	
	switch(header->msg.netcode)
	{

	case	shcServiceInvalidPIN:
		/*	Perform a setup to get all required pointers */
		save_msgtype = header->msg.msgtype;
		header->msg.msgtype = SHC_FINREQ_RESPONSE;	/*	to allow startup */
		//ShcmsgBaseTxn::enrich();	//		shc_initialise_transaction(header);
		if (!header->createdInternal())
		{
			thisShcApp->shcmsgTxnHelperObj->setDefaultKeyLen(header);
			thisShcApp->shcmsgTxnHelperObj->setOriginator(header);
			thisShcApp->shcmsgHelperObj->shc_normalizepan(header->msg.pan);
	
//			thisShcApp->shcmsgTxnHelperObj->setParamSet(header);
			thisShcApp->shcmsgHelperObj->shc_get_pin_data(header);
			thisShcApp->shcmsgTxnHelperObj->setCurrencyCode(header);
			thisShcApp->shcmsgTxnHelperObj->setAcqCountry(header);
			thisShcApp->shcmsgHelperObj->setPinParm(header);
			thisShcApp->shcmsgTxnHelperObj->setOnlineActivity(header);
			OTraceInfo("I-SHC-121002: (header) enrich(iss=%s, acq=%s),(txnSrc=%s, txnDest=%s)\n",
					header->msg.issuer, header->msg.acquirer,
					header->msg.txnSrc, header->msg.txnDest);
		}
				header->msg.msgtype = save_msgtype;
		break;

	case	shcServiceRouteIssuer:
	case	shcServiceRouteAcquirer:
	case	shcServiceManageToIssuer:
	case	shcServiceManageToAcquirer:
	case	shcServiceRouteToOnUsIssuer:
		/*	Perform a setup to get all required pointers */
		save_msgtype = header->msg.msgtype;
		header->msg.msgtype = SHC_FINREQ_RESPONSE;	/*	to allow startup */
		
		//ShcmsgBaseTxn::enrich();	//		shc_initialise_transaction(header);
		if (!header->createdInternal())
		{
			thisShcApp->shcmsgTxnHelperObj->setDefaultKeyLen(header);
			thisShcApp->shcmsgTxnHelperObj->setOriginator(header);
			thisShcApp->shcmsgHelperObj->shc_normalizepan(header->msg.pan);
	
			if (!(header->issBinValid()) || !(header->acqBinValid()))	//	---	R022100
			{
				header->setReturnFlag(header->msg.respcode);
				return -1;
			}
	
//			thisShcApp->shcmsgTxnHelperObj->setParamSet(header);
			thisShcApp->shcmsgTxnHelperObj->setProcessorBusDay(header);
			thisShcApp->shcmsgTxnHelperObj->setCapDate(header);
			thisShcApp->shcmsgHelperObj->shc_get_pin_data(header);
			thisShcApp->shcmsgTxnHelperObj->setCurrencyCode(header);
			thisShcApp->shcmsgTxnHelperObj->initFromDevice(header);
			thisShcApp->shcmsgTxnHelperObj->setAcqCountry(header);
			thisShcApp->shcmsgTxnHelperObj->decideTimeOutValue(header);
			thisShcApp->shcmsgTxnHelperObj->setOnlineActivity(header);
			OTraceInfo("I-SHC-121003: (header) enrich(iss=%s, acq=%s),(txnSrc=%s, txnDest=%s)\n",
					header->msg.issuer, header->msg.acquirer,
					header->msg.txnSrc, header->msg.txnDest);
		}
		header->msg.msgtype = save_msgtype;
		break;

	case	shcServiceMarkCardStatus:
		/*	Perform a setup to get all required pointers */
		save_msgtype = header->msg.msgtype;
		header->msg.msgtype = SHC_FINREQ_RESPONSE;	/*	to allow startup */
		//ShcmsgBaseTxn::enrich();	//		shc_initialise_transaction(header);
		if (!header->createdInternal())
		{
			thisShcApp->shcmsgTxnHelperObj->setDefaultKeyLen(header);
			thisShcApp->shcmsgTxnHelperObj->setOriginator(header);
			thisShcApp->shcmsgHelperObj->shc_normalizepan(header->msg.pan);
	
			if (!(header->issBinValid()) || !(header->acqBinValid()))	//	---	R022100
			{
				header->setReturnFlag(header->msg.respcode);
				return -1;
			}
	
//			thisShcApp->shcmsgTxnHelperObj->setParamSet(header);
			thisShcApp->shcmsgTxnHelperObj->setProcessorBusDay(header);
			thisShcApp->shcmsgTxnHelperObj->setCapDate(header);
			thisShcApp->shcmsgHelperObj->shc_get_pin_data(header);
			thisShcApp->shcmsgTxnHelperObj->setCurrencyCode(header);
			thisShcApp->shcmsgTxnHelperObj->initFromDevice(header);
			thisShcApp->shcmsgTxnHelperObj->setAcqCountry(header);
			thisShcApp->shcmsgTxnHelperObj->decideTimeOutValue(header);
			thisShcApp->shcmsgTxnHelperObj->setOnlineActivity(header);
			OTraceInfo("I-SHC-121004: (header) enrich(iss=%s, acq=%s),(txnSrc=%s, txnDest=%s)\n",
					header->msg.issuer, header->msg.acquirer,
					header->msg.txnSrc, header->msg.txnDest);
		}

		header->msg.msgtype = save_msgtype;
		break;
	}
	
	return 0;
}


int ShcServiceReq::doWork()
{
	struct	ShcWithSegment omsg = { 0 };	/* R006700 */
	struct	shclogmatch shclogmatch = { 0 };	/* R006700 */
	int		save_msgtype;
	char	tmpbuf[100];
	int		evid;
	char	*ss;

	int retValue = 0;
	int pincapcode = 0;

	switch(header->msg.netcode)
	{
	case	shcServiceReadRecord:

		/*	Read the record from the data base and return */
		if(((ShcLog *)header->shcLogObj)->locateTxn(header, &(omsg.shc.msg), NULL) < 0)
			header->msg.respcode = SHC_RC_NoRecordFound;
		else
		{
			(omsg.shc).msg.senderid = header->msg.senderid;
			memcpy((char *)&header->msg,(char *)&(omsg.shc).msg, sizeof(struct shcmsg));
			memcpy((char *)&header->segment,(char *)&(omsg.segmentData), sizeof(header->segment));
		}
		((ShcLog *)header->shcLogObj)->rewind();
		
		header->shcerr = SH_RETURN;
		break;
	
	case	shcServiceGetRoute:
		if(header->setIssShcBin(header->msg.issuer) == -1)
			header->msg.respcode = SHC_RC_NoRecordFound;
		else
		{
			header->msg.serial_1 = header->issShcBin->binPkg->bin.mailbox;
		}

		header->shcerr = SH_RETURN;
		break;
	
	case	shcServiceReadRefnum:
		/*	Read by referance number and pan */
		if(((ShcLog*)header->shcLogObj)->locateTxnRefnum(header, &(omsg.shc.msg)) < 0)
			header->msg.respcode = SHC_RC_NoRecordFound;
		else
		{
			(omsg.shc).msg.senderid = header->msg.senderid;
			memcpy((char *)&header->msg,(char *)&(omsg.shc).msg, sizeof(struct shcmsg));
			memcpy((char *)&header->segment,(char *)&(omsg.segmentData), sizeof(header->segment));
		}
		((ShcLog *)header->shcLogObj)->rewind();	
		header->shcerr = SH_RETURN;
		break;

	case	shcServiceMatchShclog:

		/* Set up matching fields value */
		shclogmatch.pcode = header->msg.pcode; 
		dbm_deccopy(&shclogmatch.amount, &header->msg.amount);

		/* Call function to locate transaction base on matching values */ 
		if(((ShcLog*)header->shcLogObj)->locateTxnSeq(header, &(omsg.shc.msg), &shclogmatch) < 0)
			header->msg.respcode = SHC_RC_NoRecordFound;
		else
		{
			(omsg.shc).msg.senderid = header->msg.senderid;
			header->msg.respcode = SHC_RC_Approved;
			memcpy((char *)&header->msg,(char *)&(omsg.shc).msg, sizeof(struct shcmsg));
			memcpy((char *)&header->segment,(char *)&(omsg.segmentData), sizeof(header->segment));
		}
		((ShcLog *)header->shcLogObj)->rewind();
		header->shcerr = SH_RETURN;
		break;
	
	case	shcServiceInvalidPIN:
		/*	This service request is used to update the number of PIN
			retries. A response is generated which indicates if
			an Invalid PIN or a Number of PINS exceeded has occurred
		*/
//
//		/*	Perform a setup to get all required pointers */
//		save_msgtype = header->msg.msgtype;
//		header->msg.msgtype = SHC_FINREQ_RESPONSE;	/*	to allow startup */
//		shc_initialise_transaction(header);
//		header->msg.msgtype = save_msgtype;


		if(header->msg.pos_pin_cap_code > 0)
		{
			pincapcode = header->msg.pos_pin_cap_code - '0';
			OTraceDebug("D-SHC-121005:Pos_pin_cap_code is <%c><%d> \n",
						header->msg.pos_pin_cap_code,pincapcode);
		}

		retValue=shcPinTryCounterObj->getCnt(header,0);
		shcPinTryCounterObj->incCnt(header,pincapcode);
		if( retValue+1 >= abs(header->issShcBin->binPkg->txn.npintry))
			header->msg.respcode = SHC_RC_ExceedsPINRetry;
		else
			header->msg.respcode = SHC_RC_IncorrectPIN;
		

		header->shcerr = SH_RETURN;
		break;

	case	shcServiceRouteIssuer:
	case	shcServiceRouteAcquirer:
	case	shcServiceManageToIssuer:
	case	shcServiceManageToAcquirer:
	case	shcServiceRouteToOnUsIssuer:		/* 05jul93 */
//
//		/*	Perform a setup to get all required pointers */
//		save_msgtype = header->msg.msgtype;
//		header->msg.msgtype = SHC_FINREQ_RESPONSE;	/*	to allow startup */
//		shc_initialise_transaction(header);
//		header->msg.msgtype = save_msgtype;


		if(header->msg.netcode == shcServiceRouteIssuer
		   || header->msg.netcode == shcServiceManageToIssuer
		   || header->msg.netcode == shcServiceRouteToOnUsIssuer)
			header->shcerr = SH_SENDISS;
		else
			header->shcerr = SH_SENDACQ;
		

		if( header->msg.netcode == shcServiceRouteToOnUsIssuer
			&& !(header->issShcBin->binPkg->bin.bintype & SH_ONUS_BIN)
		  )
		{
			/*	Not an on us issuer.: Return with error */
			header->msg.respcode	= SHC_RC_NotOnUsIssuer;
			header->shcerr			= SH_RETURN;
			return(0);
		}

		if(header->msg.netcode == shcServiceManageToIssuer
		   || header->msg.netcode == shcServiceManageToAcquirer)
		{

			sprintf(tmpbuf, "%d|%d", header->msg.senderid, header->msg.unit);
			evid = tm_enqueue(shcmid, time(0) + 10, TM_NOTIFY_ONCE,
				header->msg.trace * 100, tmpbuf, sizeof(tmpbuf));
			if(evid < 0)
			{
				header->shcerr = SH_IGNORE;
				break;
			}

			tm_setflags(evid, TM_NOEXPIRE | TM_NOSAVE, 1);
		}
		
		break;

	case	shcServiceRespondToSender:
		evid = tm_locate_event(header->msg.trace * 100, (-1), shcmid, NULL);
		if(evid < 0)
		{
			header->shcerr = SH_IGNORE;
			break;
		}

		tm_getdata(evid, tmpbuf, sizeof(tmpbuf));
		tm_dequeue(evid);
		ss = strtok(tmpbuf, " \t\n|");
		header->msg.senderid = atoi(ss);
		ss = strtok(NULL, " \t\n|");
		header->msg.unit = atoi(ss);
		header->shcerr = SH_RETURN;
		break;

	case	shcServiceRouteToSender:	/* Added 29Apr92 */

		OTraceInfo("I-SHC-121005: ServiceRequest route to sender:%d\n",
			header->msg.senderid);
		header->shcerr = SH_RETURN;

		break;
	

	case	shcServiceMarkCardStatus:
//		/*	Perform a setup to get all required pointers */
//
//		save_msgtype = header->msg.msgtype;
//		header->msg.msgtype = SHC_FINREQ_RESPONSE;	/*	to allow startup */
//		shc_initialise_transaction(header);
//		header->msg.msgtype = save_msgtype;


		if(thisShcApp->shcmsgHelperObj->shc_getcard(&header->msg) < 0)
		{
			header->msg.respcode = SHC_RC_SystemError;
			header->shcerr = SH_RETURN;
			return(0);
		}

		//thisShcApp->shccard.status = header->msg.respcode;
		header->msg.respcode = SHC_RC_StatusChangeAccepted;
		thisShcApp->shcmsgHelperObj->shc_updatecard();
		header->shcLogObj->logTxn(header);
		if (header->createdInternal())
			header->shcerr = SH_IGNORE;
		else
			header->shcerr = SH_RETURN;
		break;
	
	/* 15jul95 */
	case	shcServiceUpdateRespcode:
		save_msgtype = header->msg.msgtype;
		header->msg.msgtype = header->msg.origmsg;
		((ShcLog*)header->shcLogObj)->updateRespcode(header);
		header->msg.msgtype = save_msgtype;

		header->shcerr = SH_IGNORE;
		break;
		
	/*  0001015 Start */
	case	 shcServiceProcessOn:
		if(header->setIssShcBin(header->msg.issuer) == -1)
		{
			OTraceError("E-SHC-121006: Failed to find bin for [%s]\n",  header->msg.issuer);
		}
		else
		{
			OTraceDebug("D-SHC-121007: Flags before: %08X\n", header->issShcBin->binPkg->bin.bintype);
			header->issShcBin->binPkg->bin.bintype &= ~(SH_FORWARD_MODE); 
			OTraceDebug("D-SHC-121008: Flags  after: %08X\n", header->issShcBin->binPkg->bin.bintype);
//			header->msg.msgtype = SHC_NETWORK;
//			strcpy(header->msg.acquirer, header->msg.issuer);
//			strcpy(header->msg.originator, shc_orgid);
//			cache_mb_write(header->issShcBin->binPkg->bin.mailbox,
//				shcmid, (char *)&header->msg, sizeof(struct shcmsg));
		}
		header->shcerr = SH_IGNORE;
		break;

	case	 shcServiceProcessOff:
		if(header->setIssShcBin (header->msg.issuer) == -1)
		{
			OTraceError("E-SHC-121009: Failed to find bin for [%s]\n",  header->msg.issuer);
		}
		else
		{
			OTraceDebug("D-SHC-121010: Flags before: %08X\n", header->issShcBin->binPkg->bin.bintype);
			header->issShcBin->binPkg->bin.bintype |= SH_FORWARD_MODE; 
			OTraceDebug("D-SHC-121011: Flags  after: %08X\n", header->issShcBin->binPkg->bin.bintype);

//			header->msg.msgtype = SHC_NETWORK;
//			strcpy(header->msg.acquirer, header->msg.issuer);
//			strcpy(header->msg.originator, shc_orgid);
//			cache_mb_write(header->issShcBin->binPkg->bin.mailbox,
//				shcmid, (char *)&header->msg, sizeof(struct shcmsg));
		}
		header->shcerr = SH_IGNORE;
		break;
	/*  0001015 End */
	default:
		header->msg.respcode = SHC_RC_InvalidServiceRequest;
		header->shcerr = SH_RETURN;
		OTraceError("E-SHC-121012: Unrecognized service code[%d]\n", header->msg.netcode );
		break;
	}

	return( 0 );
}
