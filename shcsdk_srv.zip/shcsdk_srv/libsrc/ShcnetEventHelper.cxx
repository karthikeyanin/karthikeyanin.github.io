static char _ShcnetEventHelper_cxx_what[] = "@(#) ShcnetEventHelper.cxx 1.5 17/03/17 02:28:08";

/*
 *  Copyright (C) 2004 eFunds Corporation ("eFunds").  All Rights Reserved.     
 *  eFunds Canada Corporation is an authorized user.                            
 *                                                                              
 *  IST is a registered trademark of eFunds Corporation.  Other brand or        
 *  product names are trademarks or registered trademarks of their respective   
 *  holders.                                                                    
 *                                                                              
 *  The information contained herein is the unpublished proprietary property    
 *  of eFunds.  Except as specifically authorized in writing by eFunds, the     
 *  holder of this document shall: i) keep all information contained herein     
 *  confidential, and ii) protect the information, in whole or in part, from    
 *  disclosure and dissemination to all third parties.                          
 *                                                                          
 *  This document and the software described in it are furnished under license  
 *  and may be used or copied only in accordance with the terms of such license.
 *  This document is supplied for information purposes only, is subject to      
 *  change without notice, and should not be construed as a commitment by       
 *  either eFunds Corporation or eFunds Canada Corporation. 
 *
 *
 *                        MODIFICATION HISTORY                  REVIEW
 *
 *	SPR#	Who	Date	Description			Who	Date   
 * ===========================================================================
 *R00xxxx ztang 05Jan03	Creation
 */
/* File Number 147 */

#include <stdio.h>
#include <string.h>
#include <ctype.h>
#include <oasis.h>
#include <ist_otrace.h>
#include <shc.h>
#include <shcmsgdef.h>
#include <CShcLog.h>
#include <ShcSdkCommon.h>
#include <BusinessDay.h>
#include <ShcmsgHelper.h>
#include <ShcnetEventHelper.h>
#include <ShcNetworkMsgHelper.h>
#include <ShcApp.h>
#include <TxnStat.h>
#include <mb_umi.h>
#include <ShcmsgTxnHelper.h>

int ShcnetEventHelper::processKeyExchangeResp(ShcmsgHeader *header)
{
    switch( header->msg.netcode )
    {
        case    SHC_NET_KEYS:
        case    SHC_NET_KEYS_START:
		case    SHC_NET_KEYS_START_2LEG:
            header->msg.respcode = SHC_RC_IssuerTimeout; /*R002203*/
            thisShcApp->shcNetworkMsgHelperObj->shcnet_exchange_response(header, SH_KEYSTAT_INACTIVE);
            break;
    }

    return 0;
}

int ShcnetEventHelper::processSignonStart(ShcmsgHeader *header)
{
	if( (header->issShcBin->binPkg->bin.bintype & SH_KEYS_AS2805) )
	{
		ShcmsgHeader tmpHeader(*header);
		if( header->issShcBin )
		{
			strcpy(tmpHeader.msg.txnSrc, header->issShcBin->binPkg->bin.institutionid);
			if( !shc_isdown(header->issShcBin->binPkg) )
			{
				OTraceDebug("D-SHCNET-107300: bin is up, signon start is not required any more - dropped\n" );
				return 0;
			}
		}
		else
			tmpHeader.msg.txnSrc[0] = '\0';

		if( tmpHeader.msg.shift_number == 2 )
		{
			OTraceDebug("D-SHCNET-107300: signon timed out, %d times, send sign off\n", tmpHeader.msg.shift_number );
			tmpHeader.msg.msgtype = SHC_NETWORK;
			tmpHeader.msg.netcode = SHC_NET_SIGNOFF_START;
			tmpHeader.msg.shc_devcap = 0;
			if( tmpHeader.msg.shift_number < 1 || tmpHeader.msg.shift_number > 2 )
				tmpHeader.msg.shift_number = 1;
			else
				tmpHeader.msg.shift_number++;
			tmpHeader.msg.origtrace = header->msg.trace;
			tmpHeader.msg.origtrace = header->msg.trace;
			tmpHeader.msg.pan[0] = '\0';
			tmpHeader.msg.trace = thisShcApp->shcNetworkMsgHelperObj->shc_generate_uni_trace();
			mb_getUmi(tmpHeader.msg.shclog_id, sizeof(tmpHeader.msg.shclog_id));
			mb_set_tid(tmpHeader.msg.shclog_id, strlen(tmpHeader.msg.shclog_id));
			OTraceDebug("D-SHCNET-107301: timed out two way signon message, - created signoff message ID[%s] m%04d/n%d, devcap[%d]\n",
						tmpHeader.msg.shclog_id, tmpHeader.msg.msgtype, tmpHeader.msg.netcode, tmpHeader.msg.shc_devcap);
			TxnStatReport(tmpHeader.msg.shclog_id,TS_SHC,TSR_CREATE,tmpHeader.msg.msgtype,0,0);
			if ( thisShcApp->shcmsgTxnHelperObj->enqueueInternalMsg( &tmpHeader ) == NULL )
				OTraceError("E-SHCNET-107302: Unable to enqueue internal message, for timed out SHC_NET_SIGNOFF_START\n");

			return 0;
		}
	    tmpHeader.msg.msgtype = SHC_NETWORK;
	    tmpHeader.msg.netcode = SHC_NET_SIGNON_START;
        tmpHeader.msg.shc_devcap = 0;
		if( tmpHeader.msg.shift_number < 1 || tmpHeader.msg.shift_number > 2 )
			tmpHeader.msg.shift_number = 1;
		else
			tmpHeader.msg.shift_number++;
		tmpHeader.msg.origtrace = header->msg.trace;
	    tmpHeader.msg.origtrace = header->msg.trace;
		tmpHeader.msg.pan[0] = '\0';
	    tmpHeader.msg.trace = thisShcApp->shcNetworkMsgHelperObj->shc_generate_uni_trace();
		mb_getUmi(tmpHeader.msg.shclog_id, sizeof(tmpHeader.msg.shclog_id));
		mb_set_tid(tmpHeader.msg.shclog_id, strlen(tmpHeader.msg.shclog_id));
		OTraceDebug("D-SHCNET-107301: timed out two way signon message - created message ID[%s] m%04d/n%d, devcap[%d]\n",
					tmpHeader.msg.shclog_id, tmpHeader.msg.msgtype, tmpHeader.msg.netcode, tmpHeader.msg.shc_devcap);
		TxnStatReport(tmpHeader.msg.shclog_id,TS_SHC,TSR_CREATE,tmpHeader.msg.msgtype,0,0);
		if ( thisShcApp->shcmsgTxnHelperObj->enqueueInternalMsg( &tmpHeader ) == NULL )
			OTraceError("E-SHCNET-107302: Unable to enqueue internal message, for timed out SHC_NET_SIGNON_START\n");
	}

    return 0;

}









