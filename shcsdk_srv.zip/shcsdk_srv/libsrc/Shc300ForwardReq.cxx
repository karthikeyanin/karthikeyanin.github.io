static char _Shc300ForwardReq_cxx_what[] = "@(#) Shc300ForwardReq.cxx 1.2 18/05/18 10:36:51";

/*
 *  Copyright (C) 2004 eFunds Corporation ("eFunds").  All Rights Reserved.     
 *  eFunds Canada Corporation is an authorized user.                            
 *                                                                              
 *  IST is a registered trademark of eFunds Corporation.  Other brand or        
 *  product names are trademarks or registered trademarks of their respective   
 *  holders.                                                                    
 *                                                                              
 *  The information contained herein is the unpublished proprietary property    
 *  of eFunds.  Except as specifically authorized in writing by eFunds, the     
 *  holder of this document shall: i) keep all information contained herein     
 *  confidential, and ii) protect the information, in whole or in part, from    
 *  disclosure and dissemination to all third parties.                          
 *                                                                          
 *  This document and the software described in it are furnished under license  
 *  and may be used or copied only in accordance with the terms of such license.
 *  This document is supplied for information purposes only, is subject to      
 *  change without notice, and should not be construed as a commitment by       
 *  either eFunds Corporation or eFunds Canada Corporation. 
 *
 *
 *                        MODIFICATION HISTORY                  REVIEW
 *
 *	SPR#	Who	Date	Description			Who	Date   
 * ===========================================================================
 *R00xxxx ztang 16Jan03 Creation
 *R028104 Dipa  29Apr10 routingInfo - fix
 *R028271 Dipa  18Jun10 Txn Statistics
 *R030381 Dipa  02Mar12 Txn Statistics
 */
/* File Number 150 */

#include <stdio.h>
#include <string.h>
#include <ctype.h>
#include <oasis.h>
#include <mb.h>
#include <ist_otrace.h>
#include <shc.h>
#include <shcdef.h>
#include <CShcLog.h>
#include <ShcmsgForwardReq.h>
#include <ShcMacHelper.h>
#include <ShcFinAuthHelper.h>
#include <ShcmsgHelper.h>
#include <ShcCamHelper.h>
#include <ShcmsgProcessor.h>
#include <ShcApp.h>
#include <ShcRetHelper.h>
#include <ShcMsgCache.h>
#include <ShcTimerHelper.h>

#include <ist_seg_name.h> //R027876
#include <ist_seg_elf_id_map.h> //R027876
#include <ist_seg_id.h> //R027876

//R028271 >>>
#include <TxnStat.h>
//<<< R028271

#include <Shc300ForwardReq.h>

int Shc300ForwardReq::enrich()
{
	processingDoneOnOtherNode = 1;
	return 0;
}


int Shc300ForwardReq::edit()
{
	return(0);
}

	
int Shc300ForwardReq::doWork()
{
	
	ShcmsgHeader *thisHeader = (ShcmsgHeader *)header;

	// R028104 >>>
	struct RoutingInfo routingInfo = {0};
	int len = sizeof(struct RoutingInfo);
	thisHeader->getSegmentData((char *)&routingInfo, &len, NETWORK_DATA_REQ_id ,ROUTING_INFO);
	// <<< R028104

	if (len) 
	{
		int outbound = mb_locateoutbound(routingInfo.mailbox);
		if (outbound >= 0)
		{
			thisHeader->time_out = routingInfo.time_out;
			thisShcApp->shcTimerObj->shc_time_message_x( thisHeader, (unsigned char *)thisHeader->segment );
			int totallen = thisHeader->truelength();
			if (cache_mb_write(outbound, shcmid, (char *)&thisHeader->msg, totallen)<0)
			{
				OTraceLog("L-SHC-17203: Failed to send msg ID[%s] /m%04d/t%d/p%06d to %s\n",
					thisHeader->msg.shclog_id, thisHeader->msg.msgtype, thisHeader->msg.trace,
					thisHeader->msg.pcode, mbMailBoxName(outbound));
			}
			else
				OTraceLog("L-SHC-17204: Sent msg ID[%s] /m%04d/t%d/p%06d to %s\n",
					thisHeader->msg.shclog_id, thisHeader->msg.msgtype, thisHeader->msg.trace,
					thisHeader->msg.pcode, mbMailBoxName(outbound));
	
			shcApp->shcmsgHelperObj->shc_dispmsg_x(&thisHeader->msg, 1, outbound);
			OTraceDebug("D-SHC-17205:The forward message is sent to[%s]\n", mbMailBoxName(outbound));
		}
		else
		{
			OTraceError("E-SHC-17206:Can't find mailbox[%s], message dropped\n", routingInfo.mailbox);
			//R028271 >>>
			TxnStatReport(thisHeader->msg.shclog_id,TS_SHC,TSR_DROP,DROP_MAILBOX_NOT_FOUND,0,0);
			//<<< R028271

		}	
	}
	else
	{
		OTraceError("E-SHC-17207:Can't find NETWORK_DATA_REQ:ROUTING_INFO segment\n");
	}	
	header->shcerr = SH_IGNORE;
	return 0;
}
