
static char _ShcRevReqHelper_cxx_what[] = "@(#) ShcRevReqHelper.cxx 1.28.19.9 19/12/05 08:14:23";
/*
 *  Copyright (C) 2004 eFunds Corporation ("eFunds").  All Rights Reserved.     
 *  eFunds Canada Corporation is an authorized user.                            
 *                                                                              
 *  IST is a registered trademark of eFunds Corporation.  Other brand or        
 *  product names are trademarks or registered trademarks of their respective   
 *  holders.                                                                    
 *                                                                              
 *  The information contained herein is the unpublished proprietary property    
 *  of eFunds.  Except as specifically authorized in writing by eFunds, the     
 *  holder of this document shall: i) keep all information contained herein     
 *  confidential, and ii) protect the information, in whole or in part, from    
 *  disclosure and dissemination to all third parties.                          
 *                                                                          
 *  This document and the software described in it are furnished under license  
 *  and may be used or copied only in accordance with the terms of such license.
 *  This document is supplied for information purposes only, is subject to      
 *  change without notice, and should not be construed as a commitment by       
 *  either eFunds Corporation or eFunds Canada Corporation. 
 *
 *
 *                        MODIFICATION HISTORY                  REVIEW
 *
 * SCR#     Who    Date  Description
 * ===========================================================================
 * R0xxxxx jyang  01Dec03 Created
 *R011629 Emj   12Aug04 SAF Interleave merged R011312
 * R017392  rzhou  11Aug06 Only return the segments has restore flag in revresp
 * R021024	bby	27Aug07	PAN/CVV/CVV2/Track2 Masking 
 * R021068 Ash 30Aug07 Avoid SHC Restart When Reversal for  Partial Dispense is send
 * R023310 Ram 27May08 SDK header should refer external header
 * R026142 vmp	06Mar09	eventId '0' is valid
 * R027876 dipa 02Mar10 Segment changes 
 * R027905 dipa 25Mar10 Reversal-Void Enhancement
 * R028031 dipa 08Apr10 Clone of R028009
 * R028485 dipa 26Aug10 Clone of R028483 - Allow reversals to issuer for MC Cash back txns with purchase amount only respcode
 * R028735 dipa 24Nov10 Modify the logic for sending to LRS(R027905)
 * R028860 dipa 03Jan11 Reversal of SHC-approved-refund txn should be replied back by SHC + cleanup of reversal logic in routeReversal()
 * R029391 Emj  11May11 Send reversal to issuer if original message to issuer timedout 
 * R030099 dipa	09Nov11	Clone of R028110 - Send reversal to posauth if org msg was sent to posauth
 * R030207 dipa	23Feb12	Clone of R030319 - Reversal of SHC-approved txn(not refund) should be SAFed and replied back to acquirer
 * R030476 dipa	16Apr12	Clone of R030474 - Check for issuer-timedout-reversal if org msg is marked as reversed
 * R030556 dipa	20May12	Clone of R029239 - segment restoration
 * R031305 dipa 25Feb13 Clone of R030474 - Check for shc.rev_update_on_reversal_respnse before updating org txn
 * IST_S761SP9-77	dipa	09Feb15	Reversal of SHC-approved-refund txns should not be sent to issuer
 */

//File Number 117

#include <ShcRevReqHelper.h>
#include <ShcApp.h>
#include <ShcBin.h>
#include <ShcSaf.h>
#include <tm.h>
#include <ShcTimerHelper.h>
#include <ShcHelper.h>	//	---	R023310
#include <ShcmsgHelper.h>
#include <CShcLog.h>
#include <ist_seg_name.h> //R027876
#include <ist_seg_elf_id_map.h> //R027876
#include <ist_seg_id.h> //R027876
#include <ShcLateRespHelper.h>	//R027905
#include <ShcRevMRHelper.h>

#include <HaPtmCctHelper.h>

int gOmsgIsSaf = 0;
int resp_code = -1;
int respCodeBeforeUpdate = -1; //R028860


/*****************************************************************************/

int ShcRevReqHelper::setReqEmvFlag(ShcmsgHeader *header)
{
	/* Ssc 28Jun00	R004671 integration to 7.2 */
	/* Rpc 01Apr00 2007336 VSDC -- set chip_type for Early/Full Issuer */
	int len;
	short chip_type;

	if (header->getSegList()->exists(EMV_BUF_id))
	{
	    if (header->issShcBin->isFullEntry())
	    	chip_type = SHC_CHIP_TYPE_FULL;
	    else
	        chip_type = SHC_CHIP_TYPE_EARLY;

        header->setSegmentData((char *)&chip_type, sizeof(chip_type), EMV_BUF_id, EMV_CHIP_TYPE);
	}
	/* Ssc end 2007336 */
	
	return 0;
}

/*****************************************************************************/

int ShcRevReqHelper::returnReqAcqFirst(ShcmsgHeader *header, int omsg_is_saf)
{
	int	 save_msgtype = header->msg.msgtype;
	int  save_respcode = header->msg.respcode;						/* 10002241 */

	resp_code = -1;
	/* Now return a reply to the acquirer */
	if(!(header->shcerr & SH_NOROUTE))
	{
		if( (getReqReturnAcqFlag(header, omsg_is_saf) ||!(header->issShcBin->binPkg->bin.flags & SH_GETAPP_HOST))
			&& ! (shcIsIBFTD(header)) )							/* 10002273 */
		{
			OTraceDebug("D-SHC-117001: Respond to Acquirer before to issuer\n" );
			
			save_msgtype = header->msg.msgtype;
			if( ! (header->issShcBin->binPkg->bin.flags & SH_GETAPP_HOST) )
			{
				if( header->msg.respcode == SHC_RC_PartialDispense )
					header->msg.revcode = SHC_RR_PartialDispense;
				/* R006640 >> */
				/* header->msg.respcode = SHC_RC_Approved;	*/		/* 10002241 */
				if( (header->msg.respcode != SHC_RC_DuplicateReversal &&
					header->msg.respcode != SHC_RC_NoOriginal &&
					header->msg.respcode != SHC_RC_IssuerDown) ||
					(shcIsPreAuthReq(header) && !shcmsgHeaderPreauthReversalAllowed(header)) )
						header->msg.respcode = SHC_RC_Approved;
				/* R006640 << */
			}

			/* 09mar95
			*	If I have to return to acq. I should update db to
			*	mark the 400 to 410 indicating I replyed to message
			*/

			if(!shcIsReversal(header))
				header->msg.msgtype = SHC_REVREQ;

			resetOriginalBuffer();
			memcpy((char *)&tmpOrigmsg.msg, (char *)&header->msg, sizeof(struct shcmsg));
			memcpy((char *)&tmpOrigmsg.segmentData, (char *)&header->segment, sizeof(tmpOrigmsg.segmentData));

			returnReversal(header, &tmpOrigmsg.msg);
				
			/*
			 * R001835
			 */
			if(shcIsRevAdvice(header) && header->issShcBin->isInterac() ||
			   shcIsRevIssReq(header) && header->acqShcBin->isInterac())
			{
				header->msg.respcode = SHC_RC_Approved;
			}

			thisShcApp->shcmsgHelperObj->shc_route(header);
			resp_code = header->msg.respcode;
				
			memcpy((char *)&header->msg, (char *)&tmpOrigmsg.msg, sizeof(struct shcmsg));
			memcpy((char *)&header->segment, (char *)&tmpOrigmsg.segmentData, sizeof(header->segment));
			header->msg.shc_devcap |= SH_DEVCAP_SHC_MSG_REPLIED;
		}
	}	

	header->msg.respcode = save_respcode;						/* 10002241 */
	
	return 0;
}

/*****************************************************************************/

int ShcRevReqHelper::getReqReturnAcqFlag( ShcmsgHeader* header, int omsg_is_saf )
{
	int 	ret_to_acq = False;
	if(shc_isdown(header->issShcBin->binPkg) && !(header->issShcBin->binPkg->saf.type & SH_SAF_POSFILE) )
	{
		if(header->issShcBin->binPkg->bin.flags & SH_GETAPP_HOST)
			header->msg.respcode = SHC_RC_IssuerDown;
		ret_to_acq = True;
		return ret_to_acq;
	}
	
	if (  ( (header->msg.shcerror == SHC_IE_NoMatch) ||   /*1002864*/
		    (header->msg.respcode == SHC_RC_NoOriginal) ) /*1002864*/
			&& ((!shcApp->acquirerShcParamsList->GetBool((char *)"shc.sendIss_420NoOrig")
			&& (!shcApp->acquirerShcParamsList->GetBool((char *)"shc.holdRevNoOriginal")))
				||shcIsIBFT(header)) )  // R011202
	{
		ret_to_acq = True;                                /*1002864*/
	}
	
	/*R002930*/
	if((header->acqShcBin->isInterac()) && (header->msg.msgtype == SHC_REVREQ_ADVICE))
		ret_to_acq = True;

	if((header->issShcBin->isInterac()) && (header->msg.msgtype == SHC_CHARGE_BACK_ADVICE))
		ret_to_acq = True;

    /* R008058 If orginal SAFed then respond to acquirer and SAF reversal */
	/* R008353 If orginal SAFed by PosAuth then send to PosAuth */
	if (omsg_is_saf && !(header->issShcBin->binPkg->saf.type & SH_SAF_POSFILE))
	{
		ret_to_acq = True;
		header->msg.respcode = SHC_RC_Approved;
	}

	if (!header->origMsg && shcApp->acquirerShcParamsList->GetBool((char *)"shc.holdRevNoOriginal") 
		&& !shcApp->acquirerShcParamsList->GetBool((char *)"shc.sendIss_420NoOrig")
		&& mbIsDualSite())
	{
		ret_to_acq = True;
	}
	
	return ret_to_acq;
}		

/*****************************************************************************/

int ShcRevReqHelper::returnReversal(ShcmsgHeader *header)
{
	resetOriginalBuffer();
	memcpy((char *)&tmpOrigmsg.msg, (char *)&header->msg, sizeof(struct shcmsg));
	memcpy((char *)&tmpOrigmsg.segmentData, (char *)&header->segment, sizeof(tmpOrigmsg.segmentData));

	return (returnReversal(header, &tmpOrigmsg.msg));
}

int ShcRevReqHelper::returnReversal(ShcmsgHeader *header, struct shcmsg * oshcmsg)
{
	/*
	 *	Setup all required fields to return a reversal
	 *	reply to the originator && Update the database.
	 */
	int		upddb;
	int 	isReq = 0;
	
	OTraceDebug("D-SHC-117003: Enter returnReversal()\n");

	upddb = ( (header->shcerr & SH_NOREVUPD) ? False : True);

	isReq = shcmsgIsRequest(&header->msg);
	
	if (isReq)
		setReqReturnDestMsgno(header);

	OTraceDebug("D-SHC-117004: header->shcerr:(%x) upddb:(%d) m%d/t%d/p:%s/lt:%ld/ld:%ld/tid:%s\n",
		header->shcerr, upddb, header->msg.msgtype, header->msg.trace,shcApp->shcHelperObj->shc_maskpan(header->msg.pan), 
		header->msg.local_time, header->msg.local_date, header->msg.termid);		//	---	R021024

	/*	Log the trasnaction */
	if(upddb)
	{
		static int shcLogDupRev = -1;
		if (shcLogDupRev < 0)
		{
			char        xbuf[256]= { 0 };
			shcLogDupRev = 1;
	
			if( cf_openfile("...") < 0 ) 
			{
				OTraceWarning("W-SHC-117030: Configuration file not present.\n");
			}
			else 
			{
				if (cf_locate("shc.logDupRev", xbuf) > 0
					&& strchr("Nn0", *xbuf) )
				{
					shcLogDupRev = 0;
		    	}	
				OTraceInfo("I-SHC-117031:shc.shcLogDupRev <%d>\n", shcLogDupRev);
				cf_close();
			}
		}

		if ((header->msg.shcerror == SHC_IE_Duplicate) && (!shcLogDupRev))
		{
			header->logFlag &= SHC_LOG_REQ|SHC_LOG_UPD_REQ;
			OTraceWarning("W-SHC-117032:Duplicate Reversal not logged.\n");
		}
		else
			header->logFlag |= SHC_LOG_REQ|SHC_LOG_UPD_REQ;	//Log resp asif req, because req not logged yet

		OTraceDebug("D-SHC-117006: Setting flag for logging reversal reply\n");
	}

		// <<<IST_S770SP12-185<<<
		// Update the Original message
		if ((header->msg.respcode == SHC_RC_Approved) || (header->msg.respcode == SHC_RC_PartialDispense))
		{	
			updateOriginal(header);				
		}
		// <<<IST_S770SP12-185<<<

	if (isReq)
	{
		OTraceDebug("D-SHC-117024: Remove segments from turnaround reversal request\n");
		header->msg.device_cap &= ~SH_DEVCAP_USER_SEGMENT;
	}
	if (oshcmsg != NULL)
	{
		// R027876 >>>
		char buf[5];
		int segLen=0;
		memset(buf, 0x00, sizeof(buf));
		header->getSegmentData(buf, &segLen, ElfIdMap::elf_to_id(IST_SEG_NETWORK_SETTLEMENT_DATA), ORIG_MSG_TYPE);

		if ((segLen>0) && buf)
		{
			header->msg.origmsg = atoi(buf);
			OTraceDebug("D-SHC-117025:Restore origmsg to %d\n", header->msg.origmsg);
		}
		// <<< R027876
		if (header->getReqSegList())
			header->getSegList()->restore(header->getReqSegList());
	}

	
	OTraceDebug("D-SHC-117007: Leave returnReversal()\n");

	return(0);
}

/*****************************************************************************/
//Update the orignal message in header to prepare the log record

int ShcRevReqHelper::updateOriginal(ShcmsgHeader *header)
{
	static int  update_on_revresp = -1; //R031305

	if( !header->origMsg )
	{
		OTraceWarning("D-SHC-117008: The original message is empty\n");
		return False;
	}

	//R031305 >>>
	if (update_on_revresp == -1)
	{
		char        xbuf[256];
		update_on_revresp = 0;

		if( cf_openfile("...") < 0 ) 
		{
			OTraceWarning("W-SHC-117026: Configuration file not present.\n");
		}
		else 
		{
			if (cf_locate("shc.rev_update_on_reversal_response", xbuf) > 0
				&& strchr("Yy1", *xbuf) )
			{
				update_on_revresp = 1;
			}	
			OTraceInfo("I-SHC-117027:shc.rev_update_on_reversal_response <%d>\n", update_on_revresp);
			if (cf_locate("shc.rev_change_aval_bal", xbuf) > 0
				&& strchr("Nn0", *xbuf) )
			{
				shcRevChangeAvalBal = 0;
			}	
			OTraceInfo("I-SHC-117029:shc.shc.rev_change_aval_bal <%d>\n", shcRevChangeAvalBal);
			cf_close();
		}
	}

	if( shcIsRequest(header))
	{
		if ( update_on_revresp )
		{
			OTraceDebug("D-SHC-117009.1: Do not update original txn now \n");
			header->logFlag |= SHC_LOG_REQ;
			return 1;
		}
	}
	//R031305 <<<
	if(shcmsgIsResponse(&header->msg) && (header->msg.respcode != SHC_RC_Approved))
		header->origMsg->shcerror = 0;
	else
		header->origMsg->shcerror = SHC_IE_Reversed;

	header->origMsg->revcode  = header->msg.revcode;

	//R028860 - Save the original txn's respcode before update
	// This is needed for decision making in routeReversal()
	respCodeBeforeUpdate = header->origMsg->respcode;

	if ((shcIsRequest(header) && (update_on_revresp != 1)) || (shcIsResponse(header) && (update_on_revresp == 1)))
	{
		OTraceDebug("D-SHC-117016: Updating the Original Response Code either for Reversal Request or Response \n");
		if (thisShcApp->shcRevReqHelperObj->needUpdateRespcode())          /* R010275 */
		{
			header->origMsg->respcode = header->msg.respcode;
		}
	}

	if (shcRevChangeAvalBal)
		dbm_deccopy(&header->origMsg->aval_balance, &header->msg.aval_balance);
	/* 10001371 */
	dbm_deccopy(&header->origMsg->new_setl_amount, &header->msg.new_setl_amount);
	dbm_deccopy(&header->origMsg->new_amount, &header->msg.new_amount);
	dbm_deccopy(&header->origMsg->new_fee, &header->msg.new_fee);
	dbm_deccopy(&header->origMsg->ch_new_amount, &header->msg.ch_new_amount);	/* R007209 */
	dbm_deccopy(&header->origMsg->new_setl_fee, &header->msg.new_setl_fee);	/* R007209 */

	if(ist_otrace_get_level() >= OTRACE_DEBUG)
	{
		char	buf1[50];
		OTraceDebug("D-SHC-117010:  Update original transaction\n");	
		OTraceDebug("              shc error code       : %12d\n", header->msg.shcerror);
		OTraceDebug("              response code        : %12d\n", header->msg.respcode);
		dbm_dectochar(&header->msg.aval_balance, buf1);
		OTraceDebug("D-SHC-117011:   available balance    : %12s\n", buf1);
		dbm_dectochar(&header->msg.new_setl_amount, buf1);
		OTraceDebug("D-SHC-117012:   new settlement amount: %12s\n", buf1);
	}

	/* Ssc 28Jun00	R004671 integration to 7.2 */
	/* Ssc - 11Apr00    SPR # 2007336 */
    
    strcpy( ((ShcLog *)(header->shcLogObj))->shclog.chip_index, shcApp->omsg_chip_index );	/* R008003 */

	//  IS DUAL Site  MR  to  other site if original from  other site

	if (mbIsDualSite())
	{
		if (header->origMsg->site_id != mbGetSiteId())
		{
			ShcRevMRHelper::getInstance()->setSegmentRevOrig(header);
		}
	}


	/*
	 *	Now if Originaly EDC Then reverse the EDC Totals
	 */
	OTraceDebug("D-SHC-117013: shcIsEDC %d shcIsResponse %d msgtype %d trace %d\n", 
		shcIsEDC(header), shcIsResponse(header), header->msg.msgtype, header->msg.trace);

	/* 10002243 17May96 */
	if( shcIsEDC(header) && (header->msg.msgtype == SHC_REVREQ
	  || header->msg.msgtype == SHC_REVREQ_ADVICE) )
	{
		/*  10Apr96 */
		header->msg.pos_condition_code = header->origMsg->pos_condition_code;

		/* zm 02jun96 */
		header->msg.origpcode = header->origMsg->pcode;
		header->msg.origFlippedMsg = header->origMsg->flipped_msgtype;

		int oMsgtype = header->msg.msgtype;
//		shc_edc_reverse(header);
		header->msg.msgtype = oMsgtype;
	}
	
	header->logFlag |= SHC_LOG_UPD_ORIG;

	return(1);
}

/*****************************************************************************/

/*
 * R001835 Verify MAC for 420/422 from network 
 */
int ShcRevReqHelper::verifyReqRevMac( ShcmsgHeader *header )
{
	int ret = -1;
	if(shcIsRevIssReq(header))
	{
		if( shcIsVerifyMac(header->issShcBin->binPkg)
			&& (ret = header->issShcBin->shcmac_verify(header, SHC_ACQ_KEY)) < 0 )
				return( -1 );

				if (ret == SEC_ASYNCH_WAIT)
				return(ret);
	}
	else
	{
		if( shcIsVerifyMac(header->acqShcBin->binPkg)
			&& (ret = header->acqShcBin->shcmac_verify(header, SHC_ISS_KEY)) < 0 )
				return( -1 );

				if (ret == SEC_ASYNCH_WAIT)
				return(ret);

	}

	return ( 0 );
}

///*****************************************************************************/
//int ShcRevReqHelper::logReqMessage(ShcmsgHeader *header, int flag)
//{
//	if( flag )											/* 10002243 */
//		return ( shcLogObj->logTxn(header)<0 ? False : True );	/* 10002243 */
//	else
//		return False;
//}	

/*****************************************************************************/
int ShcRevReqHelper::setReqReturnDestMsgno(ShcmsgHeader *header)
{
	if (shc_internalrev(header))
		header->shcerr = SH_IGNORE | SH_RECON;
	else
	{
		struct shc_data *shc_data_ptr = (struct shc_data *)header->msg.shc_data_buffer;
		if (shc_isbitset(shc_data_ptr->device_cap,SHC_DATA_DEVICE_CAP_IS_AUTHCOMP))
			header->shcerr = SH_IGNORE;
		else
			header->shcerr = SH_RETURN;
	}
	thisShcApp->shcmsgHelperObj->shc_set_return_msgno(header);
	return 0;
}


/*****************************************************************************/
int ShcRevReqHelper::needReqReversal(ShcmsgHeader *header)
{
	OTraceDebug("D-SHC-117014:(%d)determine if a reversal is really required\n",__LINE__);

	static int  update_on_revresp = -1;
	
	/* 2. Determine if a reversal is really required */
	//	>>>		R021068
 	if( header->origMsg && ((header->origMsg->shcerror == SHC_IE_Reversed) ||
 		(	(shcmsgIsResponse(header->origMsg)) &&
			(header->origMsg->respcode != SHC_RC_Approved)	&& 
 			(header->origMsg->respcode != SHC_RC_DeviceTimeOut) &&
 			(header->origMsg->respcode != SHC_RC_IssuerTimeout) &&
	   		(header->origMsg->respcode != SHC_RC_ShcTimeout) &&
	   		(header->origMsg->respcode != SHC_RC_PurchaseAmountOnly) && //R028485
			( header->origMsg->respcode != SHC_RC_IssuerDown ) &&
			( header->origMsg->respcode != SHC_RC_PartialAmount )
	   	)
		)
	//	<<<		R021068
	  )
	{

		if (update_on_revresp == -1)
		{
			char xbuf[256];
			update_on_revresp = 0;

			if( cf_openfile("...") < 0 )
			{
				OTraceWarning("W-SHC-117026-1: Configuration file not present.\n");
			}
			else
			{
				if (cf_locate("shc.rev_update_on_reversal_response", xbuf) > 0
					&& strchr("Yy1", *xbuf) )
				{
					update_on_revresp = 1;
				}
				cf_close();
			}
		}

		if ( (header->origMsg->shcerror == SHC_IE_Reversed) && update_on_revresp && (header->msg.msgtype % 10 == 1))
		{
			OTraceDebug("D-SHC-117053: Transaction already reversed. So, this repeat reversal can be responded back. respcode[%d] revcode[%d] orig_shcerror[%d]\n",
				header->origMsg->respcode, header->msg.revcode ,
				header->origMsg->shcerror);
			header->msg.respcode = SHC_RC_Approved;
			returnReversal(header);
			return(False);
		}

		//R030476 >>>
		if ( (header->origMsg->shcerror == SHC_IE_Reversed) &&
	         (!header->reqMsg || header->reqMsg && ((header->reqMsg->respcode == SHC_RC_IssuerTimeout)||
								 (header->reqMsg->respcode == SHC_RC_ShcTimeout) ||
								 (header->reqMsg->respcode == SHC_RC_MACKeyError) ||
								 (header->reqMsg->respcode == SHC_RC_MACSyncError))) )
        {
	OTraceDebug("D-SHC-117115: Sending to issuer\n");
	     header->logFlag |= SHC_LOG_REQ;
            return True;
        }
		//R030476 <<<

		/*
		 *	Original did not approve. There is no reason to send reversal
		 *	to host Or already reversed
		 */
		OTraceDebug("D-SHC-117015:Reversal not needed. respcode[%d] revcode[%d] orig_shcerror[%d]\n", 
				header->origMsg->respcode, header->msg.revcode , 
				header->origMsg->shcerror);
		header->msg.respcode = SHC_RC_Approved;
		returnReversal(header);
		return(False);
	}

	/*	SPR2002016	*/
	/*	if the original transaction is rejected
		and ack from device is timed out for the reject message
		then no need to send reversal.	*/
	//	>>>		R021068		
	if ( header->origMsg && ((header->origMsg->respcode     != SHC_RC_Approved) &&
		 (header->msg.respcode  == SHC_RC_DeviceTimeOut) &&
		 (header->msg.revcode   == SHC_RR_HardwareError)  )   )
	//	<<<		R021068		 
	{
		OTraceInfo("I-SHC-117016:Ack timed out. Reversal not send as orig txn not OK\n");
	
		returnReversal(header);
		return(False);
	}

	if (  ( header->origMsg ) &&  
		  ( header->origMsg->respcode == SHC_RC_IssuerDown ) )
	{
		header->msg.respcode = header->origMsg->respcode;
		header->msg.revcode = header->origMsg->reason_code;
		OTraceInfo("I-SHC-117052:Issuer Down. Reversal not send as orig txn not OK\n");
		returnReversal( header );
		return( False );
	}
	
	return True;
}
	

/*****************************************************************************/
int ShcRevReqHelper::needReqUpdateLog(ShcmsgHeader *header)
{
	OTraceDebug("D-SHC-117017:(%d)determine routing of transaction\n",__LINE__);
	
	/* Determine routing of transaction */
	if(header->msg.device_cap & SH_DEVCAP_UPDATE_LOGS)
	{
		header->shcerr = SH_NOREVUPD;
		returnReversal(header);
		header->shcerr = SH_RETURN;		/* 18Feb94 */
		return( False );
	}
	return True;
}
	
/*****************************************************************************/

int ShcRevReqHelper::setReplayRoutingFlag(ShcmsgHeader *header)
{
	/* 13Jul93 */
	/* if issuer was down when reversal was issued for preauth */
	if(shcIsPreAuthReq(header) && !shcmsgHeaderPreauthReversalAllowed(header))
		header->shcerr = SH_IGNORE;
	else
	{
			header->shcerr = SH_SENDISS | SH_SETTIMER;
	}
	return 0;
}

/*****************************************************************************/

int ShcRevReqHelper::routeReversal(ShcmsgHeader *header, int omsg_is_saf)
{
	/* D E T E R M I N E    W H E R E   T O   S E N D   T R X N . */

	OTraceDebug("D-SHC-117018:route reversal\n");

	if (	mbIsDualSite() && 
			!shcApp->acquirerShcParamsList->GetBool((char *)"shc.sendIss_420NoOrig") &&
			(shcApp->acquirerShcParamsList->GetNum((char *)"shc.drop_420NoOrigCounter") > 0)
		)
	{
		if ( header->msg.respcode == SHC_RC_NoOriginal && !(header->msg.shc_devcap & SH_DEVCAP_SHC_EVENT) )
		{
			OTraceDebug( "D-SHC-17040 dual site handling - send to lateresprev\n");
			if(shcLateRespHelperObj)
				shcLateRespHelperObj->processRevNoOriginal(header);
			else
				OTraceError("E-SHC-073008:Unable to send this message to LateRespServer.\n");
			header->shcerr = SH_IGNORE;
			header->logFlag = SHC_LOG_REQ;
			return False;
		}
	}
	if (header->issShcBin->binPkg->bin.flags & SH_GETAPP_HOST)
    {
	// R028860 >>>
	// Reversals of all txns(including refund) follow the below logic:
	// 		1. If original txn is issuer-approved, send reversal to issuer.
	//		2. If original txn is an SHC-approved txn, send 410/r0 to acq
	//				- If its a normal reversal(not refund), SAF it.
	//		3. If original txn is in-flight, 
	//				- if LRS enabled, send reversal to LRS, and send 410/r0 to acq
	//				- if LRS disabled, 
	//					If "reversal to issuer" is "N", send 410/r0 to acq, then send 400 to issuer
	//					If "reversal to issuer" is "Y", send 400 to issuer.
	//		4. If original txn is timed-out, 
	//				- if LRS enabled, send reversal to LRS, and send 410/r0 to acq
	//				- if LRS disabled, send reversal to issuer
	//

	//IST_S761SP9-77 - Reversals of SHC-approved-refund txns should not be sent to issuer

	if (mbIsDualSite() && !shcApp->acquirerShcParamsList->GetBool((char *)"shc.sendIss_420NoOrig"))
	{
		OTraceDebug( "D-SHC-17039 dual site handling - respcode = %d, %s\n", header->msg.respcode,
		(header->msg.shc_devcap & SH_DEVCAP_SHC_EVENT)? "second pass" : "first pass" );
		if ( header->msg.respcode == SHC_RC_NoOriginal && !(header->msg.shc_devcap & SH_DEVCAP_SHC_EVENT) )
		{
			if ( createDualSiteRetryTimer(header)  )
			{
				header->shcerr = SH_IGNORE;
				return False;
			}
		}

		if (!header->origMsg 
			&& shcApp->acquirerShcParamsList->GetBool((char *)"shc.holdRevNoOriginal"))
		{
			OTraceDebug("D-SHC-17031:No original and Hold reversal configured in dual site.\n");
			if(shcLateRespHelperObj)
				shcLateRespHelperObj->processRevNoOriginal(header);
			else
				OTraceError("E-SHC-073008:Unable to send this message to LateRespServer.\n");
		}

	}

	//IST_S761SP9-77 - Reversals of SHC-approved-refund txns should not be sent to issuer
	if((header->origMsg && header->origMsg->msgtype % 20 == 10) && 			//if orig txn is replied
		shcIsRefund(header->msg.pcode) &&                                                                        //..and this is refund txn
		(header->issShcBin->binPkg->bin.bin_cfg & SH_CFG_ReturnRefund) )         //..and if refund txn was replied by SHC by issuer bin config
		{
			OTraceDebug("D-SHC-117018.0: Original refund txn approved by SHC...Reply reversal back to acquirer.\n");
			header->shcerr = SH_RETURN;
			header->msg.respcode = SHC_RC_Approved;
			returnReversal(header);
			return False;
		}
		else
		if ((header->origMsg && header->origMsg->msgtype % 20 == 10) && 			//if orig txn is replied
			respCodeBeforeUpdate == SHC_RC_Approved &&        	//...and SHC-approved
			omsg_is_saf) 	//...and SHC-approved
	{
		OTraceDebug("D-SHC-117018.1: Original txn was approved by SHC. Reply reversal back to acquirer.\n");

		int arqc_len=0;
		char Arqcbuf[2];
		memset (Arqcbuf, 0x00, sizeof(Arqcbuf));
		header->getSegmentData(Arqcbuf, &arqc_len, NETWORK_DATA_REQ_id, SKIP_ARQC_VERIFICATION);


		//R030319 >>>
		//if(!shcIsRefund(header->msg.pcode)) //Not a Refund Reversal
		if((!shcIsRefund(header->msg.pcode)) || (arqc_len != 0))
		{
			OTraceDebug("D-SHC-117018.1a: ... and SAF the txn\n");
			//Reverse the card limits
			if(omsg_is_saf)
				thisShcApp->shcSafHelperObj->shc_saf_rev(header);
			
			//...and write to SAF
			if (omsg_is_saf)
				gOmsgIsSaf = 1;
			thisShcApp->shcSafHelperObj->shc_saf(header);
			gOmsgIsSaf = 0;
		}
		//R030319 <<<
		//if the reversal will be sent to ist auth (in postive auth mode) then we can
		//ignore this message to avoid replying twice for this reversal request (R031599)
		if(header->issShcBin->binPkg->saf.type & SH_SAF_POSFILE)
		{
			if( shc_isdown(header->issShcBin->binPkg)
			|| (shcApp->saf_interleave&&shcIsReplay(header->issShcBin->binPkg,header->msg.iss_entityId))
			|| (gOmsgIsSaf) )
			{
				OTraceDebug("D-SHC-117028: Reversal ignored as this will be again replied by ISTAuth\n");
				header->shcerr = SH_IGNORE;
			}
		}
		else
		{
			header->shcerr = SH_RETURN;
			header->msg.respcode = SHC_RC_Approved;
			returnReversal(header);
		}
		return False;
	}
	}

	if (header->origMsg && ((header->origMsg->msgtype % 20 != 10)||  //if original msg is a request OR
		(header->origMsg->alpha_response_code[0] == '\0'))) //if original msg is an SHC timeout txn
	{
		if (header->origMsg->msgtype % 20 != 10) //The original msg is still in-flight
		{
			OTraceDebug("D-SHC-117018.2: Original request msg found. Update orig txn with SHC_RR_ReversedByAcquirer.\n");
			header->origMsg->revcode = SHC_RR_ReversedByAcquirer;
			header->origMsg->respcode = SHC_RC_IssuerTimeout;
			// USP-1562 -- uncomment
			header->origMsg->msgtype = thisShcApp->shcmsgHelperObj->shc_get_return_msgno(header->origMsg->msgtype);
		}

		// Send to LRS, if enabled.
		if( (header->issShcBin->binPkg->bin.bin_cfg & SH_REV_LATERESP) || 
			(shcApp->issuerShcParamsList->GetBool((char *)"shc.reversalOnLateResp")) )
		{
			OTraceDebug("D-SHC-117018.3: shc.reversalOnLateResp=Y - Sending to LRS\n");
			if(shcLateRespHelperObj)
				shcLateRespHelperObj->processTimeOutReversal(header);
			else
				OTraceError("E-SHC-073008:Unable to send this message to LateRespServer.\n");

			OTraceDebug("D-SHC-117018.4: Reply to Acquirer with respcode=0\n");
			header->shcerr = SH_RETURN;
			header->msg.respcode = SHC_RC_Approved;
			returnReversal(header);
			return False;
		}
		else
		{
			if (header->origMsg->revcode == SHC_RR_ReversedByAcquirer) //if org txn was in-flight
			{
				OTraceDebug("D-SHC-117018.5: Send reversal to issuer\n");
				//setNormalRoutingFlag(header);//Send to issuer
				//header->msg.respcode = SHC_RC_IssuerTimeout;
				//returnReversal(header);
				//return False;
			}
			else
			{
				OTraceDebug("D-SHC-117018.6: Send reversal to issuer\n");
			}
		}
	}
	// <<< R028860

	thisShcApp->shcRevReqHelperObj->returnReqAcqFirst(header, omsg_is_saf);
	
	/* Reverse transaction amount if the transaction was done in stfwd */
	if(omsg_is_saf)
		thisShcApp->shcSafHelperObj->shc_saf_rev(header);
	
	/*
	 *	The original did approve
	 *	We must now format the request to the host and
	 *	ask for a reversal
	 */
	/* 17aug93 */
	if(!shcIsReversal(header))
		header->msg.msgtype = SHC_REVREQ;

	if (  ( (header->msg.shcerror == SHC_IE_NoMatch) ||   /*1002864*/
		    (header->msg.respcode == SHC_RC_NoOriginal) ) /*1002864*/
		&& (!(shcApp->acquirerShcParamsList->GetBool((char *)"shc.sendIss_420NoOrig"))||shcIsIBFT(header)) )  // R011202
	{													  /*1002864*/
		OTraceInfo("I-SHC-117019:sendIss_420NoOrig is 0, rev with no orig not send to iss\n");
		header->shcerr = SH_IGNORE;						  /*1002864*/
	}													  /*1002864*/
	else if( ((resp_code == -1) || (resp_code == SHC_RC_Approved)) && ((shc_isdown(header->issShcBin->binPkg))|| //R030099
			(shcApp->saf_interleave&&shcIsReplay(header->issShcBin->binPkg,header->msg.iss_entityId)) || //--R011312--
			(shcIsRevIssReq(header) && header->acqShcBin->isInterac())||
			omsg_is_saf))
	{
		/*	Write the transaction to the store forward file */
		OTraceInfo("I-SHC-117020: Step into saf mode (rev)\n");
		if (omsg_is_saf)
			gOmsgIsSaf = 1;
		thisShcApp->shcSafHelperObj->shc_saf(header);
		gOmsgIsSaf = 0;
		header->shcerr = SH_IGNORE;				/* 10002113 */	/* 10001856 */
	}
	else if(shcIsPreAuthReq(header) && !shcmsgHeaderPreauthReversalAllowed(header))
	{
		if (!(header->issShcBin->binPkg->bin.flags & SH_GETAPP_HOST))
		{
			/* Already responded to acquirer in returnReqAcqFirst() */
			header->shcerr = SH_IGNORE;
		}
		else
		{
			header->msg.respcode = 0;
			thisShcApp->shcRevReqHelperObj->returnReversal(header);
		}
	}
	else
	{
		//	>>>	R028009
		if( shc_isdown(header->issShcBin->binPkg) && !(header->issShcBin->binPkg->saf.type & SH_SAF_POSFILE))
		{
			if(header->issShcBin->binPkg->bin.flags & SH_GETAPP_HOST)
			{
				header->shcerr = SH_IGNORE;	
				OTraceDebug("D-SHC-117050: Reversal to Issuer is Enabled but Issuer Bin is down \n");
				OTraceDebug("D-SHC-117051: Ignore this message \n");
				header->msg.respcode = SHC_RC_IssuerDown;
			}
		} 
		else
		{
			setNormalRoutingFlag(header);
		}
		//	<<<	R028009

		return True;
	}

////	/*
////     * Route the settlement transaction 
//// 	 */
//// empty function:	shc_route_settlement(header);

	return False;
}

int ShcRevReqHelper::setNormalRoutingFlag(ShcmsgHeader *header)
{
	struct shc_data *shc_data_ptr = (struct shc_data *)header->msg.shc_data_buffer;
	/*	Otherwise send a reversal request */
	header->shcerr = SH_SENDISS | SH_SETTIMER;

	return 0;
}

int ShcRevReqHelper::doReplay(ShcmsgHeader *header)
{
    /* If coming from replay task then we should just route it */
    if(! (header->msg.device_cap & SH_DEVCAP_FROM_REPLAY) )
        return False;

    OTraceDebug("D-SHC-117021:  Replay transaction\n");
	if (header->time_in >=10000000000)
    	header->time_out = header->time_in + 1000*shcApp->issuerShcParamsList->GetNum((char *)"shc.saf_timeout");
	else
    	header->time_out = header->time_in + shcApp->issuerShcParamsList->GetNum((char *)"shc.saf_timeout");

    setReplayRoutingFlag(header);

    return True;
}

/* R010275 >>>>> */
int ShcRevReqHelper::needUpdateRespcode(void)
{
	HaPtmCctHelper::addHandler( "system.dcs.shc" ) ;

	static int  updaterespcode = -1;

	if (updaterespcode == -1)
	{
		char        xbuf[256];
		updaterespcode = 1;

		//if( cf_open("istparam.cfg") < 0 )
		if( cf_openfile("...") < 0 )   /* R026731 */
		{
			OTraceWarning("W-SHC-117022: Configuration file not present.\n");
		}
		else if (cf_locate("shc.rev_update_respcode", xbuf) > 0
				&& strchr("Nn0", *xbuf) )
		{
			updaterespcode = 0;
	    }	
		
		OTraceInfo("I-SHC-117023:shc.rev_update_respcode <%d>\n", updaterespcode);

		cf_close();
	}

	return (updaterespcode);
}
/* <<<<< R010275 */

int ShcRevReqHelper::createDualSiteRetryTimer(ShcmsgHeader* header)
{
	int acq_timeout = header->acqShcBin->binPkg->bin.timeout;
	int max_time_to_respond = shcApp->acquirerShcParamsList->GetNum((char *)"shc.dualsite_max_time_to_respond");
	if ( max_time_to_respond <= 0 )
	max_time_to_respond = 5;
	int retry_timeout_value = acq_timeout - max_time_to_respond;
	if ( retry_timeout_value <= 0 )
		retry_timeout_value = acq_timeout - 5;
	OTraceInfo("I-SHC-117024 dual site original not found, retrying reversal in %d seconds\n", retry_timeout_value );

	header->msg.auth_devcap|= SH_DEVCAP_AUTH_DUALSITE_REV_EVENT;
	int eventId = tm_enqueue( shcmid, time(NULL) + retry_timeout_value, TM_NOTIFY_ONCE, 
	shcApp->shcmsgHelperObj->shcMakeKey(header), (char*)&header->msg, header->truelength() );
	if ( eventId < 0 )
	{
		OTraceInfo("I-SHC-117024 dual site original not found, unable to create event\n" );
		return 0;
	}

	return 1;
}

                           
