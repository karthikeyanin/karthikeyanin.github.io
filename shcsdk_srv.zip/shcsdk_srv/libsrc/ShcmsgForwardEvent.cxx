static char _ShcmsgForwardEvent_cxx_what[] = "@(#) ShcmsgForwardEvent.cxx 1.3 14/04/16 23:15:26";

/*
 *  Copyright (C) 2004 eFunds Corporation ("eFunds").  All Rights Reserved.     
 *  eFunds Canada Corporation is an authorized user.                            
 *                                                                              
 *  IST is a registered trademark of eFunds Corporation.  Other brand or        
 *  product names are trademarks or registered trademarks of their respective   
 *  holders.                                                                    
 *                                                                              
 *  The information contained herein is the unpublished proprietary property    
 *  of eFunds.  Except as specifically authorized in writing by eFunds, the     
 *  holder of this document shall: i) keep all information contained herein     
 *  confidential, and ii) protect the information, in whole or in part, from    
 *  disclosure and dissemination to all third parties.                          
 *                                                                          
 *  This document and the software described in it are furnished under license  
 *  and may be used or copied only in accordance with the terms of such license.
 *  This document is supplied for information purposes only, is subject to      
 *  change without notice, and should not be construed as a commitment by       
 *  either eFunds Corporation or eFunds Canada Corporation. 
 *
 *
 *                        MODIFICATION HISTORY                  REVIEW
 *
 *	SPR#	Who	Date	Description			Who	Date   
 * ===========================================================================
 *R00xxxx ztang 16Jan03 Creation
 *IST_S761_HIST-17	dipa	17Apr14	Clone of IST_S761_HIST-4[Wrong bin selected if IBFT times out (in multi node)]
 */
/* File Number 152 */

#include <stdio.h>
#include <string.h>
#include <ctype.h>
#include <oasis.h>
#include <ist_otrace.h>
#include <shc.h>
#include <shcdef.h>
#include <CShcLog.h>
#include <ShcmsgForwardEvent.h>
#include <ShcMacHelper.h>
#include <ShcFinAuthHelper.h>
#include <ShcmsgHelper.h>
#include <ShcCamHelper.h>
#include <ShcmsgProcessor.h>
#include <ShcApp.h>
#include <ShcRetHelper.h>
#include <TxnStat.h>
#include <ShcIBFTEvent.h>
#include <ShcIBFTHelper.h>
#include <ShcmsgEventHelper.h>

int ShcmsgForwardEvent::enrich()
{
	OTraceInfo("I-SHC-15202: Time out of message: %d trace %d event %d unit %d\n",
			header->msg.msgtype, header->msg.trace, 
			header->eventId, header->msg.unit);
						
	/*
	*	Remove the message from the event queue
	*/
	tm_dequeue(header->eventId);
	header->eventId = -1;

	if( shcIsIBFTD(header) )
		shcBin = header->transfereeShcBin;
	else
		shcBin = header->issShcBin;

	return 0;
}

	
int ShcmsgForwardEvent::doWork()
{
	OTraceDebug("D-SHC-15201:The forward time-out message is dropped\n");
	header->shcerr = SH_IGNORE;
	header->logFlag = 0;
	TxnStatReport(header->msg.shclog_id,TS_SHC,TSR_DROP,header->msg.msgtype,STATUS_BUSIMON,0);
	thisShcApp->shcmsgEventHelperObj->checkAndSetBinDown(header, shcBin);
	return 0;
}








