static char _ShcLogReqHelper_cxx_what[] = "@(#) ShcLogReqHelper.cxx 1.2 04/08/24 17:54:01";

/*
 *  Copyright (C) 2004 eFunds Corporation ("eFunds").  All Rights Reserved.     
 *  eFunds Canada Corporation is an authorized user.                            
 *                                                                              
 *  IST is a registered trademark of eFunds Corporation.  Other brand or        
 *  product names are trademarks or registered trademarks of their respective   
 *  holders.                                                                    
 *                                                                              
 *  The information contained herein is the unpublished proprietary property    
 *  of eFunds.  Except as specifically authorized in writing by eFunds, the     
 *  holder of this document shall: i) keep all information contained herein     
 *  confidential, and ii) protect the information, in whole or in part, from    
 *  disclosure and dissemination to all third parties.                          
 *                                                                          
 *  This document and the software described in it are furnished under license  
 *  and may be used or copied only in accordance with the terms of such license.
 *  This document is supplied for information purposes only, is subject to      
 *  change without notice, and should not be construed as a commitment by       
 *  either eFunds Corporation or eFunds Canada Corporation. 
 */
/*
 *
 *                        MODIFICATION HISTORY                  REVIEW
 *
 *	SPR#	Who	Date	Description			Who	Date   
 * ===========================================================================
 */

//File Number 89

#include <stdio.h>
#include <string.h>
#include <oasis.h>
#include <ist_otrace.h>
#include <mb.h>
#include <shc.h>
#define SHC_LogReq_SRC
#include "shc_util_funcs.h"
#include <ShcmsgHelper.h>
#include <ShcTimerHelper.h>
#include <ShcSaf.h>
#include <ShcRevReqHelper.h>
#include <ShcLogReqHelper.h>
#include <ShcApp.h>


int ShcLogReqHelper::setDefaultRespCode(ShcmsgHeader *header)
{
	if(header->msg.respcode == 0)
		header->msg.respcode = SHC_RC_UnableToProcess;
	return 0;
}






