static char _ShcIBFTEvent_cxx_what[] = "@(#) ShcIBFTEvent.cxx 1.6 07/01/16 17:01:40";

/*
 *  Copyright (C) 2004 eFunds Corporation ("eFunds").  All Rights Reserved.     
 *  eFunds Canada Corporation is an authorized user.                            
 *                                                                              
 *  IST is a registered trademark of eFunds Corporation.  Other brand or        
 *  product names are trademarks or registered trademarks of their respective   
 *  holders.                                                                    
 *                                                                              
 *  The information contained herein is the unpublished proprietary property    
 *  of eFunds.  Except as specifically authorized in writing by eFunds, the     
 *  holder of this document shall: i) keep all information contained herein     
 *  confidential, and ii) protect the information, in whole or in part, from    
 *  disclosure and dissemination to all third parties.                          
 *                                                                          
 *  This document and the software described in it are furnished under license  
 *  and may be used or copied only in accordance with the terms of such license.
 *  This document is supplied for information purposes only, is subject to      
 *  change without notice, and should not be construed as a commitment by       
 *  either eFunds Corporation or eFunds Canada Corporation. 
 *
 *
 *
 *                        MODIFICATION HISTORY                  REVIEW
 *
 *	SPR#	Who	Date	Description			Who	Date   
 * ===========================================================================
 * R0xxxxx jyang 09Dec03 Created
 * R018672 jyang 16Jan07 Restore pcode in the response message to acquirer
 */

//File Number 80

#include <ShcIBFTEvent.h>
#include <ShcRevReqHelper.h>
#include <ShcFinAuthHelper.h>
#include <ShcIBFTHelper.h>
#include <ShcApp.h>

int ShcIBFTEvent::enrich()
{
	OTraceInfo("I-SHC-080001: Time out of message: %d trace %d event %d unit %d\n",
		header->msg.msgtype, header->msg.trace, header->eventId, header->msg.unit);

	/*
 	 *	Remove the message from the event queue
 	 */
	tm_dequeue(header->eventId);
	header->eventId = -1;

	if( shcIsIBFTD(header) )	// R010133
		shcBin = header->transfereeShcBin;	// R010133
	else
		shcBin = header->issShcBin;

	return 0;
}

int ShcIBFTEvent::doWork()
{
	int save_device_cap = 0;
	int savedMsgtype = header->msg.msgtype;		// R011136
	
	switch(header->msg.msgtype){
	case	SHC_FINREQ:
	case	SHC_AUTHREQ:
		/* R004165 Move the code for R001319 to fix the bug for which */
		/*         messages are logged twice in shclog. */

		/* R001319 Mark the reversal as internal reversal */
		save_device_cap = header->msg.device_cap;
		header->msg.device_cap |= SH_DEVCAP_INTERNALREV;
//		shc_data_ptr = (struct shc_data *)header->msg.shc_data_buffer;
		/* End R001319 */

		/* End R004165 */
		
		header->msg.msgtype = SHC_REVREQ_ADVICE;
		header->msg.respcode = SHC_RC_IssuerTimeout;

		/* 961108 */
		header->msg.revcode = SHC_RR_TimeOut;

		if( shcIsIBFTD(header) )
		{ 
			/* Reverse transferee bank */
			header->msg.reason_code = SHC_RC_TransfereeDown;
			thisShcApp->shcIBFTHelperObj->shc_advice_IBFT(header, SH_DEVCAP_SHC_IBFTD);
		}
		else
		{
			/* 961108 */
			header->msg.reason_code = SHC_RC_IssuerDown;
			thisShcApp->shcIBFTHelperObj->shc_advice_IBFT(header, SH_DEVCAP_SHC_IBFTW );
		}

		/* R004165 Move the code for R001319 to fix the bug for which */
		/*         messages are logged twice in shclog. */

		/* R001319 Restore the original device_cap */
		header->msg.device_cap = save_device_cap;
		/* End R001319 */
		/* End R004165 */
		header->msg.msgtype = savedMsgtype;			// R011136

		/* Send response to acquirer */
		header->msg.pcode = header->msg.origpcode;	// R018672
		thisShcApp->shcFinAuthHelperObj->shc_return_finauth(header, -1);
		break;

	case	SHC_REVREQ:
		/* 10002273 */
		header->msg.pcode = header->msg.origpcode;
		header->msg.respcode = SHC_RC_IssuerTimeout;

		if( shcIsIBFTD(header) )
			header->msg.reason_code = SHC_RC_TransfereeDown;
		else
			header->msg.reason_code = SHC_RC_IssuerDown;

		thisShcApp->shcRevReqHelperObj->shc_return_reversal(header);
		break;
	
	}
	return 0;
}
