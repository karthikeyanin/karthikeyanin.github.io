static char _ShcRetShc300_cxx_what[] = "@(#) ShcRetShc300.cxx 1.0 03/10/17 10:49:14";

/*
 *  Copyright (C) 2004 eFunds Corporation ("eFunds").  All Rights Reserved.     
 *  eFunds Canada Corporation is an authorized user.                            
 *                                                                              
 *  IST is a registered trademark of eFunds Corporation.  Other brand or        
 *  product names are trademarks or registered trademarks of their respective   
 *  holders.                                                                    
 *                                                                              
 *  The information contained herein is the unpublished proprietary property    
 *  of eFunds.  Except as specifically authorized in writing by eFunds, the     
 *  holder of this document shall: i) keep all information contained herein     
 *  confidential, and ii) protect the information, in whole or in part, from    
 *  disclosure and dissemination to all third parties.                          
 *                                                                          
 *  This document and the software described in it are furnished under license  
 *  and may be used or copied only in accordance with the terms of such license.
 *  This document is supplied for information purposes only, is subject to      
 *  change without notice, and should not be construed as a commitment by       
 *  either eFunds Corporation or eFunds Canada Corporation. 
 *
 *
 *                        MODIFICATION HISTORY                  REVIEW
 *
 *	SPR#	Who	Date	Description			Who	Date   
 * ===========================================================================
 *R00xxxx shoba 03Oct17 Creation
 */
/* File Number 115 */

#include <stdio.h>
#include <string.h>
#include <ctype.h>
#include <oasis.h>
#include <ist_otrace.h>
#include <shc.h>
#include <shcdef.h>
#include <CShcLog.h>
#include <ShcRetShc300.h>
#include <ShcMacHelper.h>
#include <ShcFinAuthHelper.h>
#include <ShcmsgHelper.h>
#include <ShcCamHelper.h>
#include <ShcmsgProcessor.h>
#include <ShcApp.h>
#include <ShcRetHelper.h>


int ShcRetShc300::enrich()
{
	return 0;
}


int ShcRetShc300::edit()
{
	return(0);
}

	
int ShcRetShc300::doWork()
{
	header->logFlag = SHC_LOG_REQ;
	
	switch(header->msg.msgtype)
	{
			case	SHC_FILEUPD_ISSREQ:
			case	SHC_LOCAL_FILEUPD_ISSREQ:
			case	SHC_NEGATIVEFILE_ADVICE_MSG:
				header->shcerr = SH_RETURN;
				break;
			case	SHC_FILEUPD_ISSREQ_RESPONSE:
			case	SHC_LOCAL_FILEUPD_ISSREQ_RESPONSE:
			case	SHC_NEGATIVEFILE_ADVICE_RESP:
				header->shcerr = SH_RETURN;
				break;
			default:
			header->shcerr = SH_RETURN;
	}
	
	thisShcApp->shcmsgHelperObj->shc_set_return_msgno(header);
	
	return 0;
}








