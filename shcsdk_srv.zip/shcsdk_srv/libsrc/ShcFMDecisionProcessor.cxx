/*
 *  Copyright (C) 2004 eFunds Corporation ("eFunds").  All Rights Reserved.
 *  eFunds Canada Corporation is an authorized user.
 *
 *  IST is a registered trademark of eFunds Corporation.  Other brand or
 *  product names are trademarks or registered trademarks of their respective
 *  holders.
 *
 *  The information contained herein is the unpublished proprietary property
 *  of eFunds.  Except as specifically authorized in writing by eFunds, the
 *  holder of this document shall: i) keep all information contained herein
 *  confidential, and ii) protect the information, in whole or in part, from
 *  disclosure and dissemination to all third parties.
 *
 *  This document and the software described in it are furnished under license
 *  and may be used or copied only in accordance with the terms of such license.
 *  This document is supplied for information purposes only, is subject to
 *  change without notice, and should not be construed as a commitment by
 *  either eFunds Corporation or eFunds Canada Corporation.
 *
 *
 *                        MODIFICATION HISTORY                  REVIEW
 *
 * SCR#     Who    Date  Description
 * ===========================================================================
 * R020052  spa	 21May07 New file created
 * R020938	spa	 16Aug07 IST LM Bridge support
 * R021958	lee	 13Nov07 Added a segment for Timestamps
 * R022835	lee  03Apr08 Issues rectified while getting response from FM
 * R023105  sel  13May08 LM message routing between nodes
 * R023376  sel  29May08 Debug line with timestamp in milliseconds
 * R023394  sel  30May08 Debug line with timestamp in milliseconds-OTraceLog
 * ITM-1567 ram  09Jul08 Proper initialization of ShcmsgFMHelper object
 * R023871  ram  15Jul08 Support LM Trial Mode
 * R024019  sks	 23Jul08 Check the return value of tm_dequeue() in Event Processing
 * R026142  vmp	 06Mar09 eventId '0' is valid
 * R027876  dipa 02Mar10 Segment Changes      
 * R027876  dipa 22Apr10 Segment Changes - fix 
 * R028104  dipa 29Apr10 routingInfo - fix
 * R029287  dipa 15Apr11 WR33845 - New EMEA Rule Templates - store rule list and domain list in FN_DATA_SEGMENT, if available
 * R160740849 IS 19Jul17 To overcome warning messages in debug files by passing of the real buffer length instead of zero
 */

 /* File Number 154 */

static char _ShcFMDecisionProcessor_cxx_what[] = "@(#) ShcFMDecisionProcessor.cxx 1.16.2.6 16/12/02 06:45:58";

#include <mb_umi.h>
#include <ist_otrace.h>
#include <shc_callback.h>
#include <shc.h>
#include <shcdef.h>
#include <ShcmsgHelper.h>
#include <ShcTimerHelper.h>
#include <ShcmsgProcessor.h>
#include <ShcApp.h>
#include <ShcmsgTxnRegistration.h>
#include <ShcHelper.h>
#include <ShcmsgTxnHelper.h>
#include <ShcBin.h>
#include <CShcLog.h>
#include <ShcHeaderRegistration.h>
#include <ShcAppBase.h>
#include <ShcFMDecisionProcessor.h>
#include <ShcmsgFMHelper.h>
//  >>> R023105
#include <ShcmsgHeader.h>
#include <ShcMsgCache.h>
#include <BinRoute.h>
//  <<< R023105
#include <ist_seg_name.h> //R027876
#include <ist_seg_elf_id_map.h> //R027876
#include <ist_seg_id.h> //R027876
#include <ist_seg_pdt_base.h> //R027876
#include <algorithm>


//	>>>	R020938
int ShcFMDecisionProcessor::process()
{

//	struct FM_seg_data *fmData = NULL; //R027876
	IstSegPdtBase *fmData; //R027876
//	int fmDataLen;
	int tmstpLen;	//	---	R021958
	int flag = 0;

	ShcmsgFMHeader *thisHeader = (ShcmsgFMHeader *)header;

	struct ShcmsgWithSegment timerBuf;

	struct ShcmsgWithSegment shcmsgSeg = {0} ;
	struct shcmsg *oReqMsg = &(shcmsgSeg.msg);

	/*Copy from FMmsg to current msg */
	if((thisHeader->FMMsg.msgtype == SHC_LM_REVRESP) || (thisHeader->FMMsg.msgtype == SHC_LM_LATERESP))
		thisHeader->msg.msgtype = SHC_REVREQ_ADVICE_RESPONSE;//make istreplay happy
	else
		thisHeader->msg.msgtype = thisHeader->FMMsg.msgtype;
	thisHeader->msg.flipped_msgtype = thisHeader->FMMsg.flipped_msgtype;
	thisHeader->msg.trace = thisHeader->FMMsg.trace;
	thisHeader->msg.pcode = thisHeader->FMMsg.pcode;
	thisHeader->msg.pos_entry_code = thisHeader->FMMsg.pos_entry_code;
	strcpy(thisHeader->msg.pan, thisHeader->FMMsg.pan);
	strcpy(thisHeader->msg.acquirer, thisHeader->FMMsg.acquirer);
	strcpy(thisHeader->msg.issuer, thisHeader->FMMsg.issuer);
	strcpy(thisHeader->msg.transferee, thisHeader->FMMsg.transferee);
	thisHeader->msg.respcode = thisHeader->FMMsg.respcode; //there may be respcode mapping later
	//thisHeader->msg.origmsg = thisHeader->FMMsg.origmsg;
	strcpy(thisHeader->msg.txnSrc, thisHeader->FMMsg.txnSrc);
	strcpy(thisHeader->msg.txnDest, thisHeader->FMMsg.txnDest);

	dbm_deccopy(&thisHeader->msg.amount , &thisHeader->FMMsg.amount );
	dbm_deccopy(&thisHeader->msg.new_amount , &thisHeader->FMMsg.new_amount );
	//later copy all fields if needed

	thisShcApp->shcTimerObj->shc_locate_event_x((ShcmsgHeader *)header, oReqMsg, (unsigned char *)(oReqMsg+1));

	if(thisHeader->eventId >= 0)	//	---	R026142
	{
	//we shud also check orig msgtype match to avoid removing a wrong event
		if( (	(thisHeader->FMMsg.msgtype == SHC_LM_RESP) &&
	 			(oReqMsg->flipped_msgtype == thisHeader->FMMsg.flipped_msgtype)
			) ||
			(	(thisHeader->FMMsg.msgtype == SHC_LM_LATERESP) &&
				(oReqMsg->auth_devcap & SH_DEVCAP_AUTH_LMLateResp) &&
				(oReqMsg->flipped_msgtype == thisHeader->FMMsg.flipped_msgtype)
			) ||
			(	(thisHeader->FMMsg.msgtype == SHC_LM_REVRESP) &&
				(oReqMsg->auth_devcap & SH_DEVCAP_AUTH_LMForcePost) &&
				(oReqMsg->flipped_msgtype == thisHeader->FMMsg.flipped_msgtype)
			) ||
			(thisHeader->FMMsg.msgtype == SHC_FM_RESP)	//	---	R022835
	  	  )
		{
			flag = 1;
			//	>>>	R024019
			//tm_dequeue(thisHeader->eventId);	//  --- R022835
			if (tm_dequeue(header->eventId) < 0 )
			{
				OTraceDebug("D-SHC-154016:Event not removed properly from queue ,message dropped \n");
				header->shcerr = SH_IGNORE;
				header->setIgnoreFlag();
				return 0;
			}
			//	<<<	R024019
				
		}
	}

    //  >>> ITM-1567
    if(!shcmsgFMHelperObj)
        shcmsgFMHelperObj = new ShcmsgFMHelper;
    //  <<< ITM-1567

	/* Late response Start*/
	if((thisHeader->eventId < 0) || (!flag) )
	{
        	thisHeader->shcerr = SH_IGNORE;
	        thisHeader->logFlag = 0;

	        if(thisHeader->FMMsg.msgtype/100 == 84)
	        {
                //  >>> R023871
                if(isLMTrial())
                {
                    OTraceDebug("D-SHC-154015:LM is in TRIAL MODE ,Response ignored\n");
                    return (0);
                }
                //  <<< R023871

				OTraceDebug("D-SHC-154006:Late response from LM\n");
				shcmsgFMHelperObj->sendLateResponse(thisHeader, TO_LM);
			}
			else
			{
				OTraceDebug("D-SHC-154001:Late response from FM ignored\n");
			}

			return (-1);
       	 /* Late response end */
	}

	/* Normal Response start */

	//tm_dequeue(thisHeader->eventId);	//  --- R022835

	int totalLen=thisHeader->truelength(oReqMsg);
	memcpy(&thisHeader->msg, oReqMsg, min<long>(sizeof(struct shcmsg), totalLen));
	if (totalLen > sizeof(struct shcmsg)) //segments present
		memcpy(&thisHeader->segment, ((char *)oReqMsg)+sizeof(struct shcmsg), sizeof(thisHeader->segment));

	//	>>>	R023105
	ShcmsgHeader *Header = (ShcmsgHeader *)header;
	char buf[100];
	int l=0;

	// R027876, R028104 >>>
	struct RoutingInfo r = {0};
	l = sizeof(struct RoutingInfo);
	Header->getSegmentData((char *)&r, &l, NETWORK_DATA_REQ_id, ROUTING_INFO);
	// <<< R027876, R028104

	if (l)
	{
		if (r.flag & (ROUTE_INFO_FLAG_USE_FOR_REQ | ROUTE_INFO_FLAG_USE_BINROUTE) &&
			(strcmp(r.destNode, mbcurrentnode)==0) &&
			(strcmp(r.destNode, r.srcNode)!=0))
		{
			//The req msg is sent across the node, so just send it back.
			if (mcastHelperObj->ready())
			{
				int outbound = mcastHelperObj->getMbID();
				int totallen = 0;
				char *tmpp = mcastHelperObj->createBroadcastMsg(0, (char *)&thisHeader->FMMsg, sizeof(thisHeader->FMMsg), r.srcNode, &totallen, r.srcSiteId);
				if (mb_write(outbound, shcmid, tmpp, totallen) < 0)
				{
					OTraceLog("L-SHC-154013: Failed to send msg ID[%s] /m%04d/t%d/p%06d to %s\n",
					thisHeader->msg.shclog_id, thisHeader->msg.msgtype, thisHeader->msg.trace,
					thisHeader->msg.pcode, mbMailBoxName(outbound));
				}
				else
					OTraceLog("L-SHC-154014: Sent msg ID[%s] /m%04d/t%d/p%06d to %s\n",
				thisHeader->msg.shclog_id, thisHeader->msg.msgtype, thisHeader->msg.trace,
				thisHeader->msg.pcode, mbMailBoxName(outbound));
			}
			return 0;
		}
		r.flag = 0;    //Clear the flag in ROUTINGINFO segment
		Header->setSegmentData((char*)&r, sizeof(r), NETWORK_DATA_REQ_id, ROUTING_INFO); //R027876, R028104

	}
	//	<<<	R023105

	if(thisHeader->msg.msgtype == SHC_REVREQ_ADVICE)//original mti was 420 if replay
	{
		shcApp->shcmsgHelperObj->shc_set_return_msgno(&thisHeader->msg);
		thisHeader->msg.respcode = SHC_RC_Approved;
		thisHeader->shcerr = SH_RETURN;//return to istadvice response server
		shcmsgFMHelperObj->enqueueInternalMsg(thisHeader);

		return (0);
	}


	OTraceDebug("D-SHC-154002:FM msgtype [%d] flipped back to original msgtype[%d]\n",
		thisHeader->msg.msgtype, thisHeader->msg.flipped_msgtype);

	thisHeader->msg.msgtype = thisHeader->msg.flipped_msgtype;
	thisHeader->reqMsg = NULL;
	thisHeader->origMsg = NULL;

	if(thisHeader->FMMsg.msgtype == SHC_FM_RESP)
	{
		// R027876
		fmData = (IstSegPdtBase *)thisHeader->getSegmentObj(ElfIdMap::elf_to_id(IST_SEG_FM));
		if(fmData)
			OTraceDebug("D-SHC-154007:FM_SEG_DATA segment found\n");

		//R029287 >>>
		//Store Rule list and domain list in segment, if available
		if(strlen(thisHeader->FMMsg.rule_list))
		{
			thisHeader->setSegmentData(thisHeader->FMMsg.rule_list,strlen(thisHeader->FMMsg.rule_list),
									ElfIdMap::elf_to_id(IST_SEG_FN_DATA),FN_DATA_RULE_LIST);
			OTraceDebug("D-SHC-154002.1: Stored rulelist[%s] in FN_DATA_SEGMENT\n", thisHeader->FMMsg.rule_list);
		}

		if(strlen(thisHeader->FMMsg.domain_list))
		{
			thisHeader->setSegmentData(thisHeader->FMMsg.domain_list,strlen(thisHeader->FMMsg.domain_list),
									ElfIdMap::elf_to_id(IST_SEG_FN_DATA),FN_DATA_DOMAIN_LIST);

			OTraceDebug("D-SHC-154002.2: Stored domainlist[%s] in FN_DATA_SEGMENT\n", thisHeader->FMMsg.domain_list);
		}
		//R029287 <<<
	}
	else if(thisHeader->FMMsg.msgtype == SHC_LM_RESP)
	{
		// R027876
		fmData = (IstSegPdtBase *)thisHeader->getSegmentObj(ElfIdMap::elf_to_id(IST_SEG_LM));
		if(fmData) {
			OTraceDebug("D-SHC-154008:LM_SEG_DATA segment found\n");
		//	>>>	R021958

		ShcTimeStamp_seg *origTimeStamp;
		ShcTimeStamp_seg tmstpResp;
		memset(&tmstpResp, 0, sizeof(struct ShcTimeStamp_seg));

		fmData->getTimestamp(&origTimeStamp,&tmstpLen);
		if(tmstpLen)
			OTraceDebug("D-SHC-154009: TIMESTAMP subelement found\n");


		tmstpResp.sendToLM_tme = origTimeStamp->sendToLM_tme;
		tmstpResp.sendToLM_ms = origTimeStamp->sendToLM_ms;

		struct timeb tmpTime;
		ftime(&tmpTime);
		struct tm *tmResp;
		tmResp = localtime ( &tmpTime.time);

		char tme[10],dtme[20];
		snprintf(tme, sizeof(tme),"%02d%02d%02d", tmResp->tm_hour, tmResp->tm_min, tmResp->tm_sec);
		snprintf(dtme, sizeof(dtme), "%02d:%02d:%02d:%02d", tmResp->tm_hour, tmResp->tm_min, tmResp->tm_sec, tmpTime.millitm); // --- R023376
		tmstpResp.receiveFromLM_tme = atoi(tme);
		tmstpResp.receiveFromLM_ms = tmpTime.millitm;
		OTraceLog("L-SHC-154010: Time in HH:MM:SS:ss when Response from LM: %s \n",dtme);	//	---	R023394

		fmData->setTimestamp(&tmstpResp,sizeof(tmstpResp)); //R027876
		OTraceDebug("D-SHC-154012: TIMESTAMP_SEG segment has been added after response from LM\n");
		} //End of if - for fmData
		//	<<<	R021958
	}

	if(fmData)
	{
		//      >>>     R160740849

		memset(buf, 0x00, sizeof(buf)); l=sizeof(buf);

		// fmData->getReqEventId(buf,&l);
		// if(l) 	---	R026142
		if (fmData->getReqEventId(buf,&l) == IST_RET_OK)
		{
			if( tm_getdata(atoi(buf), (char *)&timerBuf, sizeof(timerBuf)) > 0)
			{
				thisHeader->allocateAndCopyReqMsg(&(timerBuf.msg));
				OTraceDebug("D-SHC-154003: reqmsg restored from FM event\n");
			}
			tm_dequeue(atoi(buf));
		}

		memset(buf, 0x00, sizeof(buf)); l=sizeof(buf);

		// fmData->getOrigEventId(buf,&l);
		// if(l)		---	R026142
		if (fmData->getOrigEventId(buf,&l) == IST_RET_OK)
		{
			if( tm_getdata(atoi(buf), (char *)&timerBuf, sizeof(timerBuf)) > 0)
			{
				thisHeader->allocateAndCopyOrigMsg(&(timerBuf.msg));
				OTraceDebug("D-SHC-154004: origmsg restored from FM event\n");
			}
			tm_dequeue(atoi(buf));
		}

		memset(buf, 0x00, sizeof(buf)); l=sizeof(buf);
		if (fmData->getFlippedMsgType(buf,&l) == IST_RET_OK)
			thisHeader->msg.flipped_msgtype = atoi(buf);
		
		memset(buf, 0x00, sizeof(buf)); l=sizeof(buf);
		if (fmData->getLogFlag(buf,&l) == IST_RET_OK)
			thisHeader->logFlag = atoi(buf);

		memset(buf, 0x00, sizeof(buf)); l=sizeof(buf);
		if (fmData->getRepeatFlag(buf,&l) == IST_RET_OK)
			thisHeader->repeatFlag = atoi(buf);

		memset(buf, 0x00, sizeof(buf)); l=sizeof(buf);
		if (fmData->getShcerr(buf,&l) == IST_RET_OK)
			thisHeader->shcerr = atoi(buf);

		memset(buf, 0x00, sizeof(buf)); l=sizeof(buf);
		if (fmData->getTxnIn_time(buf,&l) == IST_RET_OK)
			thisHeader->time_in = atol(buf);

		memset(buf, 0x00, sizeof(buf)); l=sizeof(buf);
		if (fmData->getTxnOut_time(buf,&l) == IST_RET_OK)
			thisHeader->time_out = atol(buf);
		//      <<<     R160740849

		struct RoutingInfo routingInfo = {0};
		int routingInfoLen=sizeof(struct RoutingInfo);

		if (fmData->getRoutingInfo((char*)&routingInfo, &routingInfoLen)==IST_RET_OK)
			thisHeader->setSegmentData((char*)&routingInfo, sizeof(routingInfo), NETWORK_DATA_REQ_id,ROUTING_INFO);

	}

	// clarify whether procFlag or skipFlag
	thisHeader->setSkipFlag(TXN_PROC_SKIP_ENRICH | TXN_PROC_SKIP_RESTORE | TXN_PROC_SKIP_EDIT | TXN_PROC_SKIP_VERIFY);

	/* FM Denial case start*/

	if(thisHeader->FMMsg.respcode != 0)//respcode to be changed later
	{
		if(thisHeader->FMMsg.msgtype == SHC_LM_RESP)
		{
			thisHeader->msg.respcode = SHC_RC_LMDeclined;	//150
		}
		else if(thisHeader->FMMsg.msgtype == SHC_FM_RESP)
		{
			thisHeader->msg.respcode = SHC_RC_FMDeclined;	//152
		}
		thisHeader->logFlag |= SHC_LOG_UPD_REQ;
		thisHeader->setSkipFlag(TXN_PROC_SKIP_DOWORK);
		thisHeader->shcerr = SH_RETURN;
		shcApp->shcmsgHelperObj->shc_set_return_msgno(&thisHeader->msg);
	}

	shcmsgFMHelperObj->enqueueInternalMsg(thisHeader);

	return(0);

}
//	<<<	R020938


ShcFMDecisionProcessor::ShcFMDecisionProcessor(char *msgbuf)
{
	header = shcHeaderRegister.getTargetObj(msgbuf);

	if (!header)
	{
		OTraceError("E-SHC-154005: Can't create header\n");
		return;
	}

	shcTxn = NULL;
}
