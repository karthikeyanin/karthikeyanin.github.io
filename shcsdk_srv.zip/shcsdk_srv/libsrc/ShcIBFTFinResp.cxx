static char _ShcIBFTFinResp_cxx_what[] = "@(#) ShcIBFTFinResp.cxx 1.9.2.1 16/12/14 09:13:57";

/*
 *  Copyright (C) 2004 eFunds Corporation ("eFunds").  All Rights Reserved.     
 *  eFunds Canada Corporation is an authorized user.                            
 *                                                                              
 *  IST is a registered trademark of eFunds Corporation.  Other brand or        
 *  product names are trademarks or registered trademarks of their respective   
 *  holders.                                                                    
 *                                                                              
 *  The information contained herein is the unpublished proprietary property    
 *  of eFunds.  Except as specifically authorized in writing by eFunds, the     
 *  holder of this document shall: i) keep all information contained herein     
 *  confidential, and ii) protect the information, in whole or in part, from    
 *  disclosure and dissemination to all third parties.                          
 *                                                                          
 *  This document and the software described in it are furnished under license  
 *  and may be used or copied only in accordance with the terms of such license.
 *  This document is supplied for information purposes only, is subject to      
 *  change without notice, and should not be construed as a commitment by       
 *  either eFunds Corporation or eFunds Canada Corporation. 
 *
 *
 *                        MODIFICATION HISTORY                  REVIEW
 *
 * SCR#     Who    Date  Description
 * ===========================================================================
 * R0xxxxx jyang 21Nov03 Created
 * R018687 Emj   22Jan07 ShcCamHelperObj decide if the txn should be sent to
 *                       the cam server
 */
 
 //File Number 82

#include <stdio.h>
#include <string.h>
#include <ctype.h>
#include <oasis.h>
#include <ist_otrace.h>
#include <shc.h>
#include <ShcFinAuthReq.h>
#include <ShcFinAuthHelper.h>
#include <ShcmsgHelper.h>
#include <ShcCamHelper.h>
#include <ShcmsgProcessor.h>

#include <ShcIBFTFinResp.h>
#include <ShcRevReqHelper.h>
#include <ShcApp.h>
#include <ShcIBFTHelper.h>


int ShcIBFTFinResp::restore()
{
	if (!header->shouldContinue(TXN_PROC_SKIP_RESTORE))
		return 0;
	thisShcApp->shcFinAuthHelperObj->shc_restore_fields(header);
	
							/* R011136 >> */
	int saved_msgtype, saved_pcode;
	saved_msgtype = header->msg.msgtype;
	saved_pcode   = header->msg.pcode;
	
	thisShcApp->shcIBFTHelperObj->restoreCallback(header);
	header->allocateAndCopyOrigMsg( &header->msg );

	if (shcmsgIsRequest(header->origMsg))
		header->origMsg->msgtype = shc_get_return_msgno(header->origMsg->msgtype);
	if (shcIsIBFTW(header))
		header->logFlag = SHC_LOG_ORIG;
	
	header->msg.msgtype = saved_msgtype;
	header->msg.pcode = saved_pcode;
							/* R011136 << */
	return 0;
	/*	Restore all the required fields. */
}



int ShcIBFTFinResp::doWork()
{
	if (!header->shouldContinue(TXN_PROC_SKIP_DOWORK))
		return 0;
	
	thisShcApp->shcFinAuthHelperObj->setLogFlag(header);
	thisShcApp->shcFinAuthHelperObj->checkNDKE(header);
//	thisShcApp->shcFinAuthHelperObj->updateEDC(header);

	/* Ssc - 28Jun00 	R004671 Integration to 7.2 */
	/* Ssc - 29Feb00    SPR # 2007336 VSDC enhancement  */
	if( thisShcApp->shcCamHelperObj->shc_cam_response_result( header ) < 0 )
	{
	    OTraceError("E-SHC-082001: Unable to retrieve result from cam.\n");
	    return (-1);
	}
	/* 2007336 */

	thisShcApp->shcFinAuthHelperObj->doAck(header);
	thisShcApp->shcFinAuthHelperObj->notifyPosAuth(header);
	thisShcApp->shcFinAuthHelperObj->writeSaf(header);
	thisShcApp->shcFinAuthHelperObj->updatePreauth(header);
	thisShcApp->shcFinAuthHelperObj->routeSettlement(header);
	thisShcApp->shcFinAuthHelperObj->shc_updateduptxn_info(header);
	thisShcApp->shcIBFTHelperObj->setDoWorkRoutingInfo(header);
	return 0;
}
