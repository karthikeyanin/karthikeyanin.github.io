static char _ShcRetShcmsg_cxx_what[] = "@(#) ShcRetShcmsg.cxx 1.5 05/02/03 10:49:14";

/*
 *  Copyright (C) 2004 eFunds Corporation ("eFunds").  All Rights Reserved.     
 *  eFunds Canada Corporation is an authorized user.                            
 *                                                                              
 *  IST is a registered trademark of eFunds Corporation.  Other brand or        
 *  product names are trademarks or registered trademarks of their respective   
 *  holders.                                                                    
 *                                                                              
 *  The information contained herein is the unpublished proprietary property    
 *  of eFunds.  Except as specifically authorized in writing by eFunds, the     
 *  holder of this document shall: i) keep all information contained herein     
 *  confidential, and ii) protect the information, in whole or in part, from    
 *  disclosure and dissemination to all third parties.                          
 *                                                                          
 *  This document and the software described in it are furnished under license  
 *  and may be used or copied only in accordance with the terms of such license.
 *  This document is supplied for information purposes only, is subject to      
 *  change without notice, and should not be construed as a commitment by       
 *  either eFunds Corporation or eFunds Canada Corporation. 
 *
 *
 *                        MODIFICATION HISTORY                  REVIEW
 *
 *	SPR#	Who	Date	Description			Who	Date   
 * ===========================================================================
 *R00xxxx ztang 16Jan03 Creation
 */
/* File Number 115 */

#include <stdio.h>
#include <string.h>
#include <ctype.h>
#include <oasis.h>
#include <ist_otrace.h>
#include <shc.h>
#include <shcdef.h>
#include <CShcLog.h>
#include <ShcRetShcmsg.h>
#include <ShcMacHelper.h>
#include <ShcFinAuthHelper.h>
#include <ShcmsgHelper.h>
#include <ShcCamHelper.h>
#include <ShcmsgProcessor.h>
#include <ShcApp.h>
#include <ShcRetHelper.h>


int ShcRetShcmsg::enrich()
{
	if ( !(header->msg.device_cap & SH_DEVCAP_FROM_REPLAY) )
		thisShcApp->shcRetHelperObj->checkMac(header);
	return 0;
}


int ShcRetShcmsg::edit()
{
	return(0);
}

	
int ShcRetShcmsg::doWork()
{
	header->logFlag = SHC_LOG_REQ;
	
	switch(header->msg.msgtype)
	{
	case SHC_DEVICE_ACK:
	case SHC_DEVICE_NAK:
		header->shcerr = SH_IGNORE;
		break;
	case SHC_ADMIN:
	case SHC_ADMIN_ADVICE:
		if (header->msg.netcode == 174)
			header->shcerr = SH_IGNORE;
		else
			header->shcerr = SH_RETURN;
		break;
	default:
		header->shcerr = SH_RETURN;
	}
	
	thisShcApp->shcmsgHelperObj->shc_set_return_msgno(header);
	
	return 0;
}








