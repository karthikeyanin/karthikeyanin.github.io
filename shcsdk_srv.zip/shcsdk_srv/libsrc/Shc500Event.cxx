static char _Shc500Event_cxx_what[] = "@(#) Shc500Event.cxx 1.3 04/08/24 17:53:35";

/*
 *  Copyright (C) 2004 eFunds Corporation ("eFunds").  All Rights Reserved.     
 *  eFunds Canada Corporation is an authorized user.                            
 *                                                                              
 *  IST is a registered trademark of eFunds Corporation.  Other brand or        
 *  product names are trademarks or registered trademarks of their respective   
 *  holders.                                                                    
 *                                                                              
 *  The information contained herein is the unpublished proprietary property    
 *  of eFunds.  Except as specifically authorized in writing by eFunds, the     
 *  holder of this document shall: i) keep all information contained herein     
 *  confidential, and ii) protect the information, in whole or in part, from    
 *  disclosure and dissemination to all third parties.                          
 *                                                                          
 *  This document and the software described in it are furnished under license  
 *  and may be used or copied only in accordance with the terms of such license.
 *  This document is supplied for information purposes only, is subject to      
 *  change without notice, and should not be construed as a commitment by       
 *  either eFunds Corporation or eFunds Canada Corporation. 
 *
 *
 *
 *                        MODIFICATION HISTORY                  REVIEW
 *
 *	SPR#	Who	Date	Description			Who	Date   
 * ===========================================================================
 * R0xxxxx jyang 09Dec03 Created
 */

//File Number 50

#include <Shc500Event.h>
#include <ShcSaf.h>
#include <ShcApp.h>
#include <ShcBin.h>
#include <ShcmsgEventHelper.h>
#include <Shc500Helper.h>

int Shc500Event::doWork()
{
	//ShcmsgEvent:doWork
	if ( ! header->shouldContinue(TXN_PROC_SKIP_DOWORK) )
		return False;
		
	if ( thisShcApp->shcmsgEventHelperObj->retryOnTimeout(header, shcBin) == True )
	{
		header->setSkipFlag();
		return False;
	}
		
	switch(header->msg.msgtype)
	{
	case	SHC_STLMTREQ:
		if(shcBin->binPkg->saf.type & SH_SAF_POSFILE)
		{
			tm_dequeue(header->eventId);
			thisShcApp->shcmsgEventHelperObj->doPositiveAuth( header, shcBin, 1 );
		}
		else
			thisShcApp->shc500HelperObj->procStlmtEvent(header);
		break;

	case	SHC_STLMTREQ_ADVICE:
		tm_dequeue(header->eventId);
		thisShcApp->shcmsgEventHelperObj->procAdviceEvent(header, shcBin);
		/* For now we just drop it. */
		header->shcerr = SH_IGNORE;
		break;

	default:
	
		break;
	}
	
	OTraceDebug( "D-SHC-050001: Leave Shc500Event::doWork()\n" );

		return 0;
}










