static char _ShcIBFTHelper_cxx_what[] = "@(#) ShcIBFTHelper.cxx 1.24.1.2 20/02/17 23:58:12";

/*
 *  Copyright (C) 2004 eFunds Corporation ("eFunds").  All Rights Reserved.     
 *  eFunds Canada Corporation is an authorized user.                            
 *                                                                              
 *  IST is a registered trademark of eFunds Corporation.  Other brand or        
 *  product names are trademarks or registered trademarks of their respective   
 *  holders.                                                                    
 *                                                                              
 *  The information contained herein is the unpublished proprietary property    
 *  of eFunds.  Except as specifically authorized in writing by eFunds, the     
 *  holder of this document shall: i) keep all information contained herein     
 *  confidential, and ii) protect the information, in whole or in part, from    
 *  disclosure and dissemination to all third parties.                          
 *                                                                          
 *  This document and the software described in it are furnished under license  
 *  and may be used or copied only in accordance with the terms of such license.
 *  This document is supplied for information purposes only, is subject to      
 *  change without notice, and should not be construed as a commitment by       
 *  either eFunds Corporation or eFunds Canada Corporation. 
 */
/*
 *
 *                        MODIFICATION HISTORY                  REVIEW
 *
 *	SPR#	Who	Date	Description			Who	Date   
 * ===========================================================================
 * 10002273 la  19aug96 Created for IBFT transaction processing.
 * 10002675 JSG	21Oct96	shc_advice_IBFT(): Change msgtype for transferree to
 *			SHC_REVREQ from SHC_REVREQ_ADVICE.
 *			shc_reverse_IBFT_update(): Use the original pcode to
 *			locate the original.
 * 10002676 JSG	21Oct96	shc_advice_IBFT_send(): Clear SH_DEVCAP_FROM_REPLAY.
 * R007062	gbeeng	26Nov2001	C++ Migration
 * R018276	pve	26Nov06	Add new OTraceLog messages
 * R027876  dipa  02Mar10  Segment changes
 * R027876  dipa  22Apr10  Segment changes - fix
 * R030381  dipa  02Mar12  Txnstat changes
 */

//File Number 83

#include <stdio.h>
#include <string.h>
#include <oasis.h>
#include <ist_otrace.h>
#include <mb.h>
#include <mb_umi.h>
#include <shc.h>
#define SHC_IBFT_SRC
#include "shc_util_funcs.h"
#include <ShcmsgHelper.h>
#include <ShcTimerHelper.h>
#include <ShcSaf.h>
#include <ShcRevReqHelper.h>
#include <ShcIBFTHelper.h>
#include <ShcApp.h>
#include <ShcSafIOHelper.h>
#include <ShcFinAuthHelper.h>
#include <ShcBin.h>
#include <CShcLog.h>
#include <ist_seg_name.h> //R027876
#include <ist_seg_elf_id_map.h> //R027876
#include <ist_seg_id.h> //R027876
#include <TxnStat.h>
#include <istsafe.h>



int ShcIBFTHelper::shc_create_IBFT( ShcmsgHeader *header, long type )
{
	int len ;
	char tmpShclogId[sizeof(header->msg.shclog_id)];
	istsafe_strcpy(tmpShclogId,sizeof(tmpShclogId), header->msg.shclog_id);

	if( type & SH_DEVCAP_SHC_IBFTW )
	{
		OTraceDebug("D-SHC-083001: Creating withdrawal request\n");
		header->msg.shc_devcap |= SH_DEVCAP_SHC_IBFTW;
		header->msg.shc_devcap &= ~SH_DEVCAP_SHC_IBFTD;
		header->msg.pcode = shcMakeProcessingCode(SH_ISO_WD, 
			header->msg.from_acct, header->msg.to_acct);
		
		header->setSegmentData(tmpShclogId,sizeof(tmpShclogId), NETWORK_DATA_REQ_id, SHC_CHIP_IND);
		//mb_getUmi(header->msg.shclog_id, sizeof(header->msg.shclog_id));

		header->shcerr |= SH_SENDISS;
	}
	else if( type & SH_DEVCAP_SHC_IBFTD )
	{ 
		OTraceDebug("D-SHC-083002: Creating deposit request\n");
		header->msg.shc_devcap |= SH_DEVCAP_SHC_IBFTD;
		header->msg.shc_devcap &= ~SH_DEVCAP_SHC_IBFTW;
    	header->msg.pcode = shcMakeProcessingCode(SH_ISO_DEPOSIT,
			header->msg.from_acct, header->msg.to_acct);

		thisShcApp->shcmsgHelperObj->shc_pinblk_ob2tb(header);

		len = sizeof(tmpShclogId);
		header->getSegmentData(tmpShclogId,&len, NETWORK_DATA_REQ_id, SHC_CHIP_IND);
		istsafe_strcpy(header->msg.shclog_id,sizeof(header->msg.shclog_id),tmpShclogId);

		header->shcerr |= SH_SENDTRA;
	}

	mb_set_tid(header->msg.shclog_id, strlen(header->msg.shclog_id));

	OTraceLog("L-SHC-083010: Created msg ID[%s]/m%04d/t%06ld/p%06ld from msg ID[%s]\n",
		header->msg.shclog_id, header->msg.msgtype, header->msg.trace, header->msg.pcode, tmpShclogId);

	TxnStatReport(header->msg.shclog_id,TS_SHC,TSR_CREATE,header->msg.msgtype,0,0);

	// R027876 >>>
	struct RoutingInfo r={0};
	len = sizeof(struct RoutingInfo);
	header->getSegmentData((char *)&r, &len, NETWORK_DATA_REQ_id,ROUTING_INFO);
	if(len)
	{
		r.flag = 0;
		header->setSegmentData((char*)&r, sizeof(r), NETWORK_DATA_REQ_id,ROUTING_INFO); //R027876
	}
	// <<< R027876


	thisShcApp->shcTimerObj->shc_set_timers(header);
	header->shcerr |= SH_SETTIMER;

	return( 0 );
}

int ShcIBFTHelper::shc_advice_IBFT_send( ShcmsgHeader *header, ShcBin *shcBin )
{
	/* 10002676 */
	int deviceCap = header->msg.device_cap;
	header->msg.device_cap &= ~SH_DEVCAP_FROM_REPLAY;

	thisShcApp->shcSafIOHelperObj->shc_saf_writefile(shcBin, header);
	
	header->msg.device_cap = deviceCap;
	return( 0 );
}


int ShcIBFTHelper::shc_reverse_IBFT_update( ShcmsgHeader *header )
{
	/*	10002675
	*	Locate the original, using the original pcode.
	*/
	int tmpPcode = header->msg.pcode;
	if( !shcIsTransfer(header->msg.pcode) && shcIsTransfer(header->msg.origpcode) )
		header->msg.pcode = header->msg.origpcode;

	if( thisShcApp->shcmsgHelperObj->locateOrigTxn(header) < 0 )
	{
		header->msg.shcerror = SHC_IE_NoMatch;
		header->msg.respcode = SHC_RC_NoOriginal;
		header->msg.pcode = tmpPcode;
		return( -1 );
	}
	
	OTraceDebug("D-SHC-083003: shc_reverse_IBFT_update\n");
	
	thisShcApp->shcRevReqHelperObj->updateOriginal( header );
		header->msg.pcode = tmpPcode;
	return( 0 );
}

int ShcIBFTHelper::shc_advice_IBFT( ShcmsgHeader *header, long type )
{
	struct ShcmsgWithSegment tmpMsg;

	int totalLen = header->truelength();
	memcpy(&tmpMsg.msg, &header->msg, sizeof(struct shcmsg));
	if (totalLen > sizeof(struct shcmsg)) //segments present
		memcpy(&tmpMsg.segmentData, &header->segment, sizeof(tmpMsg.segmentData));

	if( type & SH_DEVCAP_SHC_IBFTD )
	{ 
		/* Reverse transferee */
		shc_create_IBFT(header, SH_DEVCAP_SHC_IBFTD);

		if( shcmsgIsReversal(&header->msg) )
		{
			/* 10002675 */
			header->msg.msgtype = SHC_REVREQ_ADVICE;	// R011202
			shc_reverse_IBFT_update(header);
		}

		shc_advice_IBFT_send(header, header->transfereeShcBin);
	}

	if( type & SH_DEVCAP_SHC_IBFTW )
	{
		/* Reverse issuer */
		shc_create_IBFT(header, SH_DEVCAP_SHC_IBFTW);

		if( shcmsgIsReversal(&header->msg) )
		{
			header->msg.msgtype = SHC_REVREQ_ADVICE;
			shc_reverse_IBFT_update(header);
		}

		shc_advice_IBFT_send(header, header->issShcBin);
	}

	memcpy(&header->msg, &tmpMsg.msg,sizeof(struct shcmsg));
	memcpy(&header->segment, &tmpMsg.segmentData, sizeof(header->segment));

	//	>>>	R018276
	if( shcmsgIsReversal(&header->msg) && header->origMsg )
		OTraceLog("L-SHC-083008: Created SAF msg ID[%s]/m%04d/t%06ld/p%06ld from msg ID[%s]/m%04d/t%06ld/p%06ld\n",
			header->msg.shclog_id, header->msg.msgtype, header->msg.trace,
			header->msg.pcode, header->origMsg->shclog_id, header->origMsg->msgtype,
			header->origMsg->trace, header->origMsg->pcode);
	else
		OTraceLog("L-SHC-083009: Created SAF msg ID[%s]/m%04d/t%06ld/p%06ld\n", header->msg.shclog_id,
			header->msg.msgtype, header->msg.trace, header->msg.pcode);
	//	<<<	R018276

	return( 0 );
}


int ShcIBFTHelper::shc_restore_IBFT( ShcmsgHeader *header)
{
	if (!header->reqMsg)
		return 0;
	header->msg.shc_devcap |= header->reqMsg->shc_devcap
		& (SH_DEVCAP_SHC_IBFTW | SH_DEVCAP_SHC_IBFTD );

	header->msg.msgtype = header->reqMsg->origmsg;
	header->msg.pcode = header->reqMsg->origpcode;
	header->msg.senderid = header->reqMsg->senderid;
	istsafe_strcpy(header->msg.transferee, sizeof(header->msg.transferee), header->reqMsg->transferee);
	if(header->msg.transferee[0])
	{
		if(!header->transfereeShcBin)
			header->setTransfereeShcBin(header->msg.transferee);
	}

	strcpy(header->msg.pin, header->reqMsg->pin);

	OTraceDebug("D-SHC-083004: original pcode[%ld], shc_devcap[%ld]\n", header->msg.pcode, header->msg.shc_devcap);
	return( 0 );
}

/*****************************************************************************/
int ShcIBFTHelper::updateReqOriginal(ShcmsgHeader *header)
{
	OTraceDebug("D-SHC-083005:(%d)update original\n",__LINE__);
	
	/* 10002273 */
	if( shcIsIBFT(header) )
	{
		header->msg.origpcode = header->msg.pcode;
		header->msg.origFlippedMsg = header->msg.flipped_msgtype;
		
		if( header->msg.msgtype == SHC_REVREQ_ADVICE )
		{
			/* 961108 */
			thisShcApp->shcIBFTHelperObj->shc_advice_IBFT(header, SH_DEVCAP_SHC_IBFTD);
			thisShcApp->shcRevReqHelperObj->returnReversal(header);
		}
		else
			thisShcApp->shcIBFTHelperObj->shc_create_IBFT(header, SH_DEVCAP_SHC_IBFTD);
		
		return( False );
	}
	
	return True;
}

/*****************************************************************************/

int ShcIBFTHelper::restoreCallback(ShcmsgHeader *header)
{
	if (header->reqMsg)
	{
		if( shcmsgIsIBFTW(header->reqMsg) || shcmsgIsIBFTD(header->reqMsg) )	/* 10002273 */
			thisShcApp->shcIBFTHelperObj->shc_restore_IBFT(header);				/* 10002273 */
	}
	return (thisShcApp->shcFinAuthHelperObj->restoreCallback(header));
}

/*****************************************************************************/

int ShcIBFTHelper::setDoWorkRoutingInfo(ShcmsgHeader *header)
{
	if( processIBFT(header) < 0 )
		thisShcApp->shcFinAuthHelperObj->setDoWorkRoutingInfo(header);
	
	return 0;
}

int ShcIBFTHelper::doReplay(ShcmsgHeader *header)
{
	if(thisShcApp->shcRevReqHelperObj->doReplay(header) == False )
		return False;
		
			/* R010133 >> */
	if(shcIsIBFTD(header))
	{
		ODebug("I-SHC-083006: SEND TO TRANSFEREE\n");
		header->shcerr = SH_SENDTRA | SH_SETTIMER;
	}
			/* R010133 << */
	
	return True;
}


/*****************************************************************************/

int ShcIBFTHelper::routeReversal(ShcmsgHeader *header, int omsg_is_saf)
{
	if( thisShcApp->shcRevReqHelperObj->routeReversal(header, omsg_is_saf) == True )
	{
		if( shcIsIBFTD(header) )							/* 10002273 */
		{													/* 10002273 */
			header->shcerr = SH_SENDTRA | SH_SETTIMER;		/* 10002273 */
		}													/* 10002273 */
		return True;
	}

	return False;
}

/*****************************************************************************/

int ShcIBFTHelper::prepareRespLogMessage(ShcmsgHeader *header)
{
	
	int logresponse;
	
	struct ShcmsgWithSegment tmpShcmsg;
	/* 10002273 */
	if( shcmsgIsIBFTD(header->reqMsg) || shcmsgIsIBFTW( header->reqMsg ) )
	{
		/* 961108 */
		header->reqMsg->pcode = header->reqMsg->origpcode;
		header->reqMsg->respcode = header->msg.respcode;
		/* 961108 */
	}
	
	logresponse = True;
	
	if( header->msg.msgtype==SHC_REVREQ_RESPONSE )  
	{
		/*
		 *	If the we have already posted a 410/430 then do NOT update
		 *	with current 430 values
		 *	this might be duplicate
		 */
		if(((ShcLog *)header->shcLogObj)->locateTxn(header, &(tmpShcmsg.msg), NULL) >= 0)
		{
			if( shcmsgIsResponse(&(tmpShcmsg.msg)) )
			{
				if( header->reqMsg->device_cap & SH_DEVCAP_FROM_REPLAY )
				{
					if( tmpShcmsg.msg.respcode == SHC_RC_Approved )
					{
						if( header->msg.respcode != SHC_RC_Approved
						  && tmpShcmsg.msg.msgtype == SHC_REVREQ_ADVICE_RESPONSE )
						{
							header->msg.serial_1 = (long)header->msg.respcode;
							header->msg.serial_2 = (long)header->msg.reason_code;
						}
						logresponse = False;
					}
				}
				logresponse = False;
			}
		}
		((ShcLog *)header->shcLogObj)->rewind();
	}
	
	return logresponse;
}

/*****************************************************************************/
int ShcIBFTHelper::restoreBeforeRouting(ShcmsgHeader *header)
{
	/* 10002273 */
	if( shcmsgIsIBFTD(header->reqMsg) && header->msg.respcode == SHC_RC_Approved )
	{
		int tmpMsgType = header->msg.msgtype;
		int tmpShcerr  = header->shcerr;
		header->msg.respcode = header->msg.origrespcode; 
		thisShcApp->shcRevReqHelperObj->updateOriginal(header);		//////////////////////////////

		header->msg.msgtype = SHC_REVREQ_ADVICE;
		thisShcApp->shcIBFTHelperObj->shc_advice_IBFT(header, SH_DEVCAP_SHC_IBFTW);

		/* 961108 */
		header->msg.respcode = SHC_RC_Approved;
		header->msg.msgtype = tmpMsgType;
		header->shcerr      = tmpShcerr;
	}
	
//	Following function removed
//	thisShcApp->shcRevRespHelperObj->restoreBeforeRouting(revTxn, header);
	
	return 0;
}

/*****************************************************************************/
int ShcIBFTHelper::setRoutingFlag(ShcmsgHeader *header)
{

	/*	27Mar92
	*	If original message is from SHCREPLAY, need to return
	*	it back to him so that he can sent me the next message.
	*/
	if( (header->reqMsg->device_cap & SH_DEVCAP_FROM_REPLAY)
		|| (header->issShcBin->binPkg->bin.flags & SH_GETAPP_HOST) 
		|| shcmsgIsIBFTD(header->reqMsg) )				/* 10002273 */
	{
		/* 10002113 */
		if( header->reqMsg->msgtype == SHC_REVREQ_ADVICE
			&& (header->issShcBin->binPkg->saf.type & SH_SAF_POSFILE) )
		{
			header->shcerr			= SH_RECON|SH_RETURN;
		}
		else
		{
			header->shcerr			= SH_RETURN;
		}
	
		header->msg.senderid	= header->reqMsg->senderid;
		header->msg.unit		= header->reqMsg->unit;
	}
	return 0;
}

/*****************************************************************************/

int ShcIBFTHelper::processIBFT(ShcmsgHeader *header)
{
	/* 10002273 */
	if( shcIsIBFTW(header) || shcIsIBFTD(header) )
	{
		header->logFlag = SHC_LOG_UPD_REQ;
		thisShcApp->shcIBFTHelperObj->shc_restore_IBFT(header);	// R011136
		if( shcIsIBFTW(header) )
		{
			if( header->msg.respcode == SHC_RC_Approved ) 
			{
						/* R010133 >> */
				if(shc_isdown(header->transfereeShcBin->binPkg))
				{
					header->msg.msgtype = SHC_REVREQ_ADVICE;
					header->msg.respcode = SHC_RC_IssuerDown;
					header->msg.reason_code = SHC_RC_TransfereeDown;
					thisShcApp->shcIBFTHelperObj->shc_advice_IBFT(header, SH_DEVCAP_SHC_IBFTW);
				}
				else
				{
					thisShcApp->shcIBFTHelperObj->shc_create_IBFT(header, SH_DEVCAP_SHC_IBFTD);
					header->shcerr &= ~SH_IGNORE;                        // R011136
					OTraceDebug("D-SHC-083007: Generate a deposit to TRA\n"); // R011136
					header->logFlag = SHC_LOG_ORIG;
					return(0);
				}
						/* R010133 << */
			} 

			header->msg.reason_code = SHC_RC_IssuerDown;
			if( header->origMsg )
				header->logFlag = SHC_LOG_ORIG;
		}
		else if( shcIsIBFTD(header) )
		{
			if( header->msg.respcode != SHC_RC_Approved 
				&& header->msg.respcode != SHC_RC_IssuerTimeout ) 
			{
				header->msg.msgtype = SHC_REVREQ_ADVICE;
				header->msg.reason_code = SHC_RC_TransfereeDown;
				thisShcApp->shcIBFTHelperObj->shc_advice_IBFT(header, SH_DEVCAP_SHC_IBFTW);
			}
			if( header->origMsg )
				header->logFlag = SHC_LOG_UPD_ORIG;
		}

 		header->msg.msgtype = thisShcApp->shcmsgHelperObj->shc_get_return_msgno(header->msg.origmsg);
		header->msg.shc_devcap |= (SH_DEVCAP_SHC_IBFTW | SH_DEVCAP_SHC_IBFTD);
		
		if( header->origMsg )
		{
			header->origMsg->msgtype = header->msg.msgtype;
			header->origMsg->shc_devcap = header->msg.shc_devcap;
		}

	}
	return (-1);
}



