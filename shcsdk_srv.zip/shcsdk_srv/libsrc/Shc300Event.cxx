static char _Shc300Event_cxx_what[] = "@(#) Shc300Event.cxx 1.6.1.3 17/09/25 01:32:19";

/*
 *  Copyright (C) 2004 eFunds Corporation ("eFunds").  All Rights Reserved.
 *  eFunds Canada Corporation is an authorized user.
 *
 *  IST is a registered trademark of eFunds Corporation.  Other brand or
 *  product names are trademarks or registered trademarks of their respective
 *  holders.
 *
 *  The information contained herein is the unpublished proprietary property
 *  of eFunds.  Except as specifically authorized in writing by eFunds, the
 *  holder of this document shall: i) keep all information contained herein
 *  confidential, and ii) protect the information, in whole or in part, from
 *  disclosure and dissemination to all third parties.
 *
 *  This document and the software described in it are furnished under license
 *  and may be used or copied only in accordance with the terms of such license.
 *  This document is supplied for information purposes only, is subject to
 *  change without notice, and should not be construed as a commitment by
 *  either eFunds Corporation or eFunds Canada Corporation.
 *
 *
 *
 *                        MODIFICATION HISTORY                  REVIEW
 *
 *	SPR#	Who	Date	Description			Who	Date
 * ===========================================================================
 * R0xxxxx jyang 09Dec03 Created
 */

//File Number 43

#include <Shc300Event.h>
#include <Shc300Helper.h>
#include <Shc300Processor.h>
#include <ShcApp.h>

int Shc300Event::doWork()
{
	OTraceInfo("I-SHC-043001: Time out of message: %d \n", header->msg.msgtype );

	/*	Special processing */
	header->msg.msgtype = thisShcApp->shc300HelperObj->shc_get_return_msgno(header->msg.msgtype);

	/* 27May93  Assign response code for time out. */
	((struct shcmsg *)&header->msg)->respcode = SHC_RC_LateResponse;

	//ShcProcessor *newProcessor;
	//if ( (newProcessor = thisShcApp->shc300HelperObj->enqueueInternalMsg(header)) == NULL )
	//{
	//	OTraceError("E-SHC-043002: Unable to enqueueInternalMsg() in Shc300Event::doWork()\n");
	//}
	//else
	//	newProcessor->header->setSkipFlag(TXN_PROC_SKIP_ENRICH|TXN_PROC_SKIP_RESTORE);

	tm_dequeue(header->eventId);

	header->shcerr = SH_RETURN;
	header->logFlag |= SHC_LOG_REQ;

	OTraceDebug( "D-SHC-043003: Leave Shc300Event::doWork()\n" );

	return(0);
}

