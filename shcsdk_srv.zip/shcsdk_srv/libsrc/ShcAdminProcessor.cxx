static char _ShcAdminProcessor_cxx_what[] = "@(#) ShcAdminProcessor.cxx 1.9 05/01/10 15:04:24";

/*
 *  Copyright (C) 2004 eFunds Corporation ("eFunds").  All Rights Reserved.     
 *  eFunds Canada Corporation is an authorized user.                            
 *                                                                              
 *  IST is a registered trademark of eFunds Corporation.  Other brand or        
 *  product names are trademarks or registered trademarks of their respective   
 *  holders.                                                                    
 *                                                                              
 *  The information contained herein is the unpublished proprietary property    
 *  of eFunds.  Except as specifically authorized in writing by eFunds, the     
 *  holder of this document shall: i) keep all information contained herein     
 *  confidential, and ii) protect the information, in whole or in part, from    
 *  disclosure and dissemination to all third parties.                          
 *                                                                          
 *  This document and the software described in it are furnished under license  
 *  and may be used or copied only in accordance with the terms of such license.
 *  This document is supplied for information purposes only, is subject to      
 *  change without notice, and should not be construed as a commitment by       
 *  either eFunds Corporation or eFunds Canada Corporation. 
 *
 *
 *                        MODIFICATION HISTORY                  REVIEW
 *
 * SCR#     Who    Date  Description
 * ===========================================================================
 * R0xxxxx 
 */
 
 //File Number 53

#include <ist_otrace.h>
#include <tm.h>
#include <shc.h>
#include <shcextbuf.h>
#include <ShcSender.h>
#include <ShcSdkCommon.h>
#include <ShcBin.h>
#include <ShcMsgCache.h>
#include <ShcmsgHelper.h>
#include <ShcTimerHelper.h>
#include <ShcAdminProcessor.h>
#include <CShcNotify.h>
#include <ShcFinAuthReq.h>
#include <ShcFinAuthResp.h>
#include <ShcMacHelper.h>
#include <ShcRevReq.h>
#include <ShcRevResp.h>
#include <ShcnetEventMsg.h>
#include <ShcnetNetworkMsg.h>
#include <ShcTimerHelper.h>
#include <ShcAdminReq.h>
#include <ShcAdminResp.h>
#include <ShcRetShcmsg.h>
#include <ShcNetworkMsgHelper.h>
#include <ShcAdminTxnRegistration.h>
#include <ShcApp.h>

ShcAdminProcessor::ShcAdminProcessor(char *msgbuf): ShcmsgProcessor(msgbuf)
{
}

ShcBaseTxn *ShcAdminProcessor::classify()
{
	return shcAdminTxnRegistration.getTargetObj(header);
}






