static char _Shc300Helper_cxx_what[] = "@(#) Shc300Helper.cxx 1.22 16/10/21 08:07:49";

/*
 *  Copyright (C) 2004 eFunds Corporation ("eFunds").  All Rights Reserved.     
 *  eFunds Canada Corporation is an authorized user.                            
 *                                                                              
 *  IST is a registered trademark of eFunds Corporation.  Other brand or        
 *  product names are trademarks or registered trademarks of their respective   
 *  holders.                                                                    
 *                                                                              
 *  The information contained herein is the unpublished proprietary property    
 *  of eFunds.  Except as specifically authorized in writing by eFunds, the     
 *  holder of this document shall: i) keep all information contained herein     
 *  confidential, and ii) protect the information, in whole or in part, from    
 *  disclosure and dissemination to all third parties.                          
 *                                                                          
 *  This document and the software described in it are furnished under license  
 *  and may be used or copied only in accordance with the terms of such license.
 *  This document is supplied for information purposes only, is subject to      
 *  change without notice, and should not be construed as a commitment by       
 *  either eFunds Corporation or eFunds Canada Corporation. 
 *
 *
 *                        MODIFICATION HISTORY                  REVIEW
 *
 * SCR#     Who    Date  Description
 * ===========================================================================
 * R0xxxxx 
 * R018276 pve	27Nov06	Remove excessive syslg messages
 * R023310 Ram  27May08 SDK header should refer external header
 * R028271 dipa 18Jun10 Txn Statistics
 * R030381 dipa 02Mar12 Removed TXNSTAT macro
 */
 
//File Number 44
#include <stdio.h>
#include <oasis.h>
#include <mb.h>
#include <mb_umi.h>
#include <tm.h>
#include <ist_otrace.h>
#include <shc.h>
#include <shcerror.h>
#include <shc_callback.h>
#include <ShcApp.h>
#include <ShcBin.h>
#include <ShcBaseTxn.h>
#include <Shc300Processor.h>
#include <ShcHelper.h>	//	---	R023310
#include <Shc300Helper.h>
#include <ShcSender.h>
#include <ShcMsgCache.h>
#include <ShcProcessorRegistration.h>
#include <Shc300Header.h>
#include <ShcmsgHelper.h>
#include <ShcTimerHelper.h>
#include <Shc300Log.h>
#include <Shc3XX.h>
#include <InstProfile.h>

//R028271 >>>
#include <TxnStat.h>
//<<< R028271


int Shc300Helper::shc_get_return_msgno(int msgno)
{
	int msgtype = msgno/10;
	return ( msgtype & 1 ? msgtype : msgtype+1 ) * 10 + ((msgno%10 & 1) ? 0 : msgno%10);
}


ShcProcessor *Shc300Helper::enqueueInternalMsg(ShcmsgHeader *hd)
{
    ShcProcessor *newProcessor = shcProcessorRegistration.getTargetObj((char *)(&hd->msg));

    if (!newProcessor)
        return NULL;
	
	newProcessor->header->flag	        = hd->flag;
	newProcessor->header->time_in		= hd->time_in;
	newProcessor->header->applMailboxId	= hd->applMailboxId;
	newProcessor->header->shcLogObj		= thisShcApp->shc300LogObj;
	
	OTraceDebug("D-SHC-4401: Shc300Helper::enqueueInternalMsg[%p]\n", newProcessor );
    newProcessor->header->flag |= MSG_CREATED_INTERNAL;
	thisShcApp->msgQueue.join(newProcessor);
    return newProcessor;
	
}

int Shc300Helper::shc_deny_txn(ShcmsgHeader *header)
{
	struct shcmsg *shcmsgP = (struct shcmsg *)&header->msg;
	
	if (!shcmsgIsRequest(shcmsgP))
		return -1;

	header->msg.msgtype = shc_get_return_msgno(header->msg.msgtype);
	
	header->shcerr |= SH_RETURN;

	switch(header->msg.msgtype/100)
	{
	case 3:
	{
		struct shcmsg *shc300P;
		shc300P = &header->msg;
		if ( shc300P->respcode == SHC_RC_Approved )
			shc300P->respcode = SHC_RC_DoNotHonor;
		break;
	}
	default:
		if ( 	(header->msg.respcode == SHC_RC_Approved) ||
				(header->msg.respcode == SHC_RC_PartialDispense) )
			header->msg.respcode = SHC_RC_DoNotHonor;
	}

	shc_callback_log(header, SHCCALLBACKDENY);

	return 0;
}

void Shc300Helper::shc_callback_log( ShcmsgHeader *header, int logType)
{
	int useSyslog = 1;

	OTraceDebug("D-SHC-4402: Callback logging. Message Type:[%d] logType:[%d]\n", 
		header->msg.msgtype, logType );
	
	if (logType == SHCCALLBACKDROP)
		useSyslog = 1;
	
	if (useSyslog)
	{
		char logInfo[512], amountBuf[100];
		bin_t acq_inst = {0}, acq_user_bin = {0}, iss_inst = {0}, iss_user_bin = {0};
		
		struct shc300fileupdt *shc300P;
		shc300P = reinterpret_cast<struct shc300fileupdt *>(&header->msg);
		struct	shc300fileupdt *actionP = (struct shc300fileupdt *)(shc300P->ActionCode);
		if (header->issBinValid())
		{
			strcpy(iss_inst, header->issShcBin->binPkg->bin.institutionid);
			strcpy(iss_user_bin, header->issShcBin->binPkg->bin.userbinid);
		}
		else
			shc_internalBin2ExternalBin(iss_inst, iss_user_bin, shc300P->receiveBin);
		if (header->acqBinValid())
		{
			strcpy(acq_inst, header->acqShcBin->binPkg->bin.institutionid);
			strcpy(acq_user_bin, header->acqShcBin->binPkg->bin.userbinid);
		}
	}
	return;
}

int Shc300Helper::shc_route(ShcmsgHeader *header)
{
	int		totallen;
	ShcmsgHeader *thisHeader = (ShcmsgHeader *)header;

	/*
	 *	This function works from the flags in header->scherr
	 *	These must be set correctly in order for routing to take place
	 */
	register	long	flags;
	register	int		outbound;
	int					senderid;
	static 	int 		respSenderId;
	static	AdviceSender		adviceSender;
	static	AccumulationSender	accumulationSender;

	InstitutionProfile instProfile = { 0 };
        struct InstitutionProfile *ip = NULL;
        int len = sizeof(struct InstitutionProfile);

        struct RoutingInfo routingBuf = { 0 };
        struct RoutingInfo *tmpInfo = &routingBuf;

	int routeInfo = 0;

	OTraceDebug("D-SHC-4403: Routing message based on 300 flags\n");

	if ((thisHeader->msg.msgtype == SHC_FILEUPD_ISSREQ) || ( thisHeader->msg.msgtype == SHC_LOCAL_FILEUPD_ISSREQ)
		 || (thisHeader->msg.msgtype == SHC_NEGATIVEFILE_ADVICE_MSG))
	{
		routeInfo = shc300Obj->setShc300Route(thisHeader);
		respSenderId = thisHeader->msg.senderid;
		OTraceDebug("D-SHC-4407: SenderID in req is <%d>\n",thisHeader->msg.senderid);

		if (routeInfo)
		{

			senderid	= thisHeader->msg.senderid;
			flags	= header->shcerr;

			if( flags & SH_IGNORE )
			{
				OTraceInfo("I-SHC-4408:  action : Ignore route\n");

				return(0);
			}
			else if((flags & SH_SENDISS) || (thisHeader->msg.msgtype == SHC_NEGATIVEFILE_ADVICE_MSG)) 
			{
				OTraceInfo("I-SHC-4409:  action : Send to issuer mailbox\n");
				header->getSegmentData((char *)&instProfile, &len, NETWORK_DATA_REQ_id, ISS_INST_PROFILE_ENTRY);
                                if (len == 0)
                                {
                                        OTraceDebug("D-SHC-4421:No issuer side inst_profile entry in segment, lookup a new entry\n");
                                        NetworkInfo networkInfo;

                                        bin_t routingBin;
                                        int size;
                                        size = sizeof(routingBin);
                                        header->getSegmentData((char *)routingBin,&size, NETWORK_DATA_REQ_id, ROUTING_BIN);
                                        shcApp->instProfileObj->locateNetworkInfo(header->msg.txnSrc, header->msg.txnDest,header->msg.iss_entityId, header->msg.msgtype,header->msg.issuer,  networkInfo);

                                        if (networkInfo.foundNetworkInfo())
                                        {
                                                memcpy(&instProfile, networkInfo.getInstProfileEntry(), sizeof(instProfile));
                                                thisHeader->setSegmentData((char *)&instProfile,sizeof(struct InstitutionProfile), NETWORK_DATA_REQ_id, ISS_INST_PROFILE_ENTRY);
                                                ip=&instProfile;
                                                thisShcApp->shcmsgHelperObj->addRoutingInfoSegment( header, networkInfo );
                                        }
                                        else
                                        {
                                                OTraceError("E-SHC-4422:Can't find inst_profile entry for s(%s) d(%s), e(%s),m(%d), i(%s)\n",
                                                header->msg.txnSrc, header->msg.txnDest,
                                                header->msg.iss_entityId, header->msg.msgtype, header->msg.issuer);
                                                ip=NULL;
                                        }
                                }
                                else
                                ip=&instProfile;
                                thisShcApp->shcmsgHelperObj->fillTransNodeInfo(header, header->issShcBin, &routingBuf, &outbound, ip);
			}

			else if(flags & SH_RETURN)
			{
				OTraceInfo("I-SHC-4410:  action : Return to sender\n");
				outbound = senderid;	
			}

			else if(flags & SH_SENDACQ)
			{
				OTraceInfo("I-SHC-4411:  action : Send to acquirer\n");
				if(header->acqBinValid())
                                {
                                        header->getSegmentData((char *)&instProfile, &len, NETWORK_DATA_REQ_id, ACQ_INST_PROFILE_ENTRY);
                                        if (len == 0)
                                        {
                                                OTraceDebug("D-SHC-4424:No acquirer side inst_profile entry in segment, lookup a new entry\n");
                                                NetworkInfo networkInfo;

                                                shcApp->instProfileObj->locateNetworkInfo(header->msg.txnDest, header->msg.txnSrc,
                                                        header->msg.entityId, header->msg.msgtype, header->msg.acquirer, networkInfo);
                                                if (networkInfo.foundNetworkInfo())
                                                {
                                                        memcpy(&instProfile, networkInfo.getInstProfileEntry(), sizeof(instProfile));
                                                        thisHeader->setSegmentData((char *)&instProfile,
                                                        sizeof(struct InstitutionProfile), NETWORK_DATA_REQ_id, ACQ_INST_PROFILE_ENTRY);
                                                        ip=&instProfile;
                                                        thisShcApp->shcmsgHelperObj->addRoutingInfoSegment( header, networkInfo );
                                                }
                                                else
                                                {
                                                        OTraceError("E-SHC-4425:Can't find inst_profile entry for s(%s) d(%s), e(%s),m(%d), a(%s)\n",
                                                                header->msg.txnSrc, header->msg.txnDest,
                                                        header->msg.entityId, header->msg.msgtype, header->msg.acquirer);
                                                        ip = NULL;
                                                }
                                        }
                                        else
                                                ip=&instProfile;

                                        thisShcApp->shcmsgHelperObj->fillTransNodeInfo(header, header->acqShcBin, &routingBuf, NULL, ip);
                                }


			}
			else if(flags & SH_SENDAPPL)
			{
				OTraceInfo("I-SHC-4412:  action : Send to application\n");

				outbound = header->applMailboxId;
			}
			else
			{
				OTraceError("E-SHC-4413: shc_route(0x%08x):Invalid routing\n", flags);
				return(-1);
			}
		}
	}
	else
	if ((thisHeader->msg.msgtype == SHC_FILEUPD_ISSREQ_RESPONSE  )  || (thisHeader->msg.msgtype == SHC_LOCAL_FILEUPD_ISSREQ_RESPONSE)
		 || (thisHeader->msg.msgtype == SHC_NEGATIVEFILE_ADVICE_RESP) || (thisHeader->msg.msgtype == SHC_FILEUPD_ACQREQ_ADVICE_RESP) )
	{

		if (thisHeader->msg.msgtype == SHC_NEGATIVEFILE_ADVICE_RESP)
			outbound = respSenderId;
		else
			outbound = thisHeader->msg.senderid;
		OTraceInfo("I-SHC-4407: Captured Outbound ID (%d) Outbound mbMailBoxName (%s)\n ",outbound,mbMailBoxName(outbound));

		if(outbound < 0)
			header->shcerr = SH_IGNORE;


		flags	= header->shcerr;
		if( flags & SH_IGNORE )
		{
			OTraceInfo("I-SHC-4408:  action : Ignore route\n");
			return(0);
		}
		else if(flags & SH_SENDISS)
		{
			OTraceInfo("I-SHC-4409:  action : Send to issuer mailboix\n");

			if(header->acqBinValid())
				outbound = header->issShcBin->binPkg->bin.mailbox;
		}

		else if(flags & SH_RETURN)
		{
			OTraceDebug("D-SHC-4414:  mailbox: %s [%d]\n", mbMailBoxName(outbound), outbound);
		}

		else if(flags & SH_SENDACQ)

		{
			OTraceInfo("I-SHC-4411:  action : Send to acquirer\n");

		}
		else if(flags & SH_SENDAPPL)
		{
			OTraceInfo("I-SHC-4412:  action : Send to application\n");
			outbound = header->applMailboxId;
		}
		else
		{
			OTraceError("E-SHC-4413: shc_route(0x%08x):Invalid routing\n", flags);
			return(-1);
		}
	}
	else
	if ((thisHeader->msg.msgtype != SHC_FILEUPD_ISSREQ) && ( thisHeader->msg.msgtype != SHC_LOCAL_FILEUPD_ISSREQ) &&
		(thisHeader->msg.msgtype != SHC_NEGATIVEFILE_ADVICE_MSG) && ( thisHeader->msg.msgtype != SHC_FILEUPD_ISSREQ_RESPONSE) &&
		(thisHeader->msg.msgtype != SHC_LOCAL_FILEUPD_ISSREQ_RESPONSE) && ( thisHeader->msg.msgtype != SHC_NEGATIVEFILE_ADVICE_RESP) &&
		(thisHeader->msg.msgtype != SHC_FILEUPD_ACQREQ_ADVICE) && ( thisHeader->msg.msgtype != SHC_FILEUPD_ACQREQ_ADVICE_RESP))
	{
		OTraceInfo("I-SHC-4413:  action : Drop route : Unsupported MsgType (%d)\n",thisHeader->msg.msgtype);
		return(0);
	}
		/* determine true legth of buffer */
		totallen = thisHeader->truelength();

	thisShcApp->shcmsgHelperObj->shc_dispmsg_x(&thisHeader->msg, 1, outbound);
	strtrim(routingBuf.destNode, routingBuf.destNode);
        strtrim(routingBuf.srcNode, routingBuf.srcNode);

	if ((routingBuf.destNode[0])&&(strcmp(routingBuf.destNode, routingBuf.srcNode)!=0))
        {
                /* R021436 >> */
                if (mcastHelperObj->ready())
                {
                        char *tmpp;
                        int ackFlag= 0;
                        if (!tmpInfo->siteId)
                                ackFlag = 0;
                        else if (tmpInfo->siteId != mbGetSiteId())
                                ackFlag = 2;
                        tmpp = mcastHelperObj->createBroadcastMsg(ackFlag, (char *)&thisHeader->msg, totallen, tmpInfo->destNode, &totallen, tmpInfo->siteId);
                        if (cache_mb_write(mcastHelperObj->getMbID(), shcmid, (char *)tmpp, totallen)<0)
                        {
                                OTraceLog("L-SHC-4419: Failed to send msg ID[%s] /m%04d/t%d/p%06d to %s\n",
                                thisHeader->msg.shclog_id, thisHeader->msg.msgtype, thisHeader->msg.trace,
                                thisHeader->msg.pcode, mbMailBoxName(mcastHelperObj->getMbID()));
                        }
                        else
                                OTraceLog("L-SHC-4420: Sent msg ID[%s] /m%04d/t%d/p%06d to %s\n",
                                thisHeader->msg.shclog_id, thisHeader->msg.msgtype, thisHeader->msg.trace,
                                thisHeader->msg.pcode, mbMailBoxName(mcastHelperObj->getMbID()));
                }
                else
                {
                        OTraceLog("L-SHC-4421: Can not send msg ID[%s] /m%04d/t%d/p%06d to broad cast port! send to BIN's destination ID: <%d> instead\n",
                                thisHeader->msg.shclog_id, thisHeader->msg.msgtype, thisHeader->msg.trace,
                                thisHeader->msg.pcode, outbound);

                        if (cache_mb_write(outbound, shcmid, (char *)&thisHeader->msg, totallen)<0)
			{
				OTraceLog("L-SHC-4422: Failed to send msg ID[%s] /m%04d/t%d/p%06d to %s\n",
				thisHeader->msg.shclog_id, thisHeader->msg.msgtype, thisHeader->msg.trace,
				thisHeader->msg.pcode, mbMailBoxName(outbound));
                        }
                        else
				OTraceLog("L-SHC-4423: Sent msg ID[%s] /m%04d/t%d/p%06d to %s\n",
				thisHeader->msg.shclog_id, thisHeader->msg.msgtype, thisHeader->msg.trace,
				thisHeader->msg.pcode, mbMailBoxName(outbound));
                }
        }
	else if (cache_mb_write(outbound, shcmid, (char *)&thisHeader->msg, totallen) < 0)
	{
		OTraceLog("L-SHC-4417: Failed to send msg ID[%s] /m%04d to %s\n",
			thisHeader->msg.shclog_id, thisHeader->msg.msgtype, mbMailBoxName(outbound));
		return(-1);
	}
	else
		OTraceLog("L-SHC-4418: Sent msg ID[%s] /m%04d to %s\n",
				thisHeader->msg.shclog_id, thisHeader->msg.msgtype, mbMailBoxName(outbound));

	if( ! (flags & SH_IGNORE) ) 
		thisShcApp->shcmsgHelperObj->shc_debug_route(&thisHeader->msg, outbound);

	return( 0 );

}

int Shc300Helper::adjustTimer(Shc300Header *header)
{
	/*	adjust timers to wait longer */
	if (header->time_in >=10000000000)
		header->time_out = header->time_in + 1000*thisShcApp->shcParams.getInst(header->issShcBin->binPkg->bin.institutionid)->GetNum((char *)"shc.03xxtimer");
	else
		header->time_out = header->time_in + thisShcApp->shcParams.getInst(header->issShcBin->binPkg->bin.institutionid)->GetNum((char *)"shc.03xxtimer");
	return 0;
}
int Shc300Helper::setDefaultTranDate(ShcmsgHeader *header)
{
	if(header->msg.trandate == 0)
	{
		header->msg.trandate = shc_gmt_currentdate();
		header->msg.trantime = shc_gmt_currenttime();
	}
	return 0;
}


int Shc300Helper::getEvent(ShcmsgHeader *header)
{
	struct ShcmsgWithSegment omsg = { 0 };
	if(thisShcApp->shcTimerObj->shc_locate_event_x(header,&(omsg.msg),(unsigned char *)omsg.segmentData)<0)
	{
		OTraceError("E-SHC-4416:Unable to locate 03xx event trace(%ld)\n",
			header->msg.trace);
		header->setIgnoreFlag();
		return(-1);
	}

	header->allocateAndCopyReqMsg(&omsg.msg);
	tm_dequeue(header->eventId);

	return 0;
}
