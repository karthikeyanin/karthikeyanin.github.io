/*
 *  Copyright (C) 2004 eFunds Corporation ("eFunds").  All Rights Reserved.
 *  eFunds Canada Corporation is an authorized user.
 *
 *  IST is a registered trademark of eFunds Corporation.  Other brand or
 *  product names are trademarks or registered trademarks of their respective
 *  holders.
 *
 *  The information contained herein is the unpublished proprietary property
 *  of eFunds.  Except as specifically authorized in writing by eFunds, the
 *  holder of this document shall: i) keep all information contained herein
 *  confidential, and ii) protect the information, in whole or in part, from
 *  disclosure and dissemination to all third parties.
 *
 *  This document and the software described in it are furnished under license
 *  and may be used or copied only in accordance with the terms of such license.
 *  This document is supplied for information purposes only, is subject to
 *  change without notice, and should not be construed as a commitment by
 *  either eFunds Corporation or eFunds Canada Corporation.
 *
 *
 *
 *                        MODIFICATION HISTORY                  REVIEW
 *
 *	SPR#	Who	Date	Description			Who	Date
 * ===========================================================================
 *	R020052	spa	21May07	New file created
 *	R020938	spa	16Aug07	IST LM Bridge support
 *  R023105	sel 13May08 LM message routing between nodes
 *	R023574	lee	11Jun08	Marking bin down if LM Timeout
 *	R024019	sks	23Jul08 Check the return value of tm_dequeue() in Event Processing
 *	R025639 vmp	16Jan09	Changes made for FM PhaseII enhancement
 *	R027876 dipa 02Mar10 Segment changes
 *	R027876 dipa 22Apr10 Segment changes - fix
 *	R028104 dipa 29Apr10 routingInfo - fix
 *      R160740849 IS 19Jul17 To overcome warning messages in debug files by passing of the real buffer  length instead of zero
 */

/* File Number 155 */
static char _ShcmsgFMEvent_cxx_what[] = "@(#) ShcmsgFMEvent.cxx 1.11.2.2 16/10/21 08:08:27";

#include <ShcmsgEvent.h>
#include <ShcmsgFMEvent.h>
#include <ShcmsgTxnHelper.h>
#include <ShcApp.h>
#include <ShcBin.h>
#include <ShcmsgHelper.h>
#include <ShcmsgFMHelper.h>
#include <ShcTimerHelper.h>
//	>>>	R023105
#include <ShcmsgHeader.h>
#include <ShcMsgCache.h>
#include <BinRoute.h>
//	<<<	R023105
#include <ist_seg_name.h> //R027876
#include <ist_seg_elf_id_map.h> //R027876
#include <ist_seg_id.h> //R027876
#include <ist_seg_pdt_base.h> //R027876
#include <TxnStatSource.h>
#include <TxnStatReason.h>
#include <TxnStat.h>


int ShcmsgFMEvent::enrich()
{
	return 0;
}

int ShcmsgFMEvent::edit()
{
	return 0;
}

int ShcmsgFMEvent::verify()
{

//	struct FM_seg_data *fmData = NULL;
//	int fmDataLen;
	IstSegPdtBase *fmData; //R027876

	struct ShcmsgWithSegment timerBuf;

	int origmti = header->msg.msgtype;

	//	>>>	R024019
	//tm_dequeue(header->eventId);
	if (tm_dequeue(header->eventId) < 0 )
	{
		OTraceDebug("D-SHC-155008:Event not removed properly from queue ,message dropped \n");
		header->shcerr = SH_IGNORE;
		header->setIgnoreFlag();

		TxnStatReport(header->msg.shclog_id,  TS_SHC,TSR_DROP,header->msg.msgtype,0,mbLastSenderId());
		return 0;
	}
	//	<<<	R024019

	OTraceDebug("D-SHC-155001:FM msgtype [%d] flipped back to original msgtype [%d]\n",
		header->msg.msgtype, header->msg.flipped_msgtype);
	header->msg.msgtype = header->msg.flipped_msgtype;

	header->reqMsg = NULL;
	header->origMsg = NULL;

	//	>>>	R020938
	if(origmti == SHC_FM_REQ)
	{
		// R027876 >>>
		fmData = (IstSegPdtBase *)header->getSegmentObj(ElfIdMap::elf_to_id(IST_SEG_FM));
		if (fmData)
			OTraceDebug("D-SHC-155004:FM_SEG_DATA segment found\n");
		// <<< R027876

	}
	else if(origmti == SHC_LM_REQ)
	{
		// R027876 >>>
		fmData = (IstSegPdtBase*)header->getSegmentObj(ElfIdMap::elf_to_id(IST_SEG_LM));
		if (fmData)
			OTraceDebug("D-SHC-155005:LM_SEG_DATA segment found\n");
		// <<< R027876

	}
	//	<<<	R020938

	//	>>>	R023105
	ShcmsgFMHeader *thisHeader = (ShcmsgFMHeader *)header;
	int l;
	char buf[100];

	// R027876, R028104 >>>
	struct RoutingInfo r = {0};
	l = sizeof(struct RoutingInfo);
	header->getSegmentData((char *)&r, &l,  NETWORK_DATA_REQ_id, ROUTING_INFO);
	// <<< R027876, R028104

	if (l)
	{
		if (r.flag & (ROUTE_INFO_FLAG_USE_FOR_REQ | ROUTE_INFO_FLAG_USE_BINROUTE) &&
			(strcmp(r.destNode, mbcurrentnode)==0) &&
			(strcmp(r.destNode, r.srcNode)!=0))
		{
			//The req msg is sent across the node, so just send it back.
			if (mcastHelperObj->ready())
			{
				int outbound = mcastHelperObj->getMbID();
				int totallen = 0;
				char *tmpp = mcastHelperObj->createBroadcastMsg(0, (char *)&thisHeader->FMMsg, sizeof(thisHeader->FMMsg), r.srcNode, &totallen, r.srcSiteId);
				if (cache_mb_write(outbound, shcmid, tmpp, totallen) < 0)
				{
					OTraceLog("L-SHC-155006: Failed to send msg ID[%s] /m%04d/t%d/p%06d to %s\n",
					thisHeader->msg.shclog_id, thisHeader->msg.msgtype, thisHeader->msg.trace,
					thisHeader->msg.pcode, mbMailBoxName(outbound));
				}
			 	else
					 OTraceLog("L-SHC-155007: Sent msg ID[%s] /m%04d/t%d/p%06d to %s\n",
				thisHeader->msg.shclog_id, thisHeader->msg.msgtype, thisHeader->msg.trace,
			 	thisHeader->msg.pcode, mbMailBoxName(outbound));
		 	}
			 return 0;
	 	}
	 	r.flag = 0;    //Clear the flag in ROUTINGINFO segment
		thisHeader->setSegmentData((char*)&r, sizeof(r), NETWORK_DATA_REQ_id, ROUTING_INFO); //R027876, R028104

 	}
	//	<<<	R023105


	if(fmData)
	{
		// R027876 >>>
		// >>> R160740849
		memset(buf, 0x00, sizeof(buf)); l=sizeof(buf);
		//fmData->getReqEventId(buf,&l);
		//if(l)
		if (fmData->getReqEventId(buf,&l) == IST_RET_OK)
		{
			if( tm_getdata(atoi(buf), (char *)&timerBuf, sizeof(timerBuf)) > 0)
			{
				header->allocateAndCopyReqMsg(&(timerBuf.msg));
				OTraceDebug("D-SHC-155002: reqmsg restored from FM event\n");
			}
			tm_dequeue(atoi(buf));
		}

		memset(buf, 0x00, sizeof(buf)); l=sizeof(buf);
		//fmData->getOrigEventId(buf,&l);
		//if(l)
		if (fmData->getOrigEventId(buf,&l) == IST_RET_OK)
		{
			if( tm_getdata(atoi(buf), (char *)&timerBuf, sizeof(timerBuf)) > 0)
			{
				header->allocateAndCopyOrigMsg(&(timerBuf.msg));
				OTraceDebug("D-SHC-155003: origmsg restored from FM event\n");
			}
			tm_dequeue(atoi(buf));
		}

		memset(buf, 0x00, sizeof(buf)); l=sizeof(buf);
		if (fmData->getFlippedMsgType(buf,&l) == IST_RET_OK)
			header->msg.flipped_msgtype = atoi(buf);

		memset(buf, 0x00, sizeof(buf)); l=sizeof(buf);
		if (fmData->getLogFlag(buf,&l) == IST_RET_OK)
			header->logFlag = atoi(buf);

		memset(buf, 0x00, sizeof(buf)); l=sizeof(buf);
		if (fmData->getRepeatFlag(buf,&l) == IST_RET_OK)
			header->repeatFlag = atoi(buf);

		memset(buf, 0x00, sizeof(buf)); l=sizeof(buf);
		if (fmData->getShcerr(buf,&l) == IST_RET_OK)
			header->shcerr = atoi(buf);

		memset(buf, 0x00, sizeof(buf)); l=sizeof(buf);
		if (fmData->getTxnIn_time(buf,&l) == IST_RET_OK)
			header->time_in = atol(buf);

		memset(buf, 0x00, sizeof(buf)); l=sizeof(buf);
		if (fmData->getTxnOut_time(buf,&l) == IST_RET_OK)
			header->time_out = atol(buf);
		// <<< R160740849
		// <<< R027876

	}

	// clarify whether procFlag or skipFlag
	header->setSkipFlag(TXN_PROC_SKIP_ENRICH | TXN_PROC_SKIP_RESTORE | TXN_PROC_SKIP_EDIT | TXN_PROC_SKIP_VERIFY);

	if(!shcmsgFMHelperObj)
		shcmsgFMHelperObj = new ShcmsgFMHelper;

	//	>>>	R020938
	//check for shc.DenyonLMtimeout parameter

	if(origmti == SHC_LM_REQ)
	{
		if(shcmsgFMHelperObj->getShc_denyOnLMtimeout())
		{
			header->msg.respcode = SHC_RC_Declined_On_LMTimeout;	//151
	    	header->logFlag |= SHC_LOG_UPD_REQ;
	    	header->setSkipFlag(TXN_PROC_SKIP_DOWORK);
	    	header->shcerr = SH_RETURN;
	    	shcApp->shcmsgHelperObj->shc_set_return_msgno(&header->msg);
		}
		else
			header->msg.auth_devcap |= SH_DEVCAP_AUTH_LMTimeout;//continue on LM timeout
	}

		//	>>>	R023574
		//	>>>	R025639
	else if(origmti == SHC_FM_REQ)
	{
		if(shcmsgFMHelperObj->getShc_denyOnFMtimeout())
		{
			header->msg.respcode = SHC_RC_Declined_On_FMTimeout;	//153
			header->logFlag |= SHC_LOG_UPD_REQ;
			header->setSkipFlag(TXN_PROC_SKIP_DOWORK);
			header->shcerr = SH_RETURN;
			shcApp->shcmsgHelperObj->shc_set_return_msgno(&header->msg);
		}
		else
		header->msg.auth_devcap |= SH_DEVCAP_AUTH_FMTimeout;//continue on FM timeout
	}
	//	<<<	R025639
	//	>>>	R023574
	struct RoutingInfo s = {0};
	// R027876, R028104 >>>
	int len = sizeof(struct RoutingInfo);
	header->getSegmentData((char *)&s, &len, NETWORK_DATA_REQ_id,ROUTING_INFO);
	// <<< R027876, R028104
	if (len)
	{
		binRouteObj->markRouteDown(NULL, &s, NULL);
		binRouteObj->tidyUpBinStatus();
	}

		//	<<<	R023574
	//	<<<	R020938

	shcmsgFMHelperObj->enqueueInternalMsg((ShcmsgFMHeader *)header);

	header->shcerr = SH_IGNORE;
	header->logFlag = 0;

	return 0;
}




int ShcmsgFMEvent::doWork()
{
	return 0;
}

