static char _ShcChargeBackHelper_cxx_what[] = "@(#) ShcChargeBackHelper.cxx 1.9 16/05/10 12:20:13";

/*
 *  Copyright (C) 2004 eFunds Corporation ("eFunds").  All Rights Reserved.     
 *  eFunds Canada Corporation is an authorized user.                            
 *                                                                              
 *  IST is a registered trademark of eFunds Corporation.  Other brand or        
 *  product names are trademarks or registered trademarks of their respective   
 *  holders.                                                                    
 *                                                                              
 *  The information contained herein is the unpublished proprietary property    
 *  of eFunds.  Except as specifically authorized in writing by eFunds, the     
 *  holder of this document shall: i) keep all information contained herein     
 *  confidential, and ii) protect the information, in whole or in part, from    
 *  disclosure and dissemination to all third parties.                          
 *                                                                          
 *  This document and the software described in it are furnished under license  
 *  and may be used or copied only in accordance with the terms of such license.
 *  This document is supplied for information purposes only, is subject to      
 *  change without notice, and should not be construed as a commitment by       
 *  either eFunds Corporation or eFunds Canada Corporation. 
 *
 *
 *
 *                        MODIFICATION HISTORY                  REVIEW
 *
 *	SPR#	Who	Date	Description			Who	Date   
 * ===========================================================================
 * R0xxxxx jyang 21Nov03 Created
 */

//File Number 65

#include <ShcRevReqHelper.h>
#include <ShcChargeBackHelper.h>
#include <ShcApp.h>
#include <ShcBin.h>
#include <ShcSaf.h>
#include <CShcLog.h>


int ShcChargeBackHelper::setReplayRoutingFlag(ShcmsgHeader *header)
{
	/* 13Jul93 */
	/* if issuer was down when reversal was issued for preauth */
	if(shcIsPreAuthReq(header) && !shcmsgHeaderPreauthReversalAllowed(header))
		header->shcerr = SH_IGNORE;
	else 
	{														/* 27may97  */
		OTraceInfo("I-SHC-065001: Sending Charge Back to Acquirer\n"); /* 27may97  */
		header->shcerr = SH_SENDACQ | SH_SETTIMER;			/* 27may97  */
	}
	
	return 0;
}


int ShcChargeBackHelper::setNormalRoutingFlag(ShcmsgHeader *header)
{
	OTraceDebug("D-SHC-065002: Sending Charge Back to Acquirer\n"); /* 27may97  */
	header->shcerr = SH_SENDACQ | SH_SETTIMER;			/* 27may97  */

	return 0;
}


/*****************************************************************************/
int ShcChargeBackHelper::prepareRespLogMessage(ShcmsgHeader *header)
{
	int		logresponse = True;	//, useresponse = True;
	ShcmsgHeader tmpShcmsgHeader(*header);
//	int		save_msgno, orig_found = False;
	
//	Following function removed
//	logresponse = thisShcApp->shcRevRespHelperObj->prepareRespLogMessage(revTxn, header);
	
	/*
	 *	If the we have already posted a 410/430 then do NOT update
	 *	with current 430 values
	 *	this might be duplicate
	 */
	if(((ShcLog *)header->shcLogObj)->locateTxn(header, &(tmpShcmsgHeader.msg), NULL) >= 0)
	{
		if(shcmsgIsResponse(&(tmpShcmsgHeader.msg)))
			logresponse = False;
		else						/* 26apr95 */
			logresponse = True;		/* 26apr95 */
	}
	
	return logresponse;
}


/*****************************************************************************/

int ShcChargeBackHelper::doReplay(ShcmsgHeader *header)
{
	/* If coming from replay task then we should just route it */
	if(! (header->msg.device_cap & SH_DEVCAP_FROM_REPLAY) )
		return False;

	OTraceDebug("D-SHC-065003:  Replay transaction\n");
	if (header->time_in>10000000000)
		header->time_out = header->time_in + 1000*shcApp->issuerShcParamsList->GetNum((char *)"shc.saf_timeout");
	else
		header->time_out = header->time_in + shcApp->issuerShcParamsList->GetNum((char *)"shc.saf_timeout");

	setReplayRoutingFlag(header);
	
	return True;
}

/*****************************************************************************/

int ShcChargeBackHelper::routeReversal(ShcmsgHeader *header, int omsg_is_saf)
{
	/* D E T E R M I N E    W H E R E   T O   S E N D   T R X N . */

	OTraceDebug("D-SHC-065004:route reversal\n");

	thisShcApp->shcRevReqHelperObj->returnReqAcqFirst(header, omsg_is_saf);
	
	/* Reverse transaction amount if the transaction was done in stfwd */
	if(omsg_is_saf)
		thisShcApp->shcSafHelperObj->shc_saf_rev(header);
	
	/*
	 *	The original did approve
	 *	We must now format the request to the host and
	 *	ask for a reversal
	 */
	/* 17aug93 */
	if(!shcIsReversal(header))
		header->msg.msgtype = SHC_REVREQ;

	if (  ( (header->msg.shcerror == SHC_IE_NoMatch) ||   /*1002864*/
		    (header->msg.respcode == SHC_RC_NoOriginal) ) /*1002864*/
		&& !(shcApp->acquirerShcParamsList->GetBool((char *)"shc.sendIss_420NoOrig"))    )     /*1002864*/
	{													  /*1002864*/
		OTraceInfo("I-SHC-065005:sendIss_420NoOrig is 0, rev with no orig not send to iss\n");
		header->shcerr = SH_IGNORE;						  /*1002864*/
	}													  /*1002864*/
	else if((shc_isdown(header->issShcBin->binPkg))||
			(shcIsRevIssReq(header) && header->acqShcBin->isInterac())||
			omsg_is_saf)
	{
		/*	Write the transaction to the store forward file */
		thisShcApp->shcSafHelperObj->shc_saf(header);
		header->shcerr = SH_IGNORE;				/* 10002113 */	/* 10001856 */
	}
	else
	{
		/* 13Jul93 */
		if(shcIsPreAuthReq(header) && !shcmsgHeaderPreauthReversalAllowed(header))
		{
			header->msg.respcode = 0;
			thisShcApp->shcRevReqHelperObj->returnReversal(header);
		}
		else
			setNormalRoutingFlag(header);
			
		return True;
	}

////	/*
////     * Route the settlement transaction 
//// 	 */
//// empty function:	shc_route_settlement(header);

	return False;
}
