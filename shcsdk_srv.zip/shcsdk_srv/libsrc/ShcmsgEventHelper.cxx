static char _ShcmsgEventHelper_cxx_what[] = "@(#) ShcmsgEventHelper.cxx 1.34.2.11 20/02/10 07:34:44";

/*
 *  Copyright (C) 2004 eFunds Corporation ("eFunds").  All Rights Reserved.     
 *  eFunds Canada Corporation is an authorized user.                            
 *                                                                              
 *  IST is a registered trademark of eFunds Corporation.  Other brand or        
 *  product names are trademarks or registered trademarks of their respective   
 *  holders.                                                                    
 *                                                                              
 *  The information contained herein is the unpublished proprietary property    
 *  of eFunds.  Except as specifically authorized in writing by eFunds, the     
 *  holder of this document shall: i) keep all information contained herein     
 *  confidential, and ii) protect the information, in whole or in part, from    
 *  disclosure and dissemination to all third parties.                          
 *                                                                          
 *  This document and the software described in it are furnished under license  
 *  and may be used or copied only in accordance with the terms of such license.
 *  This document is supplied for information purposes only, is subject to      
 *  change without notice, and should not be construed as a commitment by       
 *  either eFunds Corporation or eFunds Canada Corporation. 
 *
 *
 *
 *                        MODIFICATION HISTORY                  REVIEW
 *
 *	SPR#	Who	Date	Description			Who	Date   
 * ===========================================================================
 * R0xxxxx jyang 09Dec03 Created
 *R011925 jyang 16Sep04 SAF Interleave Merged R011312
 *R016037 pve	22Mar06	Log time-out reversal message
 *R018276 pve	27Nov06	Add new OTraceLog messages
 *R021469 emj   25Sep07 Removed EMV buf for internal generate 420 for interac
 *R021843 bby   01Nov07 clone from R019906 and R021767
 *R024473 Ash   03Sep08 Enable Timer for REPEAT Messages
 *R027060 dipa  18Aug09 Enable SAFing for preauth completion txn(120 with pcode 11)
 *R027320 dipa  19Nov09 Include 121/221 txns in handling timeout txns
 *R027876 dipa  02Mar10 Segment changes
 *R027963 dipa  19Mar10 Handle advice timeout
 *R027959 dipa  23Mar10 Handle advice timeout - more changes
 *R028271 dipa  18Jun10 Txn Statistics 
 *R030381 dipa  02Mar12 Txn Statistics 
 *R030455 dipa  04Apr12 Do not insert DB record if reversal is already replied to acq by SHC
*/

//File Number 95

#include <stdio.h>
#include <oasis.h>
#include <mb.h>
#include <tm.h>
#include <ist_otrace.h>
#include <shc.h>
#include <shcerror.h>	 	/* 27May93 Included for response code def. */ 

#include <CShcLog.h>
//#include "shc_util_funcs.h"

#include <ShcmsgBaseTxn.h>
#include <ShcNetworkMsgHelper.h>
#include <ShcmsgEventHelper.h>
#include <ShcmsgHelper.h>
#include <ShcFinAuthHelper.h>
#include <ShcRevReqHelper.h>
#include <ShcApp.h>
#include <mb_umi.h>
#include <ShcBin.h>
#include <ShcmsgTxnHelper.h>
#include <ShcSafIOHelper.h>
#include <shc_callback.h>
#include <ShcLateRespHelper.h>
#include <ShcTimerHelper.h>		//	--- R024473
#include <ist_seg_name.h> //R027876
#include <ist_seg_elf_id_map.h> //R027876
#include <ist_seg_id.h> //R027876
#include <istsafe.h>
#include <BinRoute.h>

//R028271 >>>
#include <TxnStat.h>
//<<< R028271

int ShcmsgEventHelper::restoreOldPINBlock(ShcmsgHeader *header)
{
	char oldPin[SHC_PIN_LEN]; //R027876
	int oldPinLen = 0;

	// R027876 >>>
	memset(oldPin, 0x00, sizeof(oldPin));
	header->getSegmentData(oldPin, &oldPinLen, ElfIdMap::elf_to_id(IST_SEG_NETWORK_DATA_REQ),ISO_PIN);
	if (oldPinLen)
	{
		memcpy(header->msg.pin, oldPin, sizeof(header->msg.pin));
		memset(oldPin, 0x00, sizeof(oldPin)); oldPinLen = 0;
		header->setSegmentData(oldPin, oldPinLen, ElfIdMap::elf_to_id(IST_SEG_NETWORK_DATA_REQ),ISO_PIN);
	}
	// <<< R027876
	return 0;

}

int ShcmsgEventHelper::retryOnTimeout(ShcmsgHeader *header, ShcBin *shcBin)
{
	if(!shc_isdown(shcBin->binPkg) && (shcBin->binPkg->saf.type & SH_SAF_TIMEOUT_RETRY))
	{
		//	 down so convert to a repeat
		int msgType = 0;
		switch( header->msg.msgtype )
		{
		case SHC_FINREQ : 
			msgType = SHC_FINREQ_REPEAT;
			break;
		case SHC_AUTHREQ :
			msgType = SHC_AUTHREQ_REPEAT;
			break;
		case SHC_REVREQ :
			msgType = SHC_REVREQ_REPEAT;
			break;
		default:
			msgType = -1;
			break;
		}
		
		if ( msgType > 0 )
		{
			header->shcerr = SH_SENDISS | SH_SETTIMER;
			header->msg.msgtype = msgType;
			thisShcApp->shcTimerObj->shc_set_timers(header);	//	---		R024473
			return True;
		}
	}
	return False;
}

extern int g_failed_posauth;
int ShcmsgEventHelper::procAdviceEvent(ShcmsgHeader *header, ShcBin *shcBin)
{
	/*
	 *	Handle a timed out SAF message
	 */
	int		return_txn = 1;		/** 14dec92 **/

	/*
	 *	Already timed out once
	 */
	if(shc_isdown(shcBin->binPkg))
	{
		/*
		 *	Either down or down and in replay, Ignore this message
		 */

		/*
		*	19Jul93
		*		Change the if statement, does not make sense.
		*		Should check if in replay and time out on message mark down,
		*		then
		*			send 800 message to stop shcreplay.
		*/
		if((shcBin->binPkg->bin.flags & SH_REPLAY)&&(shcBin->binPkg->saf.type & SH_SAF_FORCE_DOWN))
		{
			/*	if in replay but not being forced down we should do so now */
			thisShcApp->shcNetworkMsgHelperObj->shc_markdown(header, shcBin);
		}
		
		/* 19Jul93
		*	If I am replaying txn and txn originated from replay,
		*	do not log txn in saf file again.
		*/
		if((shcBin->binPkg->bin.flags & SH_REPLAY) && (header->msg.device_cap & SH_DEVCAP_FROM_REPLAY))
			return_txn = 0;

		header->shcerr = SH_IGNORE;
	}

    /*
     * R001835 Stop ISTREPLAY for issuer bin once advice time out
     */
     if(header->msg.device_cap & SH_DEVCAP_FROM_REPLAY)
     {
        OTraceInfo("I-SHC-095001: Stop Replay for %s\n", header->issShcBin->binPkg->bin.networkid);
        
        //-R011925- Comment below lines for not sending 0800 message out
        //thisShcApp->shcNetworkMsgHelperObj->shc_stopreplay(header, shcBin);
        header->shcerr = SH_IGNORE;
        return_txn = 0;
     }


	/****			CHANGED ON 17Aug93		****/
	if( return_txn && ( shc_safallowed(header->issShcBin->binPkg)
	/* 961108 */
	|| !( header->issShcBin->binPkg->bin.flags & SH_GETAPP_HOST ) 
	|| (shcmsgIsPreAuthConfReq(&header->msg)) ) ) //R027060
	{
		/*
		 *	If here then we must answer the transaction
		 */
		
		/* 10002243 */
		if( header->msg.device_cap & SH_DEVCAP_FROM_REPLAY )
			header->msg.respcode = SHC_RC_IssuerDown;
		else
		{
			// R027060 >>>>
			if (shcmsgIsPreAuthConfReq(&header->msg) && (header->issShcBin->binPkg->saf.type & SH_SAF_NOFILE))
			{
				OTraceInfo("I-SHC-095001.1: Turn OFF SH_SAF_NOFILE for %s\n", header->issShcBin->binPkg->bin.networkid);
				header->issShcBin->binPkg->saf.type &= ~SH_SAF_NOFILE;
			}
			// <<<< R027060

			//R027959 >>>
			if (((header->msg.msgtype==SHC_AUTHREQ_ADVICE) || (header->msg.msgtype==SHC_FINREQ_ADVICE) ||
				(header->msg.msgtype==SHC_AUTHREQ_ADVICE_REPEAT) || (header->msg.msgtype==SHC_FINREQ_ADVICE_REPEAT))
				&& (header->issShcBin->binPkg->bin.flags & SH_GETAPP_HOST)
				&& (!shcmsgIsPreAuthConfReq(&header->msg)))
			{
				// Do not SAF the message when shc denies or drops the advice request txn
			}
			else
			{
				header->msg.saf = SH_SAF_PENDING;
				thisShcApp->shcSafHelperObj->shc_general_saf_write(NULL, header, 0);
			}
			// <<< R027959

			/*	I can never have a balance at this point */

			/*
			 * 2002693  Special processing for 420
		     */
			if((header->msg.msgtype == SHC_REVREQ_ADVICE) ||
			  (header->msg.msgtype == SHC_AUTHREQ_ADVICE) || 	//	---	R021843
			  (header->msg.msgtype == SHC_FINREQ_ADVICE) ||		//	---	R021843 
			  (header->msg.msgtype == SHC_AUTHREQ_ADVICE_REPEAT) ||		//R027320
			  (header->msg.msgtype == SHC_FINREQ_ADVICE_REPEAT) ||		//R027320
			   (header->msg.msgtype == SHC_CHARGE_BACK_ADVICE)) /* 27may97 */
			{
				if(!(header->issShcBin->binPkg->bin.flags & SH_GETAPP_HOST))
				{
					OTraceInfo("I-SHC-095002: Ignore time out %d\n", header->msg.msgtype);
													/* R007676 >> */
					thisShcApp->shcmsgHelperObj->shc_set_return_msgno(&header->msg);
					if( shcBin->binPkg->saf.type & SH_SAF_POSFILE )	
					{
						header->msg.respcode = SHC_RC_Approved;
						if (!g_failed_posauth)
							thisShcApp->shcmsgTxnHelperObj->shc_posauth(header, 0 );
					}
													/* R007676 << */
					header->shcerr = SH_IGNORE;
					OTraceInfo("I-SHC-8810.1: Timeout. RevToIss=N - Update [%d] to response w/ approved\n",
								header->msg.msgtype);
					header->msg.respcode = SHC_RC_Approved; //R027959
					header->logFlag |= SHC_LOG_UPD_REQ; //R027959

					return(0);
				}
				
				//	>>>	R021843	
				else if ((header->msg.msgtype==SHC_AUTHREQ_ADVICE) ||
				(header->msg.msgtype==SHC_FINREQ_ADVICE) ||
				(header->msg.msgtype==SHC_AUTHREQ_ADVICE_REPEAT) || //R027320
				(header->msg.msgtype==SHC_FINREQ_ADVICE_REPEAT)) //R027320

				{
					// R027959 >>>
					if ( shcApp->issuerShcParamsList->GetBool( ( char * )"shc.decline_advice_when_timeout_issdown" ) )
					{
						OTraceError("I-SHC-8810.2: Issuer Timeout and no SAF\n");
						//header->shcerr = SH_IGNORE;
						thisShcApp->shcFinAuthHelperObj->shc_return_finauth(header, SHC_RC_IssuerTimeout);
						//thisShcApp->shcmsgHelperObj->shc_set_return_msgno(&header->msg);
						//header->msg.respcode = SHC_RC_IssuerTimeout;
						//header->logFlag |= SHC_LOG_UPD_REQ;
						return( 0 );
					}
					else if (shcmsgIsPreAuthConfReq(&header->msg))
					{
						OTraceInfo("I-SHC-8810.1: Timeout. RevToIss=Y - Preauth completion txn - Ret approved[%d] to acq\n",
									header->msg.msgtype);
						header->logFlag |= SHC_LOG_UPD_REQ;
						thisShcApp->shcmsgHelperObj->shc_set_return_msgno(&header->msg);
						header->msg.respcode = SHC_RC_Approved;
						header->shcerr = SH_RETURN;
						return(0);
					}
					else
					{
						OTraceInfo("I-SHC-8810.1: Timeout. RevToIss=Y - Update [%d] to response w/ issuer timeout\n",
									header->msg.msgtype);
						header->shcerr = SH_IGNORE;
						thisShcApp->shcmsgHelperObj->shc_set_return_msgno(&header->msg);
						header->msg.respcode = SHC_RC_IssuerTimeout;
						header->logFlag |= SHC_LOG_UPD_REQ;
						return(0);
					}	
					// <<< R027959
				}
				//	<<<	R021843
				
				else
				{
					OTraceInfo("I-SHC-095003: Return Time out %d\n", header->msg.msgtype);
					header->msg.respcode = SHC_RC_IssuerTimeout;
					header->msg.revcode = SHC_RR_TimeOut;
					header->shcerr |= SH_NOREVUPD;
					thisShcApp->shcRevReqHelperObj->returnReversal(header);
					header->logFlag |= SHC_LOG_UPD_REQ;
				}
			}
			else
			{
				thisShcApp->shcFinAuthHelperObj->shc_return_finauth(header, -1);
			}
		}

		header->msg.shcerror = SHC_IE_NoBalance;
	
		/* 961108 */
		if( !(header->issShcBin->binPkg->bin.flags & SH_GETAPP_HOST )
			&& shcIsReversal(header)					/* R007676 */
			&& header->shcerr == SH_RETURN )
		{
			header->shcerr = SH_IGNORE;
		}
//		else
//		{
//	        if( thisShcApp->shcmsgTxnHelperObj->enqueueInternalMsg(header) == NULL )
//	        	OTraceError("E-SHC-095004: Unable to enqueueInternalMsg() in ShcmsgEventHelper::procAdviceEvent()\n");
//      }
		thisShcApp->shcmsgHelperObj->shc_route(header);
		
							/* R007620,7676 >> */
		if( shcBin->binPkg->saf.type & SH_SAF_POSFILE )	
		{
			header->msg.respcode = SHC_RC_Approved;
			if (!g_failed_posauth)
				thisShcApp->shcmsgTxnHelperObj->shc_posauth(header, 0 );
		}
							/* R007620,7676 << */

		header->shcerr = SH_IGNORE;
	}
	//R027963 >>>
	else
	{
		if (!(header->msg.device_cap & SH_DEVCAP_FROM_REPLAY)) //R027959 
		{
			// Timedout advice message w/o SAF. Just set the respcode to timeout and update SHCLOG record to response
			OTraceInfo("I-SHC-8810.1: Timeout. Update [%d]/[%s] to response w/ issuer timeout\n",header->msg.msgtype,header->msg.shclog_id);
			header->shcerr = SH_IGNORE;
			thisShcApp->shcmsgHelperObj->shc_set_return_msgno(&header->msg);
			header->msg.respcode = SHC_RC_IssuerTimeout; 
			header->logFlag |= SHC_LOG_UPD_REQ; 
		}
	}
	// <<< R027963

	if (header->time_in >=10000000000)
		header->time_out = header->time_in + 1000*shcApp->issuerShcParamsList->GetNum((char *)"shc.saf_timeout");
	else
		header->time_out = header->time_in + shcApp->issuerShcParamsList->GetNum((char *)"shc.saf_timeout");
	header->shcerr = SH_IGNORE; //R027959
	return(0);
}




int ShcmsgEventHelper::doPositiveAuth(ShcmsgHeader *header, ShcBin *shcBin, int timeout)
{
	if( ! (shcBin->binPkg->saf.type & SH_SAF_POSFILE) )
		return False;
	if( !shcIsReversal(header))
		generateInternalRev(header, shcBin);

	/*	set indicator to tell the world we are authorizing in S&F */
	header->msg.saf = SH_SAF_PENDING;

	/*	requires pos authorization */
	if (thisShcApp->shcmsgTxnHelperObj->shc_posauth(header, timeout) == -1)
	    thisShcApp->shcFinAuthHelperObj->shc_return_finauth(header, -1);
	 
 	OTraceInfo( "I-SHC-095005: Do not create SAF for request message.\n" );
	 	
	return True;
}


int ShcmsgEventHelper::generateInternalRev(ShcmsgHeader *header, ShcBin *shcBin)
{
	if( header->issShcBin->binPkg->bin.flags & SH_SENDREV_ALWAYS
		&& (((header->msg.merchant_type == 6011) && (header->msg.pcode / 10000 == SH_ISO_PINCHANGE)) 
		||(!(header->msg.txntype & (SH_TX_AUTHENTICATE|SH_TX_BAL))))	/* R008354 */
		&& header->msg.msgtype != SHC_AUTHREQ_REPEAT
		&& header->msg.msgtype != SHC_FINREQ_REPEAT
		&& header->msg.msgtype != SHC_REVREQ_REPEAT )
	{ 
		int	msgtype;
		int	save_device_cap;	/* R004165 Save the original device_cap */
		
		/*
		 * Save msgtype
		 */
		msgtype = header->msg.msgtype;
		char saveID[sizeof(header->msg.shclog_id)+1];
		//strcpy(saveID, header->msg.shclog_id);
		istsafe_strcpy(saveID, sizeof(saveID), header->msg.shclog_id);
		
		header->msg.msgtype = SHC_REVREQ_ADVICE;
		long    origdate;
		long    origtime;
		long    datebak;
		long    timebak;

		origdate = header->msg.origdate;
		origtime = header->msg.origtime;
		datebak = header->msg.trandate;
		timebak = header->msg.trantime;

		header->msg.trandate = shc_gmt_currentdate();
		header->msg.origdate = datebak;
		header->msg.trantime = shc_gmt_currenttime();
		header->msg.origtime = timebak;
		header->msg.origmsg = msgtype;

		mb_getUmi(header->msg.shclog_id, sizeof(header->msg.shclog_id));
		
		/* R004165 Move the code for R001319 to fix the bug for which */
		/*         messages are logged twice in shclog. */
		if(msgtype != SHC_REVREQ) /* R003895 Log a new one in this case */
		{
			save_device_cap = header->msg.device_cap;
			header->msg.device_cap |= SH_DEVCAP_INTERNALREV;
		}
		/* End R004165 */
		
		if(header->issShcBin->isCheckDupRev() 
		  && ((ShcLog *)header->shcLogObj)->locateTxn(header, NULL, NULL) == 0)
		{
			OTraceWarning("W-SHC-095006: Found duplicate reversals in database\n");
			OTraceInfo("I-SHC-095007: NOT Generate reversal\n");
		}
		else
		{
			OTraceInfo("I-SHC-095008: NO duplicate reversals in database\n");
			OTraceInfo("I-SHC-095009: Generate reversal\n");

			//	>>>	R018276
			if( header->origMsg )
				OTraceLog("L-SHC-095011: Created msg ID[%s]/m%04d/t%06ld/p%06ld from msg ID[%s]/m%04d/t%06ld/p%06ld\n",
					header->msg.shclog_id, header->msg.msgtype, header->msg.trace,
					header->msg.pcode, header->origMsg->shclog_id, header->origMsg->msgtype,
					header->origMsg->trace, header->origMsg->pcode);
			else
				OTraceLog("L-SHC-095012: Created msg ID[%s]/m%04d/t%06ld/p%06ld from msg ID[%s]\n",
					header->msg.shclog_id, header->msg.msgtype, header->msg.trace, header->msg.pcode, saveID);
			//	<<<	R018276

			//R028271 >>>
			mb_set_tid(header->msg.shclog_id, strlen(header->msg.shclog_id));
			TxnStatReport(header->msg.shclog_id,TS_SHC,TSR_CREATE,header->msg.msgtype,0,0);
			//<<< R028271

			header->msg.respcode = SHC_RC_IssuerTimeout;
			header->msg.revcode  = SHC_RR_TimeOut;
					/* R005129 >> */
			if(header->issShcBin->isInterac())
			{
				/* R021469 remove emvbuffer for internal generated reversal
				   for interac */
			   if (header->msg.device_cap & SH_DEVCAP_USER_SEGMENT)
			   {
				   	struct  shcseg          *segp;
				   	struct  shcsegstart     *sp;
				   	segp    = shcmsgLocateSegmentStart(&(header->msg));
				   	sp      = shc_segfind(segp, "EMV_BUF");
				   	if (sp != NULL)
				   	{
						strcpy(sp->type, "OLD_EMV_BUF");
					}
				}

				header->msg.origdate = header->msg.trandate;
				header->msg.origtime = header->msg.trantime;
			}
					/* R005129 << */
			if (shcLateRespHelperObj && shcLateRespHelperObj->processTimeOutReversal(header)>0)
			{
				//Nothing need to be done as late response server will take care of it
			}
			else
			{
			thisShcApp->shcSafHelperObj->shc_general_saf_write(header->issShcBin, header, 0);
			
			/* R003895 Restore before loogging in this case. */
			if(msgtype == SHC_REVREQ)
				header->msg.respcode = SHC_RC_Approved; 
			
			header->shcLogObj->logTxn(header);		//	R016037
			thisShcApp->shcmsgHelperObj->shc_set_return_msgno(&header->msg);
			header->msg.respcode = SHC_RC_Approved; /* R003895 */
			}
		}
		((ShcLog *)header->shcLogObj)->rewind();
		
		/* Restore msgtype */
		header->msg.msgtype = msgtype;
		snprintf(header->msg.shclog_id, sizeof(header->msg.shclog_id), "%s", saveID);
		header->msg.trandate = datebak;
		header->msg.trantime = timebak;
		header->msg.origdate = origdate;
		header->msg.origtime = origtime;
		
		/* R004165 Move the code for R001319 to fix the bug for which */
		/*         messages are logged twice in shclog. */
		if(msgtype != SHC_REVREQ) /* R003895 Restore the device_cap in this case */
		{
			header->msg.device_cap = save_device_cap;
		}
		/* End R004165 */
		
	}
	
	return 0;
}

int ShcmsgEventHelper::procFinAuthEvent(ShcmsgEvent *eventTxn, ShcmsgHeader *header)
{
	/*
	 *	An authorization request has timed out.
	 *	Attempt to authorize it
	 */
//	 int	reject_failed_posauth = False;		/* 17may95 */
	
	/*
	 *	This is a fresh request
	 *
	 *	o	Authorize and log
	 *	o	Reply to acquirer
	 *
	 *	NOTE:	Positive file authorizations should never get here
	 */

	thisShcApp->shcmsgEventHelperObj->generateInternalRev(header, eventTxn->shcBin);
		
//	/*	17may95 */
//	if(eventTxn->posauth_failed && shc_safallowed(header->issShcBin->binPkg) &&
//	   shcApp->issuerShcParamsList->getShcActionOnPosauthTimeout() != SHC_RC_Approved)
//		reject_failed_posauth = True;

									  /* 17may95 */
	if(shc_safallowed(header->issShcBin->binPkg))
	{
		thisShcApp->shcSafHelperObj->shc_saf(header, 'N');
	}
	else
	{
		header->msg.respcode = SHC_RC_IssuerTimeout;
		header->msg.revcode  = SHC_RR_TimeOut;
	}

   /* 
	* R001835
	*
	* SG added the line to stop the mac verification when
	*  message is routed internally 
	*/
	if(!(header->msg.device_cap & SH_DEVCAP_FROM_NETWORK))
			header->msg.device_cap|=SH_DEVCAP_INTERNALREV;

	thisShcApp->shcFinAuthHelperObj->shc_return_finauth(header, -1);

	/*	I can never have a balance at this point */
	header->msg.shcerror = SHC_IE_NoBalance;
//////	shc_route(header);
////// 
//////	/*	17nov92 */
//////	header->shcerr = SH_IGNORE;

	return(0);
}

int ShcmsgEventHelper::procRevEvent(ShcmsgHeader *header)
{
	/*
	 *	Handle a timed out reversal request
	 */
	
	/*
	 *	o	Put message in saf file
	 */

	/*	ad:	30Nov91		Have to check if already in file */
	ShcBin *shcBin;

	//if(!(header->msg.saf & SH_SAF_ALLOWED))
	if (header->issShcBin->binPkg->saf.type & SH_SAF_NOFILE)
	{
		header->msg.respcode = SHC_RC_IssuerTimeout;
		header->msg.revcode  = SHC_RR_TimeOut;
	}

	/*
	 *	o	Return to sender
	 */
	if(header->issShcBin->binPkg->bin.flags & SH_GETAPP_HOST)
	{
		header->shcerr |= SH_NOREVUPD;
		header->msg.respcode = SHC_RC_IssuerTimeout;
		header->msg.revcode  = SHC_RR_TimeOut;
	}

	//R030455 >>>
	if(header->msg.shc_devcap & SH_DEVCAP_SHC_MSG_REPLIED)
		header->shcerr |= SH_NOREVUPD;
	//R030455 <<<

	//Only need to write to saf if approved.
	if ((header->msg.respcode == SHC_RC_Approved) || (header->msg.respcode ==SHC_RC_PartialDispense))
	{
		shcBin = thisShcApp->shcSafIOHelperObj->shc_saf_determine_file(header);
		thisShcApp->shcSafHelperObj->shc_general_saf_write(shcBin, header, 1);
		thisShcApp->shcSafIOHelperObj->shc_saf_close_file(shcBin);
	}
	
	thisShcApp->shcRevReqHelperObj->returnReversal(header);
	
	/* 961108 */
	if( !(header->issShcBin->binPkg->bin.flags & SH_GETAPP_HOST )
	  && header->shcerr == SH_RETURN )
		header->shcerr = SH_IGNORE;
	
//////	shc_route(header);
//////
//////	header->shcerr = SH_IGNORE;		/*	23oct92 */

	return(0);
}

int ShcmsgEventHelper::checkAndSetBinDown(ShcmsgHeader *header, ShcBin *shcBin)
{
	/*	Decide what happens on time out  */
	if(shcBin->binPkg->saf.type & SH_SAF_FORCE_DOWN)
			/*	inst does not support interleave */
		{ /* R007950 */
			int numberTimeout = thisShcApp->acquirerShcParamsList->GetNum((char *)"shc.number_timeouts_markbindown");
			if(numberTimeout >0)
			{
				struct RoutingInfo routingInfo = {0};
				int len=sizeof(routingInfo);
				header->getSegmentData((char *)&routingInfo, &len, NETWORK_DATA_REQ_id,ROUTING_INFO);
				if(binRouteObj->checkTimeoutCounterVal(&routingInfo, numberTimeout)<0)
				{
					OTraceDebug("D-SHC-095001: max retry timeout count not reached[%d].Not marking-bin-down \n", numberTimeout);
					return 0;
				}
				else
				{
					OTraceDebug("D-SHC-095002: max retry timeout count reached[%d].marking-bin-down \n", numberTimeout);
				}
			}
			int callbackRet = shc_callback(header, "markdown_on_timeout");
			switch(callbackRet)
			{
			case SHCCALLBACKOVERRIDE:
				OTraceInfo("I-SHC-095010: Skipped as markdown_on_timeout callback function asked\n");
				break;
			case SHCCALLBACKDROP:
			case SHCCALLBACKCONTINUE:
			default:
				thisShcApp->shcNetworkMsgHelperObj->shc_markdown(header, shcBin);
			}
		}
	return 0;
}

int ShcmsgEventHelper::checkAndSetSafType(ShcmsgEvent *eventTxn, ShcmsgHeader *header, ShcBin *shcBin)
{
	/*
	 *	Determine if POS AUTH agent has timed out: If so
	 *	this indicates an IST/SHARE error since this task should have been
	 *	brought up.
	 *	Solution:
	 *		1.	Convert the transaction to negative authorization
	 *		2.	Attempt to authorize
	 *		3.	Log this error
	 */
	/* 14Jul93 */
	if(header->msg.saf == SH_SAF_PENDING && (shcBin->binPkg->saf.type & SH_SAF_POSFILE)
		&& !shcIsPreAuthConfReq(header) )
	{

		/*
		 *	Then we have already attempted to authorize
		 *	Temporarialy turn off postive authorization and re-authorize
		 */
		eventTxn->posauth_failed = 1;
//		shcBin->binPkg->saf.type &= ~SH_SAF_POSFILE;
//		shcBin->binPkg->saf.type |= SH_SAF_NEGFILE;

		/*
		 *	We should somehow log this event
		 */
	}
	return 0;
}

