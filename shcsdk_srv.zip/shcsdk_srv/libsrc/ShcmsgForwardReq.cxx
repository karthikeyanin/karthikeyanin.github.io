static char _ShcmsgForwardReq_cxx_what[] = "@(#) ShcmsgForwardReq.cxx 1.10.1.1 20/02/19 14:41:16";

/*
 *  Copyright (C) 2004 eFunds Corporation ("eFunds").  All Rights Reserved.     
 *  eFunds Canada Corporation is an authorized user.                            
 *                                                                              
 *  IST is a registered trademark of eFunds Corporation.  Other brand or        
 *  product names are trademarks or registered trademarks of their respective   
 *  holders.                                                                    
 *                                                                              
 *  The information contained herein is the unpublished proprietary property    
 *  of eFunds.  Except as specifically authorized in writing by eFunds, the     
 *  holder of this document shall: i) keep all information contained herein     
 *  confidential, and ii) protect the information, in whole or in part, from    
 *  disclosure and dissemination to all third parties.                          
 *                                                                          
 *  This document and the software described in it are furnished under license  
 *  and may be used or copied only in accordance with the terms of such license.
 *  This document is supplied for information purposes only, is subject to      
 *  change without notice, and should not be construed as a commitment by       
 *  either eFunds Corporation or eFunds Canada Corporation. 
 *
 *
 *                        MODIFICATION HISTORY                  REVIEW
 *
 *	SPR#	Who	Date	Description			Who	Date   
 * ===========================================================================
 *R00xxxx ztang 16Jan03 Creation
 *R028104 Dipa  29Apr10 routingInfo - fix
 *R028271 Dipa  18Jun10 Txn Statistics
 *R030381 Dipa  02Mar12 Txn Statistics
 */
/* File Number 150 */

#include <stdio.h>
#include <string.h>
#include <ctype.h>
#include <oasis.h>
#include <mb.h>
#include <ist_otrace.h>
#include <shc.h>
#include <shcdef.h>
#include <CShcLog.h>
#include <ShcmsgForwardReq.h>
#include <ShcMacHelper.h>
#include <ShcFinAuthHelper.h>
#include <ShcmsgHelper.h>
#include <ShcCamHelper.h>
#include <ShcmsgProcessor.h>
#include <ShcApp.h>
#include <ShcRetHelper.h>
#include <ShcMsgCache.h>
#include <ShcTimerHelper.h>

#include <ist_seg_name.h> //R027876
#include <ist_seg_elf_id_map.h> //R027876
#include <ist_seg_id.h> //R027876

//R028271 >>>
#include <TxnStat.h>
//<<< R028271

int ShcmsgForwardReq::enrich()
{
	processingDoneOnOtherNode = 1;
	return 0;
}


int ShcmsgForwardReq::edit()
{
	return(0);
}

	
int ShcmsgForwardReq::doWork()
{
	
	ShcmsgHeader *thisHeader = (ShcmsgHeader *)header;

    int mtype = thisHeader->msg.msgtype/10; //Get first two digit of msgtype
    if ((mtype == 10)||(mtype == 20)) 
    {
        //Do pin translation again before routing
        if (thisShcApp->shcFinAuthHelperObj->translatePinBlock(thisHeader) < 0)
        {
            OTraceInfo("I-SHC-:pin translation failed, deny\n");
	        header->shcerr = SH_IGNORE;
            return 0;
        }
    }

	// R028104 >>>
	struct RoutingInfo routingInfo = {0};
	int len = sizeof(struct RoutingInfo);
	thisHeader->getSegmentData((char *)&routingInfo, &len, NETWORK_DATA_REQ_id ,ROUTING_INFO);
	// <<< R028104

	if (len) 
	{
		int outbound = mb_locateoutbound(routingInfo.mailbox);
		
                if (outbound < 0)
                   outbound = mb_locatemailbox(routingInfo.mailbox);

		if (outbound >= 0)
		{
			int totallen = thisHeader->truelength();
			if (routingInfo.time_out > 0)
            {
				thisHeader->time_out = routingInfo.time_out;
				if(thisShcApp->shcTimerObj->shc_time_message_x( thisHeader, (unsigned char *)thisHeader->segment )< 0)
				{
					OTraceError("E-SHC-15000: Failed to Create Event ID[%s] /m%04d/t%d/p%06d  stop sending to %s\n",
						thisHeader->msg.shclog_id, thisHeader->msg.msgtype, thisHeader->msg.trace,
						thisHeader->msg.pcode, mbMailBoxName(outbound));
					TxnStatReport(thisHeader->msg.shclog_id,TS_SHC,TSR_DROP,DROP_MAILBOX_NOT_FOUND,0,0);
					header->shcerr = SH_IGNORE;
					return 0;
				}
            }
			if (cache_mb_write(outbound, shcmid, (char *)&thisHeader->msg, totallen)<0)
			{
				OTraceLog("L-SHC-15001: Failed to send msg ID[%s] /m%04d/t%d/p%06d to %s\n",
					thisHeader->msg.shclog_id, thisHeader->msg.msgtype, thisHeader->msg.trace,
					thisHeader->msg.pcode, mbMailBoxName(outbound));
			}
			else
				OTraceLog("L-SHC-15002: Sent msg ID[%s] /m%04d/t%d/p%06d to %s\n",
					thisHeader->msg.shclog_id, thisHeader->msg.msgtype, thisHeader->msg.trace,
					thisHeader->msg.pcode, mbMailBoxName(outbound));
	
			shcApp->shcmsgHelperObj->shc_dispmsg_x(&thisHeader->msg, 1, outbound);
			OTraceDebug("D-SHC-15002:The forward message is sent to[%s]\n", mbMailBoxName(outbound));
		}
		else
		{
			OTraceError("E-SHC-15001:Can't find mailbox[%s], message dropped\n", routingInfo.mailbox);
			//R028271 >>>
			TxnStatReport(thisHeader->msg.shclog_id,TS_SHC,TSR_DROP,DROP_MAILBOX_NOT_FOUND,0,0);
			//<<< R028271

		}	
	}
	else
	{
		OTraceError("E-SHC-15002:Can't find NETWORK_DATA_REQ:ROUTING_INFO segment\n");
	}	
	header->shcerr = SH_IGNORE;
	return 0;
}








