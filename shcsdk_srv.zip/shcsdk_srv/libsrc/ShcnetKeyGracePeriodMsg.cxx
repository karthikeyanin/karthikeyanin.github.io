static char _ShcnetEventMsg_cxx_what[] = "@(#) ShcnetKeyGracePeriodMsg.cxx 1.1 16/03/01 10:48:23";

/*
 *  Copyright (C) 2004 eFunds Corporation ("eFunds").  All Rights Reserved.     
 *  eFunds Canada Corporation is an authorized user.                            
 *                                                                              
 *  IST is a registered trademark of eFunds Corporation.  Other brand or        
 *  product names are trademarks or registered trademarks of their respective   
 *  holders.                                                                    
 *                                                                              
 *  The information contained herein is the unpublished proprietary property    
 *  of eFunds.  Except as specifically authorized in writing by eFunds, the     
 *  holder of this document shall: i) keep all information contained herein     
 *  confidential, and ii) protect the information, in whole or in part, from    
 *  disclosure and dissemination to all third parties.                          
 *                                                                          
 *  This document and the software described in it are furnished under license  
 *  and may be used or copied only in accordance with the terms of such license.
 *  This document is supplied for information purposes only, is subject to      
 *  change without notice, and should not be construed as a commitment by       
 *  either eFunds Corporation or eFunds Canada Corporation. 
 *
 *
 *                        MODIFICATION HISTORY                  REVIEW
 *
 *	SPR#	Who	Date	Description			Who	Date   
 * ===========================================================================
 *R00xxxx ztang 05Jan03	Creation
 */
/* File Number 167 */

#include <stdio.h>
#include <string.h>
#include <ctype.h>
#include <oasis.h>
#include <ist_otrace.h>
#include <shc.h>
#include <shcmsgdef.h>
#include <CShcLog.h>
#include <ShcSdkCommon.h>
#include <BusinessDay.h>
#include <ShcmsgHelper.h>
#include <ShcnetKeyGracePeriodMsg.h>
#include <ShcNetworkMsgHelper.h>
#include <ShcApp.h>
#include <ShcnetEventHelper.h>

int ShcnetKeyGracePeriodMsg::enrich()
{
	/*
	 *	Initialise the structures
	 */
	if(thisShcApp->shcmsgHelperObj->shcGetIssAcq(header, 0) == -1)
	{
		OTraceError("E-SHCNET-167001: Invalid network transaction: Code: %d issuer %s\n", 
			header->msg.respcode, header->msg.issuer);
		header->setIgnoreFlag();
		return(0);
	}
	header->shcerr = SH_IGNORE;

	OTraceInfo("I-SHCNET-167002:  Time-out Network Message:\n");
	OTraceInfo("          :    msgtype   : %04d\n", header->msg.msgtype);
	OTraceInfo("          :    netcode   : %d\n", header->msg.netcode);
	OTraceInfo("          :    trace     : %06ld\n", header->msg.trace);
	OTraceInfo("          :    originator: %s\n", header->msg.originator);
	OTraceInfo("          :    acquirer  : %s\n", header->msg.acquirer);



	return 0;
}
int ShcnetKeyGracePeriodMsg::edit()
{
	return 0;
}

int ShcnetKeyGracePeriodMsg::doWork()
{
	if (!header->shouldContinue(TXN_PROC_SKIP_DOWORK))
		return 0;
	thisShcApp->shcNetworkMsgHelperObj->processKeyGracePeriod(header);
	thisShcApp->shcmsgHelperObj->shc_set_return_msgno(&header->msg);
	header->shcerr = SH_IGNORE;

	return(0);
}










