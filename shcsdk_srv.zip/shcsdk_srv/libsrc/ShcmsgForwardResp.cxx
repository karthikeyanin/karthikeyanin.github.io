static char _ShcmsgForwardResp_cxx_what[] = "@(#) ShcmsgForwardResp.cxx 1.10.1.6 16/07/07 13:29:32";

/*
 *  Copyright (C) 2004 eFunds Corporation ("eFunds").  All Rights Reserved.     
 *  eFunds Canada Corporation is an authorized user.                            
 *                                                                              
 *  IST is a registered trademark of eFunds Corporation.  Other brand or        
 *  product names are trademarks or registered trademarks of their respective   
 *  holders.                                                                    
 *                                                                              
 *  The information contained herein is the unpublished proprietary property    
 *  of eFunds.  Except as specifically authorized in writing by eFunds, the     
 *  holder of this document shall: i) keep all information contained herein     
 *  confidential, and ii) protect the information, in whole or in part, from    
 *  disclosure and dissemination to all third parties.                          
 *                                                                          
 *  This document and the software described in it are furnished under license  
 *  and may be used or copied only in accordance with the terms of such license.
 *  This document is supplied for information purposes only, is subject to      
 *  change without notice, and should not be construed as a commitment by       
 *  either eFunds Corporation or eFunds Canada Corporation. 
 *
 *
 *                        MODIFICATION HISTORY                  REVIEW
 *
 *	SPR#	Who	Date	Description			Who	Date   
 * ===========================================================================
 *R00xxxx ztang 16Jan03 Creation
 *R028104 dipa  29Apr10 routingInfo - fix
 *R028271 dipa  18Jun10 Txn Statistics
 *R030381 dipa	02Mar12  Txn Statistics
 */
/* File Number 151 */

#include <stdio.h>
#include <string.h>
#include <ctype.h>
#include <oasis.h>
#include <ist_otrace.h>
#include <shc.h>
#include <shcdef.h>
#include <CShcLog.h>
#include <ShcmsgForwardResp.h>
#include <ShcMacHelper.h>
#include <ShcFinAuthHelper.h>
#include <ShcmsgHelper.h>
#include <ShcCamHelper.h>
#include <ShcmsgProcessor.h>
#include <ShcApp.h>
#include <ShcRetHelper.h>
#include <ShcMsgCache.h>
#include <ShcLateRespHelper.h>

#include <ist_seg_name.h> //R027876
#include <ist_seg_elf_id_map.h> //R027876
#include <ist_seg_id.h> //R027876

//R028271 >>>
#include <TxnStat.h>
//<<< R028271

int ShcmsgForwardResp::enrich()
{
	return 0;
}


int ShcmsgForwardResp::edit()
{
	return(0);
}

	
int ShcmsgForwardResp::doWork()
{
	int l;
	int outbound = -1;
	ShcmsgHeader *thisHeader = (ShcmsgHeader *)header;
	if (header->eventId >= 0)
		tm_dequeue( header->eventId );

	// R028104 >>>
	struct RoutingInfo tmpInfo = {0};
	int len=sizeof(struct RoutingInfo);
	thisHeader->getReqSegmentData((char*)&tmpInfo, &len, NETWORK_DATA_REQ_id,ROUTING_INFO);
	// <<< R028104

	if (len)
	{
		try
		{
		//Original requst from another node, need to send it back
		char *tmpp;
		int totallen = thisHeader->truelength();
		tmpp = mcastHelperObj->createBroadcastMsg(2, (char *)&thisHeader->msg, totallen, tmpInfo.srcNode, &totallen, tmpInfo.srcSiteId);
		if (mcastHelperObj->ready())
		{
			outbound = mcastHelperObj->getMbID();
			if (!mbPortIsConnected(mbMailBoxGetPortId(outbound)))
			{
				header -> msg.shc_devcap |= SH_DEVCAP_SHC_LATE_RESPONSE;
				if (shcLateRespHelperObj && (shcLateRespHelperObj->processLateResp(header))>=0)
				{
					OTraceLog("L-SHC-:Syncsrv port down, route to laterespsrv ID[%s] /m%04d/t%d/p%06d to laterespsrv\n",
						thisHeader->msg.shclog_id, thisHeader->msg.msgtype, thisHeader->msg.trace,
						thisHeader->msg.pcode);
					throw 1;
				}
				else
				{
					header -> msg.shc_devcap &= ~SH_DEVCAP_SHC_LATE_RESPONSE;
					OTraceDebug("D-SHC-:Late resp not used, continue...\n");
				}
			}
			if (cache_mb_write(outbound, shcmid, (char *)tmpp, totallen) < 0)
			{
				OTraceLog("L-SHC-15105: Failed to send msg ID[%s] /m%04d/t%d/p%06d to %s\n",
					thisHeader->msg.shclog_id, thisHeader->msg.msgtype, thisHeader->msg.trace,
					thisHeader->msg.pcode, mbMailBoxName(outbound));
			}
			else
			{
				OTraceLog("L-SHC-15104: Sent msg ID[%s] /m%04d/t%d/p%06d to %s\n",
					thisHeader->msg.shclog_id, thisHeader->msg.msgtype, thisHeader->msg.trace,
					thisHeader->msg.pcode, mbMailBoxName(outbound));
				TxnStatReport(thisHeader->msg.shclog_id,TS_SHC,TSR_LASTSEND,thisHeader->msg.msgtype,STATUS_BUSIMON,0);
			}
				
			shcApp->shcmsgHelperObj->shc_dispmsg_x(&thisHeader->msg, 1, outbound);
			OTraceDebug("D-SHC-15101:The forward response is sent to[%s]\n", mbMailBoxName(outbound));
		}
		else
		{
			OTraceDebug("D-SHC-15102:Can't find syncserver mailbox. The forward response is dropped\n");
			//R028271 >>>
			TxnStatReport(thisHeader->msg.shclog_id,TS_SHC,TSR_DROP,DROP_MAILBOX_NOT_FOUND,0,0);
			//<<< R028271
		}
		}
		catch(...)
		{
		}
	}
	else
		OTraceDebug("D-SHC-15103:Can't find routing information. The forward response is dropped\n"); //R027876

	header->shcerr = SH_IGNORE;
	
	return 0;
}








