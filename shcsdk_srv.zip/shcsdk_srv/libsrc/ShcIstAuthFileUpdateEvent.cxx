static char _ShcIstAuthFileUpdateEvent_cxx_what[] = "@(#) ShcIstAuthFileUpdateEvent.cxx 1.12.1.1 17/09/21 13:25:49";

/*
 *  Copyright (C) 2004 eFunds Corporation ("eFunds").  All Rights Reserved.     
 *  eFunds Canada Corporation is an authorized user.                            
 *                                                                              
 *  IST is a registered trademark of eFunds Corporation.  Other brand or        
 *  product names are trademarks or registered trademarks of their respective   
 *  holders.                                                                    
 *                                                                              
 *  The information contained herein is the unpublished proprietary property    
 *  of eFunds.  Except as specifically authorized in writing by eFunds, the     
 *  holder of this document shall: i) keep all information contained herein     
 *  confidential, and ii) protect the information, in whole or in part, from    
 *  disclosure and dissemination to all third parties.                          
 *                                                                          
 *  This document and the software described in it are furnished under license  
 *  and may be used or copied only in accordance with the terms of such license.
 *  This document is supplied for information purposes only, is subject to      
 *  change without notice, and should not be construed as a commitment by       
 *  either eFunds Corporation or eFunds Canada Corporation. 
 *
 *
 *
 *                        MODIFICATION HISTORY                  REVIEW
 *
 *	SPR#	Who	Date	Description			Who	Date   
 * ===========================================================================
 * 
 */

#include <ShcmsgEvent.h>
#include <ShcIstAuthFileUpdateEvent.h>
#include <TxnStat.h>


int ShcIstAuthFileUpdateEvent::enrich()
{

	OTraceInfo("I-SHC-90001: Time out of message: %d trace %d event %d unit %d\n", header->msg.msgtype, header->msg.trace, 
		header->eventId, header->msg.unit);


	if( tm_dequeue(header->eventId) < 0 )
	{
		OTraceInfo("I-SHC-90002: Event not removed properly from event queue, message dropped\n");
		header->shcerr = SH_IGNORE;
		header->setIgnoreFlag();
		return 0;
	}
	else
	{
		TxnStatReport(header->msg.shclog_id, TS_SHC,TSR_TIMEOUT,header->msg.msgtype,0,mbLastSenderId());
    	return 0;
	}
}

int ShcIstAuthFileUpdateEvent::edit()
{
	return 0;
}


int ShcIstAuthFileUpdateEvent::doWork()
{
	header->shcerr = SH_IGNORE;
	header->setIgnoreFlag();
	return 0;
}


