static char _ShcmsgProcessor_cxx_what[] = "@(#) ShcmsgProcessor.cxx 1.51.19.6 20/04/16 18:52:30";

/*
 *  Copyright (C) 2004 eFunds Corporation ("eFunds").  All Rights Reserved.     
 *  eFunds Canada Corporation is an authorized user.                            
 *                                                                              
 *  IST is a registered trademark of eFunds Corporation.  Other brand or        
 *  product names are trademarks or registered trademarks of their respective   
 *  holders.                                                                    
 *                                                                              
 *  The information contained herein is the unpublished proprietary property    
 *  of eFunds.  Except as specifically authorized in writing by eFunds, the     
 *  holder of this document shall: i) keep all information contained herein     
 *  confidential, and ii) protect the information, in whole or in part, from    
 *  disclosure and dissemination to all third parties.                          
 *                                                                          
 *  This document and the software described in it are furnished under license  
 *  and may be used or copied only in accordance with the terms of such license.
 *  This document is supplied for information purposes only, is subject to      
 *  change without notice, and should not be construed as a commitment by       
 *  either eFunds Corporation or eFunds Canada Corporation. 
 *
 *
 *                        MODIFICATION HISTORY                  REVIEW
 *
 * SCR#     Who    Date  Description
 * ===========================================================================
 * R0xxxxx 
 * R016794  spa  29Jun06 Added call to shc_writecard() in log() method
 * R021617  emj  09Ocy07 Flush cache after checkndke
 * R022088  sel  29Nov07 Reject txn when it fails to insert record in shclog table 
 * R022222  Ram  23May08 Exit shc if disconnected from database
 * R025432	sel	 09Dec08 copy from issuer to acquier for service request
 * R027320  Dipa 08Oct09 Allow advice response txn to match with advice req txn while updating in SHCLOG.
 * R027320  Dipa 16Oct09 Changes reverted.
 * R027320  Dipa 13Nov09 Allow advice response txn to match with advice req txn while updating in SHCLOG.
 * R027959  Dipa 23Mar10 Handle shclog_specified_logid
 * R027959  Dipa 05Apr10 Remove shclog_specified_logid; use logFlag instead.
 * R028251  Dipa 15Jun10 Fix core dump when cardscheme is not found for a cardproduct
 * R028271  Dipa 18Jun10 Txn Statistics
 * R029567  Dipa 01Jul11 Set DN_SEGMENT.message_mode
 * R030381  Dipa 02Mar12 Txnstat changes
 * R030556  Dipa 04Jun12 B/w compatibility for SHM versioning
 * R030556  Dipa 14Jun12 Clone of R030592
 * R030643  las  20Jun12 clone of R030592 - add routinginfo to network info structure
 * R030745  Dipa 09Aug12 Clone of R030164 - Remove default case for setting DN_SEGMENT.message_mode
 * R030745  Dipa 09Aug12 Clone of R030292 - Decline txn if DB error occurs during shclog insertion, if shc.return_on_error is set
 * R031154	Dipa 21Dec12 Clone of R031066 - Added code to locate original for void even if they have same trace
 * R031887  Dipa 02Sep13 Clone of R031839 - Set DN.message_mode for txns when the bank is the issuer
 * IST_S770SP1-84	Dipa	11Feb15	Clone of IST_S761SP8-230 - Create DN_SEGMENT only if shc.supportDN is set to Y
 */
 
 //File Number 98

#include <sys/timeb.h>
#include <mb_umi.h>
#include <ist_otrace.h>
#include <shc.h>
#include <shc_callback.h>
#include <ShcmsgHelper.h>
#include <ShcTimerHelper.h>
#include <ShcAppBase.h>
#include <ShcmsgProcessor.h>
#include <ShcApp.h>
#include <ShcmsgTxnRegistration.h>
#include <ShcHelper.h>
#include <ShcmsgTxnHelper.h>
#include <ShcBin.h>
#include <CShcLog.h>
#include <ShcHeaderRegistration.h>
#include <ist_seg_elf_id_map.h>
#include <ShcAppBase.h>
#include <ShcmsgProcessor.h>
#include <ShcKeyHelper.h>
#include <InstProfile.h>
#include <ist_seg_id.h>
#include <ist_seg_dn.h>
#include <ShcGenericLogBinary.h>
#include <rules.h>
#include <ShcmsgODHelper.h>
#include <MSTShclogMap.h>
#include <BinRoute.h>

//R028271 >>>
#include <TxnStat.h>
//<<< R028271
extern int shclogSkipGenlog;	//Real definitiion is in ShcLog.cxx
int ShcmsgProcessor::dnCardCategoryBasedOnCardPdt =  -1;


ShcBaseTxn *ShcmsgProcessor::classify()
{
	return shcmsgTxnRegistration.getTargetObj((void *)header);
}

int ShcmsgProcessor::getBINs()
{
	ShcmsgHeader *thisHeader = (ShcmsgHeader *)header;

	int tmpRespCode = thisHeader->msg.respcode;
	if (thisHeader->msg.acquirer[0])
		thisShcApp->shcmsgHelperObj->shc_normalizebin(thisHeader->msg.acquirer);

	switch(thisHeader->msg.msgtype)
	{
	case SHC_ISTAUTH_FILE_UPD_REQ:
	case SHC_ISTAUTH_FILE_UPD_REQ_REPEAT:
		break;
	//	>>>	R025432
	case SHC_SERVICE_REQUEST:
		if (!thisHeader->msg.acquirer[0])
			strcpy(thisHeader->msg.acquirer, thisHeader->msg.issuer);
	//	<<<	R025432
	default:
		/*	Extract issuer from pan */
		int getIssuerFromPan = 0;
		
		if ( thisHeader->msg.issuer[0] == '\0' )
			getIssuerFromPan = 1;

		if (	!(thisHeader->msg.device_cap & SH_DEVCAP_FROM_REPLAY)	&&
				shcIsRequest(thisHeader) &&
				(thisHeader->msg.msgtype%10 != 2)	//Not sending to acquirer
				)
		{
			ShcInstParamsList *txnSrcParamList = (ShcInstParamsList *)thisShcApp->shcParams.getInst(thisHeader->msg.txnSrc);
			if (txnSrcParamList && txnSrcParamList->GetBool((char *)"shc.reLookUpIssAcq"))
				getIssuerFromPan = 1;
		}
		
		if( thisShcApp->shcmsgHelperObj->shcGetIssAcq(thisHeader, getIssuerFromPan) < 0 )
			return -1;
		/**	R025432
		else
		{
			if (thisHeader->msg.issuer[0])
				thisHeader->setIssShcBin(thisHeader->msg.issuer);
			if (thisHeader->msg.acquirer[0])
				thisHeader->setAcqShcBin(thisHeader->msg.acquirer);
			if (thisHeader->msg.transferee[0])
				thisHeader->setTransfereeShcBin(thisHeader->msg.transferee);
		}
			**/
	}
	//	>>>	R025432
	if (thisHeader->msg.issuer[0])
	{
		thisHeader->setIssShcBin(thisHeader->msg.issuer);
		// Code for setting keys moved after loacting event -- R030141
		//lookup inst_profile
		//int keyparam;
		//InstitutionProfile instProfile = { 0 };
		//int len = sizeof(struct InstitutionProfile);
		//if (shcIsRequest(thisHeader))
		//{
		//	thisHeader->getSegmentData((char *)&instProfile, &len, NETWORK_DATA_REQ_id, ISS_INST_PROFILE_ENTRY);
		//}
		//else
		//{
		//	thisHeader->getReqSegmentData((char *)&instProfile, &len, NETWORK_DATA_REQ_id, ISS_INST_PROFILE_ENTRY);
		//}

		//if (len <= 0)
		//{
		//	NetworkInfo networkInfo;
		//	shcApp->instProfileObj->locateNetworkInfo(thisHeader->msg.txnSrc, thisHeader->msg.txnDest, 
		//		thisHeader->msg.iss_entityId, thisHeader->msg.msgtype, thisHeader->msg.issuer, networkInfo);
		//	if (networkInfo.foundNetworkInfo())
		//		thisHeader->setSegmentData((char *)networkInfo.getInstProfileEntry(), 
		//			sizeof(struct InstitutionProfile), NETWORK_DATA_REQ_id, ISS_INST_PROFILE_ENTRY);
		//	keyparam = networkInfo.getKeyparam();
		//}
		//else
		//{
		//	keyparam = instProfile.keyparm;
		//}
		//if (thisHeader->issBinValid() && (keyparam >= 0))
		//{
		//	thisHeader->issShcBin->setKey(&shcSecurity[keyparam]);
		//}
	}

	if (thisHeader->msg.acquirer[0])
	{
		//InstitutionProfile instProfile = { 0 };
		//int len = sizeof(struct InstitutionProfile);

		thisHeader->setAcqShcBin(thisHeader->msg.acquirer);
		//if (shcIsRequest(thisHeader))
		//{
		//	thisHeader->getSegmentData((char *)&instProfile, &len, NETWORK_DATA_REQ_id, ACQ_INST_PROFILE_ENTRY);
		//}
		//else
		//{
		//	thisHeader->getReqSegmentData((char *)&instProfile, &len, NETWORK_DATA_REQ_id, ACQ_INST_PROFILE_ENTRY);
		//}
		//if (len <= 0)
		//{
		//	OTraceDebug("E-SHC-9834:No acquirer side inst_profile entry in segment,key pointer use bin\n");
		//}
		//else
		//{
		//	if ( thisHeader->acqBinValid() )
		//		thisHeader->acqShcBin->setKey(&shcSecurity[instProfile.keyparm]);
		//}
	}
	if (thisHeader->msg.transferee[0])
		thisHeader->setTransfereeShcBin(thisHeader->msg.transferee);
	//	<<<	R025432

	bin_t routing_bin;
	int size  = sizeof(routing_bin);
	thisHeader->getSegmentData(routing_bin, &size, NETWORK_DATA_REQ_id, ROUTING_BIN);
	if(size <= 0)
	{
		if (!shcIsResponse(thisHeader)) /*Segment should be create or add sub element after  shc_restore_fields in response*/
		{
			thisHeader->setSegmentData(thisHeader->msg.issuer,sizeof(thisHeader->msg.issuer), NETWORK_DATA_REQ_id, ROUTING_BIN);
			OTraceDebug("D-SHC-9809: routingbin value is NULL, hence setting issuer_bin [%s]\n",thisHeader->msg.issuer);
		}
	}
	return(0);

}

int ShcmsgProcessor::log()
{
	int save_respcode, save_shcerror, save_msgtype;
	int flag = 0;

	if(shcmsgODHelperObj)
	shcmsgODHelperObj->sendRespToOD((ShcmsgHeader *)header);

	if (!header->shcLogObj)
	{
		OTraceDebug("D-SHC-9801: No log object allocated, log flag[%x] not processed\n", 
			header->logFlag );
		return 0;
	}
	
	ShcmsgHeader *thisHeader = (ShcmsgHeader *)header;

	//shclog record must be updated in order to update related generic log record
	if (thisHeader->logFlag & SHC_LOG_UPD_GENLOG)
		thisHeader->logFlag |= SHC_LOG_UPD_REQ;

	if (shcIsResponse(thisHeader))
	{
		//record mst_shclog_id mapping
		MSTShclogMap::record(thisHeader);
	}

	if (thisHeader->logFlag & SHC_LOG_REQ)
	{
		if (thisHeader->logFlag & SHC_LOG_UPD_REQ)
		{
			//Both flags are set, we should only change the request to response
			//and log it
			save_msgtype = thisHeader->msg.msgtype;
			thisShcApp->shcmsgHelperObj->shc_set_return_msgno(&thisHeader->msg);
		}
		OTraceDebug("D-SHC-9802: Log Request message[%04d]\n", thisHeader->msg.msgtype );
		//	>>>	R022088
		if (thisHeader->logFlag & SHC_LOG_UPD_GENLOG)
			shclogSkipGenlog = 1;
		if (thisHeader->shcLogObj->logTxn(thisHeader) < 0)
		{
			shclogSkipGenlog = 0;
			if(!shcApp->shcReturnDBError) //R030292
			{
				OTraceError("E-SHC-9830: Log Request message failed, ignore message \n");
				thisHeader->shcerr = SH_IGNORE;
				//      >>> R022222
				thisHeader->shcLogObj->rewind();
				if (dbm_rollback(dbmid) < 0)
				{
					OTraceError("E-SHC-9831: Rollback failed\n");
					if (dbm_errno == DBME_DISCONNECT)
					{
						OTraceFatal("F-SHC-9832: disconnected from database, exiting\n");
						kill(getpid(),1);
					}
				}
				//      <<< R022222
				return (-1);
			}
			else
			{
				OTraceError("E-SHC-9830.1: Log Request message failed due to DB error. Txn Declined\n");
				thisHeader->shcerr = SH_RETURN;
				thisHeader->msg.respcode = SHC_RC_SystemError;
				thisShcApp->shcmsgHelperObj->shc_set_return_msgno(&thisHeader->msg);
				return(0);
			}
		}
		shclogSkipGenlog = 0;
		//	<<<	R022088
		if (thisHeader->logFlag & SHC_LOG_UPD_REQ)
		{
			thisHeader->msg.msgtype = save_msgtype;
			//Clear flag to prevent logging again
			thisHeader->logFlag &= ~SHC_LOG_UPD_REQ; 
		}
	}

	if (thisHeader->logFlag & SHC_LOG_LATE_RESP)
	{
		OTraceDebug("D-SHC-9803: Log Late Response message[%04d]\n", thisHeader->msg.msgtype );


		save_msgtype = thisHeader->msg.msgtype;
		save_shcerror = thisHeader->msg.shcerror;
		save_respcode = thisHeader->msg.respcode;

		thisHeader->msg.msgtype + SHC_LATE_RESPONSE <10000?
			thisHeader->msg.msgtype += SHC_LATE_RESPONSE:
			thisHeader->msg.msgtype -= (thisHeader->msg.msgtype-SHC_LATE_RESPONSE)/1000*1000;
		thisHeader->msg.respcode = SHC_RC_LateResponse;
		thisHeader->msg.shcerror = SHC_IE_NoMatch;

		if (thisHeader->logFlag & SHC_LOG_UPD_GENLOG)
			shclogSkipGenlog = 1;
		thisHeader->shcLogObj->logTxn(thisHeader);
		shclogSkipGenlog = 0;

		thisHeader->msg.msgtype = save_msgtype;
		thisHeader->msg.shcerror = save_shcerror;
		thisHeader->msg.respcode = save_respcode;
		thisHeader->msg.shc_devcap |= SH_DEVCAP_SHC_LATE_RESPONSE;	/* R009856 */

	}
	
	if ( thisHeader->logFlag & (SHC_LOG_ORIG|SHC_LOG_UPD_ORIG) )
	{
		if( thisHeader->origMsg )
		{
			struct ShcmsgWithSegment tmpMsg;
			memcpy(&tmpMsg.msg, &thisHeader->msg, sizeof(tmpMsg));
			//memcpy(&thisHeader->msg, thisHeader->origMsg, sizeof(tmpMsg));
			memcpy(&thisHeader->msg, thisHeader->origMsg, sizeof(thisHeader->msg));
			int savedPcode = -1;
			int ret = 0;

			if (thisHeader->reqMsg)
			{
				//Need to make the reqmsg->pcode same as origMsg->pcode to prevent strange behavior in ShcLog class
				savedPcode = thisHeader->reqMsg->pcode;
				thisHeader->reqMsg->pcode = thisHeader->origMsg->pcode;
			}

	
			if(thisHeader->logFlag & SHC_LOG_ORIG)
			{
				OTraceDebug("D-SHC-9804: Log Original Request message[%04d]\n", thisHeader->origMsg->msgtype );
				if( thisHeader->shcLogObj->logTxn(thisHeader) < 0 )
					OTraceError("E-SHC-9805:DB log origmsg of (%ld) failed.\n",thisHeader->msg.trace);
				
			}
			
			if (thisHeader->logFlag & SHC_LOG_UPD_ORIG)
			{
				OTraceDebug("D-SHC-9806: Update Original message[%04d] for [%04d]\n", 
						thisHeader->msg.msgtype, tmpMsg.msg.msgtype );
				if ((tmpMsg.msg.msgtype / 100) == 4)
				{
				 	ret = ((ShcLog *)thisHeader->shcLogObj)->doUpdateReversal(thisHeader);
				}
				else if (tmpMsg.msg.shc_devcap & SH_DEVCAP_SHC_VOID)
				{
					 ret = ((ShcLog *)thisHeader->shcLogObj)->doUpdateVoid(thisHeader);
				}
				else if (tmpMsg.msg.formatter_devcap & SH_FORMATDEVCAP_CAPTURE_ONLY)
				{
					 ret = ((ShcLog *)thisHeader->shcLogObj)->doUpdateFinCapture(thisHeader);
				}
				else
				{
			 		ret = ((ShcLog *)thisHeader->shcLogObj)->updateTxn(thisHeader, NULL, !(thisHeader->logFlag & SHC_LOG_SKIP_LOCATE_ORIG));
				}
				if (ret < 0)
				{
					OTraceError("E-SHC-9807:DB update origmsg of (%ld) failed.\n",thisHeader->msg.trace);
				}
			}
			//memcpy(&thisHeader->msg, &tmpMsg.msg, sizeof(tmpMsg));
			memcpy(&thisHeader->msg, &tmpMsg.msg, sizeof(tmpMsg));
			if (savedPcode >= 0)
				thisHeader->reqMsg->pcode = savedPcode;
		}
		else
		{
			OTraceError("E-SHC-9808: Original message[%04d] is empty, Ignored %s\n", 
						thisHeader->msg.msgtype, thisHeader->logFlag&SHC_LOG_ORIG ? "LOG":"UPDATE" );
		}
	}
	
	if (thisHeader->logFlag & SHC_LOG_UPD_REQ)
	{
		// Change to Insert RESP not update REQ
		OTraceDebug("D-SHC-9809: Insert Resp  message[%04d]\n", thisHeader->msg.msgtype );
		if ((thisHeader->reqMsg) && (thisHeader->msg.msgtype != thisHeader->reqMsg->msgtype)
		  && (!(shcmsgIsIBFTW(thisHeader->reqMsg) || shcmsgIsIBFTD(thisHeader->reqMsg))) )	// R011136
		{
			/* Only locate request */ /* R008689 */
			shcApp->shclog_specified_msgtype = thisHeader->reqMsg->msgtype;
		}

		//if (thisHeader->logFlag & SHC_LOG_UPD_GENLOG)
		//		shclogSkipGenlog = 1;
		//	flag = IST_SHCLOG_FLAG_LOCATE_FIRST|IST_SHCLOG_FLAG_USE_CHIP_INDEX;

		//if (((ShcLog *)thisHeader->shcLogObj)->updateTxn(thisHeader, NULL,flag) < 0)
		if (((ShcLog *)thisHeader->shcLogObj)->logTxn(thisHeader) < 0)
		{
			if((dbm_errno == DBME_DUPLICATE_KEY) && !(thisHeader->msg.shc_devcap & SH_DEVCAP_SHC_EVENT)&&
                ((thisHeader->msg.msgtype == 110)||(thisHeader->msg.msgtype == 210)))
			{
				OTraceInfo("I-SHC-9836: duplicate key, change to late response.\n");
	            thisShcApp->shcHelperObj->reset_mb_cache();
				dbm_rollback(dbmid);
				ShcProcessor *p = thisShcApp->shcmsgTxnHelperObj->enqueueInternalMsg(thisHeader);
				p->header->flag &= ~MSG_CREATED_INTERNAL;
				return -1;
			}
			OTraceWarning("w-SHC-9809:Could not insert need to update [%04d][%s]\n", 
					thisHeader->msg.msgtype,  thisHeader->msg.shclog_id);
			if (thisHeader->logFlag & SHC_LOG_UPD_GENLOG)
				shclogSkipGenlog = 1;
			flag = IST_SHCLOG_FLAG_LOCATE_FIRST|IST_SHCLOG_FLAG_USE_CHIP_INDEX|IST_SHCLOG_FLAG_LOCATE_RESP;

			if (((ShcLog *)thisHeader->shcLogObj)->updateTxn(thisHeader, NULL,flag) < 0)
			{

				shclogSkipGenlog = 0;
				OTraceError("E-SHC-9810:Db insert/update resp of (%s)(%ld) failed.\n",thisHeader->msg.shclog_id, thisHeader->msg.trace);

				/*  10apr95 */
				if(!shcApp->shcReturnDBError)
				{
					//      >>>     R022222
					thisHeader->shcLogObj->rewind();
					if ( dbm_commit(dbmid) < 0)
					{
						if (dbm_errno == DBME_DISCONNECT)
						{
							OTraceFatal("F-SHC-9833: disconnected from database, exiting\n");
							kill(getpid(),1);
						}
					}
					//      <<<     R022222
					thisHeader->shcerr = SH_IGNORE;
					return(-1);
				}
			}
		}
		shclogSkipGenlog = 0;
		shcApp->shclog_specified_msgtype = 0;   /* Remove message type used to locate txn in shclog, So it will
										 * not affect other functions that may not want to use full message
										 * type to locate txns
										 */
	}
	
	
	if (thisHeader->logFlag & SHC_LOG_REPEAT)
	{
		OTraceDebug("D-SHC-9811: Check and Log Request message[%04d]\n", thisHeader->msg.msgtype );
		if (thisHeader->logFlag & SHC_LOG_UPD_GENLOG)
			shclogSkipGenlog = 1;
		thisHeader->shcLogObj->logRepeat(thisHeader);
		shclogSkipGenlog = 0;
		
	}

	if (thisHeader->logFlag & SHC_LOG_UPD_GENLOG)
	{
		static int isBinaryGenericLog = -1;

		if (!(thisHeader->logFlag & SHC_LOG_UPD_REQ))
			OTraceError("E-SHC-9830:Update genericlog must be done with update req, no update done\n");
		else
		{
			if (isBinaryGenericLog < 0)
			{
				if (strcmp(shcGenericLogObj->getName(), "ShcGeneric_logBinary")==0)
					isBinaryGenericLog = 1;
				else
					isBinaryGenericLog = 0;
			}
		
			if (isBinaryGenericLog)
				((ShcGenericLogBinary *)shcGenericLogObj)->update();
		}
	}
	
	if (thisHeader->logFlag & SHC_LOG_TXN_SPECIFIC)
	{
		OTraceDebug("D-SHC-9812: Txn specific log, message[%04d]\n", thisHeader->msg.msgtype );
		shcTxn->log();
		
	}

	thisShcApp->shcmsgHelperObj->shc_writecard();	//	---	R016794

	thisHeader->shcLogObj->rewind();

	struct timeb tmpTime;
	ftime(&tmpTime);
	
	if ( dbm_commit(dbmid) < 0)
	{
		if(!shcApp->shcReturnDBError) //R030292
		{
			//      >>>     R022222
			//#if defined(DBME_DISCONNECT)
			if (dbm_errno == DBME_DISCONNECT)
			{
				OTraceFatal("F-SHC-9822: disconnected from database, exiting\n");
				//exit(1);
				kill(getpid(),1);
			}
			//#endif
			//      <<<     R022222
			OTraceDebug("E-SHC-9813: dbm_commit failed, rollback and continue\n");
			if (dbm_rollback(dbmid) < 0)
				OTraceDebug("E-SHC-9814: rollback failed\n");
			return -1;
		}
		else
		{
			OTraceError("E-SHC-9813.1: Log Request message failed due to DB error. Txn Declined\n");
			thisHeader->shcerr = SH_RETURN;
			thisHeader->msg.respcode = SHC_RC_SystemError;
			thisShcApp->shcmsgHelperObj->shc_set_return_msgno(&thisHeader->msg);
			return(0);
		}
	}
	struct timeb afterTime;
	ftime(&afterTime);

	OTraceInfo("I-SHC-9814:commit cost[%ld]\n",
					 (afterTime.time-tmpTime.time)*1000+afterTime.millitm-tmpTime.millitm);

	return 0;
}

int ShcmsgProcessor::route()
{
	int ret = thisShcApp->shcmsgHelperObj->shc_route((ShcmsgHeader *)header);
	return ret;

}


int ShcmsgProcessor::process()
{
	ShcmsgHeader *thisHeader 	= (ShcmsgHeader *)header;
	int 		  status 		= 0;								//	---	R025432
	IstSegDN*	  dnobj			= NULL;								//  USP-1519
	char buf[3] = {0};

	if ((thisHeader->msg.trandate <= 0)&&shcIsRequest(thisHeader))
	{
		shc_get_current_date();
		thisHeader->msg.trandate = shc_gmt_currentdate();
		thisHeader->msg.trantime = shc_gmt_currenttime();
	}

	if (!thisHeader->msg.shclog_id[0])
	{
		mb_getUmi(thisHeader->msg.shclog_id, sizeof (thisHeader->msg.shclog_id));
		OTraceLog("L-SHC-9823: Begin processing message new ID [%s] for m%04d/t%06d/p%06d\n", 
			thisHeader->msg.shclog_id, thisHeader->msg.msgtype, 
			thisHeader->msg.trace, thisHeader->msg.pcode);
	}

    int callbackRet = shc_callback(header,"preprocess");
	switch(callbackRet)
	{
	case SHCCALLBACKOVERRIDE:
		OTraceDebug("I-SHC-9815: Message process skipped required by preprocess callback function\n");
		return 0;
		break;
	case SHCCALLBACKDROP:
	{
		thisShcApp->shcmsgHelperObj->shc_callback_log(thisHeader, SHCCALLBACKDROP);
		OTraceLog("L-SHC-9816: Drop message required by preprocess callback function ID[%s]/m%04d/t%06ld/p%06ld\n", thisHeader->msg.shclog_id,
            thisHeader->msg.msgtype, thisHeader->msg.trace, thisHeader->msg.pcode);

		//R028271 >>>
		TxnStatReport(thisHeader->msg.shclog_id,TS_SHC,TSR_DROP,DROP_BY_CALLBACK_preprocess,0,0);
		//<<< R028271
        return(0);
	}
	case SHCCALLBACKDENY:
		thisShcApp->shcmsgHelperObj->shc_deny_txn(thisHeader);
		{
			OTraceDebug("I-SHC-9825: Message denied required by preprocess callback function\n");
			thisShcApp->shcmsgHelperObj->shc_route(thisHeader);

        	thisShcApp->shcmsgHelperObj->shc_writecard();
        	thisHeader->shcLogObj->rewind();
	        if ( dbm_commit(dbmid) < 0)
	        {
	            OTraceDebug("E-SHC-9826: dbm_commit failed, rollback and continue\n" );
	            if (dbm_rollback(dbmid) < 0)
	                OTraceDebug("E-SHC-9827: rollback failed\n");
	            thisShcApp->shcHelperObj->reset_mb_cache();
	        }
	        else
	        {
	            thisShcApp->shcHelperObj->flush_mb_cache();
	            struct timeb tmpTime;
	            ftime(&tmpTime);
	            OTraceInfo("I-SHC-9828: Messages out at %ld %d\n", tmpTime.time, tmpTime.millitm);
	        }

        	thisShcApp->shcmsgHelperObj->shc_stats(thisHeader);
			return 0;
		}
	case SHCCALLBACKCONTINUE:
	default:
		break;
	}
	
	thisShcApp->shcmsgHelperObj->dumpShcmsg( &thisHeader->msg );

	// R027759
	// Process the DN segment here
	// -  set the card_category and
	// -  populate other fields where possible
    if(   !(thisHeader->msg.shc_devcap & SH_DEVCAP_SHC_EVENT)
	   && !(thisHeader->msg.msgtype >= SHC_EVENT) )
	{
		if (shcIsRequest(thisHeader)) 							// 23Apr2010
		{
			if (haveDNSupport && DNSegHelperObj)
			{
				OTraceDebug("D-SHC-9828-a: processing DN segment\n");

				// USP-1519 -- definition moved above so other function need not create this 
				// if done already.  Also repositioned here
				dnobj = (IstSegDN*)thisHeader->getSegmentObj(DN_SEG_id, IST_SEG_CREATE);

				DNSegHelperObj->setDNSegmentValue(thisHeader);
			}

			// R027759
			// Initialize the LCR object before caling getBINs()
			// Also, this can be used where header is not available
			// 18May2010
			// Make sure that the setter for DN (above) is called before doing this
			// LCR is currently for debits only -- this may change but for now, it is debit only
			if (haveLCRSupport && LCRHelperObj)
			{
				LCRHelperObj->initialize(thisHeader);
				if (dnobj)
					LCRHelperObj->setProcessOption(dnobj->getCardType());	
				else
					LCRHelperObj->setProcessOption('?'); // defaults to 'not debit' if unknown
			}

			if (haveTieBreaker && TieBreakerObj)
				TieBreakerObj->initialize(thisHeader);
		}
	}
	
	
	getBINs();

	// 19Apr2010
	// At this stage, if txn is valid, card_scheme can be located because the message
	// has the following now:
	// - institution ID of the issuer
	// - cardproduct
	// - entityid
    if(   !(thisHeader->msg.shc_devcap & SH_DEVCAP_SHC_EVENT)
	   && !(thisHeader->msg.msgtype >= SHC_EVENT) )
	{
		char	cdscheme[3];
		char	instID[12];
		const struct shcpkg*	issPkg 	= NULL;
		struct shcbin*			issBin 	= NULL;

		// USP-1519
		struct shc_data*	  shc_data	= (struct shc_data*)&(thisHeader->msg.shc_data_buffer[0]);

		// USP-1519 -- start
		// Need to re-set card type to consider the signature debits
		if (!dnobj && haveDNSupport) 
			dnobj = (IstSegDN*)thisHeader->getSegmentObj(DN_SEG_id, IST_SEG_CREATE);
	
		//R029567 >>>
		if( dnobj && shcIsResponse(thisHeader))
		{
			//set the message mode - 'S' or 'D'
			if ((strcmp(thisHeader->msg.iss_entityId,"BaseI")==0) || (strcmp(thisHeader->msg.iss_entityId,"BANKNET")==0))
			{
				dnobj->setMessageMode('D');
				OTraceDebug("D-SHC-9816-0:  Setting DN_SEGMENT.message_mode to 'D'\n");
			}
			else if ((strcmp(thisHeader->msg.iss_entityId,"SMS")==0) || (strcmp(thisHeader->msg.iss_entityId,"MDS")==0))
			{
				dnobj->setMessageMode('S');
				OTraceDebug("D-SHC-9816-0:  Setting DN_SEGMENT.message_mode to 'S'\n");
			}
			//R030164 - Remove default case to avoid any value assigned by custom formatter,if any
			//else
			//{
			//	dnobj->setMessageMode(' ');
			//	OTraceDebug("D-SHC-9816-0:  Setting DN_SEGMENT.message_mode to ' '\n");
			//}
		}
		//R029567 <<<

		//R031887 >>>
		if( dnobj && shcIsRequest(thisHeader))
		{
			//set the message mode - 'S' or 'D'
			if ((strcmp(thisHeader->msg.entityId,"BaseI")==0) || (strcmp(thisHeader->msg.entityId,"BANKNET")==0))
			{
				dnobj->setMessageMode('D');
				OTraceDebug("D-SHC-9816-1:  Setting DN_SEGMENT.message_mode to 'D'\n");
			}
			else if ((strcmp(thisHeader->msg.entityId,"SMS")==0) || (strcmp(thisHeader->msg.entityId,"MDS")==0))
			{
				dnobj->setMessageMode('S');
				OTraceDebug("D-SHC-9816-2:  Setting DN_SEGMENT.message_mode to 'S'\n");
			}
		}
		//R031887 <<<

		if ( haveDNSupport && dnCardCategoryBasedOnCardPdt < 0 )
		{
			if(cf_open(NULL) >= 0)
			{
				cf_rewind();
				if( (cf_locate("shc.setDNCardCategoryBasedOnCardPdt", buf)) >= 0 )
				{
					if ( toupper(buf[0]) == 'Y' || buf[0] == '1' )
					{
						OTraceDebug("D-SHC-9816-3: Parameter shc.setDNCardCategoryBasedOnCardPdt is set on\n");
						dnCardCategoryBasedOnCardPdt = 1;
					}
					else
						dnCardCategoryBasedOnCardPdt = 0;
				}
				else
					dnCardCategoryBasedOnCardPdt = 0;
				cf_close();
			}
			else
				dnCardCategoryBasedOnCardPdt = 0;
		}


		if (   dnobj
			&& shcIsRequest(thisHeader)
			&& shc_data->network_data[OFFSET_SDI] == SIGNATURE_DEBIT && !dnCardCategoryBasedOnCardPdt  )
		{
			// re-set the card type -- which should 'C'(credit) as current value
			OTraceDebug("D-SHC-9816-a:  Changing card type to signature debit\n");
			dnobj->setCardType(SIGNATURE_DEBIT);			
		}
		else
		{
			// this should not happen and if it does, something's wrong in the system
			// and we want to catch it
			if (!dnobj && haveDNSupport)
			{
				OTraceError("E-SHC-9816-b:  Unable to get/create DN segment object!-continuing\n");
				syslg      ("E-SHC-9816-b:  Unable to get/create DN segment object!-continuing\n");
			}
			//else this is not an error condition
		}
		// USP-1519 -- end

		if ((thisHeader->issShcBin))
			issPkg = (thisHeader->issShcBin)->getBinPkg();

		if (issPkg)
			issBin = (struct shcbin*)&issPkg->bin;

		if (!issBin)
			OTraceError("E-SHC-9817: No issuer BIN detected!\n");
		else
		{
			if ( (!shcIsResponse(thisHeader) )&& haveDNSupport && DNSegHelperObj ) // R029926
			{
				strcpy(instID, issBin->institutionid);
				OTraceDebug("D-SHC-9817-a: Looking for card scheme...\n");
				if (shcApp->shcHelperObj->shc_getCardSchemeFromCardProduct(&cdscheme[0], 
					&thisHeader->msg.cardProduct[0], sizeof(cdscheme)) >= 0)
				{
					DNSegHelperObj->setAlternateMerchantID(thisHeader, instID, thisHeader->msg.entityId, cdscheme);
				}
				else
				{
					//R028251
					OTraceWarning("W-SHC-%06d: Did not find card scheme for (%s)\n",__LINE__,
								  thisHeader->msg.cardProduct);
				}
			}
		}
	}
	
	if( (status=thisShcApp->shcmsgTxnHelperObj->initTransaction(thisHeader)) < 0 )
	{
		if (status == -2) //In forward only mode
			thisHeader->shcerr |= SH_RETURN;
		else
			thisHeader->shcerr |= SH_IGNORE;
		OTraceDebug("D-SHC-9818: No txn classify needed\n");
	}
	else
	{
		// >>> R030141 Setting the keys after locate event
		struct shcsecurity *keyparam;
		int ikeyparam = -1;
		InstitutionProfile instProfile = { 0 };
		int len = sizeof(struct InstitutionProfile);
		if (shcIsRequest(thisHeader))
		{
			thisHeader->getSegmentData((char *)&instProfile, &len, NETWORK_DATA_REQ_id, ISS_INST_PROFILE_ENTRY);
		}
		else
		{
			if (!routingRecord.bin[0])
			{
				//Restore routing bin from request
				len = sizeof(routingRecord);
				thisHeader->getReqSegmentData((char *)&routingRecord, &len, NETWORK_DATA_REQ_id, ROUTING_BIN);
				if (len > 0)
				{
					/*Segment should be create or add sub element after shc_restore_fields in response*/
					if (!shcIsResponse(thisHeader)) 
					{
						thisHeader->setSegmentData((char *)&routingRecord, len, NETWORK_DATA_REQ_id, ROUTING_BIN);
					}
				}
			}
			len = sizeof(struct InstitutionProfile);
			thisHeader->getReqSegmentData((char *)&instProfile, &len, NETWORK_DATA_REQ_id, ISS_INST_PROFILE_ENTRY);
		}

		if (len <= 0)
		{
			NetworkInfo networkInfo;

			bin_t routingBin;
			int size;
			size = sizeof(routingBin);
			thisHeader->getSegmentData((char *)routingBin, &size, NETWORK_DATA_REQ_id, ROUTING_BIN);

			headerForLocateNetworkInfo = thisHeader;


			shcApp->instProfileObj->locateNetworkInfo(thisHeader->msg.txnSrc, thisHeader->msg.txnDest,
			thisHeader->msg.iss_entityId, thisHeader->msg.msgtype, routingBin, networkInfo);
			if (networkInfo.foundNetworkInfo())
			{
				/*Segment should be create or add sub element after shc_restore_fields in response*/
				if (!shcIsResponse(thisHeader))
				{	
					thisHeader->setSegmentData((char *)networkInfo.getInstProfileEntry(),
						sizeof(struct InstitutionProfile), NETWORK_DATA_REQ_id, ISS_INST_PROFILE_ENTRY);

					//	>>>	R030643
					thisShcApp->shcmsgHelperObj->addRoutingInfoSegment( thisHeader, networkInfo );
					//	<<<	R030643
				}
			}
			if(rm_isMultiVerSupported(0))
				keyparam = networkInfo.getKey();
			else
				ikeyparam = networkInfo.getKeyparam();
		}
		else
		{
			if(rm_isMultiVerSupported(0))
				keyparam = shcApp->shcKeyObj->getKey(instProfile.instId, instProfile.keyparamStr);
			else
				ikeyparam = instProfile.keyparm;
		}

		if(rm_isMultiVerSupported(0))
		{
			if (thisHeader->issBinValid() && (keyparam))
			{
				thisHeader->issShcBin->setKey(keyparam);
			}
		}
		else
		{
			if (thisHeader->issBinValid() && (ikeyparam >= 0))
			{
				thisHeader->issShcBin->setKey(&shcSecurity[ikeyparam]);
			}
		}

		if (thisHeader->msg.acquirer[0])
		{
			InstitutionProfile instProfile = { 0 };
			int len = sizeof(struct InstitutionProfile);
			struct shcsecurity *acqKeyParm=NULL;

			if (shcIsRequest(thisHeader))
			{
				thisHeader->getSegmentData((char *)&instProfile, &len, NETWORK_DATA_REQ_id, ACQ_INST_PROFILE_ENTRY);
			}
			else
			{
				thisHeader->getReqSegmentData((char *)&instProfile, &len, NETWORK_DATA_REQ_id, ACQ_INST_PROFILE_ENTRY);
			}
			if (len <= 0)
			{
				OTraceDebug("E-SHC-9834:No acquirer side inst_profile entry in segment\n");
			}
			else
			{
				if(!rm_isMultiVerSupported(0))
				{
					if ( thisHeader->acqBinValid() )
						thisHeader->acqShcBin->setKey(&shcSecurity[instProfile.keyparm]);
				}
				else
					acqKeyParm = shcApp->shcKeyObj->getKey(instProfile.instId, instProfile.keyparamStr);
			}
			if(rm_isMultiVerSupported(0))
			{
				if ((acqKeyParm) && ( thisHeader->acqBinValid() ))
					thisHeader->acqShcBin->setKey(shcApp->shcKeyObj->getKey(instProfile.instId, instProfile.keyparamStr));
				else
					OTraceDebug("E-SHC-9835:Can't find acquirer key(%s,%s)\n", instProfile.instId, instProfile.keyparamStr);
			}
		}
		// <<< R030141
		if(mbIsEvent() && shcIsRequest(thisHeader))
		{
			if(thisShcApp->acquirerShcParamsList->GetNum((char *)"shc.number_timeouts_markbindown")>0)
			{
				struct RoutingInfo routingInfo = {0};
				int len=sizeof(routingInfo);
				thisHeader->getSegmentData((char *)&routingInfo, &len, NETWORK_DATA_REQ_id,ROUTING_INFO);
				if(len>0)
					binRouteObj->incCounter(&routingInfo);
				else
					OTraceDebug("D-SHC-9834: unable to get routingInfo len[%d]\n", len);
			}
		}
		else if(!shcIsRequest(thisHeader) && !mbIsEvent())
		{
			if(thisShcApp->acquirerShcParamsList->GetNum((char *)"shc.number_timeouts_markbindown")>0)
			{
				struct RoutingInfo routingInfo = {0};
				int len=sizeof(routingInfo);
				thisHeader->getReqSegmentData((char *)&routingInfo, &len, NETWORK_DATA_REQ_id,ROUTING_INFO);
				if(len>0)
					binRouteObj->resetCounter(&routingInfo);
				else
					OTraceDebug("D-SHC-9835: unable to get routingInfo len[%d]\n", len);
			}
		}
		if (shcIsResponse(thisHeader))
		{
			char buf[32];
			int len = sizeof(buf);
			thisHeader->getSegmentData(buf, &len, NETWORK_SETTLEMENT_DATA_RESP_id, TS_TO_ISSUER);
			if (len <= 0)
			{
				/* try to restore timestamp_from_issuer from request */
				len = sizeof(buf);
				thisHeader->getReqSegmentData(buf, &len, NETWORK_SETTLEMENT_DATA_RESP_id, TS_TO_ISSUER);
				if (len > 0)
				{
					thisHeader->setSegmentData(buf, strlen(buf), NETWORK_SETTLEMENT_DATA_RESP_id, TS_TO_ISSUER);
				}
			}
		}
		if ( (shcTxn=classify())!=NULL )
		{
			shcTxn->process();
		}
		else
		{
			OTraceError("E-SHC-9819:Can't classify the txn\n");
		}
	}

	thisShcApp->shcmsgHelperObj->shc_stats(thisHeader);
	thisShcApp->shcmsgHelperObj->checkRouting(thisHeader);
	if (log() < 0)
	{
		OTraceWarning("W-SHC-9820:Log failed, messages will not be sent\n");
		thisShcApp->shcHelperObj->reset_mb_cache();
		return 0;
	}
	

	if (thisHeader->shcerr & SH_SETTIMER)
	{
		//create timestamp for sending to issuer
		struct timeb tmpTime;
		ftime(&tmpTime);
		char buf[32];
		snprintf(buf, sizeof(buf), "%ld.%3.3d", tmpTime.time, (int)tmpTime.millitm);
		//thisHeader->setSegmentData(buf, strlen(buf), NETWORK_SETTLEMENT_DATA_RESP_id, TS_TO_ISSUER);

		thisShcApp->shcTimerObj->shc_time_message_x( thisHeader, (unsigned char *)thisHeader->segment );
		if (	(thisHeader->msg.msgtype == SHC_OD_REQ) &&
				(thisHeader->msg.device_cap & SH_DEVCAP_FROM_REPLAY)
		   )
			thisHeader->msg.netcode = thisHeader->eventId;
	}

	route();
	
	int tmp_delaySendCachedMsg = delaySendCachedMsg;
	thisShcApp->shcHelperObj->flush_mb_cache();
    struct timeb tmpTime;
    ftime(&tmpTime);
    OTraceInfo("I-SHC-9829: Messages out at %ld %d\n", tmpTime.time, tmpTime.millitm);
	
	if( shcTxn )
	{
		delaySendCachedMsg = tmp_delaySendCachedMsg;	//if we decided to delay send for other msg, we should delay here as well
		thisShcApp->shcmsgTxnHelperObj->shc_check_ndke(thisHeader);
		thisShcApp->shcHelperObj->flush_mb_cache();
	}
	
	
	return(0);
	
}


ShcmsgProcessor::ShcmsgProcessor(char *msgbuf)
{
	header = shcHeaderRegister.getTargetObj( (struct shcmsg *)msgbuf);
	
	if (!header)
	{
		OTraceError("E-SHC-9821: Can't create header\n");
		return;
	}
	
	shcTxn = NULL;
}
