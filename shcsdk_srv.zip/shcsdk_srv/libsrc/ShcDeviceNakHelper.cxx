static char _ShcDeviceNakHelper_cxx_what[] = "@(#) ShcDeviceNakHelper.cxx 1.5 04/08/24 17:53:51";

/*
 *  Copyright (C) 2004 eFunds Corporation ("eFunds").  All Rights Reserved.     
 *  eFunds Canada Corporation is an authorized user.                            
 *                                                                              
 *  IST is a registered trademark of eFunds Corporation.  Other brand or        
 *  product names are trademarks or registered trademarks of their respective   
 *  holders.                                                                    
 *                                                                              
 *  The information contained herein is the unpublished proprietary property    
 *  of eFunds.  Except as specifically authorized in writing by eFunds, the     
 *  holder of this document shall: i) keep all information contained herein     
 *  confidential, and ii) protect the information, in whole or in part, from    
 *  disclosure and dissemination to all third parties.                          
 *                                                                          
 *  This document and the software described in it are furnished under license  
 *  and may be used or copied only in accordance with the terms of such license.
 *  This document is supplied for information purposes only, is subject to      
 *  change without notice, and should not be construed as a commitment by       
 *  either eFunds Corporation or eFunds Canada Corporation. 
 */
/*
 *
 *                        MODIFICATION HISTORY                  REVIEW
 *
 *	SPR#	Who	Date	Description			Who	Date   
 * ===========================================================================
 *	ad		24nov92		Added logic to route an ACK
 *	ad		05mar94		If no 9000 pending then just stop processing.
 *  la      12may96     Patch recommened from support (dk) for mailbox events.
 *  wrg     961115      Added forward-NAK support
 *  wrg     961204      Added support for timer-segment ops 
 *  yh R001564 23Mar99  Also use new_amount for partial reversal
 *  R007062	gbeeng	26Nov2001	C++ Migration
 */

//File Number 71

#include <stdio.h>
#include <string.h>
#include <oasis.h>
#include <ist_otrace.h>
#include <mb.h>
#include <shc.h>
#include <tm.h>
#define SHC_DEVICE_SRC
#include <shc_util_funcs.h>

#include <ShcmsgHelper.h>
#include <ShcDeviceNakHelper.h>
#include <ShcDeviceNak.h>
#include <ShcApp.h>
#include <ShcBin.h>
#include <ShcmsgTxnHelper.h>


/*****************************************************************************/
int ShcDeviceNakHelper::removeNakEvent(ShcmsgHeader *header)
{
	if( header->msg.msgtype == SHC_DEVICE_NAK )
		if(thisShcApp->shcmsgHelperObj->shc_locate_device_message(header) < 0)
			return(-1);

	/*	Remove from the event queue */
	tm_dequeue(header->eventId);
	OTraceWarning("W-SHC-071001:Device nak trace: %d\n", header->msg.trace);
	
	return 0;
}

/*****************************************************************************/
int ShcDeviceNakHelper::forwardNak(ShcDeviceNak *nakTxn, ShcmsgHeader *header)
{
	/* new 13jan97 */
	if( (header->issBinValid()) && shcmsgHeaderFwdNak( header ) )
	{
		/* restore message type if was not timed out ACK */
		if ( header->msg.msgtype < SHC_DEVICE_ACK )
			header->msg.msgtype += SHC_DEVICE_ACK; 
		/* let shc_route handle forwarding the message */
		header->shcerr = SH_SENDISS;
		header->msg.revcode  = nakTxn->save_revcode;
		memcpy(&header->msg.aval_balance,&nakTxn->save_aval_bal,sizeof(nakTxn->save_aval_bal));

		/* R001564 */
		memcpy(&header->msg.new_amount, &nakTxn->save_new_amount, sizeof(nakTxn->save_new_amount));
		
		return 0;
	}
	return (-1);
}

/*****************************************************************************/
int ShcDeviceNakHelper::generateRevReq(ShcDeviceNak *nakTxn, ShcmsgHeader *header)
{
	if(header->msg.respcode == SHC_RC_Approved || header->msg.respcode == SHC_RC_DeviceTimeOut)
	{
		/*	There is something to reverse */
		header->msg.respcode = nakTxn->save_respcode;
		header->msg.revcode  = nakTxn->save_revcode;
		memcpy(&header->msg.aval_balance,&nakTxn->save_aval_bal,sizeof(nakTxn->save_aval_bal));

		/* R001564. */
        memcpy(&header->msg.new_amount, &nakTxn->save_new_amount, sizeof(nakTxn->save_new_amount));

//		return( shc_revreq(header) );
		if (thisShcApp->shcmsgTxnHelperObj->enqueueInternalMsg(&header->msg) == NULL)
			return -1;
	}
	
	return 0;
}

/*****************************************************************************/

