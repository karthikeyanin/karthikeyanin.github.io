static char _ShcAdminReq_cxx_what[] = "@(#) ShcAdminReq.cxx 1.7 09/03/04 08:09:57";

/*
 *  Copyright (C) 2004 eFunds Corporation ("eFunds").  All Rights Reserved.     
 *  eFunds Canada Corporation is an authorized user.                            
 *                                                                              
 *  IST is a registered trademark of eFunds Corporation.  Other brand or        
 *  product names are trademarks or registered trademarks of their respective   
 *  holders.                                                                    
 *                                                                              
 *  The information contained herein is the unpublished proprietary property    
 *  of eFunds.  Except as specifically authorized in writing by eFunds, the     
 *  holder of this document shall: i) keep all information contained herein     
 *  confidential, and ii) protect the information, in whole or in part, from    
 *  disclosure and dissemination to all third parties.                          
 *                                                                          
 *  This document and the software described in it are furnished under license  
 *  and may be used or copied only in accordance with the terms of such license.
 *  This document is supplied for information purposes only, is subject to      
 *  change without notice, and should not be construed as a commitment by       
 *  either eFunds Corporation or eFunds Canada Corporation. 
 *
 *
 *                        MODIFICATION HISTORY                  REVIEW
 *
 *	SPR#	Who	Date	Description			Who	Date   
 * ===========================================================================
 *R019844	LS	04May07	Included Normalizepan funtionality in enrich.
 *R00xxxx
 *R026138	sks	04Mar09	Populate Settlement Date field
 */
/* File Number 54 */

#include <stdio.h>
#include <string.h>
#include <ctype.h>
#include <oasis.h>
#include <ist_otrace.h>
#include <shc.h>
#include <ShcAdminReq.h>
#include <ShcAdminReqHelper.h>
#include <ShcmsgHelper.h>
#include <ShcSaf.h>
#include <ShcApp.h>
#include <ShcmsgTxnHelper.h>	//	---	R026138
#include <ShcTimerHelper.h>

#define P1C_DEST "50"

int ShcAdminReq::enrich()
{
	if (header->createdInternal())
		return 0;

	thisShcApp->shcmsgTxnHelperObj->setCapDate(header);	//	---	R026138
	thisShcApp->shcAdminReqHelperObj->checkMac(header);
	thisShcApp->shcmsgHelperObj->shc_normalizepan(header->msg.pan);	//	R019844
	
	return 0;
}

int  ShcAdminReq::doWork()
{
	/*
	 * 0600/0620/0602/0622 are handled here
	 */
	int timeoutUsed = 0;
	long issuerTimeOut = 0;
	issuerTimeOut = header->issShcBin->binPkg->bin.timeout;
	timeoutUsed = issuerTimeOut;
	header->time_out = shc_current_time + timeoutUsed;
	if( ! header->shouldContinue(TXN_PROC_SKIP_DOWORK) )
		return 0;

	int ret = -1;

	if (thisShcApp->shcAdminReqHelperObj->checkReplay(header) < 0)
		return 0;

	header->msg.respcode = SHC_RC_Approved;

	char p1cInst[MAX_TXN_DESTINATION_LEN+1];
	int inst_ret_value = shc_getInstitutionIdFromCardScheme(p1cInst, P1C_DEST);
	OTraceDebug("D-SHC-09002: Check for Destination Admin Request [%s]\n",p1cInst);
	thisShcApp->shcAdminReqHelperObj->processFromMember(header);
        if((shc_isdown(header->issShcBin->binPkg)) && (header->msg.netcode == SHC_TKN_REQ) && (strcmp(header->msg.txnDest, p1cInst)==0))
        {
                OTraceDebug("E-SHC-09001: BIN is down, so ignoring the transaction\n");
                header->logFlag |= SHC_LOG_REQ;
                header->shcerr = SH_IGNORE;
                return (0);
        }

	if((header->msg.netcode == SHC_TKN_REQ) || (header->msg.reason_code == 3700) || (header->msg.reason_code == 3711) || (header->msg.reason_code == 3701) || (header->msg.reason_code == 3702) || (header->msg.reason_code == 3703))
	{
		header->logFlag |= SHC_LOG_REQ;
		thisShcApp->shcTimerObj->shc_time_message(header);
		header->shcerr = SH_SENDISS;
		return (0);
	}
	
    if (header->msg.netcode == 174)
    {
		header->logFlag |= SHC_LOG_REQ;
        header->shcerr = SH_IGNORE;
        return (0);
    }

	thisShcApp->shcmsgHelperObj->shc_set_return_msgno(&header->msg);

    header->shcerr = SH_RETURN;

	thisShcApp->shcAdminReqHelperObj->processFromNetwork(header);
	
	return(0);
}




//int ShcAdminReq::(ShcmsgHeader *header)
//{
//}


/*
 *	SPR#	Who	Date	Description			Who	Date   
 * ===========================================================================
 *	ad		21dec91		Check for duplicate advice transactions and
 *						avoid logging them. Also check the return of
 *						logRepeate to determine if error, duplicate or new.
 *	ad		03Jan92		Do not assign origtrace if already set
 *	ad		18jun92		Added more descriptive ODebug's for denial resons
 *	ad		17aug92		If exp date flag is NOT set then call validate_date
 *	ss		05Nov92		Check if txn amount over SAF MaxTxnLimit if issuer down.
 *	ad		16nov92		Modified fix of 05nov92 to include POS txn's as well
 *	ad		26nov92		Added check for 'PREAUTH_ON_VALIDATE'
 *						If sending pre-auth, then set the saf flag if the
 *						issuer is down.
 *	ss		12Jan93		if msg is PREAUTH_RESP, set timer up
 *	ad		29apr93		Added support for duplicate txn checking.
 *	ad		05may93		Changed repeat checking NOT to include 101 messages
 *	jsn		06May93		shc_verify_check_digit(): now skip lead zeroes 	 
 *	ss		11Jun93		Reconstruct missing code from Oasis machine. Seem
 *						missing code to log transaction into DB.
 *	MI		22Jun93		Dropped preauth request if not supported.
 *	MI		26Jul93		Do not need any edits for processed conf req
 *	ad		22dec93		Removed PIN requiremnt for service codes
 *	pk		17Feb94		This is due to reversals being mirrored across 
 *						the alt node
 *	jsn		30mar94		shc_checkscode() comment out check between country
 *						codes of acq and iss.
 *	ad		14may94		Added code to mark a duplicate advice for later
 *						use in shc
 *	ad		16nov94		Corrected change made by PAHIA. Moved code AFTER
 *						check for pre-auth resp. We cannot lose the response
 *						code generated by the response agent.
 *						Added code that rejects a transaction if it is a
 *						duplicate.
 *	ss		09Mar95		Check iss_minamount and acq_minamount for transaction.
 * 10001592 qd  18mar96	Check txn.amount if acq and iss has the same currency 
 * 10001592 la  27mar96 Instead check the txn.amount if the txn.currency and
 *                       the iss.currency is the same.
 * 10001455 la  28mar96 Expect shc_iscardexpired() to set the response code.
 *  2002847 qd  27mar97 Set origmsg, origdate and origtime iff origmsg is zero 
 *  R001538 qd  03mar99 Added CVV2 support
 *	R003357	HJ	01Nov99 Delete leading zero in pan
 *	R004595	HJ	01Jun00	Original capture date in 420 should be tomorow's date
 *	R004832, R004686 jy	05Dec00	Checking duplicate 100 msg of Europay)
 *	R005871 jy	03Apr01	Truncate trailing spaces of PAN in shc_verify_check_digit()
 *	R005887	jy	04Apr01 Added shc_setCvvResultCode(), shc_getCvvResultCode() 
 * 						and shc_checkCvvCvv2() functions
 *R006401 ztang	21Jun01	set new field cvv_resultcode with '\0', 'M' and 'N'
 * R007062	gbeeng	26Nov2001	C++ Migration
 *R007206 jyang 04Oct01	Add a new func to check Europay BIN/MBR table
 *R007237 jyang 05Dec01 Support to validate "Acquirer Profiles" for Europay
 *R007211 ztang 22Jan02 Changed logic of processing repeat messages
 *R007615 jyang 19Mar02 Prevent from logging duplicate advice/repeat txn
 *R007612 jyang 20Mar02 Enable to handle cash advance with pcode=01 for 
 *						Europay Profiles checking
 *R007672 jyang 04Apr02 Instead of return DuplcateTxn, relay advice message 
 *						which original being reversed
 *R007855 jyang 02Jun02 Switch the sequence of checking PIN and HotCard
 *R007909 Emj   13Jun02 Added new callback shc_edit_transaction
 *R008224 ztang 13Sep02 Added void transaction support
 *R008464 jyang 25Oct02 Refresh the pointer of pin_data for VOID txn
 *R009100 jyang 11Feb03 Set SH_DEVCAP_NOPIN flag as no pin data
 *R009807 jyang 10Jun03 Check duplicate for financial txn
 */






