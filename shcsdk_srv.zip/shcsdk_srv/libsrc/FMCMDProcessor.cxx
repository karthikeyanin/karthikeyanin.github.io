//
// Copyright (C) 2004 eFunds Corporation ("eFunds").  All Rights Reserved.
// eFunds Canada Corporation is an authorized user.
//
// IST is a registered trademark of eFunds Corporation.  Other brand or
// product names are trademarks or registered trademarks of their respective
// holders.
//
// The information contained herein is the unpublished proprietary property
// of eFunds.  Except as specifically authorized in writing by eFunds, the
// holder of this document shall: i) keep all information contained herein
// confidential, and ii) protect the information, in whole or in part, from
// disclosure and dissemination to all third parties.
//
// This document and the software described in it are furnished under license
// and may be used or copied only in accordance with the terms of such license.
// This document is supplied for information purposes only, is subject to
// change without notice, and should not be construed as a commitment by
// either eFunds Corporation or eFunds Canada Corporation.
//
 /*
 *  SCR     Who   Date     Description
 *  ===========================================================================
 *  R020052 spa   21May07  New file created
 *	R026365 vmp   13Apr09	Added code for FM PhaseII enhancement	
 */

/* File Number 158 */

#include <FMCMDProcessor.h>
#include <ShcApp.h>
#include <FMBlockRegistration.h>
#include <FMCMDHeader.h>	//	---	R026365

FMCMDProcessor :: FMCMDProcessor(char *msgbuf)
{
	header = (FMCMDHeader *)shcHeaderRegister.getTargetObj(msgbuf);
	shcTxn = NULL;
}

ShcBaseTxn *FMCMDProcessor :: classify()
{
	return FMBlockRegister.getTargetObj(header);
}

int FMCMDProcessor :: getBINs()
{
	//do nothing
	return 0;

}

int FMCMDProcessor :: log()
{
	//	>>>	R026365
	FMCMDHeader *thisHeader = (FMCMDHeader*)header;
	if (thisHeader->blockCMD.msgtype == SHC_FM_CMD_RESP)
	{
		if ( dbm_commit(0) < 0)
		{
			if (dbm_errno == DBME_DISCONNECT)
			{
				OTraceFatal("F-SHC-158002: disconnected from database, exiting\n");
				kill(getpid(),1);
			}
			OTraceDebug("E-SHC-158003: dbm_commit failed, rollback and continue\n" );
			if (dbm_rollback(0) < 0)
			{
				OTraceDebug("E-SHC-158004: rollback failed\n");
			}
			return -1;
		}
	}
	//	<<<	R026365
	//do nothing
	return 0;

}

int FMCMDProcessor :: route()
{
	//do nothing
	return 0;

}

int FMCMDProcessor :: process()
{
	int ret;//	---	R026365
	shcTxn = classify();

	if( !shcTxn )
	{
		OTraceError("E-SHC-158001: Unable to classify the txn\n");
		return (-1);
	}
	//	>>>	R026365
	ret = shcTxn->process();
	log();
	return ret;
	//	<<<	R026365
}



