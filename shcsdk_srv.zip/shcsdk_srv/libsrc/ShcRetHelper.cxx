static char _ShcRetHelper_cxx_what[] = "@(#) ShcRetHelper.cxx 1.4 04/08/24 17:54:20";

/*
 *  Copyright (C) 2004 eFunds Corporation ("eFunds").  All Rights Reserved.     
 *  eFunds Canada Corporation is an authorized user.                            
 *                                                                              
 *  IST is a registered trademark of eFunds Corporation.  Other brand or        
 *  product names are trademarks or registered trademarks of their respective   
 *  holders.                                                                    
 *                                                                              
 *  The information contained herein is the unpublished proprietary property    
 *  of eFunds.  Except as specifically authorized in writing by eFunds, the     
 *  holder of this document shall: i) keep all information contained herein     
 *  confidential, and ii) protect the information, in whole or in part, from    
 *  disclosure and dissemination to all third parties.                          
 *                                                                          
 *  This document and the software described in it are furnished under license  
 *  and may be used or copied only in accordance with the terms of such license.
 *  This document is supplied for information purposes only, is subject to      
 *  change without notice, and should not be construed as a commitment by       
 *  either eFunds Corporation or eFunds Canada Corporation. 
 *
 *
 *                        MODIFICATION HISTORY                  REVIEW
 *
 *	SPR#	Who	Date	Description			Who	Date   
 * ===========================================================================
 *R00xxxx ztang 16Jan03 Creation
 */
/* File Number 114 */

#include <stdio.h>
#include <string.h>
#include <ctype.h>
#include <oasis.h>
#include <ist_otrace.h>
#include <shc.h>
#include <shcdef.h>
#include <CShcLog.h>
#include <ShcRetHelper.h>
#include <ShcMacHelper.h>
#include <ShcFinAuthHelper.h>
#include <ShcmsgHelper.h>
#include <ShcCamHelper.h>
#include <ShcmsgProcessor.h>
#include <ShcApp.h>
#include <ShcmsgTxnHelper.h>
#include <ShcBin.h>



int ShcRetHelper::checkMac(ShcmsgHeader *header)
{
	if (header->issBinValid() && header->acqBinValid())
	{
		OTraceWarning("W-SHC-114001:Agent encounters error while parsing request messages.\n");
		if ( header->msg.msgtype == SHC_ISS_ADMIN ||
			header->msg.msgtype == SHC_ISS_ADMIN_ADVICE)
		{
			thisShcApp->shcmsgTxnHelperObj->verifyIssMac(header);
		}
		else if(header->msg.msgtype == SHC_CHARGE_BACK_ADVICE)
		{
			thisShcApp->shcRetHelperObj->verifyIssMacUsingAcqKey(header);
		}
//		if (header->msg.msgtype == SHC_AUTHREQ ||
//			header->msg.msgtype ==  SHC_FINREQ ||
//			header->msg.msgtype == SHC_FINREQ_ADVICE ||
//			header->msg.msgtype == SHC_REVREQ_ADVICE  ||
//			header->msg.msgtype == SHC_ADMIN  ||
//			header->msg.msgtype == SHC_ADMIN_ADVICE  ||
//			header->msg.msgtype == SHC_NETWORK  )
		else
		{
			thisShcApp->shcmsgTxnHelperObj->verifyAcqMac(header);
		}

		return(-1);
	}
	return 0;
}

int ShcRetHelper::verifyIssMacUsingAcqKey(ShcmsgHeader *header)
{
	if ( shcIsVerifyMac(header->issShcBin->binPkg) ) 
		header->issShcBin->shcmac_verify(header, SHC_ACQ_KEY);
	return 0;
}







