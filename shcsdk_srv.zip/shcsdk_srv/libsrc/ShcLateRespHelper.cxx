static char _ShcLateRespHelper_cxx_what[] = "@(#) ShcLateRespHelper.cxx 1.10.1.8 20/02/10 07:33:56";

/*
 *  Copyright (C) 2004 eFunds Corporation ("eFunds").  All Rights Reserved.
 *  eFunds Canada Corporation is an authorized user.
 *
 *  IST is a registered trademark of eFunds Corporation.  Other brand or
 *  product names are trademarks or registered trademarks of their respective
 *  holders.
 *
 *  The information contained herein is the unpublished proprietary property
 *  of eFunds.  Except as specifically authorized in writing by eFunds, the
 *  holder of this document shall: i) keep all information contained herein
 *  confidential, and ii) protect the information, in whole or in part, from
 *  disclosure and dissemination to all third parties.
 *
 *  This document and the software described in it are furnished under license
 *  and may be used or copied only in accordance with the terms of such license.
 *  This document is supplied for information purposes only, is subject to
 *  change without notice, and should not be construed as a commitment by
 *  either eFunds Corporation or eFunds Canada Corporation.
 *
 *
 *                        MODIFICATION HISTORY                  REVIEW
 *
 *	SPR#	Who	Date	Description			Who	Date
 * ===========================================================================
 *R00xxxx ztang 16Jan03 Creation
 *R022021 Emj   20Nov07 Set acquirer parameter list if is NULL
 *R024824 uhb   26Sep08 late 0210 missing seg area in shcmsg when sent to LateRspServer
 *R027905 dipa  25Mar10 Reversal-Void Enhancement
 *R028271 dipa  09Jul10 Txn Statistics
 *R030381 dipa  02Mar12 Txn Statistics - changes
 */
/* File Number 114 */

#include <stdio.h>
#include <string.h>
#include <ctype.h>
#include <oasis.h>
#include <ist_otrace.h>
#include <mb_umi.h>
#include <shc.h>
#include <shcdef.h>
#include <CShcLog.h>
#include <ShcLateRespHelper.h>
#include <ShcMacHelper.h>
#include <ShcFinAuthHelper.h>
#include <ShcMsgCache.h>
#include <ShcmsgHelper.h>
#include <ShcCamHelper.h>
#include <ShcmsgProcessor.h>
#include <ShcApp.h>
#include <ShcmsgTxnHelper.h>
#include <ShcBin.h>
//R028271 >>>
#include <TxnStat.h>
//<<< R028271
#include <istsafe.h>
/*File Number 163*/

static int mid = -1;
static 	int laterrev_id = -1;


int ShcLateRespHelper::processLateResp(ShcHeader  *tmpHeader)
{
	ShcmsgHeader *header = (ShcmsgHeader *)tmpHeader;
	if (!shcApp->issuerShcParamsList)
		thisShcApp->shcmsgTxnHelperObj->setParamSet(header);

	//Needs to change the late response shclog_id because there is a small chance it's restored from request

	char tmpLogId[sizeof(header->msg.shclog_id)+1];
	//strcpy(tmpLogId, header->msg.shclog_id);
	istsafe_strcpy(tmpLogId, (sizeof(header->msg.shclog_id)+1), header->msg.shclog_id);

	mb_getUmi(header->msg.shclog_id, sizeof(header->msg.shclog_id));
	OTraceLog("L-SHC-163020: Replace ID [%s] with ID [%s]\n", tmpLogId, header->msg.shclog_id);
    TxnStatEquate(tmpLogId, header->msg.shclog_id);

	if ( header->setIssShcBin(header->msg.issuer) == -1 )
	{
		if (!(shcApp->issuerShcParamsList->GetBool((char *)"shc.reversalOnLateResp")))
		{
			OTraceInfo("E-SHC-163021: Issuer [%s] can't be located in shcbin table. default inst level lateRespRev is disabled. Late response not processed\n", header->msg.issuer);
		return -1;
		}
		else
			OTraceInfo("E-SHC-163022: Issuer [%s] can't be located in shcbin table. default inst level lateRespRev is enabled.\n", header->msg.issuer);
	}
	else
		if ( !(header->issShcBin->binPkg->bin.bin_cfg & SH_REV_LATERESP) &&
		 	!(shcApp->issuerShcParamsList->GetBool((char *)"shc.reversalOnLateResp")))
			return -1;
	if (strncmp(tmpHeader->getName(), SHC_ShcmsgHeader, strlen(SHC_ShcmsgHeader))!= 0)
	{
		OTraceInfo("I-shcLateRev-402:Not ShcmsgHeader[%s], ignore\n", tmpHeader->getName());
		return -1;
	}
	OTraceInfo("I-SHC-163001:Process the late Response.\n" );


	if (shcmid < 0)
		shcmid = mb_locatemailbox(SHC_SERVER_NAME);
    if(shcmid < 0)
    {
        OTraceFatal("F-SHC-163002:Unable to locate switch at '%s'\n",SHC_SERVER_NAME);
        return -1;
    }
	laterrev_id = mb_locatemailbox("ShcLateRev");
    if( laterrev_id < 0 )
    {
        OTraceError("E-SHC-163003:Unable to connect later reversal util srv. Late Response not processed\n");
        return -1;
    }
	if ( mid < 0 )
    {
        if ( (mid = mb_createmailbox("passtoLateResp", getpid(), 0L)) < 0 )
        {
            OTraceFatal("F-SHC-163004:Unable to create required mailbox:%s.\n", "passtoLateResp");
            throw 1;
        }
    }
	// late 0110/0210 late response support
	if((header -> msg.msgtype == SHC_AUTHREQ_RESPONSE|| header -> msg.msgtype == SHC_FINREQ_RESPONSE )&&
       (header -> msg.shc_devcap & SH_DEVCAP_SHC_LATE_RESPONSE) )
	{
		TxnStatReport(header->msg.shclog_id,TS_SHC,TSR_SEND,header->msg.msgtype,0,laterrev_id);
		if (header->msg.local_time <=0)
		{
			struct shcmsg tmpOldMsg;
			OTraceDebug("D-SHC-073018: local_time[%d]\n", header->msg.local_time);
			OTraceDebug("D-SHC-073019: Tring to get local_time and local_date from 200 message shclog_req...\n"); 
			int ret = ((ShcLog *)header->shcLogObj)->locateTxnRefnum(header, &tmpOldMsg, IST_SHCLOG_FLAG_LOCATE_REQ);
			if(ret>=0)
			{
				header->msg.local_time = tmpOldMsg.local_time;
				header->msg.local_date = tmpOldMsg.local_date;
				OTraceDebug("D-SHC-073020: local_time[%d] local_date[%d] retrieved from shclog_req.\n",
							 tmpOldMsg.local_time, tmpOldMsg.local_date);
			}
			else
			{
				OTraceDebug("D-SHC-073021: failed to retrieve from shclog_req.\n");
			}
		}
		//	>>>	R024824
		//if(mb_write(laterrev_id,mid,&header->msg,sizeof(header->msg))<0)
        if(cache_mb_write(laterrev_id,mid,(char *)&header->msg,header->truelength())<0)
		//	<<<	R024824
        {
            OTraceError("E-SHC-163005:Unable to write to late reversal srv %d.\n",
                    laterrev_id );
            return -1;
        }
        OTraceInfo("I-SHC-163006:late response %d  sent.\n" ,header -> msg.msgtype);
	}

	return 0;
}


int ShcLateRespHelper::processTimeOutReversal(ShcmsgHeader *header)
{
	if (!(header->issShcBin->binPkg->bin.bin_cfg & SH_REV_LATERESP) &&
		!(shcApp->issuerShcParamsList->GetBool((char *)"shc.reversalOnLateResp")))
		return -1;

	OTraceInfo("I-SHC-163007:prcLateRev function executed.\n" );
	int laterrev_id = -1;
	int shcmid = -1;

	shcmid = mb_locatemailbox(SHC_SERVER_NAME);
    if(shcmid < 0)
    {
        OTraceFatal("F-SHC-163008:Unable to locate switch at '%s'\n",SHC_SERVER_NAME);
        throw 1;
    }
	laterrev_id = mb_locatemailbox("ShcLateRev");
    if( laterrev_id < 0 )
    {
        OTraceError("E-SHC-163009:Unable to connect late reversal util srv\n");
        return -1;
    }
	if ( mid < 0 )
    {
        if ( (mid = mb_createmailbox("passtoLateRev", getpid(), 0L)) < 0 )
        {
            OTraceFatal("F-SHC-163010:Unable to create required mailbox.\n");
            throw 1;
        }
    }
	// late reversal 0420 support
	if((header -> msg.msgtype == SHC_REVREQ_ADVICE || header -> msg.msgtype == SHC_REVREQ_ADVICE_REPEAT )&&
//      !(header -> msg.serial_1 & CUSC_LATER_REVERSAL) &&
       header -> msg.device_cap & SH_DEVCAP_INTERNALREV &&
      header -> msg.respcode == 8 )
	{
		if( header -> msg.msgtype != SHC_REVREQ_ADVICE )
            header -> msg.msgtype = SHC_REVREQ_ADVICE;
		struct  shcseg  *t_seg;

    	int MsgLength = header->truelength();
 		TxnStatReport(header->msg.shclog_id,TS_SHC,TSR_SEND,header->msg.msgtype,0,laterrev_id);
        if(MsgLength=cache_mb_write(laterrev_id,mid,(char *)&header->msg,MsgLength)<0)
        {
            OTraceError("E-SHC-163011:Unable to write to late reversal srv %d.\n",
                    laterrev_id );
            return -1;
        }
        OTraceInfo("I-SHC-163012:late reversal 420 sent.\n" );
        return 1;
	}
	//R027905 >>>
	else if (header -> msg.msgtype == SHC_REVREQ|| header -> msg.msgtype == SHC_REVREQ_REPEAT)
	{
		int MsgLength = header->truelength();
 		TxnStatReport(header->msg.shclog_id,TS_SHC,TSR_SEND,header->msg.msgtype,0,laterrev_id);
		if(MsgLength=cache_mb_write(laterrev_id,mid,(char *)&header->msg,MsgLength)<0)
		{
			OTraceError("E-SHC-163012:Unable to write to late reversal srv %d.\n", laterrev_id );
			return -1;
		}
		OTraceInfo("I-SHC-163013: 400(original-in-flight/timed-out auth) sent to LRS\n" );
		return 1;
	}
	// <<< R027905

	return 0;
}

// R027905 >>>
int ShcLateRespHelper::processVoid(ShcmsgHeader *header)
{
	if ( !(header->issShcBin->binPkg->bin.bin_cfg & SH_REV_LATERESP) &&
		 !(shcApp->issuerShcParamsList->GetBool((char *)"shc.reversalOnLateResp")))
		return -1;

	OTraceInfo("I-SHC-163014:processVoid function executed.\n" );
	int laterrev_id = -1;
	int shcmid = -1;

	if(!header->isVoidTxn())
		return -1;


	shcmid = mb_locatemailbox(SHC_SERVER_NAME);
	if(shcmid < 0)
	{
		OTraceFatal("F-SHC-163015:Unable to locate switch at '%s'\n",SHC_SERVER_NAME);
		throw 1;
	}
	laterrev_id = mb_locatemailbox("ShcLateRev");
	if( laterrev_id < 0 )
	{
		OTraceError("E-SHC-163016:Unable to connect late reversal util srv\n");
		return -1;
	}
	if ( mid < 0 )
	{
		if ( (mid = mb_createmailbox("passtoLateRev", getpid(), 0L)) < 0 )
		{
			OTraceFatal("F-SHC-163017:Unable to create required mailbox.\n");
			throw 1;
		}
	}

	if (header->msg.msgtype == SHC_FINREQ || header->msg.msgtype == SHC_AUTHREQ)
	{
		int MsgLength = header->truelength();
 		TxnStatReport(header->msg.shclog_id,TS_SHC,TSR_SEND,header->msg.msgtype,0,laterrev_id);
		if(MsgLength=cache_mb_write(laterrev_id,mid,(char *)&header->msg,MsgLength)<0)
		{
			OTraceError("E-SHC-163018:Unable to write to late reversal srv %d.\n", laterrev_id );
			return -1;
		}
		OTraceInfo("I-SHC-163019: 100/200 void txn(original-in-flight/timed-out auth) sent to LRS\n" );
		return 1;
	}
	return 0;
}
// <<< R027905


int ShcLateRespHelper::processRevNoOriginal(ShcmsgHeader *header)
{
	OTraceInfo("I-SHC-163030:Process the Reversal No Original.\n" );

	if (laterrev_id == -1)
	{
		laterrev_id = mb_locatemailbox("ShcLateRev");
	}

    if( laterrev_id < 0 )
    {
        OTraceError("E-SHC-163003:Unable to connect later reversal util srv. Late Response not processed\n");
        return -1;
    }

	if ( mid < 0 )
    {
        if ( (mid = mb_createmailbox("passtoLateResp", getpid(), 0L)) < 0 )
        {
            OTraceFatal("F-SHC-163004:Unable to create required mailbox:%s.\n", "passtoLateResp");
            throw 1;
        }
    }

	if(header->msg.msgtype == SHC_REVREQ || header->msg.msgtype == SHC_REVREQ_ADVICE)
	{
		header->msg.msgtype += 1000;
		
		TxnStatReport(header->msg.shclog_id,TS_SHC,TSR_SEND,header->msg.msgtype,0,laterrev_id);
        if(cache_mb_write(laterrev_id,mid,(char *)&header->msg,header->truelength())<0)
        {
            OTraceError("E-SHC-163005:Unable to write to late reversal srv %d.\n",
                    laterrev_id );
            return -1;
        }

        OTraceInfo("I-SHC-163031:Unmatch reversal Sent to LRS [%s]%d  sent.\n" , header->msg.shclog_id, header -> msg.msgtype);

		header->msg.msgtype -= 1000;
	}

	return 0;
}


