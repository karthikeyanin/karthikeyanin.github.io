static char _ShcRevResp_cxx_what[] = "@(#) ShcRevResp.cxx 1.13 19/06/17 10:26:37";

/*
 *  Copyright (C) 2004 eFunds Corporation ("eFunds").  All Rights Reserved.     
 *  eFunds Canada Corporation is an authorized user.                            
 *                                                                              
 *  IST is a registered trademark of eFunds Corporation.  Other brand or        
 *  product names are trademarks or registered trademarks of their respective   
 *  holders.                                                                    
 *                                                                              
 *  The information contained herein is the unpublished proprietary property    
 *  of eFunds.  Except as specifically authorized in writing by eFunds, the     
 *  holder of this document shall: i) keep all information contained herein     
 *  confidential, and ii) protect the information, in whole or in part, from    
 *  disclosure and dissemination to all third parties.                          
 *                                                                          
 *  This document and the software described in it are furnished under license  
 *  and may be used or copied only in accordance with the terms of such license.
 *  This document is supplied for information purposes only, is subject to      
 *  change without notice, and should not be construed as a commitment by       
 *  either eFunds Corporation or eFunds Canada Corporation. 
 *
 *
 *                        MODIFICATION HISTORY                  REVIEW
 *
 *	SPR#	Who	Date	Description			Who	Date   
 * ===========================================================================
 * R0xxxxx jyang 21Nov03 Created
 * R023659 ram	 19Jun08 Callback prototype changed to improve performance
 * R023762 ram	 28Jun08 Callback changes enclosed inside DSWITCH macro
 */
/* File Number 118 */


/*****************************************************************************/

#include <ShcRevReqHelper.h>
#include <ShcRevResp.h>
#include <ShcApp.h>
#include <ShcmsgTxnHelper.h>
#include <ShcRevRespHelper.h>
#include <ShcmsgHelper.h>
//  >>> R023762
#include <shc_callback.h>	//	---	R023659
//  <<< R023762



/*****************************************************************************/
int ShcRevResp::enrich()
{
	//ShcmsgBaseTxn::enrich();
	if (header->createdInternal())
		return 0;
		
	thisShcApp->shcmsgTxnHelperObj->setDefaultKeyLen(header);
	thisShcApp->shcmsgTxnHelperObj->setOriginator(header);
	thisShcApp->shcmsgHelperObj->shc_normalizepan(header->msg.pan);
	
	thisShcApp->shcRevRespHelperObj->locateRevReqEvent(header);
	if (!(header->issBinValid()) || !(header->acqBinValid()))
	{
		header->setReturnFlag(header->msg.respcode);
		return -1;
	}
	
//	thisShcApp->shcmsgTxnHelperObj->setParamSet(header);
	thisShcApp->shcmsgTxnHelperObj->setCapDate(header);
	thisShcApp->shcmsgHelperObj->shc_get_pin_data(header);
	thisShcApp->shcmsgTxnHelperObj->setCurrencyCode(header);
	thisShcApp->shcmsgTxnHelperObj->initFromDevice(header);
	thisShcApp->shcmsgTxnHelperObj->setAcqCountry(header);
	thisShcApp->shcmsgTxnHelperObj->decideTimeOutValue(header);
	thisShcApp->shcmsgHelperObj->setPinParm(header);
	thisShcApp->shcmsgTxnHelperObj->setOnlineActivity(header);
	OTraceInfo("I-SHC-118001: (header) enrich(iss=%s, acq=%s),(txnSrc=%s, txnDest=%s)\n",
			header->msg.issuer, header->msg.acquirer,
			header->msg.txnSrc, header->msg.txnDest);


	thisShcApp->shcRevRespHelperObj->verifyRespRevMac(header);
	return 0;
}


/*****************************************************************************/
int ShcRevResp::restore()
{
	if ( header->createdInternal() )
		return 0;
		


	thisShcApp->shcRevRespHelperObj->restoreRespReversal(header);		////////////////////////
 
	if (header->reqMsg)
	{
		::tmpShcOmsg = header->reqMsg;
		shc_callback(header, "post_reversal_restore_event");
	}

	return 0;
}

/*****************************************************************************/
int ShcRevResp::edit()
{
	
	return 0;
}


/*****************************************************************************/
int ShcRevResp::doWork()
{
	if( ! header->shouldContinue(TXN_PROC_SKIP_DOWORK) || header->createdInternal() )
		return 0;

	if ( thisShcApp->shcRevRespHelperObj->doReplay(header) == True )
		return 0;

	thisShcApp->shcRevRespHelperObj->prepareLog( header );

	thisShcApp->shcRevRespHelperObj->sendToPosauthSever(header);

	thisShcApp->shcRevRespHelperObj->setRoutingFlag(header);

	thisShcApp->shcRevRespHelperObj->writeSaf(header);

	return(0);
}
		
	


/*
 *
 *                        MODIFICATION HISTORY                  REVIEW
 *
 *	SPR#	Who	Date	Description			Who	Date   
 * ===========================================================================
 * ad	24mar92		Made minor changes for accepting ADVICE response
 *			 messages.
 * ss	27Mar92		If the orginal message was from SHCREPLAY then
			 need to return it back to SHCREPLAY.
 * bsa 30jul92 		 made changes to allow for reversals being auth by
 *			 host before switch responding to the acquirer
 * 
 * bsa  13Nov92      	 reset Shcerr to SH_RETURN after locate original  
 *                       due to it being overwritten during update
 * ss	27Nov92		Check for issbin flags for GETAPP_HOST instead.
 * bsa  22dec92		Added code to restore formatter_use data for 410
 *			 response messages.
 * ss	14Apr93		Need to update the original respcode to its 
 *			 original value if revresp is approved.
 *
 * aes	24June93	The acq_currency_code in the SHC_REVREQ will be
 *			 restored in the SHC_REVRESP msg.
 * jsn	03jun93		Restore shc 'termloc' field: CCA was mangling it!
 *			 in future may need to call shc_restore()??
 * la	26Feb94		Update cash_back field which contains the new amount
 *			 in cardholder billing currency.
 * ad	08may94		Update the settlement_amount/fee from the incomming
 *			 410/430 into the database.
 * la	27Jul94		Retain partial dispense flag.
 * ss	26apr95		made 430 to be logged(done by LS).
 * jsg  13Jun95		Process reversal resp without using batch id from recon.
 *                       shc_recon_send() no longer obtains the batch id. Check
 *                       respcode, shcerror to decide whether to send to recon.
 * 10002113 la  01jun96 Ensure transaction is reconcilled.
 * 10002187 la  07jul96 Do not do any processing replay transactions.
 * 10002243 la  09jul96 Must log late reversal response as late, otherwise
 *						a duplicate reversal may occur.
 * 10002273 la  19aug96 Use new APIs and marcos for IBFT processing.
 * 10002675 jsg 961108  Process IBFT reversal responses from replay
 *                      1. Allow IBFT rev-resp to be located/updated
 *                      2. Restore the response code
 *                      3. Restore original pcode
 * 10002113 qd  27feb97 Make sure response is sent back to sender 
 * xxxxxxxx qd  26may97 Added charge back related functionality  
 *  R002003 qd  09nov98 Make sure trace does not change during process
 *  R001564 yh  23Mar99  Also use new_amount for partial reversal 
 *  R001835 qd  06may99 Interac Merge
 *	R001319	rlo	16Feb00	Added code to support reversal response for internal
 *						reversal messages.
 *	R004406	rlo	18Apr00	Fixed logging wrong message type when SH_GETAPP_HOST is
 *						on.
 *	R003895	rlo	20Apr00	Map respcode to 8 for an approved internal reversal.
 *  R004489 jy  03May00 Chargeback reference number is restored.
 *  R004488 jy	17May00	Chargeback/Chargeback Reversal's Reason Code is restored.
 * R004741 jsun 09Jun00 Do not call shcmac_ChgKey(), because
 *                        it is called in shc_process.c shc_check_ndke()
 * 2009291  Rpc 10apr00 restore field acquirer_data on response for SMS
 * 2007336  Ssc 11Apr00 Restore chip data on response for SMS
 * 2007336  Ssc 02Jun00 Added emvbuf pointer to chip_type
 * R004671(SPR2007336) Ssc VSDC enhancement 7.2
 * R004684	jy	05Dec00	Restore origmsg, origtrace, origdate, origtime for Europay
 * R006583	jy	29Aug01	Restore internal reversal flag
 * R006477  jiz 04Sep01 Restore original trace number
 * R007062	gbeeng	26Nov2001	C++ Migration
 *R007234 jyang 07Jan02 Restore field acceptorname from revreq
 *R007209 jyang	09Jan02	Restore pos_entry_mode and log txn_conv_rate,new_setl_fee 
 * 						and ch_new_amount
 *R007231 ztang 21Jan02 Log filler2 in reversal response messages.
 *R007205 ztang 25Jan02 Log ch_new_amount if it's in response
 *R007618 jyang 19Mar02 Send to istauth and update shclog for 430 response from issuer
 *R007063 emj 30Apr02   Restore acquirer ID from original message
 *R007781 ztang 02May02	Fix for restoring filler fields
 *R007953 ztang 17Jun02 Retore fields: pos_condition_code, device_devcap, formatter_devcap,
 *							pos_entry_code, pos_cap_code
 *R008061 emj 15Jul02   Restore revcode from original message
 *R008083 emj 25Jul02   Restore issuer_app_data
 *R008717 ztang 10Dec02 Multi-institution support
 *R009856 ztang 02Jul03 Set late response flag
 */

