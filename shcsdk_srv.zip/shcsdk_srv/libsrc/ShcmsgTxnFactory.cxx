static char _ShcmsgTxnFactory_cxx_what[] = "@(#) ShcmsgTxnFactory.cxx 1.32.3.1 20/05/15 16:59:23";

/*
 *  Copyright (C) 2004 eFunds Corporation ("eFunds").  All Rights Reserved.
 *  eFunds Canada Corporation is an authorized user.
 *
 *  IST is a registered trademark of eFunds Corporation.  Other brand or
 *  product names are trademarks or registered trademarks of their respective
 *  holders.
 *
 *  The information contained herein is the unpublished proprietary property
 *  of eFunds.  Except as specifically authorized in writing by eFunds, the
 *  holder of this document shall: i) keep all information contained herein
 *  confidential, and ii) protect the information, in whole or in part, from
 *  disclosure and dissemination to all third parties.
 *
 *  This document and the software described in it are furnished under license
 *  and may be used or copied only in accordance with the terms of such license.
 *  This document is supplied for information purposes only, is subject to
 *  change without notice, and should not be construed as a commitment by
 *  either eFunds Corporation or eFunds Canada Corporation.
 *
 *
 *                        MODIFICATION HISTORY                  REVIEW
 *
 * SCR#     Who    Date  Description
 * ===========================================================================
 * R016255  spa	12Apr06	 Fix for SPR 2021630;Avoid repeating 220,240,260 etc
 * R020052  spa	21May07	 Added SHC_FM_REQ case
 * R020524 jyang 04Jul07 Added dual-message transaction support
 * R020938 	spa	16Aug07	 IST LM Bridge support
 * R022060  emj 26Nov07  Use thisHeader->acqBinValid to check acquirer bin
 * R027876  dipa 02Mar10 Segment changes
 * R027876  dipa 22Apr10 Segment changes - fix
 * R028104  dipa 29Apr10 routingInfo - fix
 */

//File Number 99

//#include <shc.h>
//#include <shcdef.h>
//#include <shcextbuf.h>
//
//#include <ShcSdkCommon.h>
//#include <ShcHeader.h>
#include <shc.h>
#include <ShcBin.h>
#include <ShcRetShcmsg.h>
#include <ShcIBFTFinReq.h>
#include <ShcFinAuthReq.h>
#include <ShcIBFTFinResp.h>
#include <ShcIBFTRevReq.h>
#include <ShcRevReq.h>
#include <ShcIBFTRevResp.h>
#include <ShcRevResp.h>
#include <ShcNetworkMsg.h>
#include <ShcPreauthResp.h>
#include <ShcBackOfficeReq.h>
#include <ShcChargeBackReq.h>
#include <ShcBackOfficeResp.h>
#include <ShcChargeBackResp.h>
#include <ShcDeviceAck.h>
#include <ShcDeviceNak.h>
#include <ShcServiceReq.h>
#include <ShcLogReq.h>
#include <ShcmsgEventAck.h>
#include <ShcmsgEventAck.h>
#include <ShcmsgEventBO.h>
#include <Shc500Event.h>
#include <Shc300Req.h>
#include <Shc300Resp.h>
#include <ShcAdminEvent.h>
#include <ShcmsgEventFinAuth.h>
#include <ShcmsgEventRev.h>
#include <ShcIBFTEvent.h>
#include <ShcFRSReq.h>
#include <ShcFRSResp.h>
#include <ShcFRSEvent.h>
#include <ShcmsgFMEvent.h>	//	---	R020052
#include <ShcmsgODEvent.h>	
#include <ShcDualMsgHelper.h>
#include <ShcDualMsgEvent.h>
#include <ShcDualFirstMsgReq.h>
#include <ShcDualSecondMsgReq.h>

#include <ShcmsgForwardReq.h>
#include <ShcmsgForwardResp.h>
#include <ShcmsgForwardEvent.h>
#include <BinRoute.h>

#include <ShcmsgTxnFactory.h>
#include <ist_seg_name.h> //R027876
#include <ist_seg_elf_id_map.h> //R027876
#include <ist_seg_id.h> //R027876
#include <ShcDualSiteRetryReversalEvent.h>
#include <istsafe.h>
#include <ShcIstAuthFileUpdateReq.h>
#include <ShcIstAuthFileUpdateResp.h>
#include <ShcIstAuthFileUpdateEvent.h>
#include <ShcStandInByIssuerRespMsgEvent.h>

int isEmptyField(char *s, size_t s_size)
{
    if (s[0] == '\0' )
        return 1;

    int starti, endi, len;
    char tmpBuf[1000];
    len =strlen(s);

    for (starti=0; starti<len && s[starti] == ' '; starti++);
    for (endi=len-1; endi>=starti && s[endi] == ' '; endi--);

    if (endi < starti)
        return 1;

    len=endi-starti+1;
    memcpy(tmpBuf, &s[starti], len);

    tmpBuf[len] = '\0';
    if (tmpBuf[0] == '*' )
        return 1;

    //strcpy(s, tmpBuf);
	istsafe_strcpy(s, s_size, tmpBuf);
    return 0;
}

int ShcmsgTxnFactory::createCondition(char *condition, const void *header)
{
	ShcmsgHeader *thisHeader = (ShcmsgHeader *)header;

	sprintf(condition, "%4.4d%c%c%c%c%c",
			thisHeader->msg.msgtype%10000,
			thisHeader->msg.msgtype < SHC_EVENT?'N':'Y',
			thisHeader->msg.formatter_devcap & SH_FORMATDEVCAP_RETURN?'Y':'N',
			((shcIsTransfer((thisHeader)->msg.pcode) || \
  				shcIsTransfer((thisHeader)->msg.origpcode)) && \
				!isEmptyField((thisHeader)->msg.transferee, sizeof((thisHeader)->msg.transferee)) )?'Y':'N',
			thisHeader->msg.shc_devcap & SH_DEVCAP_SHC_BO_MASK?'Y':'N',
			shcIsLogRequest(thisHeader)?'Y':'N'
			);
	return 0;
}

ShcmsgBaseTxn *ShcmsgTxnFactory::getTargetObj(char *condition, const void *headerBuf)
{
	int l;
	ShcmsgHeader *thisHeader = (ShcmsgHeader *)headerBuf;
	// R027876 >>>
	struct RoutingInfo routingInfo = {0};
	int len;
	// <<< R027876

	int saved_auth_devcap = thisHeader->msg.auth_devcap;

	//Remove this flag to prevent wrong classification in future
	thisHeader->msg.auth_devcap &= ~SH_DEVCAP_AUTH_DUALSITE_REV_EVENT;

	ist_ElfId_t NETWORK_DATA_REQ_id=ElfIdMap::elf_to_id("NETWORK_DATA_REQ");
	if (NETWORK_DATA_REQ_id == (ist_ElfId_t)-1)
	{
		OTraceFatal("F-SHC-099000:Can't find elf id for NETWORK_DATA_REQ, quit...\n");
		throw 1;
	}

	if (shcmsgIsRequest(&thisHeader->msg))
	{
		// R027876, R028104 >>>
		len=sizeof(struct RoutingInfo);
		thisHeader->getSegmentData((char *)&routingInfo, &len, NETWORK_DATA_REQ_id,ROUTING_INFO);
		// <<< R027876, R028104
	}

	else if (thisHeader->reqMsg)
	{
		// R027876, R028104 >>>
		len=sizeof(struct RoutingInfo);
		thisHeader->getReqSegmentData((char *)&routingInfo, &len, NETWORK_DATA_REQ_id,ROUTING_INFO);
		// <<< R027876, R028104
	}


	if ( thisHeader->msg.msgtype < SHC_EVENT )
	{
		RoutingInfo *tmpInfo = NULL;
		if (len) //R028104
			tmpInfo = &routingInfo;

		if (	tmpInfo&&
				tmpInfo->flag & (ROUTE_INFO_FLAG_USE_FOR_REQ | ROUTE_INFO_FLAG_USE_BINROUTE) &&
				(tmpInfo->destNode[0] == '*' || strcmp(tmpInfo->destNode, mbcurrentnode)==0) &&
				(strcmp(tmpInfo->destNode, tmpInfo->srcNode)!=0))
		{
			if (shcmsgIsRequest(&thisHeader->msg))
				return new ShcmsgForwardReq(thisHeader);
			else
				return new ShcmsgForwardResp(thisHeader);
		}
		//	---	R016255
		if ((!shcIsResponse(thisHeader)) && (!thisHeader->issBinValid() ||
			!thisHeader->acqBinValid() ||
			(thisHeader->msg.formatter_devcap & SH_FORMATDEVCAP_RETURN)))
		{
			// If response code is approved  they set as system error
			if ( thisHeader->msg.respcode == SHC_RC_Approved &&
				!(thisHeader->msg.formatter_devcap & SH_FORMATDEVCAP_RETURN) )
			{
				thisHeader->msg.respcode = SHC_RC_SystemError;
			}
			return new ShcRetShcmsg(thisHeader);
		}

		switch(thisHeader->msg.msgtype)
		{
		case	SHC_FINREQ:
		case	SHC_FINREQ_REPEAT:
		case	SHC_FINREQ_ADVICE:
		case	SHC_FINREQ_ADVICE_REPEAT:
		case	SHC_AUTHREQ_ADVICE:
		case	SHC_AUTHREQ_ADVICE_REPEAT:
		case	SHC_AUTHREQ:
		case	SHC_AUTHREQ_REPEAT:
		case    SHC_REPRESENTMENT_ADVICE_MSG:
			if (thisHeader->msg.shc_devcap & SH_DEVCAP_SHC_BO_MASK)
				return new ShcBackOfficeReq(thisHeader);
			else if ( shcIsDualFirstMsg(thisHeader) )
				return new ShcDualFirstMsgReq(thisHeader);	// R020524
			else if ( shcIsDualSecondMsg(thisHeader) )
				return new ShcDualSecondMsgReq(thisHeader);	// R020524
			else if ( condition[6] == 'Y' )
				return new ShcIBFTFinReq(thisHeader);
			else
				return new ShcFinAuthReq(thisHeader);
			break;

		case	SHC_FINREQ_RESPONSE:
		case	SHC_AUTHREQ_RESPONSE:
		case	SHC_POSAUTH_RESPONSE:
		case	SHC_FINREQ_ADVICE_RESPONSE:
		case	SHC_AUTHREQ_ADVICE_RESPONSE:
		case    SHC_REPRESENTMENT_ADVICE_RESP:
			if (thisHeader->msg.shc_devcap & SH_DEVCAP_SHC_BO_MASK)
				return new ShcBackOfficeResp(thisHeader);
			else if ( thisHeader->reqMsg && shcmsgIsIBFT(thisHeader->reqMsg) )
				return new ShcIBFTFinResp(thisHeader);
			else
				return new ShcFinAuthResp(thisHeader);
			break;

		case	SHC_REVREQ:
		case	SHC_REVREQ_REPEAT:
		case	SHC_REVREQ_ADVICE:
		case	SHC_REVREQ_ADVICE_REPEAT:
		case    SHC_AUTHCOMP:
			if ( condition[6] == 'Y')
				return new ShcIBFTRevReq(thisHeader);
			else
				return new ShcRevReq(thisHeader);
			break;

		case	SHC_REVREQ_RESPONSE:
		case	SHC_REVREQ_ADVICE_RESPONSE:
			if ( thisHeader->reqMsg && shcmsgIsIBFT(thisHeader->reqMsg) )
				return new ShcIBFTRevResp(thisHeader);
			else
				return new ShcRevResp(thisHeader);
			break;

		case	SHC_STLMTREQ:
		case	SHC_STLMTREQ_RESPONSE:
			return new Shc500Event(thisHeader);
			break;

		case	SHC_NETWORK:
		case	SHC_NETWORK_ADVICE:
		case	SHC_NETWORK_ADVICE_REPEAT:
		case	SHC_NETWORK_RESPONSE:
		case	SHC_NETWORK_ADVICE_RESPONSE:
			return new ShcNetworkMsg(thisHeader);
			break;
		case	SHC_PREAUTH_RESP:
			return new ShcPreauthResp(thisHeader);

		case	SHC_CHARGE_BACK_ADVICE:
			if (thisHeader->msg.shc_devcap & SH_DEVCAP_SHC_BO_MASK)
				return new ShcBackOfficeReq(thisHeader);
			else
				return new ShcChargeBackReq(thisHeader);
			break;

		case	SHC_CHARGE_BACK_ADVICE_RESPONSE:
			if (thisHeader->msg.shc_devcap & SH_DEVCAP_SHC_BO_MASK)
				return new ShcBackOfficeResp(thisHeader);
			else
				return new ShcChargeBackResp(thisHeader);
			break;

		case SHC_DEVICE_ACK:
			return new ShcDeviceAck(thisHeader);
			break;

		case SHC_DEVICE_NAK:
			return new ShcDeviceNak(thisHeader);
			break;

		case SHC_SERVICE_REQUEST:
			return new ShcServiceReq(thisHeader);
			break;

		case SHC_FRS_ADVICE:
			return new ShcFRSReq(thisHeader);
			break;

		case SHC_FRS_ADVICE_RESPONSE:
			return new ShcFRSResp(thisHeader);
			break;
		case SHC_ISTAUTH_FILE_UPD_REQ:
		case SHC_ISTAUTH_FILE_UPD_REQ_REPEAT:
			return new ShcIstAuthFileUpdateReq(thisHeader);
			break;
		case SHC_ISTAUTH_FILE_UPD_RESP:
		case SHC_ISTAUTH_FILE_UPD_REQ_REPEAT_RESP:
			return new ShcIstAuthFileUpdateResp(thisHeader);
			break;
		default:
			if( shcIsLogRequest(thisHeader) )
			{
				return new ShcLogReq(thisHeader);
			}
			else
			{
				OTraceError("E-SHC-099001: Failed in ShcProcessor::classify(),"
					" msgtype[%04d] eventId[%d]\n", thisHeader->msg.msgtype,
					thisHeader->eventId );
				return NULL;
			}
		}
	}
	else
	{
		thisHeader->msg.msgtype -= SHC_EVENT;
		thisHeader->msg.shc_devcap |= SH_DEVCAP_SHC_EVENT;
		RoutingInfo *tmpInfo = NULL;
		if (len) //R028104
			tmpInfo = &routingInfo;

		if (tmpInfo&& (strcmp(tmpInfo->destNode, mbcurrentnode)==0) &&
			(strcmp(tmpInfo->destNode, tmpInfo->srcNode)!=0))
			return new ShcmsgForwardEvent(thisHeader);

		if ( shcIsIBFT( thisHeader ) )
		{
			return new ShcIBFTEvent( thisHeader );
		}
		else if ( thisHeader->msg.shc_devcap & SH_DEVCAP_SHC_BO_MASK )
		{
			return new ShcmsgEventBO( thisHeader );
		}else if ( shcIsReversal(thisHeader) && 
				(thisHeader->msg.respcode == SHC_RC_NoOriginal) && 
				(saved_auth_devcap & SH_DEVCAP_AUTH_DUALSITE_REV_EVENT) && 
				mbIsDualSite() )
		{
			return new ShcDualSiteRetryReversalEvent( thisHeader );
		}

		switch(thisHeader->msg.msgtype)
		{
		case	SHC_FINREQ:
		case	SHC_FINREQ_REPEAT:
		case	SHC_FINREQ_ADVICE:
		case	SHC_FINREQ_ADVICE_REPEAT:
		case	SHC_AUTHREQ_ADVICE:
		case	SHC_AUTHREQ_ADVICE_REPEAT:
		case	SHC_AUTHREQ:
		case	SHC_AUTHREQ_REPEAT:
			if (thisHeader->msg.shc_devcap & SH_DEVCAP_SHC_BO_MASK)
				return new ShcBackOfficeReq(thisHeader);
			else
				return new ShcmsgEventFinAuth( thisHeader );
			break;

		case	SHC_REVREQ:
		case	SHC_REVREQ_REPEAT:
		case	SHC_REVREQ_ADVICE:
		case	SHC_REVREQ_ADVICE_REPEAT:
			return new ShcmsgEventRev( thisHeader );
			break;

		case	SHC_ADMIN:
		case	SHC_ADMIN_ADVICE:
		case	SHC_ISS_ADMIN:
		case	SHC_ISS_ADMIN_ADVICE:
			if (thisHeader->msg.shc_devcap & SH_DEVCAP_SHC_BO_MASK)
				return new ShcBackOfficeReq(thisHeader);
			else
				return new ShcAdminEvent( thisHeader );
			break;

		case	SHC_STLMTREQ:
		case	SHC_STLMTREQ_ADVICE:
			return new Shc500Event(thisHeader);
			break;

		case SHC_DEVICE_ACK:
		case SHC_DEVICE_NAK:
			return new ShcmsgEventAck(thisHeader);
			break;

		case SHC_FRS_ADVICE:
			return new ShcFRSEvent(thisHeader);
			break;

		case SHC_FM_REQ:	//	---	R020052
		case SHC_LM_REQ:	//	---	R020938
			return new ShcmsgFMEvent(thisHeader);
			break;
		case SHC_OD_REQ:	//	---	R020938
			return new ShcmsgODEvent(thisHeader);
		case SHC_ISTAUTH_FILE_UPD_REQ:
		case SHC_ISTAUTH_FILE_UPD_REQ_REPEAT:
			return new ShcIstAuthFileUpdateEvent(thisHeader);
			break;

		case SHC_STANDIN_DECISION_BY_ISS_RESP_NOTIFICATION:
			return new ShcStandInByIssuerRespMsgEvent(thisHeader);
			break;
		default:

			if ( shcIsDualFirstMsg(thisHeader) || shcIsDualSecondMsg(thisHeader) ) // R020524
			{
				return new ShcDualMsgEvent(thisHeader);
				break;
			}
			/*	Could be an ACK/NAK which timed out */
			if(thisHeader->msg.msgtype / 1000 % 10 == 9)
			{
				return new ShcmsgEventAck( thisHeader );
			}
			else
			{
				OTraceError("E-SHC-099002: Failed in ShcProcessor::classify() "
					"for event, msgtype[%04d] eventId[%d]\n", thisHeader->msg.msgtype,
					thisHeader->eventId );
				return NULL;
			}
		}
	}
}


