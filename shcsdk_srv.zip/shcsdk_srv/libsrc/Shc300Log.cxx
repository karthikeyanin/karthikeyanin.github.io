static char _Shc300Log_cxx_what[] = "@(#) Shc300Log.cxx 1.11 15/04/27 16:11:36";

/*
 *  Copyright (C) 2004 eFunds Corporation ("eFunds").  All Rights Reserved.
 *  eFunds Canada Corporation is an authorized user.
 *
 *  IST is a registered trademark of eFunds Corporation.  Other brand or
 *  product names are trademarks or registered trademarks of their respective
 *  holders.
 *
 *  The information contained herein is the unpublished proprietary property
 *  of eFunds.  Except as specifically authorized in writing by eFunds, the
 *  holder of this document shall: i) keep all information contained herein
 *  confidential, and ii) protect the information, in whole or in part, from
 *  disclosure and dissemination to all third parties.
 *
 *  This document and the software described in it are furnished under license
 *  and may be used or copied only in accordance with the terms of such license.
 *  This document is supplied for information purposes only, is subject to
 *  change without notice, and should not be construed as a commitment by
 *  either eFunds Corporation or eFunds Canada Corporation.
 *
 *
 *                        MODIFICATION HISTORY                  REVIEW
 *
 * SCR#     Who    Date  Description
 * ===========================================================================
 * R0xxxxx
 */

//File Number 45

#if defined( WIN32 )
#       define SHCDLLEXPORT __declspec(dllexport)
#else
#       define SHCDLLEXPORT
#endif



#include <shc.h>
#include <ShcSdkCommon.h>
#include <ShcmsgHelper.h>
#include <ShcApp.h>
#include <Shc300Log.h>
#include <ShcmsgTxnHelper.h>
#include <Shc3XX.h>

int Shc300Log::logTxn(ShcHeader *header)
{
	/*
	 *	This function updates the switch shccard to ensure that
	 *	the hot card is also entered into our tables
	 */
	struct	shc300fileupdt	mupd;
	struct ShcmsgWithSegment msg = { 0 };
	int ret;
	ShcmsgHeader *thisHeader = (ShcmsgHeader *)header;
	thisShcApp->shcmsgLogObj->logTxn(header);
	ret = shc300Obj->shc3xxSegmentData(thisHeader,&mupd);

	if(stricmp(mupd.strFileName, "P.CH.EXP") != 0 &&
	 stricmp(mupd.strFileName, "V.CH.EXP") != 0 )
		/*	not exception file */
		return(0);

	/*(1 = Add, 2 = Change, 3 = Delete, 5 = Inquiry Response)*/
	switch(mupd.nFileUpdateCode) {
	case	'1':
	case	'2':
		if(mupd.ActionCode[0] == ' '
		  || mupd.ActionCode[0] == '\0')
		{
			return(0);
		}
		break;

	case	'3':
		break;

	case	'5':
		return(0);

	default:
		return(0);
	}


	thisShcApp->shcmsgTxnHelperObj->enqueueInternalMsg(&msg.msg);
	return(0);

}







