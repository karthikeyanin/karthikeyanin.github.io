static char _Shc300TxnFactory_cxx_what[] = "@(#) Shc300TxnFactory.cxx 1.7 17/10/04 03:55:42"; 

/*
 *  Copyright (C) 2004 eFunds Corporation ("eFunds").  All Rights Reserved.
 *  eFunds Canada Corporation is an authorized user.
 *
 *  IST is a registered trademark of eFunds Corporation.  Other brand or
 *  product names are trademarks or registered trademarks of their respective
 *  holders.
 *
 *  The information contained herein is the unpublished proprietary property
 *  of eFunds.  Except as specifically authorized in writing by eFunds, the
 *  holder of this document shall: i) keep all information contained herein
 *  confidential, and ii) protect the information, in whole or in part, from
 *  disclosure and dissemination to all third parties.
 *
 *  This document and the software described in it are furnished under license
 *  and may be used or copied only in accordance with the terms of such license.
 *  This document is supplied for information purposes only, is subject to
 *  change without notice, and should not be construed as a commitment by
 *  either eFunds Corporation or eFunds Canada Corporation.
 *
 *
 *                        MODIFICATION HISTORY                  REVIEW
 *
 * SCR#     Who    Date  Description
 * ===========================================================================
 * R0xxxxx
 */

//File Number 49

#include <Shc300Event.h>
#include <Shc300Req.h>
#include <Shc300Resp.h>
#include <Shc300Header.h>
#include <Shc300TxnFactory.h>
#include <ShcRetShc300.h>

#include <Shc300ForwardReq.h>
#include <Shc300ForwardResp.h>
#include <Shc300ForwardEvent.h>
#include <BinRoute.h>
#include <ShcmsgEvent.h>

#include <ist_seg_name.h>
#include <ist_seg_elf_id_map.h>
#include <ist_seg_id.h>

int Shc300TxnFactory::createCondition(char *condition, const void *header)
{
	Shc300Header *thisHeader = (Shc300Header *)header;

	sprintf(condition, "%4.4d%c",
			thisHeader->msg.msgtype,
			thisHeader->msg.msgtype < SHC_EVENT?'N':'Y'
			);
	return 0;
}

Shc300BaseTxn *Shc300TxnFactory::getTargetObj(char *condition, const void *headerBuf)
{
		ShcmsgHeader *thisHeader = (ShcmsgHeader *)headerBuf;

		struct RoutingInfo routingInfo = {0};
                int len;
                ist_ElfId_t NETWORK_DATA_REQ_id=ElfIdMap::elf_to_id("NETWORK_DATA_REQ");
                if (NETWORK_DATA_REQ_id == (ist_ElfId_t)-1)
                {
                        OTraceFatal("F-SHC-049000:Can't find elf id for NETWORK_DATA_REQ, quit...\n");
                        throw 1;
                }
                if (shcmsgIsRequest(&thisHeader->msg))
                {
                        len=sizeof(struct RoutingInfo);
                        thisHeader->getSegmentData((char *)&routingInfo, &len, NETWORK_DATA_REQ_id,ROUTING_INFO);
                }
                else if (thisHeader->reqMsg)
                {
                        len=sizeof(struct RoutingInfo);
                        thisHeader->getReqSegmentData((char *)&routingInfo, &len, NETWORK_DATA_REQ_id,ROUTING_INFO);
                }

		if ( thisHeader->msg.msgtype>SHC_EVENT )
		{
			thisHeader->msg.msgtype -= SHC_EVENT;
			RoutingInfo *tmpInfo = NULL;
                        if (len)
                                tmpInfo = &routingInfo;

                        if (tmpInfo&& (strcmp(tmpInfo->destNode, mbcurrentnode)==0) &&
                        (strcmp(tmpInfo->destNode, tmpInfo->srcNode)!=0))
                        {
                                OTraceDebug("D-SHC-049002: 3xx forward event \n");
                                return new Shc300ForwardEvent(thisHeader);
                        }

			switch(thisHeader->msg.msgtype)
			{
			case	SHC_FILEUPD_ISSREQ:
			case	SHC_FILEUPD_ISSREQ_RESPONSE:
			case    SHC_NEGATIVEFILE_ADVICE_MSG:
			case    SHC_NEGATIVEFILE_ADVICE_RESP:
				return new Shc300Event(thisHeader);
				break;

			default:
				OTraceError("E-SHC-049001: Failed in Shc300Processor::classify() for event\n" );
				return NULL;
			}
		}
		else
		{
			RoutingInfo *tmpInfo = NULL;
                        if (len)
                                tmpInfo = &routingInfo;

                        if (tmpInfo&&
                                        tmpInfo->flag & (ROUTE_INFO_FLAG_USE_FOR_REQ | ROUTE_INFO_FLAG_USE_BINROUTE) &&
                                        (strcmp(tmpInfo->destNode, mbcurrentnode)==0) &&
                                        (strcmp(tmpInfo->destNode, tmpInfo->srcNode)!=0))
                        {
                                if (shcmsgIsRequest(&thisHeader->msg))
                                        return new Shc300ForwardReq(thisHeader);
                                else
                                        return new Shc300ForwardResp(thisHeader);
                        }

			if ((!shcIsResponse(thisHeader)) && (thisHeader->msg.formatter_devcap & SH_FORMATDEVCAP_RETURN))
			{
				// If response code is approved  they set as system error
				if ( thisHeader->msg.respcode == SHC_RC_Approved &&
					!(thisHeader->msg.formatter_devcap & SH_FORMATDEVCAP_RETURN) )
				{
					thisHeader->msg.respcode = SHC_RC_SystemError;
				}
				OTraceInfo("I-SHC-14513:Returing the transaction to source according to SH_FORMATDEVCAP_RETURN flag\n");
				return new ShcRetShc300(thisHeader);
			}
			switch(thisHeader->msg.msgtype)
			{
			case	SHC_FILEUPD_ISSREQ:
			case	SHC_LOCAL_FILEUPD_ISSREQ:
			case    SHC_NEGATIVEFILE_ADVICE_MSG:
			case	SHC_FILEUPD_ACQREQ_ADVICE:
				return new Shc300Req(thisHeader);
				break;
			case	SHC_FILEUPD_ISSREQ_RESPONSE:
			case	SHC_LOCAL_FILEUPD_ISSREQ_RESPONSE:
			case    SHC_NEGATIVEFILE_ADVICE_RESP:
			case	SHC_FILEUPD_ACQREQ_ADVICE_RESP:
				return new Shc300Resp(thisHeader);
				break;
			default:
				return NULL;
			}
		}
}
