static char _ShcPreauthSvcHelper_cxx_what[] = "@(#) ShcPreauthSvcHelper.cxx 1.12.1.1 17/03/08 15:07:30";

/*
 *  Copyright (C) 2004 eFunds Corporation ("eFunds").  All Rights Reserved.     
 *  eFunds Canada Corporation is an authorized user.                            
 *                                                                              
 *  IST is a registered trademark of eFunds Corporation.  Other brand or        
 *  product names are trademarks or registered trademarks of their respective   
 *  holders.                                                                    
 *                                                                              
 *  The information contained herein is the unpublished proprietary property    
 *  of eFunds.  Except as specifically authorized in writing by eFunds, the     
 *  holder of this document shall: i) keep all information contained herein     
 *  confidential, and ii) protect the information, in whole or in part, from    
 *  disclosure and dissemination to all third parties.                          
 *                                                                          
 *  This document and the software described in it are furnished under license  
 *  and may be used or copied only in accordance with the terms of such license.
 *  This document is supplied for information purposes only, is subject to      
 *  change without notice, and should not be construed as a commitment by       
 *  either eFunds Corporation or eFunds Canada Corporation. 
 */
/*
 *
 *                        MODIFICATION HISTORY                  REVIEW
 *
 *	SPR#	Who	Date	Description			Who	Date   
 * ===========================================================================
 * 10002264 qd 22jul96  Do not send messages to preauth agent if it is not up 
 * R007062	gbeeng	26Nov2001	C++ Migration
 * R021024	bby   27Aug07 PAN/CVV/CVV2/Track2 Masking 
 * R023310  Ram   27May08 SDK header should refer external header
 * R028271  Dipa  18Jun10 Txn Statistics
 * R030381  Dipa  02Mar12 Txn Statistics
 
 */

//File Number 110

#include <stdio.h>
#include <string.h>
#include <oasis.h>
#include <mb_umi.h>
#include <ist_otrace.h>
#include <ShcMsgCache.h>
#include <shc.h>
#include <CShcLog.h>
#include <tm.h>
#include <shcpreauth.h>

#include <ShcHelper.h>	//	---	R023310
#include <ShcPreauthHelper.h>
#include <ShcPreauthSvcHelper.h>
#include <ShcApp.h>
#include <ShcmsgHelper.h>
#include <ShcTimerHelper.h>
#include <ShcFinAuthHelper.h>
#include <ShcmsgTxnHelper.h>

//R028271 >>>
#include <TxnStat.h>
//<<< R028271

int ShcPreauthSvcHelper::preauth_service_return(ShcmsgHeader *header)
{
	long o_trace, c_trace;	
//	struct ShcWithSegment omsg;

	/*
		trace is the trace of the original preauth request.
		origtrace is the trace of the confirmation request.
		msgtype is SHC_PREAUTH_SERVICERSP
	*/

	o_trace = header->msg.trace;
	c_trace = header->msg.origtrace;
	header->msg.msgtype = header->msg.origmsg;

	header->msg.trace = c_trace;
//	shc_get_bin_entries(header);
	thisShcApp->shcmsgHelperObj->shcGetIssAcq(header,1);

	/*******************************************************************	
		Serv-Rsp	Event	Forward	 Reverse	Action
		Respcode	Found	Allowed	 Allowed	Taken by this module
		--------	-----	-------	 -------	-----------------------
		 Denied	  	  Y		   Y		Y		Forward conf req to issuer
		 Denied		  Y		   Y		N		Forward conf req to issuer
		 Denied	  	  Y		   N		Y		Respond to event(conf req)
		 Denied	  	  Y		   N		N		Respond to event(conf req)
		 Denied	  	  N		   Y		Y		Ignore Serv-Rsp from agent
		 Denied	  	  N		   Y		N		Ignore Serv-Rsp from agent
		 Denied	  	  N		   N		Y		Ignore Serv-Rsp from agent 
		 Denied	  	  N		   N		N		Ignore Serv-Rsp from agent 
		 Approved	  Y		   Y		Y		Part-Rev + Forward conf req 
		 Approved	  Y		   Y		N		Part-Rev + Forward conf req 
		 Approved	  Y		   N		Y		Part-Rev + Respond to conf req 
		 Approved	  Y		   N		N		Part-Rev + Respond to conf req 
		 Approved	  N		   Y		Y		Reverse Serv-Rsp (preauth req) 
		 Approved	  N		   Y		N		Reverse Serv-Rsp (preauth req) 
		 Approved	  N		   N		Y		Reverse Serv-Rsp (preauth req) 
		 Approved	  N		   N		N		Reverse Serv-Rsp (preauth req)
	*******************************************************************/	
	if(thisShcApp->shcTimerObj->shc_locate_event(header) < 0)	
	{
		if(header->msg.respcode == SHC_RC_Approved)
		{
			OTraceError("E-SHC-110001:No match for srv-ret resp in queue.\n");
			header->msg.trace = o_trace;
			thisShcApp->shcPreauthSvcHelperObj->shc_preauth_reverse(header, FULL);
		}
		header->shcerr = SH_IGNORE;
		return(0);
	}
	else
	{
		OTraceDebug("D-SHC-110002:Found match for srv-ret resp in queue.\n");

		if(header->msg.respcode == SHC_RC_Approved)
		{
			/* set up partial reverse */  
			header->msg.trace = o_trace;
			thisShcApp->shcPreauthSvcHelperObj->shc_preauth_reverse(header, PART);
			header->msg.trace = c_trace;
		}

		OTraceDebug("D-SHC-110003:srv-ret rsp - Restoring all fields.\n");

		thisShcApp->shcFinAuthHelperObj->shc_restore_fields(header);

		if(tm_dequeue(header->eventId) < 0)
			OTraceError("E-SHC-110004:Could not remove event from queue.\n");

		((ShcLog *)header->shcLogObj)->locateTxn(header, header->origMsg, NULL);
		((ShcLog *)header->shcLogObj)->rewind();

		header->msg.senderid = header->origMsg->senderid;
		header->msg.unit = header->origMsg->unit;

		header->msg.device_cap |= SH_DEVCAP_PROAGENT_STATE;
		header->shcerr |= SH_SETTIMER;
		
//		shc_finreq(header);
		header->truelength();
		if (thisShcApp->shcmsgTxnHelperObj->enqueueInternalMsg(&header->msg) == NULL)
			return -1;
	}
	return(0);
}

int ShcPreauthSvcHelper::shc_preauth_reverse(ShcmsgHeader *header, int state)
{
	dec_t diff;
	int ret;
	struct shcmsg rmsg;
	char amt1[50], amt2[50];

	memcpy(&rmsg, &header->msg, sizeof(header->msg));

	if(state == PART)
	{
		ret = dbm_deccmp(&header->msg.aval_balance, &header->msg.amount);
		if(ret > 0)
		{
			OTraceDebug("D-SHC-110005: Confirmed_Amt < Preauthed_Amt.\n");
			dbm_deccopy(&diff, &rmsg.amount);
			dbm_deccopy(&rmsg.amount, &header->msg.aval_balance);
			dbm_deccopy(&rmsg.aval_balance, &diff);
			rmsg.revcode = SHC_RC_PreauthAmtAdjust; 
			rmsg.respcode = SHC_RC_PreauthAmtAdjust; 
		}
		else
		{
			OTraceInfo("I-SHC-110006: No reversal because Conf_Amt = Preauth_Amt.\n");
			return(0);
		}
	}
	else
	{
		dbm_deccopy(&rmsg.amount, &header->msg.aval_balance);
		rmsg.revcode = SHC_RR_TimeOut; 
	}
	rmsg.msgtype = SHC_REVREQ;
	rmsg.origtrace = header->msg.trace;
	rmsg.origmsg = header->msg.msgtype;
	mb_getUmi(rmsg.shclog_id, sizeof(rmsg.shclog_id));
	mb_set_tid(rmsg.shclog_id, strlen(rmsg.shclog_id));
	
	int mbPreauthAgtId;
	
	if ( (mbPreauthAgtId=thisShcApp->shcPreauthHelperObj->find_preauth_agent()) < 0 )
	{
		OTraceFatal("F-SHC-110007: Failed to locate preauth agent.\n");
		return (-1);
	}
	
	if (cache_mb_write(shcmid, mbPreauthAgtId, (char *)&rmsg, sizeof(rmsg))<0)
	{
		OTraceLog("L-SHC-11013: Failed to send msg ID[%s] /m%04d/t%d/p%06d to %s\n",
			rmsg.shclog_id, rmsg.msgtype, rmsg.trace, 
			rmsg.pcode, mbMailBoxName(shcmid));
	}
	else
			OTraceLog("L-SHC-11014: Sent msg ID[%s] /m%04d/t%d/p%06d to %s\n",
				rmsg.shclog_id, rmsg.msgtype, rmsg.trace, 
				rmsg.pcode, mbMailBoxName(shcmid));


	OTraceDebug("D-SHC-110008:This is the reversal message:\n");
	OTraceDebug("D-SHC-110009:t(%ld),ld(%ld),lt(%ld),t(%s),p(%s),a(%s)\n", rmsg.trace,
   		rmsg.local_date,rmsg.local_time,rmsg.termid,
		shcApp->shcHelperObj->shc_maskpan(rmsg.pan),rmsg.acquirer);		//	---	R021024
	OTraceDebug("D-SHC-110010:ot%06ld/om%04d\n", rmsg.origtrace, rmsg.origmsg);
	dbm_dectochar(&rmsg.amount, amt2);
	OTraceDebug("D-SHC-110011:Reverse msg amount is <$%s>.\n", amt2);
	dbm_dectochar(&rmsg.aval_balance, amt1);
	OTraceDebug("D-SHC-110012:Reverse msg aval_balance is <$%s>.\n", amt1);
	return(0);
}


