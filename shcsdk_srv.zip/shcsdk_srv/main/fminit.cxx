/*
 *  Copyright (C) 2004 eFunds Corporation ("eFunds").  All Rights Reserved.
 *  eFunds Canada Corporation is an authorized user.
 *
 *  IST is a registered trademark of eFunds Corporation.  Other brand or
 *  product names are trademarks or registered trademarks of their respective
 *  holders.
 *
 *  The information contained herein is the unpublished proprietary property
 *  of eFunds.  Except as specifically authorized in writing by eFunds, the
 *  holder of this document shall: i) keep all information contained herein
 *  confidential, and ii) protect the information, in whole or in part, from
 *  disclosure and dissemination to all third parties.
 *
 *  This document and the software described in it are furnished under license
 *  and may be used or copied only in accordance with the terms of such license.
 *  This document is supplied for information purposes only, is subject to
 *  change without notice, and should not be construed as a commitment by
 *  either eFunds Corporation or eFunds Canada Corporation.
 */
/*
 *
 *                        MODIFICATION HISTORY                  REVIEW
 *
 *	SPR#	Who	Date	Description			Who	Date
 * ===========================================================================
 *	R020052	spa	21May07	New file created
 */

/* File Number 160 */

static char ver[]="IST:FM Share Initialisation: ";
static char _fminit_cxx_what[] = "@(#) fminit.cxx 1.10 16/11/08 04:32:13";

#include <stdio.h>
#include <string.h>
#include <oasis.h>
#include <oasisenv.h>
#include<ic/ic_instid.h>
#include<ic/ic_bin.h>
#include <ist_otrace.h>
#include <util.h>
#include <mb.h>
#include <rules.h>


#include <DBM3.h>
#include <dbm.h>
#include <dbm_private.h>
#include <shc.h>
#include <FMCMDHeader.h>
#include <FMInstList.h>
#include <ShcmsgFMHelper.h>

#include <HaPtmCctHelper.h>

/*
 *	FM Participating Institution initialiser
 */



static int count_records();



/*
 *	An application initialiser is invoked with the following paramaters
 *
 *		<taskname>	<mode>	<rulename>	<appid> <srvname> [<data>]
 *
 *	<taskname>		the executable name of this task		(argv[0])
 *	<mode>			the mode of processing
 *						'count'			count space needed and report to strm
 *						'init'			init the rules in-core database
 *						'update'		update an existing rule
 *						'load'			load you application
 *
 *	<rulename>		the name of the rule to be initialised
 *	<appid>			the system assigned application id for this rule
 *
 *	<srvname>		the server to which count information should be sent
 *
 *	<data>			data which might be included in an 'update' command
 *
 *
 *****************************************************************************
 *
 *	This is FM initialiser
 *
 */

int		con_id = (-1);
struct	rules_keytab keytab = {0};
int		max_keys = 0;
int		fmAppid = -1;

int		fd = (-1);
int		mode = 0;

int		argc = 0;
char	**argv = NULL;


int main(int a_rgc, char **a_rgv)
{
	int	aRet = 0 ;

	argv = a_rgv;
	argc = a_rgc;

	argv0 = *argv;
	catch_all_signals(NULL);

	strcat(ver,VERSION);
	syslg("%s\n", ver);
	OTraceOn("fminit");
	OTraceDebug("%s\n", ver);

	HaPtmCctHelper::deinit() ;

	if(argc < 5)
		log_msg(FATAL, TO_CC, "F-SHC-160001:%d is an invalid number of parameters\n", argc);


	mb_init();

	shcmid = mb_locatemailbox(SHC_SERVER_NAME);

	/*
	 *	Connect to the named server
	 */
	con_id = mb_locatemailbox(argv[RULES_PARM_SRVNAME]);
	if(con_id == -1)
		log_msg(FATAL, TO_CC, "F-SHC-160002:Unable to connect to %s: Error: %d\n",
			argv[RULES_PARM_SRVNAME], errno);

	//Read from istparam.cfg the max inst
	if(cf_openfile((char*)"cfg/istparam.cfg") < 0)
	{
		OTraceError((char *)"E-SHC-160003:Can not open configuration file:\n");
		aRet = -1 ;
		goto exit ;
	}

	if(cf_locatenum("FM.max_insts", &max_keys) < 0)
	{
		max_keys = 100;	//default value
		OTraceLog("L-SHC-160004:Default value of 100 max instutitions is configured\n");
	}
	cf_close();

	/*
	 *	Extract all paramaters
	 */
	fmAppid = atoi(argv[RULES_PARM_APPID]);

	if(!shcmsgFMHelperObj)
		shcmsgFMHelperObj = new ShcmsgFMHelper;

	/*
	 *	Now determine which we need and perform action
	 */
	if(stricmp(argv[RULES_PARM_MODE], "count") == 0)
		count_records();
	else if(stricmp(argv[RULES_PARM_MODE], "init") == 0)
		shcmsgFMHelperObj->init_records();
	else if(stricmp(argv[RULES_PARM_MODE], "load") == 0)
	{
	}
	else
		log_msg(FATAL, TO_CC,
		"F-SHC-160005:I don't know how to interpret mode '%s'\n", argv[RULES_PARM_MODE]);

  exit :

	HaPtmCctHelper::cleanUp() ;
	OTraceOff();
	exit( aRet );
}



int count_records()
{
	/*
	 *	He wants me to inidcate how many keys and text buffers
	 *	as well as their respective sizes
	 *
	 *	I can do this by reading the database or by lokking in a
	 *	config file
	 */


	/*
	 *	Set up my retrun packet
	 */
	keytab.appid = fmAppid;

	/*
	 *	Now i tell him how large my buffers should be
	 */
	keytab.keysize	= MAX_TXN_DESTINATION_LEN + 1;				/* 10001935 */

	keytab.nkeys	= max_keys;//	later needs to be fetched form istparam.cfg

	keytab.textsize	= 0;
	keytab.ntext	= 0;

	snprintf(keytab.name, sizeof(keytab.name),"%s",argv[RULES_PARM_RULENAME]);

	/*
	 *	Now i send him the information
	 */
	int len = mb_write(con_id, 0, &keytab, sizeof(keytab));

	if(len < 0)
		OTraceError("E-SHC-160006:mb_write failed to [%s][%d]\n", argv[RULES_PARM_SRVNAME], con_id);
	else
		OTraceLog("D-SHC-160007:mb_write sucessful to [%s][%d]\n", argv[RULES_PARM_SRVNAME], con_id);


	return(0);
}

