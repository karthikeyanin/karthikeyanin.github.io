/*
 *  Copyright (C) 2004 eFunds Corporation ("eFunds").  All Rights Reserved.
 *  eFunds Canada Corporation is an authorized user.
 *
 *  IST is a registered trademark of eFunds Corporation.  Other brand or
 *  product names are trademarks or registered trademarks of their respective
 *  holders.
 *
 *  The information contained herein is the unpublished proprietary property
 *  of eFunds.  Except as specifically authorized in writing by eFunds, the
 *  holder of this document shall: i) keep all information contained herein
 *  confidential, and ii) protect the information, in whole or in part, from
 *  disclosure and dissemination to all third parties.
 *
 *  This document and the software described in it are furnished under license
 *  and may be used or copied only in accordance with the terms of such license.
 *  This document is supplied for information purposes only, is subject to
 *  change without notice, and should not be construed as a commitment by
 *  either eFunds Corporation or eFunds Canada Corporation.
 */
/*
 *
 *                        MODIFICATION HISTORY                  REVIEW
 *
 *	SPR	Who	Date	Description			Who	Date
 * ===========================================================================
 *	R020052	spa	21May07	New file created
 */

/* File Number 161 */

static char ver[]="IST:FM Interface: ";
static char _fmcmd_cxx_what[] = "@(#) fmcmd.cxx 1.8 17/03/06 07:09:21";


/*
 *	Fraud Manager command Interface
 *
 *	Usage:	fmcmd [command]
 *
 */


#include <stdio.h>
#include <ctype.h>
#include <signal.h>
#include <unistd.h>
#include <oasis.h>
#include <ist_otrace.h>
#include <mb.h>
#include <mbpipe.h>
#include <rules.h>
#include <shcdef.h>
#include <shc.h>

#include <shcThrottle.h>
#include <mb_r.h>
#include <ShcmsgFMHelper.h>

/*	Define all the commands */
#define C_LIST				1
#define C_REQUEST			2
#define C_CUTOVER           		3
#define C_EXIT				4
#define C_HELP				5


struct	cmdtab	cmdtab[] = {
	{"list",		C_LIST,		"list -> Shows the FM participating institutions list"},
	{"request",		C_REQUEST,	"request -> Requests update of FM participating institutions list"},
	{"help",		C_HELP,		"help: This is it."},
	{"exit",		C_EXIT,		"exit command processor"},
	{"quit",		C_EXIT,		"quit the command processer"},
	{NULL}
	};


extern "C"
{
	void	cmdexit( int );
}

static char		inpbuf[1024] = {0};
static char	xbuf[1024]	= {0}; 
static int		istty 		= 1;
static char		**arg_v 	= NULL;
static int		arg_c 		= 0;
static int		command_index = (-1);

int 		fmAppid = -1;
char 		*fmInstKeys = NULL;
struct rules_keytab *fmRuleKeyPtr = NULL;

static int execute_command(int cmd);
static int process_commands();
static int get_input();
static int list();
static int request();


int main(int argc, char **argv)
{
	int i;

	argv0 = *argv;
	catch_all_signals(cmdexit);

	mb_init();
	dbm_init();

	OTraceOn("fmcmd");
	OTraceDebug("%s\n", ver);


	dbm_close_all(getpid());

	istty = check_isatty(fileno(stdin));


	/*	Check if we should run the command at another node */
	/*	This function will not return if we should run on another node */
	/*	otherwise it returns the mail box id of the server */
	shcmid = mb_pipeatnode(SHC_SERVER_NAME, argv);

	rm_init();

	if((fmAppid = rm_getappid(FM_MESSAGE_NAME)) < 0)
	{
	        OTraceFatal("F-SHC-161001:unable to locate message name: %s\n", FM_MESSAGE_NAME);
	}
	else
	{
		if ( rm_attach( fmAppid, RULES_VER_CURRENT) != 0) //R029951
		{
			OTraceFatal("F-SHC-161001.1: Unable to attach to CURRENT version of %s\n",FM_MESSAGE_NAME);
		}
		fmRuleKeyPtr = rm_getapphead(fmAppid);
	    fmInstKeys = (char *)rm_getappkey(fmAppid);
	}



	if(istty && argc == 1)
		printf("%s\n", ver);


	if(argc > 1)
	{
		arg_c = argc - 1;
		arg_v = argv + 1;
		i = find_command(cmdtab, arg_v[0], NULL);
		if(i < 0)
			printf("Invalid command\n");
		else
			execute_command(i);
	}
	else
		process_commands();
	return(0);
}


void cmdexit( int n )
{

	if(n == SIGPIPE)
	{
		/* signal(n, (void (*)())cmdexit); */
		signal(n, cmdexit);
		return;
	}

	dbm_close_all(getpid());

	if(n > 2)
		syslg("F-SHC-161002: Exit due to signal %d\n", n);

	OTraceFatal("F-SHC-161003: Exit due to signal %d\n", n);
	OTraceOff();

	if(n > 2)
		kill(getpid(), n);

	exit(n);
}


int process_commands()
{
	int	cmd;

	for(;;)
	{
		cmd = get_input();
		if(cmd < 0)
			break;
		execute_command(cmd);
	}
	return(0);
}



int get_input()
{
	/*
	 *	Prompts for a command line
	 *	Determines type of command
	 *	Returns command type
	 */
	char	*bp;
	int		i;

	for(;;)
	{

#if !defined(WIN32)
		if(arg_v)
			/*	clear from last command */
			free(arg_v);
#endif

		arg_v = NULL;

		if(istty)
			printf("fmcmd> ");

		fflush(stdout);

		if(fgets(inpbuf, sizeof(inpbuf), stdin) == NULL)
			return(-1);

		/*
		 *	Check if an empty line
		 */
		bp = inpbuf;
		while(isspace(*bp))
			++bp;
		if(!*bp)
			continue;

		if(*bp == '!')
		{
			call_shell(bp);
			continue;
		}

		arg_v = make_argv(inpbuf, 1);
		for(arg_c = 0; arg_v[arg_c]; ++arg_c)
			;

		i = find_command(cmdtab, arg_v[0], NULL);
		if(i >= 0)
			return(i);

		printf("Invalid command: Use 'help'.\n");
	}
}

int execute_command(int cmd)
{

	switch(cmd) {
	case	C_EXIT:		cmdexit(0);					break;
	case	C_HELP:		help(cmdtab, arg_c, arg_v);			break;
	case	C_LIST:		list();						break;
	case	C_REQUEST:	request();					break;

	default:		printf("Internal error: cmd %d ????\n", cmd);	break;
	}
	return (0);
}



int list()
{
	/*
	 *	list institution
	 */
	char buf[MAX_TXN_DESTINATION_LEN +1];

	char *ptr = fmInstKeys;

	printf("Institution List\n");
	if(fmRuleKeyPtr->keysused == 0)
	{
		printf("No entries available\n");
		return ( 0 );

	}

	for(int i=0; i < fmRuleKeyPtr->keysused; i++)
	{
	        memcpy(buf, ptr, sizeof(buf));
	        printf("[%s]\n",buf);
	        memset(buf, 0, sizeof(buf));
	        ptr += fmRuleKeyPtr->keysize;
	}


	return( 0 );
}



int request()
{
	char buf[256];

	OTraceDebug("D-SHC-161004:fmcmd :request executed\n");

	if(!shcmsgFMHelperObj)
		shcmsgFMHelperObj = new ShcmsgFMHelper;

	if(shcmsgFMHelperObj->init_records(1) == -1)
		OTraceError("E-SHC-161005:init_records in Inst list request failed\n");

	return( 0 );
}

