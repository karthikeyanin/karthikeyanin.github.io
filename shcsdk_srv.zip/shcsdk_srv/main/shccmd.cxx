static char ver[]="IST:Shared Cash Interface: r1.0.0 01Jun97";
static char _shccmd_cxx_what[] = "@(#) shccmd.cxx 1.71.25.2 20/02/27 15:26:10";
/*
 *  Copyright (C) 2004 eFunds Corporation ("eFunds").  All Rights Reserved.     
 *  eFunds Canada Corporation is an authorized user.                            
 *                                                                              
 *  IST is a registered trademark of eFunds Corporation.  Other brand or        
 *  product names are trademarks or registered trademarks of their respective   
 *  holders.                                                                    
 *                                                                              
 *  The information contained herein is the unpublished proprietary property    
 *  of eFunds.  Except as specifically authorized in writing by eFunds, the     
 *  holder of this document shall: i) keep all information contained herein     
 *  confidential, and ii) protect the information, in whole or in part, from    
 *  disclosure and dissemination to all third parties.                          
 *                                                                          
 *  This document and the software described in it are furnished under license  
 *  and may be used or copied only in accordance with the terms of such license.
 *  This document is supplied for information purposes only, is subject to      
 *  change without notice, and should not be construed as a commitment by       
 *  either eFunds Corporation or eFunds Canada Corporation. 
 */
/*
 *
 *                        MODIFICATION HISTORY                  REVIEW
 *
 *	SPR#	Who	Date	Description			Who	Date   
 * ===========================================================================
 *	ad		08jan92		Added close day/batch commands
 *	ad		05feb92		Fixed minor problem with "keys" display.
 *	ad		09mar92		Changed 'close day' to accept store/lane id.
 *	ad		18mar92		Fixed CLOSE_BATCH cmd. Needed to use CLOSE_BATCH_START
 *	ad		20mar92		Added a -d (date) command to the close request
 *	ad		07May92		Added CheckPIN flag in the options table
 *	ad		30May92		Changed currency interface so had to change this
 *						interface.
 *	ad		31Jul92		Added display or revflag
 *	bsa		17sep92		Added shcmsgdump command to safcmd		
 *	bsa		17oct92		Cleaned up shcmsgdump command interface
 *	ad		23oct92		Added support for new shc flags
 *	ad		24oct92		Changed call to strcmd to mbrulecmd
 *	ad		20nov92		Changed the display of the 'list' and
 *						created new command 'flags'
 *						Catch signal SIGPIPE and ignore it.
 *	ad		24nov92		Added SendAck in 'options' list
 *	ad		26nov92		Added PreauthOnCardValidate in 'options' list
 *	ad		27nov93		Added support for the bin map tables
 *	jsn		26jun94		Add netcode table; so can use string tokens
 *						instead of netcode field values!
 *	dq		08jan96		Assign new netcode to key-xchg option	
 * 10001905 la  30apr96 Test is not bin mapping tables are present.
 * 10001905 la  01mar96 Check number of arguments for change option.
 * 10001959 la  12may96 Use istadvicecmd instead of safcmd.
 * 10002364 la  02jul96 Added send option to shccmd reconcile. Messages are sent
 *                       to istadvice.
 *	1002888 jt	13nov96 Expanded online help for signon.
 *	2002029 rc	22nov96	Remove the 'dump' command.
 *          la  7oct97  Added multiple keys support.
 * R001835  qd  04may99 Interac Merge
 * R003931  fg  24Jan00 Add throttling support
 * R004120	rlo	07Mar00	Added support for sending group-signon/off messages to
 *						a credit formatter.
 * R004120	rlo	09Mar00 Changed "signon-group-de" to "signon-group-db" and
 *						"signoff-group-de" to "signoff-group-db" for "shccmd
 *						send".
 *	R004401	rlo	13Apr00	Fixed core dump when using shccmd key bin.
 * R004403	jsun	25Apr00	Added to display "UPD" in keys_usage()
 *  R004726 jy	16Jun00	changed the strings in sprintf() to make 'update' working
 * R004671  Dds 26Jun00 Merger vsdc enhancement to 7.2, refer to 2007336
 * 2007336  Mch 26Feb00 Added support for new chip data on 7.1.3.
 * R004922 jsun 24Jul00 Made no difference between Interac & non-Interac bin
 * R005267 jsun 30Oct00 To display 3 keys for all bins
 * R005420 emj  13Nov00 Fixed bugs in shccmd keys interface.
 * R005324 emj  18Dec00 TDES Support
 * R005743 rzhou  23Feb01 Fixed the bug in shccmd cmdexit, require dbm_close()
 * R005789 rzhou  09Apr01 Fix the bug when perform the sub-command from the prompt in NT platform 
 * R006465 af	20Aug01	Fixed coredump on executing reconcile option.
 * R006576 jiz  28Aug01 Support Key exchange on demand (network code 162)
 * R005201	jy	05Sep01	Using "get key" function instead of "set key" in keys_dump()
 * R007062	gbeeng	26Nov2001	C++ Migration
 * R008060 emj  15Jul02 Added support for all bins to exchange current or next key
 *R008328 jyang 27Sep02 Echo proper message after doing "update" command
 *R008717 ztang 18Nov02	Multi-institution support. Keep only one mailbox route and one port
 *R008717 Emj   10Jan02 Multi-institution support.
 *R009076 ztang 05Feb02 Set txnSrc field
 *R009115 Emj 10Feb03 Updated commands to use shcBinKeys for institutionid and userbinid
 *R009248 ztang 24Feb03 Remove spaces from instituion id fields
 *R009267 Emj   25Feb03 Left justify institutionid
 *R009398 Emj   10Mar03 Call function to get next vaild key index
 *R009493 Emj   10Jum03 Support for commands at inst profile level
 *R009952 Emj   31Jul03 Fixed instforce command
 *R010153 emj   25Sep03 Reverse storage of key for key xchg initiated by the switch
 *R010308 Emj   17Nov03 Call dbm_close_all() after dbm_init() to avoid core dump
 *R010558 Emj   08Mar04 For key exchange set trace to -1 in shccmd to force 
 *                      shcnet to generate trace number 
 *R011218 Emj   16Jun04 Removed binmap functionality
 *R011219 Emj   16Jun04 Removed change Command
 *R011219 Emj   16Jun04 Removed Options Cmd add output to list cmd
 *R011219 Emj   16Jun04 Removed Close command
 *R011219 Emj   16Jun04 Updated Flags cmd to display internal bin ID
 *R011219 Emj   16Jun04 Fixed instset and instforce cmds
 *R011219 Emj   16Jun04 Updated list command to display internal binID
 *R011227 Emj   17Jun04 Added option to keys cmd for key exchange on demand requests
 *R012134 Emj   04Oct04 Issuer Entity Support
 *R011307 Emj   18Oct04 Removed display of cutoff time from bin
 *R012245 Emj   28Oct04 Added business day cutover command
 *R012344 rzhou 09Nov04 Support Entity level business day reconcile
 *R013418 rzhou 01Mar05 Get Entity level business day configuration properly
 *R014598 jyang 31Aug05 leave flag SH_REPLAY alone
 *R016425 Emj   17May06 Mark bin up using ShcBin class
 *R016654 emj   19Jun06 Support for sharing keys across BINs
 *R017808 Emj   22Sep06 Support broadcast of reloading shckey into shared memory
 *R018276 pve	27Nov06	Remove excessive syslg messages
 *R019289 jyang 26Mar07 Gracefully shutdown switch node support
 *R019535 jyang 10Apr07 Created shccmd daemon process
 *R019505 pve	16Apr07	Use correct networkid of its own instead of from bin pkg for 800 msgs
 *R020242 Emj   12Jun07 Updated to use thisShcApp instead of shccmdApp
 *R020635 spa	14Jul07	Send 800 messages with optional network data
 *R025411 sel	01Dec08	Added information about GSI data usage in shccmd command
 *R026452 sel	26May09	added help information about session messages
 *R027817 mm    17Feb10 added isMAIN_INST
 *R027876 dipa  02Mar10 Segment changes  
 *R027855 mm    04Mar10 _cutover_no_db, phc_cutover
 *R028104 dipa  29Apr10  routinginfo - fix
 *R028271 dipa  18Jun10  Txn Statistics
 *R029092 dipa  16Mar11  Remove 'replay' option
 *R029275 dipa  08Apr11  HA - Switch node graceful shutdown
 *R029275 dipa  29Apr11  HA - Switch node graceful shutdown - check nodeId
 *R030745 dipa	09Aug12	 Clone of R030696 - Added netcode: SHC_NET_GROUPSIGNON_START
 *IST_S761SP8-34	dipa	10Apr14	Clone of R032410,IST_S761SP7-4,R032505
 */

//File Number 135

/*
 *	Shared cash command processor
 *
 *	Usage:	shccmd [-m] [command]
 *
 *	-m		from monitor flag: Changes the manner in which the list command
 *			works
 */


#include <stdio.h>
#include <ctype.h>
#include <signal.h>
#include <unistd.h>	/* R008328 */
#include <oasis.h>
#include <ist_otrace.h>
#include <mb.h>
#include <mb_umi.h>
#include <tm.h>
#include <mbpipe.h>
#include <rules.h>
#include <shcdef.h>
#include <shc.h>
#include <istcurrency.h>
#include <shc500std.h>
#include <ic/ic_bin.h>
#include <ic/ic_instid.h>
#include <osysinfo.h>
#include <BinRoute.h>
#include <ShcCutoverHelper.h>

/* R003931 */
#include <shcThrottle.h>
#include <ShcBin.h>
#include <ShcApp.h>
#include <ShcmsgHeader.h>
#include <ShcNetworkMsgHelper.h>
#include <InstProfile.h>
#include <ShcHelper.h>
#include <ShcmsgHeader.h>
#include <ShcmsgHelper.h>
#include <ShcSafIOHelper.h>
#include <ShcKeyHelper.h>
#include <ShcKeyTxnHelper.h>
#include <mb_r.h>
#include <ist_seg_name.h> //R027876
#include <ist_seg_elf_id_map.h> //R027876
#include <ist_seg_id.h> //R027876
#include <UpdateMemHelper.h>
#include <ShcSharedMemoryHelper.h>
#include <HaPtmCctHelper.h>
#include <ShcLateRev.h>
#include<switch_state_apis.h>
#include <msg_repl_util.h>
#include <auto_ptr.h>
#include <DBM3.h>
#include <dbm_private.h>
#include <DBMWrapper.hxx>
#include <ClusterInfoSHM.h>
#include <msg_repl_exception.h>

//R028271 >>>
#include <TxnStat.h>
//<<< R028271

#include <ist_executor.h>
#include <security.h>
#include <istsafe.h>
#include <algorithm>
/*	Define all the commands */
#define C_LIST				1
#define C_SET				2
#define C_DEBUG				4
#define C_HELP				5
#define C_READ				6
#define C_REPLAY			7
#define C_FORCE				8
#define C_SAF				9
#define C_UPDATE			10
#define C_FLAGS				11
#define C_STATS				12
#define C_RATES				13
#define C_CURRENCY			14
#define C_SETTLEMENT		15

#define C_ECHO				18
#define C_KEYS				19
#define C_SEND				20

/* R003931 */
#define C_THROTTLELIST      24


#define C_INSTPROFILE   	25
#define C_INSTFORCE   		26
#define C_INSTSET   	    27

#define C_CUTOVER           28
#define C_READY             29
#define C_NODEUPDATE		30
#define C_NODEUPDATEACK		31
#define C_NEWNODE			32
#define C_SHUTDOWN			33
#define C_ROUTESET			34
#define C_ROUTESEND			35
#define C_ROUTEUPDATE 	36
#define C_CUTOVER_NO_DB			37
#define C_PHC_CUTOVER 			38
#define C_GRACEFUL_SHUTDOWN	39 		//R029275
#define C_MEMUPDATE			40
#define C_REVLOGCMD 		41
#define C_MAINTENANCE		42
#define C_NODESTATUS		43
#define C_RESETSTATUS		44
#define C_EXIT				999

#define IST_MB_DAEMON		"ShccmdDaemon"
#define SHUTDOWN_SLEEP		5		// seconds

#define SHCCMD_ROUTE_BROADCAST_BUF_LEN 204800
#define SET		1
#define RESET 	2

struct	cmdtab	cmdtab[] = {
	{"list",		C_LIST,		"list [instid [bin] | up | down]"},
	{"trace",		C_DEBUG,	"trace [<instid> | switch] [on | off]"},
	{"set",			C_SET,		"set [instid [bin] | all] [up | down]"},
	{"force",		C_FORCE,	"force [instid [bin] | all] [up | down]"},
//	{"replay",		C_REPLAY,	"replay instid bin"},
	{"saf",			C_SAF,		"saf -- run S&F command processor"},
	{"update",		C_UPDATE,	"update instid bin [bin ...] {OR} update all instid bin [bin ...]"},
	{"help",		C_HELP,		"help: This is it."},
	{"exit",		C_EXIT,		"exit command processor"},
	{"quit",		C_EXIT,		"quit the command processer"},
	{"reconcile", C_SETTLEMENT,	"reconcile instid bin [today | YYYYMMDD] [send]"},
	{"echo",		C_ECHO,		"echo <instid bin>"},
	{"keys",		C_KEYS,		"keys <instid keyparamid> [XCHG|RST|UPD|REQ {class}{type}{index} ...  [-route <port>]]"},
/*	----------------- Essa:	15Feb93 ------------------ */
	{"send",		C_SEND,		"send netcode to institution networkid [ for institution]"},
	{"flags",		C_FLAGS,	"flags instid [bin ...]"},
    /* R003931 */
	{"throttlelist",    C_THROTTLELIST, "display shc throttling parameters."},
	{"instprofile",		C_INSTPROFILE, "List institution profile."},
	{"instset",			C_INSTSET,		"instset [txnsrc [txndest [entityId]]]  [up | down]"},
	{"instforce",		C_INSTFORCE,	"instforce [txnsrc [txndest [entityId]]]  [up | down]"},
	{"cutover",         C_CUTOVER,  "\nUsage:cutover SWITCH APO YYYYMMDD \n (OR) \nUsage:cutover InstId [EntityId|SWITCH|ACQ|ISS|BOTH] APO YYYYMMDD"},
	{"ready",         C_READY,  "ready - Set system status to ready and broadcast bin status"},
	{"nodeupdate",    C_NODEUPDATE,  "nodeupdate <from node> <networkid1> <networkid2>...- Set these bins up, typically from other nodes"},
	{"acknodeupdate",    C_NODEUPDATEACK,  "acknodeupdate <from node> <networkid1> <networkid2>...- Set these bins up, typically from other nodes"},
	{"newnode",    C_NEWNODE,  "newnode <from node> - need to boradcast bins to that node"},
	{"shutdownnode",  C_SHUTDOWN,  "shutdown node - shutdown current node"},
	{"routeset",  C_ROUTESET,  "routeset instid bin node|- binroute_group |- port|- up|down - set port(s) down/up"},
	{"routesend",		C_ROUTESEND,		"send netcode to institution networkid mailbox|- port|- [ for institution] [ with network_data]"},
	{"routeupdate",		C_ROUTEUPDATE,	"routeupdate"},
	{"_cutover_no_db",	C_CUTOVER_NO_DB,	"_cutover_no_db"},	//R027855 IBD SHM update 
	{"phc_cutover",		C_PHC_CUTOVER,		"phc_cutover"},		//R027855 Pure Host Capture
	{"gracefuldown",	C_GRACEFUL_SHUTDOWN,		"gracefuldown <nodeid>"},		//R029275
	{"memupdate", 		C_MEMUPDATE, "update shared memory, for deamon process only" },
	{"revlog", 		C_REVLOGCMD, "revlog commands - revlog usage for help" },
	{"maintenance", C_MAINTENANCE, "set node in maintenance mode for graceful shutdown" },
	{"nodestatus", C_NODESTATUS, "get node current status" },
	{"reset-maintenance", C_RESETSTATUS, "clear maintenance status" },

	{NULL}
	};

struct	optlist {
	const char	*name;
	long	flags;
};

struct	optlist optlist[] = {
	{"CheckExpiry",			SH_CHECKEXP},	
	{"CheckPIN",			SH_CHECKPIN},	
	{"CheckIndividualHotCard",	SH_CHECK_INDIV_HOT},
	{"CheckHotCardRange",		SH_CHECK_RANGE_HOT},
	{"OnlineSettlement",	SH_ONLINE_SETTLEMENT},
	{"CheckServiceCode",	SH_CHECKSCODE},
	{"CheckCVV",			SH_CHECKCVV},
	{"VerifyCheckDigit",	SH_VERIFY_CHECK_DIGIT},
	{"DebitCard",			SH_DEBIT_CARD},
	{"CreditCard",			SH_CREDIT_CARD},
	{"CardAlertAlways",		SH_CARDALERT_ALWAYS},
	{"CardAlertByCard",		SH_CARDALERT_BYCARD},
	{"TraceOn",				SH_TRACE},
	{"SendRevToIssuer",		SH_GETAPP_HOST},

	/*	23oct92	*/
	{"CheckFloorLimits",	SH_CHKFLRLIM},
	{"SendRevForAuth",		SH_SENDREV},
	{"SAFAccmAuth",			SH_SAFAUTH},

	/* 24nov92 */
	{"SendAck",				SH_SENDACK},

	/*	26nov92 */
	{"PreauthOnValidation",	SH_PREAUTH_ON_VALIDATE},
	{"Flip Msgtype",          SH_FLIP_MSGTYPE },

	{NULL}
};


struct		optlist	netcode[] = {

	{"signon-start",		SHC_NET_SIGNON_START},
	{"signon",				SHC_NET_SIGNON},

	{"signoff-start",		SHC_NET_SIGNOFF_START},
	{"signoff",				SHC_NET_SIGNOFF},	

	{"signon-group",		SHC_NET_GROUP_SIGNON}, /* R004120 */
	{"signoff-group",	SHC_NET_GROUP_SIGNOFF}, /* R004120 */
	{"saf-start",			SHC_NET_START_SAF},
	{"saf-stop",			SHC_NET_STOP_SAF},

	{"si-enter",			SHC_NET_ENTER_SI},
	{"si-exit", 			SHC_NET_EXIT_SI},
    /* 2002773 - cutover networkcode should not be SHC_NET_CUTOVER. 1997/03/27 */
	{"cutover",				SHC_NET_CUTOVER_START},
	{"echo-start",			SHC_NET_ECHO_START},
	{"echo",				SHC_NET_ECHO},
	{"session-act",			9081},
	{"session-deact",		9082},
	{"echo-manual",			9270},
	{"_cutover_no_db",				SHC_NET_CUTOVER_START},
	{"phc_cutover",				SHC_NET_CUTOVER_START},
	{"signon-group-start",		SHC_NET_GROUPSIGNON_START }, /* R030696 */
	{NULL,					-1}
};
char		NetcodeHelp[] = "Valid commands are:\n"
"\tsignon\t\tRoute 800/signon(if set) to iss. or reply 810 to acq.\n"
"\tsignoff\n"
"\tsignon-start\tSignon request from switch\n"
"\tsignoff-start\n"
"\tsignon-group\tNormally used for mastercard.\n"
"\tsignoff-group\tNormally used for mastercard.\n"
"\tsaf-start\n"
"\tsaf-stop\n"
"\tsi-enter\tNormally used for visa.\n"
"\tsi-exit\t\tNormally used for visa.\n"
"\tcutover \tSend a cutover (end of day) message\n"
"\tphc_cutover \tSend a cutover (end of day) message for Pure Host Capture entities\n"
"\techo-start\n"
"\techo\n"
"\techo-manual\tsend echo message with netcode 9270\n"
"\tsession-act\tSession activation request from switch\n"
"\tsession-deact\tSession deactivation request from switch\n\n"
"\tie. %shccmd> send signon to 5\n";

//_cutover_no_db - IBD SHM update without DB update - internal

extern "C"
{
	void	cmdexit( int );
}
static char	inpbuf[1024] = {0};
static char xbuf[SHCCMD_ROUTE_BROADCAST_BUF_LEN]    = {0}; /* R001835 make it static */

static int		istty 		= 1;
static char	**arg_v 	= NULL;
static int		arg_c 		= 0;
static int		command_index = (-1);
static int		mflag		= (0);
static int		dflag		= (0);
static int		isKeyBlkDev	= 0;

extern int instProfNeedPause;	//Defined in InstProfile.cxx
static int key_dump_td (struct shcsecurity *secp, struct shcpkg *pkgp, int maxlen, char type ) ; 
/* R007062 */

static int mbidShccmdDaemon = -1;
static int mbidSharedcash = -1;

static int ready();
static int nodeupdate(int isAck);
static int shutdownNode();
static int countEvents( int mbid );
static int getMbInput();
static int routeset();
static int routesend();
static int routeupdate();
static int graceful_shutdown(); //R029275
static int setNodeMaintenance();
static int getNodeStatus();
static int resetNodeStatus();

static int cutover();
static int cutover_no_db();
static int phc_cutover();
static int execute_command(int cmd);
static int process_commands();
static int get_input();
static int trace();
static int list();
static int set();
//int start_replay();
static int saf();
static int update();
static int settlement();
static int echo();
static int keys();
static int send_network();
static int list_flags();
static int do_stats();
static int list_short(int i);
static int list_up_down();
static int list_inst();
static int set_up(struct shcpkg *pkg);
static int set_down(struct shcpkg *pkg);
//int replay(struct shcpkg *pkg);
static int settlement_print( struct shc500std *msg );
static int pr_settlement(const char *msg, int num, amount_t *amt, amount_t *pr_fee, amount_t *txn_fee);
static int set_up(NetworkInfo &netinfo, struct shcpkg *pkg);
static int set_down(NetworkInfo &netinfo, struct shcpkg *pkg);
static void inst_profile(void);
static void inst_set(void);
static int memUpdate();
static int revlogcmd();
static int get_pin_index(char *InstId, char *Network_Bin);
int performNodeOperation(int Oper);


static ShcBin *shcBin = NULL;
static ShcmsgHeader tmpHeader;
static int isDaemon;
static char updateMemData[UPD_MEM_MAX_LEN];
static int updateMemDataLen;
static char updateMemRuleName[RULES_NAME_LEN];
static struct rules_keytab *pShcAppHead = NULL;
static struct rules_keytab *pShckeyAppHead = NULL;

static char sec_dev_name[50];

static char *getSecDeviceType()
{

        static int init_val = 0;
        if ( init_val )
                return sec_dev_name;

        memset(sec_dev_name, 0x00, sizeof(sec_dev_name));
        if ( cf_locate(( char * ) "sec.device", sec_dev_name ) < 0 )
        {
                OTraceInfo("L-SEC-0102:security device  is not configured\n");
        }
        OTraceInfo("L-SEC-0103:security device is <%s>\n", sec_dev_name);

        init_val = -1;
        return sec_dev_name;
}

bool isKeyBlockDevice()
{

        char device_name[50];

        memset(device_name, 0x00, sizeof(device_name));
        strcpy(device_name, getSecDeviceType());

        if( strcmp(device_name, RACAL_NAME_KB) == 0)
                return true;
        else if( strcmp(device_name, ERACOM_NAME_KB) == 0)
                return true;
        else if( strcmp(device_name, EXCRYPT_NAME_KB) == 0)
                return true;
        else
                return false;
}

int main(int argc, char **argv)
{
	int i;
	
	isDaemon = 0;
	if ( argv && *argv && (argv0=strrchr(*argv,'/')) )
	{
		argv0++;
	}
	else
	{
		argv0 = *argv;
	}
	isDaemon = !stricmp(argv0, "shccmddaemon");		// R019535
	
	catch_all_signals(cmdexit);

	//syslg("%s\n", ver);	//	R018276
	strcat(ver, VERSION);
	OTraceOn(argv0);
	OTraceDebug("%s\n", ver);
	
	
	mb_init();
	dbm_init();
	HaPtmCctHelper::init() ;

	thisShcApp = new ShcApp;
	shcBin = (ShcBin *)shcHelperRegister.getTargetObj(SHC_ShcBin);


	/* R010308 R005743 */
	dbm_close_all(getpid()); 

	istty = check_isatty(fileno(stdin));

	if(isKeyBlockDevice())
		isKeyBlkDev = 1;

	/*	Check if we should run the command at another node */
	/*	This function will not return if we should run on another node */
	/*	otherwise it returns the mail box id of the server */
	shcmid = mb_pipeatnode(SHC_SERVER_NAME, argv);

	/*	Shared Cash on this node! Initialise */
	shc_init();
	shc_get_current_date();
	rm_enableSingleAttach();
	mcastHelperObj->setHandlerID("shccmd");
	/*
	 *	Check for -m flag
	 */
	while(argc > 1)
	{
		if(strcmp(argv[1], "-m") == 0)
		{
			/*	Probably called from the monitor remotley */
			mflag = 1;
			instProfNeedPause = 0;
			++argv;
			--argc;
		}
		else if(strcmp(argv[1], "-d") == 0)
		{
			/*	Some commands need to broadcast */
			dflag = 1;
			++argv;
			--argc;
		}
		else if(strcmp(argv[1], "-site") == 0)
		{
			//command is for this site
			ofThisSite = atoi(argv[2]);
			argv += 2;
			argc -= 2;
		}
		else if(strcmp(argv[1], "-s") == 0)
		{
			/*	Absolutely no broadcast */
			noBraodcastFlag = 1;
			++argv;
			--argc;
		}
		else
			break;
	}

	if (noBraodcastFlag)
		dflag = 0;	//If both -s and -d are specified, only -s is used.
	
	if(istty && argc == 1 && !isDaemon)
		printf("%s\n", ver);

	HaPtmCctHelper::addHandler( "system.dcs.shc" ) ;

	if(argc > 1)
	{
		for ( int indx = 0; indx < argc; indx++ )
			OTraceDebug("D-SHC-100000 argument[%d] = [%s]\n", indx, argv[indx]);
		arg_c = argc - 1;
		arg_v = argv + 1;
		i = find_command(cmdtab, arg_v[0], NULL);
		if(i < 0)
		{
			if((istty) && (!isDaemon))
				printf("Invalid command\n");
			else
				OTraceInfo("I-SHC-135048: Invalid command\n");
		}
		else
			execute_command(i);
	}
	else
		process_commands();
	return(0);
}


void cmdexit( int n )
{
	/*	20nov92 */
	if(n == SIGPIPE)
	{
		/* signal(n, (void (*)())cmdexit); */
		signal(n, cmdexit);
		return;
	}
	/* R005743 */
	dbm_close_all(getpid()); 

	//if(n > 2)	//      R018276
		//syslg("F-SHC-135001: Exit due to signal %d\n", n);	//	R018276

	OTraceInfo("I-SHC-135051: Exit due to signal %d\n", n);
	HaPtmCctHelper::cleanUp() ;
	OTraceOff();
	if(n > 2)
		kill(getpid(), n);
	
	exit(n);
}


int process_commands()
{
	int	cmd;

	HaPtmCctHelper::prepare() ;

	for(;;)
	{
		if( HaPtmCctHelper::checkBefore() != 0 )
		{
			OTraceInfo( "I-SHC-135027: Terminate due to HaPtmCct\n" );
			syslg( "I-SHC-135027: Terminate due to HaPtmCct\n" );
			break ;
		}

		if ( isDaemon )	// R019535
		{
			cmd = getMbInput();
		}
		else 
		{
			cmd = get_input();
		}
		if(cmd < 0)
			break;
		execute_command(cmd);
	}
	return(0);
}



int get_input()
{
	/*
	 *	Prompts for a command line
	 *	Determines type of command
	 *	Returns command type
	 */
	char	*bp;
	int		i;

	for(;;)
	{

#if !defined(WIN32)    /* R005789 */
		if(arg_v)
			/*	clear from last command */
			free(arg_v);
#endif    /* R005789 */
		
		arg_v = NULL;

		if((istty) && (!isDaemon))
			printf("shccmd> ");
		
		fflush(stdout);

		if(fgets(inpbuf, sizeof(inpbuf), stdin) == NULL)
			return(-1);
		
		/*
		 *	Check if an empty line
		 */
		bp = inpbuf;
		while(isspace(*bp))
			++bp;
		if(!*bp)
			continue;
		
		if(*bp == '!')
		{
			call_shell(bp);
			continue;
		}

		arg_v = make_argv(inpbuf, 1);
		for(arg_c = 0; arg_v[arg_c]; ++arg_c)
			;
		
		i = find_command(cmdtab, arg_v[0], NULL);
		if(i >= 0)
			return(i);
		
		if((istty) && (!isDaemon))
			printf("Invalid command: Use 'help'.\n");
		else
                        OTraceInfo("I-SHC-135049: Invalid command: Use 'help'.\n");
	}
}

int execute_command(int cmd)
{

	char txnId[32] = {0};
	mb_getUmi(txnId, sizeof(txnId));
	mb_set_tid(txnId, sizeof(txnId));

	switch(cmd) {
	case	C_EXIT:		cmdexit(0);								break;
	case	C_HELP:		help(cmdtab, arg_c, arg_v);				break;
	case	C_DEBUG:	trace();								break;
	case	C_LIST:		list();									break;
	case	C_SET:		set();									break;
	case	C_FORCE:	set();									break;
//	case	C_REPLAY:	start_replay();							break;
	case	C_SAF:		saf();									break;
	case	C_UPDATE:	update();								break;
	case	C_STATS:	do_stats();								break;
	case	C_SETTLEMENT:	settlement();						break;
	case	C_ECHO:		echo();									break;
	case	C_KEYS:		keys();									break;

	/*	--------- Essa:	15Feb93 -------------- */
	case	C_SEND:		send_network();							break;

	case	C_FLAGS:	list_flags();							break;

	/* R003931 */
	case    C_THROTTLELIST: display_throttle("SHC");            break;

	case    C_INSTPROFILE:	inst_profile();						break;
	case    C_INSTSET:		inst_set();							break;
	case    C_INSTFORCE:	inst_set();							break;
	case    C_CUTOVER:      cutover();                          break;
	case    C_READY:      	ready();                          break;
	case    C_NODEUPDATE:  	nodeupdate(0);                          break;
	case	C_NEWNODE:		nodeupdate(1);							break;
	case    C_NODEUPDATEACK:  	nodeupdate(1);                          break;
	case    C_SHUTDOWN:     shutdownNode();                     break;  // R019289
	case	C_ROUTESET:	routeset();									break;
	case	C_ROUTESEND:	routesend();									break;
	case	C_ROUTEUPDATE:	routeupdate();									break;
	case	C_CUTOVER_NO_DB:	cutover_no_db();									break;
	case	C_PHC_CUTOVER:	phc_cutover();									break;
	case	C_GRACEFUL_SHUTDOWN:	graceful_shutdown();					break; //R029275
	case	C_MEMUPDATE:	memUpdate();									break;
	case	C_REVLOGCMD:	revlogcmd();									break;
	case	C_MAINTENANCE:	setNodeMaintenance();					break;
	case	C_NODESTATUS:	getNodeStatus();					break;
	case	C_RESETSTATUS:	resetNodeStatus();					break;
	default:			if((istty) && (!isDaemon)) 
						printf("Internal error: cmd %d ????\n", cmd); 
					else 			
						OTraceInfo("I-SHC-135050: Internal error: cmd %d ????\n", cmd); 
					break;
	}
	return (0);
}

static int fillNetworkID(char *cmdbuf, int len)
{
	unsigned int offset = 0;
	if (binRouteObj)
	{
		char *lastUpBin = NULL;
		cmdbuf += strlen(cmdbuf);
		struct RoutingInfo routingInfo = { 0 };
		snprintf(routingInfo.destNode, sizeof(routingInfo.destNode), "%s", mbcurrentnode);
		int m = binRouteObj->getRouteEntries(NULL, &routingInfo);
		for (int ii=0;ii<m;ii++)
		{
			struct s_binroute *r = binRouteObj->getRoute(ii);
			if (r->status == BIN_ROUTE_STATUS_UP)
			{
				snprintf(cmdbuf + offset, len - offset, " -up ");

			}
			else
			{
				snprintf(cmdbuf + offset, len - offset, " -down ");
			}
			offset = strlen(cmdbuf);

			binRouteObj->createBroadcastStr(cmdbuf+offset, len - offset, r);
			offset = strlen(cmdbuf);

			if (	((lastUpBin == NULL) || (strcmp(lastUpBin, r->internalid)!=0)) &&
					(strcmp(r->node, mbcurrentnode)== 0)
				)
			{
				if (shcBin->setBinPkg(r->internalid)>=0)
				{
					if (!shc_isdown(shcBin->binPkg))
					{
						snprintf(cmdbuf + offset, len - offset, " -up %s ", r->internalid);
						offset = strlen(cmdbuf);
						lastUpBin = r->internalid;
					}
				}
			}
		}
	}

	int i;
	int n = 0;
	char *p = NULL;
    struct shcpkg *pTmpPkg = NULL;
	if (shcSharedMemoryHelperObj->attachCurrent(&shcAppid, &pShcAppHead) < 0)
	{
		if((istty) && (!isDaemon))
		{
			printf("Can't find shared-cash rule, list request aborted\n");
			return -1;
		}
		else
		{
			OTraceError("E-SHC-135051: Can't find shared-cash rule, list request aborted\n");
                        return -1;
		}
	}

	if (strcmp(arg_v[0],"ready")!=0)  
	{
		for(i = 0, p = rm_getapptext(shcAppid); i < pShcAppHead->textused; ++i,p+=pShcAppHead->textsize)
		{
//		if (strcmp(shcBinPkg[i].bin.node, mbcurrentnode)!=0)
//			continue;
//		if (!shcBinPkg[i].bin.node[0])
//			continue;
			pTmpPkg = (struct shcpkg *)p;
			if (pTmpPkg->bin.flags & SH_DOWN)
			{
				if (strcmp(arg_v[0],"newnode")!=0)
					snprintf(cmdbuf + offset, len - offset, " -down  %s ", pTmpPkg->bin.networkid);
				else
					{
						//don't broadcast down bin for newnode command because as long as
						//one code has bin as up, all other nodes should set the bin up as well
					}
			}
			else
			{
				snprintf(cmdbuf + offset, len - offset, " -up %s ", pTmpPkg->bin.networkid);
			}
			offset = strlen(cmdbuf);
			n++;
		}
		
		shcApp->instProfileObj->addAllBroadcastString(cmdbuf,len);
		
	}
	
	return n;
}
static int ready()
{
	if(arg_c != 1)
	{
		if((istty) && (!isDaemon))
		{
			printf("Usage: %s\n", arg_v[0]);
			return(0);
		}
		else
		{
                        OTraceInfo("I-SHC-135052: Usage: %s\n", arg_v[0]);
                        return(0);
                }
			
	}

	istswSetReady();
	char cmdbuf[SHCCMD_ROUTE_BROADCAST_BUF_LEN];

	sprintf(cmdbuf, "shccmd -site %hd -s acknodeupdate  %s ", mbGetSiteId(), mbcurrentnode);
	//Send broadcast message
	int n = fillNetworkID(cmdbuf, sizeof(cmdbuf));

	//Need to send this message out even no bin to broadcast
	mcastHelperObj->broadcast("shccmd", 3, cmdbuf , strlen(cmdbuf), NULL, 0);

	return 0;
}

static int nodeupdate(int needAck)
{
	bin_t bin;
	int newRouteStatus = BIN_ROUTE_STATUS_UP;
	
	if( (strcmp(arg_v[0], "nodeupdate")== 0) && (arg_c < 3 ))
	{
		if((istty) && (!isDaemon))
		{
			printf("Usage: %s <from node> [<networkid1>|-r <[siteid.]routeid>]|-i <inst_profile id> ...\n", arg_v[0]);
			return(0);
		}
		else
		{		
			OTraceInfo("I-SHC-135053: Usage: %s <from node> [<networkid1>|-r <[siteid.]routeid>]|-i <inst_profile id> ...\n", arg_v[0]);
                        return(0);
                }
	}
	else if ( (strcmp(arg_v[0], "acknodeupdate")== 0) && (arg_c < 2 ))
	{
		if((istty) && (!isDaemon))
                {
			printf("Usage: %s <from node> [<networkid1>|-r <[siteid.]routeid>]...\n", arg_v[0]);
			return(0);
		}
		else
		{
			OTraceInfo("I-SHC-135054: Usage: %s <from node> [<networkid1>|-r <[siteid.]routeid>]...\n", arg_v[0]);
                        return(0);
                }
	}
	else if ((strcmp(arg_v[0], "newnode")== 0) && (arg_c != 2))
	{
		if((istty) && (!isDaemon))
                {
			printf("Usage: %s <from node> \n", arg_v[0]);
			return(0);
		}
		else
		{	
			OTraceInfo("I-SHC-135055: Usage: %s <from node> \n", arg_v[0]);
                        return(0);
                }
	}

	int i = 2;	//Starting from the first networkid
	
	int hasRouteChange = 0;

	if (strcmp(arg_v[0], "newnode")!= 0)
	{
		for(;i<arg_c;i++)
		{
			if (strcmp(arg_v[i], "-down") == 0)
			{
				newRouteStatus = BIN_ROUTE_STATUS_DOWN;
				continue;
			}
			else if (strcmp(arg_v[i], "-up") == 0)
			{
				newRouteStatus = BIN_ROUTE_STATUS_UP;
				continue;
			}
			else if (strcmp(arg_v[i], "-r") == 0)
			{
				//This is a route entry
				struct RoutingInfo routingInfo = { 0 };
				if (binRouteObj)
				{
					routingInfo.siteId = ofThisSite;
					snprintf(routingInfo.destNode, sizeof(routingInfo.destNode), "%s", arg_v[++i]);
					routingInfo.mailbox[0] = 0;
					strncpy(getRouteEntriesBinrouteGroup, arg_v[++i], sizeof(_nouse->binroute_group)-1);
					snprintf(routingInfo.port, sizeof(routingInfo.port), "%s", arg_v[++i]);
					snprintf(bin, sizeof(bin), "%s", arg_v[++i]);
					shcApp->shcmsgHelperObj->shc_normalizebin(bin);
					binRouteObj->changeRouteStatus(bin, &routingInfo, newRouteStatus);
					hasRouteChange = 1;
					continue;
				}
				else
					i += 5;	//skip -r, mailbox, port and binid and binrouteGroup
			}
			else if (strcmp(arg_v[i], "-i") == 0)
			{
				//Institution profile data
				shcApp->instProfileObj->changeInstProfileStatus(atoi(arg_v[++i]), newRouteStatus, NULL);
				continue;
			}
			else if (shcBin->setBinPkg(arg_v[i])<0)
			{
				OTraceDebug("E-SHC-135023:Invalid internal bin:[%s]\n", arg_v[i]);
				continue;
			}

			if (newRouteStatus ==BIN_ROUTE_STATUS_UP)
				shcBin->setInstUp( 1 );
		}
		if (hasRouteChange)
			binRouteObj->tidyUpBinStatus();
	}
	
	if (needAck)
	{
		char cmdbuf[SHCCMD_ROUTE_BROADCAST_BUF_LEN] = {0};
	
		snprintf(cmdbuf, sizeof(cmdbuf), "shccmd -site %hd -s nodeupdate %s", mbGetSiteId(), mbcurrentnode);
		//Send broadcast message
		int n = fillNetworkID(cmdbuf, sizeof(cmdbuf));
	
		if (n>0)
			mcastHelperObj->broadcast("shccmd", 2, cmdbuf , strlen(cmdbuf), arg_v[1][0]=='*'?NULL:arg_v[1], ofThisSite);
		else
		{
			if((istty) && (!isDaemon))
			{
				printf("No bin to broadcast\n");
				OTraceInfo("I-SHC-135002: No bin to broadcast\n");
			}
			else
				OTraceInfo("I-SHC-135002: No bin to broadcast\n");
		}
	}
	return 0;
}

static int shutdownNode()		// R019289
{
	char       cmdbuf[512]={0};
	
	if(arg_c != 1)
	{
		if((istty) && (!isDaemon))
		{
			printf("Usage: %s\n", arg_v[0]);
			return(0);
		}
		else
		{
			OTraceInfo("I-SHC-135057: Usage: %s\n", arg_v[0]);
                        return(0);
                }
	}
	
	if ( mbidShccmdDaemon < 0 )
	{
		mbidShccmdDaemon = mb_locatemailbox(IST_MB_DAEMON);
		if (mbidShccmdDaemon <= 0)
		{
			OTraceWarning("W-SHC-135003: Unable to locate mbox '%s', ignored shutdown\n", IST_MB_DAEMON);
			return -1;
		}
	}
	
	if ( mbidSharedcash < 0 )
	{
		mbidSharedcash = mb_locatemailbox(SHC_SERVER_NAME);
		if (mbidSharedcash <= 0)
		{
			OTraceWarning("W-SHC-135004: Unable to locate mbox '%s', ignored shutdown\n", SHC_SERVER_NAME);
			return -2;
		}
	}
	
 	int flagBroadcast = ! isIstswSuspend();
	
	istswClearReady();
	suspendIstsw();
	
	if ( flagBroadcast )
	{
		// broadcast current node down
		snprintf(cmdbuf, sizeof(cmdbuf),"shccmd -site %hd force -node %s down", mbGetSiteId(), mbcurrentnode);
		mcastHelperObj->broadcast("shccmd", 3, cmdbuf , strlen(cmdbuf), NULL, 0);
		OTraceInfo("I-SHC-135005: '%s' broadcasted\n", cmdbuf);
		syslg("'%s' broadcasted\n", cmdbuf);
		
		// Set local binroute down
		if (binRouteObj)
		{
			sleep(2);		//Sleep for a few seconds to let the broadcast take effect on other nodes 
			struct RoutingInfo routingInfo = { 0 };
			snprintf(routingInfo.destNode, sizeof(routingInfo.destNode), "%s", mbcurrentnode);
			binRouteObj->markRouteDown(NULL, &routingInfo);
		}
		return 0;		
		
	}

#if defined(TM_MULTI_Q)
	int nEvents = tm_count_fresh_mbid_events( mbidSharedcash );
#else
	int nEvents = countEvents( mbidSharedcash );
#endif

	if ( nEvents > 0 )
	{
		OTraceDebug("D-SHC-135006: [%d] event(s) remain in mbox[%s], sleep %d seconds\n", nEvents, SHC_SERVER_NAME, SHUTDOWN_SLEEP );
		snprintf( cmdbuf, sizeof(cmdbuf), "shccmd shutdownnode" );
		tm_enqueue( mbidShccmdDaemon, time(NULL)+SHUTDOWN_SLEEP, TM_NOTIFY_ONCE, 74883696L, cmdbuf, sizeof(cmdbuf) );
	}
	else
	{
		OTraceInfo("I-SHC-135007: Current node[%s] coming down\n", mbcurrentnode);
		syslg("I-SHC-135007:Current node[%s] coming down\n",mbcurrentnode);
		ist_executor::execute_l("mbkill", 0);	// shutdown ist switch
	}
	
	return 0;
}

#if !defined(TM_MULTI_Q)
static int countEvents( int mbid )		// R019289
{
	register  struct  memhead   *q;
	register  struct  mbbufhead *h;
	int  nEvents = 0;
	
	if(mb->event_queue < 0)
		return(-1);
	
	tm_lock();
	
	q = MEM_GETHEADADDR((struct memcntrl *)mbbuf, mb->event_queue);
	if(q == NULL)
	{
		tm_unlock();

		return(-1);
	}
	
	for(q = MEM_GETHEADADDR((struct memcntrl *)mbbuf, q->next);
		q;
		q = MEM_GETHEADADDR((struct memcntrl *)mbbuf, q->next))
	{
		h = (struct mbbufhead *)MEM_GETHEADDATA(q);
		if(h->expire == 0)
			continue;

		/* To cover case if message already expired, but notification 
		   in queue already
		*/
		if(h->flags & TM_DID_NOTIFY)
			continue;
		
		if(mbid >= 0)
			if(h->mbid != mbid)
				continue;
		
		nEvents++;
	}
	
	tm_unlock();

	return nEvents;
}
#endif

static int getMbInput()		// R019535
{
	char	*bp;
	int		i;
	int len;

	if ( mbidShccmdDaemon < 0 )
	{
		mbidShccmdDaemon = mb_locatemailbox(IST_MB_DAEMON);
		if (mbidShccmdDaemon <= 0)
		{
			if((mbidShccmdDaemon = mb_createmailbox(IST_MB_DAEMON, 0, 0)) < 0)
			{
				OTraceFatal("F-SHC-135008: Unable to create mailbox '%s'\n", mbidShccmdDaemon);
				return(-1);
			}
		}
	}
	
	OTraceInfo("I-SHC-135009: Waiting command from mailbox '%s'\n", IST_MB_DAEMON);
	for(;;)
	{

#if !defined(WIN32)
		if(arg_v)
			/*	clear from last command */
			free(arg_v);
#endif
		
		arg_v = NULL;
		memset(xbuf, 0, sizeof(xbuf));
		if ( (len=mb_read( mbidShccmdDaemon, xbuf, sizeof(xbuf) )) <= 0 )
		{
			if( mb_test() < 0 ) return -1 ;
			continue ;
		}

		xbuf[len] = '\0';
		OTraceHexDump((unsigned char *)xbuf, len);
		
		if( mbIsEvent() )
		{
			tm_dequeue(mbLastEvent());
		}

		const char CMD_KEYWORD[]  = "shccmd ";
		
		bp = strstr(xbuf, CMD_KEYWORD);
		
		if ( bp && *bp )
		{
			bp += strlen(CMD_KEYWORD);
			for( ; isspace(*bp); bp++ );
			 OTraceInfo("I-SHC-135010: Received message %d from mbox[%s]\n", len, IST_MB_DAEMON);
		}
		else
		{
			continue;
		}

		mflag = 0;
		dflag = 0;
		noBraodcastFlag = 0;
		ofThisSite = 0;
		//Check options
		while(bp[0])
		{
			if(strncmp(bp, "-m", 2) == 0)
			{
				/*	Probably called from the monitor remotley */
				mflag = 1;
				bp += 2;
				if (bp[0] == ' ')
					bp++;
			}
			else if(strncmp(bp, "-d", 2) == 0)
			{
				/*	Some commands need to broadcast */
				dflag = 1;
				bp += 2;
				if (bp[0] == ' ')
					bp++;
			}
			else if(strncmp(bp, "-site", 5) == 0)
			{
				/*	From site */
				bp += 5;
				while (bp[0] == ' ')
					bp++;
				ofThisSite = atoi(bp);

				//seek to next paramater
				while (isdigit(bp[0]))
					bp++;
				while (bp[0] == ' ')
					bp++;

			}
			else if(strncmp(bp, "-s", 2) == 0)
			{
				/*	Absolutely no broadcast */
				noBraodcastFlag = 1;
				bp += 2;
				if (bp[0] == ' ')
					bp++;
			}
			else
				break;
		}

		if (strncmp(bp, "memupdate", 9)==0)
		{
			if (len > 40)
			{
				updateMemDataLen = len - 38;
				memcpy(updateMemData, bp+31, std::min<int> (updateMemDataLen, sizeof (updateMemData)));
				bp[30] = '\0';
			}
			else
			{
				OTraceError("E-SHC-135028:updatemem command too short, ignore\n");
				continue;
			}
		}
		arg_v = make_argv(bp, 1);
		for(arg_c = 0; arg_v[arg_c]; ++arg_c)
			;
		
		i = find_command(cmdtab, arg_v[0], NULL);
		if(i >= 0)
		{
			OTraceInfo("I-SHC-135011: execute command '%s'\n", arg_v[0]);
			return(i);
		}
		
		OTraceInfo("I-SHC-135012: Invalid command: '%s'\n", xbuf);
	}
}


static int cutover()
{
	char instid[100] = {0};
	char entityid[100] = {0};
	char type[5] = {0};;
	char *usage = (char *)"InstId [EntityId|SWITCH|ACQ|ISS|BOTH] APO YYYYMMDD";
	char *usage1 = (char *)"SWITCH APO YYYYMMDD";
	date_t date;
	IssuerInfo issInfo;
	InstBusinessDay businessDay;
	struct  shcpkg  *pkg;
	char timezoneId[30] = {0};    // R021833

	bool isMsgReplication = false;
	char* replicationFlags = NULL;

	entityid[0] = '\0';

	memset(&tmpHeader.msg, 0, sizeof(struct shcmsg));
	memset(&tmpHeader.segment, 0, sizeof(tmpHeader.segment));


	if ( strncmp( arg_v[arg_c-1], "-msg-repl-flags=", 16 ) == 0 ){
		replicationFlags = arg_v[arg_c-1] + 16;
		arg_c--;
		isMsgReplication = true;
		OTraceDebug("D-MRREPL-135013 message replication for cutover - replication flags = %s\n", replicationFlags );
	}


	if(arg_c < 4  || arg_c > 5)
	{
		if((istty) && (!isDaemon))
		{
			printf("Usage: %s %s\n (OR) \n", arg_v[0], usage1);
			printf("Usage: %s %s\n", arg_v[0], usage);
			return(0);
		}
		else
		{
			OTraceInfo("I-SHC-135058: Usage: %s %s\n (OR) \n", arg_v[0], usage1);
			OTraceInfo("I-SHC-135058: Usage: %s %s\n", arg_v[0], usage);
                        return(0);
                }
	}

	if (strlen(arg_v[1]) > 10)
	{
		if((istty) && (!isDaemon))
                {
			printf("Usage: Institution id length should be <= 10\n");
			return (0);
		}
		else
		{
			OTraceInfo("I-SHC-135059: Usage: Institution id length should be <= 10\n");
                        return (0);
                }
	}

	snprintf(instid, sizeof(instid), "%s", arg_v[1]);

	if (strcmp (instid, "SWITCH") == 0)
	{
		/* Switch Cutover */
		if ((arg_c != 4) && (arg_c != 5))
		{
			if((istty) && (!isDaemon))
                	{
				printf("Usage: %s %s [-msg-repl-flags=I|A|B|M]\n", arg_v[0], usage1);	
				return (0);
			}
			else
			{
				OTraceInfo("I-SHC-135060: Usage: %s %s [-msg-repl-flags=I|A|B|M]\n", arg_v[0], usage1);
                                return (0);
                        }
		}

		snprintf(type, sizeof(type),"%s",arg_v[2]);

		if (strlen (arg_v[3]) != 8)
		{
			if((istty) && (!isDaemon))
                        {
				printf("Usage: %s %s\n", arg_v[0], usage);
				return (0);
			}
			else
                        {
                                OTraceInfo("I-SHC-135061: Usage: %s %s\n", arg_v[0], usage);
                                return (0);
                        }
		}

		date = atol(arg_v[3]);

		tmpHeader.msg.from_acct |= IST_ROLE_SW;

		businessDay.getMainInstEntryFromMem();

		businessDay.getInstId(instid);
		businessDay.getEntityId(entityid);

	}
	else
	{
		if (arg_c == 5)
		{
			entityid[0] = '\0';
			if (strcmp(arg_v[2], "ACQ")==0)
			tmpHeader.msg.from_acct |= IST_ROLE_ACQ;
			else if (strcmp(arg_v[2], "ISS")==0)
			tmpHeader.msg.from_acct |= IST_ROLE_ISS;
			else if (strcmp(arg_v[2], "BOTH")==0)
			tmpHeader.msg.from_acct |= IST_ROLE_ISS|IST_ROLE_ACQ;
			else
				snprintf(entityid, sizeof(entityid),"%s",arg_v[2]);
		}

		if (strlen(arg_v[arg_c - 2]) > 4)
		{
			if((istty) && (!isDaemon))
			{
				printf("Usage: %s %s\n", arg_v[0], usage);
				return (0);
			}
			else
			{
				OTraceInfo("I-SHC-135062: Usage: %s %s\n", arg_v[0], usage);
                                return (0);
                        }
		}

		snprintf(type, sizeof(type), "%s", arg_v[arg_c - 2]);

		if (strlen (arg_v[arg_c -1 ]) != 8)
		{
			if((istty) && (!isDaemon))
                        {
				printf("Usage: %s %s\n", arg_v[0], usage);
				return (0);
			}
			else
                        {
                                OTraceInfo("I-SHC-135063: Usage: %s %s\n", arg_v[0], usage);
                                return (0);
                        }
		}

		date = atol(arg_v[arg_c -1]);
	}
	
	for (int x = 0; x < strlen(type); x++)
	{
		switch (type[x])
		{
			case 'A':
				tmpHeader.msg.from_acct |= IST_ROLE_ATM;
				break;
			case 'P':
				tmpHeader.msg.from_acct |= IST_ROLE_POS;
				break;
			case 'O':
				tmpHeader.msg.from_acct |= IST_ROLE_OTHER;
				break;
			default:
				if((istty) && (!isDaemon))
                        	{
					printf ("Usage: %s %s\n", arg_v[0],usage);
					return(0);
				}
				else
                        	{
                        	        OTraceInfo("I-SHC-135064: Usage: %s %s\n", arg_v[0], usage);
                        	        return (0);
                        	}
		}
	}

	OTraceInfo("I-SHC-135012: process in the cutover command \n");
	shc_locate_issuer_from_institution(instid, entityid, SHC_NETWORK, issInfo);

	if (!issInfo.foundIssuer())
	{
		shc_locate_issuer_from_institution("SWITCH", "", SHC_NETWORK, issInfo);
		if (!issInfo.foundIssuer())
		{
			if((istty) && (!isDaemon))
                        {
				printf("%s: Can't find issuer for Inst[%s] Entity[%s]\n",  arg_v[0], instid, entityid);
				return(0);
			}
			else
			{
				OTraceInfo("I-SHC-135065: %s: Can't find issuer for Inst[%s] Entity[%s]\n",  arg_v[0], instid, entityid);
                                return(0);
                        }
		}
		OTraceDebug("D-SHC-135025:Use SWITCH entry to find the issuer in inst_profile\n");
	}

	if(shc_locate_bin(&pkg, (char *)issInfo.getIssuerBin()) < 0)
	{
		if((istty) && (!isDaemon))
                {
			printf("%s: Institution <%s> Bin <%s>is not valid.\n", arg_v[0], instid, issInfo.getIssuerBin());
			return(0);
		}
		else
                {
                        OTraceInfo("I-SHC-135066: %s: Institution <%s> Bin <%s>is not valid.\n", arg_v[0], instid, issInfo.getIssuerBin());
                        return(0);
                }
	}

	snprintf(tmpHeader.msg.txnSrc, sizeof(tmpHeader.msg.txnSrc), "%s", instid);
	snprintf(tmpHeader.msg.txnDest, sizeof(tmpHeader.msg.txnDest), "%s", instid);
	snprintf(tmpHeader.msg.entityId, sizeof(tmpHeader.msg.entityId),"%s",entityid);
	snprintf(tmpHeader.msg.iss_entityId, sizeof(tmpHeader.msg.iss_entityId),"%s",entityid);
	snprintf(tmpHeader.msg.issuer, sizeof(tmpHeader.msg.issuer), "%s", issInfo.getIssuerBin());
	snprintf(tmpHeader.msg.acquirer, sizeof(tmpHeader.msg.acquirer), "%s", issInfo.getIssuerBin());
	snprintf(tmpHeader.msg.originator, sizeof(tmpHeader.msg.originator),  "%s", shc_orgid);
	tmpHeader.msg.msgtype = SHC_NETWORK;
	tmpHeader.msg.netcode = SHC_NET_CUTOVER_START;
	tmpHeader.msg.cap_date = date;
	//	tmpHeader.msg.cap_date = shc_adjust_date(date, -1);	The date is already old date
	if ( isMsgReplication ){
		if (replicationFlags[0] == 'M')
			tmpHeader.msg.from_acct |= IST_ROLE_SW;
		else if ( replicationFlags[0] == 'A' )
			tmpHeader.msg.from_acct |= IST_ROLE_ACQ;
		else if ( replicationFlags[0] == 'I' )
			tmpHeader.msg.from_acct |= IST_ROLE_ISS;
		else if ( replicationFlags[0] == 'B' ){
			tmpHeader.msg.from_acct |= IST_ROLE_ISS;
			tmpHeader.msg.from_acct |= IST_ROLE_ACQ;
		}
		tmpHeader.msg.pos_condition_code |= IS_CUTOVER_CMD_MSG_REPL;
	}


	ShcCutoverHelper * shcCutoverHelper = (ShcCutoverHelper *)shcHelperRegister.getTargetObj(SHC_ShcCutoverHelper);
	if(shcCutoverHelper){
		int err = shcCutoverHelper->check_cap_date(date);
		if(err == -1)
			return 0;
	}
// R021833 >>>
    tmpHeader.msg.batch_id = 0;
// R021833 <<<<

	mb_getUmi(tmpHeader.msg.shclog_id, sizeof(tmpHeader.msg.shclog_id));
	OTraceLog("L-SHC-135013: Created message ID[%s] m%04d/n%d\n", 
		tmpHeader.msg.shclog_id, tmpHeader.msg.msgtype, tmpHeader.msg.netcode);
	shcBin->setBinPkg(pkg);
	thisShcApp->shcNetworkMsgHelperObj->shc_send_800(&tmpHeader, shcBin);

	return (0);
}
//R027855 >>
static int phc_cutover()
{
	ShcCutoverHelper * shcCutoverHelper = (ShcCutoverHelper *)shcHelperRegister.getTargetObj(SHC_ShcCutoverHelper);

	int err = shcCutoverHelper->initialize(thisShcApp, &tmpHeader);

	if(err>=0)
		err = shcCutoverHelper->cmd_process_phc_cutover(arg_c,arg_v);

	delete shcCutoverHelper;

	return err;
}
static int cutover_no_db()
{
	ShcCutoverHelper * shcCutoverHelper = (ShcCutoverHelper *)shcHelperRegister.getTargetObj(SHC_ShcCutoverHelper);

	int err = shcCutoverHelper->initialize(thisShcApp, &tmpHeader);

	if(err>=0)
		err = shcCutoverHelper->cmd_process_cutover_no_db(arg_c,arg_v);

	delete shcCutoverHelper;

	return err;
}
//R027855 <<

static void inst_profile(void)
{
	if(arg_c == 1)
	{
		thisShcApp->instProfileObj->display(NULL, NULL);
	}
	else if (arg_c == 2)
	{
		thisShcApp->instProfileObj->display(arg_v[1], NULL);
	}
	else if (arg_c == 3)
	{
		thisShcApp->instProfileObj->display(arg_v[1], arg_v[2]);
	}
}

static void inst_set(void)
{
	char txnSrc[11];
	char txnDest[11];
	char iss_entityId[31];
	InstProfileList ipList;
	struct	shcpkg	*pkg;

	txnSrc[0] = '\0';
	txnDest[0] = '\0';
	iss_entityId[0] = '\0';

	if(stricmp(arg_v[arg_c - 1], "up") != 0 && stricmp(arg_v[arg_c - 1], "down") != 0)
	{
		if((istty) && (!isDaemon))
		{
			printf("Usage: %s [txnsrc [txndest [EntityID]]]  [up | down]\n", arg_v[0]);
			return;
		}
		else
		{
			OTraceInfo("I-SHC-135067: Usage: %s [txnsrc [txndest [EntityID]]]  [up | down]\n", arg_v[0]);
                        return;
                }
	}

	if (arg_c == 3)
	{
		if(strlen(arg_v[1]) > 10)
		{
			if((istty) && (!isDaemon))
                	{
				printf("Source Institution has too many digits.\n");
				return;
			}
			else
                	{
                        	OTraceInfo("I-SHC-135068: Source Institution has too many digits.\n");
                        	return;
                	}
		}

		snprintf(txnSrc, sizeof(txnSrc), "%s", arg_v[1]);
	}
	else if (arg_c == 4)
	{
		if(strlen(arg_v[1]) > 10)
		{
			if((istty) && (!isDaemon))
                        {
				printf("Source Institution has too many digits.\n");
				return;
			}
                        else
                        {
                                OTraceInfo("I-SHC-135069: Source Institution has too many digits.\n");
                                return;
                        }
		}

		if(strlen(arg_v[2]) > 10)
		{
			if((istty) && (!isDaemon))
                        {
				printf("Txn Destination has too many digits.\n");
				return;
			}
                        else
                        {
                                OTraceInfo("I-SHC-135070: Txn Destination has too many digits.\n");
                                return;
                        }
		}
		
		snprintf(txnSrc, sizeof(txnSrc), "%s", arg_v[1]);
		snprintf(txnDest, sizeof(txnDest), "%s", arg_v[2]);
	}
	else if (arg_c == 5)
	{
		if(strlen(arg_v[1]) > 10)
		{
			if((istty) && (!isDaemon))
                        {
				printf("Source Institution has too many digits.\n");
				return;
			}
                        else
                        {
                                OTraceInfo("I-SHC-135071: Source Institution has too many digits.\n");
                                return;
                        }
		}

		if(strlen(arg_v[2]) > 10)
		{
			if((istty) && (!isDaemon))
                        {
				printf("Txn Destination has too many digits.\n");
				return;
			}
                        else
                        {
                                OTraceInfo("I-SHC-135072: Txn Destination has too many digits.\n");
                                return;
                        }
		}

		if(strlen(arg_v[2]) > 10)
		{
			if((istty) && (!isDaemon))
                        {
				printf("Txn Destination has too many digits.\n");
				return;
			}
                        else
                        {
                                OTraceInfo("I-SHC-135073: Txn Destination has too many digits.\n");
                                return;
                        }
		}
		
		snprintf(txnSrc, sizeof(txnSrc), "%s", arg_v[1]);
		snprintf(txnDest,sizeof(txnDest), "%s", arg_v[2]);
		snprintf(iss_entityId, sizeof(iss_entityId),"%s", arg_v[3]);
	}

	if (thisShcApp->instProfileObj->getInstProfileList(txnSrc, txnDest, iss_entityId, ipList) < 0)
	{
		return;
	}


	for (int x = 0; x < ipList.size(); x++)
	{
		if(shc_locate_bin(&pkg, (char *)ipList[x].getBin()) < 0)
		{
			if((istty) && (!isDaemon))
                        {
				printf("Internal BIN : %s  in send command is not recognized\n",
					(char *)ipList[x].getBin());
			}
			else
                        {
				OTraceInfo("I-SHC-135074: Internal BIN : %s  in send command is not recognized\n", (char *)ipList[x].getBin());
                        }
			continue;
		}

		if(stricmp(arg_v[arg_c - 1], "up") == 0)
			set_up(ipList[x], pkg);
		else if(stricmp(arg_v[arg_c - 1], "down") == 0)
			set_down(ipList[x], pkg);
	}
	return;
}



int trace()
{
	struct	shcpkg	*pkg;
	bin_t	bin;
	int		on;

	if(arg_c < 2)
	{
		if((istty) && (!isDaemon))
			printf("Usage: %s [<instid> | switch] [on | off]\n", arg_v[0]);
		else
			OTraceInfo("I-SHC-135075: Usage: %s [<instid> | switch] [on | off]\n", arg_v[0]);
		return(0);
	}
	
	if(arg_c == 3)
	{
		if(stricmp(arg_v[2], "on") == 0)
			on = 1;
		else if(stricmp(arg_v[2], "off") == 0)
			on = 0;
		else
		{
			if((istty) && (!isDaemon))
			{
				printf("%s: '%s' is invalid. This value must be 'on' or 'off'.\n",
				arg_v[0], arg_v[2]);
			}
			else
			{
				OTraceInfo("I-SHC-135076: %s: '%s' is invalid. This value must be 'on' or 'off'.\n",
				arg_v[0], arg_v[2]);
			}
			return(0);
		}
	}
	else
		on = -1;
	
	/*	determine if they debug on for the switch. */
	if(stricmp(arg_v[1], "switch") == 0)
	{
		if(on == -1)
		{
			if((istty) && (!isDaemon))
				printf("%s: You must specify one of 'on' or 'off' for option 'switch'\n", arg_v[0]);
			else
				OTraceInfo("I-SHC-135077; %s: You must specify one of 'on' or 'off' for option 'switch'\n", arg_v[0]);
			return(0);
		}
		else
		{
			/*	we ask the mailbox command for trace command */
			ist_executor::execute_l("mbcmd", "trace", "appl", SHC_SERVER_NAME, arg_v[2], (void *)0);
			return(0);
		}
	}


	/*	if here then they want trace on for a particular insitution */
	snprintf(bin, sizeof(bin),"%s",arg_v[1]);

	if(shc_locate_bin(&pkg, bin) < 0)
	{
		if((istty) && (!isDaemon))
			printf("%s: Institution <%s> is not valid.\n", arg_v[0], bin);
		else
                        OTraceInfo("I-SHC-135078: %s: Institution <%s> is not valid.\n", arg_v[0], bin);
		return(0);
	}

	if(arg_c == 2)
	{
		if((istty) && (!isDaemon))
			printf("%s: Trace is %s.\n", bin, shcIsTraceOn(pkg) ? "on" : "off");
		else
			OTraceInfo("I-SHC-135079: %s: Trace is %s.\n", bin, shcIsTraceOn(pkg) ? "on" : "off");
	}
	else if(on)
		shcTurnTraceOn(pkg);
	else
		shcTurnTraceOff(pkg);
	
	return(0);
}


int saf()
{
	ist_executor::execute("istadvicecmd", arg_v + 1, 0);
	
	return( 0 );
}

int list()
{
	/*	
	 *	list [networkid | up | down]
	 */
	int	i;
	char inst[11];
	char *p = NULL;
	struct shckeysmem *pTmp = NULL;

	if (shcSharedMemoryHelperObj->attachCurrent(&shcAppid, &pShcAppHead) < 0)
	{
		if((istty) && (!isDaemon))
			printf("Can't find shared-cash rule, list request aborted\n");
		else
                        OTraceError("E-SHC-135080: Can't find shared-cash rule, list request aborted\n");
		return -1;
	}
	if(arg_c == 1 || stricmp(arg_v[1], "all") == 0)
	{
		for(i = 0; i < pShcAppHead->keysused; ++i)
		{
			list_short(i);
		}
	}
	else if((arg_c == 2 || arg_c == 3 ) &&  
			(stricmp(arg_v[arg_c - 1], "up") == 0 || stricmp(arg_v[arg_c - 1], "down") == 0))
		list_up_down();
	else if (arg_c == 2)
	{
		ICInstId_pure(inst, arg_v[1]);
		p = rm_getappkey(shcAppid);
		for(i = 0; i < pShcAppHead->keysused; ++i, p+=pShcAppHead->keysize)
		{
			/*	list only for inst */
			pTmp = (struct shckeysmem *)p;
			if(strcmp(pTmp->institutionid,inst) != 0)
				continue;
			else
			{
				list_short(i);
			}
		}
	}
	else
		list_inst();

	return( 0 );
}


int list_short(int i)
{
	struct shckeysmem *pTmp =(struct shckeysmem *) (rm_getappkey(shcAppid)+pShcAppHead->keysize*i);
	int textid = pTmp->textid;
	struct shcpkg *pTmpPkg = (struct shcpkg *) (rm_getapptext(shcAppid)+pShcAppHead->textsize*textid);
	

	if(mflag)
	{
		if((istty) && (!isDaemon))
		{
			printf("%-10s %s 0x%lx\n", pTmp->institutionid,
							   pTmp->userbinid,
							   (int)pTmpPkg->bin.flags);
		}
		else
		{
			OTraceInfo("I-SHC-135081: %-10s %s 0x%lx\n", pTmp->institutionid, 
									pTmp->userbinid, 
									(int)pTmpPkg->bin.flags);
		}
		return(0);
	}
	
	if((istty) && (!isDaemon))
        {
		printf("[%3d]: %-10s %-10s (%-10s, %-3d)  Status: ", i,
		pTmp->institutionid, pTmp->userbinid, pTmp->owner, pTmp->textid);
	}
	else
	{
		OTraceInfo("I-SHC-135082: [%3d]: %-10s %-10s (%-10s, %-3d)  Status: ", i, 
		pTmp->institutionid, pTmp->userbinid, pTmp->owner, pTmp->textid);
	}

	if(pTmpPkg->bin.bintype & SH_DEFAULT_ISSUER)
		if((istty) && (!isDaemon))
                {
			printf("(Dflt) ");
		}
		else
		{
			OTraceInfo("I-SHC-135082: (Dflt) ");
                }

    if(pTmpPkg->bin.flags & SH_KEY_EXCHANGE) /* R001835 */
	if((istty) && (!isDaemon))
        {
        	printf("Ready "); /* R001835 */
	}
	else
	{
		OTraceInfo("I-SHC-135083: Ready ");
	}
    else if(pTmpPkg->bin.flags & SH_DOWN)
	if((istty) && (!isDaemon))
        {
		printf("Down  ");
	}
	else
	{
		OTraceInfo("I-SHC-135084: Down");
	}
	else
		if((istty) && (!isDaemon))
        	{
			printf("Up    "); /* R001835 */
		}
		else
		{
			OTraceInfo("I-SHC-135085: Up    ");
		}
		
	
    if(pTmpPkg->bin.bintype & SH_FORWARD_MODE) /* R001835 */
	if((istty) && (!isDaemon))
        {
        	printf("& Forward  ");
	}
	else
	{
		OTraceInfo("I-SHC-135086: & Forward  ");
        }

	if(pTmpPkg->bin.flags & SH_REPLAY)
		if((istty) && (!isDaemon))
        	{
			printf("S&F Replay  ");
		}
		else
        	{
                	OTraceInfo("I-SHC-135087: S&F Replay  ");
                }
	if(pTmpPkg->bin.flags & SH_KEY_MAC)
		if((istty) && (!isDaemon))
                {
			printf("MAC Key Xchg  ");
		}
		else
                {
                        OTraceInfo("I-SHC-135088: MAC Key Xchg  ");
                }
	if(pTmpPkg->bin.flags & SH_KEY_PIN)
		if((istty) && (!isDaemon))
                {
			printf("PIN Key Xchg  ");
		}
                else
                {
                        OTraceInfo("I-SHC-135089: PIN Key Xchg  ");
                }

	if (binRouteObj)
	{
		struct RoutingInfo routingInfo = { 0 };
		struct s_binroute *r = NULL;
		int nr = binRouteObj->getRouteEntries(pTmp->bin, &routingInfo);
		int m;
		
		for (m=0; m<nr; m++)
		{
			if((istty) && (!isDaemon))
                	{
				printf("\n");
			}
			else
			{
				OTraceInfo("\n");
			}
			r = binRouteObj->getRoute(m);
			if (r)
				if((istty) && (!isDaemon))
				{
					printf("\tROUTE:Site%1hd:%15s%25s%25s%25s%5s", 
					((r->siteId==1) || (r->siteId==2))?r->siteId:1, r->node, r->binrouteGroup, r->mailbox, r->port, r->status=='D'?"Down":"Up");
				}
				else
				{
					OTraceInfo("I-SHC-135090: \tROUTE:Site%1hd:%15s%25s%25s%25s%5s", 
					((r->siteId==1) || (r->siteId==2))?r->siteId:1, r->node, r->binrouteGroup, r->mailbox, r->port, r->status=='D'?"Down":"Up");
				}
			else
				if((istty) && (!isDaemon))
                                {
					printf("Route Error\n");
				}
				else
                                {
					OTraceError("E-SHC-135091: Route Error\n");
                                }
		}
	}

	if((istty) && (!isDaemon))
        {
		printf("\n");
	}
	else
	{
		OTraceInfo("\n");
        }

	return( 0 );
}

int list_up_down()
{
	int		i;
	int		type;
	int     checkinst = 0;
	char inst[11];

	if(stricmp(arg_v[arg_c - 1], "up") == 0)
		type = 1;
	else
		type = 2;

	if (arg_c == 3)
	{
		checkinst = 1;
		ICInstId_pure(inst, arg_v[1]);

	}

	if (shcSharedMemoryHelperObj->attachCurrent(&shcAppid, &pShcAppHead) < 0)
	{
		if((istty) && (!isDaemon))
        	{
			printf("Can't find shared-cash rule, list request aborted\n");
		}
		else
		{
			OTraceError("E-SHC-135092: Can't find shared-cash rule, list request aborted\n");
                }
		return -1;
	}

	char *p=rm_getappkey(shcAppid);
	
	if (!p)
	{
		if((istty) && (!isDaemon))
                {
			printf("Can't get key of shared-cash rule, abort.\n");
		}
		else
                {
			OTraceError("E-SHC-135093: Can't get key of shared-cash rule, abort.\n");
                }
		return -1;
	}
	struct shckeysmem *pTmp = NULL;
	struct shcpkg *pTmpPkg = NULL;
	for(i = 0; i < pShcAppHead->keysused; ++i, p+=pShcAppHead->keysize)
	{
		pTmp = (struct shckeysmem *)p;
		if(type == 1)
		{
			if (!checkinst || (strcmp(pTmp->institutionid,inst) == 0))
			{
				/*	list only 'up' inst */
				if (pTmp->textid < 0)
				{
					if((istty) && (!isDaemon))
					{
						printf("text id of bin(%s, %s) is %d, ignore\n", pTmp->institutionid, pTmp->userbinid, pTmp->textid);
					}
					else
					{
						OTraceInfo("I-SHC-135094: text id of bin(%s, %s) is %d, ignore\n", pTmp->institutionid, pTmp->userbinid, pTmp->textid);
                                        }
					continue;
				}
				pTmpPkg =(struct shcpkg *)( rm_getapptext(shcAppid) + pShcAppHead->textsize*pTmp->textid);
				if(pTmpPkg ->bin.flags & SH_DOWN)
					continue;
				else
					list_short(i);
			}
		}
		else
		{
			if (!checkinst || (strcmp(pTmp->institutionid,inst) == 0))
			{
				/*	list only down inst */
				pTmpPkg =(struct shcpkg *)( rm_getapptext(shcAppid) + pShcAppHead->textsize*pTmp->textid);
				if(pTmpPkg->bin.flags & SH_DOWN)
					list_short(i);
				else
					continue;
			}
		}

	}
	
	return( 0 );
}



int list_inst()
{
	struct	shcpkg *pkg;
	char	bin[100];
	char    inst[100];
	char	amount[100];
	char	buf[64];
	int		i,j;
	struct	pinverparm	*pin;

	snprintf(inst, sizeof(inst),"%s",arg_v[1]);
	snprintf(bin, sizeof(bin),"%s",arg_v[2]);
	
	if (shcSharedMemoryHelperObj->attachCurrent(&shcAppid, &pShcAppHead) < 0)
	{
		if((istty) && (!isDaemon))
		{
			printf("Can't find shared-cash rule, list request aborted\n");
		}
		else
		{
			OTraceError("E-SHC-135095: Can't find shared-cash rule, list request aborted\n");
                }
		return -1;
	}
	
	newlyFoundShcBinKey = NULL;
	shc_normalizebin(bin);
	if(shc_locate_bin(&pkg, inst, bin) < 0)
	{
		if((istty) && (!isDaemon))
                {
			printf("%s: Institution %s BIN %s not valid.\n", arg_v[0], arg_v[1], arg_v[2]);
		}
		else
                {
                        OTraceInfo("I-SHC-135096: %s: Institution %s BIN %s not valid.\n", arg_v[0], arg_v[1], arg_v[2]);
                }
		return(0);
	}


	/*
	 *	Display header stuff
	 */
	if((istty) && (!isDaemon))
	{
		printf("\nInstitution %s Bin %s <%s> is ", pkg->bin.institutionid, bin, pkg->bin.bankname);
	}
	else
	{
		OTraceInfo("I-SHC-135097: \nInstitution %s Bin %s <%s> is ", pkg->bin.institutionid, bin, pkg->bin.bankname);
        }
	if(pkg->bin.flags & SH_DOWN)
		if((istty) && (!isDaemon))
        	{
			printf("currently Down"); /* R001835 */
		}
		else
		{
			OTraceInfo("I-SHC-135098: currently Down");
		}
	else
		if((istty) && (!isDaemon))
                {
			printf("currently Up"); /* R001835 */
		}
		else
		{
                        OTraceInfo("I-SHC-135099: currently Up");
		}


	if(pkg->bin.bintype & SH_FORWARD_MODE) /* R001835 */
		if((istty) && (!isDaemon))
		{
        		printf(" & Forward\n");
		}
		else
		{
			OTraceInfo("I-SHC-135100:  & Forward\n");
        	}
    else
	if((istty) && (!isDaemon))
	{
        	printf("\n");
	}
	else
	{
		OTraceInfo("\n");
        }

	if((istty) && (!isDaemon))
        {
		printf( "Internal BIN <%-10s> Owner: %-10s  Network Manager: %s"
		   "\nBin type: %x   Time out: %ld %sseconds"
		   "\nMailbox Name: %s\n",
		newlyFoundShcBinKey->bin,
		pkg->bin.owner, 
		mbtab[pkg->bin.netmgrid].name,
		pkg->bin.bintype,
		(int)pkg->bin.timeout, (pkg->bin.addflag & SH_ADDFLAG_TIMEOUT_DECISECOND)?"Deci-":"",
		mbtab[pkg->bin.mailbox].name);
	}
	else
	{
		OTraceInfo("I-SHC-135101: Internal BIN <%-10s> Owner: %-10s  Network Manager: %s" 
		"\nBin type: %x   Time out: %ld %sseconds" 
		"\nMailbox Name: %s\n", 
		newlyFoundShcBinKey->bin, 
		pkg->bin.owner, 
		mbtab[pkg->bin.netmgrid].name, 
		pkg->bin.bintype, 
		(int)pkg->bin.timeout, (pkg->bin.addflag & SH_ADDFLAG_TIMEOUT_DECISECOND)?"Deci-":"", 
		mbtab[pkg->bin.mailbox].name);
	}
	
	if((istty) && (!isDaemon))
        {
		printf("Port Name: %-20s\n",
		mbtab[pkg->bin.port].name);
	}
	else
	{
		OTraceInfo("I-SHC-135102: Port Name: %-20s\n", 
		mbtab[pkg->bin.port].name);
	}
//	printf("Node: %-15s\n", pkg->bin.node);
	if (shcBalancerObj)
	{
		char balBuf[128];
		shcBalancerObj->toString(pkg, balBuf, sizeof(balBuf));
		if((istty) && (!isDaemon))
		{
			printf("%s", balBuf);
		}
		else
		{
			OTraceInfo("I-SHC-135103: %s", balBuf);
                }
	}
	if (binRouteObj)
	{
	
		if((istty) && (!isDaemon))
                {	
			printf("Route Information:\n");
		}
		else
		{
			OTraceInfo("I-SHC-135104: Route Information:\n");
                }
		
		struct RoutingInfo routingInfo = { 0 };
		snprintf(routingInfo.destNode, sizeof(routingInfo.destNode), "%s", mbcurrentnode);
		int m = binRouteObj->getRouteEntries(newlyFoundShcBinKey->bin, NULL);
		if (m <= 0)
		{
			if((istty) && (!isDaemon))
                	{
				printf("No route defined for this bin\n");
			}
			else
			{
				OTraceInfo("I-SHC-135105: No route defined for this bin\n");
                        }
		}
		else
		{
			int mm;
			struct s_binroute *r;
			for (mm=0;mm<m;mm++)
			{
				r = binRouteObj->getRoute(mm);
				if (r)
				{
					if((istty) && (!isDaemon))
					{
						printf("\tnode[%1hd:%s] group[%s] mailbox[%s] port[%s] status[%c] flag[0x%x] cfg[%s] initStatus[%c] echo[%c] priority[%d]\n", 
						r->siteId, r->node, r->binrouteGroup, r->mailbox, r->port, r->status, r->flag, r->cfg, r->initStatus, r->echo, (int)r->priority);
					}
					else
					{
						OTraceInfo("I-SHC-135106: \tnode[%1hd:%s] group[%s] mailbox[%s] port[%s] status[%c] flag[0x%x] cfg[%s] initStatus[%c] echo[%c] priority[%d]\n", 
						r->siteId, r->node, r->binrouteGroup, r->mailbox, r->port, r->status, r->flag, r->cfg, r->initStatus, r->echo, (int)r->priority);
					}
				}
				else
				{
					if((istty) && (!isDaemon))
                                        {
						printf("binroute entry [%d] error\n", mm);
					}
                                        else
                                        {
						OTraceInfo("I-SHC-135107: binroute entry [%d] error\n", mm);
                                        }
				}
			}
		}
	}	



	dbm_dectochar(&pkg->txn.amount, amount);
	if((istty) && (!isDaemon))
	{
		printf("\nTransaction Limit:   %s\n", amount);
		printf("            Allowed:\n");
	}
	else
	{
		OTraceInfo("I-SHC-135108: \nTransaction Limit:   %s\n", amount);
		OTraceInfo("I-SHC-135108:             Allowed:\n");
	}
	for(i = 0; thisShcApp->shc_txn_def[i].offset != -1; ++i)
	{
		if(pkg->txn.txnset & thisShcApp->shc_txn_def[i].flag)
		{
			if((istty) && (!isDaemon))
			{
				printf("\t<%20s>\n", thisShcApp->shc_txn_def[i].desc);
			}
			else
			{
				OTraceInfo("I-SHC-135109: \t<%20s>\n", thisShcApp->shc_txn_def[i].desc);
                        }
		}
	}

	/*
	 * R001835 Bin Level Configuration
	 * 2007336 R004671 Dds 26Jun00 -change for chipdata enhancement
	 */
	if((istty) && (!isDaemon))
        {
		printf("\nBin Level Configuration:\n" );
	}
	else
	{
		OTraceInfo("I-SHC-135110: \nBin Level Configuration:\n" );
        }
	for(i = 0; thisShcApp->shc_bin_cfg[i].offset != -1; ++i)
	{
		printf("[DEBUG] %-24s : flag=0x%lX\n",thisShcApp->shc_bin_cfg[i].desc,thisShcApp->shc_bin_cfg[i].flag);
		if (ShcAppBase::shc_bin_cfg[i].offset == SH_CFGIX_ENABLE_DUAL_SITE_BRIDGE)
		{
			int safflag = pkg->bin.bin_cfg & SH_CFG_ALLOW_SAF_ACROSS_SITE;
			int onlineflag = pkg->bin.bin_cfg & SH_CFG_ENABLE_DUAL_SITE_BRIDGE;
			if (safflag && onlineflag)
			{
				if((istty) && (!isDaemon))
				{
					printf( "\t<%24s -  Online & Saf>\n", thisShcApp->shc_bin_cfg[i].desc );
				}
				else
				{
					OTraceInfo("I-SHC-135111: \t<%24s -  Online & Saf>\n", thisShcApp->shc_bin_cfg[i].desc );
                                }
			}
			else if (safflag)
			{
				if((istty) && (!isDaemon))
                                {
					printf( "\t<%24s -  Saf>\n", thisShcApp->shc_bin_cfg[i].desc );
				}
				else
                                {
                                        OTraceInfo("I-SHC-135112: \t<%24s -  Saf>\n", thisShcApp->shc_bin_cfg[i].desc );
                                }
			}
			else if (onlineflag)
			{
				if((istty) && (!isDaemon))
                                {
					printf( "\t<%24s -  Online>\n", thisShcApp->shc_bin_cfg[i].desc );
				}
                                else
                                {
                                        OTraceInfo("I-SHC-135113: \t<%24s -  Online>\n", thisShcApp->shc_bin_cfg[i].desc );
                                }
			}
			else
			{
				if((istty) && (!isDaemon))
                                {
					printf( "\t<%24s -  Disabled>\n", thisShcApp->shc_bin_cfg[i].desc );
				}
                                else
                                {
                                        OTraceInfo("I-SHC-135114: \t<%24s -  Disabled>\n", thisShcApp->shc_bin_cfg[i].desc );
                                }
			}
		}			
		else if ( thisShcApp->shc_bin_cfg[i].offset == SH_CFGIX_AMEX_CSC )
		{
			char tmpbuf[128];
			tmpbuf[0] = 0;
			switch(pkg->bin.addflag & SH_ADDFLAG_CAVV_MASK)
			{
			case SH_ADDFLAG_AMEX_CSC:
				strncpy(tmpbuf, "Yes", sizeof(tmpbuf));
				break; 
			default:
				strncpy(tmpbuf, "No", sizeof(tmpbuf));
				if( pkg->bin.bin_cfg & SH_CSC_CHECK_STAND_IN_ONLY )
				{
					strncpy(tmpbuf, "stand-in only", sizeof(tmpbuf));
				}else
					strncpy(tmpbuf, "No", sizeof(tmpbuf));
				break; 
			}
			if((istty) && (!isDaemon))
            		{
				printf( "\t<%24s - %s>\n", thisShcApp->shc_bin_cfg[i].desc, tmpbuf );
			}
		        else
		        {
				OTraceInfo("I-SHC-135250: \t<%24s - %s>\n", thisShcApp->shc_bin_cfg[i].desc , tmpbuf);
		        }
		}
		else if ( thisShcApp->shc_bin_cfg[i].offset == SH_CFGIX_CAAV_CAVV_VERIFY )
		{
			char tmpbuf[128];
			tmpbuf[0] = 0;
			switch(pkg->bin.addflag & SH_ADDFLAG_CAVV_MASK)
			{
			case SH_ADDFLAG_HMAC_MAS:
				strncpy(tmpbuf, "HMAC_MAS", sizeof(tmpbuf));
				break; 
			case SH_ADDFLAG_CVC2_MAS:
				strncpy(tmpbuf, "CVC2_MAS", sizeof(tmpbuf));
				break; 
			case SH_ADDFLAG_HMAC_VIS:
				strncpy(tmpbuf, "HMAC_VIS", sizeof(tmpbuf));
				break; 
			case SH_ADDFLAG_CAVV_VIS:
				strncpy(tmpbuf, "CAVV_VIS", sizeof(tmpbuf));
				break; 
			case SH_ADDFLAG_AMEX_CSC:
				strncpy(tmpbuf, "AMEX_CSC", sizeof(tmpbuf));
				break; 
			default:
				strncpy(tmpbuf, "No", sizeof(tmpbuf));
				break; 
			}
			if((istty) && (!isDaemon))
            		{
				printf( "\t<%24s - %s>\n", thisShcApp->shc_bin_cfg[i].desc, tmpbuf );
			}
		        else
		        {
				OTraceInfo("I-SHC-135250: \t<%24s - %s>\n", thisShcApp->shc_bin_cfg[i].desc , tmpbuf);
		        }
		}
		else if ( thisShcApp->shc_bin_cfg[i].offset == SH_CFGIX_DCVV_CVC3 )
		{
			char tmpbuf[128];
			tmpbuf[0] = 0;
			switch(pkg->bin.bin_cfg & (SH_CFG_DCVV_CHECK|SH_CFG_DCVV_VERIFY|SH_CFG_DCVV_CHECK_VERIFY_STAND_IN_ONLY))
			{
			case SH_CFG_DCVV_CHECK:
				strncpy(tmpbuf, "Check", sizeof(tmpbuf));
				break; 
			case SH_CFG_DCVV_VERIFY:
				strncpy(tmpbuf, "Verify", sizeof(tmpbuf));
				break; 
			case SH_CFG_DCVV_VERIFY|SH_CFG_DCVV_CHECK:
				strncpy(tmpbuf, "Verify & Check", sizeof(tmpbuf));
				break; 
			case SH_CFG_DCVV_CHECK_VERIFY_STAND_IN_ONLY:
				strncpy(tmpbuf, "Verify & Check in stand-in only", sizeof(tmpbuf));
				break;
			default:
				strncpy(tmpbuf, "No", sizeof(tmpbuf));
				break; 
			}
			if((istty) && (!isDaemon))
            		{
				printf( "\t<%24s - %s>\n", thisShcApp->shc_bin_cfg[i].desc, tmpbuf );
			}
			else
			{
				OTraceInfo("I-SHC-135250: \t<%24s - %s>\n", thisShcApp->shc_bin_cfg[i].desc , tmpbuf);
			}
		}
                else if ( ShcAppBase::shc_bin_cfg[i].offset ==  SH_CFGIX_CAAV_CAVV_3DS_VERIFY_STAND_IN_ONLY )
                {
                        if( pkg->bin.bin_cfg & SH_CFG_CAVV_3DS_STAND_IN_ONLY )
                        {
                                if((istty) && (!isDaemon))
                                {
                                        printf( "\t<%24s -  YES>\n", thisShcApp->shc_bin_cfg[i].desc );
                                }
                                else
                                {
                                        OTraceInfo("I-SHC-135346: \t<%24s - YES>\n", thisShcApp->shc_bin_cfg[i].desc );
                                }
                        }
                }
		else if ( thisShcApp->shc_bin_cfg[i].offset == SH_CFGIX_DCVVCVC3_TYPE )
		{
			char tmpbuf[128];
			tmpbuf[0] = 0;
			if (pkg->bin.bin_cfg & SH_CFG_DCVV)
			{
				strncat(tmpbuf, " DCVV", sizeof(tmpbuf)-strlen(tmpbuf)-1);
			}
			if (pkg->bin.bin_cfg & SH_CFG_ICVV)
			{
				strncat(tmpbuf, " ICVV", sizeof(tmpbuf)-strlen(tmpbuf)-1);
			}
			if (pkg->bin.bin_cfg & SH_CFG_CVC3)
			{
				strncat(tmpbuf, " CVC3", sizeof(tmpbuf)-strlen(tmpbuf)-1);
			}
			if (pkg->bin.bin_cfg & SH_CFG_SCVC3)
			{
				strncat(tmpbuf, " SCVC3", sizeof(tmpbuf)-strlen(tmpbuf)-1);
			}
			if (!tmpbuf[0])
			{
				strncpy(tmpbuf, "No", sizeof(tmpbuf));
			}
			if((istty) && (!isDaemon))
            		{
				printf( "\t<%24s - %s>\n", thisShcApp->shc_bin_cfg[i].desc, tmpbuf );
			}
		        else
		        {
				OTraceInfo("I-SHC-135250: \t<%24s - %s>\n", thisShcApp->shc_bin_cfg[i].desc , tmpbuf);
		        }
		}
		else if ( thisShcApp->shc_bin_cfg[i].offset == SH_CFGIX_SUBSECOND_TIMEOUT )
		{
		        if (pkg->bin.addflag & SH_ADDFLAG_TIMEOUT_DECISECOND)
		        {
		               	if((istty) && (!isDaemon))
                   		{
	    	   			printf( "\t<%24s -  YES>\n", thisShcApp->shc_bin_cfg[i].desc );
		   		}
		   		else
                   		{
                        		OTraceInfo("I-SHC-135346: \t<%24s - YES>\n", thisShcApp->shc_bin_cfg[i].desc );
                   		}	
		        }
		               
	                else
	                {
				if((istty) && (!isDaemon))
                   		{
	    	   			printf( "\t<%24s -   NO>\n", thisShcApp->shc_bin_cfg[i].desc );
		   		}
		   		else
                   		{
                        		OTraceInfo("I-SHC-135346: \t<%24s - NO>\n", thisShcApp->shc_bin_cfg[i].desc );
                   		}	                
	                }
		}
	/*
        else if( thisShcApp->shc_bin_cfg[i].offset == SH_CFGIX_KPE_KEYBLOCK )
        {
              if (pkg->bin.bin_cfg & SH_CFG_KPE_KEYBLOCK)
              {
	                if((istty) && (!isDaemon))
	                    printf( "\t<%24s -  YES>\n", thisShcApp->shc_bin_cfg[i].desc );
	                else
	                  OTraceInfo("I-SHC-135349: \t<%24s - YES>\n", thisShcApp->shc_bin_cfg[i].desc );
	          }
	          else
	          {
	               if((istty) && (!isDaemon))
	                   printf( "\t<%24s -  NO>\n", thisShcApp->shc_bin_cfg[i].desc );
	               else
			            OTraceInfo("I-SHC-135349: \t<%24s - NO>\n", thisShcApp->shc_bin_cfg[i].desc );
		      }
		}
		*/
		else if ( thisShcApp->shc_bin_cfg[i].offset == SH_CFGIX_KPE_KEYBLOCK )
		{
			char tmpbuf[128];
			tmpbuf[0] = 0;
			switch(pkg->bin.bin_cfg & (SH_CFG_KPE_KEYBLOCK | SH_KB_VERSIONID_A|SH_KB_VERSIONID_B|SH_KB_VERSIONID_C|SH_KB_VERSIONID_D))
			{
			case SH_CFG_KPE_KEYBLOCK:
				strncpy(tmpbuf, "Yes-A", sizeof(tmpbuf));
				break;
			case SH_KB_VERSIONID_A:
				strncpy(tmpbuf, "Yes-A", sizeof(tmpbuf));
				break;
			case SH_KB_VERSIONID_B:
				strncpy(tmpbuf, "Yes-B", sizeof(tmpbuf));
				break;
			case SH_KB_VERSIONID_C:
				strncpy(tmpbuf, "Yes-C", sizeof(tmpbuf));
				break;
			case SH_KB_VERSIONID_D:
				strncpy(tmpbuf, "Yes-D", sizeof(tmpbuf));
				break;
			default:
				strncpy(tmpbuf, "NO", sizeof(tmpbuf));
				break;
			}
			if((istty) && (!isDaemon))
			{
				printf( "\t<%24s -  %s>\n", thisShcApp->shc_bin_cfg[i].desc, tmpbuf );
			}
			else
			{
				OTraceInfo("I-SHC-135349: \t<%24s - %s>\n", thisShcApp->shc_bin_cfg[i].desc , tmpbuf);
			}
		}
		else if(pkg->bin.bin_cfg & thisShcApp->shc_bin_cfg[i].flag)
		{
		        if( thisShcApp->shc_bin_cfg[i].offset == SH_CFGIX_FULL_ENTRY )
		        {
		               	if((istty) && (!isDaemon))
                   		{
	    	   			printf( "\t<%24s -  FULL>\n", thisShcApp->shc_bin_cfg[i].desc );
		   		}
		   		else
                   		{
                        		OTraceInfo("I-SHC-135347: \t<%24s - FULL>\n", thisShcApp->shc_bin_cfg[i].desc );
                   		}	
		        }
	                else
	                {
				if((istty) && (!isDaemon))
                   		{
	    	   			printf( "\t<%24s -   YES>\n", thisShcApp->shc_bin_cfg[i].desc );
		   		}
		   		else
                   		{
                        		OTraceInfo("I-SHC-135347: \t<%24s - YES>\n", thisShcApp->shc_bin_cfg[i].desc );
                   		}	                
	                }
		} 
		else if( thisShcApp->shc_bin_cfg[i].offset == SH_CFGIX_ENABLE_REFNUM_EVENTKEY )
		{
			if (pkg->bin.bin_cfg & SH_CFG_ENABLE_REFNUM_EVENTKEY)
			{
				if((istty) && (!isDaemon))
					printf( "\t<%24s -  YES>\n", thisShcApp->shc_bin_cfg[i].desc );
				else
					OTraceInfo("I-SHC-135349: \t<%24s - YES>\n", thisShcApp->shc_bin_cfg[i].desc );
			}
			else
			{
				if((istty) && (!isDaemon))
					printf( "\t<%24s -  NO>\n", thisShcApp->shc_bin_cfg[i].desc );
				else
					OTraceInfo("I-SHC-135349: \t<%24s - NO>\n", thisShcApp->shc_bin_cfg[i].desc );
			}
		}
		else
		{
	        	if( thisShcApp->shc_bin_cfg[i].offset == SH_CFGIX_FULL_ENTRY )
	        	{
		   		if((istty) && (!isDaemon))
                   		{
	    	   			printf( "\t<%24s - EARLY>\n", thisShcApp->shc_bin_cfg[i].desc );
		   		}
		   		else
                   		{
                        		OTraceInfo("I-SHC-135348: \t<%24s - EARLY>\n", thisShcApp->shc_bin_cfg[i].desc );
                   		}
                   	}
	        	else	        	
	        	{
	        		if((istty) && (!isDaemon))
                   		{
	           			printf( "\t<%24s -    NO>\n", thisShcApp->shc_bin_cfg[i].desc );
		   		}
                   		else
                   		{
                        		OTraceInfo("I-SHC-135115: \t<%24s -    NO>\n", thisShcApp->shc_bin_cfg[i].desc );
                   		}	
	        	}
		}
	}

	if( (pkg->bin.flags & SH_CHECKCVV) &&  (pkg->bin.bintype & SH_CHECK_CVV2) )
	{
		istsafe_strcpy(buf, sizeof(buf), "cvv, cvv2 check enabled");
	}
	else if( pkg->bin.flags & SH_CHECKCVV )
	{
		istsafe_strcpy(buf, sizeof(buf), "cvv check enabled");
	}
	else if( pkg->bin.bintype & SH_CHECK_CVV2 )
	{
		istsafe_strcpy(buf, sizeof(buf), "cvv2 check enabled");
	}
	else if ( (pkg->bin.bin_cfg & SH_CHECK_CVV_CVV2_STANDIN_ONLY) == SH_CHECK_CVV_CVV2_STANDIN_ONLY )
	{
		istsafe_strcpy(buf, sizeof(buf), "cvv, cvv2 checks enabled in stand-in only");
	}
	else if ( pkg->bin.bin_cfg & SH_CHECKCVV_STANDIN_ONLY )
	{
		istsafe_strcpy(buf, sizeof(buf), "cvv check enabled in stand-in only");
	}
	else if ( pkg->bin.bin_cfg & SH_CHECKCVV2_STANDIN_ONLY )
	{
		istsafe_strcpy(buf, sizeof(buf), "cvv2 stand-only check enabled");
	}else
	{
		istsafe_strcpy(buf, sizeof(buf), "no cvv check");
	}

	if((istty) && (!isDaemon))
	{
		printf( "\t<             CVV Flags -    %s>\n", buf );
	}
    	else
    	{
    		OTraceInfo("I-SHC-135250: \t<              CVV Flags -    %s>\n", buf );
	}
	if((istty) && (!isDaemon))
	{
		printf( "\t<Forward Capture Request -  %s>\n", pkg->bin.bin_cfg & SH_CFG_FWD_CAPTURE?"YES":"NO" );
	}
	else
	{
		OTraceInfo("I-SHC-135347: \t<Forward Capture Request -  %s>\n", pkg->bin.bin_cfg & SH_CFG_FWD_CAPTURE?"YES":"NO" );
	}	

	if( (pkg->bin.flags & SH_CHECKPIN) && (pkg->bin.flags & SH_CHECKPIN_STAND_IN) )
	{
		istsafe_strcpy(buf, sizeof(buf), "pin check enabled in both online and stand-in");
	}
	else if( (pkg->bin.flags & SH_CHECKPIN) )
	{
		istsafe_strcpy(buf, sizeof(buf), "pin check enabled");
	}
	else if( pkg->bin.flags & SH_CHECKPIN_STAND_IN )
	{
		istsafe_strcpy(buf, sizeof(buf), "pin check enabled in stand-in only");
	}
	else 
	{
		istsafe_strcpy(buf, sizeof(buf), "no pin check");
	}
	
	if((istty) && (!isDaemon))
	{
		printf( "\t<             PIN Flags -    %s>\n", buf );
	}
    	else
    	{
    		OTraceInfo("I-SHC-135250: \t<              PIN Flags -    %s>\n", buf );
	}

	switch(pkg->bin.bin_cfg & SH_CFG_ONDOT_MASK)
	{
	case SH_CFG_ONDOT_DOWN_CONT:
		istsafe_strcpy(buf, sizeof(buf), "Continue when down/timeout");
		break;
	case SH_CFG_ONDOT_DOWN_DENY:
		istsafe_strcpy(buf, sizeof(buf), "Deny when down/timeout");
		break;
	default:
		istsafe_strcpy(buf, sizeof(buf), "No");
		break;
	}

	if((istty) && (!isDaemon))
	{
		printf( "\t<             On Dot -    %s>\n", buf );
	}
    else
    {
    	OTraceInfo("I-SHC-135250: \t<              On Dot-    %s>\n", buf );
	}	

	if((istty) && (!isDaemon))
	{
		printf( "CAMMailbox:  %s\tID:  %d\n", 
             mbMailBoxName(pkg->bin.cammailboxid),pkg->bin.cammailboxid );
	/* 2007336 R004671 Dds 26Jun00 End of change*/

		printf("\nStore And Forward\n");
	}
	else
	{
		OTraceInfo("I-SHC-135116: CAMMailbox:  %s\tID:  %d\n", 
		mbMailBoxName(pkg->bin.cammailboxid),pkg->bin.cammailboxid );
		OTraceInfo("I-SHC-135117: \nStore And Forward\n");
        }
	if(pkg->saf.type & SH_SAF_POSFILE)
	{
		if((istty) && (!isDaemon))
                {
			printf("<Positive Authorization (%3d)> ", pkg->saf.posmailbox);
		}
		else
		{
			OTraceInfo("I-SHC-135118: <Positive Authorization (%3d)> ", pkg->saf.posmailbox);
                }
	}
	else if(pkg->saf.type & SH_SAF_NEGFILE)
	{
		if((istty) && (!isDaemon))
                {
			printf("<Negative Authorization> ");
		}
		else
                {
                        OTraceInfo("I-SHC-135119: <Negative Authorization> ");
                }
	}
	else
	{
		if((istty) && (!isDaemon))
                {
			printf("<Not Allowed> ");
		}
		else
                {
                        OTraceInfo("I-SHC-135120: <Not Allowed> ");
                }
	}
	
	if(pkg->saf.type & SH_SAF_NOFILE)
	{
		if((istty) && (!isDaemon))
                {
			printf("<No output file> ");
		}
		else
                {
                        OTraceInfo("I-SHC-135121: <No output file> ");
                }
	}

	/*	ad	21nov91	*/
	if(pkg->saf.type & SH_SAF_FORCE_DOWN)
	{
		if((istty) && (!isDaemon))
                {
			printf("<Markdown on timeout> ");
		}
                else
                {
                        OTraceInfo("I-SHC-135122: <Markdown on timeout> ");
                }
	}
	else if(pkg->saf.type & SH_SAF_TIMEOUT_DONOTHING)
	{
		if((istty) && (!isDaemon))
                {
			printf("<Drop message on timeout> ");
		}
                else
                {
                        OTraceInfo("I-SHC-135123: <Drop message on timeout> ");
                }
	}
	else if(pkg->saf.type & SH_SAF_TIMEOUT_RETRY)
	{
		if((istty) && (!isDaemon))
                {
			printf("<Retry message on timeout> ");
		}
                else
                {
                        OTraceInfo("I-SHC-135124: <Retry message on timeout> ");
                }
	}
	else
	{
		if((istty) && (!isDaemon))
                {
			printf("<Unknown timeout code> ");
		}
                else
                {
                        OTraceInfo("I-SHC-135125: <Unknown timeout code> ");
                }
	}
	/*	ad	21nov91 end */

	if((istty) && (!isDaemon))
	{	
		printf("<authid %d> ", pkg->auth.authserver);
	
		printf("<Refresh Time %d>\n", (int)pkg->saf.refreshtime);
	}
	else
	{
		OTraceInfo("I-SHC-135126: <authid %d> ", pkg->auth.authserver);
		OTraceInfo("I-SHC-135127: <Refresh Time %d>\n", (int)pkg->saf.refreshtime);
        }

	dbm_dectochar(&pkg->saf.amount, amount);
	if((istty) && (!isDaemon))
        {
		printf("Limit $ %s   Number %d\n", amount, pkg->saf.num);

		// R011219 Merged option command to list
		printf("\nOptions\n");
	}
	else
	{
		OTraceInfo("I-SHC-135128: Limit $ %s   Number %d\n", amount, pkg->saf.num);
		OTraceInfo("I-SHC-135129: \nOptions\n");
        }
 	for(j = 0; optlist[j].name; ++j)
	 	if(pkg->bin.flags & optlist[j].flags)
			if((istty) && (!isDaemon))
			{
		 		printf("%s ", optlist[j].name);
			}
			else
			{
				OTraceInfo("I-SHC-135130: %s ", optlist[j].name);
                        }
	if((istty) && (!isDaemon))
        {
		printf("\n");
	}
	else
	{
		OTraceInfo("\n");
        }
	
	if(istty && pkg->bin.pinparm >= 0)
	{
		if (!mflag)
		{
			if((istty) && (!isDaemon))
			{
				printf("Pin parameters (Y/N): "); fflush(stdout);
			}
			else
			{
				OTraceInfo("I-SHC-135131: Pin parameters (Y/N): "); fflush(stdout);
                        }
			if (fgets(buf,sizeof(buf),stdin) == NULL)
				return(0);
			if(buf[0] != 'Y' && buf[0] != 'y')
				return(0);
		}
		pin = thisShcApp->shcHelperObj->shc_getpinparm(pkg->bin.pinparm);
		if((istty) && (!isDaemon))
                {
			printf("Pin index: %d   Institution %s BIN: %s\n", pkg->bin.pinparm, 
														   pin->institutionid,
														   pin->bin);
			printf("bin offset: %d  pan len: %d panvaloffset: %d  panvallen: %d\n",
				pin->binoffset, pin->panlen, pin->panvaloffset, pin->panvallen);
			printf("Pan Pad: %c  Pin Pad: %c  Pin len: %d  Pin offset: %d\n",
				pin->panpad, pin->pinpad, pin->pinlen, pin->pinoffset);
			printf("Decimalization: %s  ekpv: %s\nekpv_comkey: %s\n",
				pin->dec_table, pin->ekpv, pin->ekpv_comkey);
			printf("Pin Method: %s  Pin Blk: %s\n", pin->pinmethod, pin->pinblk);
			printf("Expiry offset: %d  Branch Offset: %d  Verify Flag: %c\n",
				pin->expiryoffset, pin->branchoffset, pin->verify_pin_local);
			printf("Service code offset: %d\n", pin->scodeoffset);
			printf("CVV Offset: %d\n", pin->cvvoffset);
			printf("CVV A-KEY: %s\n", pin->cvv_a_key);
			printf("CVV B-KEY: %s\n", pin->cvv_b_key);

			/* This code is needed to support multiple pvks : Do not remove */
       			printf("pin->visa_pvk1_key_0 = %s\n", pin->visa_pvk1_key_0);
			printf("pin->visa_pvk2_key_0 = %s\n", pin->visa_pvk2_key_0);
			printf("pin->visa_pvk1_key_1 = %s\n", pin->visa_pvk1_key_1);
			printf("pin->visa_pvk2_key_1 = %s\n", pin->visa_pvk2_key_1);
			printf("pin->visa_pvk1_key_2 = %s\n", pin->visa_pvk1_key_2);
			printf("pin->visa_pvk2_key_2 = %s\n", pin->visa_pvk2_key_2);
			printf("pin->visa_pvk1_key_3 = %s\n", pin->visa_pvk1_key_3);
			printf("pin->visa_pvk2_key_3 = %s\n", pin->visa_pvk2_key_3);
			printf("pin->visa_pvk1_key_4 = %s\n", pin->visa_pvk1_key_4);
			printf("pin->visa_pvk2_key_4 = %s\n", pin->visa_pvk2_key_4);
			printf("pin->visa_pvk1_key_5 = %s\n", pin->visa_pvk1_key_5);
			printf("pin->visa_pvk2_key_5 = %s\n", pin->visa_pvk2_key_5);
			printf("pin->visa_pvk1_key_6 = %s\n", pin->visa_pvk1_key_6);
			printf("pin->visa_pvk2_key_6 = %s\n", pin->visa_pvk2_key_6);

			printf("visa pvk 1: %s\n", pin->visa_pvk1_key);
			printf("visa pvk 2: %s\n", pin->visa_pvk2_key);
			printf("visa pvki offset: %d\n", pin->pvkioffset);
			printf("visa pvv  offset: %d\n", pin->pvvoffset);
		}
		else
		{
			OTraceInfo("I-SHC-135132: Pin index: %d   Institution %s BIN: %s\n", 
				pkg->bin.pinparm, pin->institutionid, pin->bin);
			OTraceInfo("I-SHC-135132: bin offset: %d  pan len: %d panvaloffset: %d  panvallen: %d\n", 
				pin->binoffset, pin->panlen, pin->panvaloffset, pin->panvallen);
			OTraceInfo("I-SHC-135132: Pan Pad: %c  Pin Pad: %c  Pin len: %d  Pin offset: %d\n", 
				pin->panpad, pin->pinpad, pin->pinlen, pin->pinoffset);
			OTraceInfo("I-SHC-135132: Decimalization: %s  ekpv: %s\nekpv_comkey: %s\n", 
				pin->dec_table, pin->ekpv, pin->ekpv_comkey);
			OTraceInfo("I-SHC-135132: Pin Method: %s  Pin Blk: %s\n", pin->pinmethod, pin->pinblk);
			OTraceInfo("I-SHC-135132: Expiry offset: %d  Branch Offset: %d  Verify Flag: %c\n", 
				pin->expiryoffset, pin->branchoffset, pin->verify_pin_local);
			OTraceInfo("I-SHC-135132: Service code offset: %d\n", pin->scodeoffset);
			OTraceInfo("I-SHC-135132: CVV Offset: %d\n", pin->cvvoffset);
			OTraceInfo("I-SHC-135132: CVV A-KEY: %s\n", pin->cvv_a_key);
			OTraceInfo("I-SHC-135132: CVV B-KEY: %s\n", pin->cvv_b_key);
			
			/* This code is needed to support multiple pvks : Do not remove */
			OTraceInfo("I-SHC-135132: pin->visa_pvk1_key_0 = %s\n", pin->visa_pvk1_key_0);
			OTraceInfo("I-SHC-135132: pin->visa_pvk2_key_0 = %s\n", pin->visa_pvk2_key_0);
			OTraceInfo("I-SHC-135132: pin->visa_pvk1_key_1 = %s\n", pin->visa_pvk1_key_1);
			OTraceInfo("I-SHC-135132: pin->visa_pvk2_key_1 = %s\n", pin->visa_pvk2_key_1);
			OTraceInfo("I-SHC-135132: pin->visa_pvk1_key_2 = %s\n", pin->visa_pvk1_key_2);
			OTraceInfo("I-SHC-135132: pin->visa_pvk2_key_2 = %s\n", pin->visa_pvk2_key_2);
			OTraceInfo("I-SHC-135132: pin->visa_pvk1_key_3 = %s\n", pin->visa_pvk1_key_3);
			OTraceInfo("I-SHC-135132: pin->visa_pvk2_key_3 = %s\n", pin->visa_pvk2_key_3);
			OTraceInfo("I-SHC-135132: pin->visa_pvk1_key_4 = %s\n", pin->visa_pvk1_key_4);
			OTraceInfo("I-SHC-135132: pin->visa_pvk2_key_4 = %s\n", pin->visa_pvk2_key_4);
			OTraceInfo("I-SHC-135132: pin->visa_pvk1_key_5 = %s\n", pin->visa_pvk1_key_5);
			OTraceInfo("I-SHC-135132: pin->visa_pvk2_key_5 = %s\n", pin->visa_pvk2_key_5);
			OTraceInfo("I-SHC-135132: pin->visa_pvk1_key_6 = %s\n", pin->visa_pvk1_key_6);
			OTraceInfo("I-SHC-135132: pin->visa_pvk2_key_6 = %s\n", pin->visa_pvk2_key_6);

			OTraceInfo("I-SHC-135132: visa pvk 1: %s\n", pin->visa_pvk1_key);
			OTraceInfo("I-SHC-135132: visa pvk 2: %s\n", pin->visa_pvk2_key);
			OTraceInfo("I-SHC-135132: visa pvki offset: %d\n", pin->pvkioffset);
			OTraceInfo("I-SHC-135132: visa pvv  offset: %d\n", pin->pvvoffset);
                }
	}

	return(0);
}


int list_flags()
{
	int		i,j;
	struct	shcpkg *pkg;
	char	bin[100];
	char	inst[100];
	int textid;

	if (shcSharedMemoryHelperObj->attachCurrent(&shcAppid, &pShcAppHead) < 0)
	{
		if((istty) && (!isDaemon))
		{
			printf("Can't find shared-cash rule, list request aborted\n");
			return -1;
		}
		else
		{
			OTraceError("E-SHC-135133: Can't find shared-cash rule, list request aborted\n");
                        return -1;
                }
	}
		
	/* Print for all inst and bins */
	char *p= rm_getappkey(shcAppid);
	if (!p)
	{	
		if((istty) && (!isDaemon))
                {
			printf("Can't get key of shared-cash rule, abort.\n");
			return -1;
		}
		else
                {
                        OTraceError("E-SHC-135134: Can't get key of shared-cash rule, abort.\n");
                        return -1;
                }
	}
	struct shckeysmem *pTmp = NULL;
	struct shcpkg *pTmpPkg = NULL;
	if(arg_c == 1)
	{
		for(i = 0; i < pShcAppHead->keysused; ++i, p+=pShcAppHead->keysize)
		{
			pTmp = (struct shckeysmem *)p;
			textid = pTmp->textid;
			pTmpPkg =(struct shcpkg *)( rm_getapptext(shcAppid) + pShcAppHead->textsize*pTmp->textid);

			if((istty) && (!isDaemon))
                	{
				printf("%-10s %10s <%10s>: (%10s)  Flags: 0x%16lx Add-Flags:0x%04x\n",
					pTmp->institutionid,
					pTmp->userbinid, 
					pTmp->bin,
					pTmp->owner,
					pTmpPkg->bin.flags, pTmpPkg->bin.addflag);
			}
			else
			{
				OTraceInfo("I-SHC-135135: %-10s %10s <%10s>: (%10s)  Flags: 0x%08lx Add-Flags:0x%04x\n", 
					pTmp->institutionid, 
					pTmp->userbinid, 
					pTmp->bin, 
					pTmp->owner, 
					(int)pTmpPkg->bin.flags, pTmpPkg->bin.addflag);
                        }
		}
	}
	else if (arg_c == 2) /* list all bins for institution */
	{
		ICInstId_pure(inst, arg_v[1]);
		for(i = 0; i < pShcAppHead->keysused; ++i, p+=pShcAppHead->keysize)
		{
			/*	list only for inst */
			pTmp = (struct shckeysmem *)p;
			textid = pTmp->textid;
			pTmpPkg =(struct shcpkg *)( rm_getapptext(shcAppid) + pShcAppHead->textsize*pTmp->textid);
			if(strcmp(pTmp->institutionid,inst) != 0)
				continue;
			else
			{
				if((istty) && (!isDaemon))
				{
					printf("%-10s %10s <%10s>: (%10s)  Flags: 0x%08lx\n",
						pTmp->institutionid,
						pTmp->userbinid, 
						pTmp->bin,	
						pTmp->owner,
						(int)pTmpPkg->bin.flags);
				}
				else
				{
					OTraceInfo("I-SHC-135136: %-10s %10s <%10s>: (%10s)  Flags: 0x%08lx\n", 
						pTmp->institutionid, 
						pTmp->userbinid, 
						pTmp->bin, 
						pTmp->owner, 
						(int)pTmpPkg->bin.flags);
                                }
			}
		}
	}
	else
	{
		ICInstId_pure(inst, arg_v[1]);
		for(i = 2; i < arg_c; ++i)
		{
			snprintf(bin, sizeof(bin),"%s",arg_v[i]);
			shc_normalizebin(bin);
			for(j = 0; j < pShcAppHead->keysused; ++j, p+=pShcAppHead->keysize)
			{
				pTmp = (struct shckeysmem *)p;
				if( (stricmp(inst, pTmp->institutionid) == 0) &&
							(stricmp(bin, pTmp->userbinid) == 0) )
				{
					textid = pTmp->textid;
					pTmpPkg =(struct shcpkg *)( rm_getapptext(shcAppid) + pShcAppHead->textsize*pTmp->textid);
					if((istty) && (!isDaemon))
                                	{
						printf("%-10s %10s <%10s>: (%10s)  Flags: 0x%08lx\n",
							pTmp->institutionid,
							pTmp->userbinid, 
				    			pTmp->bin,	
							pTmp->owner,
							(int)pTmpPkg->bin.flags);
					}
					else
					{
						OTraceInfo("I-SHC-135137: %-10s %10s <%10s>: (%10s)  Flags: 0x%08lx\n", 
							pTmp->institutionid, 
							pTmp->userbinid, 
							pTmp->bin, 
							pTmp->owner, 
							(int)pTmpPkg->bin.flags);
                                        }
					break;
				}
			}
			if(j >= pShcAppHead->keysused)		
			{
				if((istty) && (!isDaemon))
                                {
					printf("%s: Institution %s BIN %s not valid.\n", arg_v[0], arg_v[1], arg_v[i]);
				}
				else
				{
					OTraceInfo("I-SHC-135138: %s: Institution %s BIN %s not valid.\n", arg_v[0], arg_v[1], arg_v[i]);
                                }

			}
		}
	}
	return( 0 );
}


int set()
{
	/*
	 *	set [instid | all] [up | down]
	 */
	
	int	i;
	int x;
	char	bin[100];
	char	inst[100];
	struct	shcpkg *pkg;
	char *p = NULL;
	struct shckeysmem *pTmp = NULL;

	if (shcSharedMemoryHelperObj->attachCurrent(&shcAppid, &pShcAppHead) < 0)
	{
		if((istty) && (!isDaemon))
		{
			printf("Can't find shared-cash rule, set request aborted\n");
			return -1;
		}
		else
		{
			OTraceError("E-SHC-135139: Can't find shared-cash rule, set request aborted\n");
                        return -1;
                }
	}
	/*
	 *	Get desired bin entry
	 */
	if(arg_c !=  3 && arg_c != 4)
	{
		if((istty) && (!isDaemon))
                {
			printf("Usage: %s [instid [bin]| all] [up | down]\n", arg_v[0]);
			printf("Or   : %s instprofile [id] [up | down]\n", arg_v[0]);
		}
                else
                {
                        OTraceInfo("I-SHC-135140: Usage: %s [instid [bin]| all] [up | down]\n", arg_v[0]);
			OTraceInfo("I-SHC-135140: Or   : %s instprofile [id] [up | down]\n", arg_v[0]);
                }
		return(0);
	}
   
	if(stricmp(arg_v[arg_c - 1], "up") != 0 && stricmp(arg_v[arg_c - 1], "down") != 0)
	{
		if((istty) && (!isDaemon))
                {
			printf("%s: %s Invalid command\n", arg_v[0], arg_v[arg_c - 1]);
		}
		else
                {
                        OTraceInfo("I-SHC-135141: %s: %s Invalid command\n", arg_v[0], arg_v[arg_c - 1]);
                }
		return(0);
	}

	if(	(stricmp(arg_v[1], "-node") == 0) &&
		(arg_c == 4) 
	  )
	{
		//Set a node up or down
			struct RoutingInfo routingInfo = { 0 };
			routingInfo.siteId = ofThisSite;
			if (arg_v[2][0] != '*')
				snprintf(routingInfo.destNode, sizeof(routingInfo.destNode),"%s",arg_v[2]);
			binRouteObj->markRouteDown(NULL, &routingInfo);
			binRouteObj->tidyUpBinStatus();
	}
	else if ((stricmp(arg_v[1], "instprofile") == 0) &&
			 (arg_c == 4))
	{
		if (!ofThisSite ||(ofThisSite == mbGetSiteId()))
		{
		int id = atoi(arg_v[2]);
		int status = (stricmp(arg_v[3],"up")==0)?BIN_ROUTE_STATUS_UP:BIN_ROUTE_STATUS_DOWN;
		char *p = xbuf;
		unsigned int offset = 0;
		snprintf(xbuf, sizeof(xbuf), "shccmd -site %hd -s nodeupdate %s ", mbGetSiteId(), mbcurrentnode);
		offset = strlen(xbuf);
		shcApp->instProfileObj->changeInstProfileStatus(id,status, xbuf + offset);
		if (strlen(p) > 0)
		{
			mcastHelperObj->broadcast("shccmd", 3, xbuf , strlen(xbuf), NULL, 0);
		}
		}
	}
	else if((stricmp(arg_v[1], "-blrnode") == 0) && (arg_c == 4)) //R029275
	{
		//Set a balancer node down
		struct RoutingInfo routingInfo = { 0 };
		snprintf(routingInfo.destNode, sizeof(routingInfo.destNode),"%s",arg_v[2]);
		binRouteObj->markRouteDown(NULL, &routingInfo, NULL, BIN_ROUTE_BALANCER_NODE);
		binRouteObj->tidyUpBinStatus();
	}
	else
	if (arg_c == 4)
	{
		/* set up/down for specific bin */

		snprintf(inst, sizeof(inst),"%s",arg_v[1]);
		snprintf(bin, sizeof(bin),"%s",arg_v[2]);
		if(shc_locate_bin(&pkg, inst, bin) < 0)
		{
			if((istty) && (!isDaemon))
			{
				printf("%s: Institution %s Bin %s is invalid network id\n", arg_v[0], 
							 arg_v[1], arg_v[2]);
			}
			else
			{
				OTraceInfo("I-SHC-135142: %s: Institution %s Bin %s is invalid network id\n", arg_v[0], 
							arg_v[1], arg_v[2]);
                        }
				

			return(0);
		}

		if(stricmp(arg_v[3], "up") == 0)
			set_up(pkg);
		else if(stricmp(arg_v[3], "down") == 0)
			set_down(pkg);
	}
	else if(stricmp(arg_v[1], "all") == 0)
	{
		for(i = 0; i < pShcAppHead->textused; ++i)
		{
			pkg = (struct shcpkg *)( rm_getapptext(shcAppid) + pShcAppHead->textsize*i);
			if(stricmp(arg_v[2], "up") == 0)
				set_up(pkg);
			else
				set_down(pkg);
		}
	}
	else
	{   
		/* all bins for an institution */ 
		ICInstId_pure(inst, arg_v[1]);
		p = rm_getappkey(shcAppid);
		if (!p)
		{
			if((istty) && (!isDaemon))
                        {
				printf("Can't get key of shared-cash rule, abort.\n");
			}
			else
			{
				OTraceError("E-SHC-135143: Can't get key of shared-cash rule, abort.\n");
                        }
			return -1;
		}
		for(i = 0; i < pShcAppHead->keysused; ++i )
		{
			/*	list only for inst */
			pTmp = (struct shckeysmem *)(p + pShcAppHead->keysize*i);
			if(strcmp(pTmp->institutionid,inst) == 0)
			{
				pkg =(struct shcpkg *)( rm_getapptext(shcAppid) + pShcAppHead->textsize*pTmp->textid);

				if(stricmp(arg_v[2], "up") == 0)
					set_up(pkg);
				else
					set_down(pkg);
			}
		}
	}



	return(0);
}

int set_up(NetworkInfo &netinfo, struct shcpkg *pkg)
{
	shcBin->setBinPkg(pkg);
	if(arg_v[0][0] == 'f' || arg_v[0][0] == 'F' ||
	   arg_v[0][4] == 'f' || arg_v[0][4] == 'F')
   	{
   	    shcBin->setInstUp();	
	    return(0);
	}

	memset(&tmpHeader.msg, 0, sizeof(struct shcmsg));
	memset(&tmpHeader.segment, 0, sizeof(tmpHeader.segment));
	snprintf((tmpHeader).msg.txnSrc,sizeof ((tmpHeader).msg.txnSrc), "%s",  netinfo.getTxnSrc());
	snprintf((tmpHeader).msg.txnDest, sizeof((tmpHeader).msg.txnDest), "%s", netinfo.getTxnDest());
	snprintf((tmpHeader).msg.iss_entityId, sizeof((tmpHeader).msg.iss_entityId), "%s", netinfo.getDestEntityId());
	snprintf((tmpHeader).msg.issuer, sizeof((tmpHeader).msg.issuer), "%s", pkg->bin.networkid);
	snprintf((tmpHeader).msg.acquirer, sizeof((tmpHeader).msg.acquirer), "%s", pkg->bin.networkid);
	snprintf((tmpHeader).msg.originator, sizeof((tmpHeader).msg.originator), "%s", shc_orgid);
	shcBin->setBinPkg(pkg);
	thisShcApp->shcNetworkMsgHelperObj->shc_setup(&tmpHeader, shcBin);

	return( 0 );
}

int set_down(NetworkInfo &netinfo, struct shcpkg *pkg)
{
	shcBin->setBinPkg(pkg);
	if(arg_v[0][0] == 'f' || arg_v[0][0] == 'F' ||
	   arg_v[0][4] == 'f' || arg_v[0][4] == 'F')
	{
		shcBin->setInstDown();
		return(0);
	}
	memset(&tmpHeader.msg, 0, sizeof(struct shcmsg));
	memset(&tmpHeader.segment, 0, sizeof(tmpHeader.segment));
	snprintf((tmpHeader).msg.txnSrc,sizeof ((tmpHeader).msg.txnSrc), "%s",  netinfo.getTxnSrc());
	snprintf((tmpHeader).msg.txnDest, sizeof((tmpHeader).msg.txnDest), "%s", netinfo.getTxnDest());
	snprintf((tmpHeader).msg.iss_entityId, sizeof((tmpHeader).msg.iss_entityId), "%s", netinfo.getDestEntityId());
	snprintf((tmpHeader).msg.issuer, sizeof((tmpHeader).msg.issuer), "%s", pkg->bin.networkid);
	snprintf((tmpHeader).msg.acquirer, sizeof((tmpHeader).msg.acquirer), "%s", pkg->bin.networkid);
	snprintf((tmpHeader).msg.originator, sizeof((tmpHeader).msg.originator), "%s", shc_orgid);
	thisShcApp->shcNetworkMsgHelperObj->shc_setdown(&tmpHeader, shcBin);

	return( 0 );
}


int set_up(struct shcpkg *pkg)
{
	/*
	 *	Build an 800 for this message and send it off
	 */
	
	shcBin->setBinPkg(pkg);
	if(arg_v[0][0] == 'f' || arg_v[0][0] == 'F' ||
	   arg_v[0][4] == 'f' || arg_v[0][4] == 'F')
	{
		shcBin->setInstUp();
		return(0);
	}

	memset(&tmpHeader.msg, 0, sizeof(struct shcmsg));
	memset(&tmpHeader.segment, 0, sizeof(tmpHeader.segment));
	snprintf((tmpHeader).msg.txnSrc,sizeof ((tmpHeader).msg.txnSrc), "%s", pkg->bin.institutionid);
	snprintf((tmpHeader).msg.issuer, sizeof((tmpHeader).msg.issuer), "%s", pkg->bin.networkid);
	snprintf((tmpHeader).msg.acquirer, sizeof((tmpHeader).msg.acquirer), "%s", pkg->bin.networkid);
	snprintf((tmpHeader).msg.originator, sizeof((tmpHeader).msg.originator), "%s", shc_orgid);
	thisShcApp->shcNetworkMsgHelperObj->shc_setup(&tmpHeader, shcBin);
	
	return( 0 );
}

int set_down(struct shcpkg *pkg)
{
	shcBin->setBinPkg(pkg);
	if(arg_v[0][0] == 'f' || arg_v[0][0] == 'F' ||
	   arg_v[0][4] == 'f' || arg_v[0][4] == 'F')
	{
		shcBin->setInstDown();
		return(0);
	}
	memset(&tmpHeader.msg, 0, sizeof(struct shcmsg));
	memset(&tmpHeader.segment, 0, sizeof(tmpHeader.segment));
	snprintf((tmpHeader).msg.txnSrc,sizeof ((tmpHeader).msg.txnSrc), "%s",  pkg->bin.institutionid);
	snprintf((tmpHeader).msg.issuer, sizeof((tmpHeader).msg.issuer), "%s", pkg->bin.networkid);
	snprintf((tmpHeader).msg.acquirer, sizeof((tmpHeader).msg.acquirer), "%s", pkg->bin.networkid);
	snprintf((tmpHeader).msg.originator, sizeof((tmpHeader).msg.originator), "%s", shc_orgid);
	thisShcApp->shcNetworkMsgHelperObj->shc_setdown(&tmpHeader, shcBin);

	return( 0 );
}


int update()
{
	int i;
	char	buf[100] ={0};
	int		update_all = 0;
	struct  shcpkg  *pkg;     /* R001835 */
	char    bin[30] = {0};;          /* R001835 */
	char    inst[30]= {0};;         

	if(arg_c < 3)
	{
		if((istty) && (!isDaemon))
		{
			printf("Usage: %s institution bin [bin ...]\n", arg_v[0]);
			printf("           {OR}                      \n");
			printf("Usage: %s all institution bin [bin ...]\n", arg_v[0]);
		}
		else
		{
			OTraceInfo("I-SHC-135144: Usage: %s institution bin [bin ...]\n", arg_v[0]);
			OTraceInfo("I-SHC-135144:            {OR}                      \n");
			OTraceInfo("I-SHC-135144: Usage: %s all institution bin [bin ...]\n", arg_v[0]);
                }
		return(0);
	}

	if(stricmp(arg_v[1], "all") == 0)
	{
		update_all = 1;
		i = 3;
	}
	else
		i = 2;

	for(; i < arg_c; ++i)
	{
		if(update_all)
		{
			ist_executor::execute_l("mbrulecmd", "update", "shared-cash", "all", arg_v[2], arg_v[i], (void *)0); /* R004726 */
			snprintf(inst, sizeof(inst), "%s", arg_v[2]);
		}
		else
		{
			ist_executor::execute_l("mbrulecmd", "update", "shared-cash", arg_v[1], arg_v[i], (void *)0);	/* R004726 */
			snprintf(inst, sizeof(inst), "%s", arg_v[1]);
		}

		if (dflag)
			mcastHelperObj->broadcast("shccmd", 3, buf , strlen(buf), NULL, 0);	

		/* R001835 > */
		snprintf(bin, sizeof(bin), "%s", arg_v[i]);
            						/* R008328 >> */
		/* retry 5 times with 1 sec delayed each */
		int  flagFound = -1;
		for( int j=0; j<5; j++ )	
		{
			sleep(1);
			flagFound = shc_locate_bin(&pkg, inst, bin);
			if( flagFound >= 0 )
				break;
		}
		if(flagFound < 0 )
		{
			if((istty) && (!isDaemon))
			{
				printf("%s: Institution %s Network '%s' not valid.\n", arg_v[0], inst, arg_v[i]);
								/* R008328 << */
			}
			else
			{
				OTraceInfo("I-SHC-135145: %s: Institution %s Network '%s' not valid.\n", arg_v[0], inst, arg_v[i]);
			}
		}
        /* R001835 < */
	}

	return( 0 );
}


int do_stats()
{
	return( 0 );
}

/* R012344 >> */
int GetReconcileCfg(InstBusinessDay * businessDay, int send_cutover)
{
int instRole = 0, from_acct_type = 0;

	if ( businessDay->isSwitch() || businessDay->isMAIN_INST()) //R027817
		instRole = IST_ROLE_SW;
	else
	{
		if ( businessDay->isAcquirer() ) instRole |= IST_ROLE_ACQ;
		if ( businessDay->isIssuer() ) instRole |= IST_ROLE_ISS;
	}

	/* Check Cutover and Reconcile combined configuration */
	if( businessDay->getOneCfg((int)CT_SEND_MEMBER_COMBINED_CUTOVER)=='B' && !(instRole&IST_ROLE_SW) )
		from_acct_type = T_ROLE_CUTOVER_RECON_COMBINED | instRole | IST_ROLE_COMBINED_MSG
						| IST_ROLE_ATM | IST_ROLE_POS | IST_ROLE_OTHER;
	else
	{
		if( businessDay->getOneCfg((int)CT_ATM_SEND_FORCE_MEMBER_CUTOVER) == 'B' )
			from_acct_type = T_ROLE_CUTOVER_RECON_COMBINED|IST_ROLE_ATM|instRole;
		if( businessDay->getOneCfg((int)CT_POS_SEND_FORCE_MEMBER_CUTOVER) == 'B' )
			from_acct_type |= T_ROLE_CUTOVER_RECON_COMBINED|IST_ROLE_POS|instRole;
		if( businessDay->getOneCfg((int)CT_OTHER_SEND_FORCE_MEMBER_CUTOVER) == 'B' )
			from_acct_type |= T_ROLE_CUTOVER_RECON_COMBINED|IST_ROLE_OTHER|instRole;
	}

	if (send_cutover > 0)
	{
		 if (from_acct_type != 0)
			return from_acct_type;
		else
			return (-1);
	}
	else
	{
		from_acct_type = 0;
	}

	/* Check Reconcile configuration without cutover */
	if( instRole & IST_ROLE_ACQ )
	{
		int curInstRole = instRole & ~IST_ROLE_ISS;
		if( businessDay->getOneCfg((int)CT_ATM_SEND_ACQUIRER_RECON) == 'Y' )
			from_acct_type = T_ROLE_RECON|IST_ROLE_ATM|curInstRole;
		if( businessDay->getOneCfg((int)CT_POS_SEND_ACQUIRER_RECON) == 'Y' )
			from_acct_type |= T_ROLE_RECON|IST_ROLE_POS|curInstRole;
		if( businessDay->getOneCfg((int)CT_OTHER_SEND_ACQUIRER_RECON) == 'Y' )
			from_acct_type |= T_ROLE_RECON|IST_ROLE_OTHER|curInstRole;
	
		switch( businessDay->getOneCfg((int)CT_SEND_ACQUIRER_COMBINED_RECON) )
		{
			case 'M' : from_acct_type |= IST_ROLE_COMBINED_MSG; break;
			case 'B' : from_acct_type |= IST_ROLE_COMBINED_BAL; break;
			default  : break;
		}
	}

	if( instRole & IST_ROLE_ISS )
	{
		int curInstRole = instRole & ~IST_ROLE_ACQ;
		if( businessDay->getOneCfg((int)CT_ATM_SEND_ISSUER_RECON) == 'Y' )
			from_acct_type |= T_ROLE_RECON|IST_ROLE_ATM|curInstRole;
		if( businessDay->getOneCfg((int)CT_POS_SEND_ISSUER_RECON) == 'Y' )
			from_acct_type |= T_ROLE_RECON|IST_ROLE_POS|curInstRole;
		if( businessDay->getOneCfg((int)CT_OTHER_SEND_ISSUER_RECON) == 'Y' )
			from_acct_type |= T_ROLE_RECON|IST_ROLE_OTHER|curInstRole;

		switch( businessDay->getOneCfg((int)CT_SEND_ISSUER_COMBINED_RECON) )
		{
			case 'M' : from_acct_type |= IST_ROLE_COMBINED_MSG; break;
			case 'B' : from_acct_type |= IST_ROLE_COMBINED_BAL; break;
			default :	break;
		}
	}

	return from_acct_type;
}
/* << R012344 */

/* 10002364 */
int settlement()
{
	/*	Display/process current settlement of a particular institution and entity */
	struct shcpkg	*pkg = NULL;
	date_t			settle_date;
	int				cutover_send = False;
	Mailbox 		reconMails;
	InstBusinessDay	* reconBusDay;
	int				mbidDest = -1;
	int				dateflag = DT_POS_CURRENT_BUSINESS_DAY, recondateflag = DT_POS_LAST_RECON, deviceflag = IST_ROLE_POS;
	char 			instid[64] = {0};
	char 			entityid[64] = {0};
	char 			iss_bin[16] = {0};
	int 			busday_type;
	int 			tm_resp = 60;
	int 			len_resp = 0;

	if(arg_c < 4)
	{
		if((istty) && (!isDaemon))
		{
			printf("Usage  : %s inst_id entity_id [today | YYYYMMDD] {APO} [cutover]\n", arg_v[0]);
			printf("Options:\n");
			printf("         inst_id         - institution id from business day profile\n");
			printf("         entity_id       - entity id from business day profile\n");
			printf("         {APO}           - device_type, A: ATM device, P: POS device, O: other devices\n");
			printf("         cutover         - means send cutover prior to reconcile, optional\n");
		}
		else
		{
			OTraceInfo("I-SHC-135146: Usage  : %s inst_id entity_id [today | YYYYMMDD] {APO} [cutover]\n", arg_v[0]);
			OTraceInfo("I-SHC-135146: Options:\n");
			OTraceInfo("I-SHC-135146:          inst_id         - institution id from business day profile\n");
			OTraceInfo("I-SHC-135146:          entity_id       - entity id from business day profile\n");
			OTraceInfo("I-SHC-135146:          {APO}           - device_type, A: ATM device, P: POS device, O: other devices\n");
			OTraceInfo("I-SHC-135146:          cutover         - means send cutover prior to reconcile, optional\n");
                }		

		return(0);
	}
	/* R012344 >> */
	snprintf(instid, sizeof(instid),"%s",arg_v[1]);
	snprintf(entityid, sizeof(entityid),"%s",arg_v[2]);
	shc_get_current_date();
	if(stricmp(arg_v[3], "today") == 0)
		settle_date = shc_local_currentdate();
	else
		settle_date = atol(arg_v[3]);
	
	switch ( *arg_v[4] )
	{
		case 'A':
			dateflag = DT_ATM_CURRENT_BUSINESS_DAY;
			recondateflag = DT_ATM_LAST_RECON;
			deviceflag = IST_ROLE_ATM;
			break;
		case 'O':
			dateflag = DT_OTHER_CURRENT_BUSINESS_DAY;
			recondateflag = DT_OTHER_LAST_RECON;
			deviceflag = IST_ROLE_OTHER;
			break;
		case 'P':
			dateflag = DT_POS_CURRENT_BUSINESS_DAY;
			recondateflag = DT_POS_LAST_RECON;
			deviceflag = IST_ROLE_POS;
			break;
		default:
			if((istty) && (!isDaemon))
			{
				printf("%s: Device type not support for reconcile command.\n", arg_v[0]);
			}
			else
			{
				OTraceError("E-SHC-135147: %s: Device type not support for reconcile command.\n", arg_v[0]);
                        }
			return (-1);
	}
	
	if( arg_c >= 5 && stricmp(arg_v[5], "cutover") == 0 ) cutover_send = True;

	reconBusDay = new InstBusinessDay();
	if (reconBusDay->getEntryFromMem(instid, entityid) >= 0)
	{
		long lastrecon = reconBusDay->getOneDate(recondateflag);
		if (settle_date > lastrecon)
		{
			long settingdate = reconBusDay->getOneDate(dateflag);
			if(cutover_send && settle_date < settingdate )
			{
				if((istty) && (!isDaemon))
				{
					printf("%s: Unable to initiate a cutover & reconcile older than current business day.\n", arg_v[0]);
				}
				else
				{
					OTraceError("E-SHC-135148: %s: Unable to initiate a cutover & reconcile older than current business day.\n", arg_v[0]);
                                }
				delete reconBusDay;
				return (-1);
			}

			if (settingdate >= settle_date)
			{
			ShcmsgHeader msgHeader;
			struct  shc500std *std500P;
			struct shc	xshc = {0};
			
			if (cutover_send)
				xshc.msg.msgtype = SHC_NETWORK;
			else
				xshc.msg.msgtype = SHC500_MSG_DAYEND;
			msgHeader.fromShcStruct(&xshc);

			busday_type = GetReconcileCfg(reconBusDay, cutover_send);
			if ( ((busday_type & IST_ROLE_DEVICE_MASK) & deviceflag) || 
			   ((busday_type & IST_ROLE_COMBINED_MASK) & IST_ROLE_COMBINED_BAL))
			{
			if (busday_type != 0 && busday_type != -1)
			{

				/* To Lookup Inst Profile */
				IssuerInfo issInfo;

				shc_locate_issuer_from_institution(instid, entityid, xshc.msg.msgtype, issInfo );

				if (!issInfo.foundIssuer())
				{
        			shc_locate_issuer_from_institution("SWITCH", "", SHC_NETWORK, issInfo);
        			if (!issInfo.foundIssuer())
        			{
					if((istty) && (!isDaemon))
					{
						printf("%s: Can't find issuer for Inst[%s] Entity [%s], dropped!\n", 
						arg_v[0], instid, entityid);
					}
					else
					{
						OTraceError("E-SHC-135149: %s: Can't find issuer for Inst[%s] Entity [%s], dropped!\n", 
						arg_v[0], instid, entityid);
                                        }
					xshc.msg.respcode = SHC_RC_InvalidIssuer;
        			}
        			OTraceDebug("D-SHC-135026:Use SWITCH entry to find the issuer in inst_profile\n");
				}

				if (issInfo.foundIssuer())
				{
					snprintf(iss_bin, sizeof(iss_bin), "%s", issInfo.getIssuerBin());
					if( shc_locate_bin(&pkg, iss_bin) == -1 ) 
						mbidDest = -1;
					else
						mbidDest = pkg->bin.mailbox;

					if (mbidDest < 0)
					{
						if((istty) && (!isDaemon))
						{
							printf("%s: Unable to locate issuer BIN for Inst[%s] and Entity[%s]\n", 
							arg_v[0], instid, entityid);
						}
						else
						{
							OTraceError("E-SHC-135150: %s: Unable to locate issuer BIN for Inst[%s] and Entity[%s]\n", 
							arg_v[0], instid, entityid);
                                                }
					}
					else
					{
						if (pkg->bin.timeout > 0) tm_resp = pkg->bin.timeout;

						if (cutover_send)
						{
							snprintf(msgHeader.msg.txnSrc, sizeof(msgHeader.msg.txnSrc),"%s",instid);
							snprintf(msgHeader.msg.txnDest, sizeof(msgHeader.msg.txnDest),"%s",instid);
							snprintf(msgHeader.msg.entityId, sizeof(msgHeader.msg.entityId),"%s",entityid);
							snprintf(msgHeader.msg.iss_entityId, sizeof(msgHeader.msg.iss_entityId),"%s",entityid);
							snprintf(msgHeader.msg.issuer, sizeof(msgHeader.msg.issuer), "%s", iss_bin);
							snprintf(msgHeader.msg.acquirer, sizeof(msgHeader.msg.acquirer), "%s", iss_bin);
							snprintf(tmpHeader.msg.originator, sizeof(tmpHeader.msg.originator), "%s", shc_orgid);
							msgHeader.msg.netcode = SHC_NET_CUTOVER_START;
							msgHeader.msg.cap_date = shc_adjust_date(settingdate, 1);
							mb_getUmi(tmpHeader.msg.shclog_id, sizeof(tmpHeader.msg.shclog_id));
							OTraceLog("L-SHC-135017: Created message ID[%s] m%04d/n%d\n", 
								tmpHeader.msg.shclog_id, tmpHeader.msg.msgtype, tmpHeader.msg.netcode);
			
							msgHeader.msg.from_acct = busday_type;

							shcBin->setBinPkg(pkg);
							thisShcApp->shcNetworkMsgHelperObj->shc_send_800(&msgHeader, shcBin);
						}
						else
						{
							std500P = reinterpret_cast<struct shc500std *>(&msgHeader.msg);

							std500P->flags = (busday_type&IST_ROLE_TYPE_MASK)  | (busday_type&IST_ROLE_DEVICE_MASK);
							std500P->trace = shc_gentrace();
							std500P->trandate = shc_local_currentdate();
							std500P->trantime = shc_local_currenttime();
							snprintf(msgHeader.msg.issuer, sizeof(msgHeader.msg.issuer), "%s", iss_bin);
							snprintf(msgHeader.msg.acquirer, sizeof(msgHeader.msg.acquirer), "%s", iss_bin);
							snprintf(std500P->institution_id , sizeof(std500P->institution_id),"%s",instid);
							snprintf(std500P->entityId , sizeof(std500P->entityId),"%s",entityid);
							std500P->settlement_date = settle_date;

							if((istty) && (!isDaemon))
							{
								printf("%s: Recon_flags[0x%lx] for Inst[%s] Entity [%s]\n", arg_v[0],
								(int)std500P->flags, std500P->institution_id, std500P->entityId);
							}
							else
							{
								OTraceInfo("I-SHC-135151: %s: Recon_flags[0x%lx] for Inst[%s] Entity [%s]\n", arg_v[0], 
								(int)std500P->flags, std500P->institution_id, std500P->entityId);
                                                        }
							mb_getUmi(std500P->shclog_id, sizeof(std500P->shclog_id));
							OTraceLog("L-SHC-135018: Created message ID[%s] m%04d\n", 
								std500P->shclog_id, std500P->msgtype);
    						int myid = reconMails.create_private();
    						if(myid >= 0)
							{
								reconMails.write(mbidDest, myid, (char *) &msgHeader.msg, sizeof(struct shc500std));
								shc_get_current_date();
								long start_tm = shc_local_currentdate() *1000000 + shc_local_currenttime();
								long end_tm = start_tm;
								len_resp = -1;
								while ( (end_tm - start_tm)< (tm_resp + 10))
								{
									tm_resp -= (end_tm - start_tm);
									len_resp = reconMails.read(myid, (char *) &msgHeader.msg, sizeof(struct shc500std), (tm_resp + 10) * 1000);
									shc_get_current_date();
									end_tm = shc_local_currentdate() *1000000 + shc_local_currenttime();
									if (len_resp > 0) break;
								}
								reconMails.msgdiscard();

    							reconMails.destroy(myid);
								if (len_resp > 0)
								{
    									if (std500P->respcode != 0)
									{
										if((istty) && (!isDaemon))
										{
											printf("%s: Failed on reconciliation message response: %d\n", arg_v[0], (int)std500P->respcode );
										}
										else
										{
											OTraceError("E-SHC-135152: %s: Failed on reconciliation message response: %d\n", arg_v[0], (int)std500P->respcode );
                                                                                }
									}
    							}
    							else
							{
								if((istty) && (!isDaemon))
                                                                {
    									printf("%s: reconciliation message response timeout: %ds\n", arg_v[0], tm_resp );
								}
								else
								{
									OTraceInfo("I-SHC-135153: %s: reconciliation message response timeout: %ds\n", arg_v[0], tm_resp );
                                                                }
							}
    							}
    						}
						}
					}
				}
				else
				{
					if (busday_type == -1)
					{
						if((istty) && (!isDaemon))
						{
							printf("%s: Inst[%s] and Entity[%s] not allowed to send cutover and reconcile\n", arg_v[0], instid, entityid);
						}
						else
						{
							OTraceInfo("I-SHC-135154: %s: Inst[%s] and Entity[%s] not allowed to send cutover and reconcile\n", arg_v[0], instid, entityid);
                                                }
					}
					else
					{
						if((istty) && (!isDaemon))
                                                {
							printf("%s: No reconciliation configuration for this Inst[%s] and Entity [%s]\n", arg_v[0], instid, entityid);
						}
						else
						{
							OTraceInfo("I-SHC-135155: %s: Inst[%s] and Entity[%s] not allowed to send cutover and reconcile\n", arg_v[0], instid, entityid);
                                                }
					}
				}
			}
			else
			{
				if((istty) && (!isDaemon))
				{
					printf("%s: Inst[%s] and Entity [%s] and Devicetype[%c] reconcile configuration not found!\n", arg_v[0], instid, entityid, *arg_v[4]);
				}
				else
				{
					OTraceInfo("I-SHC-135156: %s: Inst[%s] and Entity [%s] and Devicetype[%c] reconcile configuration not found!\n", arg_v[0], instid, entityid, *arg_v[4]);
                                }
			}
		}
		else
		{
			if((istty) && (!isDaemon))
			{
				printf("%s: business day of Inst: %s and Entity: %s is %08ld\n", 
				arg_v[0], instid, entityid, (int)settingdate);
			}
			else
			{
				OTraceInfo("I-SHC-135157: %s: business day of Inst: %s and Entity: %s is %08ld\n", 
				arg_v[0], instid, entityid, (int)settingdate);
                        }
		}

		}
		else
		{
			if((istty) && (!isDaemon))
                	{
				printf("%s: Last reconciled date of Inst: %s and Entity: %s is %08ld\n", 
				arg_v[0], instid, entityid, (int)lastrecon);
			}
                        else
                        {
                                OTraceInfo("I-SHC-135158: %s: Last reconciled date of Inst: %s and Entity: %s is %08ld\n", 
				arg_v[0], instid, entityid, (int)lastrecon);
                        }
		}

	}
	else
	{
		if((istty) && (!isDaemon))
                {
			printf("%s: Business day profile of Inst: %s and Entity: %s not found!\n", 
			arg_v[0], instid, entityid);
		}
		else
		{
			OTraceInfo("I-SHC-135159: %s: Business day profile of Inst: %s and Entity: %s not found!\n", 
			arg_v[0], instid, entityid);
                }
	}
	delete reconBusDay;
	/* << R012344 */
	
	return( 0 );
}

/* 10002364 */

int settlement_print( struct shc500std *msg )
{
	/*	print result */

	if((istty) && (!isDaemon))
	{
		printf("%-20s  %-10s  %-12s  %-10s  %-10s\n", 
		"Type", "Number", "Amount", "Fees/Proc", "Fees/Txn");
		printf(
		"-----------------------------------------------------------------\n");
	}
	else
	{
		OTraceInfo("I-SHC-135160: %-20s  %-10s  %-12s  %-10s  %-10s\n", "Type", "Number", "Amount", "Fees/Proc", "Fees/Txn");
		OTraceInfo("I-SHC-135160: -----------------------------------------------------------------\n");
        }

	pr_settlement("Credits", msg->num_credit, &msg->amt_credit,
	&msg->fee_cr_processing, &msg->fee_cr_transaction);

	pr_settlement("Credits/Rev", msg->num_credit_rev,
	&msg->amt_credit_rev, NULL, NULL);

	pr_settlement("Debits", msg->num_debit, &msg->amt_debit,
	&msg->fee_db_processing, &msg->fee_db_transaction);

	pr_settlement("Debits/Rev", msg->num_debit_rev,
	&msg->amt_debit_rev, NULL, NULL);

	pr_settlement("Authorizations", msg->num_auth, &msg->amt_auth, NULL, NULL);
	pr_settlement("Authorizations/Rev", msg->num_auth_rev, 
	&msg->amt_auth_rev, NULL, NULL);


	pr_settlement("Transfers", msg->num_transfer, NULL, NULL, NULL);
	pr_settlement("Transfers/Rev", msg->num_transfer_rev, NULL, NULL, NULL);

	pr_settlement("Inquiries", msg->num_inquiry, NULL, NULL, NULL);


	pr_settlement("Net Settlement", (-1), &msg->amt_netset, NULL, NULL);

	return( 0 );
}

int pr_settlement(const char *msg, int num, amount_t *amt, amount_t *pr_fee, amount_t *txn_fee)
{
	char	buf[500];

	if((istty) && (!isDaemon))
	{
		printf("%-20s  ", msg);
	}
	else
	{
		OTraceInfo("I-SHC-135161: %-20s  ", msg);
        }
	if(num < 0)
	{
		if((istty) && (!isDaemon))
		{
			printf("%10s  ", " ");
		}
		else
		{
			OTraceInfo("I-SHC-135162: %10s  ", " ");
                }
	}
	else
	{
		if((istty) && (!isDaemon))
                {
			printf("%10ld  ", (long)num);
		}
		else
                {
                        OTraceInfo("I-SHC-135163: %10ld  ", (long)num);
                }
	}

	if(NULL == amt)
	{
		if((istty) && (!isDaemon))
                {
			printf("%12s  ", " ");
		}
                else
                {
                        OTraceInfo("I-SHC-135164: %12s  ", " ");
                }
        }
	else
	{
		dbm_dectochar(amt, buf);
		if((istty) && (!isDaemon))
                {
			printf("%12s  ", buf);
		}
                else
                {
                        OTraceInfo("I-SHC-135165: %12s  ", buf);
                }
	}

	if(NULL == pr_fee)
	{
		if((istty) && (!isDaemon))
                {
			printf("%10s  ", " ");
		}
		else
                {
                        OTraceInfo("I-SHC-135166: %10s  ", " ");
                }
	}
	else
	{
		dbm_dectochar(pr_fee, buf);
		if((istty) && (!isDaemon))
                {
			printf("%10s  ", buf);
		}
		else
		{
			OTraceInfo("I-SHC-135167: %10s  ", buf);
                }
	}

	if(NULL == txn_fee)
	{
		if((istty) && (!isDaemon))
                {
			printf("%10s  ", " ");
		}
		else
                {
                        OTraceInfo("I-SHC-135168: %10s  ", " ");
                }
	}
	else
	{
		dbm_dectochar(txn_fee, buf);
		if((istty) && (!isDaemon))
                {
			printf("%10s  ", buf);
		}
		else
                {
                        OTraceInfo("I-SHC-135169: %10s  ", buf);
                }
	}

	if((istty) && (!isDaemon))
	{
		printf("\n");
	}
	else
	{
		OTraceInfo("\n");
        }

	return( 0 );
}


int echo()
{
	/*
	 *	Build an 800 for this message and send it off
	 */
	
	
	int		i;
	struct	shcpkg	*pkg;
	char	bin[30];
	char	inst[30];

	if(arg_c < 3)
	{
		if((istty) && (!isDaemon))
		{
			printf("Usage: %s instid bin...\n", arg_v[0]);
		}
		else
		{
			OTraceInfo("I-SHC-135170: Usage: %s instid bin...\n", arg_v[0]);
                }
		return(0);
	}

	snprintf(inst, sizeof(inst),"%s",arg_v[1]);
	for(i = 2; i < arg_c; ++i)
	{
		snprintf(bin, sizeof(bin),"%s",arg_v[i]);
		newlyFoundShcBinKey = NULL;	//	R019505
		if(shc_locate_bin(&pkg, inst, bin) < 0)
		{
			if((istty) && (!isDaemon))
			{
				printf("%s:  Institution '%s' Bin '%s' not valid.\n", arg_v[0], arg_v[1], arg_v[i]);
			}
			else
			{
				OTraceInfo("I-SHC-135171: %s:  Institution '%s' Bin '%s' not valid.\n", arg_v[0], arg_v[1], arg_v[i]);
                        }
			continue;
		}
		shcBin->setBinPkg(pkg);

		memset(&tmpHeader.msg, 0, sizeof(struct shcmsg));
		memset(&tmpHeader.segment, 0, sizeof(tmpHeader.segment));
		snprintf((tmpHeader).msg.txnSrc, sizeof((tmpHeader).msg.txnSrc), "%s",pkg->bin.institutionid);
		//	>>>	R019505
		if (newlyFoundShcBinKey)
			snprintf((tmpHeader).msg.issuer, sizeof((tmpHeader).msg.issuer),  "%s", newlyFoundShcBinKey->bin);
		else
			snprintf((tmpHeader).msg.issuer, sizeof((tmpHeader).msg.issuer),  "%s", pkg->bin.networkid);
		snprintf((tmpHeader).msg.acquirer, sizeof((tmpHeader).msg.acquirer),"%s",(tmpHeader).msg.issuer);
		//	<<<	R019505
		snprintf((tmpHeader).msg.originator, sizeof((tmpHeader).msg.originator), "%s", shc_orgid);
	
		struct shcpkg *pkg = NULL;
		struct InstitutionProfile *ip = NULL;
		struct RoutingInfo _routingInfo = {0};
		strcpy(_routingInfo.destNode, mbcurrentnode);
		_routingInfo.siteId = mbGetSiteId();

		int numOfRoute = binRouteObj->getRouteEntries( pkg->bin.networkid, &_routingInfo );

		if ( numOfRoute > 0 )
		{
			struct s_binroute *pBinRoute = NULL;
			for ( int j=0; j<numOfRoute; j++ )
			{
				pBinRoute = binRouteObj->getRoute(j);
				
				if ( (!pBinRoute) || (pBinRoute->node[0] && strcmp(pBinRoute->node, mbcurrentnode)!=0) )
					continue;

				i = shcApp->shcBinObj->shc_locate_bin(&pkg, pBinRoute->internalid);
				if (i < 0)
				{
					if((istty) && (!isDaemon))
					{
						printf("Can't find bin:(%s). skipped echo for it.\n", pBinRoute->internalid);
					}
					else
					{
						OTraceInfo("I-SHC-135172: Can't find bin:(%s). skipped echo for it.\n", pBinRoute->internalid);
                                        }
					continue;
				}
				
				struct RoutingInfo routingInfo = {0};
				routingInfo.siteId = pBinRoute->siteId;
				strncpy( routingInfo.destNode, pBinRoute->node,    sizeof(routingInfo.destNode)-1 );
				strncpy( routingInfo.mailbox , pBinRoute->mailbox, sizeof(routingInfo.mailbox)-1 );
				strncpy( routingInfo.srcNode , mbcurrentnode,      sizeof(routingInfo.srcNode)-1 );
				strncpy( routingInfo.port    , pBinRoute->port,    sizeof(routingInfo.port)-1 );
				strncpy( routingInfo.misc    , pBinRoute->misc,    sizeof(routingInfo.misc)-1 );
				routingInfo.flag |= (ROUTE_INFO_FLAG_USE_FOR_REQ | ROUTE_INFO_FLAG_USE_BINROUTE);

				tmpHeader.setSegmentData((char*)&routingInfo, sizeof(routingInfo),
						ElfIdMap::elf_to_id(IST_SEG_NETWORK_DATA_REQ),ROUTING_INFO); //R027876
			
				ip = shcApp->instProfileObj->locateByBinroute(pBinRoute);
				if (!ip)
				{
					if((istty) && (!isDaemon))
                                        {
						printf("Can't find inst_profile for group(%s), bin(%s), port(%s). skip echo for it.\n",
							pBinRoute->binrouteGroup, pBinRoute->internalid, pBinRoute->port);
					}
					else
                                        {
                                                OTraceInfo("I-SHC-135173: Can't find inst_profile for group(%s), bin(%s), port(%s). skip echo for it.\n", 
							pBinRoute->binrouteGroup, pBinRoute->internalid, pBinRoute->port);
                                        }
					continue;
				}

				tmpHeader.setSegmentData((char *)ip, sizeof(*ip), NETWORK_DATA_REQ_id, ISS_INST_PROFILE_ENTRY);
				tmpHeader.setSegmentData((char *)ip, sizeof(*ip), NETWORK_DATA_REQ_id, ACQ_INST_PROFILE_ENTRY);

				thisShcApp->shcNetworkMsgHelperObj->shc_echotest(&tmpHeader, shcBin);
			}
		}

	}
	
	return( 0 );
}

/* 7oct97 > */
static int keys_usage()
{
	if((istty) && (!isDaemon))
	{
		printf("USAGE: KEYS {instid keyparamid} [XCHG|RST|UPD|REQ {class}{type}{index} ...  [-i <inst_profile_id>]]\n");
		printf("        key param id in shckeys to exchange\n");
		printf("        class  A = Acquirer, I = Issuer, B = Both\n");
		printf("        type   P = PIN, M = MAC, K = KME\n");
		printf("        index  1, 2 ,3 or + \n"); /* R001835 */
		printf("	route  is binroute to use for key exchange (XCHG) only. Port is required.\n" );
		printf("	       Only a local route is selected\n");
	}
	else
	{
		OTraceInfo("I-SHC-135174: USAGE: KEYS {instid keyparamid} [XCHG|RST|UPD|REQ {class}{type}{index} ...  [-i <inst_profile_id>]]\n");
		OTraceInfo("I-SHC-135174:         key param id in shckeys to exchange\n");
		OTraceInfo("I-SHC-135174:         class  A = Acquirer, I = Issuer, B = Both\n");
		OTraceInfo("I-SHC-135174:         type   P = PIN, M = MAC, K = KME\n");
		OTraceInfo("I-SHC-135174:         index  1, 2 ,3 or + \n"); /* R001835 */
		OTraceInfo("I-SHC-135174:         route  is binroute to use for key exchange (XCHG) only. Port is required.\n" );
		OTraceInfo("I-SHC-135174:                Only a local route is selected\n");
        }
	return( 0 );
}

/*
 * R001835 Rename it keys_dump_interac
 */
static int keys_dump_interac( struct shcsecurity *secp, struct shcpkg *pkgp )
{
	struct	shckey_buf keybuf = {0};
	const char	*cp = NULL, *tp = NULL, *ip = NULL; 
	int		ret = 0;
	/* R005324 >>>> */
	int maxisslen = 16;
	int maxacqlen = 16;
	char buf[100];
	/* <<<< R005324 */

	keybuf.keyp = secp;


	/* R005324 >>>> */
  	for( tp = "PKM"; *tp; tp++ )
	{
		shcBin->setBinPkg(pkgp);
		shcBin->shckeys_GetKey(&keybuf, 'A', *tp, '1');
		
		if (*keybuf.akeylen > maxacqlen)
			maxacqlen = *keybuf.akeylen;
		
		shcBin->setBinPkg(pkgp);
		shcBin->shckeys_GetKey(&keybuf, 'I', *tp, '1');

		if (*keybuf.akeylen > maxisslen)
			maxisslen = *keybuf.akeylen;
	}
	/* <<<< R005324 */

	if((istty) && (!isDaemon))
	{
		printf(" keytypes(%c) flags(%s)\n",
			keybuf.keyp->k.keytypes, keybuf.keyp->k.flags);
	}
	else
	{
		OTraceInfo("I-SHC-135175:  keytypes(%c) flags(%s)\n", 
			keybuf.keyp->k.keytypes, keybuf.keyp->k.flags);
        }

	if(isKeyBlkDev)
	{
		if((istty) && (!isDaemon))
                {
                        printf(" KEK %-56.*s %-4s\n", keybuf.keyp->k.kek_len, keybuf.keyp->k.kek, keybuf.keyp->k.kekchk);
                }
                else
                {
                        OTraceInfo("I-SHC-135176: KEK %-56.*s %-4s\n", keybuf.keyp->k.kek_len, keybuf.keyp->k.kek, keybuf.keyp->k.kekchk);
                }
	}
	else
	{
		//	--- R031475
		if( getHostKeyLen(keybuf.keyp->k.kek_len)  == 74 )
		{
			if((istty) && (!isDaemon))
			{
				printf(" KEK %-74.*s %-4s\n", 74, keybuf.keyp->k.kek, keybuf.keyp->k.kekchk);
			}
			else
			{
				OTraceInfo("I-SHC-135176: KEK %-74.*s %-4s\n", 74, keybuf.keyp->k.kek, keybuf.keyp->k.kekchk);
                	}
		}
		else
		{
			if((istty) && (!isDaemon))
                	{
				printf(" KEK %-16.*s %-4s\n", keybuf.keyp->k.kek_len, keybuf.keyp->k.kek, keybuf.keyp->k.kekchk);     
	//	--- R031475
			}
			else
			{
				OTraceInfo("I-SHC-135177: KEK %-16.*s %-4s\n", keybuf.keyp->k.kek_len, keybuf.keyp->k.kek, keybuf.keyp->k.kekchk);
			}
		}
	}

	if((istty) && (!isDaemon))
	{
		printf(" ACQ KEK CNT %20s  ", keybuf.keyp->k.acqkekcnt);
		printf(" ISS KEK CNT %20s  \n", keybuf.keyp->k.isskekcnt);
	}
	else
	{
		OTraceInfo("I-SHC-135178: ACQ KEK CNT %20s  ", keybuf.keyp->k.acqkekcnt);
		OTraceInfo("I-SHC-135178: ISS KEK CNT %20s  \n", keybuf.keyp->k.isskekcnt);
        }

	if ((maxisslen == 16) && (maxacqlen == 16))
	{
		if((istty) && (!isDaemon))
		{
			printf("        Acquirer                        Issuer\n");
			printf("        S KEY              CHK  *       S KEY              CHK  *\n");
			printf("        -------------------------       -------------------------\n");
		}
		else
		{
			OTraceInfo("I-SHC-135179:         Acquirer                        Issuer\n");
			OTraceInfo("I-SHC-135179:         S KEY              CHK  *       S KEY              CHK  *\n");
			OTraceInfo("I-SHC-135179:         -------------------------       -------------------------\n");
                }

		for( tp = "PKM"; *tp; tp++ )
		{
		/*	for( ip = "12"; *ip; ip++ ) R005267 */
			for( ip = "123"; *ip; ip++ )
			{
				for( cp = "AI"; *cp; cp++ )
				{
					shcBin->setBinPkg(pkgp);
					shcBin->shckeys_GetKey(&keybuf, *cp, *tp, *ip);

					if( *cp == 'A' )
					{
						if((istty) && (!isDaemon))
						{
							printf(" %s %c ", keybuf.ctype, keybuf.index);
						}
						else
						{
							OTraceInfo("I-SHC-135180:  %s %c ", keybuf.ctype, keybuf.index);
                                                }
					}

					if( isxdigit(keybuf.akeyp[0]) )
					{
						strtrim(keybuf.akeyp,keybuf.akeyp);	//R030188
						if((istty) && (!isDaemon))
                                                {
							printf(" %c %-16s %-4s %c      ",
								*keybuf.astatp, keybuf.akeyp, keybuf.achkp,
								*keybuf.aidxp == keybuf.index - '0' ? '*' : ' ' );
						}
						else
						{
							OTraceInfo("I-SHC-135181: %c %-16s %-4s %c      ", 
								*keybuf.astatp, keybuf.akeyp, keybuf.achkp, 
								*keybuf.aidxp == keybuf.index - '0' ? '*' : ' ' );
                                                }
					}
					else
					{
						if((istty) && (!isDaemon))
                                                {
							printf(" . ................ ....        ");
						}
						else
						{
							OTraceInfo("I-SHC-135182:  . ................ ....        ");
                                                }
					}

				}
				if((istty) && (!isDaemon))
				{
					printf("\n");
				}
				else
				{
					OTraceInfo("\n");
				}

				for( cp = "AI"; *cp; cp++ )
				{
					shcBin->setBinPkg(pkgp);
					shcBin->shckeys_GetKey(&keybuf, *cp, *tp, *ip);

					if( isdigit(keybuf.acntp[0]) )
					{
						if((istty) && (!isDaemon))
						{
							printf("           %-20s ", keybuf.acntp);
						}
						else
						{
							OTraceInfo("I-SHC-135183:            %-20s ", keybuf.acntp);
                                                }
					}
					else
					{
/*
						printf("           .................... ");
*/
						if((istty) && (!isDaemon))
                                                {
							printf("           '%p' ", keybuf.acntp);
						}
						else
						{
                                                        OTraceInfo("I-SHC-135184:            '%p' ", keybuf.acntp);
                                                }
					}
				}
				if((istty) && (!isDaemon))
				{
					printf("\n");
				}
                                else
                                {
                                        OTraceInfo("\n");
                                }
			}
			if((istty) && (!isDaemon))
			{
				printf("\n");
			}
			else
			{
				OTraceInfo("\n");
			}
		}
	}
	else
	{
		key_dump_td (secp, pkgp, maxacqlen, 'A');
		if (!mflag)
		{
			if((istty) && (!isDaemon))
			{
	 			printf("Issuer Keys (Y/N): "); fflush(stdout);
			}
			else
                        {
				OTraceInfo("I-SHC-135185: Issuer Keys (Y/N): "); fflush(stdout);
                        }
			if (fgets(buf,sizeof(buf),stdin) == NULL)
    			return(0);
			if(buf[0] != 'Y' && buf[0] != 'y')
    			return(0);
		}
		key_dump_td (secp, pkgp, maxisslen, 'I');
	}
	return( 0 );
}


static int key_dump_td (struct shcsecurity *secp, struct shcpkg *pkgp, int maxlen, char type )
{
	struct  shckey_buf keybuf = {0};
	const char *tp = NULL, *ip = NULL; 
	int     ret = 0;

	int offset = 0 ;	// --- R031475


 	if (type == 'A')
 	{
		if((istty) && (!isDaemon))
		{
 			printf("        Acquirer\n");
		}
		else
		{
			OTraceInfo("I-SHC-135186:         Acquirer\n");
                }
	}
 	else
	{
		if((istty) && (!isDaemon))
                {
			printf("        Issuer\n");
		}
		else
                {
			OTraceInfo("I-SHC-135187:         Issuer\n");
                }
	}

	maxlen = getHostKeyLen(maxlen);	// --- R031475

	if((istty) && (!isDaemon))
	{
		printf("        S KEY%*sCHK  *\n", maxlen - 2, "");
		printf("        -------------------------");
	}
	else
	{
		OTraceInfo("I-SHC-135188:         S KEY%*sCHK  *\n", maxlen - 2, "");
		OTraceInfo("I-SHC-135188:         -------------------------");
        }
	if (maxlen == 32)
	{
		if((istty) && (!isDaemon))
		{
			printf ("----------------");
		}
		else
		{
			OTraceInfo("I-SHC-135189: ----------------");
                }
	}
	else if (maxlen == 48)
	{
		if((istty) && (!isDaemon))
                {
			printf ("--------------------------------");
		}
		else
                {
                        OTraceInfo("I-SHC-135190: --------------------------------");
                }
	}
	//	--- R031475
	else if (maxlen == 74)
	{
		if((istty) && (!isDaemon))
                {
			printf ("----------------------------------------------------------------");
		}
		else
                {
                        OTraceInfo("I-SHC-135191: ----------------------------------------------------------------");
                }
	}
	//	--- R031475
	if((istty) && (!isDaemon))
        {
		printf("\n");
	}
	else
	{
		OTraceInfo("\n");
	}
	
	for( tp = "PKM"; *tp; tp++ )
	{
		for( ip = "123"; *ip; ip++ )
		{
			//offset = getHostKeyLen(*keybuf.akeylen);	// --- R031475
			offset = maxlen;
			shcBin->setBinPkg(pkgp);
			shcBin->shckeys_GetKey(&keybuf, type, *tp, *ip);

 			if((istty) && (!isDaemon))
			{
				printf(" %s %c ", keybuf.ctype, keybuf.index);
			}
			else
			{
				OTraceInfo("I-SHC-135192:  %s %c ", keybuf.ctype, keybuf.index);
                        }

			if(( isxdigit(keybuf.akeyp[0]) ) || ((isKeyBlkDev) && (keybuf.akeyp[0] == 'S')))
			{
				strtrim(keybuf.akeyp,keybuf.akeyp);	//R030188
				if((istty) && (!isDaemon))
				{
 					printf(" %c %-*.*s%*s%-4s %c      ",
						*keybuf.astatp, offset, offset, keybuf.akeyp, 
						maxlen - (offset - 1), " ",keybuf.achkp,
                    				*keybuf.aidxp == keybuf.index - '0' ? '*' : ' ' );
				}
				else
				{
					OTraceInfo("I-SHC-135193:  %c %-*.*s%*s%-4s %c      ", 
					*keybuf.astatp, offset, offset, keybuf.akeyp, 
					maxlen - (offset - 1), " ",keybuf.achkp, 
					*keybuf.aidxp == keybuf.index - '0' ? '*' : ' ' );
                                }
			}
   			else
   			{
   				if (*keybuf.akeylen == 32)
				{
					if((istty) && (!isDaemon))
					{
						printf(" . ................................%*s....        ", maxlen - 31, "");
					}
					else
					{
						OTraceInfo("I-SHC-135194:  . ................................%*s....        ", maxlen - 31, "");
                                        }
				}
				else if(*keybuf.akeylen == 48)
				{
					if((istty) && (!isDaemon))
                                        {
						printf(" . ................................................ ....        ");
					}
					else
                                        {
						OTraceInfo("I-SHC-135195:  . ................................................ ....        ");
                                        }
				}
				else if(maxlen == 74)
				{
					if((istty) && (!isDaemon))
                                        {
						printf(" . ................................................................................................ ....        ");
					}
					else
                                        {
                                                OTraceInfo("I-SHC-135196:  . ................................................................................................ ....        ");
                                        }
				}
				else
				{
					if((istty) && (!isDaemon))
                                        {
						printf(" . ................%*s....        ", maxlen - 15, "");
					}
					else
					{
						OTraceInfo("I-SHC-135197:  . ................%*s....        ", maxlen - 15, "");
                                        }
				}
			}
			if((istty) && (!isDaemon))
			{
				printf("\n");
			}
			else
			{
				OTraceInfo("\n");
			}
			if( isdigit(keybuf.acntp[0]) )
			{
				if((istty) && (!isDaemon))
				{
					printf("           %-20s ", keybuf.acntp);
				}
				else
				{
					OTraceInfo("I-SHC-135198:            %-20s ", keybuf.acntp);
                                }
			}
			else
			{
				if((istty) && (!isDaemon))
                                {
					printf("           '%p' ", keybuf.acntp);
				}
				else
                                {
                                        OTraceInfo("I-SHC-135199:            '%p' ", keybuf.acntp);
                                }
			}
			if((istty) && (!isDaemon))
                        {
				printf("\n");
			}
			else
			{
				OTraceInfo("\n");
			}
			offset = 0;		// --- R031475
		}
		if((istty) && (!isDaemon))
		{
			printf("\n");
		}
		else
                {
                        OTraceInfo("\n");
                }
	}
	return (0);
}

int keys()
{
	struct shcpkg *pkg;
	/*struct shcsecurity *key;*/
	struct shckey_buf keybuf = {0};
	struct  shcsecurity *keyp = NULL;
	bin_t	bin;
	bin_t	inst;
	int		reset_flag = False;
	int		request_flag = False;
	int		request_flag2 = False;
	int		argix = 0;
	char 	keyindex;
	char 	*p = NULL;
	struct shcsecurity *pTmp = NULL;
	struct RoutingInfo routingInfo = { 0 };
	int tmpId = -1;
	int as2805_flag = 0;
	char issuer_flag[2];


	if (shcSharedMemoryHelperObj->attachCurrent(&shcSecurityAppid, &pShckeyAppHead) < 0)
	{
		if((istty) && (!isDaemon))
                {
			printf("Can't find security rule, no keys operation avialable\n");
		}
		else
		{
			OTraceError("E-SHC-1351200: Can't find security rule, no keys operation avialable\n");
                }
		return -1;
	}

	/* R005420 */
	if( arg_c < 3 || (arg_c == 4 && ((stricmp(arg_v[3], "UPD")!= 0) && (stricmp(arg_v[3], "UPDLOCAL") != 0))))
	{
		keys_usage();
		return( -1 );
	}

	thisShcApp->shcKeyObj->shc_keys_init();  /* R001835 */  

	/* Test configuration */
	snprintf(inst, sizeof(inst),"%s",arg_v[1]);
	snprintf(bin, sizeof(bin),"%s",arg_v[2]);
	shcApp->shcmsgHelperObj->shc_normalizebin(bin);
	
	int i;
	for ( i = arg_c - 1; i > 2; i-- )
	{
		if ( !stricmp(arg_v[i], "-i") )
		{
			if ( arg_v[i+1] )
			{
				tmpId = instProfileIdLocateByKeyParam = atoi( arg_v[i+1] );
				arg_c -= 2;
				break;
			}
		}
	}

	p = rm_getapptext(shcSecurityAppid);
	
	for(i = 0; i < pShckeyAppHead->textused; ++i, p+=pShckeyAppHead->textsize)
	{
		pTmp = (struct shcsecurity *)p;
 		if(stricmp(inst, pTmp->k.institutionid) == 0 &&
	   	stricmp(bin, pTmp->k.userbinid) == 0)
		{
			break;
		}
	}

	if (i>=pShckeyAppHead->textused)
	{
		if((istty) && (!isDaemon))
                {
			printf("%s:Can't find key (%s,%s) in shckeys\n", arg_v[0], inst, bin);
		}
		else
		{
			OTraceError("E-SHC-1351201: %s:Can't find key (%s,%s) in shckeys\n", arg_v[0], inst, bin);
                }
		return -1;
	}

	//Found the key
	NetworkInfo networkInfo;
	if(rm_isMultiVerSupported(0))
		shcApp->instProfileObj->locateNetworkInfoByKeyParamStr(pTmp->k.institutionid,
				pTmp->k.userbinid , networkInfo);
	else
		shcApp->instProfileObj->locateNetworkInfoByKeyParam(i, networkInfo);

	if (!networkInfo.foundNetworkInfo())
	{
		if (tmpId >= 0)
		{
			if((istty) && (!isDaemon))
			{
				printf("%s:Can't find inst_profile entry for key entry (%s,%s) inst_profile_id(%d)\n", arg_v[0], inst, bin, tmpId);
			}
			else
			{
				OTraceError("E-SHC-1351202: %s:Can't find inst_profile entry for key entry (%s,%s) inst_profile_id(%d)\n", arg_v[0], inst, bin, tmpId);
                        }
		}
		else
		{
			if((istty) && (!isDaemon))
                        {
				printf("%s:Can't find inst_profile entry for key entry (%s,%s)\n", arg_v[0], inst, bin);
			}
			else
                        {
                                OTraceError("E-SHC-1351203: %s:Can't find inst_profile entry for key entry (%s,%s)\n", arg_v[0], inst, bin);
                        }
		}
		return -1;
	}

	shcBin->setBinPkg((char *)networkInfo.getBin());
	
	pkg = shcBin->binPkg;
	
	if(!(shcBin->binPkg->bin.bintype & SH_USES_KEYS))
	{
		if((istty) && (!isDaemon))
                {
			printf("%s: Institution %s Bin %s has no keys.\n", 
				arg_v[0], shcBin->binPkg->bin.institutionid, shcBin->binPkg->bin.userbinid);
		}
		else
		{
			OTraceError("E-SHC-1351204: %s: Institution %s Bin %s has no keys.\n", 
				arg_v[0], shcBin->binPkg->bin.institutionid, shcBin->binPkg->bin.userbinid);
		}
		return( -1 );
	}

	if (pkg->bin.bintype & SH_KEYS_AS2805)
		as2805_flag = 1;

	tmpHeader.reset();	
	shcBin->setKey(pTmp);
	tmpHeader.issShcBin = shcBin;
	shcBin->shc_setkeypointers(&tmpHeader);

	if((istty) && (!isDaemon))
	{
		printf("Institution(%s) Bin(%s) KeysID (%s)\n", 
			shcBin->binPkg->bin.institutionid, shcBin->binPkg->bin.userbinid, 
			shcBin->key->k.userbinid);
	}
	else
	{
		OTraceInfo("I-SHC-1351205: Institution(%s) Bin(%s) KeysID (%s)\n", 
			shcBin->binPkg->bin.institutionid, shcBin->binPkg->bin.userbinid, 
			shcBin->key->k.userbinid);
        }


 	if( (arg_c > 3) && (! stricmp(arg_v[3], "UPD") || 
						! stricmp(arg_v[3], "UPDLOCAL")))
	{
		int isLocked = 0;
		if (shcSharedMemoryHelperObj->lockRule(sharedCashSecurityRuleName, &isLocked, &shcSecurityAppid) < 0)
		{
			OTraceError("E-SHC-135028:Can't get shared-cash-security locked. operation failed.\n");
			return -1;
		}
    	
		int rr = shcBin->shckeys_Dbm2Mem(tmpHeader.issShcBin->key);

		if (rr >= 0)
		{
			shcSharedMemoryHelperObj->updateCurrentVersion(sharedCashSecurityRuleName, isLocked, 
				shcSecurityAppid, (char *)&tmpHeader.issShcBin->key->k, sizeof(tmpHeader.issShcBin->key->k));
		}    	

		if( rr < 0 )
		{
			rm_appUnlockMemory(shcSecurityAppid);
			if((istty) && (!isDaemon))
			{
				printf("Command failed.");
			}
			else
			{
				OTraceInfo("I-SHC-1351206: Command failed.");
			}
		}
		else
		{
			/* if UPD then broadcast to other nodes to UPD */
			if (! stricmp(arg_v[3], "UPD"))
			{

				char cmdbuf[1024];
				snprintf(cmdbuf, sizeof(cmdbuf), "shccmd keys %s %s UPDLOCAL", 
						shcBin->key->k.institutionid, 
						shcBin->key->k.userbinid);
				mcastHelperObj->broadcast("shccmd", 3, cmdbuf , strlen(cmdbuf), NULL, 0);

			}
			if((istty) && (!isDaemon))
			{
				printf("Command successful.\n");
			}
			else
			{
				OTraceInfo("I-SHC-1351207: Command successful.\n");
			}

		}

		return( 0 );
	}


	if( arg_c < 4 )
	{
		/* R001835 */

		keys_dump_interac(tmpHeader.issShcBin->key, pkg);
		return( 0 );
	}

	if( ! stricmp(arg_v[3], "RST") )
	{
		reset_flag = True;
	}
	else if( !stricmp(arg_v[3], "REQ") && !shcBinIsInterac(pkg))
	{
		request_flag = True;
	}
	else if( !stricmp(arg_v[3], "REQ_SINGLE_LEG") && !shcBinIsInterac(pkg))
	{
		request_flag2 = True;
	}
	else if( stricmp(arg_v[3], "XCHG") )
	{
		if((istty) && (!isDaemon))
		{
			printf("!!! Invalid keyword '%s'\n", arg_v[3]);
		}
		else
		{
			OTraceError("E-SHC-1351208: !!! Invalid keyword '%s'\n", arg_v[3]);
                }
		return( -1 );
	}

	/* 
	 * Perform key exchange 
	 */
	for( argix = 4; argix < arg_c; argix++ )
	{
		if( strlen(arg_v[argix]) != 3 )
		{
			if((istty) && (!isDaemon))
			{
				printf("!!! Invalid arguments '%s'\n", arg_v[argix]);
			}
			else
			{
				OTraceError("E-SHC-1351209: !!! Invalid arguments '%s'\n", arg_v[argix]);
                        }
			return( -1 );
		}
		
		/* R001835 */
		if(!shcBinIsInterac(pkg))
		{
			if( ! strchr("AIB", arg_v[argix][0]) )
			{
				if((istty) && (!isDaemon))
				{
					printf("!!! Invalid class '%c'\n", arg_v[argix][0]);
				}
				else
				{
					OTraceError("E-SHC-1351210: !!! Invalid class '%c'\n", arg_v[argix][0]);
                                }
				return( -1 );
			}
		}
		else
		{
			if( ! strchr("AI", arg_v[argix][0]) )
			{
				if((istty) && (!isDaemon))
                                {
					printf("!!! Invalid class for Interac Bin '%c'\n", arg_v[argix][0]);
				}
				else
                                {
                                        OTraceError("E-SHC-1351211: !!! Invalid class for Interac Bin '%c'\n", arg_v[argix][0]);
                                }
				return( -1 );
			}
		}

		if( ! strchr("PMK", arg_v[argix][1]) )
		{
			if((istty) && (!isDaemon))
			{
				printf("!!! Invalid type '%c'\n", arg_v[argix][1]);
			}
			else
			{
				OTraceError("E-SHC-1351212: !!! Invalid type '%c'\n", arg_v[argix][1]);
                        }
			return( -1 );
		}

		if( ! strchr("0123+", arg_v[argix][2]) )
		{
			if((istty) && (!isDaemon))
                        {
				printf("!!! Invalid index '%c'\n", arg_v[argix][2]);
			}
			else
			{
                                OTraceError("E-SHC-1351213: !!! Invalid index '%c'\n", arg_v[argix][2]);
                        }
			return( -1 );
		}

		/*
		 * R001835
		 */
		if(!shcBinIsInterac(pkg))
		{
			/*
			 * Non-Interac Version
			 */
			/* R008060 */
			if (arg_v[argix][2] == '0' ||  (arg_v[argix][2] == '+'))
			{
				/* Current key */
				keyp = pTmp;
				if (arg_v[argix][1] == SH_KEYTYPE_PIN)
				{
					if (!request_flag && !request_flag2)
					{
						if (arg_v[argix][0] == SH_KEYTYPE_PIN_ACQ) /* R010153 */
							keyindex = '0' + keyp->k.isspinidx;
						else
							keyindex = '0' + keyp->k.acqpinidx;
					}
					else
					{
						if (arg_v[argix][0] == SH_KEYTYPE_PIN_ACQ)
							keyindex = '0' + keyp->k.acqpinidx;
						else
							keyindex = '0' + keyp->k.isspinidx;
					}

				}
				else
				{
					if (!request_flag && !request_flag2)
					{
						if (arg_v[argix][0] == SH_KEYTYPE_PIN_ACQ) /* R010153 */
							keyindex = '0' + keyp->k.issmacidx;
						else
							keyindex = '0' + keyp->k.acqmacidx;
					}
					else
					{
						if (arg_v[argix][0] == SH_KEYTYPE_PIN_ACQ) 
							keyindex = '0' + keyp->k.acqmacidx;
						else
							keyindex = '0' + keyp->k.issmacidx;
					}

				}
				if (arg_v[argix][2] == '+')
				{
					/* Next Key */
					thisShcApp->shcKeyObj->shckeys_getnext_index(pkg->bin.institutionid, &keyindex);
				}
			}
			else
				keyindex = arg_v[argix][2];

			if( reset_flag )
			{
				keybuf.keyp = tmpHeader.issShcBin->key;
				keybuf.key_class = arg_v[argix][0];
				keybuf.type = arg_v[argix][1];
				keybuf.index = keyindex;
				shcBin->shc_keys_set_pointers(&keybuf);
				thisShcApp->shcKeyObj->shc_keys_set_status_as2805(&keybuf, SH_KEYSTAT_INACTIVE, as2805_flag);
			}
			else
			{
				
				(tmpHeader).msg.msgtype = SHC_NETWORK;
				(tmpHeader).msg.trace    = -1;
				snprintf((tmpHeader).msg.txnSrc, sizeof((tmpHeader).msg.txnSrc), "%s", pkg->bin.institutionid);
				//	>>>	R019505
				snprintf((tmpHeader).msg.issuer, sizeof((tmpHeader).msg.issuer), "%s", pkg->bin.networkid);
				snprintf((tmpHeader).msg.acquirer, sizeof((tmpHeader).msg.acquirer),"%s",(tmpHeader).msg.issuer);
				//	<<<	R019505
				snprintf((tmpHeader).msg.originator, sizeof((tmpHeader).msg.originator), "%s", shc_orgid);
				if (request_flag)
				{
					(tmpHeader).msg.netcode = SHC_NET_KEY_VALIDATION;
					memset(issuer_flag,'\0',sizeof(issuer_flag));
					if (arg_v[argix][0] == SH_KEYTYPE_PIN_ISS)
						istsafe_strcpy(issuer_flag,sizeof(issuer_flag),"Y");
					tmpHeader.setSegmentData((char *)&issuer_flag,sizeof(issuer_flag), NETWORK_DATA_REQ_id, SHCIMF_NETWORK_REQ_FOR_ISSUER);
				}
				else if (request_flag2)
					(tmpHeader).msg.netcode = SHC_NET_KEYS_REQ_SINGLE_LEG;
				else
					(tmpHeader).msg.netcode = SHC_NET_KEYS_START;
				(tmpHeader).msg.format_code[0]=arg_v[argix][0];
				(tmpHeader).msg.format_code[1]=arg_v[argix][1];
				/* R005420 >>>>> */
				if (arg_v[argix][1] == 'P')
				{
					(tmpHeader).msg.pin_index=keyindex;
				}
				else
				{
					(tmpHeader).msg.mac_index=keyindex;
				}
				
				mb_getUmi(tmpHeader.msg.shclog_id, sizeof(tmpHeader.msg.shclog_id));
				tmpHeader.setSegmentData((char *)networkInfo.getInstProfileEntry(), sizeof(struct InstitutionProfile),
					NETWORK_DATA_REQ_id, ISS_INST_PROFILE_ENTRY);
				tmpHeader.setSegmentData((char *)networkInfo.getInstProfileEntry(), sizeof(struct InstitutionProfile),
					NETWORK_DATA_REQ_id, ACQ_INST_PROFILE_ENTRY);
				OTraceLog("L-SHC-135019: Created message ID[%s] m%04d/n%d\n", 
				tmpHeader.msg.shclog_id, tmpHeader.msg.msgtype, tmpHeader.msg.netcode);

				/* <<<<<< R005420 */
				tmpHeader.truelength();
				thisShcApp->shcNetworkMsgHelperObj->shc_send_800(&tmpHeader, shcBin);
			}
		}
		else
		{
			/*
			 * Interac Version
			 */
			if( reset_flag )
			{
				if( shcBin->shckeys_GetKey(&keybuf, arg_v[argix][0],
					arg_v[argix][1], arg_v[argix][2]) < 0 )
				{
					if((istty) && (!isDaemon))
					{
						printf("Command failed.\n");
					}
					else
					{
						OTraceError("E-SHC-135214: Command failed.\n");
                                        }
					return( -1 );
				}
				shcBin->shckeys_SetStatus(&keybuf, SH_KEYSTAT_INACTIVE);
			}
			else
			{
				thisShcApp->shcKeyTxnHelperObj->shckeys_ChangeKey(shcBin, arg_v[argix][0], arg_v[argix][1],
					arg_v[argix][2], NULL, (InstitutionProfile *)networkInfo.getInstProfileEntry());
			}
		}
	}

	if((istty) && (!isDaemon))
	{	
		printf("Command successful.\n");
	}
	else
	{
		OTraceInfo("I-SHC-135215: Command successful.\n");
        }

	return( 0 );
}
/* < 7oct97 */


/*	-------------- Essa:	15Feb93 ----------------- */

static int inst_prof_send_network(int NetCode, char *txnSrc, char *txnDest, char *iss_entityId)
{
	InstProfileList ipList;
	InstProfileList groupList;
	struct	shcpkg	*pkg;


	if (NetCode == SHC_NET_SIGNON_START || NetCode == SHC_NET_SIGNOFF_START)
	{
		if (thisShcApp->instProfileObj->getInstProfileList (txnSrc, txnDest, iss_entityId, ipList, groupList) < 0)
		{
			if((istty) && (!isDaemon))
			{
				printf("TxnSrc: %s TxnDest: %s  in send command is not recognized\n", 
					arg_v[3], arg_v[5]);
			}
			else
			{
				OTraceInfo("I-SHC-135216: TxnSrc: %s TxnDest: %s  in send command is not recognized\n", 
					arg_v[3], arg_v[5]);
                        }
			return(0);
		}
	}
	else
	{
		if (thisShcApp->instProfileObj->getInstProfileList (txnSrc, txnDest, iss_entityId, ipList) < 0)
		{
			if((istty) && (!isDaemon))
                        {
				printf("TxnSrc: %s TxnDest: %s  in send command is not recognized\n", 
					arg_v[3], arg_v[5]);
			}
			else
                        {
                                OTraceInfo("I-SHC-135217: TxnSrc: %s TxnDest: %s  in send command is not recognized\n", 
					arg_v[3], arg_v[5]);
                        }
			return(0);
		}
	}

    /* Got to loop here and send 800 for each BIN */ 

	for (int x =0; x < ipList.size(); x++)
	{
		newlyFoundShcBinKey = NULL;	//	R019505
		if(shc_locate_bin(&pkg, (char *)ipList[x].getBin()) < 0)
		{
			if((istty) && (!isDaemon))
                        {
				printf("Internal BIN : %s  in send command is not recognized\n", 
					(char *)ipList[x].getBin());
			}
			else
			{
				OTraceInfo("I-SHC-135218: Internal BIN : %s  in send command is not recognized\n", 
					(char *)ipList[x].getBin());
                        }
			continue;
		}

		memset(&tmpHeader.msg, 0, sizeof(struct shcmsg));
		memset(&tmpHeader.segment, 0, sizeof(tmpHeader.segment));
		//mb_getUmi((tmpHeader).msg.shclog_id, sizeof((tmpHeader).msg.shclog_id));	//	R018276
		snprintf((tmpHeader).msg.txnSrc, sizeof((tmpHeader).msg.txnSrc), "%s", ipList[x].getTxnSrc());
		snprintf((tmpHeader).msg.txnDest, sizeof((tmpHeader).msg.txnDest), "%s", ipList[x].getTxnDest());
		snprintf((tmpHeader).msg.iss_entityId, sizeof((tmpHeader).msg.iss_entityId), "%s", ipList[x].getDestEntityId());
		tmpHeader.setSegmentData((char *)ipList[x].getInstProfileEntry(), sizeof(InstitutionProfile), NETWORK_DATA_REQ_id, ISS_INST_PROFILE_ENTRY);
		tmpHeader.setSegmentData((char *)ipList[x].getInstProfileEntry(), sizeof(InstitutionProfile), NETWORK_DATA_REQ_id, ACQ_INST_PROFILE_ENTRY);

		//	>>>	R019505
		if (newlyFoundShcBinKey)
			snprintf((tmpHeader).msg.issuer, sizeof((tmpHeader).msg.issuer), "%s",   newlyFoundShcBinKey->bin);
		else
			snprintf((tmpHeader).msg.issuer, sizeof((tmpHeader).msg.issuer), "%s", pkg->bin.networkid);
		//	<<<	R019505
		snprintf((tmpHeader).msg.acquirer, sizeof((tmpHeader).msg.acquirer), "%s",pkg->bin.networkid);
		snprintf((tmpHeader).msg.originator, sizeof((tmpHeader).msg.originator), "%s", shc_orgid);
		(tmpHeader).msg.netcode = NetCode;
		(tmpHeader).msg.msgtype = SHC_NETWORK;
		(tmpHeader).msg.format_code[0]='B';
		(tmpHeader).msg.format_code[1]='P';
		(tmpHeader).msg.pin_index='1';
		shcBin->setBinPkg(pkg);
		mb_getUmi(tmpHeader.msg.shclog_id, sizeof(tmpHeader.msg.shclog_id));
		OTraceLog("L-SHC-135020: Created message ID[%s] m%04d/n%d\n", 
			tmpHeader.msg.shclog_id, tmpHeader.msg.msgtype, tmpHeader.msg.netcode);
		thisShcApp->shcNetworkMsgHelperObj->shc_send_800(&tmpHeader, shcBin);
	}

	if (NetCode == SHC_NET_SIGNON_START || NetCode == SHC_NET_SIGNOFF_START)
	{   
		newlyFoundShcBinKey = NULL;	//	R019505
		for (int x =0; x < groupList.size(); x++)
		{
			if(shc_locate_bin(&pkg, (char *)groupList[x].getBin()) < 0)
			{
				if((istty) && (!isDaemon))
				{
					printf("Internal BIN : %s  in send command is not recognized\n", 
						(char *)groupList[x].getBin());
				}
				else
				{
					OTraceInfo("I-SHC-135219: Internal BIN : %s  in send command is not recognized\n", 
						(char *)groupList[x].getBin());
                                }
				continue;
			}
			memset(&tmpHeader.msg, 0, sizeof(struct shcmsg));
			memset(&tmpHeader.segment, 0, sizeof(tmpHeader.segment));
			//mb_getUmi((tmpHeader).msg.shclog_id, sizeof((tmpHeader).msg.shclog_id));	//	R018276
			snprintf((tmpHeader).msg.txnSrc, sizeof((tmpHeader).msg.txnSrc), "%s", groupList[x].getTxnSrc());
			snprintf((tmpHeader).msg.txnDest, sizeof((tmpHeader).msg.txnDest), "%s", groupList[x].getTxnDest());
			snprintf((tmpHeader).msg.iss_entityId, sizeof((tmpHeader).msg.iss_entityId), "%s", groupList[x].getDestEntityId());
			tmpHeader.setSegmentData((char *)groupList[x].getInstProfileEntry(), sizeof(InstitutionProfile), NETWORK_DATA_REQ_id, ISS_INST_PROFILE_ENTRY);
			tmpHeader.setSegmentData((char *)groupList[x].getInstProfileEntry(), sizeof(InstitutionProfile), NETWORK_DATA_REQ_id, ACQ_INST_PROFILE_ENTRY);
			//	>>>	R019505
			if (newlyFoundShcBinKey)
				snprintf((tmpHeader).msg.issuer,  sizeof((tmpHeader).msg.issuer), "%s", newlyFoundShcBinKey->bin);
			else
				snprintf((tmpHeader).msg.issuer, sizeof((tmpHeader).msg.issuer), "%s", pkg->bin.networkid);
			//	<<<	R019505
			snprintf((tmpHeader).msg.acquirer, sizeof((tmpHeader).msg.acquirer), "%s", pkg->bin.networkid);
			snprintf((tmpHeader).msg.originator, sizeof((tmpHeader).msg.originator), "%s", shc_orgid);
			if (NetCode == SHC_NET_SIGNON_START)
			{
				(tmpHeader).msg.netcode = SHC_NET_GROUPSIGNON_START;
			}
			else
			{
				(tmpHeader).msg.netcode = SHC_NET_GROUPSIGNOFF_START;
			}
			(tmpHeader).msg.msgtype = SHC_NETWORK;
			(tmpHeader).msg.format_code[0]='B';
			(tmpHeader).msg.format_code[1]='P';
			(tmpHeader).msg.pin_index='1';
			shcBin->setBinPkg(pkg);
			mb_getUmi(tmpHeader.msg.shclog_id, sizeof(tmpHeader.msg.shclog_id));
			OTraceLog("L-SHC-135021: Created message ID[%s] m%04d/n%d\n", 
				tmpHeader.msg.shclog_id, tmpHeader.msg.msgtype, tmpHeader.msg.netcode);
			thisShcApp->shcNetworkMsgHelperObj->shc_send_800(&tmpHeader, shcBin);
		}
	}

	return (0);
}

int send_network()
{
	int		NetCode, i;
	char	Network_Bin[11] = {0};
	char	InstId[11] = {0};
	char	txnSrc[11] = {0};
	char	txnDest[11] = {0};
	char    iss_entityId[31]= {0};
	struct	shcpkg	*pkg;
	struct RoutingInfo routingInfo = { 0 };
 
	txnSrc[0] = '\0';
	txnDest[0] = '\0';
	iss_entityId[0] = '\0';

	
	if(arg_c < 4)
	{
		if((istty) && (!isDaemon))
		{
			//	>>>	R020635
			printf("Use 'send netcode to instid bin [ for instid ] [with <network data>]' OR ...\n");
			printf("Use 'send netcode from TxnSrc to TxnDest [-eEntityId] [with <network data>]' OR ...\n");
			printf("Use 'send netcode for TxnSrc [with <network data>]' OR ...\n");
			printf("Use 'send netcode to TxnDest [-eEntityId] [with <network data>]'... OR instead of netcode:\n\n");
			printf("%s", NetcodeHelp);
			printf("network data:	This is an optional string that will be saved in ADD_NET_INFO segment\n");
			printf("		in 800 messages. e.g. send netcode to 123 with MAST123\n");
			//	<<<	R020635
			//	>>>	R025411
			printf("		GSI usage: 'GSI:<5 digit GSI>' \n");
			printf("		'e.g. send netcode to instid bin [ for instid ] with GSI:<5 digit GSI>' \n");
			//	<<<	R025411
		}
		else
		{
			OTraceInfo("I-SHC-135220: Use 'send netcode to instid bin [ for instid ] [with <network data>]' OR ...\n");
			OTraceInfo("I-SHC-135220: Use 'send netcode from TxnSrc to TxnDest [-eEntityId] [with <network data>]' OR ...\n");
			OTraceInfo("I-SHC-135220: Use 'send netcode for TxnSrc [with <network data>]' OR ...\n");
			OTraceInfo("I-SHC-135220: Use 'send netcode to TxnDest [-eEntityId] [with <network data>]'... OR instead of netcode:\n\n");
			OTraceInfo("I-SHC-135220: %s", NetcodeHelp);
			OTraceInfo("I-SHC-135220: network data:   This is an optional string that will be saved in ADD_NET_INFO segment\n");
			OTraceInfo("I-SHC-135220:                 in 800 messages. e.g. send netcode to 123 with MAST123\n");
			OTraceInfo("I-SHC-135220:                 GSI usage: 'GSI:<5 digit GSI>' \n");
			OTraceInfo("I-SHC-135220:                 'e.g. send netcode to instid bin [ for instid ] with GSI:<5 digit GSI>' \n");
		}
		return(0);
	}

	//	>>>	R020635
	tmpHeader.reset();
	if(strcmp(arg_v[arg_c-2], "with")==0)
	{
		tmpHeader.setSegmentData(arg_v[arg_c-1],strlen(arg_v[arg_c-1])+1, 
					ElfIdMap::elf_to_id(IST_SEG_NETWORK_DATA_REQ), ADD_NET_INFO); //R027876
		arg_c -= 2;
	}
	//	<<<	R020635

	if( is_digit(arg_v[1], strlen(arg_v[1]) ) )
	{
		NetCode = atoi(arg_v[1]);
		if( NetCode == SHC_NET_KEYS || NetCode == SHC_NET_KEYS_START )
		{
			if((istty) && (!isDaemon))
			{
				printf("!!! Use 'keys' option to send this command.\n");
			}
			else
			{
				OTraceInfo("I-SHC-135221: !!! Use 'keys' option to send this command.\n");
                        }
			return( 0 );
		}
	}
	else
	{
		/* 
		 *	26jun94 	: a little more wordy.
		 */

		 for( i = 0; netcode[i].flags > 0 ; i++)
		 {
			if( stricmp( arg_v[1], netcode[i].name) == 0)
			{
				if((istty) && (!isDaemon))
				{
					printf("I: Performing '%s' with IST val '%ld' \n",
						netcode[i].name, netcode[i].flags);
				}
				else
				{
					OTraceInfo("I-SHC-135222: I: Performing '%s' with IST val '%ld' \n", 
						netcode[i].name, netcode[i].flags);
                                }
				break;
			}
		 }

		 if( netcode[i].flags < 0)
		 {
			if((istty) && (!isDaemon))
			{
				printf("%s", NetcodeHelp);
			}
			else
			{
				OTraceInfo("I-SHC-135223: %s", NetcodeHelp);
                        }
			return(-1);
		 }

		NetCode = netcode[i].flags;
		
	}

	
    if (strcmp(arg_v[2], "to") == 0 && ((arg_c == 5)||(arg_c == 7)) && arg_v[4][1] != 'e')
	{
		if(strlen(arg_v[3]) > 10)
		{
			if((istty) && (!isDaemon))
                        {
				printf("Institution has too many digits.\n");
			}
			else
			{
				OTraceError("E-SHC-135224: Institution has too many digits.\n");
                        }
			return(-1);
		}


		if(strlen(arg_v[4]) > 10)
		{
			if((istty) && (!isDaemon))
                        {
				printf("Network BIN has too many digits.\n");
			}
			else
			{
				OTraceError("E-SHC-135225: Network BIN has too many digits.\n");
                        }
			return(-1);
		}

		snprintf(InstId, sizeof(InstId), "%s", arg_v[3]);
		snprintf(Network_Bin, sizeof(Network_Bin), "%s", arg_v[4]);
		newlyFoundShcBinKey = NULL;	//	R019505

		if(shc_locate_bin(&pkg, InstId, Network_Bin) < 0)
		{
			if((istty) && (!isDaemon))
                        {
				printf("Institution: %s Networkid Bin: %s  in send command is not recognized\n", 
					arg_v[3], arg_v[4]);
			}
			else
			{
				OTraceInfo("I-SHC-135226: Institution: %s Networkid Bin: %s  in send command is not recognized\n", 
					arg_v[3], arg_v[4]);
                        }
			return(0);
		}
		//mb_getUmi((tmpHeader).msg.shclog_id, sizeof((tmpHeader).msg.shclog_id));	//	R018276
		(tmpHeader).msg.txnSrc[0] = '\0';
		if ((arg_c == 7) && (strcmp(arg_v[5],"for")==0))
			snprintf((tmpHeader).msg.txnSrc, sizeof((tmpHeader).msg.txnSrc),"%s",arg_v[6]);

		InstProfileList ipList;
		if (thisShcApp->instProfileObj->getInstProfileList ((tmpHeader).msg.txnSrc, NULL, iss_entityId, ipList, newlyFoundShcBinKey->bin) <= 0)
		{
			if((istty) && (!isDaemon))
                        {
				printf("TxnSrc: (%s) Bin(%s,%s)in send command is not recognized in inst_profile\n", 
				(tmpHeader).msg.txnSrc,InstId, Network_Bin);
			}
			else
			{
				OTraceInfo("I-SHC-135227: TxnSrc: (%s) Bin(%s,%s)in send command is not recognized in inst_profile\n", 
				(tmpHeader).msg.txnSrc,InstId, Network_Bin);
                        }
			return(0);
		}
		if (!(tmpHeader).msg.txnSrc[0])
			strcpy((tmpHeader).msg.txnSrc, ipList[0].getTxnSrc());
		if (!(tmpHeader).msg.txnSrc[0])
			strcpy((tmpHeader).msg.txnDest, ipList[0].getTxnDest());
		if (!(tmpHeader).msg.txnDest[0])
			snprintf((tmpHeader).msg.txnSrc, sizeof((tmpHeader).msg.txnSrc),"%s",pkg->bin.institutionid);
		snprintf((tmpHeader).msg.txnDest, sizeof((tmpHeader).msg.txnDest),"%s",pkg->bin.institutionid);
		//	>>>	R019505

		strcpy((tmpHeader).msg.iss_entityId, ipList[0].getInstProfileEntry()->m_iss_entityId);
		if (newlyFoundShcBinKey)
			snprintf((tmpHeader).msg.issuer,sizeof((tmpHeader).msg.issuer), "%s",  newlyFoundShcBinKey->bin);
		else
			snprintf((tmpHeader).msg.issuer,sizeof((tmpHeader).msg.issuer), "%s",  pkg->bin.networkid);
		snprintf((tmpHeader).msg.acquirer, sizeof((tmpHeader).msg.acquirer),"%s",(tmpHeader).msg.issuer);
		//	<<<	R019505
		snprintf((tmpHeader).msg.originator, sizeof((tmpHeader).msg.originator), "%s", shc_orgid);
		(tmpHeader).msg.netcode = NetCode;
		(tmpHeader).msg.msgtype = SHC_NETWORK;
		(tmpHeader).msg.format_code[0]='B';
		(tmpHeader).msg.format_code[1]='P';
		(tmpHeader).msg.pin_index=get_pin_index( InstId, Network_Bin)+'0';
		if ((tmpHeader).msg.pin_index - '0' <=0)
			(tmpHeader).msg.pin_index='1';
		strcpy(routingInfo.destNode, mbcurrentnode);
		routingInfo.siteId = mbGetSiteId();


int n=binRouteObj->getRouteEntries(tmpHeader.msg.issuer, &routingInfo);
struct s_binroute *br;
for(n--;n>=0;n--)
{
br = binRouteObj->getRoute(n);
if (br)
{
int ii;
binRouteObj->useRoute(br, &routingInfo, NULL);
tmpHeader.setSegmentData((char*)&routingInfo, sizeof(routingInfo),
NETWORK_DATA_REQ_id, ROUTING_INFO);
if (br->inst_profile_id > 0)
{
ii = shcApp->instProfileObj->locateById(br->inst_profile_id);
if (ii>=0)
{
tmpHeader.setSegmentData((char *)shcApp->instProfileObj->chooseEntry(),
sizeof(struct InstitutionProfile), NETWORK_DATA_REQ_id, ISS_INST_PROFILE_ENTRY);
tmpHeader.setSegmentData((char *)shcApp->instProfileObj->chooseEntry(),
sizeof(struct InstitutionProfile), NETWORK_DATA_REQ_id, ACQ_INST_PROFILE_ENTRY);
}
else
OTraceInfo("I-SHC-125023:Can't find inst_profile id[%d]\n", br->inst_profile_id);
}
else
OTraceInfo("I-SHC-125024:No inst_profile specified in this binroute\n");
break;
}
else
{
	if((istty) && (!isDaemon))
	{
		printf("Have a problem on one route, ignore this route\n");
	}
	else
	{
		OTraceInfo("I-SHC-135228: Have a problem on one route, ignore this route\n");
        }
}
}

		mb_getUmi(tmpHeader.msg.shclog_id, sizeof(tmpHeader.msg.shclog_id));
		OTraceLog("L-SHC-135022: Created message ID[%s] m%04d/n%d\n", 
			tmpHeader.msg.shclog_id, tmpHeader.msg.msgtype, tmpHeader.msg.netcode);

		shcBin->setBinPkg(pkg);
		tmpHeader.truelength();
		thisShcApp->shcNetworkMsgHelperObj->shc_send_800(&tmpHeader, shcBin); 
    	}
	else if (strcmp(arg_v[2], "from") == 0 && strcmp(arg_v[4], "to") == 0)
	{
		if(strlen(arg_v[3]) > 10)
		{
			if((istty) && (!isDaemon))
			{
				printf("Source Institution has too many digits.\n");
			}
			else
			{
				OTraceError("E-SHC-135229: Source Institution has too many digits.\n");
                        }
			return(-1);
		}

		if(strlen(arg_v[5]) > 10)
		{
			if((istty) && (!isDaemon))
                        {
				printf("Txn Destination has too many digits.\n");
			}
			else
			{
				OTraceError("E-SHC-135230: Txn Destination has too many digits.\n");
                        }
			return(-1);
		}
		snprintf(txnSrc, sizeof(txnSrc),"%s", arg_v[3]);
		snprintf(txnDest,sizeof(txnDest), "%s", arg_v[5]);

		if (arg_c == 7)
		{
			if (arg_v[6][0] == '-' && arg_v[6][1] == 'e')
			{
				snprintf(iss_entityId, sizeof(iss_entityId),"%s", &arg_v[6][2]);
				inst_prof_send_network(NetCode, txnSrc, txnDest, iss_entityId);
			}
			else
			{
				if((istty) && (!isDaemon))
				{
					printf("Invalid Entity ID.\n");
				}
				else
				{
					OTraceError("E-SHC-135231: Invalid Entity ID.\n");
                                }
				return(-1);
			}
		}
		else
		{
			inst_prof_send_network(NetCode, txnSrc, txnDest, NULL);
		}
	}
	else if (strcmp(arg_v[2], "for") == 0)
	{
		if(strlen(arg_v[3]) > 10)
		{
			if((istty) && (!isDaemon))
			{
				printf("Source Institution has too many digits.\n");
			}
			else
			{
				OTraceError("E-SHC-135232: Source Institution has too many digits.\n");
                        }
			return(-1);
		}

		snprintf(txnSrc, sizeof(txnSrc), "%s", arg_v[3]);
		
		inst_prof_send_network(NetCode, txnSrc, NULL, NULL);
	}
    else if (strcmp(arg_v[2], "to") == 0 && (arg_c == 4 || arg_c == 5))
	{
		if(strlen(arg_v[3]) > 10)
		{
			if((istty) && (!isDaemon))
                        {
				printf("Destitation has too many digits.\n");
			}
			else
			{
				OTraceError("E-SHC-135233: Destitation has too many digits.\n");
                        }
			return(-1);
		}

		snprintf(txnDest, sizeof(txnDest), "%s", arg_v[3]);

		if (arg_c == 5)
		{
			if (arg_v[4][1] == 'e')
			{
				snprintf(iss_entityId, sizeof(iss_entityId),"%s", &arg_v[4][2]);
			}
			else
			{
				if((istty) && (!isDaemon))
				{
					printf("Invalid Entity ID.\n");
				}
				else
				{
					OTraceError("E-SHC-135234: Invalid Entity ID.\n");
                                }
				return(-1);
			}
			inst_prof_send_network(NetCode, NULL, txnDest, iss_entityId);
		}
		else
		{
			inst_prof_send_network(NetCode, NULL, txnDest, NULL);
		}
	}

	return(0);
}


int routeset()
{
	/*
	 *	set inst bin mailbox port [up | down]
	 */
	
	int	i;
	int x;
	struct RoutingInfo routingInfo = { 0 };
	struct	shcpkg *pkg;
	char *binid;

	newlyFoundShcBinKey = NULL;	//	R019505

	if (!binRouteObj)
	{
		if((istty) && (!isDaemon))
		{
			printf("binRouteObj is NULL, no route operation allowed\n");
		}
		else
		{
			OTraceInfo("I-SHC-135235: binRouteObj is NULL, no route operation allowed\n");
                }
		return(0);
	}
	/*
	 *	Get desired bin entry
	 */
	if(arg_c !=  7)
	{
		if((istty) && (!isDaemon))
                {
			printf("Usage: %s instid bin nodename|- binroute_group|- portname|- [up | down]\n", arg_v[0]);
		}
		else
                {
			OTraceInfo("I-SHC-135236: Usage: %s instid bin nodename|- binroute_group|- portname|- [up | down]\n", arg_v[0]);
                }
		return(0);
	}
   
	if(stricmp(arg_v[arg_c - 1], "up") != 0 && stricmp(arg_v[arg_c - 1], "down") != 0)
	{
		if((istty) && (!isDaemon))
                {
			printf("%s: %s Invalid command\n", arg_v[0], arg_v[arg_c - 1]);
		}
		else
                {
                        OTraceInfo("I-SHC-135237: %s: %s Invalid command\n", arg_v[0], arg_v[arg_c - 1]);
                }
		return(0);
	}

	/* find the specific bin */

	bin_t bin;
	char inst[sizeof(pkg->bin.institutionid)];
	
	snprintf(inst, sizeof(inst),"%s",arg_v[1]);
	snprintf(bin, sizeof(bin),"%s", arg_v[2]);
	if(shc_locate_bin(&pkg, inst, bin) < 0)
	{
		if((istty) && (!isDaemon))
                {
			printf("%s: Institution %s Bin %s is invalid network id\n", arg_v[0], 
						 arg_v[1], arg_v[2]);
		}
		else
                {
                        OTraceInfo("I-SHC-135238: %s: Institution %s Bin %s is invalid network id\n", arg_v[0], arg_v[1], arg_v[2]);
                }
		return(0);
	}
	if (newlyFoundShcBinKey)
		binid = newlyFoundShcBinKey->bin;
	else
		binid = pkg->bin.networkid;

	routingInfo.siteId = ofThisSite;

	if (arg_v[3][0] != '-')
	{
		snprintf(routingInfo.destNode, sizeof(routingInfo.destNode),"%s",arg_v[3]);
	}
	if (arg_v[4][0] != '-')
		istsafe_strcpy(getRouteEntriesBinrouteGroup,sizeof(getRouteEntriesBinrouteGroup), arg_v[4]);

	if (arg_v[5][0] != '-')
		snprintf(routingInfo.port, sizeof(routingInfo.port),"%s",arg_v[5]);
	if(stricmp(arg_v[6], "up") == 0)
		binRouteObj->markRouteUp(binid, &routingInfo,&i);
	else if(stricmp(arg_v[6], "down") == 0)
		binRouteObj->markRouteDown(binid, &routingInfo,NULL);

	return(0);
}

int routesend()
{
	/*
	 *	routesend netcode to inst bin node mailbox port [for inst] [with network_data]
	 */
	
	int	i;
	int x;
	struct RoutingInfo routingInfo = { 0 };
	struct	shcpkg *pkg;
	char	Network_Bin[11];
	char	InstId[11];
	int NetCode = 0;
	if (!binRouteObj)
	{
		if((istty) && (!isDaemon))
		{
			printf("binRouteObj is NULL, no route operation allowed\n");
		}
		else
		{
			OTraceInfo("I-SHC-135239: binRouteObj is NULL, no route operation allowed\n");
                }
		return(0);
	}
	/*
	 *	Get desired bin entry
	 */
	if((arg_c !=  8) && (arg_c != 10) && (arg_c != 12))
	{
		if((istty) && (!isDaemon))
                {
			printf("Usage: %s netcode to instid bin nodename|- mailboxname|- portname|- [for inst] [ with netword_data]\n", arg_v[0]);
			printf("Example:\n");
			printf("\t routesend 9001 to 13 111111 node117 VisaFormatter -\n");
			printf("\t routesend 9001 to 13 111111 node117 - VisaRoute for 12 with free_text_data\n");
			printf("\t routesend 9001 to 13 111111 node117 - VisaRoute with free_text_data\n");
		}
		else
		{
			OTraceInfo("I-SHC-135240: Usage: %s netcode to instid bin nodename|- mailboxname|- portname|- [for inst] [ with netword_data]\n", arg_v[0]);
			OTraceInfo("I-SHC-135240: Example:\n");
			OTraceInfo("I-SHC-135240: \t routesend 9001 to 13 111111 node117 VisaFormatter -\n");
			OTraceInfo("I-SHC-135240: \t routesend 9001 to 13 111111 node117 - VisaRoute for 12 with free_text_data\n");
			OTraceInfo("I-SHC-135240: \t routesend 9001 to 13 111111 node117 - VisaRoute with free_text_data\n");
                }
		return(0);
	}
  
	routingInfo.siteId = ofThisSite;

	/* find the specific bin */
	if (arg_v[5][0] != '-')
	{
		snprintf(routingInfo.destNode, sizeof(routingInfo.destNode),"%s",arg_v[5]);
	}
	snprintf(routingInfo.srcNode, sizeof(routingInfo.srcNode), "%s", mbcurrentnode);
	if (arg_v[6][0] != '-')
		istsafe_strcpy(getRouteEntriesBinrouteGroup, sizeof(getRouteEntriesBinrouteGroup), arg_v[6]);
	if (arg_v[7][0] != '-')
		snprintf(routingInfo.port, sizeof(routingInfo.port),"%s",arg_v[7]);

	tmpHeader.reset();
	if(strcmp(arg_v[arg_c-2], "with")==0)
	{
		tmpHeader.setSegmentData(arg_v[arg_c-1],strlen(arg_v[arg_c-1])+1, 
				ElfIdMap::elf_to_id(IST_SEG_NETWORK_DATA_REQ), ADD_NET_INFO); //R027876
		arg_c -= 2;
	}
	//	<<<	R020635

	if( is_digit(arg_v[1], strlen(arg_v[1]) ) )
	{
		NetCode = atoi(arg_v[1]);
		if( NetCode == SHC_NET_KEYS || NetCode == SHC_NET_KEYS_START )
		{
			if((istty) && (!isDaemon))
			{
				printf("!!! Use 'keys' option to send this command.\n");
			}
			else
			{
				OTraceInfo("I-SHC-135241: !!! Use 'keys' option to send this command.\n");
                        }
			return( 0 );
		}
	}
	else
	{
		/* 
		 *	26jun94 	: a little more wordy.
		 */

		 for( i = 0; netcode[i].flags > 0 ; i++)
		 {
			if( stricmp( arg_v[1], netcode[i].name) == 0)
			{
				if((istty) && (!isDaemon))
				{
					printf("I: Performing '%s' with IST val '%ld' \n",
						netcode[i].name, (int)netcode[i].flags);
				}
				else
				{
					OTraceInfo("I-SHC-135242: I: Performing '%s' with IST val '%ld' \n", 
						netcode[i].name, (int)netcode[i].flags);
                                }
				break;
			}
		 }

		 if( netcode[i].flags < 0)
		 {
			if((istty) && (!isDaemon))
                        {
				printf("%s", NetcodeHelp);
			}
			else
                        {
                                OTraceInfo("I-SHC-135242: %s", NetcodeHelp);
                        }
			return(-1);
		 }

		NetCode = netcode[i].flags;
		
	}

	
	if(strlen(arg_v[3]) > 10)
	{
		if((istty) && (!isDaemon))
                {
			printf("Institution has too many digits.\n");
		}
		else
		{
			OTraceError("E-SHC-135243: Institution has too many digits.\n");
                }
		return(-1);
	}


	if(strlen(arg_v[4]) > 10)
	{
		if((istty) && (!isDaemon))
                {
			printf("Network BIN has too many digits.\n");
		}
		else
                {
			OTraceError("E-SHC-135244: Network BIN has too many digits.\n");
                }
		return(-1);
	}

	snprintf(InstId, sizeof(InstId), "%s", arg_v[3]);
	snprintf(Network_Bin, sizeof(Network_Bin), "%s", arg_v[4]);
	newlyFoundShcBinKey = NULL;	//	R019505

	if(shc_locate_bin(&pkg, InstId, Network_Bin) < 0)
	{
		if((istty) && (!isDaemon))
                {
			printf("Institution: %s Networkid Bin: %s  in send command is not recognized\n", 
				arg_v[3], arg_v[4]);
		}
		else
		{
			OTraceInfo("I-SHC-135245: Institution: %s Networkid Bin: %s  in send command is not recognized\n", 
				arg_v[3], arg_v[4]);
                }
		return(0);
	}
	//mb_getUmi((tmpHeader).msg.shclog_id, sizeof((tmpHeader).msg.shclog_id));	//	R018276
	if (strcmp(arg_v[arg_c-2],"for")==0)
	{
		snprintf((tmpHeader).msg.txnSrc, sizeof((tmpHeader).msg.txnSrc),"%s",arg_v[arg_c-1]);
		arg_c -= 2;
	}
	else
		snprintf((tmpHeader).msg.txnSrc, sizeof((tmpHeader).msg.txnSrc), "%s", pkg->bin.institutionid);
	//	>>>	R019505
	if (newlyFoundShcBinKey)
		snprintf((tmpHeader).msg.issuer, sizeof((tmpHeader).msg.issuer), "%s", newlyFoundShcBinKey->bin);
	else
		snprintf((tmpHeader).msg.issuer, sizeof((tmpHeader).msg.issuer), "%s", pkg->bin.networkid);
	snprintf((tmpHeader).msg.acquirer, sizeof((tmpHeader).msg.acquirer),"%s",(tmpHeader).msg.issuer);
	//	<<<	R019505
	snprintf((tmpHeader).msg.originator, sizeof((tmpHeader).msg.originator), "%s", shc_orgid);

	//R030696 >>>
	if (NetCode == SHC_NET_GROUP_SIGNON)
	{
		(tmpHeader).msg.netcode = SHC_NET_GROUPSIGNON_START;
	}
	else
		(tmpHeader).msg.netcode = NetCode;
	//R030696 <<

	(tmpHeader).msg.msgtype = SHC_NETWORK;
	(tmpHeader).msg.format_code[0]='B';
	(tmpHeader).msg.format_code[1]='P';
	(tmpHeader).msg.pin_index=get_pin_index( InstId, Network_Bin)+'0';
	if ((tmpHeader).msg.pin_index - '0' <=0)
		(tmpHeader).msg.pin_index='1';
	mb_getUmi(tmpHeader.msg.shclog_id, sizeof(tmpHeader.msg.shclog_id));
	OTraceLog("L-SHC-135024: Created message ID[%s] m%04d/n%d\n", 
		tmpHeader.msg.shclog_id, tmpHeader.msg.msgtype, tmpHeader.msg.netcode);

	shcBin->setBinPkg(pkg);
	routingInfo.flag |= ROUTE_INFO_FLAG_USE_BINROUTE | ROUTE_INFO_FLAG_USE_FOR_REQ;
	tmpHeader.setSegmentData((char*)&routingInfo, sizeof(routingInfo), 
					ElfIdMap::elf_to_id(IST_SEG_NETWORK_DATA_REQ),ROUTING_INFO); //R027876

	int l=0;

	// R027876 >>>
	//struct RoutingInfo	newRoutingInfo = {0};
	//newRoutingInfo.flag |= ROUTE_INFO_FLAG_USE_BINROUTE | ROUTE_INFO_FLAG_USE_FOR_REQ;
	//tmpHeader.getSegmentData((char*)&newRoutingInfo, &l, ElfIdMap::elf_to_id(IST_SEG_NETWORK_DATA_REQ),ROUTING_INFO);
	// <<< R027876
	//if (!l)
	//{
	//	printf("Can't add segment, can't send\n");
	//	return -1;
	//}
	
	int n=binRouteObj->getRouteEntries(tmpHeader.msg.issuer, &routingInfo);
	struct s_binroute *br;
	for(n--;n>=0;n--)
	{
		br = binRouteObj->getRoute(n);
		if (br)
		{
			binRouteObj->useRoute(br, &routingInfo, NULL);
			tmpHeader.setSegmentData((char*)&routingInfo, sizeof(routingInfo),
					NETWORK_DATA_REQ_id, ROUTING_INFO);

			 struct InstitutionProfile *ip= shcApp->instProfileObj->locateByBinroute(br);
			if (ip)
			{
				tmpHeader.setSegmentData((char *)ip,
                		sizeof(struct InstitutionProfile), NETWORK_DATA_REQ_id, ISS_INST_PROFILE_ENTRY);
				tmpHeader.setSegmentData((char *)ip,
                		sizeof(struct InstitutionProfile), NETWORK_DATA_REQ_id, ACQ_INST_PROFILE_ENTRY);
			}
			else
				OTraceInfo("I-SHC-125023:Can't find inst_profile group[%s] bin[%s] port[%s]\n", 
					br->binrouteGroup, br->internalid, br->port);

			int ii=tmpHeader.truelength();
			thisShcApp->shcNetworkMsgHelperObj->shc_send_800(&tmpHeader, shcBin); 
			if((istty) && (!isDaemon))
			{
				printf("network msg sent for node[%s] mailbox[%s] port[%s]\n", routingInfo.destNode,
				routingInfo.mailbox, routingInfo.port);
			}
			else
			{
				OTraceInfo("I-SHC-135246: network msg sent for node[%s] mailbox[%s] port[%s]\n", 
				routingInfo.destNode, routingInfo.mailbox, routingInfo.port);
                        }
			OTraceHexDump((unsigned char *)&tmpHeader.msg, ii);
		}
		else
		{
			if((istty) && (!isDaemon))
                        {
				printf("Have a problem on one route, ignore this route\n");
			}
                        else
                        {
                                OTraceInfo("I-SHC-135247: Have a problem on one route, ignore this route\n");
                        }
		}
	}


	return(0);
}

int routeupdate()
{
	int i;
	char	buf[100];
	int		update_all = 0;
	struct  shcpkg  *pkg;     /* R001835 */
    char    bin[30];          /* R001835 */
    char    inst[30];         

	if(arg_c != 1)
	{
		if((istty) && (!isDaemon))
		{
			printf("Usage: %s \n", arg_v[0]);
		}
		else
		{
			OTraceInfo("I-SHC-135248: Usage: %s \n", arg_v[0]);
                }
		return(0);
	}

	ist_executor::execute_l("mbrulecmd", "update", "shc-bin-route", "all", (void *)0);

	return( 0 );
}

//R029275 >>>
static int graceful_shutdown()
{
	char cmdbuf[512]={0};
	char nodeId[128];

	if(arg_c != 2)
	{
		if((istty) && (!isDaemon))
                {
			printf("Usage: %s <node-id>\n", arg_v[0]);
		}
		else
		{
			OTraceInfo("I-SHC-135249: Usage: %s <node-id>\n", arg_v[0]);
                }
		return(0);
	}

	memset(nodeId,0x00,sizeof(nodeId));
	snprintf(nodeId,sizeof(nodeId),"%s",arg_v[1]);

	if((strcmp(mbcurrentnode, nodeId)==0) && binRouteObj)
	{
		// Set local binroutes down
		struct RoutingInfo routingInfo = { 0 };
		routingInfo.siteId = mbGetSiteId();
		snprintf(routingInfo.destNode, sizeof(routingInfo.destNode),"%s",nodeId);
		binRouteObj->markRouteDown(NULL, &routingInfo);
		binRouteObj->tidyUpBinStatus();
	}
	if ( !noBraodcastFlag)
	{
		// broadcast nodeId down to other nodes
		sprintf(cmdbuf, "shccmd -site %hd -s gracefuldown %s", mbGetSiteId(), nodeId);
		mcastHelperObj->broadcast("shccmd",3, cmdbuf , strlen(cmdbuf), NULL, 0);
		OTraceInfo("I-SHC-135005: '%s' broadcasted\n", cmdbuf);
		syslg("'%s' broadcasted\n", cmdbuf);
	}
	return 0;
}
//R029275 <<<

int updateMemShcKey()
{
	struct  shckeys *kp = (struct shckeys *)updateMemData;
	struct  shcsecurity *pTmp;
	int ret = -1;
	int i;
	char *p;
	
	if (updateMemDataLen != sizeof(struct shckeys))
	{
		OTraceError("E-SHC-135029:data size not correct for shckeys(%d)\n", updateMemDataLen);
		return -1;
	}
    if (shcSecurityAppid < 0)
    {
        shcSecurityAppid = rm_getappid("shared-cash-security");
        if (shcSecurityAppid < 0)
        {
            OTraceError("F-SHC-135030:Failed to get shckeys appid. Abort.\n");
            return -1;
        }
    }
	if (rm_appLockMemory(shcSecurityAppid)<0)
	{
		OTraceError("E-SHC-135031:Faild to lock shared-cash-security, abort update\n");
		syslg("E-SHC-135031:Faild to lock shared-cash-security, abort update\n");
		return -1;
	}
	if (rm_rearmSingleAttach() < 0)
	{
		OTraceError("E-SHC-135032:Faild to calling rm_rearmSingleAttach shared-cash-security, abort update\n");
		syslg("E-SHC-135032:Faild to calling rm_rearmSingleAttach shared-cash-security, abort update\n");
		rm_appUnlockMemory(shcSecurityAppid);
		return -1;
	}

	if (rm_attach( shcSecurityAppid, RULES_VER_CURRENT  )<0)
	{
		OTraceError("E-SHC-135033:Faild to attach shared-cash-security, abort update\n");
		syslg("E-SHC-135033:Faild to attach shared-cash-security, abort update\n");
		rm_appUnlockMemory(shcSecurityAppid);
		return -1;
	}
	struct rules_keytab *keyp = rm_getapphead(shcSecurityAppid);
	for(i = 0, p=rm_getapptext(shcSecurityAppid); i < keyp->textused; i++, p+=keyp->textsize)
    {
        pTmp=(struct  shcsecurity *)p;
        if ((strcmp(pTmp->k.institutionid, kp->institutionid)==0) &&
        	(strcmp(pTmp->k.userbinid, kp->userbinid)==0)
           )
        {
        	memcpy(&pTmp->k, kp, updateMemDataLen);
        	OTraceDebug("D-SHC-135034:Updated key record for (%s, %s)\n", pTmp->k.institutionid,
        		pTmp->k.userbinid);
        	ret = 0;
        	break;
        }
    }
    if (ret < 0)
	   	OTraceDebug("E-SHC-135035:Can't find shckey record for (%s, %s)\n", pTmp->k.institutionid,
        		pTmp->k.userbinid);
	rm_appUnlockMemory(shcSecurityAppid);
	return ret;
}

int updateMemShcBin()
{
	struct  shcpkg *kp = (struct shcpkg *)updateMemData;
	struct  shcpkg *pTmp;
	int ret = -1;
	int i;
	char *p;
	
	if (updateMemDataLen != sizeof(struct shcpkg))
	{
		OTraceError("E-SHC-135036:data size not correct for shcpkg(%d), abort\n", updateMemDataLen);
		return -1;
	}
    if (shcAppid < 0)
    {
        shcAppid = rm_getappid("shared-cash");
        if (shcAppid < 0)
        {
            OTraceError("F-SHC-135037:Failed to get shared-cash appid. Abort.\n");
            return -1;
        }
    }
	if (rm_appLockMemory(shcAppid) < 0)
	{
		OTraceError("E-SHC-135038:Faild to lock shared-cash, abort update\n");
		syslg("E-SHC-135038:Faild to lock shared-cash, abort update\n");
		return -1;
	}
	if (rm_rearmSingleAttach() < 0)
	{
		OTraceError("E-SHC-135039:Faild to calling rm_rearmSingleAttach shared-cash, abort update\n");
		syslg("E-SHC-135039:Faild to calling rm_rearmSingleAttach shared-cash, abort update\n");
		rm_appUnlockMemory(shcAppid);
		return -1;
	}
	if (rm_attach( shcAppid, RULES_VER_CURRENT  ) < 0)
	{
		OTraceError("E-SHC-135040:Faild to attach shared-cash, abort update\n");
		syslg("E-SHC-135040:Faild to attach shared-cash, abort update\n");
		rm_appUnlockMemory(shcAppid);
		return -1;
	}
	struct rules_keytab *keyp = rm_getapphead(shcAppid);
	for(i = 0, p=rm_getapptext(shcAppid); i < keyp->textused; i++, p+=keyp->textsize)
    {
        pTmp=(struct  shcpkg *)p;
        if ((strcmp(pTmp->bin.institutionid, kp->bin.institutionid)==0) &&
        	(strcmp(pTmp->bin.userbinid, kp->bin.userbinid)==0)
           )
        {
        	memcpy(pTmp, kp, updateMemDataLen);
        	OTraceDebug("D-SHC-135041:Updated shcbin record for (%s, %s)\n", pTmp->bin.institutionid,
        		pTmp->bin.userbinid);
        	ret = 0;
        	break;
        }
    }
    if (ret < 0)
    {
	   	OTraceError("E-SHC-135042:Can't find shcbin record for (%s, %s), update failed\n", pTmp->bin.institutionid,
        		pTmp->bin.userbinid);
	   	syslg("E-SHC-135043:Can't find shcbin record for (%s, %s), update failed\n", pTmp->bin.institutionid,
        		pTmp->bin.userbinid);
    }
	if (rm_appUnlockMemory(shcAppid) < 0)
	{
		OTraceError("E-SHC-135044:Faild to unlock shared-cash.\n");
		syslg("E-SHC-135044:Faild to unlock shared-cash.\n");
	}

	return ret;
}

int memUpdate()
{
	if (arg_c != 2)
	{
		OTraceError("E-SHC-135045:Expecting two argument in memUpdate()\n");
		return 0;
	}
	
	if (strcmp(arg_v[1], "shared-cash-security")==0)
		updateMemShcKey();
	else if (strcmp(arg_v[1], "shared-cash")==0)
		updateMemShcBin();
	else
	{
		OTraceError("E-SHC-135046:rule(%s) memory not supported\n", arg_v[1]);
	}
	return 0;
}
	
int revlogcmd()
{
	if (arg_c  < 2)
	{
		OTraceError("E-SHC-135047:Expecting two argument in memUpdate()\n");
		return 0;
	}

	static ShcLateRev *shcLateRev = NULL;

	if (!shcLateRev)
	{
		shcLateRev = new ShcLateRev();
	}

	shcLateRev->commandLine(arg_c, arg_v);

	return 0;
}	

int get_pin_index(char *InstId, char *Network_Bin)
{
	if (shcSharedMemoryHelperObj->attachCurrent(&shcSecurityAppid, &pShckeyAppHead) < 0)
	{
		if((istty) && (!isDaemon))
			printf("Can't find security rule, no keys operation avialable\n");
		else
			OTraceError("E-SHC-1351230: Can't find security rule, no keys operation avialable\n");
		return -1;
	}
	shcApp->shcmsgHelperObj->shc_normalizebin(Network_Bin);

	struct shcsecurity *pTmp = NULL;
	char       *p = NULL;
	int keyindex = 1;
	p = rm_getapptext(shcSecurityAppid);
	int i;
	for(i = 0; i < pShckeyAppHead->textused; ++i, p+=pShckeyAppHead->textsize)
	{
		pTmp = (struct shcsecurity *)p;
		if(stricmp(InstId, pTmp->k.institutionid) == 0 &&
			stricmp(Network_Bin, pTmp->k.userbinid) == 0)
			break;
	}
	if (i >= pShckeyAppHead->textused)
	{
		if((istty) && (!isDaemon))
			printf("Can't find key record(%s,%s), no keys operation avialable\n", InstId, Network_Bin);
		else
			OTraceError("E-SHC-135251: Can't find key record(%s,%s), no keys operation avialable\n", InstId, Network_Bin);
	}
	else
		keyindex = pTmp->k.isspinidx;
	OTraceInfo("I-SHC-1351231: SHCKEYS KEYINDEX for routesend is [%d]\n", keyindex);

	return keyindex;

}
static int setNodeMaintenance()
{
	int nodeId=-1, retVal=0;;
	try{
		IST_MR::get_current_node_id(nodeId);
		if((nodeId>0) && (IST_MR::set_node_is_maintenance(nodeId)))
			printf("Node[%d] is set maintenance mode\n", nodeId);
		else
		{
			printf("Node[%d] is failed to set maintenance mode\n", nodeId);
			return -1;
		}
		performNodeOperation(SET);
	}
    catch (IST_MR::Exception& e)
    {
        OTraceFatal("F-SHC-13528 Caught an exception in set node status: %s, exiting\n", e.getErrMsg().c_str());
        retVal =-1;
    }
    return retVal;
}
static int getNodeStatus()
{
	int nodeId=-1, retVal=0;
	try{
		IST_MR::get_current_node_id(nodeId);
		if((nodeId>0) && (IST_MR::check_if_node_is_maintenance(nodeId)))
			printf("Node[%d] is in maintenance \n", nodeId);
		else
			printf("Node[%d] is not in maintenance \n", nodeId);
	}
    catch (IST_MR::Exception& e)
    {
        OTraceFatal("F-SHC-13529 Caught an exception in get node status: %s, exiting\n", e.getErrMsg().c_str());
        retVal =-1;
    }
    return retVal;
}
static int resetNodeStatus()
{
    int nodeId=-1, retVal=0;
	try{
		IST_MR::get_current_node_id(nodeId);
		if((nodeId>0) && (IST_MR::reset_maintenance(nodeId)))
			printf("Node[%d] cleared the node status\n", nodeId);
		else
			printf("Node[%d] Not able to clear the node status\n", nodeId);
		performNodeOperation(RESET);
	}
	catch (IST_MR::Exception& e)
	{
		OTraceFatal("F-SHC-13530 Caught an exception in reset node status: %s, exiting\n", e.getErrMsg().c_str());
		retVal =-1;
	}
	return retVal;
}
int  performNodeOperation(int Oper)
{
    char state_value[6];
	int site_id=-1, node_id=-1, retVal=1;
	if (dbm_connect() <0)
	{
		printf("failed to connect DB to update node status\n");
		return -1;
	}
    char sql[] = "UPDATE node_record SET production_state = ? WHERE site_id = ? AND node_id = ?";
    DBMConn* dbConn = new DBMConn(dbm_dbconn);
    auto_ptr<DBMConn> delConn(dbConn);
    DBMStmt* stmt = dbConn->getStmt();
    auto_ptr<DBMStmt> delStmt(stmt);
    DBMString productionState(5);
    DBMInt siteId;
    DBMInt nodeId;
	memset(state_value, 0x00, sizeof(state_value));
	if(Oper == SET)
		state_value[0]=IST_MR::PROD_STATE_NODE_MAINTENANCE;
	else
		state_value[0]=IST_MR::PROD_STATE_NODE_UP;

	site_id=mbGetSiteId();
	IST_MR::get_current_node_id(node_id);
    try{
        stmt->prepare(sql);
        stmt->bindParam(1, productionState);
        stmt->bindParam(2, siteId);
        stmt->bindParam(3, nodeId);
        productionState.setValue((OCString)state_value);
        siteId.setValue(site_id);
        nodeId.setValue(node_id);
        stmt->execute();
        stmt->close();
        dbConn->commit();
    }catch(DBMException& e){
		OTraceError( "E-SHC-13526: sql error in node set state, native error=%d, sqlstate=%.5s, msg=%s\n",
						e.getNativeError(), e.getSQLState().data(), e.getErrMsg().data());
        printf("sql error in node set state, native error=%d, sqlstate=%.5s, msg=%s\n",
                        e.getNativeError(), e.getSQLState().data(), e.getErrMsg().data());
		retVal=-1;
    }
    return retVal;
}

/* -------------------------------------------------- */

