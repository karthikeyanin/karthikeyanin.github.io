static char _shcinitbinroute_cxx_what[] = "@(#) shcinitbinroute.cxx 1.24.2.5 20/01/13 16:07:39";


/*
 *  Copyright (C) 2004 eFunds Corporation ("eFunds").  All Rights Reserved.     
 *  eFunds Canada Corporation is an authorized user.                            
 *                                                                              
 *  IST is a registered trademark of eFunds Corporation.  Other brand or        
 *  product names are trademarks or registered trademarks of their respective   
 *  holders.                                                                    
 *                                                                              
 *  The information contained herein is the unpublished proprietary property    
 *  of eFunds.  Except as specifically authorized in writing by eFunds, the     
 *  holder of this document shall: i) keep all information contained herein     
 *  confidential, and ii) protect the information, in whole or in part, from    
 *  disclosure and dissemination to all third parties.                          
 *                                                                          
 *  This document and the software described in it are furnished under license  
 *  and may be used or copied only in accordance with the terms of such license.
 *  This document is supplied for information purposes only, is subject to      
 *  change without notice, and should not be construed as a commitment by       
 *  either eFunds Corporation or eFunds Canada Corporation. 
 */
/*
 *
 *                        MODIFICATION HISTORY                  REVIEW
 *
 *	SPR#	Who	Date	Description			Who	Date   
 * ===========================================================================
 *	Alf			10Jan95		modified to use new shcextbindb table and fixed 
 *							some bugs.
 * 10001935 la  09may96 Was opening incorrect index name.
 * R002639	zt  01Sep99 Loaded network_data into shared memory for external bin
 * R004214  fg  22Mar00 replace DBM_RSEQ with DBM_RFIRST, DBM_RNEXT 
 * R007062	gbeeng	26Nov2001	C++ Migration
 *R007235 ztang 03Jan01	Update 	keyp->keysused for update command
 *R008717 ztang 09Dec02	Multi-institution support. Using new structure.
 *R009074 ztang 04Feb03 changed keys_cmp to use memcpy
 *R009352 ztang 05Mar03 Increase the textused by 1
 *R012134 Emj   01Oct04 Issuer Entity Support  
 *R020436 leesy 26Jun07 Bin Load Performance Improvement 
 *R023095 jyang 13May08 Supported for locking shared memory of BinRoute
 *R028747 dipa  17Nov10 Remove reference to rules_keytab[]
 *R029948 dipa  04Oct11 Wait for shared-cash rule to be loaded
 */

//File Number 165

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <errno.h>
#include <shc.h>
#include <mb.h>
#include <rules.h>
#include<ic/ic_instid.h>
#include <DBM3.h>
#include <dbm.h>
#include <dbm_private.h>
#include <ist_otrace.h>
#include <shcdef.h>	
#include <binroute.h>
#include <BinRoute.h>
#include <ShcApp.h>

#include <HaPtmCctHelper.h>

/*
 *	Example application initialiser
 */



/*
 *	An application initialiser is invoked with the following paramaters
 *
 *		<taskname>	<mode>	<rulename>	<appid> <srvname> [<data>]
 *
 *	<taskname>		the executable name of this task		(argv[0])
 *	<mode>			the mode of processing
 *						'count'			count space needed and report to strm
 *						'init'			init the rules in-core database
 *						'update'		update an existing rule
 *						'load'			load you application
 *
 *	<rulename>		the name of the rule to be initialised
 *	<appid>			the system assigned application id for this rule
 *
 *	<srvname>		the server to which count information should be sent
 *
 *	<data>			data which might be included in an 'update' command
 *
 *
 *****************************************************************************
 *
 *	This is SHARED Cash ExtBin initialiser
 *	This task accepts initialisation requests for message
 *
 *			shcbinroute
 */

/* Following two parameters determines the minimum number of entries allocated in shared memory */
#define MINIMUM_MEMORY_INCREMENT 40

/* Minimum percentage of extra memory needed */
#define EXTRA_MEMORY				20

extern "C"
{
	int keys_cmp(const void *anykey1, const void *anykey2);
	int keys_cmp_local_first(const void *anykey1, const void *anykey2); //	---	R030592
}
int update_record();
int count_records();
int init_records();
int dump_records();
int load_servers();
int pexit(int n);
int initSys();
int processError(int ret, DBMHSTMT sh);
int fillStaticInfo(struct s_binroute *mem, BINROUTE *db);
int find_outbound(char *outroute);
int loadBnrtRuleParam();
		
		
static char ver[100];		
int con_id = -1;
int appid = -1;
struct      rules_keytab keytab = { 0 };
int         my_count = 0;
int size;
int         argc        = 0;
char        **argv      = NULL;
char		bp[1024] = "select count(*) from binroute";
int initversion = RULES_VER_LOADING;


int main(int a_rgc, char **a_rgv)
{
  argv = a_rgv;
  argc = a_rgc;
	
	argv0 = *argv;
	catch_all_signals(NULL);

	strcat(ver, VERSION);
	syslg("%s\n", ver);
	OTraceOn("shcinitbinroute");

	HaPtmCctHelper::deinit() ;

	if(argc < 5)
	{
		OTraceFatal("F-SHC-165001: %d is an invalid number of parameters.\n", argc);
		pexit(1);
	}

	OTraceDebug("D-SHC-165002:record size:%d\n", sizeof(struct s_binroute));
	
	mb_init();

	OTraceInfo("I-SHC-165003: %s mode for rule %s\n", 
	    argv[RULES_PARM_MODE], argv[RULES_PARM_RULENAME]);

	con_id = mb_locatemailbox(argv[RULES_PARM_SRVNAME]);
	if (con_id == -1)
	{
		OTraceFatal("F-SHC-165004: Unable to connect to %s: Error: %d\n",
		    argv[RULES_PARM_SRVNAME], errno);
		pexit(1);
	}
//	if (rm_init() < 0)
//	{
//		OTraceDebug("F-SHC-165055: Unable to connect to RuleManager : Error: %d\n",
//				errno);
//		pexit(1);
//	}

	/* Extract all paramaters */
//	appid = rm_getappid(argv[RULES_PARM_RULENAME]);
	appid = atoi(argv[RULES_PARM_APPID]);

	if(stricmp("shc-bin-route", argv[RULES_PARM_RULENAME]) != 0)
	{
		OTraceFatal("F-SHC-165005: Invalid message type: %s\n",
			argv[RULES_PARM_RULENAME]);
		pexit(1);
	}

	/* Now determine which we need and perform action */

	if(stricmp(argv[RULES_PARM_MODE], "count") == 0)
		count_records();
	else if(stricmp(argv[RULES_PARM_MODE], "init") == 0)
		init_records();
	else if(stricmp(argv[RULES_PARM_MODE], "testinit") == 0)
	{
		initversion = RULES_VER_CURRENT;
		init_records();
	}
	else if(stricmp(argv[RULES_PARM_MODE], "load") == 0)
		load_servers();
	else if(stricmp(argv[RULES_PARM_MODE], "update") == 0)
	{
		//Always update all records
		//update_all = (!stricmp("all", argv[RULES_PARM_DATA]) ? 1 : 0);
		update_record();
	}
	else if(stricmp(argv[RULES_PARM_MODE], "dump") == 0)
		dump_records();
	else
		OTraceFatal("F-SHC-165006: Don't know how to interpret mode '%s'\n", 
		    argv[RULES_PARM_MODE]);

	pexit(0);
	return(0);
}

//	>>>	R030592
bool isPreferLocalForFailover()
{
	bool flag = true;
	char buf[128] = {0};
	if(cf_locate("shc.preferLocalRouteForFailover", buf) <= 0 )
	{
		flag = true; //      default value
	}
	else if( toupper(buf[0]) == 'Y' || buf[0] == '1' )
		flag = true;
	else
		flag = false;
													
	OTraceDebug("D-SHC-165010: Parameter shc.preferLocalRouteForFailover value [%c]\n",
		(flag? 'Y': 'N') );
	return flag;
}
//	<<<	R030592

bool shouldLoadExtTable()
{
	bool flag = false;
	char buf[128] = {0};
	cf_open(NULL);
	if(cf_locate("binroute.extend", buf) <= 0 )
	{
		flag = false; //      default value
	}
	else if( toupper(buf[0]) == 'Y' || buf[0] == '1' )
		flag = true;
	else
		flag = false;
	cf_close();

	OTraceDebug("D-SHC-165074: Parameter binroute.extend value [%c]\n",
	(flag? 'Y': 'N') );
return flag;
}



bool shouldLoadRemoteSite()
{
	static int initialized = 0;
	static bool flag = false;

	if (initialized)
	return flag;

	char buf[128] = {0};
	cf_open(NULL);
	if(cf_locate("syncsrv.enable_cross_sites", buf) <= 0 )
	{
		flag = false; //      default value
	}
	else if( toupper(buf[0]) == 'Y' || buf[0] == '1' )
		flag = true;
	else
		flag = false;
	cf_close();

	OTraceDebug("D-SHC-165074: Parameter syncsrv.enable_cross_sites value [%c]\n",
	(flag? 'Y': 'N') );
	initialized = 1;
	return flag;
}


static void removeTrailingSpace(char *s)
{
	int i;
	
	for (i=strlen(s)-1;i>=0 && s[i] && s[i] == ' '; i--);
	
	s[i+1] = '\0';
	return;
}

int shcinitbinrouteGetMinimumSpace()
{
	int ret;
	int numOfEntries = 0;
	DBMHSTMT tmpStmt;
	
  if (dbm_connect() >=0)
  {
      OTraceDebug("D-SHC-165007:Connecting to database successful");
  }
  else
  {
      OTraceFatal("F-SHC-165008:Connecting to database failed");
      return -1;
  }
  ret=DBMAllocStmt(dbm_dbconn, &tmpStmt);
  if (ret < 0)
  {
      OTraceFatal("F-SHC-165009:Can't allocate statment:%s", bp);
      return -1;
  }

  if (shouldLoadExtTable())
  {
	strcpy(bp, "select count(1) from binroute b full outer join binroute_ext e on b.site_id=e.site_id AND b.node = e.node AND b.port = e.route");
  }
  ret=DBMPrepare(tmpStmt, (char *)bp);
  if (ret < 0)
  {
      OTraceFatal("F-SHC-165010:Can't prepare statment:%s", bp);
      return -1;
  }
  ret=DBMExecute(tmpStmt);
  if (ret < 0)
  {
      OTraceFatal("F-SHC-165011:Can't execute statment:%s", bp);
      return -1;
  }
  
  int status;
  ret=DBMBindCol(tmpStmt, 1, DBM_LONGTYPE, &numOfEntries, sizeof(numOfEntries), &status);
  if (ret < 0)
  {
      OTraceFatal("F-SHC-165012:Can't bind for statment:%s", bp);
      return -1;
  }

  ret=DBMFetch(tmpStmt);
  if (ret == DBM_NO_DATA)
  	numOfEntries = 0;
	else if (ret < 0)
  {
      OTraceFatal("F-SHC-165013:Can't fetch for statment:%s", bp);
      return -1;
  }
  DBMFreeStmt(tmpStmt, DBM_CLOSE);
  
  OTraceDebug("D-SHC-165014: Found %d records\n", numOfEntries);
  /* Now calculate how many entries we should allocate
   * The number of entries increase by 100.
   * And we need to keep at least 20% free space
   */
  numOfEntries = (numOfEntries+1) * (100 + EXTRA_MEMORY)/100;
  numOfEntries = (numOfEntries + MINIMUM_MEMORY_INCREMENT - 1)/MINIMUM_MEMORY_INCREMENT * MINIMUM_MEMORY_INCREMENT;
  
  return numOfEntries;
}


	
int count_records()
{
	/*
	 *	He wants me to inidcate how many keys and text buffers
	 *	as well as their respective sizes
	 *
	 *	I can do this by reading the database or by looking in a
	 *	config file
	 */

	int mbw;

	/* Set up my return packet */

	keytab.appid = atoi(argv[RULES_PARM_APPID]);

	size	= BIN_ROUTE_SIZE_MEM;

	if (sizeof(struct s_binroute) > BIN_ROUTE_SIZE_MEM)
	{
		log_msg(FATAL, TO_CC, "F-SHC-165015: real size %d is bigger than max size\n",
			sizeof(struct s_binroute), BIN_ROUTE_SIZE_MEM);
	}
		
	if ((my_count = shcinitbinrouteGetMinimumSpace()) < 0)
		log_msg(FATAL, TO_CC, "F-SHC-165016:Can't estimate shared memory needed.\n");

	/* Now i tell him how large my buffers should be */

	keytab.keysize = BIN_ROUTE_SIZE_MEM;
	keytab.nkeys	= my_count;
	keytab.textsize	= BIN_ROUTE_SIZE_MEM;
	keytab.ntext	= 0;

	snprintf(keytab.name, sizeof(keytab.name),"%s",argv[RULES_PARM_RULENAME]);

	/* Now I send him the information */

	if ((mbw = mb_write(con_id, 0, &keytab, sizeof(keytab))) < 0)
		OTraceFatal("F-SHC-165017: Unable to write to server id %d\n", con_id);
	
	OTraceDebug("D-SHC-165018:count result: keysize[%d] nkeys[%d] textsize[%d] ntext[%d]\n",
		keytab.keysize, keytab.nkeys, keytab.textsize, keytab.ntext);
	cf_close();
	return(0);
}

//	>>>	R030592
int keys_cmp_local_first(const void *anykey1, const void *anykey2)
{
	struct s_binroute *k1 = (struct s_binroute *)anykey1;
	struct s_binroute *k2 = (struct s_binroute *)anykey2;
			
	int ret;
	int k1isLocal, k2isLocal;
						
	ret = strcmp(k1->internalid, k2->internalid);
	if (ret != 0)
		return ret;

	if (	(strcmp(k1->node, k2->node)== 0) &&
			(strcmp(k1->binrouteGroup, k2->binrouteGroup)== 0) &&
			(strcmp(k1->port, k2->port)== 0)
		)
	{
		OTraceError("E-SHC-165019: Duplicate record in binroute:inst[%s] bin[%s] node[%s] group[%s] port[%s]\n",
					k1->institutionid, k1->userbinid, k1->node, k1->binrouteGroup, k1->port);
	}
										
	
	int k1isLocalSite = (k1->siteId == mbGetSiteId());
	int k2isLocalSite = (k2->siteId == mbGetSiteId());

	if (k1isLocalSite && !k2isLocalSite)
		ret = -1;
	else if (k2isLocalSite && !k1isLocalSite)
		ret = 1;
	else
		ret = 0;

	if (ret != 0)
		return ret;


	k1isLocal = (strcmp(k1->node, mbcurrentnode) == 0);
	k2isLocal = (strcmp(k2->node, mbcurrentnode) == 0);

	if (k1isLocal && !k2isLocal)
		ret = -1;
	else if (k2isLocal && !k1isLocal)
		ret = 1;
	else
		ret = 0;

	if (ret != 0)
		return ret;

	ret = k1->priority - k2->priority;	//smaller number, higher priority

	return ret;
}
//	<<<	R030592

int keys_cmp(const void *anykey1, const void *anykey2)
{
	struct s_binroute *k1 = (struct s_binroute *)anykey1;
	struct s_binroute *k2 = (struct s_binroute *)anykey2;
	
	int ret;
	int k1isLocal, k2isLocal;
	
	ret = strcmp(k1->internalid, k2->internalid);

	if (ret != 0)
		return ret;

//	>>>	R030592
//	ret = k1->inst_profile_id - k2->inst_profile_id;

//	if (ret != 0)
//		return ret;
//	<<<	R030592
	
	if (	(strcmp(k1->node, k2->node)== 0) &&
				(strcmp(k1->binrouteGroup, k2->binrouteGroup)== 0) &&
				(strcmp(k1->port, k2->port)== 0)
			)
	{
		OTraceError("E-SHC-165019: Duplicate record in binroute:inst[%s] bin[%s] node[%s] group[%s] port[%s]\n",
			k1->institutionid, k1->userbinid, k1->node, k1->binrouteGroup, k1->port);
	}
				
	ret = k1->priority - k2->priority;	//smaller number, higher priority

	if (ret != 0)
		return ret;
	
	k1isLocal = (strcmp(k1->node, mbcurrentnode) == 0);
	k2isLocal = (strcmp(k2->node, mbcurrentnode) == 0);
	
	if (k1isLocal && !k2isLocal)
		ret = -1;
	else if (k2isLocal && !k1isLocal)
		ret = 1;
	else
		ret = 0;

	int k1isLocalSite = (k1->siteId == mbGetSiteId());
	int k2isLocalSite = (k2->siteId == mbGetSiteId());


	if (k1isLocalSite && !k2isLocalSite)
		ret = -1;
	else if (k2isLocalSite && !k1isLocalSite)
		ret = 1;
	else
		ret = 0;

	return ret;
}


int init_records()
{
	/* Now I can actualy initialise my table */

	int	key_count = 0, text_count = 0;
	int	i;
	struct rules_keytab *keyp;
	BINROUTE binRouteDB;
	int currentCount;

	/* for debug */
	static	int		recordnum = 0;

	int ind[16] = { 0 };	//	---	R020436 
	int buf[1024];
	struct s_binroute buf2;
	struct s_binroute *pTmp = &buf2;

	initSys();
	if(loadBnrtRuleParam() < 0)
		return -1;

	DBMHSTMT shQuery;
	DBMHDBC ch;	
	DBMRETURN ret = 0;
	if (dbm_connect() >=0)
	{
		OTraceDebug("D-SHC-165020:Connecting to database successful\n");
		ch=dbm_dbconn;
  }
	else
	{
		OTraceError("E-SHC-165021: Connecting to database failed\n");
		return (-1);
 	}

	char sqlStatementQuery[512] = "select institutionid, userbinid, node, binroute_group, mailbox, port, "
									"cfg, init_status, echo,  priority,"
									"base_port_name, blrnode, site_id, inst_profile_id  from binroute"; //R029275

	if (shouldLoadExtTable())
	{
		strcpy(sqlStatementQuery, "select b.institutionid, b.userbinid, b.node, b.binroute_group, e.sub_route, "
									"b.cfg, b.init_status, b.echo,  b.priority,"
									"b.port, e.forwarding_node, b.site_id, b.inst_profile_id  from binroute b full outer join  binroute_ext e "
									"on b.site_id=e.site_id AND b.node = e.node AND b.port = e.route"); 
	}


 	if( DBMAllocStmt(ch, &shQuery) < 0)
	{
		OTraceError("E-SHC-165022: Select query statement allocate error:\n%s\n", sqlStatementQuery);
		return -1;
	}
	i=1;
	if( (DBMBindCol(shQuery,1,DBM_STRINGTYPE,binRouteDB.institutionid,sizeof(binRouteDB.institutionid),&ind[0]) != DBM_SUCCESS) ||
			(DBMBindCol(shQuery,2,DBM_STRINGTYPE,binRouteDB.userbinid,sizeof(binRouteDB.userbinid),&ind[1]) != DBM_SUCCESS) ||
			(DBMBindCol(shQuery,3,DBM_STRINGTYPE,binRouteDB.node,sizeof(binRouteDB.node),&ind[2]) != DBM_SUCCESS) ||
			(DBMBindCol(shQuery,4,DBM_STRINGTYPE,binRouteDB.binroute_group,sizeof(binRouteDB.binroute_group),&ind[3]) != DBM_SUCCESS) ||
			(DBMBindCol(shQuery,5,DBM_STRINGTYPE,binRouteDB.mailbox,sizeof(binRouteDB.mailbox),&ind[4]) != DBM_SUCCESS) ||
			(DBMBindCol(shQuery,6,DBM_STRINGTYPE,binRouteDB.port,sizeof(binRouteDB.port),&ind[5]) != DBM_SUCCESS) ||
			(DBMBindCol(shQuery,7,DBM_STRINGTYPE,binRouteDB.cfg,sizeof(binRouteDB.cfg),&ind[6]) != DBM_SUCCESS) ||
			(DBMBindCol(shQuery,8,DBM_CHARTYPE,&binRouteDB.init_status,sizeof(binRouteDB.init_status),&ind[7]) != DBM_SUCCESS) ||
			(DBMBindCol(shQuery,9,DBM_CHARTYPE,&binRouteDB.echo,sizeof(binRouteDB.echo),&ind[8]) != DBM_SUCCESS) ||
			(DBMBindCol(shQuery,10,DBM_LONGTYPE,&binRouteDB.priority,sizeof(binRouteDB.priority),&ind[9]) != DBM_SUCCESS) ||
			(DBMBindCol(shQuery,11,DBM_STRINGTYPE,binRouteDB.base_port_name,sizeof(binRouteDB.port),&ind[10]) != DBM_SUCCESS) ||
			(DBMBindCol(shQuery,12,DBM_STRINGTYPE,binRouteDB.blrnode,sizeof(binRouteDB.blrnode),&ind[11]) != DBM_SUCCESS) ||
			(DBMBindCol(shQuery,13,DBM_INTTYPE,&binRouteDB.site_id,sizeof(binRouteDB.site_id),&ind[12]) != DBM_SUCCESS) ||
			(DBMBindCol(shQuery,14,DBM_LONGTYPE,&binRouteDB.inst_profile_id,sizeof(binRouteDB.inst_profile_id),&ind[13]) != DBM_SUCCESS)

		)
	{
		OTraceError("E-SHC-165023: Select query bind error \n");
		return (-1);
	}
	else
	{
		if( DBMPrepare(shQuery, sqlStatementQuery) != DBM_SUCCESS )
		{
			OTraceError("E-SHC-165024: Select query prepare error:\n%s \n", sqlStatementQuery);
		}
        int num_prefetch = 10000;
        DBMSetStmtAttribute(shQuery, DBM_ATTR_PREFETCH_COUNT, &num_prefetch, sizeof(num_prefetch));
		
		ret = DBMExecute(shQuery);
		if(ret != DBM_SUCCESS)
		{
			if(processError(ret, shQuery))
			{
				DBMFreeStmt(shQuery, DBM_DROP);
				return (-1);
			}

		}
	}
				/*	Insert the key */
	keyp = rm_getapphead(appid);
	keyp->keysused = 0;
	int site_id = mbGetSiteId();
	for(key_count = 0;;key_count++)
	{
		memset((char *)&binRouteDB, 0, sizeof(binRouteDB));
		ret = DBMFetch(shQuery);
		if ((ret != DBM_SUCCESS)&&(ret != DBM_SUCCESS_WITH_INFO))
		{
			if(processError(ret, ch))
			break;
		}
		else
		{
			if ( !shouldLoadRemoteSite() && binRouteDB.site_id && ( site_id != binRouteDB.site_id ))
			{
				OTraceDebug("D-SHC-165075 skip record [%s.%s] as db site[%d] not same as current site[%d]\n", 
				binRouteDB.institutionid, binRouteDB.userbinid, binRouteDB.site_id, site_id );
				continue;
			}

			memset(pTmp, 0, sizeof(*pTmp));

			if(fillStaticInfo(pTmp, &binRouteDB) < 0)
			{
				OTraceDebug("D-SHC-165079 Skip record as bin is not found\n");
				continue;
			}

			if(rm_insert_key(appid, (const char *)pTmp, recordnum) < 0)
				OTraceFatal("F-SHC-165025: Unable to insert header\n");
			else
				OTraceDebug("D-SHC-165026: record %d inserted\n", key_count);
		recordnum ++;
		}
	}

	
	keyp->textused = text_count;
	keyp->keysused = recordnum;

	if(!rm_isMultiVerSupported(0))
		return(0);

		/* Now sort the bin entries for faster look up */

	if ( isPreferLocalForFailover()  )
		qsort(rm_getappkey(appid), keyp->keysused, keyp->keysize, keys_cmp_local_first);
	else
		qsort(rm_getappkey(appid), keyp->keysused, keyp->keysize, keys_cmp);

	// >>> R029583
	if ( rm_appLockMemory(appid) < 0 )
	{
		OTraceError("E-SHC-165056:Can't get lock, Abort shared-cash init.\n");
		syslg("E-SHC-165056:shared-cash initialization failed.\n");
		return -1;
	}

	struct shcpkg *pkg = NULL;
	int haveRouteUp = 0;
	bin_t currentBin="";
	char *p = NULL;
	//Check if this is an initial load of this rule table
	if(rm_attachedcurrent(appid)==0)
	{
		OTraceDebug("D-SHC-165073: check bin status for very first load. appid:%d, keyused:%d.\n", 
			appid, keyp->keysused);

		pTmp = NULL;
		p = rm_getappkey(appid);
		for(key_count = 0; key_count < keyp->keysused; key_count++, p+=keyp->keysize)
		{
			pTmp=(struct s_binroute*)p;
			if (!currentBin[0])
			{
				strcpy(currentBin, pTmp->internalid);
				haveRouteUp = 0;
			}
			else if (strcmp(currentBin, pTmp->internalid)!=0)
			{
				if (!haveRouteUp)
				{
					if (shcApp->shcBinObj->setBinPkg(currentBin)<0)
						OTraceError("E-SHC-:failed to find bin pkg[%s].\n", currentBin);
					else
						shcApp->shcBinObj->setInstDown();
				}
				strcpy(currentBin, pTmp->internalid);
				haveRouteUp = 0;
			}
			if (pTmp->status == BIN_ROUTE_STATUS_UP)
				haveRouteUp = 1;
		}
		if (pTmp && !haveRouteUp)
		{
			if (shcApp->shcBinObj->setBinPkg(currentBin) < 0)
			OTraceDebug("E-SHC-165029:Can't find bin [%s]\n");
			else
				shcApp->shcBinObj->setInstDown();
		}
		//set to READY state, unset loading and just return.
		if (rm_setstate( appid, RULES_VER_ATTACHED, RM_STATE_READY ) < 0)
			log_msg(FATAL, TO_CC, "F-BUSD-0116.1: Unable to set READY state after rule[%s] is loaded\n",
			argv[RULES_PARM_RULENAME]);
		//Unset loading
		rm_unsetloading(appid);
		rm_appUnlockMemory(appid);
		return(0);
	}

	//Attach to the current version of the table
	if ( rm_attach( appid, RULES_VER_CURRENT ) != 0)
	{
		OTraceError("E-SHC-165057: Unable to attach to CURRENT version \n");
		return (-1);
	}
	keyp = rm_getapphead(appid);
	currentCount = keyp->keysused;

	//Prepare memory buffer to copy the whole existing rule table
	char *localMem;
	localMem = (char *)calloc(keyp->keysize,keyp->keysused);
	if (!localMem)
	{
		OTraceError("E-SHC-165058: can't allocate %d bytes\n",keyp->keysize*keyp->keysused);
		return(-1);
	}

	//Copy existing rule table into memory buffer
	memcpy(localMem,rm_getappkey(appid),keyp->keysused*keyp->keysize);
	p = localMem;

	//Need to save the old apphead before attach to loading version
	struct rules_keytab oldAppHead = { 0 };
	memcpy(&oldAppHead,keyp, sizeof(oldAppHead));

	//Attach to the loading version of rule table
	if ( rm_attach( appid, RULES_VER_LOADING ) != 0)
	{
		OTraceError("E-SHC-165059: Unable to attach to LOADING version \n");
		return(-1);
	}

	keyp = rm_getapphead(appid);

	//Transfer data from localMem into loading version of the table
	struct s_binroute *pAppKey;
	struct s_binroute *pNewAppKey;
	pAppKey = (struct s_binroute*)rm_getappkey(appid);
	int lastNewKeyIndex = 0;
	for(i=0;i<currentCount;i++,p+=oldAppHead.keysize)
	{
		pAppKey = (struct s_binroute *)p;
		int j;
		char *newp = NULL;
		for(j=lastNewKeyIndex,newp = rm_getappkey(appid)+lastNewKeyIndex*keyp->keysize; j<keyp->keysused; j++,newp += keyp->keysize)
		{
			pNewAppKey = (struct s_binroute *)newp;
			if (pAppKey->hashValue != pNewAppKey->hashValue)
				continue;
			if( (strcmp(pAppKey->institutionid,pNewAppKey->institutionid) == 0) &&
				(strcmp(pAppKey->userbinid,pNewAppKey->userbinid) == 0) &&
				(strcmp(pAppKey->node,pNewAppKey->node) == 0) &&
				(strcmp(pAppKey->binrouteGroup,pNewAppKey->binrouteGroup) == 0) &&
				(strcmp(pAppKey->port,pNewAppKey->port) == 0) )
			{
				//Copy localMem contents to Loading version SHM
				pNewAppKey->status = pAppKey->status;
				pNewAppKey->flag = pNewAppKey->flag;
				lastNewKeyIndex=j;
				break;
			}
		}
		if(j==keyp->keysused)
			OTraceDebug("D-SHC-165060: init_records() - record not found in LOADING shm for i[%s] u[%s] n[%s] g[%s] p[%s]\n", 
					pNewAppKey->institutionid, pNewAppKey->userbinid, pNewAppKey->node,
					pNewAppKey->binrouteGroup, pNewAppKey->port);
	}

	//Set the attached version in READY state
	if (rm_setstate( appid, RULES_VER_ATTACHED, RM_STATE_READY) < 0)
	{
		OTraceError("E-SHC-165061:Can't set rule state to READY, Abort shc-bin-route init.\n");
		syslg("E-SHC-165061:Can't set rule state to READY, Abort shc-bin-route init.\n");
		rm_appUnlockMemory(appid);
		return -1;
	}
	//Unset loading
	if (rm_unsetloading(appid) < 0)
	{
		OTraceError("E-SHC-165062:Can't unset rule state of LOADING, Abort shc-bin-route init.\n");
		syslg("E-SHC-165062:Can't unset rule state of LOADING, Abort shc-bin-route init.\n");
		rm_appUnlockMemory(appid);
		return -1;
	}
	//Make loading version the current version
	if (rm_setcurrent( appid, RULES_VER_ATTACHED)<0)
	{
		OTraceError("E-SHC-165063:Can't set rule to CURRENT, Abort shc-bin-route init.\n");
		syslg("E-SHC-165063:Can't set rule to CURRENT, Abort shc-bin-route init.\n");
		rm_appUnlockMemory(appid);
		return -1;
	}

	pTmp = NULL;
	p = NULL;
	for(key_count = 0,p = rm_getappkey(appid); key_count < keyp->keysused; key_count++, p+=keyp->keysize)
	{
		pTmp=(struct s_binroute*)p;
		if (!currentBin[0])
		{
			strcpy(currentBin, pTmp->internalid);
			haveRouteUp = 0;
		}
		else if (strcmp(currentBin, pTmp->internalid)!=0)
		{
			if (!haveRouteUp)
			{
				if (shcApp->shcBinObj->setBinPkg(currentBin) < 0)
					OTraceDebug("E-SHC-165077: Invalid bin.Can't find in bin tables\n");
				else
					shcApp->shcBinObj->setInstDown();
			}
			strcpy(currentBin, pTmp->internalid);
			haveRouteUp = 0;
		}
		if (pTmp->status == BIN_ROUTE_STATUS_UP)
			haveRouteUp = 1;
	}
	if (pTmp && !haveRouteUp)
	{
		if (shcApp->shcBinObj->setBinPkg(currentBin) < 0)
			OTraceDebug("E-SHC-165029:Can't find bin [%s]\n");
		else
			shcApp->shcBinObj->setInstDown();
	}

	rm_appUnlockMemory(appid);
	// <<< R029583

	return(0);
}

int fillStaticInfo(struct s_binroute *mem, BINROUTE *db)
{
	struct shcpkg *pkg = NULL;
	strcpy(mem->institutionid, db->institutionid);
	strcpy(mem->userbinid, db->userbinid);

	strcpy(mem->node, db->node);
	strcpy(mem->binrouteGroup, db->binroute_group);
	strcpy(mem->mailbox, db->mailbox);
    if (!mem->binrouteGroup[0] || (mem->binrouteGroup[0]== '*'))
        sprintf(mem->binrouteGroup, "%1d", db->inst_profile_id);

	if ((strcmp(mem->userbinid, "     ONDOT")==0)&&(strcmp(mem->institutionid, "ONDOT")==0))
	{
		//On Dot bin only use local routes
		if (mem->node[0] && (strcmp(mem->node, mbcurrentnode)!=0))
		{
			OTraceDebug("D-SHC-165077:On Dot only use local routes. remote route on node[%s] not used\n", mem->node);
			return -1;
		}
	}

	strcpy(mem->base_port_name, db->base_port_name);
	if (db->port[0])		//With balancer, it contains ext.sub_route
		strcpy(mem->port, db->port);
	else if (db->blrnode[0])
	{
		//sub_route not set, have balancer, create port as route-blrnode
		removeTrailingSpace(db->base_port_name);	//it's called route in doc
		removeTrailingSpace(db->blrnode);
		int portLen = strlen(db->base_port_name);
		int blrnodeLen = strlen(db->blrnode);
		if (portLen + blrnodeLen + 1 > sizeof(mem->port)-1)
		{
			OTraceError("E-SHC-165076:Automatically generated port name[%s-%s] too long, max (%d) chars. entry not loaded.\n", 
			db->base_port_name, db->blrnode, sizeof(mem->port)-1);
			return -1;
		}
		snprintf(mem->port, sizeof(mem->port), "%s-%s", db->base_port_name, db->blrnode);
	}
	else
	{
		//binroute_ext entry not set, use route/base_port_name as port
		strcpy(mem->port,  db->base_port_name);
	}

	strcpy(mem->cfg, db->cfg);
	mem->initStatus = db->init_status;
	mem->echo = db->echo;
	mem->priority = db->priority;
	if (strcmp(mem->node, mbcurrentnode)==0)
		mem->mailboxId = find_outbound(mem->mailbox);
	else
		mem->mailboxId = -1;

	strcpy(mem->blrnode, db->blrnode); //R029275

	if (strcmp(mem->node, mbcurrentnode)==0)
		mem->status = mem->initStatus!=BIN_ROUTE_STATUS_DOWN ? BIN_ROUTE_STATUS_UP : BIN_ROUTE_STATUS_DOWN;
	else
		mem->status = BIN_ROUTE_STATUS_DOWN;

	if(!rm_isMultiVerSupported(0))
		return(0);

	newlyFoundShcBinKey = NULL;
	if(shc_locate_bin(&pkg, mem->institutionid, mem->userbinid) < 0)
	{
		OTraceError("E-SHC-165028:  Institution '%s' Bin '%s' not valid.\n", mem->institutionid, mem->userbinid);
		strcpy(mem->internalid,  "zzzzzzzzzz");
		mem->priority = 9999;
		return -1;
	}
	if (newlyFoundShcBinKey)
		strcpy(mem->internalid,  newlyFoundShcBinKey->bin);
	else
		strcpy(mem->internalid, pkg->bin.networkid);

	mem->siteId = db->site_id;

	mem->hashValue = binRouteObj->getHashValue(mem->internalid);
	return 0;
}

int load_servers()
{
	if(rm_isMultiVerSupported(0))
		return(0);

	int	key_count = 0, text_count = 0;
	int	i;
	struct rules_keytab *keyp;
	struct s_binroute *pTmp;
	char *p = NULL;
	struct shcpkg *pkg;
	bin_t currentBin="";
	int haveRouteUp = 0;

	initSys();
	keyp = rm_getapphead(appid);

	newlyFoundShcBinKey = NULL;

	if((p = rm_getappkey(appid)) == NULL)
		log_msg(FATAL, TO_CC, "F-SHC-165027:couldn't locate the shared memory for binroute!\n");

	for(key_count = 0; key_count < keyp->keysused; key_count++, p+=keyp->keysize)
	{
		pTmp=(struct s_binroute*)p;
		newlyFoundShcBinKey = NULL;
		if(shc_locate_bin(&pkg, pTmp->institutionid, pTmp->userbinid) < 0)
		{
			OTraceError("E-SHC-165028:  Institution '%s' Bin '%s' not valid.\n", pTmp->institutionid, pTmp->userbinid);
			strcpy(pTmp->internalid,  "zzzzzzzzzz");
			pTmp->priority = 9999;
			continue;
		}
		if (newlyFoundShcBinKey)
			strcpy(pTmp->internalid,  newlyFoundShcBinKey->bin);
		else
			strcpy(pTmp->internalid, pkg->bin.networkid);
														
		pTmp->hashValue = binRouteObj->getHashValue(pTmp->internalid);
		if (strcmp(pTmp->node, mbcurrentnode)==0)
			pTmp->status = pTmp->initStatus!=BIN_ROUTE_STATUS_DOWN ? BIN_ROUTE_STATUS_UP : BIN_ROUTE_STATUS_DOWN;
		else
			pTmp->status = BIN_ROUTE_STATUS_DOWN;
	}
	//	>>>	R030592
	if ( isPreferLocalForFailover()  )
		qsort(rm_getappkey(appid), keyp->keysused, keyp->keysize, keys_cmp_local_first);
	else
		qsort(rm_getappkey(appid), keyp->keysused, keyp->keysize, keys_cmp);
	// <<< R030592
	pkg = NULL;
	haveRouteUp = 0;
	pTmp = NULL;
	for(key_count = 0,p = rm_getappkey(appid); key_count < keyp->keysused; key_count++, p+=keyp->keysize)
	{
		pTmp=(struct s_binroute*)p;
		if (!currentBin[0])
		{
			strcpy(currentBin, pTmp->internalid);
			haveRouteUp = 0;
		}
		else if (strcmp(currentBin, pTmp->internalid)!=0)
		{
			if (!haveRouteUp)
			{
				if (shcApp->shcBinObj->setBinPkg(currentBin) < 0)
					OTraceDebug("E-SHC-165078: Invalid bin.Can't find in bin tables\n");
				else
					shcApp->shcBinObj->setInstDown();
			}
			strcpy(currentBin, pTmp->internalid);
			haveRouteUp = 0;
		}
		if (pTmp->status == BIN_ROUTE_STATUS_UP)
			haveRouteUp = 1;
	}
	if (pTmp && !haveRouteUp)
	{
		if (shcApp->shcBinObj->setBinPkg(currentBin) < 0)
			OTraceDebug("E-SHC-165029:Can't find bin [%s]\n");
		else
			shcApp->shcBinObj->setInstDown();
	}
	return(0);
}


int initSys()
{
	char buf[80];
	if (dbm_init() == -1)
	{
		OTraceFatal("F-SHC-165030: Unable to connect to DB Manager : Error: %d\n",
		    errno);
		pexit(1);
	}

	if (rm_init() < 0)
	{
		OTraceFatal("F-SHC-165031: Unable to connect to RuleManager : Error: %d\n",
		    errno);
		pexit(1);
	}

	/* Get pin and key pointers */

	if (shc_initsys() < 0)
	{
		OTraceFatal("F-SHC-165032: INITSYS Failed : Error: %d\n", errno);
		pexit(1);
	}

	return(0);
}


/*
 *	alf: just a comment, this function is called when you issue a
 *
 *	"mbrulecmd update shared-cash-extbin" command.
 *
 *	For external bin, it doesn't make much sense to update it,
 *	unless you will never stop the share. Or I should update the
 *	shared memory in split second rather than attach to it and
 *	update record by record.
 *	
 *	Here is the update:  because you have credit and debit, so
 *	you can just do a update all, even you just partially update,
 *	the result will still be update all.
 */
int update_record()
{
	/* Now I can actualy initialise my table */

	int	key_count = 0, text_count = 0;
	int	i,n;
	struct rules_keytab *keyp;
	BINROUTE binRouteDB;
	char *tmpMem;
	struct RoutingInfo r = { 0 };
	struct s_binroute **pLink = NULL;
	char *p;
	struct shcpkg *pkg = NULL;
	
	/* for debug */
	static	int		recordnum = 0;

	int ind[16];	//	---	R020436 
	long buf[1024];
	struct s_binroute	*pTmp = (struct s_binroute *)buf;

	initSys();

	if(rm_isMultiVerSupported(0))
	{
		int version = 0;
		rm_init();
		if(rm_createNewVersion(appid, &version) < 0)
		{
			OTraceError("E-SHC-165064: Unable to create new version\n");
			return 0;
		}
		return 0;
	}

	DBMHSTMT shQuery;
	DBMHDBC ch;	
	DBMRETURN ret = 0;
	if (dbm_connect() >=0)
	{
		OTraceDebug("D-SHC-165033:Connecting to database successful\n");
		ch=dbm_dbconn;
	}
	else
	{
		OTraceError("E-SHC-165034: Connecting to database failed\n");
		return (-1);
	}
	char sqlStatementQuery[512]="select institutionid, userbinid, node, binroute_group, port, cfg, init_status, echo, priority, base_port_name, blrnode, inst_profile_id from binroute";
	if (shouldLoadExtTable())
	{
		strcpy(sqlStatementQuery, "select b.institutionid, b.userbinid, b.node, b.binroute_group, b.mailbox, e.sub_route, "
										"b.cfg, b.init_status, b.echo,  b.priority,"
										"b.port, e.forwarding_node, b.site_id, b.inst_profile_id  from binroute b full outer join binroute_ext e "
										"on b.site_id=e.site_id AND b.node = e.node AND b.port = e.route"); 
	}

	if( DBMAllocStmt(ch, &shQuery) < 0)
	{
		OTraceError("E-SHC-165035: Select query statement allocate error:\n%s\n", sqlStatementQuery);
	}
	if( (DBMBindCol(shQuery,1,DBM_STRINGTYPE,binRouteDB.institutionid,sizeof(binRouteDB.institutionid),&ind[0]) != DBM_SUCCESS) ||
			(DBMBindCol(shQuery,2,DBM_STRINGTYPE,binRouteDB.userbinid,sizeof(binRouteDB.userbinid),&ind[1]) != DBM_SUCCESS) ||
			(DBMBindCol(shQuery,3,DBM_STRINGTYPE,binRouteDB.node,sizeof(binRouteDB.node),&ind[2]) != DBM_SUCCESS) ||
			(DBMBindCol(shQuery,4,DBM_STRINGTYPE,binRouteDB.binroute_group,sizeof(binRouteDB.binroute_group),&ind[3]) != DBM_SUCCESS) ||
			(DBMBindCol(shQuery,5,DBM_STRINGTYPE,binRouteDB.mailbox,sizeof(binRouteDB.mailbox),&ind[4]) != DBM_SUCCESS) ||
			(DBMBindCol(shQuery,6,DBM_STRINGTYPE,binRouteDB.port,sizeof(binRouteDB.port),&ind[5]) != DBM_SUCCESS) ||
			(DBMBindCol(shQuery,7,DBM_STRINGTYPE,binRouteDB.cfg,sizeof(binRouteDB.cfg),&ind[6]) != DBM_SUCCESS) ||
			(DBMBindCol(shQuery,8,DBM_CHARTYPE,&binRouteDB.init_status,sizeof(binRouteDB.init_status),&ind[7]) != DBM_SUCCESS) ||
			(DBMBindCol(shQuery,9,DBM_CHARTYPE,&binRouteDB.echo,sizeof(binRouteDB.echo),&ind[8]) != DBM_SUCCESS) ||
			(DBMBindCol(shQuery,10,DBM_LONGTYPE,&binRouteDB.priority,sizeof(binRouteDB.priority),&ind[9]) != DBM_SUCCESS) ||
			(DBMBindCol(shQuery,11,DBM_STRINGTYPE,binRouteDB.base_port_name,sizeof(binRouteDB.port),&ind[10]) != DBM_SUCCESS) ||
			(DBMBindCol(shQuery,12,DBM_STRINGTYPE,binRouteDB.blrnode,sizeof(binRouteDB.blrnode),&ind[11]) != DBM_SUCCESS)||
			(DBMBindCol(shQuery,13,DBM_LONGTYPE,&binRouteDB.inst_profile_id,sizeof(binRouteDB.inst_profile_id),&ind[12]) != DBM_SUCCESS)
		)
	{
		OTraceError("E-SHC-165036: Select query bind error \n");
		return (-1);
	}
	else
	{
		if( DBMPrepare(shQuery, sqlStatementQuery) != DBM_SUCCESS )
		{
			OTraceError("E-SHC-165037: Select query prepare error:\n%s \n", sqlStatementQuery);
		}
		
		ret = DBMExecute(shQuery);
		if(ret != DBM_SUCCESS)
		{
			if(processError(ret, ch))
			{
				DBMFreeStmt(shQuery, DBM_DROP);
				return (-1);
			}

		}
	}
				/*	Insert the key */
	keyp = rm_getapphead(appid);
	tmpMem = (char *)calloc(keyp->keysize, keyp->nkeys);
	if (!tmpMem )
	{
		OTraceError("E-SHC-165038:can't allocate %d bytes\n", keyp->keysize*keyp->nkeys);
		DBMFreeStmt(shQuery, DBM_DROP);
		return -1;
	}
	pLink = (struct s_binroute **)calloc(sizeof(pTmp), keyp->nkeys);
	if (!pLink )
	{
		OTraceError("E-SHC-165039:can't allocate %d bytes\n", sizeof(pTmp)*keyp->nkeys);
		DBMFreeStmt(shQuery, DBM_DROP);
		return -1;
	}
	for(key_count = 0;;key_count++)
	{
		recordnum ++;
		memset((char *)&binRouteDB, 0, sizeof(binRouteDB));
		ret = DBMFetch(shQuery);
		if ((ret != DBM_SUCCESS)&&(ret != DBM_SUCCESS_WITH_INFO))
		{
			if(processError(ret, ch))
			break;
		}
		else
		{
			if (!shouldLoadRemoteSite() && (binRouteDB.site_id  && (binRouteDB.site_id != mbGetSiteId())))
				continue;

			memset(pTmp, 0, sizeof(*pTmp));

			fillStaticInfo(pTmp, &binRouteDB);
			newlyFoundShcBinKey = NULL;
			if(shc_locate_bin(&pkg, pTmp->institutionid, pTmp->userbinid) < 0)
			{
				OTraceError("E-SHC-165040:  Institution '%s' Bin '%s' not valid.\n", pTmp->institutionid, pTmp->userbinid);
				pTmp->priority = 9999;
				continue;
			}
			if (newlyFoundShcBinKey)
				strcpy(pTmp->internalid,  newlyFoundShcBinKey->bin);
			else
				strcpy(pTmp->internalid, pkg->bin.networkid);

			pTmp->hashValue = binRouteObj->getHashValue(pTmp->internalid);
	
			memcpy(&tmpMem[key_count*keyp->keysize], pTmp, keyp->keysize);
		}
	}
	//	>>>	R030592
	if ( isPreferLocalForFailover()  )
		qsort(tmpMem, key_count, keyp->keysize, keys_cmp_local_first);
	else
		qsort(tmpMem, key_count, keyp->keysize, keys_cmp);
	
	for (i = 0, p = tmpMem;i<key_count;i++, p+=keyp->keysize)
	{
		pTmp = (struct s_binroute *)p;
		binRouteObj->useRoute(pTmp, &r, NULL);
		strcpy(getRouteEntriesBinrouteGroup, pTmp->binrouteGroup);
		n=binRouteObj->getRouteEntries(pTmp->internalid, &r);
		if (n > 0)
			pLink[i] = binRouteObj->getRoute(n-1);
		else
			pLink[i] = NULL;
	}
	
	for (i = 0, p = tmpMem;i<key_count;i++, p+=keyp->keysize)
	{
		pTmp = (struct s_binroute *)p;
		if (!pLink[i])
		{
			pTmp->status = pTmp->initStatus;
			continue;
		}
		pTmp->status = pLink[i]->status;
		memcpy(pTmp->balanceInfo, pLink[i]->balanceInfo, sizeof(pTmp->balanceInfo));
	}
	
			/* 	R023095 >> */
	if ( rm_lockAppid(appid) < 0 )
	{
		OTraceWarning("W-SHC-165040.0: rm.appid[%d] locked by other, grab lock after 1 sec\n", appid);
		sleep(1);
		rm_unlockAppid(appid);
		rm_lockAppid(appid);
	}
	else
	{
		OTraceDebug("D-SHC-165040.1: Locked appid[%d] successfully, memcpy by size[%ld]\n", 
				appid,  key_count*keyp->keysize); //R028747
	}
	
	memcpy(rm_getappkey(appid), tmpMem, key_count*keyp->keysize);
		
	rm_unlockAppid(appid);
	OTraceDebug("D-SHC-165040.2: Unlocked rm.appid[%d]\n", appid);
			/* 	R023095 << */

	keyp->keysused = key_count;
	
	return 0;
}

/* This function is for debug purpose */
int dump_records()
{
	int dbi, i, memoryi;
	struct rules_keytab *keyp;
	struct s_binroute	*pTmp;
	char *p = NULL;

	initSys();

	if(binRouteObj->setBnrtRuleParam() < 0)
		return -1;

	if((p = rm_getappkey(appid)) == NULL)
		log_msg(FATAL, TO_CC, "F-SHC-165041:couldn't locate the shared memory for binroute!\n");

	keyp = rm_getapphead(appid);

	for(i = 0; i < keyp->keysused; i++, p+=keyp->keysize)
	{
		pTmp=(struct s_binroute *)p;
		OTraceDebug("D-SHC-165042: %s:%s:%s:\n", 
			pTmp->institutionid,pTmp->userbinid,pTmp->internalid);
		OTraceDebug("D-SHC-165043: %s:%s:%s:%s:%s:\n",
			pTmp->node, pTmp->binrouteGroup, pTmp->mailbox, pTmp->port, pTmp->base_port_name);
		OTraceDebug("D-SHC-165044: status[%c] flag[%x] cfg[%s] initStatus[%c]\n",
			pTmp->status?pTmp->status:' ',pTmp->flag,pTmp->cfg,pTmp->initStatus?pTmp->initStatus:' ');
		OTraceDebug("D-SHC-165045: echo[%c] priority[%d] hash[%ld]\n",
			pTmp->echo,pTmp->priority, pTmp->hashValue);
		OTraceDebug("D-SHC-165046: balancer node[%s]\n",pTmp->blrnode); //
		OTraceDebug("D-SHC-165047: balance info:\n");
		dump_hex((unsigned char *)pTmp->balanceInfo, sizeof(pTmp->balanceInfo));
	}

	dbm_close_all(getpid());

	return( 0 );
}

int pexit(int n)
{
	HaPtmCctHelper::cleanUp() ;

	OTraceOff();
	return(0);
}

int processError(int ret, DBMHSTMT sh)
{
    int recnum=1;
    char sqlstate[6];
    int native_error;
    char msg_text[2048];
    switch(ret)
    {
    case DBM_SUCCESS_WITH_INFO:
        return false;
    case DBM_NO_DATA:
    	OTraceDebug ("D-SHC-165047:End of data\n");
		return true;
    case DBM_ERROR:
        while(DBMGetDiagRec(DBM_HANDLE_STMT, sh, recnum++,
                sqlstate, &native_error, msg_text, sizeof(msg_text), NULL)
                == DBM_SUCCESS)
        {
            OTraceError("E-SHC-165048:%s\n", msg_text);
        }
        if (recnum <= 2)
        {
            OTraceError("E-SHC-165049:Unknown DB error:%d\n", ret);
        }
        return true;
    case DBM_INVALID_HANDLE:
        OTraceError("E-SHC-165050:Invalid handle(internel error)\n");
        return true;
    default:
        OTraceError("E-SHC-165051:Unknow db error:%d\n", ret);
        return true;
    }
}					

int find_outbound(char *outroute)
{
	int outbound;
	int i;

	outbound	= mb_locateoutbound(outroute);
	if(outbound < 0)
	{
		/*	This guy is not here
		 *	1.	Create it
		 *	2.	Duplicate it
		 *	3.	Find outbound
		 */
		if((i = mb_createmailbox(outroute, 0, 0)) < 0)
		{
			OTraceFatal("F-SHC-165052: Unable to create an entry for: %s\n", outroute);
			return(-1);
		}

		if(mb_duplicatemailbox(i) < 0)
		{
			OTraceFatal("F-SHC-165053: Unable to duplicate mail box: %d for entry %s\n",
				i, outroute);
			return(-1);
		}
		outbound = mb_locateoutbound(outroute);
		if(outbound < 0)
		{
			OTraceWarning("W-SHC-165054: Unable to locate outbound entry for: %s\n", outroute);
			return(-1);
		}
	}

	return(outbound);
}

// >>> R029583
int loadBnrtRuleParam()
{
	if(rm_init() < 0)
	{
		OTraceFatal("F-SHC-165066: Unable to connect to Rule Manager\n");
		pexit(1);
	}

	if (appid == -1)
	{
		appid = rm_getappid(BIN_ROUTE_MESSAGE_NAME);
		if (appid < 0)
		{
			OTraceDebug("D-SHC-165067:Failed to get appid. Abort key init\n");
			syslg("D-SHC-165067:Failed to get appid. Abort key init\n");
			return -1;
		}
	}

	if(!rm_isMultiVerSupported(0))
		return(0);

	if ( rm_attach( appid, initversion ) < 0)
	{
		OTraceError("E-SHC-165068: Unable to attach to LOADING version \n");
		syslg("E-SHC-165068: Unable to attach to LOADING version. Abort updating/init shc-bin-route\n");
		return(-1);
	}

	if (rm_appCreateSemaphore( appid, "SHBR" ) < 0)
	{
		OTraceError("E-SHC-165069: Unable to create semaphore.  Abort updating/init shc-bin-route.\n");
		syslg("E-SHC-165069: Unable to create semaphore. Abort updating/init shc-bin-route.\n");
		return(-1);
	}

	//R029948 >>> Check if shared-cash rule is loaded
	int shcbinAppid = rm_getappid(SHC_MESSAGE_NAME);
	if(shcbinAppid < 0)
	{
		OTraceError("E-SHC-165070: Failed to get shared-cash appid. Abort init.\n");
		syslg("F-SHC-165070: Failed to get shared-cash appid. Abort init.\n");
		return -1;
	}
	while(rm_waitstate(shcbinAppid, RULES_VER_CURRENT, RM_STATE_READY, 2 ) != 0)
	{
		OTraceError("E-SHC-165071: shared-cash rule not yet ready ...sleeping for 5 seconds\n");
		sleep(5);
	}
	OTraceDebug("D-SHC-165072: Shared-cash rule is ready\n");
	//R029948 <<<
	return (0);
}
// <<< R029583

