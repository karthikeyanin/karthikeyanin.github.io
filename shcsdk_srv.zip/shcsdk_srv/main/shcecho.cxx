static char _shcecho_cxx_what[] =  "@(#) shcecho.cxx 1.21.17.4 17/10/07 12:05:57";
static char ver[]="@(#) shcecho.cxx 1.21.17.4 17/10/07 12:05:57";

/*
 *  Copyright (C) 2004 eFunds Corporation ("eFunds").  All Rights Reserved.
 *  eFunds Canada Corporation is an authorized user.
 *
 *  IST is a registered trademark of eFunds Corporation.  Other brand or
 *  product names are trademarks or registered trademarks of their respective
 *  holders.
 *
 *  The information contained herein is the unpublished proprietary property
 *  of eFunds.  Except as specifically authorized in writing by eFunds, the
 *  holder of this document shall: i) keep all information contained herein
 *  confidential, and ii) protect the information, in whole or in part, from
 *  disclosure and dissemination to all third parties.
 *
 *  This document and the software described in it are furnished under license
 *  and may be used or copied only in accordance with the terms of such license.
 *  This document is supplied for information purposes only, is subject to
 *  change without notice, and should not be construed as a commitment by
 *  either eFunds Corporation or eFunds Canada Corporation.
 */
/*
 *
 *                        MODIFICATION HISTORY                  REVIEW
 *
 *	SPR#	Who	Date	Description			Who	Date
 * ===========================================================================
 *	ad		30dec91		Changed calls to shc_setdown into calls to
 *						shc_markdown().
 *	ad		24Feb92		Do not depend on last activity time.
 *
 *	ad		20nov92		Make sure that echo_time is greater then echo_timeout
 *						so that we wait for echo to expire before we send
 *						another.
 *	jsg		11May95		Call sem_exit() in echoexit() to ensure that this
 *						process has not locked the mailbox semaphore, which
 *						must be acquired before deleting it's private mbox.
 *  R001835 qd 21may99  Interac Merge
 *	R003897 HJ 01Nov99	Locate event by key and mailbox id
 *	R005830 jy 03Apr01	Removed wrong condition for time-out events
 *  R007062	gbeeng	26Nov2001	C++ Migration
 *  R010191 Emj 03Oct03 Add txnSrc when generating echo message
 *  R016386 spa	11May06	Fill values in shcmsg first
 *R00xxxx jyang 06Mar08 Bin route support
 *	R027876 dipa  02Mar10  Segment Changes
 *	R027876 dipa  22Apr10  Segment Changes - fix
 *	R028271 dipa  18Jun10  Txn Statistics
 *	R028305 dipa  09Jul10  CCT and PTM
 *  R029553 Emj   25Jun11  Use local ShcmsgHeader instead of global ShcmsgHeader
 *  R030207 dipa  03Feb12  Clone of R029189[support shcecho singleton,remove HA_SWITCH macro]
 *  R030xxx dipa  01Mar12  Txnstat changes + remove TXNSTAT macro
 *  R030556 dipa  23May12  Shm versioning changes
 *  R031106 dipa  25Feb13  Clone of R031106
 *  IST_S761SP8-46 dipa  16Apr14 Clone of IST_S761_HIST-7[Locate inetitution profile entry in shcecho process]
 */

//File Number 136

#include <stdio.h>
#include <string.h>
#include <signal.h>
#include <errno.h>
#include <oasis.h>
#include <ist_otrace.h>
#include <mb.h>
#include <tm.h>
#include <rules.h>
#include <shc.h>
#include <ShcmsgHeader.h>
#include <ShcApp.h>
#include <ShcHelper.h>
#include <ShcmsgHelper.h>
#include <ShcBin.h>
#include <ShcNetworkMsgHelper.h>
#include <BinRoute.h>
#include <SingletonBase.h>
#include <ist_seg_name.h> //R027876
#include <ist_seg_elf_id_map.h> //R027876
#include <ist_seg_id.h> //R027876

//R028271 >>>
#include <TxnStat.h>
//<<< R028271
#include <ShcSharedMemoryHelper.h>

#include <HaPtmCctHelper.h>
#include <InstProfile.h>
#include <istsafe.h>

SingletonBase *echoSingletonObj=NULL;

bool echo_timeout_bindown_flag=false;
bool echo_response_no_signon=false;

class ShcEchoParamsList : public InstParamsList
{
    public:
    virtual void Load();
    virtual ShcEchoParamsList* clone() {return(new ShcEchoParamsList(*this));};

	int getEcho_timeout() { return echo_timeout; }
	int getEcho_repeat_count() { return echo_repeat_count; }

    private:
	int		echo_timeout;		/*	time we allow before msg. times out */
	int		echo_repeat_count;		/*	max number of repeats before we set */
};

InstitutionParams shcEchoParams;

/*
 *	This program wakes up every 'n' seconds and sends an echo request
 *	to all institutions which have not had activity or are down.
 */
extern "C"
{
	void	echoexit(int);
	void SendEcho(int dummy);
	void SetEchoFlg(int dummy);
}
int Initialise();
int Process();
int ProcessTimeout(ShcmsgHeader *header);
int ProcessTimeout(struct shc *shcmsg);
int GenerateEcho(struct shcpkg *pkg, int count);
int GenerateEcho(struct shcpkg *pkg, int count, struct s_binroute *pBinRoute);

#define MAILBOX_NAME	"SharedEcho"

int		echo_time		= 120;		/*	default */

int		sleep_time		= 60;
int		minimum_time	= 10;		/*	minimum time allowed between sleep */
int		mbid			= (-1);
bool		flg_sendecho	= false;

ShcApp	*shcechoApp = NULL;
ShcBin	*shcBin = NULL;
static ShcmsgWithSegment oMsg = { 0 };
static struct shcmsg *eventMsg = &oMsg.msg;

int ProcessReply(ShcmsgHeader *header); /* R001835 */
static struct rules_keytab *pShcAppHead = NULL;

int main(int argc, char **argv)
{
	argv0 = *argv;
	syslg("%s\n", ver);
	OTraceOn(argv0);
	OTraceDebug("D-SHC-136001:%s\n", ver);
	catch_all_signals(echoexit);

	HaPtmCctHelper::init() ;

	mb_init();
	dbm_init();

	shcechoApp = new ShcApp;
	shcBin = (ShcBin *)shcHelperRegister.getTargetObj(SHC_ShcBin);

	shc_init();
	Initialise();
	TxnStatSetSrcId( TS_SHCECHO ) ;

	HaPtmCctHelper::addHandler( "system.dcs.shc" ) ;

	Process();
	echoexit(0);
	return(0);
}




void echoexit(int n)
{
	static	int	count=0;

	if(n == 0 || n == SIGTERM)
		syslg("E-SHC-136002: Normal Exit # %d\n", n);
	else
		syslg("E-SHC-136003: Exit due to signal(%d)\n", n);

	/* 11May95
	 * Release semaphore, if locked by this process.
	 */
	if(++count == 1)
		if(sem_exit(MB_BUF_SEM_NAME) == 0)
			OTraceError("E-SHC-136004: Unlocked semaphore '%s' in exit function\n",
				MB_BUF_SEM_NAME);

	if(shcmid >= 0)
		mb_deletemailbox(shcmid);

	HaPtmCctHelper::cleanUp() ;

	OTraceOff();

	if(n > 2)
		kill(getpid(), n);

	exit(n);
}


int Initialise()
{
	int		i;
	char	buf[100];
	ShcEchoParamsList shcEchoParamsList;

	/*	find required mail boxes */
	mbid = mb_locatemailbox(SHC_SERVER_NAME);
	if(mbid < 0)
	{
		OTraceFatal("F-SHC-136005: Shared Cash Server is not active.\n");
		echoexit(0);
	}

	/*	create a private mail box */
	sprintf(buf, "%s.%05d", MAILBOX_NAME, getpid());
	shcmid = mb_createmailbox(buf, getpid(), MB_TAB_PRIVATE);
	if(shcmid < 0)
	{
		OTraceFatal("F-SHC-136006: Unable to create mail box %s\n", buf);
		echoexit(0);
	}

	if(cf_locatenum("shc.echotime", &i) >= 0)
		if(i < minimum_time)
		{
			ODebug("I-SHC-136007:Configured echo time < minimum. Using %d.\n",
				minimum_time);
			echo_time = minimum_time;
		}
		else
			echo_time = i;

	cf_close();


	shcEchoParams.Load(shcEchoParamsList);
	if ( binRouteObj )
	{
		OTraceDebug("D-SHC-136007.1: Found BinRoute configured\n" );
	}

	if (!echoSingletonObj)
		echoSingletonObj = new SingletonBase("echo", echo_time, echo_time*1.2);
	if (!echoSingletonObj)
	{
		OTraceError("Singleton object not created, not singleton support\n");
	}
	return(0);
}

void ShcEchoParamsList::Load()
{
	int i;
	char 		xbuf[20]={'0'};

	if(cf_locatenum("shc.echo_timeout",	&i) >= 0)
		echo_timeout = i;

	if(cf_locatenum("shc.echo_repeat_count", &i) >= 0)
		echo_repeat_count = i;

	cf_locate("shc.echo_timeout_bindown_flag", xbuf);

	OTraceDebug("D-SHC-136018: echo_timeout_bindown_flag[%s]\n", xbuf);

	if(xbuf[0]=='Y' || xbuf[0]=='y')
		echo_timeout_bindown_flag = true;
	else
		echo_timeout_bindown_flag = false;

	/*	20nov92 */
	if(echo_time <= echo_timeout)
	{
		OTraceWarning("W-SHC-136008: 'echotime' less then or equal to 'echo_timeout'\n");
		echo_time = 2 * echo_timeout;
	}

	sleep_time = echo_time;

	return;
}

void SendEcho(int dummy)
{
	int	i;
	char *p = NULL;
	struct shcpkg *pTmpPkg = NULL;

	if(mb_test() < 0)
		return;

	shc_get_current_date();
	if (shcSharedMemoryHelperObj->attachCurrent(&shcAppid, &pShcAppHead) < 0)
	{
		OTraceError("E-SHC-136037:can't find shcard-cash, abort sendEcho.\n");
		return;
	}

	for(i = 0, p = rm_getapptext(shcAppid); i < pShcAppHead->textused; ++i, p+=pShcAppHead->textsize)
	{
		/*
		 * R001835 Let AILECHO handle his own
		 */
		pTmpPkg = (struct shcpkg *)p;
		if(shcBinIsInterac((pTmpPkg)))
			continue;

		int numOfRoute = binRouteObj ? binRouteObj->getRouteEntries( pTmpPkg->bin.networkid, NULL ) : 0;
		if ( numOfRoute > 0 )
		{
			struct s_binroute *pBinRoute = NULL;
			for ( int j=0; j<numOfRoute; j++ )
			{
				pBinRoute = binRouteObj->getRoute(j);

				if ( (!pBinRoute) || (pBinRoute->node[0] && strcmp(pBinRoute->node, mbcurrentnode)!=0) )
					continue;

				if ( pBinRoute->echo == BIN_ROUTE_ECHO_NEVER )
				{
					continue;
				}

				if ( pBinRoute->echo==BIN_ROUTE_ECHO_DOWN && pBinRoute->status!=BIN_ROUTE_STATUS_DOWN )
				{
					if(shcEchoDown(pTmpPkg) && shc_isdown(pTmpPkg))
					{
						OTraceDebug("D-SHC-136015: bin(%s) is down! send echo\n",pTmpPkg->bin.networkid);
						GenerateEcho(pTmpPkg, 0, pBinRoute);
					}
					continue;
				}
				if ( pBinRoute->echo==BIN_ROUTE_ECHO_DOWN_CONNECTED)
				{
					if(pBinRoute->status!=BIN_ROUTE_STATUS_DOWN )
						continue;
					int portid =  mb_locatemailbox(pBinRoute->port);

					if (portid < 0)
						continue;

					if (!mbPortIsConnected(mbMailBoxGetPortId(portid)))
					{
						continue;
					}
				}
				if ( pBinRoute->echo==BIN_ROUTE_ECHO_UP && pBinRoute->status!=BIN_ROUTE_STATUS_UP )
				{
					continue;
				}

				if ((pBinRoute->base_port_name[0]) && (pBinRoute->status==BIN_ROUTE_STATUS_UP))
				{
					if ( (echoSingletonObj)&&(echoSingletonObj->start(pBinRoute->base_port_name) < 0 ))
					{
						OTraceDebug("D-SHC-136014: echo key '%s' locked by other process\n", pBinRoute->base_port_name);
						continue;
					}
				}
				if ( pBinRoute->echo==BIN_ROUTE_ECHO_ONLY_IF_BIN_UP && shc_isdown(pTmpPkg) )
				{
					OTraceDebug("D-SHC-136015 Bin down, do not send echo\n" );
					continue;
				}
				if(pBinRoute->cfg[BINROUTE_CFG_IDX_ECHO_SIGNON_ACTION] == BINROUTE_CFG_NO_SIGNON_AFTER_ECHO)
				{
					echo_response_no_signon = true;
				}
				GenerateEcho(pTmpPkg, 0, pBinRoute);
			}
		}
		else
		{
			if(!shcNeedsEcho(pTmpPkg))
				continue;

			if (pTmpPkg->bin.node[0] && (strcmp(pTmpPkg->bin.node, mbcurrentnode)!=0))
				continue;
			/*	do we only echo when down? */
			if(shcEchoDown(pTmpPkg) && !shc_isdown(pTmpPkg))
				continue;

			/*	needs an echo test */
			GenerateEcho(pTmpPkg, 0);
		}
	}

}



int Process()
{
	struct	ShcWithSegment	shcmsg;
	int		sender;
	int		time_left;
	int 	len;

	time_left = sleep_time;

	HaPtmCctHelper::prepare() ;

	for(;;)
	{
		if( HaPtmCctHelper::checkBefore() != 0 )
		{
			OTraceInfo( "I-SHC-1326012.1: Terminate due to HaPtmCct\n" );
			syslg( "I-SHC-1326012.1: Terminate due to HaPtmCct\n" );
			break ;
		}

		//	prevent invalid alarm time 
		if( time_left <= 0 )	time_left = sleep_time ;

		memset(&shcmsg, 0, sizeof(shcmsg));
		if ( flg_sendecho )
		{
			SendEcho(0);
			flg_sendecho = false;
		}

		signal(SIGALRM, SetEchoFlg);
		alarm(time_left);

		len = mb_read( shcmid, &(shcmsg.shc).msg, sizeof(struct ShcmsgWithSegment) ) ;

		time_left = alarm(0);
		signal(SIGALRM, SIG_IGN);

		if( len < 0 )
		{
			if( mb_test() < 0 ) break ;
			time_left = sleep_time;
			continue ;
		}

		sender = mbLastSenderId();
		OTraceLog("L-SHC-136013: Received %d bytes from %s ID[%s] /m%04d %s\n",
				len, mbMailBoxName(sender),
				shcmsg.shc.msg.shclog_id, shcmsg.shc.msg.msgtype,
				mbIsEvent()?"(event)":"");


		//R028271 >>>
		if (strlen(shcmsg.shc.msg.shclog_id))
			TxnStatReport(shcmsg.shc.msg.shclog_id, TS_SHC,TSR_RECEIVE,shcmsg.shc.msg.msgtype,0,sender);
		//<<< R028271

		ShcmsgHeader header(&shcmsg.shc.msg);
		if(mbIsEvent())
			/*	If I got an event then an echo request has timed out
				Step one is to try again
				Step two is to shut the institution down
			*/
			ProcessTimeout(&header);
		else
			/*
			 *	I got a reply to a previous 800: All is well
			 */
			ProcessReply(&header);
	}

	return(0);
}



int ProcessTimeout(ShcmsgHeader *header)
{
	/*	Timeout of an echo request */
	int		event;
	int		count;
	ShcEchoParamsList *shcEchoParamsList;

	event = mbLastEvent();

	tm_dequeue(event);

   OTraceInfo("I-SHC-136009: Time out of echo test to %s trace %d\n",
			header->msg.issuer, header->msg.trace);

   	if (strlen(header->msg.shclog_id)>0)
	{
		OTraceDebug("D-SHC-136010: shclog_id [%s]\n",header->msg.shclog_id);
		TxnStatReport(header->msg.shclog_id, TS_SHC,TSR_FINISH,header->msg.msgtype,STATUS_BUSIMON, 0);
	}

	if(echo_timeout_bindown_flag == true)
	{
		OTraceInfo("I-SHC-136009a: trying to bring down the binroute...\n");
		shcechoApp->shcmsgHelperObj->shcGetIssAcq(header,0);
		int len = 0;
		struct RoutingInfo pRoutingInfo = {0};
		struct s_binroute *qBinRoute = NULL;
		struct RoutingInfo all_routingInfo = {0};


		len = sizeof(struct RoutingInfo);
		header->getSegmentData((char *)&pRoutingInfo, &len, ElfIdMap::elf_to_id(IST_SEG_NETWORK_DATA_REQ),ROUTING_INFO);

		if (len<=0)
		{
			len = sizeof(struct RoutingInfo);
			header->getReqSegmentData((char *)&pRoutingInfo, &len, ElfIdMap::elf_to_id(IST_SEG_NETWORK_DATA_REQ),ROUTING_INFO);
		}
		struct InstitutionProfile ip = { 0 };
		len = sizeof(ip);
		header->getSegmentData((char *)&ip, &len, NETWORK_DATA_REQ_id, ISS_INST_PROFILE_ENTRY);
		if (len <= 0)
		{
			len = sizeof(ip);
			header->getReqSegmentData((char *)&ip, &len, NETWORK_DATA_REQ_id, ISS_INST_PROFILE_ENTRY);
		}

		if (len > 0)
		{
			istsafe_strcpy(getRouteEntriesBinrouteGroup,sizeof(getRouteEntriesBinrouteGroup), ip.binrouteGroup);
		}
		else
			OTraceDebug("D-SHC-107871:No binroute group info found.\n");
		OTraceDebug("D-SHC-107872: pRoutingInfo.flag[%ld].\n", pRoutingInfo.flag&ROUTE_INFO_FLAG_USE_BINROUTE );

		if ( binRouteObj && len>0 && pRoutingInfo.flag&ROUTE_INFO_FLAG_USE_BINROUTE )
		{
			OTraceDebug("D-SHC-107873: Mark Down Bin(%s)\n", header->issShcBin->binPkg->bin.networkid );
			binRouteObj->markRouteDown( header->issShcBin->binPkg->bin.networkid, &pRoutingInfo, NULL );
		}
	}
	return(0);
#if 0
/***	20nov92	Ignore the rest of the code until we have a
		flag which allows us to count number of failed echo's
***/
	shc_get_current_date();
	count = shcmsg->msg.trace / 100000L;
	++count;
	shc_get_bin_entries(shcmsg);

	shcEchoParamsList=shcEchoParams->getInst(shcmsg->issbin.shcbin.institutionid);
	if(count > shcEchoParamsList->getEcho_repeat_count)
	{
		shc_markdown(shcmsg, shcmsg->issbin);
	}
	else
		GenerateEcho(shcmsg->issbin, count);
#endif
}


int ProcessReply(ShcmsgHeader *header)
{
	ShcmsgHeader tmpHeader;
	/*	04feb93		added all this stuff */

   OTraceInfo("I-SHC-136010: Replay of 0800 issuer %s trace %d\n",
		header->msg.issuer, header->msg.trace);

	if((header->eventId = tm_locate_event(header->msg.trace,-1,shcmid,NULL)) < 0)			/* R003897 */
	{
		OTraceFatal("F-SHC-136011: Unable to locate event for echo %ld\n", header->msg.trace);
		return(0);
	}
	else
	{
		tm_getdata( header->eventId, (char *)eventMsg, sizeof(struct ShcmsgWithSegment));
		tm_dequeue(header->eventId);
		header->allocateAndCopyReqMsg(eventMsg);
		shcechoApp->shcmsgHelperObj->shcGetIssAcq(header,0);



		int len = 0;
		struct RoutingInfo pRoutingInfo = {0};

		// R027876 >>>
		len = sizeof(struct RoutingInfo);
		header->getSegmentData((char *)&pRoutingInfo, &len, ElfIdMap::elf_to_id(IST_SEG_NETWORK_DATA_REQ),ROUTING_INFO);
		// <<< R027876
		if (len<=0)
		{
			len = sizeof(struct RoutingInfo);
			header->getReqSegmentData((char *)&pRoutingInfo, &len, ElfIdMap::elf_to_id(IST_SEG_NETWORK_DATA_REQ),ROUTING_INFO);
		}


		struct InstitutionProfile ip = { 0 };
		len = sizeof(ip);
		header->getSegmentData((char *)&ip, &len, NETWORK_DATA_REQ_id, ISS_INST_PROFILE_ENTRY);
		if (len <= 0)
		{
			len = sizeof(ip);
			header->getReqSegmentData((char *)&ip, &len, NETWORK_DATA_REQ_id, ISS_INST_PROFILE_ENTRY);
		}
		if (len > 0)
		{
			istsafe_strcpy(getRouteEntriesBinrouteGroup,sizeof(getRouteEntriesBinrouteGroup), ip.binrouteGroup);
		}
		else 
			OTraceDebug("D-SHC-107071:No binroute group info found.\n");



		if ( binRouteObj && len>0 && pRoutingInfo.flag&ROUTE_INFO_FLAG_USE_BINROUTE )
		{
			if(echo_response_no_signon)
			{
				binRouteObj->markRouteUp( header->issShcBin->binPkg->bin.networkid, &pRoutingInfo, 0 );
			}
			else
			{
				int needBinUp = 0;
				binRouteObj->markRouteUp( header->issShcBin->binPkg->bin.networkid, &pRoutingInfo, &needBinUp );

				if( shc_isdown(header->issShcBin->binPkg) && needBinUp )
				{
					//				shcBin->setBinPkg(shcmsg->issbin);
					shcechoApp->shcNetworkMsgHelperObj->shc_setup(header, header->issShcBin);
				}
			}
		}
		else
		{
			if( shc_isdown(header->issShcBin->binPkg))
			{
				/*	Set him up */
//				shcBin->setBinPkg(shcmsg->issbin);
				shcechoApp->shcNetworkMsgHelperObj->shc_setup(header, header->issShcBin);
			}
		}
	}
	return(0);
}



int GenerateEcho(struct shcpkg *pkg, int count)
{
	return GenerateEcho(pkg, count, NULL);
}


int GenerateEcho(struct shcpkg *pkg, int count, struct s_binroute *pBinRoute)
{
	/*
	 *	Generate an echo request and create an event to
	 *	catch time out's
	 *
	 *	The assumption is that shc_current_time contains a valid
	 *	value.
	 */


	ShcmsgHeader tmpHeader;
	int	event;
	ShcEchoParamsList *shcEchoParamsList;

	if ( pBinRoute && pBinRoute->siteId && (pBinRoute->siteId != mbGetSiteId()))
		return 0;	//Ignore remote site binroute

	strcpy(tmpHeader.msg.txnSrc, pkg->bin.institutionid); /* R010191 */
	strcpy(tmpHeader.msg.issuer, pkg->bin.networkid);
	strcpy(tmpHeader.msg.acquirer, pkg->bin.networkid);

	shcEchoParamsList = (ShcEchoParamsList *)shcEchoParams.getInst(pkg->bin.institutionid);

	strcpy(tmpHeader.msg.originator, shc_orgid);

	tmpHeader.msg.trace = shcechoApp->shcNetworkMsgHelperObj->shc_generate_uni_trace();

	/*	04feb93 */
	tmpHeader.msg.senderid = shcmid;
	tmpHeader.msg.netcode = SHC_NET_ECHO_START; /* R005830 for R004688 */

	shcBin->setBinPkg(pkg);

	if ( pBinRoute )
	{
		int ii;
		struct RoutingInfo routingInfo = {0};
		routingInfo.siteId = mbGetSiteId();
		strncpy( routingInfo.destNode, pBinRoute->node,    sizeof(routingInfo.destNode)-1 );
		strncpy( routingInfo.mailbox , pBinRoute->mailbox, sizeof(routingInfo.mailbox)-1 );
		strncpy( routingInfo.srcNode , mbcurrentnode,      sizeof(routingInfo.srcNode)-1 );
		strncpy( routingInfo.port    , pBinRoute->port,    sizeof(routingInfo.port)-1 );
		strncpy( routingInfo.misc    , pBinRoute->misc,    sizeof(routingInfo.misc)-1 );
		routingInfo.time_out = shcEchoParamsList->getEcho_timeout() + shc_current_time;
		routingInfo.flag |= (ROUTE_INFO_FLAG_USE_FOR_REQ | ROUTE_INFO_FLAG_USE_BINROUTE);

		tmpHeader.setSegmentData((char*)&routingInfo, sizeof(routingInfo),
					ElfIdMap::elf_to_id(IST_SEG_NETWORK_DATA_REQ),ROUTING_INFO); //R027876

		struct InstitutionProfile *ip = NULL;
        ip = shcApp->instProfileObj->locateByBinroute(pBinRoute);
        if (!ip)
        {
            OTraceError("E-SHC-136019:Can't find inst_profile for group(%s), bin(%s), port(%s). skip echo for it.\n",
                pBinRoute->binrouteGroup, pBinRoute->internalid, pBinRoute->port);
            return -1;


        }
			tmpHeader.setSegmentData((char *)ip,
				sizeof(struct InstitutionProfile), NETWORK_DATA_REQ_id, ISS_INST_PROFILE_ENTRY);
            tmpHeader.setSegmentData((char *)ip,
                sizeof(struct InstitutionProfile), NETWORK_DATA_REQ_id, ACQ_INST_PROFILE_ENTRY);



		//If the binroue is down, we should send echo and not bothered with singleton,
		//otherwise the down route may never go up
		if(pBinRoute->status!=BIN_ROUTE_STATUS_DOWN)
		{
			if (echoSingletonObj)
				tmpHeader.setSegmentData(pBinRoute->base_port_name, strlen(pBinRoute->base_port_name)+1, 
					NETWORK_DATA_REQ_id, BASE_PORT_NAME);
		}
	}

	tmpHeader.time_out = shcEchoParamsList->getEcho_timeout() + shc_current_time;
	shcechoApp->shcNetworkMsgHelperObj->shc_echotest(&tmpHeader, shcBin);

	/*	Enter an event to catch time out of echo tests */
	if (tmpHeader.time_out < 10000000000)
		event = tm_enqueue(shcmid, tmpHeader.time_out,
	   		TM_NOTIFY_ONCE, shcApp->shcmsgHelperObj->shcMakeKey(&tmpHeader),
	   		(char *)&tmpHeader.msg, tmpHeader.truelength());
	else
		event = tm_hires_enqueue(shcmid, tmpHeader.time_out/1000,tmpHeader.time_out%1000*1000000,
	   		TM_NOTIFY_ONCE, shcApp->shcmsgHelperObj->shcMakeKey(&tmpHeader),
	   		(char *)&tmpHeader.msg, tmpHeader.truelength());


	OTraceDebug("D-SHC-136016:Send echo for src[%s]dest[%s]bin[%s]ID[%s]trace[%d]base[%s]\n", 
				tmpHeader.msg.txnSrc, tmpHeader.msg.txnDest, tmpHeader.msg.issuer, 
				tmpHeader.msg.shclog_id, tmpHeader.msg.trace, 
				pBinRoute?pBinRoute->base_port_name:"");
    if (event < 0)
	{
		OTraceFatal("F-SHC-136012: Unable to create event.\n");
		return(-1);
	}

	tm_setflags(event, TM_NOSAVE, 1);
	return(0);
}


void SetEchoFlg(int dummy)
{
	flg_sendecho = true;
}

