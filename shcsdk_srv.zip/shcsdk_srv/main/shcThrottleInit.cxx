//
// Copyright (C) 2004 eFunds Corporation ("eFunds").  All Rights Reserved.  
// eFunds Canada Corporation is an authorized user. 
// 
// IST is a registered trademark of eFunds Corporation.  Other brand or
// product names are trademarks or registered trademarks of their respective
// holders. 
// 
// The information contained herein is the unpublished proprietary property
// of eFunds.  Except as specifically authorized in writing by eFunds, the
// holder of this document shall: i) keep all information contained herein
// confidential, and ii) protect the information, in whole or in part, from
// disclosure and dissemination to all third parties. 
// 
// This document and the software described in it are furnished under license
// and may be used or copied only in accordance with the terms of such license.
// This document is supplied for information purposes only, is subject to
// change without notice, and should not be construed as a commitment by
// either eFunds Corporation or eFunds Canada Corporation. 
//
static char _shcThrottleInit_cxx_what[] = "@(#) shcThrottleInit.cxx 1.12 16/11/08 04:32:16";

/*
 *	IST and IST/Share are registered trademarks of Oasis Technology Ltd.
 *
 *	Copyright (C) 1990 - 1997 Oasis Technology Ltd.
 *	All Rights Reserved
 *	This Module contains Proprietary Information of
 *	Oasis Technology Ltd., and should be treated as Confidential.
 *
 *	THIS IS UNPUBLISHED PROPRIETARY SOURCE CODE OF OASIS TECHNOLOGY LTD.
 *	The copyright notice above does not evidence any  
 *	actual or intended publication of such source code.
 */
/*
 *
 *                        MODIFICATION HISTORY                  REVIEW
 *
 *	SPR#	Who	Date	Description			Who	Date   
 * ===========================================================================
 * R003931 fguo	28Jan00 SHC Throttling
 * R007062	gbeeng	26Nov2001	C++ Migration
 * R029226  dipa    18Mar2011   Shared-memory versioning
 */

//File Number 140

#include <stdio.h>
#include <util.h>
#include <mb.h>
#include <ist_otrace.h>
#include <rules.h>
#include <dbm.h>
#include "shcThrottle.h"

#include <HaPtmCctHelper.h>

/*
 *	An application initialiser is invoked with the following paramaters
 *
 *		<taskname>	<mode>	<rulename>	<appid> <srvname> [<data>]
 *
 *	<taskname>		the executable name of this task		(argv[0])
 *	<mode>			the mode of processing
 *						'count'			count space needed and report to strm
 *						'init'			init the rules in-core database
 *						'update'		update an existing rule
 *						'load'			load you application
 *
 *	<rulename>		the name of the rule to be initialised
 *	<appid>			the system assigned application id for this rule
 *
 *	<srvname>		the server to which count information should be sent
 *
 *	<data>			data which might be included in an 'update' command
 *					The format of the data is
 *						currency-code effdate
 *
 *
 *****************************************************************************
 */
/* R007062 */
int update_record();
int count_records();
int init_records();
int load_servers();

int		con_id = (-1);
struct	rules_keytab keytab = {0};
int		appid;

#define	MAIN_REC	1
int		msgtype = 0;

int		argc = 0;
char	**argv = NULL;

int main(int a_rgc, char **a_rgv)
{
	argv = a_rgv;
	argc = a_rgc;

	argv0 = *argv;
	catch_all_signals(NULL);

	OTraceOn("shcThrottleInit"); 

	HaPtmCctHelper::deinit() ;

	if(argc < 5)
		log_msg(FATAL, TO_CC, "F-SHC-140001:%d is an invalid number of parameters\n", argc);
	
	mb_init();
	shcmid = -1; 

	/*
	 *	Connect to the named server
	 */
	con_id = mb_locatemailbox(argv[RULES_PARM_SRVNAME]);
	if(con_id == -1)
		log_msg(FATAL, TO_CC, "F-SHC-140002:Unable to connect to %s: Error: %d\n",
			argv[RULES_PARM_SRVNAME], errno);
	

	/*
	 *	Extract all paramaters
	 */
	appid = atoi(argv[RULES_PARM_APPID]);
	
	if(stricmp("shc-throttle-params", argv[RULES_PARM_RULENAME]) == 0)
		msgtype = MAIN_REC;
	else
		log_msg(FATAL, TO_CC, "F-SHC-140003:Invalid message type: %s\n", 
					argv[RULES_PARM_RULENAME]);
	
	/*
	 *	Now determine which we need and perform action
	 */
	if(stricmp(argv[RULES_PARM_MODE], "count") == 0)
		count_records();
	else if(stricmp(argv[RULES_PARM_MODE], "init") == 0)
		init_records();
	else if(stricmp(argv[RULES_PARM_MODE], "load") == 0)
		load_servers();
	else if(stricmp(argv[RULES_PARM_MODE], "update") == 0)
		update_record();
	else
		log_msg(FATAL, TO_CC, 
		"F-SHC-140004:I don't know how to interpret mode '%s'\n", argv[RULES_PARM_MODE]);

	HaPtmCctHelper::cleanUp() ;

	exit(0);
	return(0);
}


int count_records()
{
	/*
	 *	Set up my retrun packet
	 */
	keytab.appid = atoi(argv[RULES_PARM_APPID]);

	keytab.keysize	= 1;
	keytab.nkeys	= 1;

	/* keytab.textsize	= 252; *//* should be the size of class shcThrottle */
	keytab.textsize	= shcThrottleSize();
	keytab.ntext	= 1;

	snprintf(keytab.name, sizeof(keytab.name),"%s",argv[RULES_PARM_RULENAME]);
	mb_write_nothrottle(con_id, 0, &keytab, sizeof(keytab));

	return( 0 );
}

int init_records()
{
	OTraceInfo("I-SHC-140005:THROTTLE: SHC Throttling Initialization.\n");
	if (init_throttle("SHC", NULL) < 0) 
		OTraceFatal("F-SHC-140006:THROTTLE: Error in SHC Throttling Initialization.\n");	
	return(0);
}

int load_servers()
{
	return(0);
}

int update_record()
{
	OTraceDebug("D-SHC-140007:THROTTLE: Throttling Update.\n");
	//R029226 >>
	if(rm_isMultiVerSupported(appid))
	{
		int version = 0;
		rm_init();
		rm_createNewVersion(appid,&version);
	}
	//<< R029226
	return(0);
}
