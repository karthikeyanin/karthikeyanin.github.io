static char ver[]="IST:Share Initialisation: r1.0.0 01Jun97";
static char _shcinit_cxx_what[] = "@(#) shcinit.cxx 1.51.13.5 20/02/04 14:16:39";

/*
 *  Copyright (C) 2004 eFunds Corporation ("eFunds").  All Rights Reserved.     
 *  eFunds Canada Corporation is an authorized user.                            
 *                                                                              
 *  IST is a registered trademark of eFunds Corporation.  Other brand or        
 *  product names are trademarks or registered trademarks of their respective   
 *  holders.                                                                    
 *                                                                              
 *  The information contained herein is the unpublished proprietary property    
 *  of eFunds.  Except as specifically authorized in writing by eFunds, the     
 *  holder of this document shall: i) keep all information contained herein     
 *  confidential, and ii) protect the information, in whole or in part, from    
 *  disclosure and dissemination to all third parties.                          
 *                                                                          
 *  This document and the software described in it are furnished under license  
 *  and may be used or copied only in accordance with the terms of such license.
 *  This document is supplied for information purposes only, is subject to      
 *  change without notice, and should not be construed as a commitment by       
 *  either eFunds Corporation or eFunds Canada Corporation. 
 */
/*
 *
 *                        MODIFICATION HISTORY                  REVIEW
 *
 *	SPR#	Who	Date	Description			Who	Date   
 * ===========================================================================
 * 10001959 la  12may96 Use advice directory instead of saf.
 * 10002124 la  29may96 Removed edit for SPR# 10001959.
 * 10001935 la  31may96 Renamed struct shckeys to struct shckeysmem.
 *                      Renamed struct shcsecdb to struct shckeys.
 * 10002243 la  01jul96 Set all bits for send reversal flags.
 * R001538  qd  03mar99 Added CVV2 support 
 * R001654  yh  09Mar99 Change c++ keyword (new) to (new_entry)
 * R001835  qd  20may99 Interac Merge
 * R002563  fg  19Jul99 add declaration shckeys_RstKeys( struct shcpkg *pkgp);
 *                      add #include <shcdef.h>	
 * R003638	kc	10Dec99 COPAC enhancement - new bin type 3 & 4		
 * R004691  jy  30May00 To prevent host form going down on time-out, 
 *						when "Action on Time-out" is set to "N"
 * R004671  Dds 25Jun00 Merge vsdc enhancement to 7.2, refer to 2007336
 * 2007336  Mch 29Feb00 Added support for chip transactions
 * R004324  Emj 18Dec00	TDes and Multiple length Network Keys support
 * R005646	jy	12Feb01	Moved the CVV2 verification condition block 
 *						to correct position
 * R005869  jy  03Apr01 always load posauth server mailbox for ChargeBack
 * R006273  jiz 02Aug01 Put AVS service indicator in shared memory 
 * R007062	gbeeng	26Nov2001	C++ Migration
 *R007883 jyang 02Jun02 Changed "Restore Transmission Time" default as "Y"
 *R008717 ztang 11Nov02 Multi-institution support
 *R008717 Emj   10Jan03 Multi-institution support
 *R009115 Emj 10Feb03 Owner bin id is an external bin id
 *R009248 ztang 24Feb03 Remove spaces from instituion id fields
 *R009267 Emj 25Feb     Left justify institutionid, right justify bin
 *R011307 Emj 18Oct04   Renoved cutoff from Bin structure
 *R011629 Emj 12Aug04 SAF Interleave merged R0011312
 *R015297 sdc 15Dec05	clean memory before initialize shcpkg memory
 *R016425 Emj 17May06   Mark bin down using shcbin class
 *R016654 Emj 19Jun06   Support for keyparams field in ShcBin
 *R020052 spa 21May07	Support SH_CFG_CHECK_MERCHANT flag
 *R020162 emj 01Jun07   Support SH_CFGIX_DCVVCVC3_TYPE 
 *R022481 jyang 29Jan08 Supported for locking shared memory of rules
 *R027905 dipa 25Mar10  Reversal-Void Enhancements
 *R028747 dipa 17Nov10  Remove reference to rules_keytab[]
 *R029258 Emj  31Mar11  Remove load of shckeys now in inst_profile
 *R029957 Dipa 29Sep11  Add brackets to for-loop in format_pinkeys(), to avoid core dump
 *R030556 Dipa 05Jun12  B/w compatibility for SHM versioning
 *R031312 Dipa 27Feb13	Clone of R031019(For shccmd update, locate bin using instid & userbinid )
 *IST_S770SP4-103 Shobana 04Nov15 added shcinit debug enhancement
 */

//File Number 137

#include <stdio.h>
#include <string.h>
#include <oasis.h>
#include <oasisenv.h>
#include<ic/ic_instid.h>
#include<ic/ic_bin.h>
#include <ist_otrace.h>
#include <util.h>
#include <mb.h>
#include <rules.h>

/* R002563 */
#include <DBM3.h>
#include <dbm.h>
#include <dbm_private.h>
#include <shc.h> 
#include <ShcApp.h>
#include <ShcHelper.h>
#include <ShcBin.h>
#include <ShcSafIOHelper.h>

#include <HaPtmCctHelper.h>
#include <ShcSharedMemoryHelper.h>
#include <ShcKeyHelper.h>
#include <istsafe.h>

/*
 *	Example application initialiser
 */

#define DEFAULT_NETMGR	"shcNetworkManager"
#define PKG_NEEDS_OWNER		(-2)
#define PKG_NEEDS_TEXT		(-1)

/* R002563 */
/* int shckeys_RstKeys( struct shcpkg *pkgp ); */

/* R007062 */
extern "C"
{
	int keys_cmp(const void *anykey1, const void *anykey2);
}
int format_entry( struct shcbindb *db, struct shckeysmem *shckeysmem, struct shcpkg *pkg );
int get_keys(struct shcbindb *db, struct shckeysmem *shckeysmem, struct shcpkg * pkg);
int update_record(char *instid, char *binid);
int count_records();
int init_records();
int load_servers();
int find_owners();
int format_record(register struct shcbindb *db, struct shckeysmem *shckeysmem,
			struct shcpkg *pkg, int new_entry);
int find_outbound(char *outroute);
int find_mailbox(const char *name);
int saf_exists(const char *institutiond, const char *userbinid, const char *bin);
int format_keys(struct shcbindb *db, struct shckeysmem *shckeysmem, struct shcpkg *pkg);
int format_pinkeys(struct shcbindb *db, struct shckeysmem *shckeysmem, struct shcpkg *pkg);
int locate_database(char *instid, char *bin, struct shcbindb *db);
int locate_memory(char *instid, char *bin, struct shckeysmem **keys, struct shcpkg **pkg); //R031312
int update_owner(char *bin, struct shckeysmem *shckeysmem, struct shcpkg **shcpkg, struct shcbindb *db);
int update_memory(struct shcbindb *db, struct shckeysmem *keys, struct shcpkg *pkg);
extern int format_securitykeys(struct  shckeys *secdb, struct shcsecurity *sec);
static int set_default_keylens(struct  shcsecurity *sec);
static int shc_search_bintable_inst(char *instid, char *binid);
extern int update_record_shckey();
/*
 *	An application initialiser is invoked with the following paramaters
 *
 *		<taskname>	<mode>	<rulename>	<appid> <srvname> [<data>]
 *
 *	<taskname>		the executable name of this task		(argv[0])
 *	<mode>			the mode of processing
 *						'count'			count space needed and report to strm
 *						'init'			init the rules in-core database
 *						'update'		update an existing rule
 *						'load'			load you application
 *
 *	<rulename>		the name of the rule to be initialised
 *	<appid>			the system assigned application id for this rule
 *
 *	<srvname>		the server to which count information should be sent
 *
 *	<data>			data which might be included in an 'update' command
 *
 *
 *****************************************************************************
 *
 *	This is SHARED Cash initialiser
 *	This task accepts initialisation requests for two types of messages
 *
 *			shared-cash
 *			shared-cash-security			(virtual message type)
 *			shared-cash-stats			(statistics)
 *			shared-cash-pins
 *
 *	It is important that shared-cash be initialised BEFORE shared-cash-keys
 *	This is acomplished by placing the entry in the rules.cfg for shared-cash
 *	before the entry shared-cash-keys.
 *
 */

int		con_id = (-1);
struct	rules_keytab keytab = {0};
int		my_count = 0;
struct	shcbindb	shcbindb = {0};
struct	shcpkg		pkg		 = {0};
PINVERPARM			pindb	 = {0};	
struct	pinverparm		pin		 = {0};
int		update_all			 = 0;

int		fd = (-1);
int		mode = 0;

static int appid = -1;
int		size;
const char	*bp;
ShcBin *shcBin = NULL;
//ShcApp *thisShcApp = NULL;
static int justCreated = 0;

static int shcAppidLocked = 0;
static struct rules_keytab *pShcAppHead = NULL;

#define	MAIN_REC	1
#define KEYS_REC	2
#define STATS_REC	3
#define PINS_REC	4
#define RMT_REC		5


/* Following two parameters determines the minimum number of entries allocated in shared memory */
#define MINIMUM_MEMORY_INCREMENT 100

/* Minimum percentage of extra memory needed */
#define EXTRA_MEMORY				20

int		msgtype = 0;

int		argc = 0;
char	**argv = NULL;

static	int		call_dbm_init = (0);

int main(int a_rgc, char **a_rgv)
{
	int aRet = 0 ;

	argv = a_rgv;
	argc = a_rgc;

	argv0 = *argv;
	catch_all_signals(NULL);

	OTraceOn("shcinit");

	HaPtmCctHelper::deinit() ;
	
	if(argc < 5)
		log_msg(FATAL, TO_CC, "F-SHC-137001:%d is an invalid number of parameters\n", argc);

	OTraceInfo("I-SHC-137000:processing rule %s\n", argv[RULES_PARM_RULENAME] );
	for(int arg_idx=0;arg_idx<argc;arg_idx++)
	OTraceInfo("I-SHC-137001:Arq Index [%d] = %s\n",arg_idx,argv[arg_idx]);

	noBraodcastFlag = 1;
	mb_init();
	OTraceInfo("I-SHC-137002:mailbox initialization by mb_init() done ..\n");

	if(dbm_init() == -1)
	{
		aRet = -1 ;
		goto exit ;
	}

	//thisShcApp = new ShcApp;
	shcApp = new ShcAppBase;
	shcBin = (ShcBin *)shcHelperRegister.getTargetObj(SHC_ShcBin);

	dbmid = getpid();

	/*
	 *	Connect to the named server
	 */
	con_id = mb_locatemailbox(argv[RULES_PARM_SRVNAME]);
	if(con_id == -1)
		log_msg(FATAL, TO_CC, "F-SHC-137002:Unable to connect to %s: Error: %d\n",
			argv[RULES_PARM_SRVNAME], errno);
	

	/*
	 *	Extract all paramaters
	 */
	appid = atoi(argv[RULES_PARM_APPID]);	
	if(stricmp("shared-cash", argv[RULES_PARM_RULENAME]) == 0)
	{
		msgtype = MAIN_REC;
//		appid = rm_getappid("shared-cash");
//		if (appid < 0)
//		{
//			OTraceError("E-SHC-137030:Can't find appid for shared-cash, abort init/update.\n");
//			return -1;
//		}
	}
	else if(stricmp("shared-cash-security", argv[RULES_PARM_RULENAME]) == 0)
	{
		msgtype = KEYS_REC;
//		appid = rm_getappid("shared-cash-security");
//		if (appid < 0)
//		{
//			OTraceError("E-SHC-137031:Can't find appid for shared-cash-security, abort init/update.\n");
//			return -1;
//		}
	}
	else if(stricmp("shared-cash-stats", argv[RULES_PARM_RULENAME]) == 0)
	{
		msgtype = STATS_REC;
//		appid = rm_getappid("shared-cash-stats");
//		if (appid < 0)
//		{
//			OTraceError("E-SHC-137032:Can't find appid for shared-cash-stats, abort init/update.\n");
//			return -1;
//		}
	}
	else if(stricmp("shared-cash-pins", argv[RULES_PARM_RULENAME]) == 0)
	{
		msgtype = PINS_REC;
//		appid = rm_getappid("shared-cash-pins");
//		if (appid < 0)
//		{
//			OTraceError("E-SHC-137033:Can't find appid for shared-cash-pins, abort init/update.\n");
//			return -1;
//		}
	}
	else if(stricmp("shared-cash-rmtbin", argv[RULES_PARM_RULENAME]) == 0)
	{
		msgtype = RMT_REC;
//		appid = rm_getappid("shared-cash-rmtbin");
//		if (appid < 0)
//		{
//			OTraceError("E-SHC-137034:Can't find appid for shared-cash-rmtbin, abort init/update.\n");
//			return -1;
//		}
	}
	else
		log_msg(FATAL, TO_CC, "F-SHC-137003:Invalid message type: %s\n", 
					argv[RULES_PARM_RULENAME]);
	
	/*
	 *	Now determine which we need and perform action
	 */
	if(stricmp(argv[RULES_PARM_MODE], "count") == 0)
		count_records();
	else if(stricmp(argv[RULES_PARM_MODE], "init") == 0)
		init_records();
	else if(stricmp(argv[RULES_PARM_MODE], "load") == 0)
		load_servers();
	else if(stricmp(argv[RULES_PARM_MODE], "update") == 0)
	{
		if (rm_isMultiVerSupported(0) && msgtype == KEYS_REC)
		{
			update_record_shckey();
		}
		else if(msgtype != KEYS_REC)
		{
			/* R026879 */
			if(argc < 7)
				log_msg(FATAL, TO_CC, "F-SHC-137001.1:%d is an invalid number of parameters for updating the rule \n", argc);
			/* R026879 */
	
			if(stricmp("all", argv[RULES_PARM_DATA]) == 0)
			{
				/* R026879 */
				if(argc < 8)
					log_msg(FATAL, TO_CC, "F-SHC-137001.2:%d is an invalid number of parameters for updating the rule with [all] option \n", argc);
				/* R026879 */
	
				update_all = 1;
				update_record(argv[RULES_PARM_DATA + 1], argv[RULES_PARM_DATA + 2]);
			}
			else
				update_record(argv[RULES_PARM_DATA], argv[RULES_PARM_DATA + 1]);

				/* 	R022481 >> */
			if (shcAppidLocked)
				rm_appUnlockMemory(appid);

			OTraceDebug("D-SHC-137039.2: Unlocked rm.appid[%d]\n", appid);
				/* 	R022481 << */
		}

	}
	else
		log_msg(FATAL, TO_CC, 
		"F-SHC-137004:I don't know how to interpret mode '%s'\n", argv[RULES_PARM_MODE]);
	

	if(call_dbm_init)
		dbm_close_all(dbmid);

  exit :

	HaPtmCctHelper::cleanUp() ;
	OTraceOff();
	exit( aRet );
}

int shcinitGetMinimumSpace(const char *bp)
{
	int ret;
	int numOfEntries = 0;
	DBMHSTMT tmpStmt;
	
    if (dbm_connect() >=0)
    {
        OTraceDebug("D-SHC-137005:Connecting to database successful");
    }
    else
    {
        OTraceFatal("F-SHC-137006:Connecting to database failed");
        return -1;
    }
    dbm_dbconn;
    ret=DBMAllocStmt(dbm_dbconn, &tmpStmt);
    if (ret < 0)
    {
        OTraceFatal("F-SHC-137007:Can't allocate statment:%s", bp);
        return -1;
    }
    ret=DBMPrepare(tmpStmt, (char *)bp);
    if (ret < 0)
    {
        OTraceFatal("F-SHC-137008:Can't prepare statment:%s", bp);
        return -1;
    }
    int status;
    ret=DBMBindCol(tmpStmt, 1, DBM_LONGTYPE, &numOfEntries, sizeof(numOfEntries), &status);
    if (ret < 0)
    {
        OTraceFatal("F-SHC-137010:Can't bind for statment:%s", bp);
        return -1;
    }

    ret=DBMExecute(tmpStmt);
    if (ret < 0)
    {
        OTraceFatal("F-SHC-137009:Can't execute statment:%s", bp);
        return -1;
    }
    

    ret=DBMFetch(tmpStmt);
    if (ret == DBM_NO_DATA)
    	numOfEntries = 0;
	else if (ret < 0)
    {
        OTraceFatal("F-SHC-137011:Can't fetch for statment:%s", bp);
        return -1;
    }
    DBMFreeStmt(tmpStmt, DBM_CLOSE);
    
    /* Now calculate how many entries we should allocate
     * The number of entries increase by 100.
     * And we need to keep at least 20% free space
     */
    numOfEntries = (numOfEntries+1) * (MINIMUM_MEMORY_INCREMENT + EXTRA_MEMORY)/100;
    numOfEntries = (numOfEntries + MINIMUM_MEMORY_INCREMENT - 1)/MINIMUM_MEMORY_INCREMENT * MINIMUM_MEMORY_INCREMENT;
    
    return numOfEntries;
}
    
   

int count_records()
{
	/*
	 *	He wants me to inidcate how many keys and text buffers
	 *	as well as their respective sizes
	 *
	 *	I can do this by reading the database or by lokking in a
	 *	config file
	 */
	
	
	/*
	 *	Set up my retrun packet
	 */
	  OTraceInfo("I-SHC-137003:processing rule (%s) count_records  \n", argv[RULES_PARM_RULENAME] );
	keytab.appid = atoi(argv[RULES_PARM_APPID]);

	if(msgtype == MAIN_REC)
	{
		size	= sizeof(struct shcpkg);
		bp		= "select count(networkid) from shcbin";
	}
	else if(msgtype == KEYS_REC)
	{
		size	= sizeof(struct shcsecurity);
		bp		= "select count(institutionid) from shckeys";
	}
	else if(msgtype == STATS_REC)
	{
		size	= sizeof(struct shcstats);
		bp		= "";
		my_count	= 1;
	}
	else if(msgtype == PINS_REC)
	{
		size	= sizeof(struct pinverparm);
		bp		= "select count(bin) from pinverparm";
	}
	else if(msgtype == RMT_REC)
	{
		size	= sizeof(struct shcrmtbin);
		bp		= "select count(networkid) from shcbin";
	}

	if(msgtype != STATS_REC)
		if ((my_count = shcinitGetMinimumSpace(bp)) < 0)
			log_msg(FATAL, TO_CC, "F-SHC-137012:Can't estimate shared memory needed.\n");
	if(msgtype == PINS_REC)
	{
		//If not first count since system start, add at least MINIMUM_MEMORY_INCREMENT records
        if (rm_attach(keytab.appid, RULES_VER_CURRENT) >= 0)
        {
			pShcAppHead = rm_getapphead(keytab.appid);
			if (my_count - pShcAppHead->ntext < MINIMUM_MEMORY_INCREMENT)
				my_count = pShcAppHead->ntext + MINIMUM_MEMORY_INCREMENT;
		}

	}



	/*
	 *	Now i tell him how large my buffers should be
	 */
	keytab.keysize	= sizeof(struct shckeysmem);				/* 10001935 */
	if(msgtype == PINS_REC || msgtype == RMT_REC)
		keytab.nkeys	= 1;
	else
		keytab.nkeys	= my_count;

	keytab.textsize	= size;
	keytab.ntext	= my_count;

	snprintf(keytab.name, sizeof(keytab.name),"%s",argv[RULES_PARM_RULENAME]);

	/*
	 *	Now i send him the information
	 */
	mb_write(con_id, 0, &keytab, sizeof(keytab));
	OTraceInfo("I-SHC-137004:Successfully counted records for (%s)  key sizes  (%d) and Key Count (%d)\n" ,argv[RULES_PARM_RULENAME],size,my_count);

	return(0);
}



int keys_cmp(const void *anykey1, const void *anykey2)		/* 10001935 */
{
	struct shckeysmem *k1 = (struct shckeysmem *)anykey1;
	struct shckeysmem *k2 = (struct shckeysmem *)anykey2;

	return(stricmp(k1->bin, k2->bin));
}

int pkg_cmp(struct shcpkg *k1, struct shcpkg *k2)
{
	return(stricmp(k1->bin.networkid, k2->bin.networkid));
}

int init_records_key()
{
	/*
	 *	Now I can actualy initialise my table
	 */

	if (msgtype != KEYS_REC)
		return(0);

	if(!rm_isMultiVerSupported(0))
		return(0);

	int	 text_count = 0;	int	i;
	struct rules_keytab *keyp;
	struct  shcsecurity	shckeysmem = {0};						/* 10001935 */
	int	retval;
    struct  shckeys     secdb    = {0};                 /* 10001935 */

	

	syslg("%s\n", ver);

	/*	Initialiase the rule memory pointers */
	if(rm_init() < 0)
		return(-1);
		
	/*
	 *	o	Get pin and key pointers
	 */
	if(shc_initsys() < 0)
	{
		OTraceFatal("F-SHC-137013: Initsys() failed\n");
		return(0);
	}


	if (appid < 0)
	{
		appid = rm_getappid("shared-cash-security");
		if (appid < 0)
		{
			OTraceDebug("D-SHC-137035:Failed to get appid. Abort shared-cash-security init\n");
			syslg("D-SHC-137035:Failed to get appid. Abort shared-cash-security init\n");
			
			return -1;
		}
		else
		OTraceInfo("I-SHC-137005:Created the appid in shared-cash-security init\n");
	}
	
	if ( rm_attach( appid, RULES_VER_LOADING ) < 0)
	{
	    OTraceError("E-SHC-137036: Unable to attach to LOADING version \n");
	    syslg("E-SHC-137036: Unable to attach to LOADING version. Abort updating/init shared-cash-security records\n");
	    return(-1);
	}
	else
	OTraceInfo("I-SHC-137006:Attach to LOADING version. In updating/init shared-cash-security records\n");

	
	if (rm_appCreateSemaphore( appid, "SKEY" ) < 0)
	{
	    OTraceError("E-SHC-137037: Unable to create semaphore.  Abort updating/init shared-cash-security.\n");
	    syslg("E-SHC-137037: Unable to create semaphore. Abort updating/init shared-cash-security.\n");
	    return(-1);
	}
	else
	OTraceInfo("I-SHC-137007:Created semaphore. In updating/init shared-cash-security.\n");
	
	pShcAppHead = rm_getapphead(appid);

	/*
	 *	Read each of the records in the database and initialise
	 */
	dbmid = getpid();

	call_dbm_init = 1;
	if((fd = dbm_open("shckeys_2", dbmid)) <0)
		log_msg(FATAL, TO_CC, "F-SHC-138038:Can Not Open shckeys Db.  Err: %d\n", dbm_errno);
	memset(&secdb, 0, sizeof(secdb));
	OTraceInfo("I-SHC-137008:processing rule %s init_records_key\n", argv[RULES_PARM_RULENAME] );

	for(i = 0;; ++i)
	{
		/* 08Mar83. Change from RSEQ to RFIRST then RNEXT */
		if(i==0)
			retval = dbm_read(fd, (char *)&secdb, DBM_RFIRST);
		else
			retval = dbm_read(fd, (char *)&secdb, DBM_RNEXT);

		if(retval == -1)
			if(dbm_errno == DBME_NOTFOUND || dbm_errno == DBME_EOF)
				break;
			else
				log_msg(FATAL, TO_CC, "F-SHC-138039:Database error: %d\n", dbm_errno);

		if (secdb.site_id != mbGetSiteId())
		{
			OTraceDebug("D-SHC-????:My SiteID %d, Skipp record [%s][%s][%d]\n", mbGetSiteId(), secdb.institutionid, secdb.userbinid, secdb.site_id);
			continue;
		}
		
		memset(&shckeysmem, 0, sizeof(struct  shcsecurity));		/* 10001935 */

		/*
		 *	insert the key and the text into shared memory
		 */
		ICInstId_pure(secdb.institutionid, secdb.institutionid);
		if(format_securitykeys(&secdb, &shckeysmem) < 0)		/* 10001935 */
			continue;

		/*
		 *	Insert into shared memory
		 */
		struct shcsecurity *pTmp=(struct shcsecurity *)rm_getapptext(appid);
		if(rm_insert_text(appid, (char *)&shckeysmem, text_count) < 0)	/* 10001935 */
			OTraceFatal("F-SHC-138040: Unable to insert header\n");
		
		++text_count;
		
	}
	
	keyp = rm_getapphead(appid);
	keyp->textused = text_count;
	keyp->keysused = 0;
	if ( rm_appLockMemory(appid) < 0 )
	{
		OTraceError("E-SHC-138041:Can't get lock, Abort shared-cash-security init.\n");
		syslg("E-SHC-138041:shared-cash-security initialization failed.\n");
		return -1;
	}
	else
	OTraceInfo("I-SHC-137010:Inserted key  count [%d]\n",text_count);


	if (rm_attachedcurrent(appid))	//:0 current, 1:not current
	{
		//copy data from current version to loading version
		struct rules_keytab oldAppHead = { 0 };
		if (shcSharedMemoryHelperObj->attachCurrent(&shcSecurityAppid, &keyp) < 0)
		{
			OTraceError("E-SHC-138042:Can't attach current version, Abort shared-cash-security init.\n");
			syslg("E-SHC-138042:Can't attach current version, Abort shared-cash-security init.\n");
			rm_appUnlockMemory(appid);
			return -1;
		}
		else
		OTraceInfo("I-SHC-137011:Attached current version, In shared-cash-security init.\n");
		int memsize = keyp->textsize*keyp->textused;
		char *localMem = (char *)calloc(keyp->textsize, keyp->textused);
		if (!localMem)
		{
			OTraceError("E-SHC-138043:Can't allocat memory(%d) bytes, Abort shared-cash-security init.\n", memsize);
			syslg("E-SHC-138043:Can't allocat memory(%d) bytes, Abort shared-cash-security init.\n", memsize);
			rm_appUnlockMemory(appid);
			return -1;
		}
		else
		OTraceInfo("I-SHC-137012:Allocated memory(%d) bytes, In shared-cash-security init.\n", memsize);

		memcpy(localMem,rm_getapptext(appid),memsize);
		memcpy(&oldAppHead,keyp, sizeof(oldAppHead));
		if ( rm_attach( appid, RULES_VER_LOADING ) < 0)
		{
		    OTraceError("E-SHC-138044: Unable to attach to LOADING version \n");
		    syslg("E-SHC-138044: Unable to attach to LOADING version. Abort updating/init shared-cash-security records\n");
			rm_appUnlockMemory(appid);
		    return(-1);
		}
		else
		OTraceInfo("I-SHC-137013: Attached to LOADING version. In updating/init shared-cash-security records\n");

		keyp = rm_getapphead(appid);
		int oldi, newi;
		char *oldp = localMem;
		char *newp = NULL;
		struct shcsecurity *oldKey, *newKey;
		
		for(oldi=0; oldi<oldAppHead.textused;oldi++, oldp+=oldAppHead.textsize)
		{
			oldKey = (struct shcsecurity *)oldp;
			for(newi=0, newp = rm_getapptext(appid);newi<keyp->textused;newi++,newp+=keyp->textsize)
			{
				newKey = (struct shcsecurity *)newp;
				if (oldKey->hash != newKey->hash)
					continue;
				if (	(strcmp(oldKey->k.institutionid, newKey->k.institutionid)!=0) ||
						(strcmp(oldKey->k.userbinid, newKey->k.userbinid)!=0) )
					continue;
				memcpy(newp, oldp, sizeof(*newKey));
			}
		}
		
	}
	if (rm_setstate( appid, RULES_VER_ATTACHED, RM_STATE_READY) < 0)
	{
		OTraceError("E-SHC-138045:Can't set rule state to READY, Abort shared-cash-security init.\n");
		syslg("E-SHC-138045:Can't set rule state to READY, Abort shared-cash-security init.\n");
		rm_appUnlockMemory(appid);
		return -1;
	}
	else
	OTraceInfo("I-SHC-137014:Rule state set to READY,In shared-cash-security init.\n");
	
	if (rm_unsetloading(appid) < 0)
	{
		OTraceError("E-SHC-138046:Can't unset rule state of LOADING, Abort shared-cash-security init.\n");
		syslg("E-SHC-138046:Can't unset rule state of LOADING, Abort shared-cash-security init.\n");
		rm_appUnlockMemory(appid);
		return -1;
	}
	else
	OTraceInfo("I-SHC-137015:Unset the rule state of LOADING, In shared-cash-security init.\n");

	if (rm_setcurrent( appid, RULES_VER_ATTACHED)<0)
	{
		OTraceError("E-SHC-138047:Can't set rule to CURRENT, Abort shared-cash-security init.\n");
		syslg("E-SHC-138047:Can't set rule to CURRENT, Abort shared-cash-security init.\n");
		rm_appUnlockMemory(appid);
		return -1;
	}
	else
	OTraceInfo("I-SHC-137016:Set Rule to CURRENT , In shared-cash-security init.\n");



	rm_appUnlockMemory(appid);

	return(0);
}

int init_records_stats()
{
	OTraceInfo("I-SHC-137018:processing rule (%s) init_records_stats\n", argv[RULES_PARM_RULENAME] );

	if (rm_setstate( appid, RULES_VER_ATTACHED, RM_STATE_READY) < 0)
	{
		OTraceError("E-SHC-138063:Can't set rule state to READY, Abort shared-cash-stats init.\n");
		syslg("E-SHC-138063:Can't set rule state to READY, Abort shared-cash-stats init.\n");
		return -1;
	}
	else
	OTraceInfo("I-SHC-137019:Set Rule State to READY, In shared-cash-stats init.\n");

	
	if (rm_unsetloading(appid) < 0)
	{
		OTraceError("E-SHC-138064:Can't unset rule state of LOADING, Abort shared-cash-stats init.\n");
		syslg("E-SHC-138064:Can't unset rule state of LOADING, Abort shared-cash-stats init.\n");
		return -1;
	}
	else
	OTraceInfo("I-SHC-137020:Unset Rule State of LOADING , In shared-cash-stats init.\n");

	if (rm_setcurrent( appid, RULES_VER_ATTACHED)<0)
	{
		OTraceError("E-SHC-138047:Can't set rule to CURRENT, Abort shared-cash-stats init.\n");
		syslg("E-SHC-138064:Can't set rule to CURRENT, Abort shared-cash-stats init.\n");
		return -1;
	}
	else
	OTraceInfo("I-SHC-137021:Set Rule to CURRENT , In shared-cash-stats init.\n");
	OTraceInfo("I-SHC-137022:Successfully  initialzed the rule (%s) record\n",argv[RULES_PARM_RULENAME]);

	return 0;
}

int init_records()
{
	/*
	 *	Now I can actualy initialise my table
	 */

	
	int	key_count = 0, text_count = 0;
	int	i;
	struct rules_keytab *keyp;
	struct	shckeysmem	shckeysmem = {0};						/* 10001935 */
	int	retval;

	syslg("%s\n", ver);

	/*	Initialiase the rule memory pointers */
	if(rm_init() < 0)
	{
		OTraceError("E-SHC-138048:Can't inititalize rule, Abort init shared-cash\n");
		syslg("E-SHC-138048:Can't inititalize rule, Abort init shared-cash\n");
		return(-1);
	}		

	if (msgtype == KEYS_REC)
		return(init_records_key());
	if (msgtype == STATS_REC)
		return(init_records_stats());
	
	if(msgtype != MAIN_REC)
		return(0);

	/*
	 *	o	Get pin and key pointers
	 */
	if(shc_initsys() < 0)
	{
		OTraceFatal("F-SHC-137013: Initsys() failed\n");
		return(0);
	}
	OTraceInfo("I-SHC-137023:processing rule (%s) init_records\n", argv[RULES_PARM_RULENAME] );


	if (appid < 0)
	{
		appid = rm_getappid("shared-cash");
		if (appid < 0)
		{
			OTraceError("F-SHC-138049:Failed to get shared-cash appid. Abort key init\n");
			syslg("F-SHC-138049:Failed to get shared-cash appid. Abort key init\n");
			
			return -1;
		}
	}
	else
	OTraceInfo("I-SHC-137024:Received Shared-cash appid.In key init\n");


	if ( rm_attach( appid, RULES_VER_LOADING ) < 0)
	{
		OTraceError("E-SHC-138050: Unable to attach to LOADING version \n");
		syslg("E-SHC-138050: Unable to attach to LOADING version. Abort updating/init shared-cash\n");
		return(-1);
	}
	else
	OTraceInfo("I-SHC-137025:Attached to LOADING version.In updating/init shared-cash\n");

	pShcAppHead = rm_getapphead(appid);
	if (rm_appCreateSemaphore( appid, "SHCM" ) < 0)
	{
		OTraceError("E-SHC-138051: Unable to create semaphore.  Abort updating/init shared-cash.\n");
		syslg("E-SHC-138051: Unable to create semaphore. Abort updating/init shared-cash.\n");
		return(-1);
	}
	else
	OTraceInfo("I-SHC-137026:Created Semaphore.In updating/init shared-cash.\n");

	
	/*
	 *	Read each of the records in the database and initialise
	 */
	dbmid = getpid();

	call_dbm_init = 1;
	if((fd = dbm_open("shcbin_ix", dbmid)) <0)
		log_msg(FATAL, TO_CC, "F-SHC-137014:Can Not Open SHCBIN Db.  Err: %d\n", dbm_errno);
	memset(shcbindb.networkid, 0, sizeof(shcbindb.networkid));
	OTraceInfo("I-SHC-137027:Reading the records from database for init the (%s) Rule \n", argv[RULES_PARM_RULENAME] );

	for(i = 0;; ++i)
	{
		/* 08Mar83. Change from RSEQ to RFIRST then RNEXT */
		if(i==0)
			retval = dbm_read(fd, (char *)&shcbindb, DBM_RFIRST);
		else
			retval = dbm_read(fd, (char *)&shcbindb, DBM_RNEXT);

		if(retval == -1)
			if(dbm_errno == DBME_NOTFOUND || dbm_errno == DBME_EOF)
				break;
			else
				log_msg(FATAL, TO_CC, "F-SHC-137015:Database error: %d\n", dbm_errno);
		
		memset(&shckeysmem, 0, sizeof(struct shckeysmem));		/* 10001935 */
		memset(&pkg, 0, sizeof(struct  shcpkg));                        /* R015297 */

		/*
		 *	insert the key and the text into shared memory
		 */
		ICInstId_pure(shcbindb.institutionid, shcbindb.institutionid);
		if(format_entry(&shcbindb, &shckeysmem, &pkg) < 0)		/* 10001935 */
			continue;

		/*
		 *	Get the keys
		 */
		get_keys(&shcbindb, &shckeysmem, &pkg);					/* 10001935 */

		/*
		 *	Insert into shared memory
		 */

		OTraceInfo("I-SHC-137028:inserting institution_id [%s] userbin_id [%s]\n", shcbindb.institutionid,shcbindb.userbinid);

		/*	Insert the Package */
		if(shckeysmem.textid == PKG_NEEDS_TEXT)					/* 10001935 */
		{
			shckeysmem.textid = text_count;						/* 10001935 */
			if(rm_insert_text_sn(appid, (char *)&pkg, text_count, sizeof(pkg)) < 0)
				OTraceFatal("F-SHC-137016: Unable to insert text\n");
			text_count++;
		}

		/*	Insert the key */
		if(rm_insert_key_sn(appid, (char *)&shckeysmem, key_count, sizeof(shckeysmem)) < 0)	/* 10001935 */
			OTraceFatal("F-SHC-137017: Unable to insert header\n");
		
		++key_count;
		
	}
	
	keyp = rm_getapphead(appid);
	keyp->textused = text_count;
	keyp->keysused = key_count;


	/*
	 *	Now sort the bin entries for faster look up
	 */
	shcBinKeys = (struct shckeysmem *)rm_getappkey(appid);		/* 10001935 */
	shcBinPkg  = (struct shcpkg	 *)rm_getapptext(appid);
	qsort(shcBinKeys, i, keyp->keysize,keys_cmp);	/* 10001935 */
	keyp->flags |= RULES_KEY_SORTED;


	/*
	 *	Now locate the index of all owners and update the 'keys'
	 */
	find_owners();
	
	if ( rm_appLockMemory(appid) < 0 )
	{
		OTraceError("E-SHC-138052:Can't get lock, Abort shared-cash init.\n");
		syslg("E-SHC-138052:shared-cash initialization failed.\n");
		return -1;
	}
	else
	OTraceInfo("I-SHC-137030:Shared-cash initializated\n");

	if (rm_attachedcurrent(appid))	//:0 current, 1:not current
	{
		//copy data from current version to loading version
		struct rules_keytab oldAppHead = { 0 };
		if (shcSharedMemoryHelperObj->attachCurrent(&appid, &keyp) < 0)
		{
			OTraceError("E-SHC-138053:Can't attach current version, Abort shared-cash init.\n");
			syslg("E-SHC-138053:Can't attach current version, Abort shared-cash init.\n");
			rm_appUnlockMemory(appid);
			return -1;
		}
		else
		OTraceInfo("I-SHC-137031:Attached Current Version,In shared-cash init.\n");

		int memsize = keyp->textsize*keyp->textused;
		char *localMem = (char *)calloc(keyp->textsize, keyp->textused);
		if (!localMem)
		{
			OTraceError("E-SHC-138054:Can't allocat memory(%d) bytes, Abort shared-cash init.\n", memsize);
			syslg("E-SHC-138054:Can't allocat memory(%d) bytes, Abort shared-cash init.\n", memsize);
			rm_appUnlockMemory(appid);
			return -1;
		}
		else
		OTraceInfo("I-SHC-137032:Allocat memory(%d) bytes,In shared-cash init.\n",memsize);
		memcpy(localMem,rm_getapptext(appid),memsize);
		memcpy(&oldAppHead,keyp, sizeof(oldAppHead));
		if ( rm_attach( appid, RULES_VER_LOADING ) < 0)
		{
		    OTraceError("E-SHC-138055: Unable to attach to LOADING version. Abort updating/init shared-cash records \n");
		    syslg("E-SHC-138055: Unable to attach to LOADING version. Abort updating/init shared-cash records\n");
			rm_appUnlockMemory(appid);
		    return(-1);
		}
		else
		OTraceInfo("I-SHC-137032:Attached to LOADING Version.In updating/init shared-cash records\n");

		keyp = rm_getapphead(appid);
		int oldi, newi;
		char *oldp = localMem;
		char *newp = NULL;
		struct shcpkg *oldKey, *newKey;
		
		for(oldi=0; oldi<oldAppHead.textused;oldi++, oldp+=oldAppHead.textsize)
		{
			oldKey = (struct shcpkg *)oldp;
			for(newi=0, newp = rm_getapptext(appid);newi<keyp->textused;newi++,newp+=keyp->textsize)
			{
				newKey = (struct shcpkg *)newp;
				if (	(strcmp(oldKey->bin.institutionid, newKey->bin.institutionid)!=0) ||
						(strcmp(oldKey->bin.userbinid, newKey->bin.userbinid)!=0) )
					continue;
				newKey->bin.flags |= oldKey->bin.flags&SH_DOWN;
				newKey->bin.bintype |= oldKey->bin.bintype&SH_USES_KEYS;
				memcpy(newKey->balInfo, oldKey->balInfo, sizeof(newKey->balInfo));
			}
		}
		
	}

	if (rm_setstate( appid, RULES_VER_ATTACHED, RM_STATE_READY) < 0)
	{
		OTraceError("E-SHC-138056:Can't set rule state to READY, Abort shared-cash init.\n");
		syslg("E-SHC-138056:Can't set rule state to READY, Abort shared-cash init.\n");
		rm_appUnlockMemory(appid);
		return -1;
	}
	else
	OTraceInfo("I-SHC-137033:Set Rule state to READY, In shared-cash init.\n");
	
	if (rm_unsetloading(appid) < 0)
	{
		OTraceError("E-SHC-138057:Can't unset rule state of LOADING, Abort shared-cash init.\n");
		syslg("E-SHC-138057:Can't unset rule state of LOADING, Abort shared-cash init.\n");
		rm_appUnlockMemory(appid);
		return -1;
	}
	else
	OTraceInfo("I-SHC-137034:Unset Rule state of LOADING, In shared-cash init.\n");

	if (rm_setcurrent( appid, RULES_VER_ATTACHED)<0)
	{
		OTraceError("E-SHC-138058:Can't set rule to CURRENT, Abort shared-cash init.\n");
		syslg("E-SHC-138058:Can't set rule to CURRENT, Abort shared-cash init.\n");
		rm_appUnlockMemory(appid);
		return -1;
	}
	else
	OTraceInfo("I-SHC-137035:Set Rule to CURRENT ,In shared-cash init.\n");

	
	
	rm_appUnlockMemory(appid);
	OTraceInfo("I-SHC-137036:Successfully  initialized the Rule (%s) \n",argv[RULES_PARM_RULENAME]);
	return(0);
}


int format_entry( struct shcbindb *db, struct shckeysmem *shckeysmem,
				 struct shcpkg *pkg )
{
	return(format_record(db, shckeysmem, pkg, 1));				/* 10001935 */
}


/*  R001654.  */
int format_record(register struct shcbindb *db, struct shckeysmem *shckeysmem,
			struct shcpkg *pkg, int new_entry)
{
	/*
	 *	Input:		db			database record
	 *				pkg			in core record
	 *				new_entry	if set then this is a new record
	 *
	 *	Action:		Encode the database record into our internal record format
	 *				for use at run time.
	 *
	 */
	int i;
	
	shcBin->setBinPkg(pkg);

	OTraceInfo("I-SHC-137018: Start format for bin[%s]\n", db->networkid);   /* R001835 */

	/* 10001935 */
	memcpy(shckeysmem->bin, db->networkid, sizeof(shckeysmem->bin));
	ICInstId_pure(shckeysmem->institutionid, db->institutionid);
	memcpy(shckeysmem->userbinid, db->userbinid, sizeof(shckeysmem->userbinid));
	memcpy(shckeysmem->owner, db->network, sizeof(shckeysmem->owner));

	if(stricmp(db->userbinid, db->network) != 0)
	{
		OTraceDebug("D-SHC-137019: PKG_NEEDS_OWNER: %s\n", db->networkid);
		if(new_entry)
			shckeysmem->textid = PKG_NEEDS_OWNER;				/* 10001935 */
		return(0);
	}
	else
		if(new_entry)
			shckeysmem->textid = PKG_NEEDS_TEXT;				/* 10001935 */

	/*	Format the routing and configuration package */
	memcpy(pkg->bin.networkid, db->networkid, sizeof(pkg->bin.networkid));
	ICInstId_pure(pkg->bin.institutionid, db->institutionid);
	memcpy(pkg->bin.userbinid, db->userbinid, sizeof(pkg->bin.userbinid));
	memcpy(pkg->bin.owner, db->network, sizeof(pkg->bin.owner));

	/* pkg->bin.bintype	= db->bintype;  R001835 */
	pkg->bin.timeout	= db->timeout;
	pkg->bin.country_code	= db->country_code;
	pkg->bin.currency_code	= db->currency_code;
	strcpy(pkg->bin.bankname, db->bankname);

	/*	Find the outbound mailbox entry */
	pkg->bin.mailbox = find_outbound(db->mailbox);
	pkg->bin.node[0] = '\0';
	/*	Find my network Manager */
	if(db->netmgr[0])
		pkg->bin.netmgrid = find_mailbox(db->netmgr);
	else
		pkg->bin.netmgrid = find_mailbox(DEFAULT_NETMGR);
		
	/*	Find and open the Port Mail Box */
	pkg->bin.port = find_mailbox(db->port);

	/*	set the last activity time */
	pkg->bin.last_online_activity = time(0);

	if(new_entry||justCreated)
	{
        if ( shcApp->saf_interleave )       //-R011312- 28Jun04 adding the else into SH_REPLAY mode
        {
            if ( saf_exists(db->institutionid, db->userbinid, db->networkid) )
                pkg->bin.flags = SH_REPLAY;
            else
                pkg->bin.flags = 0;
        }
        else
        {
			pkg->bin.flags = 0;
            if(db->safinter == 'S' && saf_exists(db->institutionid, db->userbinid, db->networkid))
				shcBin->setInstDown();
            else
                pkg->bin.flags = 0;
        }
	}
	else
		/*	if not new then save some important flags */
		pkg->bin.flags = pkg->bin.flags & 
								(SH_DOWN | SH_KEY_EXCHANGE | SH_REPLAY);


	if(db->checkexp == 'Y')
		pkg->bin.flags |= SH_CHECKEXP;
	if(db->checkpin == 'Y')
		pkg->bin.flags |= SH_CHECKPIN;
	else if (db->checkpin == 'A')
		pkg->bin.flags |= SH_CHECKPIN_STAND_IN;

	switch(db->checkhot){
	case	'Y':	case	'I':
		pkg->bin.flags |= SH_CHECK_INDIV_HOT;		break;
	case	'R':
		pkg->bin.flags |= SH_CHECK_RANGE_HOT;		break;
	case	'B':
		pkg->bin.flags |= (SH_CHECK_RANGE_HOT | SH_CHECK_INDIV_HOT);	break;
	}

	if(db->checkscode == 'Y')
		pkg->bin.flags |= SH_CHECKSCODE;

	/* R001538 Start */
	if((db->checkcvv == 'Y') ||
	   (db->checkcvv == '1') ||
	   (db->checkcvv == 'B'))
	{
		OTraceDebug("D-SHC-137020:I: CVV checking is ON for bin %s", pkg->bin.networkid);
		pkg->bin.flags |= SH_CHECKCVV;
		pkg->bin.cvvdate = db->cvvdate;
	}
	/* R005646 -- COMMENTED --> */
	if((db->checkcvv == '2') ||
	   (db->checkcvv == 'B')) 
	{
		OTraceDebug("D-SHC-137021:I: CVV2 checking is ON for bin %s\n", pkg->bin.networkid);
		shcBinSetCheckCVV2(pkg);
	}
	/* <-- COMMENTED -- R005646 */
	/* R001538 End */

	if(db->checkmod10 == 'Y')
		pkg->bin.flags |= SH_VERIFY_CHECK_DIGIT;

	if(db->send500 == 'I')
		pkg->bin.flags |= SH_SEND500;
	else if(db->send500 == 'O')
		pkg->bin.flags |= (SH_ONLINE_SETTLEMENT | SH_SEND500);
	

	if(db->debit_credit == 'C' || db->debit_credit == 'B' || db->debit_credit == 'F')
		pkg->bin.flags |= SH_CREDIT_CARD;

	if(db->debit_credit == 'D' || db->debit_credit == 'B' || db->debit_credit == 'F')
		pkg->bin.flags |= SH_DEBIT_CARD;

	if(db->debit_credit == 'F')
		pkg->bin.flags |= SH_FLIP_MSGTYPE;
	
	if(db->cardalert == 'A')
		pkg->bin.flags |= SH_CARDALERT_ALWAYS;

	else if(db->cardalert == 'C')
		pkg->bin.flags |= SH_CARDALERT_BYCARD;
	
	if(db->cutovertype == 'E')
		pkg->bin.flags |= SH_CUTOVER_EXTERNAL;


	if(db->echotest == 'D')
		pkg->bin.flags |= SH_ECHOTEST_DOWN;
	else if(db->echotest == 'A')
		pkg->bin.flags |= SH_ECHOTEST_ALWAYS;


	if(db->txn_set[SH_TXIDX_REVFLAG] == 'Y')
		pkg->bin.flags |= SH_GETAPP_HOST;
	
	/*	23oct92 */
	if(db->txn_set[SH_TXIDX_CHKFLRLIM] == 'Y')
		pkg->bin.flags |= SH_CHKFLRLIM;
	
	if(db->txn_set[SH_TXIDX_SENDREV] == 'A') 
		pkg->bin.flags |= SH_SENDREV_ALWAYS | SH_SENDREV;		/* 10002243 */

	if(db->txn_set[SH_TXIDX_SENDREV] == 'D' ||
		db->txn_set[SH_TXIDX_SENDREV] == 'Y' )
		pkg->bin.flags |= SH_SENDREV;

	if(db->txn_set[SH_TXIDX_SAFAUTH] == 'Y')
		pkg->bin.flags |= SH_SAFAUTH;

	/* 24nov92 */
	if(db->txn_set[SH_TXIDX_SENDACK] == 'Y') 
		pkg->bin.flags |= SH_SENDACK;

	/* 26nov92 */
	if(db->txn_set[SH_TXIDX_PREAUTH_ON_VALIDATE] == 'Y') 
		pkg->bin.flags |= SH_PREAUTH_ON_VALIDATE;
	
	/* 29apr93 */
	if(db->txn_set[SH_TXIDX_CHECKDUP] == 'Y') 
		pkg->bin.flags |= SH_CHECKDUP;

	/*	----------- Essa:	18Jun93 --------------
	* new flag to indicate if this BIN supports
	* multicurrency transactions.
	*/
	if(db->txn_set[SH_TXIDX_CURRENCY_CONV] == 'Y') 
		pkg->bin.flags |= SH_CURRENCY_CONV;

	/*
	 *	Check the type of record this is
	 */
	if(new_entry) /* R001835 */
        pkg->bin.bintype = 0;
    else
			pkg->bin.bintype = pkg->bin.bintype & (SH_FORWARD_MODE | SH_USES_PIN_KEY | SH_USES_MAC_KEY | SH_ALLOW_KEY_EXCHANGE |SH_KEYS_SHARED);

	/* R005646 -- MOVED TO HERE where bintype initialized --> */
	if((db->checkcvv == '2') || (db->checkcvv == 'B')) 
	{
		OTraceDebug("D-SHC-137022:I: CVV2 checking is ON for bin %s", pkg->bin.networkid);
		shcBinSetCheckCVV2(pkg);
	}
	/* <-- R005646 */
	/************** Changes by MI for preauth support ****************/

	switch(db->txn_set[SH_PREAUTH_SUPPORT]) 
	{
		case 'A':
		case 'a':
			/*
				preauth agent can reverse preauth requests and IST can forward
				confirm requests to issuer
			*/
			pkg->bin.bintype |= (SH_PREAUTH_ALLOWED |
								(SH_PREAUTH_FORWARD | SH_PREAUTH_REVERSE));
			break;

		case 'B':
		case 'b':
			/*
				preauth agent can reverse preauth requests and IST can reply
				to confirm requests without referring back to issuer host
			*/
			pkg->bin.bintype |= (SH_PREAUTH_ALLOWED | SH_PREAUTH_REVERSE);
			break;

		case 'C':
		case 'c':
		case 'Y': /* R001835 */
		case 'y': /* R001835 */
			/*
				preauth agent can not reverse preauth requests and IST can 
				reply to confirm requests without referring back to issuer host
			*/
			pkg->bin.bintype |= SH_PREAUTH_ALLOWED;
			break;

		case 'D':
		case 'd':
			/*
				preauth agent can not reverse preauth requests and IST can
				forward confirm requests to issuer host
			*/
			pkg->bin.bintype |= (SH_PREAUTH_ALLOWED | SH_PREAUTH_FORWARD);
			break;

		default:
			break;
	}

	if(db->txn_set[SH_FULLAUTH_SUPPORT] == 'Y') 
		pkg->bin.bintype |= SH_FULL_AUTHORIZATION;
	/******************** End of changes ***************************/

	if(db->bintype & SH_DEVICE_WILL_ACK)
		pkg->bin.bintype |= SH_DEVICE_WILL_ACK;
	if(db->usekeys == 'Y')
		pkg->bin.bintype |= SH_KEYS_REQUIRED;
	else if (db->usekeys == 'A')
	{
		pkg->bin.bintype |= SH_KEYS_REQUIRED;
		pkg->bin.bintype |= SH_KEYS_AS2805;
	}
	else
		pkg->bin.bintype &= ~(SH_USES_PIN_KEY | SH_USES_MAC_KEY | SH_ALLOW_KEY_EXCHANGE | SH_KEYS_SHARED | SH_KEYS_REQUIRED | SH_KEYS_AS2805);

	if(db->bintype & SH_DEFAULT_ISSUER)
		pkg->bin.bintype |= SH_DEFAULT_ISSUER;

#if 0 /* R001835 */	
	if(db->ccstlmt == 'A')
		pkg->bin.bintype |= SH_CCSTLMT_AUTH;
	else if(db->ccstlmt == 'F')
		pkg->bin.bintype |= SH_CCSTLMT_FIN;
	else
		pkg->bin.bintype |= SH_CCSTLMT_SYSTEM;
#else
	if( db->ccstlmt == 'M' || db->ccstlmt == 'B' || db->ccstlmt == 'Y')
        shcSetVerifyMac(pkg);  

    if( db->ccstlmt == 'K' || db->ccstlmt == 'B' )
        shcSetUseKme(pkg);
#endif

	if(db->binrange == 'Y')
		pkg->bin.bintype |= SH_USE_EXTBIN;
	

	/* R003638 */
	/* 05jul93 */
	if(db->bintype & 0x2)
		pkg->bin.bintype |= SH_ONUS_BIN;
	if(db->bintype == 0x3 || db->bintype == 0x4)
		pkg->bin.bintype |= SH_SPECIAL_BIN1;
	/* R003638 */

	/* 961115 */
	if( db->bintype & SH_NO_LOG )
		pkg->bin.bintype |= SH_NO_LOG;
	if( db->bintype & SH_FORWARD_NAK )
		pkg->bin.bintype |= SH_FORWARD_NAK;
	if( db->bintype & SH_ACQTO_GEN_REV )
		pkg->bin.bintype |= SH_ACQTO_GEN_REV;

	/*
	 *	Format the transaction package
	 */
	dbm_deccopy(&pkg->txn.amount, &db->txnamount);
	pkg->txn.txnset = 0;
	pkg->txn.npintry = db->npintry;
	for(i = 0; ShcAppBase::shc_txn_def[i].offset != -1; ++i)
		if(db->txn_set[ ShcAppBase::shc_txn_def[i].offset ] == 'Y')
			pkg->txn.txnset |= ShcAppBase::shc_txn_def[i].flag;
	
	/*
	 *	Format authorization package
	 */
		
	dbm_deccopy(&pkg->auth.floor_1, &db->floor_1);
	dbm_deccopy(&pkg->auth.floor_2, &db->floor_2);
	dbm_deccopy(&pkg->auth.floor_3, &db->floor_3);
	dbm_deccopy(&pkg->auth.acq_minamount, &db->acq_minamount);
	dbm_deccopy(&pkg->auth.iss_minamount, &db->iss_minamount);
	if(stricmp(db->authflag, SHC_DBAUTH_FULL) == 0)
		pkg->auth.type	= SHC_AUTHTYPE_FULL;
	else if(stricmp(db->authflag, SHC_DBAUTH_PREAUTH) == 0)
		pkg->auth.type 	= SHC_AUTHTYPE_PREAUTH;
	else if(stricmp(db->authflag, SHC_DBAUTH_COMPLETE_PASSTHRU) == 0)
		pkg->auth.type	= SHC_AUTHTYPE_COMPLETE_PASSTHRU;
	else if(stricmp(db->authflag, SHC_DBAUTH_MGT_PASSTHRU) == 0)
		pkg->auth.type	= SHC_AUTHTYPE_MGT_PASSTHRU;
	else
		pkg->auth.type	= SHC_AUTHTYPE_FULL;

	if(pkg->auth.type == SHC_AUTHTYPE_PREAUTH)
		pkg->auth.authserver = find_mailbox(db->authserver);
	else
		pkg->auth.authserver = (-1);

	pkg->auth.def_from_acct = db->def_from_acct;
	pkg->auth.def_to_acct	= db->def_to_acct;


	/*
	 *	Process the store and forward flags
	 */
	dbm_deccopy(&pkg->saf.amount, &db->safamount);
	pkg->saf.num			= db->saflimit;
	pkg->saf.refreshtime	= db->refresh;
	if(new_entry)
	{
		pkg->saf.fd				= (-1);
		pkg->saf.replayid		= (-1);
	}

	/*	Determine SAF paramaters */
	pkg->saf.type			= 0;

	/* if(shc_IsPassThrough(pkg)) */
	if(shcIsPassThrough(pkg))
	{
		db->saftype = 'D';
		db->saffile = 'N';
		/*	db->safinter = 'S';	*/	/* R004691 */
	}

	if(db->saftype == 'P')
		pkg->saf.type |= SH_SAF_POSFILE;
	else if(db->saftype == 'N')
		pkg->saf.type |= SH_SAF_NEGFILE;
	
	if(db->saffile == 'N')
		pkg->saf.type |= SH_SAF_NOFILE;
	
	/*	ad	21nov91	*/
	if(db->safinter == 'S')
		pkg->saf.type |= SH_SAF_FORCE_DOWN;
	else if(db->safinter == 'N')
		pkg->saf.type |= SH_SAF_TIMEOUT_DONOTHING;
	else if(db->safinter == 'R')
		pkg->saf.type |= SH_SAF_TIMEOUT_RETRY;
	else
		pkg->saf.type |= SH_SAF_TIMEOUT_DONOTHING;
	/*	ad	21nov91	end */
	
	/* R005869 - COMMENTED --> 
	if(db->saftype == 'P')
	<-- R005869 */
		/*	There should be a authorization module present */
		pkg->saf.posmailbox = find_mailbox(db->posmailbox);
	
    /* 2007336 R004671 Dds 26Jun00 - Load chip data */
    pkg->bin.cammailboxid = find_mailbox( db->cammailbox );

	/*
 	 * R001835 Bin Level Configuration and Processing
	 * 2007336 R004671 Dds 26Jun00 -changing for chipdata enhancement
	 */
	pkg->bin.bin_cfg = 0;
	pkg->bin.addflag = 0;
	OTraceDebug("D-TEST-120:value of bin configuration is[%s][%c]\n",db->bin_cfg,db->bin_cfg[3]);
	for(i = 0; ShcAppBase::shc_bin_cfg[i].offset != -1; ++i)
	{
		if ( ShcAppBase::shc_bin_cfg[i].offset ==   SH_CFGIX_SUBSECOND_TIMEOUT)
		{
			switch(db->bin_cfg[SH_CFGIX_SUBSECOND_TIMEOUT])
			{
			case 'D':
			    pkg->bin.addflag |= SH_ADDFLAG_TIMEOUT_DECISECOND;
			    break;
			}

		}
		else if (ShcAppBase::shc_bin_cfg[i].offset == SH_CFGIX_ENABLE_DUAL_SITE_BRIDGE)
		{
			switch (db->bin_cfg[ShcAppBase::shc_bin_cfg[i].offset])
			{
				case 'Y': case 'y':
						pkg->bin.bin_cfg |= SH_CFG_ENABLE_DUAL_SITE_BRIDGE;
						break;
				case 'S': case 's':
						pkg->bin.bin_cfg |= SH_CFG_ALLOW_SAF_ACROSS_SITE;
						break;
				case 'A': case 'a':
						pkg->bin.bin_cfg |= SH_CFG_ALLOW_SAF_ACROSS_SITE | SH_CFG_ENABLE_DUAL_SITE_BRIDGE;
						break;
				}
		}
		else if ( ShcAppBase::shc_bin_cfg[i].offset ==  SH_CFGIX_CAAV_CAVV_3DS_VERIFY_STAND_IN_ONLY )
		{
			switch (db->bin_cfg[ShcAppBase::shc_bin_cfg[i].offset])
			{
				case 'S': case 's':
						pkg->bin.bin_cfg |= SH_CFG_CAVV_3DS_STAND_IN_ONLY;
						break;
			}
		}
		else if ( (db->bin_cfg[ShcAppBase::shc_bin_cfg[i].offset ] == 'Y') ||
		     (db->bin_cfg[ShcAppBase::shc_bin_cfg[i].offset ] == 'F'  &&	/*R004671*/
                ShcAppBase::shc_bin_cfg[i].offset == SH_CFGIX_FULL_ENTRY) ) /*R004671*/ 
		{
			pkg->bin.bin_cfg |= ShcAppBase::shc_bin_cfg[i].flag;
		}
		else
		{
			if( ShcAppBase::shc_bin_cfg[i].offset == SH_CFGIX_TRANTIME 
			  && (db->bin_cfg[ShcAppBase::shc_bin_cfg[i].offset ] != 'N') )
					pkg->bin.bin_cfg |= ShcAppBase::shc_bin_cfg[i].flag;
		}
	}												/* R007883 << */
	if (db->bin_cfg[SH_CFGIX_FWD_CAPTURE] != 'N')
		pkg->bin.bin_cfg |= SH_CFG_FWD_CAPTURE;
	if( (db->checkcvv == 'S') )
	{
		pkg->bin.bin_cfg |= SH_CHECKCVV_STANDIN_ONLY;
	}
	if( (db->checkcvv == 'T') )
	{
		pkg->bin.bin_cfg |= SH_CHECKCVV2_STANDIN_ONLY;
	}
	if( (db->checkcvv == 'U') )
	{
		pkg->bin.bin_cfg |= SH_CHECK_CVV_CVV2_STANDIN_ONLY;
	}

	switch(db->bin_cfg[SH_CFGIX_DCVV_CVC3]) 
	{
	case 'V':pkg->bin.bin_cfg |= SH_CFG_DCVV_VERIFY; break;
	case 'C':pkg->bin.bin_cfg |= SH_CFG_DCVV_CHECK; break;
	case 'Y':pkg->bin.bin_cfg |= SH_CFG_DCVV_CHECK | SH_CFG_DCVV_VERIFY; break;
	case 'S':pkg->bin.bin_cfg |= SH_CFG_DCVV_CHECK_VERIFY_STAND_IN_ONLY; break;
	default:break;
	}
	switch(db->bin_cfg[SH_CFGIX_ON_DOT])
	{
	case 'C':pkg->bin.bin_cfg |= SH_CFG_ONDOT_DOWN_CONT; break;
	case 'D':pkg->bin.bin_cfg |= SH_CFG_ONDOT_DOWN_DENY; break;
	default: break;
	}

	switch(db->bin_cfg[SH_CFGIX_CAAV_CAVV_3DS_VERIFY])
	{
		case '1':
			pkg->bin.addflag |= SH_ADDFLAG_CAVV_SPA2_APPROVE;
                        break;
		case '2':
			pkg->bin.addflag |= SH_ADDFLAG_CAVV_SPA2_DECLINE;
			break;
		case '3':
			pkg->bin.addflag |= SH_ADDFLAG_CAVV_VIS_3DS_APPROVE;
			break;
		case '4':
			pkg->bin.addflag |= SH_ADDFLAG_CAVV_VIS_3DS_DECLINE;
                        break;
		default:
			break;
	}

	switch(db->bin_cfg[SH_CFGIX_TOKEN_TXN_CHK])
	{
		case 'Y':
			pkg->bin.bin_cfg |= SH_CFG_TOKEN_TXN_CHK;
			break;
		case 'N':
			pkg->bin.bin_cfg |= SH_CFG_TOKEN_TXN_NO_CHK;
                        break;
		default:
			break;
	}
	
	switch(db->bin_cfg[SH_CFGIX_DCVVCVC3_TYPE])
	{
	case 'D':pkg->bin.bin_cfg |= SH_CFG_DCVV; break;
	case 'I':pkg->bin.bin_cfg |= SH_CFG_ICVV; break;
	case 'C':pkg->bin.bin_cfg |= SH_CFG_CVC3; break;
	case 'S':pkg->bin.bin_cfg |= SH_CFG_SCVC3; break;
	default:break;
	}
	switch(db->bin_cfg[SH_CFGIX_AVS_FLAG]) /* R006273 Begin*/
    {
	    case '1':
		    pkg->bin.bin_cfg |= SH_NONCONDENSED_AVS; /*0x40*/
	        break;
	    case '2':
	        pkg->bin.bin_cfg |= SH_CONDENSED2_AVS;  /*0x80*/
	        break;
	   case '3':
	        pkg->bin.bin_cfg |= SH_CONDENSED3_AVS;  /*0xc0*/
	        break;
	   case '4':
	        pkg->bin.bin_cfg |= SH_CONDENSED4_AVS;  /*0x100*/
	        break;
	   default:
	        pkg->bin.bin_cfg |= SH_NO_AVS;          /*0x00 */
	        break;
	} /* R006273 End*/

	switch(db->bin_cfg[SH_CFGIX_ACQ_ISS_FLAG]) /* R007010 Begin*/
	{
		case 'A':
			pkg->bin.bin_cfg |= SH_ACQUIRER_ONLY; /*0x20000*/   	//R007502
			break;
		case 'I':
			pkg->bin.bin_cfg |= SH_ISSUER_ONLY;     /*0x10000*/		//R007502
			break;
		case 'B':
			pkg->bin.bin_cfg |= SH_ISSUER_ACQURIER;     /*0x30000*/	//R007502
			break;
	} /*R007010 END*/

	// >>> R027905
	switch(db->bin_cfg[SH_CFGIX_REFUND_VOID_FLAG])
	{
		case 'V':
			pkg->bin.bin_cfg |= SH_CFG_ReturnVoid;
			break;
		case 'R':
			pkg->bin.bin_cfg |= SH_CFG_ReturnRefund;
			break;
		case 'B':
			pkg->bin.bin_cfg |= SH_CFG_ReturnVoid | SH_CFG_ReturnRefund;
			break;
	}
	// <<< R027905

	//	>>>	R020052
	if(db->bin_cfg[SH_CFGIX_CHECK_MERCHANT] == 'Y')
	{
		pkg->bin.bin_cfg |= SH_CFG_CHECK_MERCHANT;
	}
	//	<<<	R020052
	if(db->bin_cfg[SH_CFGIX_REV_LATERESP] == 'Y')
	{
		pkg->bin.bin_cfg |= SH_REV_LATERESP;
	}

	switch(db->bin_cfg[SH_CFGIX_CAAV_CAVV_VERIFY])
	{
		case '1':
			pkg->bin.addflag |= SH_ADDFLAG_HMAC_MAS;
			break;
		case '2':
			pkg->bin.addflag |= SH_ADDFLAG_CVC2_MAS;
			break;
		case '3':
			pkg->bin.addflag |= SH_ADDFLAG_HMAC_VIS;
			break;
		case '4':
			pkg->bin.addflag |= SH_ADDFLAG_CAVV_VIS;
			break;
		case '5':
			pkg->bin.addflag |= SH_ADDFLAG_HMAC_MAS_DECL;
                        break;
		case '6':
                        pkg->bin.addflag |= SH_ADDFLAG_CVC2_MAS_DECL;
                        break;
                case '7':
                        pkg->bin.addflag |= SH_ADDFLAG_HMAC_VIS_DECL;
                        break;
                case '8':
                        pkg->bin.addflag |= SH_ADDFLAG_CAVV_VIS_DECL;
                        break;
	}
	
	if(db->bin_cfg[SH_CFGIX_AMEX_CSC] == 'Y')
	{
		pkg->bin.addflag |= SH_ADDFLAG_AMEX_CSC;
	}
	else if( db->bin_cfg[SH_CFGIX_AMEX_CSC] == 'S' )
	{
		pkg->bin.bin_cfg |= SH_CSC_CHECK_STAND_IN_ONLY;
	}

	if ( db->bin_cfg[SH_CFGIX_ALLOW_ZERO_AMT_PREAUTH] == 'Y' )
	{
		pkg->bin.bin_cfg |= SH_CFG_ALLOW_ZERO_AMT_PREAUTH;
	}/*
	if ( db->bin_cfg[SH_CFGIX_KPE_KEYBLOCK] == 'Y' )
	{
		pkg->bin.bin_cfg |= SH_CFG_KPE_KEYBLOCK;
		OTraceDebug("D-SHC-137050: Keyblock configuration set\n");
	}*/
	switch(db->bin_cfg[SH_CFGIX_KPE_KEYBLOCK])
	{
		OTraceDebug("D-SHC-137050: Keyblock configuration set\n");
		case 'Y':
			pkg->bin.bin_cfg |= SH_CFG_KPE_KEYBLOCK;
			break;
		case 'A':
			pkg->bin.bin_cfg |= SH_KB_VERSIONID_A;
			break;
		case 'B':
			pkg->bin.bin_cfg |= SH_KB_VERSIONID_B;
			break;
		case 'C':
			pkg->bin.bin_cfg |= SH_KB_VERSIONID_C;
			break;
		case 'D':
			pkg->bin.bin_cfg |= SH_KB_VERSIONID_D;
			break;
		case 'E':
			pkg->bin.bin_cfg |= SH_KB_RACL_ATL_VAR;
			pkg->bin.bin_cfg |= SH_KB_VERSIONID_A;
			break;
		case 'F':
			pkg->bin.bin_cfg |= SH_KB_RACL_ATL_VAR;
			pkg->bin.bin_cfg |= SH_KB_VERSIONID_B;
			break;
		case 'G':
			pkg->bin.bin_cfg |= SH_KB_RACL_ATL_VAR;
			pkg->bin.bin_cfg |= SH_KB_VERSIONID_C;
			break;
		case 'H':
			pkg->bin.bin_cfg |= SH_KB_RACL_ATL_VAR;
			pkg->bin.bin_cfg |= SH_KB_VERSIONID_D;
			break;
		case 'V':
			pkg->bin.bin_cfg |= SH_KB_RACL_ATL_VAR;
			break;
	}
	if ( db->bin_cfg[SH_CFGIX_ENABLE_REFNUM_EVENTKEY] == 'Y' )
	{
		pkg->bin.bin_cfg |= SH_CFG_ENABLE_REFNUM_EVENTKEY;
		OTraceDebug("D-SHC-137060: Refnum based event key configuration set\n");
	}

	OTraceDebug("D-TEST-121:value of bin configuration is[%s][%c]\n",db->bin_cfg,db->bin_cfg[3]);
	/*
	 * R001835 Set Bin Down for Interac Bin
	 */
	if(shcBinIsInterac(pkg))
	{
		shcBin->setInstDown(); 
	}

	OTraceDebug("D-SHC-137023: format_record() done \n");
	return(0);
}



int find_owners()
{
	/*
	 *	Called after all memory has been initialised to locate the
	 *	owner records for those entries which need it
	 */
	
	int		i;
	int		textid;

	char *p = NULL;
	struct shckeysmem *pTmp = NULL;
	struct shckeysmem *pTmp2 = NULL;

	p= rm_getappkey(shcAppid);
	for(i = 0; i < pShcAppHead->keysused; ++i, p+=pShcAppHead->keysize)
	{
		pTmp = (struct shckeysmem *)p;
		if(pTmp->textid != PKG_NEEDS_OWNER)
			continue;
	    
		textid = shc_search_bintable_inst(pTmp->institutionid, pTmp->owner);
		if(textid < 0)
		{
			OTraceError("E-SHC-137024: Could not find owner <%s><%s> for bin <%s><%s>\n",
				pTmp->institutionid, pTmp->owner, 
				pTmp->institutionid, pTmp->userbinid);
				continue;
		}

		pTmp2 = (struct shckeysmem *)(rm_getappkey(shcAppid)+pShcAppHead->keysize*textid);
		pTmp->textid = pTmp2->textid;
	}
	return(0);
}





int get_keys(struct shcbindb *db, struct shckeysmem *shckeysmem, struct shcpkg *pkg)
{
	/*
	 *	Load the key data
	 */

	return(format_keys(db, shckeysmem, pkg));					/* 10001935 */
}



int format_keys(struct shcbindb *db, struct shckeysmem *shckeysmem, struct shcpkg *pkg)																/* 10001935 */
{
	/*
	 *	Load/update key and pin data
	 */

	if(format_pinkeys(db, shckeysmem, pkg) < 0)					/* 10001935 */
		return(-1);

	
	return(0);
}






int format_pinkeys(struct shcbindb *db, struct shckeysmem *shckeysmem, struct shcpkg *pkg)															/* 10001935 */
{
	static struct rules_keytab *pin_keyp = NULL;
	static int pin_fd = (-1);
	struct pinverparm *shcPinLocal = NULL;
	

	int		i;

	if (shcPinAppid < 0)
	{
		shcPinAppid = rm_getappid("shared-cash-pins");
		if (shcPinAppid < 0)
		{
			OTraceDebug("D-SHC-137051:Failed to get appid. Abort shared-cash-pins init\n");
			syslg("D-SHC-137051:Failed to get appid. Abort shared-cash-pins init\n");

			return -1;
		}
		else
		OTraceInfo("I-SHC-137038:Received appid.In shared-cash-pins init\n");
	}
	int sleeptime = 0;
	while (rm_appCreateSemaphore( shcPinAppid, "SHPN" ) < 0)
	{
		if (sleeptime > 120)
		{
			OTraceError("E-SHC-137037: Unable to create semaphore.  Abort updating/init shared-cash-pins\n");
			syslg("E-SHC-137037: Unable to create semaphore. Abort updating/init shared-cash-pins\n");
			return(-1);
			}
		OTraceInfo("I-SHC-137052: Wait for shared-cash-pins to be ready...\n");
		sleep(1);
		sleeptime++;
	}
	if ( rm_appLockMemory(shcPinAppid) < 0 )
	{
		OTraceError("E-SHC-137050:Can't get lock, Abort shared-cash-pins init.\n");
		syslg("E-SHC-137050:shared-cash-pins initialization failed.\n");
		return -1;
	}
	else
	OTraceInfo("I-SHC-137039:shared-cash-pins initializated\n");

	if ( rm_attach( shcPinAppid, RULES_VER_CURRENT ) < 0)
	{
		OTraceError("E-SHC-137036: Unable to attach to LOADING version \n");
		syslg("E-SHC-137036: Unable to attach to LOADING version. Abort updating/init shared-cash-pins records\n");
		rm_appUnlockMemory(shcPinAppid);
		return(-1);
	}
	else
	OTraceInfo("I-SHC-137040:Attached to LOADING version. In updating/init shared-cash-pins records\n");

	
	if(pin_keyp == NULL)
		if((pin_keyp = rm_getapphead(shcPinAppid)) == NULL)
		{
			OTraceError("E-SHC-137025: Unable to acquire header for Pin Application Id.\n");
			rm_appUnlockMemory(shcPinAppid);
			return(-1);
		}

	

	pkg->bin.pinparm = (-1);

	/*	convert to a form usable by the atm */
	ICInstId_pure(pindb.institutionid, db->institutionid);
	strcpy(pindb.bin, db->pinparm);


	/*
	 *	o	Open records if needed
	 */
	if(pin_fd == -1)
		if((pin_fd = dbm_open("pinverparm_inst", getpid())) < 0)
		{
			OTraceFatal("F-SHC-137026: Unable to open pinverparm_inst\n");
			rm_appUnlockMemory(shcPinAppid);
			return(-1);
		}

	/*
	 *	Locate an existing entry if there
	 */
	for(i = 0; i < pin_keyp->textused; ++i)
	{ //R029957
		shcPinLocal  = (struct pinverparm *)(rm_getapptext(shcPinAppid)+ pin_keyp->textsize * i);
		if((stricmp(pindb.bin, shcPinLocal->bin) == 0) && 
			(stricmp(pindb.institutionid, shcPinLocal->institutionid) == 0))
		{
			/*	Already exists */
			pkg->bin.pinparm = i;
			shckeysmem->pinid	 = i;						/* 10001935 */
			if(!update_all)
			{
				rm_appUnlockMemory(shcPinAppid);
				return(0);
			}
			else
				break;
		}
	}


	/*
	 *	o	All cards must have a card record
	 */
	if(dbm_read(pin_fd, (char *)&pindb, DBM_REQUAL) < 0)
	{
		OTraceError("F-SHC-137055:Failed to find pin in db(%s,%s)\n", pindb.institutionid, pindb.bin);
		rm_appUnlockMemory(shcPinAppid);
		return(0);
	}

	ICInstId_pure(pindb.institutionid, pindb.institutionid);
    	memcpy (&pin, &pindb, sizeof (PINVERPARM)); 
	if (i < pin_keyp->textused)
	{
		//Just use the existing entry to save space
		memcpy(shcPinLocal, &pin, sizeof (PINVERPARM));
		rm_appUnlockMemory(shcPinAppid);
		return(0);
	}

	// >>> R029583
	if (pin_keyp->textused >= pin_keyp->ntext)
	{
		int version = 0;
		if(rm_isMultiVerSupported(shcPinAppid))
		{
			if (rm_createNewVersion(shcPinAppid,&version) < 0)
			{
				OTraceError("F-SHC-137049:Failed to creat new shared-cash-pins version. Abort key init\n");
				syslg("F-SHC-xxxxx:Failed to creat new shared-cash-pins version. Abort key init\n");
				rm_appUnlockMemory(shcPinAppid);
				return -1;
			}
		}
		else
		{
			OTraceError("F-SHC-137048:MultiVersion not supported. Abort key update\n");
			syslg("F-SHC-xxxxx:MultiVersion not supported. Abort key update\n");
			rm_appUnlockMemory(shcPinAppid);
			return -1;
		}
		if (rm_waitstate(shcPinAppid, version,  RM_STATE_LOAD, 180 )<0)
		{
			OTraceError("E-SHC-139040:shared-cash-pins(%d) not ready, abort init\n", shcPinAppid);
			syslg("E-SHC-139040:shared-cash-pins(%d) not ready, abort init\n", shcPinAppid);
			rm_appUnlockMemory(shcPinAppid);
			return -1;
		}
		else
		OTraceInfo("I-SHC-137041:shared-cash-pins(%d) ready , In init\n",shcPinAppid);

		//copy data from current version to loading version
		struct rules_keytab oldAppHead = { 0 };
		int memsize = pin_keyp->textsize*pin_keyp->textused;
		char *localMem = (char *)calloc(pin_keyp->textsize, pin_keyp->textused);
		if (!localMem)
		{
			OTraceError("E-SHC-138043:Can't allocat memory(%d) bytes, Abort shared-cash-pins init.\n", memsize);
			syslg("E-SHC-138043:Can't allocat memory(%d) bytes, Abort shared-cash-pins init.\n", memsize);
			rm_appUnlockMemory(shcPinAppid);
			return -1;
		}
		else
		OTraceInfo("I-SHC-137042:Allocated memory(%d) bytes,In shared-cash-pins init.\n", memsize);
		memcpy(localMem,rm_getapptext(shcPinAppid),memsize);
		memcpy(&oldAppHead,pin_keyp, sizeof(oldAppHead));
		if ( rm_attach( shcPinAppid, RULES_VER_LOADING ) < 0)
		{
			OTraceError("E-SHC-138044: Unable to attach to LOADING version \n");
			syslg("E-SHC-138044: Unable to attach to LOADING version. Abort updating/init shared-cash-pins records\n");
			rm_appUnlockMemory(shcPinAppid);
			return(-1);
		}
		else
		OTraceInfo("I-SHC-137043:Attached to Loading Version.In updating/init shared-cash-pins records\n");
		pin_keyp = rm_getapphead(shcPinAppid);
	
		memcpy(rm_getapptext(shcPinAppid), localMem, memsize);
		pin_keyp->textused = oldAppHead.textused;
		
		// <<< R029583
	}		
	/*
	 *	Otherwise insert a new entry
	 */
	if(rm_insert_text(shcPinAppid, (char *)&pin, pin_keyp->textused) < 0)
		OTraceFatal("F-SHC-137027: Unable to insert pin text\n");
	
	OTraceDebug("D-SHC-137028:pin_keyp->textused is '%d'\n", pin_keyp->textused);

	shckeysmem->pinid = pin_keyp->textused;						/* 10001935 */

	OTraceDebug("D-SHC-137029:shckeysmem->pinid is '%d'\n", shckeysmem->pinid);	/* 10001935 */

	pkg->bin.pinparm	= pin_keyp->textused;
	++pin_keyp->textused;

	// >>> R029583
	if (rm_setstate( shcPinAppid, RULES_VER_ATTACHED, RM_STATE_READY) < 0)
	{
		OTraceError("E-SHC-138045:Can't set rule state to READY, Abort shared-cash-pins init.\n");
		syslg("E-SHC-138045:Can't set rule state to READY, Abort shared-cash-pins init.\n");
		rm_appUnlockMemory(shcPinAppid);
		return -1;
	}
	else
	 OTraceInfo("I-SHC-137044:Set Rule state to ready, In shared-cash-pins init.\n");

	if (rm_unsetloading(shcPinAppid) < 0)
	{
		OTraceError("E-SHC-138046:Can't unset rule state of LOADING, Abort shared-cash-pins init.\n");
		syslg("E-SHC-138046:Can't unset rule state of LOADING, Abort shared-cash-pins init.\n");
		rm_appUnlockMemory(shcPinAppid);
		return -1;
	}
	else
	OTraceInfo("I-SHC-137045:Unset Rule state of LOADING, In shared-cash-pins init.\n");

	if (rm_setcurrent( shcPinAppid, RULES_VER_ATTACHED)<0)
	{
		OTraceError("E-SHC-138047:Can't set rule to CURRENT, Abort shared-cash-pins init.\n");
		syslg("E-SHC-138047:Can't set rule to CURRENT, Abort shared-cash-pins init.\n");
		rm_appUnlockMemory(shcPinAppid);
		return -1;
	}
	else
	OTraceInfo("I-SHC-137046:Set Rule to CURRENT,In shared-cash-pins init.\n");
	rm_appUnlockMemory(shcPinAppid);
	// <<< R029583
	return(0);
}


int format_securitykeys(struct  shckeys *secdb, struct shcsecurity *sec)														/* 10001935 */
{
	static	struct rules_keytab *sec_keyp = NULL;
	static	int sec_fd = (-1);
	int		i;

    /* R016654 */
	ICInstId_pure(secdb->institutionid, secdb->institutionid);
	/* If keyparam is set use it otherwise use userbinid */
	memset(sec, 0, sizeof(struct shcsecurity));
	memcpy(&sec->k, secdb, sizeof(sec->k));

    set_default_keylens(sec);
    sec->hash = shcApp->shcKeyObj->getHashValue(sec->k.userbinid);

	return(0);
}


int find_outbound(char *outroute)
{
	int outbound;
	int i;

	outbound	= mb_locateoutbound(outroute);
	if(outbound < 0)
	{
		/*	This guy is not here
		 *	1.	Create it
		 *	2.	Duplicate it
		 *	3.	Find outbound
		 */
		if((i = mb_createmailbox(outroute, 0, 0)) < 0)
		{
			OTraceFatal("F-SHC-137033: Unable to create an entry for: %s\n", outroute);
			return(-1);
		}

		if(mb_duplicatemailbox(i) < 0)
		{
			OTraceFatal("F-SHC-137034: Unable to duplicate mail box: %d for entry %s\n",
				i, outroute);
			return(-1);
		}
		outbound = mb_locateoutbound(outroute);
		if(outbound < 0)
		{
			OTraceWarning("W-SHC-137035: Unable to locate outbound entry for: %s\n", outroute);
			return(-1);
		}
	}

	return(outbound);
}




int find_mailbox(const char *name)
{
	int mbid;

	OTraceInfo("I-SHC-137036:find_mailbox(%s)\n", name);

	mbid = mb_locatemailbox(name);
	if(mbid < 0)
		mbid = mb_createmailbox(name, 0, 0);
	
	if(mbid < 0)
		OTraceFatal("F-SHC-137037: Unable to locate or create mail box %s\n", name);
	
	return(mbid);
}


int load_servers()
{
	/*
	 *	Scan my config or maybe its hard coded
	 *	In either case I can load my applications
	 */
	int	mbid;

	
	if(msgtype != MAIN_REC)
		return(0);

	/*
	 *	Find the required mail box for the shared cash
	 */
	mbid = mb_locatemailbox(SHC_SERVER_NAME);
	if(mbid < 0)
	{
		OTraceFatal("F-SHC-137038: No %s mail box: Start packet not sent.\n", SHC_SERVER_NAME);
		return(0);
	}

	/*
	 *	Hard coded:	Send init packet to my server
	 */
	mb_sendstartpacket(mbid);
	OTraceInfo("I-SHC-137048:Successfully loaded the [%s] by the function load_servers\n",argv[RULES_PARM_RULENAME]);
	return(0);
}


int update_record(char *instid, char *binid)
{
	/*
	 *	Update an existing database record into memory
	 */
	bin_t	bin;
	bin_t	inst;
	struct	shcbindb db;
	struct	shcpkg	*pkg;
	struct	shcpkg 
		*create_entry(char *bin, struct shckeysmem **keys, struct shcbindb *db);
	struct	shckeysmem	*shckeysmem;
	int isLocked = 0;
	

	rm_init();
	dbm_init();
	shc_init();

	call_dbm_init = 1;

	/*	Normalize the inst */
	ICInstId_pure(inst, instid);

	/*	Normalize the inst */
	ICBin_rjfy(bin, binid);

	if(locate_database(inst, bin, &db) < 0)
		return(-1);

	if (shcSharedMemoryHelperObj->lockRule(sharedCashRuleName, &isLocked, &appid) < 0)
	{
		OTraceError("E-SHC-138059:Can't lock shared-cash rule, abort update.\n");
		return -1;
	}
	else
	OTraceInfo("I-SHC-137049:Locked shared-cash rule, In update.\n");

	
	if (shcSharedMemoryHelperObj->attachCurrent(&appid, &pShcAppHead) < 0)
	{
		OTraceError("E-SHC-138059:Can't attach shared-cash rule, aborted\n");
		if (isLocked)
			rm_appUnlockMemory(appid);
		return -1;
	}
	else
	OTraceInfo("I-SHC-137050:Attached Shared-cash rule,In update\n");

	/*	Check that owner (if diff. from bin) exists */
	if(stricmp(db.userbinid, db.network) != 0 &&
	   shc_search_bintable_inst(db.institutionid, db.network) < 0)
	{
		OTraceFatal("F-SHC-137039: Update of %s %s failed: Owner %s not located\n", instid, bin, db.network);
		if (isLocked)
			rm_appUnlockMemory(appid);
		return(-1);
	}

	if(locate_memory(db.institutionid, db.userbinid, &shckeysmem, &pkg) < 0)				/* 10001935 */
	{
		if((pkg = create_entry(db.networkid, &shckeysmem, &db)) == NULL)	/* 10001935 */
		{
			if (isLocked)
				rm_appUnlockMemory(appid);
			return(-1);
		}
		justCreated = 1;
	}
	else if(update_owner(db.networkid, shckeysmem, &pkg, &db) < 0)		/* 10001935 */
	{
		if (isLocked)
			rm_appUnlockMemory(appid);
		return(-1);
	}
	
	if(update_memory(&db, shckeysmem, pkg) < 0)					/* 10001935 */
	{
		if (isLocked)
			rm_appUnlockMemory(appid);
		return(-1);
	}
	
	OTraceDebug("D-SHC-137040: Update done for Institution %s Bin %s\n", inst, bin);

	if (isLocked)
		rm_appUnlockMemory(appid);
		OTraceInfo("I-SHC-137051:Updated the exsisting rules by update_record function\n");
	return(0);
}



int locate_database(char *instid, char *bin, struct shcbindb *db)
{
	/*
	 *	Read the inst id record from the database into program variables
	 */
	
	static	int	shc_fd = (-1);

	if(shc_fd < 0)
		if((shc_fd = dbm_open("shcbin_ix_2", dbmid)) < 0)
		{
			OTraceFatal("F-SHC-137041: Unable to open shcbin_ix_2 index: Error: %d\n", dbm_errno);
			return(-1);
		}

	snprintf(db->institutionid, sizeof(db->institutionid),"%s",instid);
	snprintf(db->userbinid, sizeof(db->userbinid),"%s",bin);
	if(dbm_read(shc_fd, (char *)db, DBM_REQUAL) < 0)
	{
		OTraceFatal("F-SHC-137042: Record for Institution %s bin %s not found.\n", instid, bin);
		return(-1);
	}

	ICInstId_pure(db->institutionid, db->institutionid);
	return(0);
}




int locate_memory(char *instid, char *userbin, struct shckeysmem **keys, struct shcpkg **pkg)
{
	/*
	 *	Attempt to locate the entry for the bin in memory
	 */
	

	int		i;
	newlyFoundShcBinKey = NULL;
	i = shcApp->shcBinObj->shc_locate_bin(pkg, instid, userbin);

	if(!newlyFoundShcBinKey)
		return(-1);
	
	*keys = newlyFoundShcBinKey;
	return(0);
}


struct shcpkg *create_entry(char *bin, struct shckeysmem **keys, 
									struct shcbindb *db)
{
	/*
	 *	Create a new slot for this entry
	 */
	
	int		next_key, next_text;
	struct	shcpkg	*pkg;
	int		newtext = 1;

	struct shckeysmem *pTmp = NULL;

	next_text = pShcAppHead->textused;
	next_key  = pShcAppHead->keysused;

	if(next_key + 1 >= pShcAppHead->nkeys)
	{
		OTraceFatal("F-SHC-137043: Not enough memory to add new BIN entry\n");
		return(NULL);
	}

	if(stricmp(db->userbinid, db->network) != 0)
	{
		next_text = shc_search_bintable_inst(db->institutionid, db->network);
		if(next_text < 0)
			return(NULL);
		pTmp = (struct shckeysmem *)( rm_getappkey(shcAppid) + pShcAppHead->keysize*next_text);
		next_text	= pTmp->textid;
		newtext		= 0;
	}

	else if(next_text + 1 >= pShcAppHead->ntext)
	{
		OTraceFatal("F-SHC-137044: Not enough memory to add new BIN entry\n");
		return(NULL);
	}
	else
		++pShcAppHead->textused;
		
	
	++pShcAppHead->keysused;
	
	pShcAppHead->flags &= ~RULES_KEY_SORTED;
	
	pkg = (struct shcpkg *)( rm_getapptext(shcAppid) + pShcAppHead->textsize*next_text);
	pTmp = (struct shckeysmem *)( rm_getappkey(shcAppid) + pShcAppHead->keysize*next_key);
		
	*keys = pTmp;
	istsafe_strcpy(pTmp->bin, sizeof(pTmp->bin), bin);
	strcpy(pTmp->owner, db->network);

	if(newtext)
	{
		pTmp->textid = next_text;
		istsafe_strcpy(pkg->bin.networkid, sizeof(pkg->bin.networkid), bin);
		pkg->saf.fd				= (-1);
		pkg->saf.replayid		= (-1);
		pkg->bin.flags			= 0;
	}

	pTmp->textid = next_text;

	return(pkg);
}

int update_owner(char *bin, struct shckeysmem *shckeysmem, struct shcpkg **shcpkg, struct shcbindb *db)										/* 10001935 */
{
	/*
	 *	Given an existing entry check if the owner has changed and if
	 *	so update appropriate pointers
	 */
	struct shcpkg *pkg = NULL;
	int		next_text;
	struct shckeysmem *pTmp = NULL;

	/*
	 *	NOTE:	shcpkg has already been filled out
	 */
	
	pkg = *shcpkg;

	/*
	 *	Check memory against database
	 */
	if(stricmp(pkg->bin.owner, db->network) == 0)
	{
		/*	nothing changed:	Do nothing */
		OTraceInfo("I-SHC-137045: Nothing changed: %s\n", db->networkid);
		return(0);
	}
	

	/*	Is the new owner same as current bin ? */
	if(stricmp(db->network, db->userbinid) == 0)
	{
		/*	Create new text entry */
		if(pShcAppHead->textused + 1 >= pShcAppHead->ntext)
		{
			OTraceFatal("F-SHC-137046: No room in text table for new bin: %s\n", db->networkid);
			return(-1);
		}

		shckeysmem->textid = pShcAppHead->textused;				/* 10001935 */
		pkg = (struct shcpkg *)( rm_getapptext(shcAppid) + pShcAppHead->textsize*pShcAppHead->textused);
		pShcAppHead->textused++;
		istsafe_strcpy(pkg->bin.networkid, sizeof(pkg->bin.networkid), bin);
		pkg->saf.fd				= (-1);
		pkg->saf.replayid		= (-1);
		pkg->bin.flags			= 0;
	}
	else
	{
		/*	Locate the existing text buffer */
		next_text	= shc_search_bintable_inst(db->institutionid, db->network);
		if(next_text < 0)
			return(-1);

		pTmp = (struct shckeysmem *)( rm_getappkey(shcAppid) + pShcAppHead->keysize*next_text);
		shckeysmem->textid = pTmp->textid;
		
		pkg=(struct shcpkg *)( rm_getapptext(shcAppid) + pShcAppHead->textsize*shckeysmem->textid);
	}

	*shcpkg = pkg;
	return(0);
}


int update_memory(struct shcbindb *db, struct shckeysmem *keys, struct shcpkg *pkg)
{
	/*
	 *	Given a database record in 'db' and a package record in 'pkg'
	 *	this program will update the memory image according to the
	 *	database image
	 */
	
	if(format_record(db, keys, pkg, 0) < 0)
		return(-1);
	
    if( strcmp(db->userbinid, db->network) == 0 )       /* R001835 */
		if(format_keys(db, keys, pkg) < 0)
			return(-1);
	
	return(0);
}

/*static int saf_exists(char *bin)*/
InstitutionParams shcinitParams;
int saf_exists(const char *institutionid, const char *userbinid, const char *bin)
{
	char	buf[252];
	static	int initialized = 0;
	char *p1, *p2;

	if( !initialized )
	{
		InstParamsList shcinitParamsList;
		
		shcinitParamsList.Add("shc.look_at_saf", PI_BOOLEAN);
		
		shcinitParams.Load(shcinitParamsList);
		initialized = 1;
	}

	if(!shcinitParams.getInst((char *)institutionid)->Get((char *)"shc.look_at_saf"))
		return(0);

				/* R009023 >> */
//	sprintf(buf, "saf/%010s.SAF", bin);
	snprintf( buf, sizeof(buf),"%s.%s", institutionid, userbinid);
	for(p1=buf, p2=buf; *p1; p1++ )
	{
	    if( *p1 != ' ' )
	        *p2++ = *p1;
	}
	*p2 = '\0';
				
//	if( access(uenv_constructfile(OLOGDIR_ENV, buf), 0) < 0 )
	if( shcApp->shcSafIOHelperObj->shc_saf_get_name(buf, sizeof(buf)) < 0 )
		return(0);
    OTraceInfo("I-SHC-137047: SAF file '%s.SAF' existed. Marked %s\n",
                buf, shcApp->saf_interleave ? "SH_REPLAY": "DOWN");
				/* R009023 << */

	return(1);
}

static int set_default_keylens(struct  shcsecurity *sec)
{
	if (sec->k.kek_len == 0)
       	sec->k.kek_len = 16;
	if (sec->k.isskpe_len == 0)
		sec->k.isskpe_len = 16;
	if (sec->k.isskme_len == 0)
		sec->k.isskme_len = 16;
	if (sec->k.issmac_len == 0)
		sec->k.issmac_len = 16;
	if (sec->k.acqkpe_len == 0)
		sec->k.acqkpe_len = 16;
	if (sec->k.acqkme_len == 0)
		sec->k.acqkme_len = 16;
	if (sec->k.acqmac_len == 0)
		sec->k.acqmac_len = 16;
	return(0);
}

static int shc_search_bintable_inst (char *instid, char *binid)
{
	int i;
	char * p  = NULL;
	struct shckeysmem *pTmp = NULL;
	p= rm_getappkey(shcAppid);
	for(i = 0; i < pShcAppHead->keysused; ++i, p+=pShcAppHead->keysize)
	{
		pTmp = (struct shckeysmem *)p;
		if(stricmp(instid, pTmp->institutionid) == 0 &&
		   stricmp(binid, pTmp->userbinid) == 0)
			return(i);
	}
	return (-1);
}

int update_record_shckey()
{
    OTraceDebug("D-SHC-138060:shared-cash-security Update.\n");
    rm_init();
    if(rm_isMultiVerSupported(appid))
    {
        int version = 0;
		if (rm_createNewVersion(appid,&version) < 0)
		{
			OTraceError("F-SHC-138061:Failed to creat new shared-cash-security version. Abort key init\n");
			syslg("F-SHC-138061:Failed to creat new shared-cash-security version. Abort key init\n");
		}
    }
    else
	{
		OTraceError("F-SHC-138062:MultiVersion not supported. Abort key update\n");
		syslg("F-SHC-138062:MultiVersion not supported. Abort key update\n");
	}
	OTraceInfo("I-SHC-137054:Successfully Updated the shckeys exsisting rules by update_record_shckey function \n");

    return(0);
}



/*
 *   Old history
 *
 *          wrg 961115  Added support for various bin.flags 
 *	Sunny		12Dec91		Make sure dbm_init was called before using
 *							dbm_close_all routine
 *	Ashraf		08Jan92		Made additions for new field ccstlmt
 *	Ashraf		05feb92		Fixed minor problem with format_keys()
 *	ad			31mar92		Display version on initialisation
 *	ad			15may92		Look for parameter shc.look_at_saf to determine
 *							if we should keep the inst. down when the saf
 *							file exists.
 *  bsa         30jul92     Added flag to give option of seeking issuer
 *							approval before returning reversal to acq
 *	ad			31jul92		Read the revflag from database
 *	ad			23oct92		Added flags
 *							SH_CHKFLRLIM, SH_SENDREV, SH_SAFAUTH
 *	ss			04nov92		Added SH_SENDREV_ALWAYS
 *	ad			24nov92		Added SH_SENDACK
 *	ad			26nov92		Added SH_PREAUTH_ON_VALIDATE
 *	ss			08Mar93		Chanage SEQ read to RFIRST and RNEXT so that
 *							it runs properly using Ingres DBM
 *	ad			29apr93		Added SH_CHECKDUP
 *  MI			31May93		Added SH_PREAUTH_SUPPORT switch statement
 *							using bintype.
 *	aes			18Jun93		Added the ability to read a shcauth flag
 *							and determine if currency conversion is
 *							to be performed for that BIN.
 *							The flag when set to Y is initialised to
 *							SH_CURRENCY_CONV.
 *
 *	ad			05jul93		Added support for ON US flag
 */
