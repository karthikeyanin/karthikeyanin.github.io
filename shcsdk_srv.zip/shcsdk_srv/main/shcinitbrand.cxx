static char _shcinitbrand_cxx_what[] = "@(#) shcinitbrand.cxx 1.12.1.6 20/04/16 18:52:32";

/*
 *  Copyright (C) 2004 eFunds Corporation ("eFunds").  All Rights Reserved.     
 *  eFunds Canada Corporation is an authorized user.                            
 *                                                                              
 *  IST is a registered trademark of eFunds Corporation.  Other brand or        
 *  product names are trademarks or registered trademarks of their respective   
 *  holders.                                                                    
 *                                                                              
 *  The information contained herein is the unpublished proprietary property    
 *  of eFunds.  Except as specifically authorized in writing by eFunds, the     
 *  holder of this document shall: i) keep all information contained herein     
 *  confidential, and ii) protect the information, in whole or in part, from    
 *  disclosure and dissemination to all third parties.                          
 *                                                                          
 *  This document and the software described in it are furnished under license  
 *  and may be used or copied only in accordance with the terms of such license.
 *  This document is supplied for information purposes only, is subject to      
 *  change without notice, and should not be construed as a commitment by       
 *  either eFunds Corporation or eFunds Canada Corporation. 
 */
/*
 *
 *                        MODIFICATION HISTORY                  REVIEW
 *
 *	SPR#	Who	Date	Description			Who	Date   
 * ===========================================================================
 * R027802 jyang 25Jan10 Initial version to support "Block by Brand"
 * R028747 dipa  17Nov10 Remove reference to rules_keytab[]
 */

//File Number 170

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <errno.h>
#include <mb.h>
#include <rules.h>
#include<ic/ic_instid.h>
#include <oasis.h>
#include <DBM3.h>
#include <dbm.h>
#include <dbm_private.h>
#include <ist_otrace.h>
#include <shcdef.h>	
#include <shc.h>
#include <ShcApp.h>
#include <block_by_brand.h>
#include <istsafe.h>

#include <HaPtmCctHelper.h>

/*
 *	Example application initialiser
 */



/*
 *	An application initialiser is invoked with the following paramaters
 *
 *		<taskname>	<mode>	<rulename>	<appid> <srvname> [<data>]
 *
 *	<taskname>		the executable name of this task		(argv[0])
 *	<mode>			the mode of processing
 *						'count'			count space needed and report to strm
 *						'init'			init the rules in-core database
 *						'update'		update an existing rule
 *						'load'			load you application
 *
 *	<rulename>		the name of the rule to be initialised
 *	<appid>			the system assigned application id for this rule
 *
 *	<srvname>		the server to which count information should be sent
 *
 *	<data>			data which might be included in an 'update' command
 *
 *
 *****************************************************************************
 *
 *	This is SHARED Cash ExtBin initialiser
 *	This task accepts initialisation requests for message
 *
 *			brandblocked
 */

/* Following two parameters determines the minimum number of entries allocated in shared memory */
#define MINIMUM_MEMORY_INCREMENT	50

/* Minimum percentage of extra memory needed */
#define EXTRA_MEMORY				20

extern "C"
{
	int keys_cmp(const void *anykey1, const void *anykey2);
}

int shcinitbrandblockedGetMinimumSpace();
int update_record();
int count_records();
int init_records();
int dump_records();
int load_servers();
int pexit(int n);
int initSys();
int processError(int ret, DBMHSTMT sh);
int format_record( BLOCK_BY_BRAND *, BLOCK_BY_BRAND * );


static char ver[88]="IST: BrandBlocked Initializer r" VERSION;
struct rules_keytab keytab = { 0 };
int  con_id = -1;
int  appid;
int  my_count = 0;
int  size;
int  argc     = 0;
char **argv   = NULL;
const char sqlStatementQuery[]="SELECT institutionid, cardproduct, destination FROM block_by_brand";

// Define global variable for shared memory version report
int gBrRuleVer = -1;

static int shc_initb_load()
{
	int     ret = 0;
	if (appid == -1)
	{
		rm_init();
		if((appid = rm_getappid("shc-brand-blocked")) == -1)
		{
			OTraceFatal("F-SHC-170.44:unable to locate message name shc-brand-blocked\n");
			return -1;
		}
	}
	if(rm_attach( appid, RULES_VER_LOADING ) != 0)
		return -1;

	// get the version number: gBrRuleVer
	rm_attachedversion(appid, &gBrRuleVer);
	return (ret);
}

int main(int a_rgc, char **a_rgv)
{
	argc = a_rgc;
	argv = a_rgv;
	argv0 = a_rgv[0];
	
	catch_all_signals(NULL);

	syslg("%s\n", ver);
	OTraceOn("shcinitbrand");
	OTraceLog("%s\n", ver);

	// Define return value for return value report
	int aRet = 0;
	// call function to mangle the argv
	rm_extOptFrArg(argc, argv);

	HaPtmCctHelper::deinit() ;

	if(argc < 5)
	{
		OTraceFatal("F-SHC-170.01: %d is an invalid number of parameters\n", argc);
		aRet = -1;
		goto exit;
	}

	mb_init();

	OTraceInfo("I-SHC-170.02: %s mode for rule %s\n", argv[RULES_PARM_MODE], argv[RULES_PARM_RULENAME]);

	con_id = mb_locatemailbox(argv[RULES_PARM_SRVNAME]);
	if (con_id == -1)
	{
		OTraceFatal("F-SHC-170.03: Unable to connect to %s: Error: %d\n",
		    argv[RULES_PARM_SRVNAME], errno);
		aRet = -1;
		goto exit;
	}

//	if (rm_init() < 0)
//	{
//		OTraceDebug("F-SHC-170.45: Unable to connect to RuleManager : Error: %d\n", errno);
//		pexit(1);
//	}


	/* Extract all paramaters */

//	appid = rm_getappid(argv[RULES_PARM_RULENAME]);
	appid = atoi(argv[RULES_PARM_APPID]);

	if(stricmp("shc-brand-blocked", argv[RULES_PARM_RULENAME]) != 0)
	{
		OTraceFatal("F-SHC-170.04: Invalid message type: %s\n",
			argv[RULES_PARM_RULENAME]);
		aRet = -1;
		goto exit;
	}

	/* Now determine which we need and perform action */

	if(stricmp(argv[RULES_PARM_MODE], "count") == 0)
		aRet = count_records();
	else if(stricmp(argv[RULES_PARM_MODE], "init") == 0)
		aRet = init_records();
	else if(stricmp(argv[RULES_PARM_MODE], "load") == 0)
		aRet = load_servers();
	else if(stricmp(argv[RULES_PARM_MODE], "update") == 0)
	{
		aRet = update_record();
	}
	else if(stricmp(argv[RULES_PARM_MODE], "dump") == 0)
		aRet = dump_records();
	else
	{
		OTraceFatal("F-SHC-170.05: Don't know how to interpret mode '%s'\n",
		    argv[RULES_PARM_MODE]);
		aRet = -1;
	}

	exit:

	// Output status info based on return value and version number
	rm_outInfo(gBrRuleVer, aRet);

	return pexit(aRet);

}


static void removeTrailingSpace(char *s)
{
	int i;
	
	for (i=strlen(s)-1;i>=0 && s[i] && s[i] == ' '; i--);
	
	s[i+1] = '\0';
	return;
}


int shcinitbrandblockedGetMinimumSpace()
{
	int ret;
	int numOfEntries = 0;
	DBMHSTMT tmpStmt;
	char bp[] = "select count(institutionid) from block_by_brand";
	
	if (dbm_connect() >=0)
	{
		OTraceDebug("D-SHC-170.06:Connecting to database successful\n");
	}
	else
	{
		OTraceFatal("F-SHC-170.07:Connecting to database failed\n");
		return -1;
	}
	ret=DBMAllocStmt(dbm_dbconn, &tmpStmt);
	if (ret < 0)
	{
		OTraceFatal("F-SHC-170.08:Can't allocate statment: %s\n", bp);
		return -1;
	}
	ret=DBMPrepare(tmpStmt, (char*)bp);
	if (ret < 0)
	{
		OTraceFatal("F-SHC-170.09:Can't prepare statment: %s\n", bp);
		return -1;
	}
	ret=DBMExecute(tmpStmt);
	if (ret < 0)
	{
		OTraceFatal("F-SHC-170.10:Can't execute statment: %s\n", bp);
		return -1;
	}
	
	int status;
	ret=DBMBindCol(tmpStmt, 1, DBM_LONGTYPE, &numOfEntries, sizeof(numOfEntries), &status);
	if (ret < 0)
	{
		OTraceFatal("F-SHC-170.11:Can't bind for statment: %s\n", bp);
		return -1;
	}
	
	ret=DBMFetch(tmpStmt);
	if (ret == DBM_NO_DATA)
	numOfEntries = 0;
	else if (ret < 0)
	{
		OTraceFatal("F-SHC-170.12:Can't fetch for statment:%s\n", bp);
		return -1;
	}
	DBMFreeStmt(tmpStmt, DBM_CLOSE);
	
	OTraceDebug("D-SHC-170.13: Found %d records\n", numOfEntries);
	/* Now calculate how many entries we should allocate
	* The number of entries increase by 100.
	* And we need to keep at least 20% free space
	*/
	numOfEntries = (numOfEntries+1) * (100 + EXTRA_MEMORY)/100;
	numOfEntries = (numOfEntries + MINIMUM_MEMORY_INCREMENT - 1)/MINIMUM_MEMORY_INCREMENT * MINIMUM_MEMORY_INCREMENT;

	return numOfEntries;
}


int isEmptyField(char *s)
{
	if (s[0] == '\0' )
		return 1;
	
	int starti, endi, len;
	char tmpBuf[1000];
	len =strlen(s);
	
	for (starti=0; starti<len && s[starti] == ' '; starti++);
	for (endi=len-1; endi>=starti && s[endi] == ' '; endi--);
	
	if (endi < starti)
		return 1;
		
	len=endi-starti+1;
	memcpy(tmpBuf, &s[starti], len);
	
	tmpBuf[len] = '\0';
	if (tmpBuf[0] == '*' )
		return 1;
	
	istsafe_strcpy(s, len+1, tmpBuf);
	return 0;
}
	
int count_records()
{
	/*
	 *	He wants me to inidcate how many keys and text buffers
	 *	as well as their respective sizes
	 *
	 *	I can do this by reading the database or by looking in a
	 *	config file
	 */

	int mbw;

	/* Set up my return packet */

	//keytab.appid = rm_getappid(argv[RULES_PARM_RULENAME]);
	keytab.appid = atoi(argv[RULES_PARM_APPID]);

	if ((my_count = shcinitbrandblockedGetMinimumSpace()) < 0)
		log_msg(FATAL, TO_CC, "F-SHC-170.14:Can't estimate shared memory needed.\n");

	/* Now i tell him how large my buffers should be */

	keytab.keysize = sizeof(BLOCK_BY_BRAND);
	keytab.nkeys	= my_count;
	keytab.textsize	= sizeof(BLOCK_BY_BRAND);
	keytab.ntext	= 0;

	snprintf(keytab.name, sizeof(keytab.name),"%s",argv[RULES_PARM_RULENAME]);

	/* Now I send him the information */

	if ((mbw = mb_write(con_id, 0, &keytab, sizeof(keytab))) < 0)
		OTraceFatal("F-SHC-170.15: Unable to write to server id %d\n", con_id);
	
	OTraceDebug("D-SHC-170.16:count result: keysize[%d] nkeys[%d] textsize[%d] ntext[%d]\n",
		keytab.keysize, keytab.nkeys, keytab.textsize, keytab.ntext);
	
	return(0);
}


int keys_cmp(const void *anykey1, const void *anykey2)
{
	BLOCK_BY_BRAND *k1 = (BLOCK_BY_BRAND *)anykey1;
	BLOCK_BY_BRAND *k2 = (BLOCK_BY_BRAND *)anykey2;
	
	int ret;
	ret = strcmp(k1->institutionid, k2->institutionid);
	if(ret != 0)
		return(ret);

	ret = strcmp(k1->destination, k2->destination);
	if(ret != 0)
		return(ret);

	ret = strcmp(k1->cardproduct, k2->cardproduct);

	return(ret);
}


int init_records()
{
	/* Now I can actualy initialise my table */

	int	key_count = 0, text_count = 0;
	int	i;
	struct rules_keytab *keyp;
	BLOCK_BY_BRAND brandblockedDB;
	BLOCK_BY_BRAND aBrandblocked;

	static	int		recordnum = 0;

	int ind[16] = { 0 };	//	---	R020436 
	int buf[1024];
//	BLOCK_BY_BRAND	*pTmp = (BLOCK_BY_BRAND *)buf;

	initSys();
	if (shc_initb_load() == -1)
		return(-1);
	DBMHSTMT shQuery;
	DBMHDBC ch;	
	DBMRETURN ret = 0;
	if (dbm_connect() >=0)
	{
		OTraceDebug("D-SHC-170.17:Connecting to database successful\n");
		ch=dbm_dbconn;
  }
	else
	{
		OTraceError("E-SHC-170.18: Connecting to database failed\n");
		return (-1);
 	}

 	if( DBMAllocStmt(ch, &shQuery) < 0)
	{
		OTraceError("E-SHC-170.19: Select query statement allocate error:\n%s\n", sqlStatementQuery);
		return -1;
	}
	if( (DBMBindCol(shQuery,1,DBM_STRINGTYPE,brandblockedDB.institutionid,sizeof(brandblockedDB.institutionid),&ind[0]) != DBM_SUCCESS) ||
			(DBMBindCol(shQuery,2,DBM_STRINGTYPE,brandblockedDB.cardproduct,sizeof(brandblockedDB.cardproduct),&ind[1]) != DBM_SUCCESS) ||
			(DBMBindCol(shQuery,3,DBM_STRINGTYPE,brandblockedDB.destination,sizeof(brandblockedDB.destination),&ind[2]) != DBM_SUCCESS)
		)
	{
		OTraceError("E-SHC-170.20: Select query bind error \n");
		return (-1);
	}
	else
	{
		if( DBMPrepare(shQuery, sqlStatementQuery) != DBM_SUCCESS )
		{
			OTraceError("E-SHC-170.21: Select query prepare error:\n%s \n", sqlStatementQuery);
		}
		
		ret = DBMExecute(shQuery);
		if(ret != DBM_SUCCESS)
		{
			if(processError(ret, shQuery))
			{
				DBMFreeStmt(shQuery, DBM_DROP);
				return (-1);
			}

		}
	}
				/*	Insert the key */
	keyp = rm_getapphead(appid);
	keyp->keysused = 0;
	for(key_count = 0;;key_count++)
	{
		recordnum ++;
		memset((char *)&brandblockedDB, 0, sizeof(brandblockedDB));
		memset((char *)&aBrandblocked, 0, sizeof(brandblockedDB));
		
		ret = DBMFetch(shQuery);
		if ((ret != DBM_SUCCESS)&&(ret != DBM_SUCCESS_WITH_INFO))
		{
			if(processError(ret, ch))
			break;
		}
		else
		{
			format_record( &brandblockedDB, &aBrandblocked );
			
			if(rm_insert_key_sn(appid, (const char *)&aBrandblocked, key_count, sizeof(aBrandblocked)) < 0)
				OTraceFatal("F-SHC-170.22: Unable to insert header\n");
		}
	}

	OTraceDebug("D-SHC-170.23: Total %d records inserted\n", key_count);

	keyp->textused = text_count;
	keyp->keysused = key_count;
		/* Now sort the bin entries for faster look up */

	if (rm_setstate( appid, RULES_VER_ATTACHED, RM_STATE_READY) < 0)
	{
		OTraceError("E-SHC-170.47:Can't set rule state to READY, Abort shc-brand-blocked init.\n");
		syslg("E-SHC-170.47:Can't set rule state to READY, Abort shc-brand-blocked init.\n");
		return -1;
	}

	if (rm_unsetloading(appid) < 0)
	{
		OTraceError("E-SHC-170.48:Can't unset rule state of LOADING, Abort shc-brand-blocked init.\n");
		syslg("E-SHC-170.48:Can't unset rule state of LOADING, Abort shc-brand-blocked init.\n");
		return -1;
	}
	// Check whether to set the version to Current
	if(! rm_optDontSetCurrAftLoad())
	{
		if (rm_setcurrent( appid, RULES_VER_ATTACHED)<0)
		{
			OTraceError("E-SHC-170.49:Can't set rule to CURRENT, Abort shc-brand-blocked init.\n");
			syslg("E-SHC-170.49:Can't set rule to CURRENT, Abort shc-brand-blocked init.\n");
			return -1;
		}
	}	


	return(0);
}


int load_servers()
{
	/*
	 *	Scan my config or maybe its hard coded
	 *	In either case I can load my applications
	 */
	return(0);
}


int initSys()
{
	char buf[80];
	if (dbm_init() == -1)
	{
		OTraceFatal("F-SHC-170.24: Unable to connect to DB Manager : Error: %d\n",
			  errno);
		pexit(1);
	}

	if (rm_init() < 0)
	{
		OTraceFatal("F-SHC-170.25: Unable to connect to RuleManager : Error: %d\n",
			  errno);
		pexit(1);
	}

	/* Get pin and key pointers */

	//if (shc_initsys() < 0)
	//{
	//	OTraceFatal("F-SHC-170.26: INITSYS Failed : Error: %d\n", errno);
	//	pexit(1);
	//}

	return(0);
}


/*
 *	alf: just a comment, this function is called when you issue a
 *
 *	"mbrulecmd update shared-cash-extbin" command.
 *
 *	For external bin, it doesn't make much sense to update it,
 *	unless you will never stop the share. Or I should update the
 *	shared memory in split second rather than attach to it and
 *	update record by record.
 *	
 *	Here is the update:  because you have credit and debit, so
 *	you can just do a update all, even you just partially update,
 *	the result will still be update all.
 */
int update_record()
{
	/* Now I can actualy initialise my table */

	int	key_count = 0, text_count = 0;
	int	i,n;
	struct rules_keytab *keyp;
	
	char *tmpMem = NULL;
	char *p      = NULL;
	
	/* for debug */
	static	int		recordnum = 0;

	int ind[16];	//	---	R020436 
	int buf[1024];
	int aRet = 0;
	
	BLOCK_BY_BRAND brandblockedDB;
	BLOCK_BY_BRAND aBrandblocked;
//	BLOCK_BY_BRAND	*pTmp = (BLOCK_BY_BRAND *)buf;

	initSys();
	if(rm_isMultiVerSupported(appid))
	{
		int version = 0;
		rm_init();
		// Create new shared memory version
		if(rm_createNewVersion(appid, &gBrRuleVer) < 0)
		{
			OTraceError("E-SHC-170.50: Unable to create new version\n");
			aRet = -1;
		}
		else
		{
			OTraceLog("L-SHC-170.51: New version created appid [%d] version [%d]\n",appid, version);
			aRet = rm_waitstate(appid, gBrRuleVer, RM_STATE_READY, -1);
		}
		return aRet;
	}
	DBMHSTMT shQuery;
	DBMHDBC ch;	
	DBMRETURN ret = 0;
	if (dbm_connect() >=0)
	{
		OTraceDebug("D-SHC-170.27:Connecting to database successful\n");
		ch=dbm_dbconn;
	}
	else
	{
		OTraceError("E-SHC-170.28: Connecting to database failed\n");
		return (-1);
	}

	if( DBMAllocStmt(ch, &shQuery) < 0)
	{
		OTraceError("E-SHC-170.29: Select query statement allocate error:\n%s\n", sqlStatementQuery);
	}
	
	if( (DBMBindCol(shQuery,1,DBM_STRINGTYPE,brandblockedDB.institutionid,sizeof(brandblockedDB.institutionid),&ind[0]) != DBM_SUCCESS) ||
			(DBMBindCol(shQuery,2,DBM_STRINGTYPE,brandblockedDB.cardproduct,sizeof(brandblockedDB.cardproduct),&ind[1]) != DBM_SUCCESS) ||
			(DBMBindCol(shQuery,3,DBM_STRINGTYPE,brandblockedDB.destination,sizeof(brandblockedDB.destination),&ind[2]) != DBM_SUCCESS)
		)
	{
		OTraceError("E-SHC-170.30: Select query bind error \n");
		return (-1);
	}
	else
	{
		if( DBMPrepare(shQuery, sqlStatementQuery) != DBM_SUCCESS )
		{
			OTraceError("E-SHC-170.31: Select query prepare error:\n%s \n", sqlStatementQuery);
		}
		
		ret = DBMExecute(shQuery);
		if(ret != DBM_SUCCESS)
		{
			if(processError(ret, ch))
			{
				DBMFreeStmt(shQuery, DBM_DROP);
				return (-1);
			}

		}
	}
				/*	Insert the key */
	keyp = rm_getapphead(appid);
	tmpMem = (char *)calloc(keyp->keysize, keyp->nkeys);
	if (!tmpMem )
	{
		OTraceError("E-SHC-170.32:can't allocate %d bytes\n", keyp->keysize*keyp->nkeys);
		DBMFreeStmt(shQuery, DBM_DROP);
		return -1;
	}
	
	for(key_count = 0;;key_count++)
	{
		recordnum ++;
		memset((char *)&brandblockedDB, 0, sizeof(brandblockedDB));
		memset((char *)&aBrandblocked, 0, sizeof(brandblockedDB));
		
		ret = DBMFetch(shQuery);
		if ((ret != DBM_SUCCESS)&&(ret != DBM_SUCCESS_WITH_INFO))
		{
			if(processError(ret, ch))
			break;
		}
		else
		{
			format_record( &brandblockedDB, &aBrandblocked );
			memcpy(&tmpMem[key_count*keyp->keysize], (char*)&aBrandblocked, keyp->keysize);
		}
	}
	qsort(tmpMem, key_count, keyp->keysize, keys_cmp);
	
			/* 	R023095 >> */
	if ( rm_lockAppid(appid) < 0 )
	{
		OTraceWarning("W-SHC-170.33: rm.appid[%d] locked by other, grab lock after 1 sec\n", appid);
		sleep(1);
		rm_unlockAppid(appid);
		rm_lockAppid(appid);
	}
	else
	{
		OTraceDebug("D-SHC-170.34: Locked appid[%d] successfully, memcpy by size[%ld]\n", 
				appid,  key_count*keyp->keysize); //---R028747
	}
	
	memcpy(rm_getappkey(appid), tmpMem, key_count*keyp->keysize);
		
	rm_unlockAppid(appid);
	OTraceDebug("D-SHC-170.35: Unlocked rm.appid[%d]\n", appid);
			/* 	R023095 << */

	keyp->keysused = key_count;
	
	return 0;
}

/* This function is for debug purpose */
int dump_records()
{
	int dbi, i, memoryi;
	struct rules_keytab *keyp;
	BLOCK_BY_BRAND	*pTmp;
	char *p = NULL;

	initSys();

	rm_attach( appid, RULES_VER_CURRENT );

	if((p = rm_getappkey(appid)) == NULL)
		log_msg(FATAL, TO_CC, "F-SHC-170.36: couldn't locate the shared memory for brandblocked!\n");

	keyp = rm_getapphead(appid);

	for(i = 0; i < keyp->keysused; i++, p+=keyp->keysize)
	{
		pTmp=(BLOCK_BY_BRAND *)p;
		OTraceDebug("D-SHC-170.37: [%s] : [%s] : [%s]\n", pTmp->institutionid,pTmp->cardproduct,pTmp->destination);
	}

	dbm_close_all(getpid());

	return( 0 );
}

int pexit(int n)
{
	HaPtmCctHelper::cleanUp() ;
	OTraceOff();
	return(n);
}

int processError(int ret, DBMHSTMT sh)
{
    int recnum=1;
    char sqlstate[6];
    int native_error;
    char msg_text[2048];
    switch(ret)
    {
    case DBM_SUCCESS_WITH_INFO:
        return false;
    case DBM_NO_DATA:
    	OTraceDebug ("D-SHC-170.38:End of data\n");
		return true;
    case DBM_ERROR:
        while(DBMGetDiagRec(DBM_HANDLE_STMT, sh, recnum++,
                sqlstate, &native_error, msg_text, sizeof(msg_text), NULL)
                == DBM_SUCCESS)
        {
            OTraceError("E-SHC-170.39:%s\n", msg_text);
        }
        if (recnum <= 2)
        {
            OTraceError("E-SHC-170.40:Unknown DB error:%d\n", ret);
        }
        return true;
    case DBM_INVALID_HANDLE:
        OTraceError("E-SHC-170.41:Invalid handle(internel error)\n");
        return true;
    default:
        OTraceError("E-SHC-170.42:Unknow db error:%d\n", ret);
        return true;
    }
}					


int format_record( BLOCK_BY_BRAND *db, BLOCK_BY_BRAND *pkg )
{
	if ( isEmptyField(db->institutionid) )
	{
		pkg->institutionid[0] = '\0';
	}	
	else
	{
		ICInstId_pure(pkg->institutionid, db->institutionid);
	}
	
	if (isEmptyField(db->destination))
	{
		pkg->destination[0] = '\0';
	}
	else
	{
		ICInstId_pure(db->destination, db->destination);
		if ( strlen(db->destination) > sizeof(db->destination)-3 )
		{
			strcpy( pkg->destination, db->destination );
		}
		else
		{
			if ( db->destination[0] != '^' )
				strcpy( pkg->destination, "^" );
				
			istsafe_strcat( pkg->destination, sizeof(pkg->destination), db->destination );
			
			if ( db->destination[strlen(db->destination)-1] != '$' )
				istsafe_strcat( pkg->destination, sizeof(pkg->destination), "$" );
		}
	}

	if (isEmptyField(db->cardproduct))
	{
		pkg->cardproduct[0] = '\0';
	}
	else
	{
		if ( strlen(db->cardproduct) > sizeof(db->cardproduct)-3 )
		{
			strcpy(pkg->cardproduct, db->cardproduct);
		}
		else
		{
			if ( db->cardproduct[0] != '^' )
				strcpy(pkg->cardproduct, "^");
				
			strcat(pkg->cardproduct, db->cardproduct);
			
			if ( db->cardproduct[strlen(db->cardproduct)-1] != '$' )
				strcat(pkg->cardproduct, "$");
		}
	}
	
	OTraceDebug("D-SHC-170.43: [%s][%s][%s][%s]\n", pkg->institutionid, pkg->cardproduct, pkg->destination, db->description);
	
	return 0;
}
