static char ver[100]="IST:External Bin Initializer r";
static char _shcinitebin_cxx_what[] = "@(#) shcinitebin.cxx 1.19.6.6 20/04/16 18:52:33";

/*
 *  Copyright (C) 2004 eFunds Corporation ("eFunds").  All Rights Reserved.     
 *  eFunds Canada Corporation is an authorized user.                            
 *                                                                              
 *  IST is a registered trademark of eFunds Corporation.  Other brand or        
 *  product names are trademarks or registered trademarks of their respective   
 *  holders.                                                                    
 *                                                                              
 *  The information contained herein is the unpublished proprietary property    
 *  of eFunds.  Except as specifically authorized in writing by eFunds, the     
 *  holder of this document shall: i) keep all information contained herein     
 *  confidential, and ii) protect the information, in whole or in part, from    
 *  disclosure and dissemination to all third parties.                          
 *                                                                          
 *  This document and the software described in it are furnished under license  
 *  and may be used or copied only in accordance with the terms of such license.
 *  This document is supplied for information purposes only, is subject to      
 *  change without notice, and should not be construed as a commitment by       
 *  either eFunds Corporation or eFunds Canada Corporation. 
 */
/*
 *
 *                        MODIFICATION HISTORY                  REVIEW
 *
 *	SPR#	Who	Date	Description			Who	Date   
 * ===========================================================================
 *	Alf			10Jan95		modified to use new shcextbindb table and fixed 
 *							some bugs.
 * 10001935 la  09may96 Was opening incorrect index name.
 * R002639	zt  01Sep99 Loaded network_data into shared memory for external bin
 * R004214  fg  22Mar00 replace DBM_RSEQ with DBM_RFIRST, DBM_RNEXT 
 * R007062	gbeeng	26Nov2001	C++ Migration
 *R007235 ztang 03Jan01	Update 	keyp->keysused for update command
 *R008717 ztang 09Dec02	Multi-institution support. Using new structure.
 *R009074 ztang 04Feb03 changed keys_cmp to use memcpy
 *R009352 ztang 05Mar03 Increase the textused by 1
 *R012134 Emj   01Oct04 Issuer Entity Support  
 *R020436 leesy 26Jun07 Bin Load Performance Improvement 
 *R022481 jyang 29Jan08 Supported for locking shared memory of rules
 *R027722 Dipa  08Jan10 Re-grouping done in local memory for shcextbin
 *R028747 Dipa  17Nov10 Remove reference to rules_keytab[]
 *R029874 las   18May11 add country code to shcextbindb table
 *R032576 Dipa  06Feb14 Spring Compliance 2014 - VISA - New column. SHCEXTBINDB.network_config
 */

//File Number 138

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <errno.h>
#include <shc.h>
#include <mb.h>
#include <rules.h>
#include<ic/ic_instid.h>
#include <DBM3.h>
#include <dbm.h>
#include <dbm_private.h>
#include <ist_otrace.h>
#include <shcdef.h>	

#include <HaPtmCctHelper.h>

/*
 *	Example application initialiser
 */

#define DEFAULT_NETMGR	"shcNetworkManager"
#define PKG_NEEDS_OWNER		(-2)
#define PKG_NEEDS_TEXT		(-1)

/* Following two parameters determines the minimum number of entries allocated in shared memory */
#define MINIMUM_MEMORY_INCREMENT 2000

/* Minimum percentage of extra memory needed */
#define EXTRA_MEMORY				20

#define EXTBIN_MAXIMUM_GROUP_NUM	2000

#define EXTBINCHAR2BCD(c, d) ((c >= '0' && c <= '9')?c - '0':d)


/*
 *	An application initialiser is invoked with the following paramaters
 *
 *		<taskname>	<mode>	<rulename>	<appid> <srvname> [<data>]
 *
 *	<taskname>		the executable name of this task		(argv[0])
 *	<mode>			the mode of processing
 *						'count'			count space needed and report to strm
 *						'init'			init the rules in-core database
 *						'update'		update an existing rule
 *						'load'			load you application
 *
 *	<rulename>		the name of the rule to be initialised
 *	<appid>			the system assigned application id for this rule
 *
 *	<srvname>		the server to which count information should be sent
 *
 *	<data>			data which might be included in an 'update' command
 *
 *
 *****************************************************************************
 *
 *	This is SHARED Cash ExtBin initialiser
 *	This task accepts initialisation requests for message
 *
 *			shared-cash-extbin
 */
/* R007062 */
extern "C"
{
	int keys_cmp(const void *anykey1, const void *anykey2);
}
int update_record(char *input_instid);
int count_records();
int init_records();
int dump_records();
int load_servers();
int pexit(int n);
int initSys();
int processError(int ret, DBMHSTMT sh);	//	---	R020436

int			con_id = (-1);
struct		rules_keytab keytab = {
	0};
int			my_count = 0;
struct shcextbin	shcExtBinMemory = {
	0};
struct shcextbindb	shcExtBinDB = {
	0};
int			update_all	= 0;

int	fd;
int			mode = 0;

int			appid = -1;
int			size;
const char		*bp = "select count(lowbin) from shcextbindb";

int shcinitebinNewGrouping = 0; //Whether use new grouping method or not

#define		EXTBIN_REC	1

int			msgtype		= 0;
int			argc 		= 0;
char		**argv 		= NULL;

static int shcinitebinPanMerge = 0;
int removedRecordNumber = 0 ;

// Define global variable for shared memory version report
int			gExtRuleVer = -1;


static int shc_init_load()
{
	int     ret = 0;

	if (appid == -1)
	{
		rm_init();

		if((appid = rm_getappid(SHC_EXTBIN_MESSAGE_NAME)) == -1)
		{
			OTraceFatal("F-SHC-138044:unable to locate message name shared-cash-extbin\n");
			return -1;
		}
	}

	if(rm_attach( appid, RULES_VER_LOADING )!= 0)
		return -1;
	
	// get the version number: gExtRuleVer
	rm_attachedversion(appid, &gExtRuleVer);

	return (ret);
}


int main(int a_rgc, char **a_rgv)
{
	argv  = a_rgv;
	argc  = a_rgc;
	argv0 = *argv;

	catch_all_signals(NULL);

	strcat(ver, VERSION);
	syslg("%s\n", ver);
	OTraceOn(argv0);

	// Define return value for return value report
	int aRet = 0;

	// call function to mangle the argv
	rm_extOptFrArg(argc, argv);

	HaPtmCctHelper::deinit() ;

	if(argc < 5)
	{
		OTraceFatal("F-SHC-138001: %d is an invalid number of parameters.\n", argc);
		pexit(-1);
	}

	mb_init();

	OTraceInfo("I-SHC-138002: %s mode for rule %s\n", 
	    argv[RULES_PARM_MODE], argv[RULES_PARM_RULENAME]);

	con_id = mb_locatemailbox(argv[RULES_PARM_SRVNAME]);
	if (con_id == -1)
	{
		OTraceFatal("F-SHC-138003: Unable to connect to %s: Error: %d\n",
		    argv[RULES_PARM_SRVNAME], errno);
		pexit(-1);
	}

	/* Extract all paramaters */

//	if (rm_init() < 0)
//	{
//		OTraceDebug("F-SHC-139034: Unable to connect to RuleManager : Error: %d\n",
//					errno);
//		pexit(-1);
//	}
//	appid = rm_getappid(argv[RULES_PARM_RULENAME]);
	appid = atoi(argv[RULES_PARM_APPID]);

	if(stricmp("shared-cash-extbin", argv[RULES_PARM_RULENAME]) == 0)
		msgtype = EXTBIN_REC;		/* Sunny 13Jan92 */
	else
	{
		OTraceFatal("F-SHC-138004: Invalid message type: %s\n",
			argv[RULES_PARM_RULENAME]);
		pexit(-1);
	}

	/* Now determine which we need and perform action */

	if(stricmp(argv[RULES_PARM_MODE], "count") == 0)
		aRet = count_records();
	else if(stricmp(argv[RULES_PARM_MODE], "init") == 0)
		aRet = init_records();
	else if(stricmp(argv[RULES_PARM_MODE], "load") == 0)
		aRet = load_servers();
	else if(stricmp(argv[RULES_PARM_MODE], "update") == 0)
	{
		//Always update all records
		//update_all = (!stricmp("all", argv[RULES_PARM_DATA]) ? 1 : 0);
		aRet = update_record(NULL);
	}
	else if(stricmp(argv[RULES_PARM_MODE], "dump") == 0)
		aRet = dump_records();
	else
	{
		OTraceFatal("F-SHC-138005: Don't know how to interpret mode '%s'\n", 
		    argv[RULES_PARM_MODE]);
			aRet = -1;
	}

	// Output status info based on return value and version number
	rm_outInfo(gExtRuleVer, aRet);

	return pexit(aRet);

}

static void initebin_removeTrailingSpace(char *s)
{
	int i;
	
	for (i=strlen(s)-1;i>=0 && s[i] && s[i] == ' '; i--);
	
	s[i+1] = '\0';
	return;
}

int shcinitebinGetMinimumSpace()
{
	int ret;
	int numOfEntries = 0;
	DBMHSTMT tmpStmt;
	
    if (dbm_connect() >=0)
    {
        OTraceDebug("D-SHC-138006:Connecting to database successful");
    }
    else
    {
        OTraceFatal("F-SHC-138007:Connecting to database failed");
        return -1;
    }
    dbm_dbconn;
    ret=DBMAllocStmt(dbm_dbconn, &tmpStmt);
    if (ret < 0)
    {
        OTraceFatal("F-SHC-138008:Can't allocate statment:%s", bp);
        return -1;
    }
    ret=DBMPrepare(tmpStmt, (char *)bp);
    if (ret < 0)
    {
        OTraceFatal("F-SHC-138009:Can't prepare statment:%s", bp);
        return -1;
    }
    ret=DBMExecute(tmpStmt);
    if (ret < 0)
    {
        OTraceFatal("F-SHC-138010:Can't execute statment:%s", bp);
        return -1;
    }
    
    int status;
    ret=DBMBindCol(tmpStmt, 1, DBM_LONGTYPE, &numOfEntries, sizeof(numOfEntries), &status);
    if (ret < 0)
    {
        OTraceFatal("F-SHC-138011:Can't bind for statment:%s", bp);
        return -1;
    }

    ret=DBMFetch(tmpStmt);
    if (ret == DBM_NO_DATA)
    	numOfEntries = 0;
	else if (ret < 0)
    {
        OTraceFatal("F-SHC-138012:Can't fetch for statment:%s", bp);
        return -1;
    }
    DBMFreeStmt(tmpStmt, DBM_CLOSE);
    
    /* Now calculate how many entries we should allocate
     * The number of entries increase by 100.
     * And we need to keep at least 20% free space
     */
    numOfEntries = (numOfEntries+1) * (100 + EXTRA_MEMORY)/100;
    numOfEntries = (numOfEntries + MINIMUM_MEMORY_INCREMENT - 1)/MINIMUM_MEMORY_INCREMENT * MINIMUM_MEMORY_INCREMENT;
    
    return numOfEntries;
}

void fill_group(struct shcextbinGroupHeader *group, struct shcextbin *extbinEntry, int posOfEntry)
{
	memset(group, 0, sizeof(struct shcextbinGroupHeader));
	strcpy(group->destination, extbinEntry->destination);
	strcpy(group->entityId, extbinEntry->entityId);
	strcpy(group->cardProduct, extbinEntry->cardProduct);
	group->bin_length = extbinEntry->bin_length;
	group->startEntry=posOfEntry;
	group->endEntry=-1;
}

//R027722
void create_groups(struct shcextbin *pTmpShcExtBin, struct shcextbinGroupHeader *pgroupLocal, int keysused, int *textused)
{
	int i,currentGroup;

	if (keysused <= 0)
		return;

	currentGroup=0;
	fill_group(pgroupLocal, pTmpShcExtBin, 0);
	for(i=1; i<keysused; i++)
	{
		if (strcmp(pgroupLocal[currentGroup].destination, pTmpShcExtBin[i].destination) == 0 &&
		strcmp(pgroupLocal[currentGroup].entityId, pTmpShcExtBin[i].entityId) == 0 &&
		strcmp(pgroupLocal[currentGroup].cardProduct, pTmpShcExtBin[i].cardProduct) == 0)
			continue;
		pgroupLocal[currentGroup].endEntry = i-1;
		currentGroup++;
		fill_group(&pgroupLocal[currentGroup], &pTmpShcExtBin[i], i);
	}
	if (pgroupLocal[currentGroup].endEntry < 0)
		pgroupLocal[currentGroup].endEntry = i-1;
	
	*textused = currentGroup + 1;
}

	
int count_records()
{
	/*
	 *	He wants me to inidcate how many keys and text buffers
	 *	as well as their respective sizes
	 *
	 *	I can do this by reading the database or by looking in a
	 *	config file
	 */

	int mbw;

	/* Set up my return packet */
//	keytab.appid = rm_getappid(argv[RULES_PARM_RULENAME]);
	keytab.appid = atoi(argv[RULES_PARM_APPID]);

	if(msgtype == EXTBIN_REC)
	{
		size	= sizeof(struct shcextbin);
	}

	if ((my_count = shcinitebinGetMinimumSpace()) < 0)
		log_msg(FATAL, TO_CC, "F-SHC-138013:Can't estimate shared memory needed.\n");

	/* Now i tell him how large my buffers should be */

	keytab.keysize = sizeof(struct shcextbin);
	keytab.nkeys	= my_count;
	keytab.textsize	= sizeof(struct shcextbinGroupHeader);
	keytab.ntext	= EXTBIN_MAXIMUM_GROUP_NUM;

	snprintf(keytab.name, sizeof(keytab.name),"%s",argv[RULES_PARM_RULENAME]);

	/* Now I send him the information */

	if ((mbw = mb_write(con_id, 0, &keytab, sizeof(keytab))) < 0)
		OTraceFatal("F-SHC-138014: Unable to write to server id %d\n", con_id);
	
	cf_close();
	return(0);
}

void getPrintableRange(struct shcextbindb *dbRecord, struct shcextbin *memoryRecord)
{
	int dbi, memoryi;
	for ( dbi = memoryi = 0; dbi <sizeof(shcExtBinDB.lowbin) -1; dbi += 2, memoryi++)
	{
		dbRecord->lowbin[dbi] = ((unsigned char)memoryRecord->lowbin[memoryi]>>4)+'0';
		dbRecord->lowbin[dbi+1] = (memoryRecord->lowbin[memoryi]&0xf) + '0';
		dbRecord->highbin[dbi] = ((unsigned char)memoryRecord->highbin[memoryi]>>4)+'0';
		dbRecord->highbin[dbi+1] = (memoryRecord->highbin[memoryi]&0xf) + '0';
	}
	
	dbRecord->lowbin[sizeof(shcExtBinDB.lowbin)-1] = '\0';
	dbRecord->highbin[sizeof(shcExtBinDB.highbin)-1] = '\0';
}


int keys_cmp(const void *anykey1, const void *anykey2)
{
	int i, ih;
	
	struct shcextbin *k1 = (struct shcextbin *) anykey1;
	struct shcextbin *k2 = (struct shcextbin *) anykey2;

	if ( shcinitebinPanMerge )
	{
		if ( k1->destination[0] == '~' )
			return 1;
		else if ( k2->destination[0] == '~' )
			return -1;
	}

	i = strcmp(k1->destination, k2->destination);
	if(i != 0)
		return(i);

	i = strcmp(k1->entityId, k2->entityId);
	if(i != 0)
		return(i);

	i = strcmp(k1->cardProduct, k2->cardProduct);
	if(i != 0)
		return(i);

	// bin length in network data
	if ( shcinitebinPanMerge )
	{
		if( ! memcmp( &k1->network_data[0], "99" , 2 ) && !memcmp( &k2->network_data[0], "99" , 2 ) ) 
		{
			i = memcmp(&(k1->network_data[4]), &(k2->network_data[4]), 2);
			if ( i != 0 )
				return(i);
		}
	}
	
	i  = memcmp(k1->lowbin, k2->lowbin, sizeof(k1->lowbin));
	ih = memcmp(k1->highbin, k2->highbin, sizeof(k1->lowbin));

	if ( ! shcinitebinPanMerge )
	{
		if ( i != 0 )
			return ( i );
		else if ( ih != 0 )
			return ( ih );
		else
			return i;
	}

	// If file is valid, this should not happen
	// Let's check it anyway
	if ( i == 0 && ih == 0 )
	{
		OTraceWarning("W-SHC-0890-2: Duplicate range detected!!!!\n");
		// Remove one of the duplicates--arbitrary choice, remove k1
		struct shcextbindb shcExtBinDB2 = { 0 };
		
		getPrintableRange(&shcExtBinDB, k1);
		getPrintableRange(&shcExtBinDB2, k2);
		
		OTraceWarning("W-SHC-0891-a:The range[%s:%s:%s:%s:%c%c] was deleted because \n"
					"it's duplicate of range [%s:%s:%s:%s:%c%c]\n", 
					shcExtBinDB.lowbin, shcExtBinDB.highbin, k1->destination, k1->cardProduct,
					k1->network_data[4], k1->network_data[5],
					shcExtBinDB2.lowbin, shcExtBinDB2.highbin, k2->destination, k2->cardProduct,
					k2->network_data[4], k2->network_data[5]
					);
		
		strcpy( k1->destination, "~~~~~~~~~~" );
		removedRecordNumber++;
		return 1;
	}
	else
	if (   ((i >  0) && (ih <  0))		// k1 totally within k2
		|| ((i == 0) && (ih <  0))		// k1 has same start value and less than end value
		|| ((i >  0) && (ih == 0))		// k1 has higher start and equal end value
	   )
	{
		//Remove k1 because k2 includes k1
		struct shcextbindb shcExtBinDB2 = { 0 };
		
		getPrintableRange(&shcExtBinDB, k1);
		getPrintableRange(&shcExtBinDB2, k2);
		
		OTraceWarning("W-SHC-0891-a:The range[%s:%s:%s:%s:%c%c] was deleted because \n"
					"it's included in range [%s:%s:%s:%s:%c%c]\n", 
					shcExtBinDB.lowbin, shcExtBinDB.highbin, k1->destination, k1->cardProduct,
					k1->network_data[4], k1->network_data[5],
					shcExtBinDB2.lowbin, shcExtBinDB2.highbin, k2->destination, k2->cardProduct,
					k2->network_data[4], k2->network_data[5]
					);
		
		strcpy( k1->destination, "~~~~~~~~~~" );
		removedRecordNumber++;
		return 1;
	}
	else if (   (i <  0) && (ih >  0)		// k2 totally within k1
			 || (i == 0) && (ih >  0)		// k2 has same start value and less than end value
			 || (i <  0) && (ih == 0)		// k2 has higher start value and equal end value
			)
	{
		//Remove k2 because k1 includes k2
		struct shcextbindb shcExtBinDB2 = { 0 };
		
		getPrintableRange(&shcExtBinDB, k1);
		getPrintableRange(&shcExtBinDB2, k2);

		OTraceWarning("W-SHC-0891-b:The range[%s:%s:%s:%s:%c%c] was deleted because \n"
					"it's included in range [%s:%s:%s:%s:%c%c]\n", 
					shcExtBinDB2.lowbin, shcExtBinDB2.highbin, k2->destination, k2->cardProduct,
					k2->network_data[4], k2->network_data[5],
					shcExtBinDB.lowbin, shcExtBinDB.highbin, k1->destination, k1->cardProduct,
					k1->network_data[4], k1->network_data[5]
					);
		
		strcpy( k2->destination, "~~~~~~~~~~" );
		removedRecordNumber++;
		return -1;	
	}
	// with the changes above -- taking into consideration equal starts or equal ends
	// the following logic should not be entered into -- keeping it anyway
	else if ( i == 0 ) 	// both low are equal
		return ih ;
	else
		return i;
}

//Compare function
static int currentGroup = 0; //Current group number in sorting, it starts with 0, then 1, 2, 3...
static int foundBiggerRange = 0;
int new_keys_cmp(const void *anykey1, const void *anykey2)
{
	int i,j;
	struct shcextbin *k1 = (struct shcextbin *) anykey1;
	struct shcextbin *k2 = (struct shcextbin *) anykey2;


	i = memcmp(k1->lowbin, k2->lowbin, sizeof(k1->lowbin));
	j = memcmp(k1->highbin, k2->highbin, sizeof(k1->lowbin));
	
	if (i>0)
	{
		if (j < 0)
		{
			//key2 completely include key1
			//remember it in the flag
			k2->entityId[30] = currentGroup+1;
			foundBiggerRange = 1;
			return i;	//Doesn't matter how we return
		}
		return i;//k1 > k2
	}
	else if (i<0)
	{
		if (j>0)
		{
			//key1 completely include key2
			//remember it in the flag
			k1->entityId[30] = currentGroup+1;
			foundBiggerRange = 1;
			return i;	//Doesn't matter how we return
		}
		return i; //k1 <k2
	}
	else
	{
		//lowbin is same
		//it's up the highbin
		return j;
	}
			
}

int optimize(struct shcextbin *ranges, int numOfRange, struct shcextbinGroupHeader *pgroupLocal, int *numOfGroup)
{
	int done = 0;
	struct shcextbin *originalRanges = ranges;
	int originalNumOfRanges = numOfRange;
	int currentGroupStartIndex = 0;
	
	struct shcextbin tmpRange;
	int i,j;
	
	while(!done)
	{
		foundBiggerRange = 0;
		qsort(ranges, numOfRange, sizeof(struct shcextbin), new_keys_cmp);
		if (foundBiggerRange)
		{
			//Needs to move the bigger ranges to the end of the range list.
			for (i=0,j=numOfRange-1;i<=j;)
			{
				if (ranges[j].entityId[30] > currentGroup)
				{
					j--;
					numOfRange--; //Move range j to next group
					continue;
				}
				if (ranges[i].entityId[30]<= currentGroup)
				{
					i++;
					continue;
				}
				//Now i points to a range that include other range
				//j points to a range that does NOT include other range
				//Need to switch places
				memcpy(&tmpRange, &ranges[j], sizeof(tmpRange));
				memcpy(&ranges[j], &ranges[i], sizeof(tmpRange));
				memcpy(&ranges[i], &tmpRange, sizeof(tmpRange));				
				
				j--;
				i++;
				numOfRange--;
			}

		}
		else 
		{
			//Sorting for the current group is done
			//Needs to write group information
			pgroupLocal[currentGroup].startEntry = currentGroupStartIndex;
			pgroupLocal[currentGroup].endEntry = currentGroupStartIndex + numOfRange - 1;
			
			if (pgroupLocal[currentGroup].endEntry >= originalNumOfRanges-1)
			{
				//All pan ranges grouped, we are done
				*numOfGroup = currentGroup+1;
				
				//entityId[30] has been used to hold group number during sorting
				//Now it's not needed, clear it
				for (i = 0;i < originalNumOfRanges; i++)
				{
					originalRanges[i].entityId[30] = '\0';
				}
				return 0;
			}
			else
			{
				//There are pan ranges in the next group, each pan ranges in next group
				//INCLUDE at least one pan ranges in the current group. 
				//Needs to sort next group as well
				currentGroup++;
				
				//Move it to the beginning of next group
				currentGroupStartIndex += 	numOfRange; 
				ranges = &originalRanges[currentGroupStartIndex];
				
				//Calculat number of ranges remaining for next group
				numOfRange = originalNumOfRanges - currentGroupStartIndex;
				
			}
		}	
		
	}
	return 0;
}

int init_records()
{
	/* Now I can actualy initialise my table */

	int	key_count = 0, text_count = 0;
	int	i;
	struct rules_keytab *keyp;
	struct shcextbin	*pTmpShcExtBinMemory;
	struct shcextbinGroupHeader *pgroupMem; //R027722


	/* for debug */
	static	int		recordnum = 0;

	int ind[17];	//	---	R020436
	if (msgtype != EXTBIN_REC)
		return(0);
     
	initSys();
	if (shc_init_load() == -1)
		return(-1);


	//	>>>	R020436

	DBMHSTMT shQuery;
	DBMHDBC ch;	
	DBMRETURN ret = 0;
	if (dbm_connect() >=0)
	{
		OTraceDebug("D-SHC-138027:Connecting to database successful\n");
		ch=dbm_dbconn;
    }
	else
	{
		OTraceError("E-SHC-138028: Connecting to database failed\n");
		return (-1);
  	}

  	char sqlStatementQuery[512]="select lowbin, highbin, o_level, status, description, destination, entity_id, cardproduct, network_data, file_name, file_version, file_date, country_code, network_config, bin_length from shcextbindb where status = 'A'"; // ---     R029874
  	if( DBMAllocStmt(ch, &shQuery) < 0)
	{
		OTraceError("E-SHC-138029: Select query statement allocate error:\n%s\n", sqlStatementQuery);
	}
	if( (DBMBindCol(shQuery,1,DBM_CHARTYPE,&shcExtBinDB.lowbin,sizeof(shcExtBinDB.lowbin),&ind[0]) != DBM_SUCCESS) ||
	    (DBMBindCol(shQuery,2,DBM_CHARTYPE,&shcExtBinDB.highbin,sizeof(shcExtBinDB.highbin),&ind[1]) != DBM_SUCCESS) ||
	    (DBMBindCol(shQuery,3,DBM_LONGTYPE,&shcExtBinDB.o_level,sizeof(shcExtBinDB.o_level),&ind[2]) != DBM_SUCCESS) ||
	    (DBMBindCol(shQuery,4,DBM_CHARTYPE,&shcExtBinDB.status,sizeof(shcExtBinDB.status),&ind[3]) != DBM_SUCCESS) ||
	    (DBMBindCol(shQuery,5,DBM_CHARTYPE,&shcExtBinDB.description,sizeof(shcExtBinDB.description),&ind[4]) != DBM_SUCCESS) ||
	    (DBMBindCol(shQuery,6,DBM_CHARTYPE,&shcExtBinDB.destination,sizeof(shcExtBinDB.destination),&ind[5]) != DBM_SUCCESS) ||	
        (DBMBindCol(shQuery,7,DBM_CHARTYPE,&shcExtBinDB.entity_id,sizeof(shcExtBinDB.entity_id),&ind[6]) != DBM_SUCCESS) ||  
	    (DBMBindCol(shQuery,8,DBM_CHARTYPE,&shcExtBinDB.cardproduct,sizeof(shcExtBinDB.cardproduct),&ind[7]) != DBM_SUCCESS) ||
		(DBMBindCol(shQuery,9,DBM_CHARTYPE,&shcExtBinDB.network_data,sizeof(shcExtBinDB.network_data),&ind[8]) != DBM_SUCCESS) ||
		(DBMBindCol(shQuery,10,DBM_CHARTYPE,&shcExtBinDB.file_name,sizeof(shcExtBinDB.file_name),&ind[9]) != DBM_SUCCESS) ||
		(DBMBindCol(shQuery,11,DBM_CHARTYPE,&shcExtBinDB.file_version,sizeof(shcExtBinDB.file_version),&ind[10]) != DBM_SUCCESS) ||
		(DBMBindCol(shQuery,12,DBM_DATETYPE,&shcExtBinDB.file_date,sizeof(shcExtBinDB.file_date),&ind[11]) != DBM_SUCCESS) ||
		(DBMBindCol(shQuery,13,DBM_INTTYPE,&shcExtBinDB.country_code,sizeof(shcExtBinDB.country_code),&ind[12]) != DBM_SUCCESS) ||
		(DBMBindCol(shQuery,14,DBM_CHARTYPE,&shcExtBinDB.network_config,sizeof(shcExtBinDB.network_config),&ind[13]) != DBM_SUCCESS) ||
		(DBMBindCol(shQuery,15,DBM_INTTYPE,&shcExtBinDB.bin_length,sizeof(shcExtBinDB.bin_length),&ind[14]) != DBM_SUCCESS) )
	{
		OTraceError("E-SHC-138030: Select query bind error \n");
		return (-1);
	}
	else
	{
		if( DBMPrepare(shQuery, sqlStatementQuery) != DBM_SUCCESS )
		{
			OTraceError("E-SHC-138031: Select query prepare error:\n%s \n", sqlStatementQuery);
		}
		
		int num_prefetch = 1000;
		int rc = DBMSetStmtAttribute(shQuery, DBM_ATTR_PREFETCH_COUNT, &num_prefetch, sizeof(num_prefetch));
		if (rc != DBM_SUCCESS)
		{
			processError(rc, shQuery);
			OTraceWarning("W-SHC-138032: Failed to set prefetch count\n");
		}

		
		ret = DBMExecute(shQuery);
		if(ret != DBM_SUCCESS)
		{
			if(processError(ret, ch))
			{
				DBMFreeStmt(shQuery, DBM_DROP);
				return (-1);
			}

		}
		for(;;)
		{
		    recordnum ++;
			memset((char *)&shcExtBinDB, 0, sizeof(struct shcextbindb));
			ret = DBMFetch(shQuery);
			if (ret != DBM_SUCCESS)
			{
				if(processError(ret, ch))
				break;
			}
			else
		    {
				int dbi,memoryi;
				memset((char *)&shcExtBinMemory, 0, sizeof(struct shcextbin));
				memset(shcExtBinMemory.highbin, (unsigned char)0xff, sizeof(shcExtBinMemory.highbin));
			
				for ( dbi = memoryi = 0; dbi <sizeof(shcExtBinDB.lowbin) -1; dbi += 2, memoryi++)
				{
					shcExtBinMemory.lowbin[memoryi] = (EXTBINCHAR2BCD(shcExtBinDB.lowbin[dbi], 0) << 4) |
									 (EXTBINCHAR2BCD(shcExtBinDB.lowbin[dbi+1], 0));
					shcExtBinMemory.highbin[memoryi] = (EXTBINCHAR2BCD(shcExtBinDB.highbin[dbi], 0xf) << 4) |
									 (EXTBINCHAR2BCD(shcExtBinDB.highbin[dbi+1], 0xf));
				}

				memcpy(shcExtBinMemory.cardProduct, shcExtBinDB.cardproduct, sizeof (shcExtBinDB.cardproduct));
				initebin_removeTrailingSpace(shcExtBinMemory.cardProduct);
				ICInstId_pure(shcExtBinMemory.destination, shcExtBinDB.destination);
														/* R002639 BEGIN */
				memcpy(shcExtBinMemory.network_data, shcExtBinDB.network_data,
					sizeof(shcExtBinMemory.network_data)-1);
				shcExtBinMemory.network_data[sizeof(shcExtBinMemory.network_data)-1]='\0';
														/* R002639 END */
				shcExtBinMemory.country_code = shcExtBinDB.country_code;//      ---     R029874

				memcpy(shcExtBinMemory.network_config, shcExtBinDB.network_config,
					sizeof(shcExtBinMemory.network_config)-1);
				shcExtBinMemory.network_config[sizeof(shcExtBinMemory.network_config)-1]='\0';

				 memcpy(shcExtBinMemory.file_version, shcExtBinDB.file_version, sizeof(shcExtBinMemory.file_version)-1);
				 shcExtBinMemory.file_version[sizeof(shcExtBinMemory.file_version)-1]='\0';


 				memcpy(shcExtBinMemory.entityId, shcExtBinDB.entity_id, sizeof (shcExtBinDB.entity_id));
				initebin_removeTrailingSpace(shcExtBinMemory.entityId);
        		if (    (shcExtBinMemory.entityId[0] == '*' )&&
                		(shcExtBinMemory.entityId[1] == '\0')
            		)
        		{
            		shcExtBinMemory.entityId[0] = '\0';
        		}

				shcExtBinMemory.bin_length = shcExtBinDB.bin_length;


				/*	Insert the key */

				if(rm_insert_key(appid, (char *)&shcExtBinMemory, key_count) < 0)
					OTraceFatal("F-SHC-138016: Unable to insert header\n");

				++key_count;
			}
		}

		keyp = rm_getapphead(appid);
		keyp->textused = text_count;
		keyp->keysused = key_count;

		/* Now sort the bin entries for faster look up */

		pTmpShcExtBinMemory = (struct shcextbin *)rm_getappkey(appid);
		pgroupMem=(struct shcextbinGroupHeader *)rm_getapptext(appid); //R027722

		while(1)
		{
			removedRecordNumber = 0 ;
			qsort(pTmpShcExtBinMemory, keyp->keysused, sizeof(struct shcextbin), keys_cmp);
			if (removedRecordNumber == 0)
				break ;
		}

		struct shcextbin *tmpm2 = &pTmpShcExtBinMemory[key_count-1];
		for (i=0; strcmp(tmpm2->destination, "~~~~~~~~~~")==0; tmpm2--, i++);
		keyp->keysused -= i;

		keyp->flags |= RULES_KEY_SORTED;
	
		if (!shcinitebinNewGrouping)
			create_groups(pTmpShcExtBinMemory,pgroupMem,key_count,&keyp->textused); //R027722
		else
		{
			optimize(pTmpShcExtBinMemory, key_count, pgroupMem, &keyp->textused);
		}

	}
	DBMFreeStmt(shQuery, DBM_DROP);	
	//	<<<	R020436 	

	if (rm_setstate( appid, RULES_VER_ATTACHED, RM_STATE_READY) < 0)
	{
		OTraceError("E-SHC-138046:Can't set rule state to READY, Abort shared-cash-extbin init.\n");
		syslg("E-SHC-138046:Can't set rule state to READY, Abort shared-cash-extbin init.\n");
		return -1;
	}
	if (rm_unsetloading(appid) < 0)
	{
		OTraceError("E-SHC-138047:Can't unset rule state of LOADING, Abort shared-cash-extbin init.\n");
		syslg("E-SHC-138047:Can't unset rule state of LOADING, Abort shared-cash-extbin init.\n");
		return -1;
	}
	// Check whether to set the version to Current
	if(! rm_optDontSetCurrAftLoad())
	{
		if (rm_setcurrent( appid, RULES_VER_ATTACHED)<0)
		{
			OTraceError("E-SHC-138048:Can't set rule to CURRENT, Abort shared-cash-extbin init.\n");
			syslg("E-SHC-138048:Can't set rule to CURRENT, Abort shared-cash-extbin init.\n");
			return -1;
		}
	}


	return(0);
}


int load_servers()
{
	/*
	 *	Scan my config or maybe its hard coded
	 *	In either case I can load my applications
	 */
	return(0);
}


int initSys()
{
	char buf[80];
	if (dbm_init() == -1)
	{
		OTraceFatal("F-SHC-138017: Unable to connect to DB Manager : Error: %d\n",
		    errno);
		pexit(1);
	}

	if (rm_init() < 0)
	{
		OTraceFatal("F-SHC-138018: Unable to connect to RuleManager : Error: %d\n",
		    errno);
		pexit(1);
	}

	/* Get pin and key pointers */

//	if (shc_initsys() < 0)
//	{
//		OTraceFatal("F-SHC-138019: INITSYS Failed : Error: %d\n", errno);
//		pexit(1);
//	}

	
	
	if(cf_open("files/shc.cfg") < 0)
		log_msg(FATAL, TO_CC, "F-SHC-138021:Unable to open config: \n");

	// do this once
	if(cf_locate("shcinitebin.pan_range_merging", buf) > 0)
	{
		if (buf[0] == 'Y' || buf[0] == 'y' || buf[0] == '1')
			shcinitebinPanMerge = 1;
	}
	if(cf_locate("shcinitebin.newGrouping", buf) > 0)
	{
		if (buf[0] == 'Y' || buf[0] == 'y' || buf[0] == '1')
			shcinitebinNewGrouping = 1;
		else
			shcinitebinNewGrouping = 0;
	}

	return(0);
}


/*
 *	alf: just a comment, this function is called when you issue a
 *
 *	"mbrulecmd update shared-cash-extbin" command.
 *
 *	For external bin, it doesn't make much sense to update it,
 *	unless you will never stop the share. Or I should update the
 *	shared memory in split second rather than attach to it and
 *	update record by record.
 *	
 *	Here is the update:  because you have credit and debit, so
 *	you can just do a update all, even you just partially update,
 *	the result will still be update all.
 */
int update_record(char *input_instid)
{
	/* Now I can actualy initialise my table */
	/* don't care if update_all or not */

	int	i,textused=0; //R027722
	struct rules_keytab *keyp;
	struct	shcextbin	*shcExtBinLocal = NULL;
	struct shcextbin	*pTmpShcExtBinMemory; 
	struct shcextbinGroupHeader *pgroupMem, *pgroupLocal; //R027722

	int ind[17];	//	---	R020436
	int aRet = 0;

	if (msgtype != EXTBIN_REC)
		return(-1);
	initSys();

	if(rm_isMultiVerSupported(appid))
	{
		int version = 0;
		rm_init();
		// Create new shared memory version
		if(rm_createNewVersion(appid,&gExtRuleVer) < 0)
		{
			OTraceError("E-SHC-138049: Unable to create new version\n");
			aRet = -1;
		}
		else
		{
			OTraceLog("L-SHC-138050: New version created appid [%d] version [%d]\n",appid, version);
			aRet = rm_waitstate(appid, gExtRuleVer, RM_STATE_READY, -1);
		}
		return aRet;
	}

	/*
	 *	we couldn't initialize when the system is up, the chance
	 *	we get it this time would be zero!
	 */

	if((pTmpShcExtBinMemory = (struct shcextbin *)rm_getappkey(appid)) == NULL)
		log_msg(FATAL, TO_CC, "F-SHC-138022:couldn't locate the shared memory for shcextbin!\n");

	// R027722 >>>
	if ((pgroupMem=(struct shcextbinGroupHeader *)rm_getapptext(appid)) == NULL)
		log_msg(FATAL, TO_CC, "F-SHC-138022.1:couldn't locate the shared memory for shcextbinGroupHeader!\n");
	// <<< R027722

	keyp = rm_getapphead(appid);

	size	= sizeof(struct shcextbin);

	if((shcExtBinLocal = (struct shcextbin *)
			calloc(keyp->nkeys, sizeof(struct shcextbin))) == NULL)
		log_msg(FATAL, TO_CC, "F-SHC-138023:Unable to allocate %ld bytes of memory.\n",
				keyp->nkeys * size);

	// R027722 >>>
	if((pgroupLocal = (struct shcextbinGroupHeader *)
						calloc(keyp->ntext , sizeof(struct shcextbinGroupHeader))) == NULL)
		log_msg(FATAL, TO_CC, "F-SHC-138023.1:Unable to allocate %ld bytes of memory.\n",
				keyp->ntext * sizeof(struct shcextbinGroupHeader));
	// <<< R027722

	//	>>>	R020436 

	DBMHSTMT shQuery;
	DBMHDBC ch;
	DBMRETURN ret = 0;
	if (dbm_connect() >=0)
	{
		OTraceDebug("D-SHC-138033:Connecting to database successful\n");
		ch=dbm_dbconn;
	}
	else
	{
		OTraceError("E-SHC-138034: Connecting to database failed\n");
		return( -1 );
	}

	char sqlStatementQuery[512]="select lowbin, highbin, o_level, status, description, destination, entity_id, cardproduct, network_data, file_name, file_version, file_date, country_code, network_config, bin_length from shcextbindb where status = 'A'"; // ---     R029874
	if( DBMAllocStmt(ch, &shQuery) < 0)
	{
		OTraceError("E-SHC-138035: Select query statement allocate error:\n%s\n", sqlStatementQuery);
	}
	if( (DBMBindCol(shQuery,1,DBM_CHARTYPE,&shcExtBinDB.lowbin,sizeof(shcExtBinDB.lowbin),&ind[0]) != DBM_SUCCESS) ||
	    (DBMBindCol(shQuery,2,DBM_CHARTYPE,&shcExtBinDB.highbin,sizeof(shcExtBinDB.highbin),&ind[1]) != DBM_SUCCESS) ||
	    (DBMBindCol(shQuery,3,DBM_LONGTYPE,&shcExtBinDB.o_level,sizeof(shcExtBinDB.o_level),&ind[2]) != DBM_SUCCESS) ||
	    (DBMBindCol(shQuery,4,DBM_CHARTYPE,&shcExtBinDB.status,sizeof(shcExtBinDB.status),&ind[3]) != DBM_SUCCESS) ||
	    (DBMBindCol(shQuery,5,DBM_CHARTYPE,&shcExtBinDB.description,sizeof(shcExtBinDB.description),&ind[4]) != DBM_SUCCESS) ||
	    (DBMBindCol(shQuery,6,DBM_CHARTYPE,&shcExtBinDB.destination,sizeof(shcExtBinDB.destination),&ind[5]) != DBM_SUCCESS) || 
        (DBMBindCol(shQuery,7,DBM_CHARTYPE,&shcExtBinDB.entity_id,sizeof(shcExtBinDB.entity_id),&ind[6]) != DBM_SUCCESS) ||  
	    (DBMBindCol(shQuery,8,DBM_CHARTYPE,&shcExtBinDB.cardproduct,sizeof(shcExtBinDB.cardproduct),&ind[7]) != DBM_SUCCESS) ||
		(DBMBindCol(shQuery,9,DBM_CHARTYPE,&shcExtBinDB.network_data,sizeof(shcExtBinDB.network_data),&ind[8]) != DBM_SUCCESS) ||
		(DBMBindCol(shQuery,10,DBM_CHARTYPE,&shcExtBinDB.file_name,sizeof(shcExtBinDB.file_name),&ind[9]) != DBM_SUCCESS) ||
		(DBMBindCol(shQuery,11,DBM_CHARTYPE,&shcExtBinDB.file_version,sizeof(shcExtBinDB.file_version),&ind[10]) != DBM_SUCCESS) ||
		(DBMBindCol(shQuery,12,DBM_DATETYPE,&shcExtBinDB.file_date,sizeof(shcExtBinDB.file_date),&ind[11]) != DBM_SUCCESS) ||
		(DBMBindCol(shQuery,13,DBM_INTTYPE,&shcExtBinDB.country_code,sizeof(shcExtBinDB.country_code),&ind[12]) != DBM_SUCCESS) ||
		(DBMBindCol(shQuery,14,DBM_CHARTYPE,&shcExtBinDB.network_config,sizeof(shcExtBinDB.network_config),&ind[13]) != DBM_SUCCESS) ||
		(DBMBindCol(shQuery,15,DBM_INTTYPE,&shcExtBinDB.bin_length,sizeof(shcExtBinDB.bin_length),&ind[14]) != DBM_SUCCESS) )
	{
		OTraceError("E-SHC-138036: Select query bind error \n");
		return (-1);
	}
	else
	{
		if( DBMPrepare(shQuery, sqlStatementQuery) != DBM_SUCCESS )
		{
			OTraceError("E-SHC-138037: Select query prepare error:\n%s \n", sqlStatementQuery);
		}
		
		int num_prefetch = 1000;
		int rc = DBMSetStmtAttribute(shQuery, DBM_ATTR_PREFETCH_COUNT, &num_prefetch, sizeof(num_prefetch));
		if (rc != DBM_SUCCESS)
		{
			processError(rc, shQuery);
			OTraceWarning("W-SHC-138038: Failed to set prefetch count\n");
		}
		
		ret = DBMExecute(shQuery);
		if(ret != DBM_SUCCESS)
		{
			if(processError(ret, ch))
			{
				DBMFreeStmt(shQuery, DBM_DROP);
				return (-1);
			}
		}
	}
	for(i = 0; i < keyp->nkeys; i++)
	{
		int dbi,memoryi;
		memset((char *)&shcExtBinDB, 0, sizeof(struct shcextbindb));
		memset((char *)&shcExtBinMemory, 0, sizeof(struct shcextbin));

		ret = DBMFetch(shQuery);
		if (ret != DBM_SUCCESS)
		{
			if(processError(ret, ch))
			break;
		}
		else
		{
		memset(shcExtBinLocal[i].highbin, (unsigned char)0xff, sizeof(shcExtBinLocal[i].highbin));
		
		/* read one record */
		for ( dbi = memoryi = 0; dbi <sizeof(shcExtBinDB.lowbin) -1; dbi += 2, memoryi++)
		{
			shcExtBinLocal[i].lowbin[memoryi] = (EXTBINCHAR2BCD(shcExtBinDB.lowbin[dbi], 0) << 4) |
								 (EXTBINCHAR2BCD(shcExtBinDB.lowbin[dbi+1], 0));
			shcExtBinLocal[i].highbin[memoryi] = (EXTBINCHAR2BCD(shcExtBinDB.highbin[dbi], 0xf) << 4) |
								 (EXTBINCHAR2BCD(shcExtBinDB.highbin[dbi+1], 0xf));

		}

		memcpy(shcExtBinLocal[i].cardProduct, shcExtBinDB.cardproduct, sizeof(shcExtBinDB.cardproduct));
		initebin_removeTrailingSpace(shcExtBinLocal[i].cardProduct);
		ICInstId_pure(shcExtBinLocal[i].destination, shcExtBinDB.destination);
													/* R002639 BEGIN */
		memcpy(shcExtBinLocal[i].network_data, shcExtBinDB.network_data,
				sizeof(shcExtBinLocal[i].network_data)-1);
		shcExtBinLocal[i].network_data[sizeof(shcExtBinLocal[i].network_data)-1]='\0';
													/* R002639 END */
		shcExtBinLocal[i].country_code = shcExtBinDB.country_code;//    ---     R029874
		shcExtBinLocal[i].bin_length = shcExtBinDB.bin_length;

		memcpy(shcExtBinLocal[i].network_config, shcExtBinDB.network_config,
				sizeof(shcExtBinLocal[i].network_config)-1);
		shcExtBinLocal[i].network_data[sizeof(shcExtBinLocal[i].network_data)-1]='\0';

		  memcpy(shcExtBinLocal[i].file_version, shcExtBinDB.file_version, sizeof(shcExtBinLocal[i].file_version)-1);
		  shcExtBinLocal[i].file_version[sizeof(shcExtBinLocal[i].file_version)-1]='\0';

		memcpy(shcExtBinLocal[i].entityId, shcExtBinDB.entity_id, sizeof (shcExtBinDB.entity_id));
		initebin_removeTrailingSpace(shcExtBinLocal[i].entityId);
		if (	(shcExtBinLocal[i].entityId[0] == '*' )&& 
				(shcExtBinLocal[i].entityId[1] == '\0')
			)
		{
			shcExtBinLocal[i].entityId[0] = '\0';
		}
		}
	}

	if(i == keyp->nkeys)
		OTraceWarning("W-SHC-138024: Shared memory is not enough. Please restart mailbox system to allocate more.\n");

	while( 1 )
	{
		removedRecordNumber = 0 ;
		qsort(shcExtBinLocal, i, sizeof(struct shcextbin), keys_cmp);
		if ( removedRecordNumber == 0)
			break ;
	}

	struct shcextbin *tmpm2 = &shcExtBinLocal[i-1];
	int j;
	for (j=0; strcmp(tmpm2->destination, "~~~~~~~~~~")==0; tmpm2--, j++);
	i -= j;
	
	if (j > 0)
	{
		syslg("E-SHC-0892:Some entry in shcextbindb are not loaded, "
				"see debug file for detailed information\n");
	}

	memcpy((char *)pTmpShcExtBinMemory, (char *)shcExtBinLocal, keyp->nkeys * size);

	keyp->keysused = i;	

	dbm_close_all(getpid());
	DBMFreeStmt(shQuery, DBM_DROP);	
	
    if (!shcinitebinNewGrouping)
    {
        create_groups(shcExtBinLocal,pgroupLocal,i,&textused); //R027722
    }
    else
    {
        optimize(shcExtBinLocal, i, pgroupLocal, &textused);
    }


			/* 	R022481 >> */
	if ( rm_lockAppid(appid) < 0 )
	{
		OTraceWarning("W-SHC-138024.0: rm.appid[%d] locked by other, grab lock after 1 sec\n", appid);
		sleep(1);
		rm_unlockAppid(appid);
		rm_lockAppid(appid);
	}
	else
	{
		OTraceDebug("D-SHC-138024.1: Locked rm.appid[%d] successfully, memcpy by size[%ld]\n", 
				appid,  keyp->nkeys*size); //---R028747
	}
	
	memcpy((char *)pTmpShcExtBinMemory, (char *)shcExtBinLocal, keyp->nkeys * size);
	memcpy((char *)pgroupMem, (char *)pgroupLocal, textused * sizeof(struct shcextbinGroupHeader)); //R027722
	
	keyp->keysused = i;     /* R007235 */
	keyp->textused = textused; //R027722
		
	rm_unlockAppid(appid);
	OTraceDebug("D-SHC-138024.2: Unlocked rm.appid[%d]\n", appid);
			/* 	R022481 << */

    //	<<<	R020436 
	return( 0 );
}

/* This function is for debug purpose */
int dump_records()
{
	int dbi, i, memoryi;
	struct rules_keytab *keyp;
	struct shcextbin	*pTmpShcExtBinMemory;
	if (msgtype != EXTBIN_REC)
		return(0);

	initSys();
	if(rm_attach( appid, RULES_VER_CURRENT ) < 0)
		return (-1);

	if((pTmpShcExtBinMemory = (struct shcextbin *)rm_getappkey(appid)) == NULL)
		log_msg(FATAL, TO_CC, "F-SHC-138025:couldn't locate the shared memory for shcextbin!\n");

	keyp = rm_getapphead(appid);

	for(i = 0; i < keyp->keysused; i++)
	{
		memset((char *)&shcExtBinDB, 0, sizeof(struct shcextbindb));
		for ( dbi = memoryi = 0; dbi <sizeof(shcExtBinDB.lowbin) -1; dbi += 2, memoryi++)
		{
			shcExtBinDB.lowbin[dbi] = ((unsigned char)pTmpShcExtBinMemory[i].lowbin[memoryi]>>4)+'0';
			shcExtBinDB.lowbin[dbi+1] = (pTmpShcExtBinMemory[i].lowbin[memoryi]&0xf) + '0';
			shcExtBinDB.highbin[dbi] = ((unsigned char)pTmpShcExtBinMemory[i].highbin[memoryi]>>4)+'0';
			shcExtBinDB.highbin[dbi+1] = (pTmpShcExtBinMemory[i].highbin[memoryi]&0xf) + '0';
		}
		
		shcExtBinDB.lowbin[sizeof(shcExtBinDB.lowbin)-1] = '\0';
		shcExtBinDB.highbin[sizeof(shcExtBinDB.highbin)-1] = '\0';
         OTraceDebug("D-SHC-138026:%s:%s:%s:%s:%s:%d:%s:%s:%d:\n", shcExtBinDB.lowbin, shcExtBinDB.highbin,
		 					pTmpShcExtBinMemory[i].destination,
							pTmpShcExtBinMemory[i].entityId,
							pTmpShcExtBinMemory[i].cardProduct,
							pTmpShcExtBinMemory[i].country_code,// ---     R029874
							pTmpShcExtBinMemory[i].network_config,
							pTmpShcExtBinMemory[i].file_version,
							pTmpShcExtBinMemory[i].bin_length);

	}

	dbm_close_all(getpid());

	return( 0 );
}

int pexit(int n)
{
	HaPtmCctHelper::cleanUp() ;
	OTraceOff();
	return(n);
}

//	>>>	R020436

int processError(int ret, DBMHSTMT sh)
{
    int recnum=1;
    char sqlstate[6];
    int native_error;
    char msg_text[2048];
    switch(ret)
    {
    case DBM_SUCCESS_WITH_INFO:
        return false;
    case DBM_NO_DATA:
    	OTraceDebug ("D-SHC-138039:End of data\n");
		return true;
    case DBM_ERROR:
        while(DBMGetDiagRec(DBM_HANDLE_STMT, sh, recnum++,
                sqlstate, &native_error, msg_text, sizeof(msg_text), NULL)
                == DBM_SUCCESS)
        {
            OTraceError("E-SHC-138040:%s\n", msg_text);
        }
        if (recnum <= 2)
        {
            OTraceError("E-SHC-138041:Unknown DB error:%d\n", ret);
        }
        return true;
    case DBM_INVALID_HANDLE:
        OTraceError("E-SHC-138042:Invalid handle(internel error)\n");
        return true;
    default:
        OTraceError("E-SHC-138043:Unknow db error:%d\n", ret);
        return true;
    }
}					
//	<<<	R020436
