//
// Copyright (C) 2017 eFunds Corporation ("eFunds").  All Rights Reserved.  
// eFunds Canada Corporation is an authorized user. 
// 
// IST is a registered trademark of eFunds Corporation.  Other brand or
// product names are trademarks or registered trademarks of their respective
// holders. 
// 
// The information contained herein is the unpublished proprietary property
// of eFunds.  Except as specifically authorized in writing by eFunds, the
// holder of this document shall: i) keep all information contained herein
// confidential, and ii) protect the information, in whole or in part, from
// disclosure and dissemination to all third parties. 
// 
// This document and the software described in it are furnished under license
// and may be used or copied only in accordance with the terms of such license.
// This document is supplied for information purposes only, is subject to
// change without notice, and should not be construed as a commitment by
// either eFunds Corporation or eFunds Canada Corporation. 
//
static char _shccmddaemonsend_cxx_what[] = "@(#) shccmddaemonsend.cxx 1.1 17/10/06 14:01:54";

#include <config.h>
static const char ver[] = PACKAGE "-" VERSION;

#include <stdio.h>
#include <string.h>
#include <stdlib.h>

#include <ist_trace.h>
#include <ist_otrace.h>

#include "ist_oasis.h"
#include "mb.h"
#include "ist_argv0.h"

/*
 *    Utility to send shccmd command to ShccmdDaemon mailbox
 */
int main(int argc, char **argv)
{
    char    buf[1000];
    int        mbid = -1;;
    int        mymbid = -1;
    int        isFailed = 0;

    argv0 = *argv;

    OTraceOn("shccmddaemonsend.debug");

    OTraceDebug("D-SHCDSD-0000: Running version:%s\n", ver);

    mb_init();

    memset(buf, 0, sizeof(buf));
    char *p = buf;
    int plen = sizeof(buf);
    int arglen = 0;
    int i = 0;

    if( argc > 1 )
    {
        snprintf(p, plen, "shccmd");  
        arglen = strlen(p);
        plen = sizeof(buf) - arglen;  
        p += arglen;

        for(i = 1; i < argc; i++)
        {
            snprintf(p, plen, " %s", argv[i]); 
            arglen = strlen(p);
            plen -= arglen;  
            p += arglen;
        }

        mymbid = mb_createmailbox_private();

        mbid = mb_locatemailbox((char *) "ShccmdDaemon" );
        if(mbid < 0)
        {
            OTraceError("E-SHCDSD-0001: ShccmdDaemon mailbox not found\n");
            printf("ERR: ShccmdDaemon mailbox not found\n");
            isFailed = 1;
        }
        else
        {
            OTraceDebug("D-SHCDSD-0002: send: %s\n", buf);
            mb_write(mbid, mymbid, buf, strlen(buf) + 1);
        }
    }
    else
    {
        printf("Usage : shccmddaemonsend <arguments>\n");
        printf("\n");
        printf("<arguments> - shccmd arguments\n");

        OTraceError("E-SHCDSD-0003: Usage : shccmddaemonsend <arguments>\n");
        return (-1);
    }

    mb_deletemailbox(mymbid);

    if (isFailed == 0)
    { 
        OTraceDebug("D-SHCDSD-0004: Complete\n");
        printf( "INFO: Complete\n" );
    }

    return(0);
}
