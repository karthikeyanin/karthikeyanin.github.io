static char ver[100]="IST:Share Initialisatian: r";
static char _shcinit_cxx_what[] = "@(#) shcinitprofiles.cxx 1.39.2.11 18/07/06 17:07:29";

/*
 *  Copyright (C) 2004 eFunds Corporation ("eFunds").  All Rights Reserved.     
 *  eFunds Canada Corporation is an authorized user.                            
 *                                                                              
 *  IST is a registered trademark of eFunds Corporation.  Other brand or        
 *  product names are trademarks or registered trademarks of their respective   
 *  holders.                                                                    
 *                                                                              
 *  The information contained herein is the unpublished proprietary property    
 *  of eFunds.  Except as specifically authorized in writing by eFunds, the     
 *  holder of this document shall: i) keep all information contained herein     
 *  confidential, and ii) protect the information, in whole or in part, from    
 *  disclosure and dissemination to all third parties.                          
 *                                                                          
 *  This document and the software described in it are furnished under license  
 *  and may be used or copied only in accordance with the terms of such license.
 *  This document is supplied for information purposes only, is subject to      
 *  change without notice, and should not be construed as a commitment by       
 *  either eFunds Corporation or eFunds Canada Corporation. 
 */
/*
 *
 *                        MODIFICATION HISTORY                  REVIEW
 *
 *	SPR#	Who	Date	Description			Who	Date   
 * ===========================================================================
 *R008717 ztang 20Nov02 Multi-institution support
 *R009076 ztang 05Feb03 wait for shbin when initialize
 *R009248 ztang 17Feb03 Added more condition when deciding null field
 *R012134 Emj   04Oct04 Issuer Entity Support
 *R021845 Emj   01Nov07 For update only load iss_profile records for node
 *R022481 jyang 29Jan08 Supported for locking shared memory of rules
 *R023310 Ram   27May08 SDK header should refer external header
 *R028747 Dipa  17Nov10 Remove reference to rules_keytab[]
 *R029083 Emj   10Feb11 Don't load keys if Bin does not use keys
 *R029258 Emj   31Mar11 Check SH_KEYS_REQUIRED if keys should be loaded
 *IST_S761_HIST-18	dipa	17Apr14	Clone of IST_S761_HIST-9[Dump keys information present in shared memory]
 *R160156939 IS 4Apr16 Addition of the site_id during the look up at the inst_prof rule
 */

//File Number 139

#include <config.h>
#include <stdio.h>
#include <string.h>
#include <oasis.h>
#include <oasisenv.h>
#include <util.h>
#include <mb.h>
#include <mb_umi.h>
#include <rules.h>
#include <ist_otrace.h>
#include<ic/ic_instid.h>

#include <DBM3.h>
#include <dbm.h>
#include <dbm_private.h>
#include <shc.h> 
#include <acq_profile.h>
#include <iss_profile.h>
#include <inst_profile.h>
#include <ShcBin.h> 	// ---	R023310
#include <mt_inst_profile.h>
#include <mt_iss_profile.h>
#include <mt_acq_profile.h>
#include <ShcApp.h>
#include <BinRoute.h>
#include <InstProfile.h>
#include <ShcSharedMemoryHelper.h>

#include <HaPtmCctHelper.h>
#include <ShcKeyHelper.h>

/* Following two parameters determines the minimum number of entries allocated in shared memory */
#define MINIMUM_MEMORY_INCREMENT 100

/* Minimum percentage of extra memory needed */
#define EXTRA_MEMORY				20

#define profileCharIsNull(c) (c == '*' || c == '\0')

extern "C"
{
	int acq_profile_cmp(const void *anykey1, const void *anykey2);
	int iss_profile_cmp(const void *anykey1, const void *anykey2);
	int inst_profile_cmp(const void *anykey1, const void *anykey2);
}
int initCfg();
int initSys(const char *tableName);
int count_records();
int init_records();
int format_record(register struct iss_profile *db, struct IssuerProfile *pkg);
int format_record(register struct acq_profile *db, struct AcquirerProfile *pkg);
int format_record(register struct inst_profile *db, struct InstitutionProfileShm *pkg);
int load_servers();
int update_record();
int pexit(int n);
int dump_record();
int dump_keys();


/*
 *	An application initialiser is invoked with the following paramaters
 *
 *		<taskname>	<mode>	<rulename>	<appid> <srvname> [<data>]
 *
 *	<taskname>		the executable name of this task		(argv[0])
 *	<mode>			the mode of processing
 *						'count'			count space needed and report to strm
 *						'init'			init the rules in-core database
 *						'update'		update an existing rule
 *						'load'			load you application
 *						'dump'			Dump the specified profile into debug file,
 *										This only works when shcinitprofiles.debug is 'DUMP'.
 *
 *	<rulename>		the name of the rule to be initialised
 *	<appid>			the system assigned application id for this rule
 *
 *	<srvname>		the server to which count information should be sent
 *
 *	<data>			data which might be included in an 'update' command
 *
 *
 *****************************************************************************
 *
 *	This is Multi-institution profiles initialiser
 *	This task accepts initialisation requests for three types of messages
 *
 *			acq_profile
 *			iss_profile	
 *			inst_profile
 *
 *	It is important that shared-cash be initialised BEFORE above three profiles
 *	This is acomplished by placing the entry in the rules.cfg for shared-cash
 *	before the entry these entries.
 *
 */

int		con_id = (-1);
struct	rules_keytab keytab = {0};
int		my_count = 0;

int		fd = (-1);

int		appid;
int		size;
const char	*bp;
char *tableName = NULL;


#define	ACQ_REC		1
#define ISS_REC		2
#define INST_REC	3

int		msgtype = 0;
int		argc = 0;
char	**argv = NULL;

static	int		call_dbm_init = (0);

// Define global variable for shared memory version report
int gRuleVer = -1;

int main(int a_rgc, char **a_rgv)
{
	argv = a_rgv;
	argc = a_rgc;

	argv0 = *argv;
	catch_all_signals(NULL);

	OTraceOn(argv0);

	// Define return value for return value report
	int aRet = 0;
	// call function to mangle the argv
	rm_extOptFrArg(argc, argv);

	HaPtmCctHelper::deinit() ;

	if(argc < 5 && argc!=2)
	{
		OTraceFatal("F-SHC-139001:%d is an invalid number of parameters\n", argc);
		// set return value and go to exit when there is error
		aRet = -1;
		goto exit;
	}
	

	strcat(ver, VERSION);
	mb_init();
	dbmid = getpid();

	if(argc == 2)
	{
		if(stricmp("dump_keys", argv[1])==0)
			dump_keys();
		else
		{
			printf("Invalid parameter! Valid param to dump keys is: dump_keys\n");
			OTraceFatal("F-SHC-139001a: Invalid parameter. Valid param is dump_keys\n");
			// set return value and go to exit when there is error
			aRet = -1;
		}
		goto exit;
	}

	/*
	 *	Connect to the named server
	 */
	con_id = mb_locatemailbox(argv[RULES_PARM_SRVNAME]);
	if(con_id == -1)
	{
		OTraceFatal("F-SHC-139002:Unable to connect to %s: Error: %d\n",
			argv[RULES_PARM_SRVNAME], errno);
			// set return value and go to exit when there is error
			aRet = -1;
			goto exit;
	}
	

	/*
	 *	Extract all paramaters
	 */
//	if (rm_init() < 0)
//	{
//		OTraceDebug("F-SHC-139034: Unable to connect to RuleManager : Error: %d\n",
//				errno);
//		pexit(1);
//	}
	//appid = rm_getappid(argv[RULES_PARM_RULENAME]);
	appid = atoi(argv[RULES_PARM_APPID]);
	
	if(stricmp("acq_profile", argv[RULES_PARM_RULENAME]) == 0)
		msgtype = ACQ_REC;
	else if(stricmp("iss_profile", argv[RULES_PARM_RULENAME]) == 0)
		msgtype = ISS_REC;
	else if(stricmp("inst_profile", argv[RULES_PARM_RULENAME]) == 0)
		msgtype = INST_REC;
	else
	{
		OTraceFatal("F-SHC-139003:Invalid message type: %s\n",
					argv[RULES_PARM_RULENAME]);
		// set return value and go to exit when there is error
		aRet = -1;
		goto exit;
	}

	switch(msgtype)
	{
	case ACQ_REC:
		size	= sizeof(struct AcquirerProfile);
		bp		= "select count(1) from acq_profile";
		tableName = (char *)"acq_profile";
		break;
	case ISS_REC:
		size	= sizeof(struct IssuerProfile);
		bp		= "select count(1) from iss_profile";
		tableName = (char *)"iss_profile";
		break;
	case INST_REC:
		size	= sizeof(struct InstitutionProfileShm);
		bp		= "select count(1) from inst_profile";
		tableName = (char *)"inst_profile";
		break;
	}

	initCfg();	/* Debug file is opened in this function */

	OTraceDebug("D-SHC-139004:Rule[%s] Mode[%s]\n", argv[RULES_PARM_RULENAME], argv[RULES_PARM_MODE]);
	
	/*
	 *	Now determine which we need and perform action
	 */
	if(stricmp(argv[RULES_PARM_MODE], "count") == 0)
		aRet = count_records();
	else if(stricmp(argv[RULES_PARM_MODE], "init") == 0)
		aRet = init_records();
	else if(stricmp(argv[RULES_PARM_MODE], "load") == 0)
		aRet = load_servers();
	else if(stricmp(argv[RULES_PARM_MODE], "update") == 0)
	{
		aRet = update_record();
	}
	else if (stricmp(argv[RULES_PARM_MODE], "dump") == 0)
	{
		aRet = dump_record();
	}
	else
	{
		OTraceFatal(
		"F-SHC-139005:I don't know how to interpret mode '%s'\n", argv[RULES_PARM_MODE]);
		aRet = -1;
	}

	exit:

	if(call_dbm_init)
		dbm_close_all(dbmid);

	// Output status info based on return value and version number 
	rm_outInfo(gRuleVer, aRet);

	// return the return value
	return pexit(aRet);

}

int profileFieldIsNull(char *s)
{
	if (s[0] == '\0' )
		return 1;
	
	int starti, endi, len;
	char tmpBuf[1000];
	len =strlen(s);
	
	for (starti=0; starti<len && s[starti] == ' '; starti++);
	for (endi=len-1; endi>=starti && s[endi] == ' '; endi--);
	
	if (endi < starti)
		return 1;
		
	len=endi-starti+1;
	memcpy(tmpBuf, &s[starti], len);
	
	tmpBuf[len] = '\0';
	if (tmpBuf[0] == '*' )
		return 1;
	
	strcpy(s, tmpBuf);
	return 0;
}
int allowedForThisNode(struct iss_profile * dbBuf)
{
	char tmpNode[sizeof(dbBuf->node)];
    int tmpi;
    int tmplen = strlen(dbBuf->node);
    for (tmpi=0;tmpi<tmplen, dbBuf->node[tmpi]==' ';tmpi++);
    int tmpj;
    for (tmpj=tmplen-1;tmpj>=tmpi,dbBuf->node[tmpj]==' ';tmpj--);
    if(tmpj<tmpi)
        tmpNode[0] = '\0';
    else
    {
        dbBuf->node[tmpj+1] =  '\0';
        strcpy(tmpNode, &dbBuf->node[tmpi]);
    }

	if (!tmpNode[0])
		return 1;
	if (ist_regexpcv(tmpNode, mbcurrentnode, 0))
		return 1;
	else
		return 0;
}

int shcinitprofilesGetMinimumSpace()
{
	int ret;
	int numOfEntries = 0;
	DBMHSTMT tmpStmt;
	
    if (dbm_connect() >=0)
    {
        OTraceDebug("D-SHC-139006:Connecting to database successful");
    }
    else
    {
        OTraceFatal("F-SHC-139007:Connecting to database failed");
        return -1;
    }
    ret=DBMAllocStmt(dbm_dbconn, &tmpStmt);
    if (ret < 0)
    {
        OTraceFatal("F-SHC-139008:Can't allocate statment:%s", bp);
        return -1;
    }
    ret=DBMPrepare(tmpStmt, (char *)bp);
    if (ret < 0)
    {
        OTraceFatal("F-SHC-139009:Can't prepare statment:%s", bp);
        return -1;
    }
    ret=DBMExecute(tmpStmt);
    if (ret < 0)
    {
        OTraceFatal("F-SHC-139010:Can't execute statment:%s", bp);
        return -1;
    }
    
    int status;
    ret=DBMBindCol(tmpStmt, 1, DBM_LONGTYPE, &numOfEntries, sizeof(numOfEntries), &status);
    if (ret < 0)
    {
        OTraceFatal("F-SHC-139011:Can't bind for statment:%s", bp);
        return -1;
    }

    ret=DBMFetch(tmpStmt);
    if (ret == DBM_NO_DATA)
    	numOfEntries = 0;
	else if (ret < 0)
    {
        OTraceFatal("F-SHC-139012:Can't fetch for statment:%s", bp);
        return -1;
    }
    DBMFreeStmt(tmpStmt, DBM_CLOSE);
    
    /* Now calculate how many entries we should allocate
     * The number of entries increase by 100.
     * And we need to keep at least 20% free space
     */
    numOfEntries = (numOfEntries+1) * (MINIMUM_MEMORY_INCREMENT + EXTRA_MEMORY)/100;
    numOfEntries = (numOfEntries + MINIMUM_MEMORY_INCREMENT - 1)/MINIMUM_MEMORY_INCREMENT * MINIMUM_MEMORY_INCREMENT;
    
    return numOfEntries;
}


int count_records()
{
	/*
	 *	He wants me to inidcate how many keys and text buffers
	 *	as well as their respective sizes
	 *
	 *	I can do this by reading the database or by lokking in a
	 *	config file
	 */
	
	
	/*
	 *	Set up my retrun packet
	 */
	//keytab.appid = rm_getappid(argv[RULES_PARM_RULENAME]);
	keytab.appid = atoi(argv[RULES_PARM_APPID]);


	/*
	 *	Now i tell him how large my buffers should be
	 */
	keytab.keysize	= size;				/* 10001935 */

	if ((my_count = shcinitprofilesGetMinimumSpace()) < 0)
		log_msg(FATAL, TO_CC, "F-SHC-139013:Can't estimate shared memory needed.\n");

	keytab.nkeys	= my_count;

	keytab.textsize	= size;
	keytab.ntext	= 1;

	snprintf(keytab.name, sizeof(keytab.name),"%s",argv[RULES_PARM_RULENAME]);
	
	OTraceDebug("D-SHC-139014:keysize[%d] nkeys[%d] txtsize[%d] ntext[%d]\n", keytab.keysize,
				keytab.nkeys, keytab.textsize, keytab.ntext);
	/*
	 *	Now i send him the information
	 */
	mb_write(con_id, 0, &keytab, sizeof(keytab));

	return(0);
}



int acq_profile_cmp(const void *anykey1, const void *anykey2)
{
	return ((struct AcquirerProfile *)anykey1)->m_priority - ((struct AcquirerProfile *)anykey2) -> m_priority;

}

int iss_profile_cmp(const void *anykey1, const void *anykey2)
{
	int ret;
	ret = ((struct IssuerProfile *)anykey1)->m_priority - ((struct IssuerProfile *)anykey2) -> m_priority;
	if (ret!=0)
		return ret;
	if (((struct IssuerProfile *)anykey1)->m_isLocal)
		ret--;	//key1 may have higher priority because it's on local node
	if (((struct IssuerProfile *)anykey2)->m_isLocal)
		ret ++;	//key2 may have higher priority because it's on local node
	return ret;
}

int inst_profile_cmp(const void *anykey1, const void *anykey2)
{
	struct InstitutionProfileShm *k1 = (struct InstitutionProfileShm *)anykey1;
	struct InstitutionProfileShm *k2 = (struct InstitutionProfileShm *)anykey2;
	
	int ret = k1->m_priority - k2->m_priority;
	
	if (ret != 0)
		return ret;
	
	ret = strcmp(k1->m_bin, k2->m_bin);
	
	return ret;

}

int init_records()
{
	/*
	 *	Now I can actualy initialise my table
	 */
	int	key_count = 0, text_count = 0;
	int	i;
	struct rules_keytab *keyp;
	int	retval;
	struct acq_profile acqProfile;
	struct iss_profile issProfile;
	struct inst_profile instProfile;
	char *dbBuf, *pMemoryBuf;
	int dbBufSize;
	struct AcquirerProfile memoryAcqProfile, *pMemoryAcqProfile;
	struct IssuerProfile memoryIssProfile, *pMemoryIssProfile;
	struct InstitutionProfileShm memoryInstProfile, *pMemoryInstProfile;

	
	syslg("%s\n", ver);

	initSys(tableName);

	// >>> R029583
	if (appid < 0)
	{
		appid = rm_getappid(argv[RULES_PARM_RULENAME]);
		if (appid < 0)
		{
			OTraceDebug("D-SHC-139042:Failed to get appid. Abort key init\n");
			syslg("D-SHC-139042:Failed to get appid. Abort key init\n");

			return (-1);
		}
	}
	if ( rm_attach( appid, RULES_VER_LOADING ) < 0)
	{
		OTraceError("E-SHC-139043: Unable to attach to LOADING version \n");
		syslg("E-SHC-139043: Unable to attach to LOADING version. Abort updating/init shared-cash\n");
		return(-1);
	}
	// <<< R029583

	// get the version number: gRuleVer
	rm_attachedversion(appid, &gRuleVer);

	if (rm_waitstate( shcAppid,RULES_VER_CURRENT,  RM_STATE_READY, 180 )<0)
	{
		OTraceError("E-SHC-139040:shared-cash(%d) not ready, abort init %s.\n", shcAppid, tableName);
		syslg("E-SHC-139040:shared-cash(%d) not ready, abort init %s.\n", shcAppid, tableName);
		return -1;
	}

	if(!rm_isMultiVerSupported(0))
	{
		//If SHM versioning not supported, manually check if SHCBIN rule is loaded
		for (i = 0; i < 10; i++)
		{
			if (shcNumberOfKeys <= 0)
				sleep(10);
			else
				break;
			if (i>=9)
				log_msg(FATAL, TO_CC, "F-SHC-139015:shcinitprofiles can't be initialized because shcbin is not initialized\n");
		}
	}

	switch (msgtype)
	{
	case ACQ_REC:
		memset(&acqProfile, 0, sizeof(acqProfile));
		dbBuf = (char *)&acqProfile;
		dbBufSize = sizeof(acqProfile);
		pMemoryBuf = (char *)&memoryAcqProfile;
		break;
	case ISS_REC:
		memset(&issProfile, 0, sizeof(issProfile));
		dbBuf = (char *)&issProfile;
		dbBufSize = sizeof(issProfile);
		pMemoryBuf = (char *)&memoryIssProfile;
		break;
	case INST_REC:
		memset(&instProfile, 0, sizeof(instProfile));
		dbBuf = (char *)&instProfile;
		dbBufSize = sizeof(instProfile);
		pMemoryBuf = (char *)&memoryInstProfile;
		break;
	}

	

	for(i = 0;; ++i)
	{

		memset(dbBuf, 0, dbBufSize);

		if(i==0)
			retval = dbm_read(fd, dbBuf, DBM_RFIRST);
		else
			retval = dbm_read(fd, dbBuf, DBM_RNEXT);
		if ((msgtype == ISS_REC) && !allowedForThisNode((struct iss_profile *)dbBuf))
			continue;
		if(retval == -1)
			if(dbm_errno == DBME_NOTFOUND || dbm_errno == DBME_EOF)
				break;
			else
			{
				OTraceFatal("F-SHC-139016: Database error: %d\n", dbm_errno);
				return (-1);
			}
		
		/*
		 *	insert the key and the text into shared memory
		 */
		int shmkey_size = 0;
		switch(msgtype)
		{
		case ACQ_REC:
			memset(&memoryAcqProfile, 0, sizeof(memoryAcqProfile));
			retval=format_record(&acqProfile, &memoryAcqProfile);
			shmkey_size = sizeof(memoryAcqProfile);
			break;
		case ISS_REC:
			memset(&memoryIssProfile, 0, sizeof(memoryIssProfile));
			retval=format_record(&issProfile, &memoryIssProfile);
			shmkey_size = sizeof(memoryIssProfile);
			break;
		case INST_REC:
			memset(&memoryInstProfile, 0, sizeof(memoryInstProfile));
			retval=format_record(&instProfile, &memoryInstProfile);
			shmkey_size = sizeof(memoryInstProfile);
			break;
		}

		if (retval < 0)
			continue;

		/*	Insert the Package */
		if(rm_insert_key_sn(appid, (char *)pMemoryBuf, key_count, shmkey_size) < 0)
			OTraceFatal("SHC-1105: Unable to insert key\n");
		key_count++;
	}
	
	OTraceDebug("D-SHC-139017:%d keys inserted\n", key_count);
	keyp = rm_getapphead(appid);
	keyp->textused = text_count;
	keyp->keysused = key_count;


	/*
	 *	Now sort the bin entries for faster look up
	 */
	switch(msgtype)
	{
	case ISS_REC:
		pMemoryIssProfile = (struct IssuerProfile *)rm_getappkey(appid);
		qsort(pMemoryIssProfile, key_count, keyp->keysize, iss_profile_cmp);
		break;
	case ACQ_REC:
		pMemoryAcqProfile = (struct AcquirerProfile *)rm_getappkey(appid);
		qsort(pMemoryAcqProfile, key_count, keyp->keysize, acq_profile_cmp);
		break;
	case INST_REC:
		pMemoryInstProfile = (struct InstitutionProfileShm *)rm_getappkey(appid);
		qsort(pMemoryInstProfile, key_count, keyp->keysize, inst_profile_cmp);
		break;
	}
	
	keyp->flags |= RULES_KEY_SORTED;

	if(!rm_isMultiVerSupported(0))
		return 0;


	if (rm_setstate( appid, RULES_VER_ATTACHED, RM_STATE_READY) < 0)
	{
		OTraceError("E-SHC-139048:Can't set rule state to READY, Abort shared-cash init.\n");
		syslg("E-SHC-139048:Can't set rule state to READY, Abort shared-cash init.\n");
		return -1;
	}

	if (rm_unsetloading(appid) < 0)
	{
		OTraceError("E-SHC-139049:Can't unset rule state of LOADING, Abort shared-cash init.\n");
		syslg("E-SHC-139049:Can't unset rule state of LOADING, Abort shared-cash init.\n");
		return -1;
	}
	// Check whether to set the version to Current
	if(! rm_optDontSetCurrAftLoad())
	{
		if (rm_setcurrent( appid, RULES_VER_ATTACHED)<0)
		{
			OTraceError("E-SHC-139050:Can't set rule to CURRENT, Abort shared-cash init.\n");
			syslg("E-SHC-139050:Can't set rule to CURRENT, Abort shared-cash init.\n");
			return (-1);
		}
	}

	// <<< R029583	

	return(0);
}



int format_record(register struct iss_profile *db, struct IssuerProfile *pkg)
{
	/*
	 *	Input:		db			database record
	 *				pkg			in core record
	 *				new_entry	if set then this is a new record
	 *
	 *	Action:		Encode the database record into our internal record format
	 *				for use at run time.
	 *
	 */
	int i;
	
	pkg->m_priority = 0;
	
	if (profileFieldIsNull(db->txnsrc))
		pkg->m_txnSrc[0] = '\0';
	else
	{
		ICInstId_pure(pkg->m_txnSrc, db->txnsrc);
	}
		
	if (profileFieldIsNull(db->txndest))
	{
		pkg->m_txnDest[0] = '\0';
	}
	else
	{
		ICInstId_pure(pkg->m_txnDest, db->txndest);
	}

	if (profileFieldIsNull(db->entity_id))
	{
		pkg->m_entityId[0] = '\0';
	}
	else
	{
		strcpy(pkg->m_entityId, "^");
		strcat(pkg->m_entityId, db->entity_id);
		strcat(pkg->m_entityId, "$");
	}

	if (profileFieldIsNull(db->cardproduct))
	{
		pkg->m_cardProduct[0] = '\0';
	}
	else
	{
		strcpy(pkg->m_cardProduct, "^");
		strcat(pkg->m_cardProduct, db->cardproduct);
		strcat(pkg->m_cardProduct, "$");
	}
		
	
	if (profileFieldIsNull(db->msgtype))
	{
		pkg->m_msgType[0] = '\0';
	}
	else
		strcpy(pkg->m_msgType, db->msgtype);

	if (profileFieldIsNull(db->devicetype))
	{
		pkg->m_deviceType[0] = '\0';
	}
	else
		strcpy(pkg->m_deviceType, db->devicetype);

	if (profileFieldIsNull(db->pcode))
	{
		pkg->m_pcode[0] = '\0';
	}
	else
		strcpy(pkg->m_pcode, db->pcode);
		
	if (profileCharIsNull(db->haspin))
		pkg->m_hasPIN = '\0';
	else
		pkg->m_hasPIN = db->haspin;
		
	ICInstId_pure(db->iss_inst_id, db->iss_inst_id);
	if (shc_externalBin2InternalBin(pkg->m_bin, db->iss_inst_id, db->iss_userbin_id) < 0)
	{
		OTraceError("E-SHC-139018: can't map %s:%s to internal bin\n", 
			db->iss_inst_id, db->iss_userbin_id);
		return -1;
	}


	if(profileFieldIsNull(db->routing_bin))
	{
		strcpy(pkg->m_routing_bin, pkg->m_bin);
		OTraceDebug("D-SHC-139060: Mapping issuer_bin[%s] to routing_bin\n",pkg->m_bin);
	}
	else 
	{
		ICInstId_pure(db->routing_inst_id, db->routing_inst_id);
		if (shc_externalBin2InternalBin(pkg->m_routing_bin, db->routing_inst_id, db->routing_bin) < 0)
		{
			OTraceError("E-SHC-139059: can't map %s:%s to internal bin\n",
			db->routing_inst_id,db->routing_bin);
			return -1;
		}
	}

	if(profileFieldIsNull(db->add_condition))
	{
		pkg->m_addCondition[0] = '\0';
	}
	else
	{
		strcpy(pkg->m_addCondition, db->add_condition);
	}

	pkg->m_priority = db->priority;

	struct shcpkg *binpkg;
	shcApp->shcBinObj->shc_locate_bin(&binpkg, pkg->m_bin);
	if ((!binpkg->bin.node[0]) ||(strcmp(binpkg->bin.node, mbcurrentnode)==0))
		pkg->m_isLocal = 1;
	else
		pkg->m_isLocal = 0;
	OTraceDebug("D-SHC-139019:[%s][%s][%s][%s][%s][%s][%s][%c][%s][%d][%s][%s]\n",
		pkg->m_txnSrc, pkg->m_txnDest, pkg->m_entityId, pkg->m_cardProduct, pkg->m_msgType, pkg->m_deviceType,
		pkg->m_pcode, (pkg->m_hasPIN == '\0'?'.':pkg->m_hasPIN), pkg->m_bin, (int)pkg->m_priority, pkg->m_routing_bin,
		pkg->m_addCondition);
		
	return(0);
}

int format_record(register struct acq_profile *db, struct AcquirerProfile *pkg)
{
	/*
	 *	Input:		db			database record
	 *				pkg			in core record
	 *				new_entry	if set then this is a new record
	 *
	 *	Action:		Encode the database record into our internal record format
	 *				for use at run time.
	 *
	 */
	int i;

	pkg->m_priority = 0;
	if (profileFieldIsNull(db->txnsrc))
	{
		pkg->m_txnSrc[0] = '\0';
		pkg->m_priority += 2;
	}

	else
	{
		ICInstId_pure(pkg->m_txnSrc, db->txnsrc);
	}

	if (profileFieldIsNull(db->txndest))
	{
		pkg->m_txnDest[0] = '\0';
		pkg->m_priority += 2;
	}
	else
	{
		ICInstId_pure(pkg->m_txnDest, db->txndest);
	}

	if (profileFieldIsNull(db->entity_id))
	{
		pkg->m_entityId[0] = '\0';
		pkg->m_priority += 2;
	}
	else
	{	
		strcpy(pkg->m_entityId, "^");
		strcat(pkg->m_entityId, db->entity_id);
		strcat(pkg->m_entityId, "$");
	}

	if (profileFieldIsNull(db->curr_code))
	{
		pkg->m_currencyCode[0] = '\0';
		pkg->m_priority += 2;
	}
	else
		strcpy(pkg->m_currencyCode, db->curr_code);

	if (profileFieldIsNull(db->devicetype))
	{
		pkg->m_deviceType[0] = '\0';
		pkg->m_priority += 2;
	}
	else
		strcpy(pkg->m_deviceType, db->devicetype);
	ICInstId_pure(db->acq_inst_id, db->acq_inst_id);
	ICInstId_pure(db->alt_inst_id, db->alt_inst_id);
	//if (shc_externalBin2InternalBin(pkg->m_bin, db->acq_inst_id, db->acq_userbin_id) < 0)
	struct shcpkg *binpkg;
	newlyFoundShcBinKey = NULL;
	if(shc_locate_bin(&binpkg, db->acq_inst_id, db->acq_userbin_id) < 0)
	{
		OTraceError("E-SHC-139020: can't map %s:%s to internal bin\n", 
			db->acq_inst_id, db->acq_userbin_id);
		return -1;
	}
	else if (newlyFoundShcBinKey)
		strcpy(pkg->m_bin, newlyFoundShcBinKey->bin);
	else
		strcpy(pkg->m_bin, binpkg->bin.networkid);
	if ((!binpkg->bin.node[0]) ||(strcmp(binpkg->bin.node, mbcurrentnode)==0))
		//Give higher priority to local bin
		pkg->m_priority -= 1;

	if (profileFieldIsNull(db->alt_inst_id))
		pkg->m_alternateBin[0] = '\0';
	else if (shc_externalBin2InternalBin(pkg->m_alternateBin, db->alt_inst_id, db->alt_userbin_id) < 0)
	{
		OTraceError("E-SHC-139021: can't map %s:%s to internal bin\n", 
			db->alt_inst_id, db->alt_userbin_id);
		return -1;
	}

	OTraceDebug("[%s][%s][%s][%s][%s][%s][%s][%d]\n",
		pkg->m_txnSrc, pkg->m_txnDest, pkg->m_entityId, pkg->m_currencyCode,
		pkg->m_deviceType, pkg->m_bin, pkg->m_alternateBin, pkg->m_priority);
	return(0);
}

static int set_default_keylens(struct  shcsecurity *sec)
{
	if (sec->k.kek_len == 0)
       	sec->k.kek_len = 16;
	if (sec->k.isskpe_len == 0)
		sec->k.isskpe_len = 16;
	if (sec->k.isskme_len == 0)
		sec->k.isskme_len = 16;
	if (sec->k.issmac_len == 0)
		sec->k.issmac_len = 16;
	if (sec->k.acqkpe_len == 0)
		sec->k.acqkpe_len = 16;
	if (sec->k.acqkme_len == 0)
		sec->k.acqkme_len = 16;
	if (sec->k.acqmac_len == 0)
		sec->k.acqmac_len = 16;
	return(0);
}

int format_securitykeys(register struct inst_profile *db, struct InstitutionProfileShm *pkg, struct shcpkg *binpkg)														/* 10001935 */
{
	static	struct rules_keytab *sec_keyp = NULL;
	static	int sec_fd = (-1);
	struct	shcsecurity	sec;
	struct	shckeys		secdb	 = {0};					/* 10001935 */
	int		i;
	static  int newVerCreated = 0;
	

	pkg->keyparm = (-1);
	pkg->keyparamStr[0] = '\0';
	pkg->instId[0] = '\0';

	if(!(binpkg->bin.bintype & SH_KEYS_REQUIRED ))
		return(0);

    //wait until shckeys rule to be ready
    if (rm_waitstate( shcSecurityAppid,RULES_VER_CURRENT,  RM_STATE_READY, 180 )<0)
	{
        OTraceWarning("W-SHC-139059:keys in inst_profile can't be initialized because shckeys is not initialized\n");
		return -1;
	}


	if(sec_keyp == NULL)
		if((sec_keyp = rm_getapphead(shcSecurityAppid)) == NULL)
			return(-1);

    /* R016654 */
	ICInstId_pure(secdb.institutionid, db->inst_id);
	/* If keyparam is set use it otherwise use userbinid */
	if (strlen(db->keyparam) != 0 && 
		strcmp(db->keyparam, "          ") != 0)
	{
		strcpy(secdb.userbinid, db->keyparam);
	}
	else
	{
		strcpy(secdb.userbinid, db->userbin_id);
	}

	secdb.site_id = mbGetSiteId();

	/*
	 *	o	Open records if needed
	 */
	if(sec_fd == -1)
		if((sec_fd = dbm_open("shckeys_2", getpid())) < 0)
		{
			OTraceFatal("F-SHC-139038: Unable to open shc_keys\n");
			return(-1);
		}
	
	/*
	 *	Locate an existing entry if there
	 */
	struct rules_keytab *pShckeyAppHead= NULL;
	char *p = NULL;
	struct shcsecurity *pTmp = NULL;
	int isLocked = 0;
	
	if (shcSharedMemoryHelperObj->lockRule(sharedCashSecurityRuleName, &isLocked, &shcSecurityAppid) < 0)
	{
		OTraceError("E-SHC-139051:Can't get shared-cash-security locked. operation failed.\n");
		return -1;
	}
 	if (shcSharedMemoryHelperObj->attachCurrent(&shcSecurityAppid, &pShckeyAppHead) < 0)
	{
		OTraceError("E-SHC-139041:Can't find shared-cash-security rule, update request aborted\n");
		return -1;
	}
	for(i = 0; i < sec_keyp->textused; ++i)
	{
		pTmp = (struct shcsecurity *)(rm_getapptext(shcSecurityAppid)+pShckeyAppHead->textsize*i);
	 	if(stricmp(db->inst_id, pTmp->k.institutionid) == 0 &&
		   stricmp(secdb.userbinid, pTmp->k.userbinid) == 0)
		{
			/*	Already exists */
			pkg->keyparm = i;
			if(rm_isMultiVerSupported(0))
			{
				strcpy(pkg->keyparamStr, secdb.userbinid);
				strcpy(pkg->instId, secdb.institutionid);
			}
			binpkg->bin.bintype &= ~(SH_USES_KEYS);
			if(pTmp->k.keytypes == 'B' || pTmp->k.keytypes == 'P')
				binpkg->bin.bintype |= SH_USES_PIN_KEY;
			if(pTmp->k.keytypes == 'B' || pTmp->k.keytypes == 'M')
				binpkg->bin.bintype |= SH_USES_MAC_KEY;
			
			if(pTmp->k.flags[0] == 'C')
				binpkg->bin.bintype |= SH_ALLOW_KEY_EXCHANGE;
			else
				binpkg->bin.bintype &= ~(SH_ALLOW_KEY_EXCHANGE);

			if(pTmp->k.flags[1] == 'S')
				binpkg->bin.bintype |= SH_KEYS_SHARED;
			else
				binpkg->bin.bintype &= ~(SH_KEYS_SHARED);

			rm_appUnlockMemory(shcSecurityAppid);
			return(0);
		}
	}
	if (sec_keyp->textused >= sec_keyp->ntext)
	{
	    if(rm_isMultiVerSupported(shcSecurityAppid))
	    {
			if (!newVerCreated)
			{
    	    	int version = 0;
				if (rm_createNewVersion(shcSecurityAppid,&gRuleVer) < 0)
				{
					OTraceError("F-SHC-139052:Failed to creat new shared-cash-security version. Abort key init\n");
					syslg("F-SHC-xxxxx:Failed to creat new shared-cash-security version. Abort key init\n");
					rm_appUnlockMemory(shcSecurityAppid);
					return 0;
				}
				newVerCreated = 1;
				pkg->keyparm	= -1;
				strcpy(pkg->keyparamStr, secdb.userbinid);
				strcpy(pkg->instId, secdb.institutionid);
			}
			rm_appUnlockMemory(shcSecurityAppid);
			OTraceDebug("D-SHC-139053:New shared-cash-security version created. The key record will be available shortly.\n");
			return 0;
    	}
    	else
    	{
			OTraceError("F-SHC-139054:No shared memory space for new key. restart switch.\n");
			syslg("F-SHC-139054:No shared memory space for new key. restart switch.\n\n");
			rm_appUnlockMemory(shcSecurityAppid);
			return 0;

    	}
	}
	
	/*
	 *	Find the shckeys record from db
	 */

	//-------- R160156939

	secdb.site_id = mbGetSiteId();
        if(secdb.site_id == 0)
                 secdb.site_id = 1;

	//-------- R160156939

	if(dbm_read(sec_fd, (char *)&secdb, DBM_REQUAL) < 0)
	{
		OTraceFatal("F-SHC-139037: No security key record for (%d,%s,%s)\n", secdb.site_id, secdb.institutionid, secdb.userbinid);
		return(-1);
	}

	memset(&sec, 0, sizeof(struct shcsecurity));
	ICInstId_pure(secdb.institutionid, secdb.institutionid);
	memcpy(&sec.k, &secdb, sizeof(sec.k));
	if(rm_isMultiVerSupported(0))
		sec.hash = shcApp->shcKeyObj->getHashValue(pkg->keyparamStr);

    set_default_keylens(&sec);

	/*
	 *	Otherwise insert a new entry
	 */
	if(rm_insert_text_sn(shcSecurityAppid, (char *)&sec, sec_keyp->textused, sizeof(sec)) < 0)
		OTraceFatal("F-SHC-139039: Unable to insert security text\n");
	
	pkg->keyparm	= sec_keyp->textused;
	if(rm_isMultiVerSupported(0))
	{
		strcpy(pkg->keyparamStr, secdb.userbinid);
		strcpy(pkg->instId, secdb.institutionid);
	}
	++sec_keyp->textused;

	binpkg->bin.bintype &= ~(SH_USES_KEYS);
	pTmp = (struct shcsecurity *)(rm_getapptext(shcSecurityAppid)+pShckeyAppHead->textsize*pkg->keyparm);

	if(pTmp->k.keytypes == 'B' ||
	   pTmp->k.keytypes == 'P')
		binpkg->bin.bintype |= SH_USES_PIN_KEY;

	if(pTmp->k.keytypes == 'B' ||
	   pTmp->k.keytypes == 'M')
		binpkg->bin.bintype |= SH_USES_MAC_KEY;
		
	if(pTmp->k.flags[0] == 'C')
		binpkg->bin.bintype |= SH_ALLOW_KEY_EXCHANGE;
	else
		binpkg->bin.bintype &= ~(SH_ALLOW_KEY_EXCHANGE);

	
	/*
	 * R001835 Reset Interac Keys
	 */
	if(shcBinIsInterac(binpkg))
	{
		shcApp->shcBinObj->setBinPkg(binpkg);
		shcApp->shcBinObj->setKey(pTmp);
		shcApp->shcBinObj->shckeys_RstKeys();
	}
	
	rm_appUnlockMemory(shcSecurityAppid);
	return(0);
}


int format_record(register struct inst_profile *db, struct InstitutionProfileShm *pkg)
{
	/*
	 *	Input:		db			database record
	 *				pkg			in core record
	 *				new_entry	if set then this is a new record
	 *
	 *	Action:		Encode the database record into our internal record format
	 *				for use at run time.
	 *
	 */
	 static int siteid = mbGetSiteId();
	 if ( siteid != db->site_id )
	 {
		 OTraceDebug("D-SHC-139024 skip record id=[%d]. DB site[%d] not same as current site[%d]\n",
		 db->id, db->site_id, siteid );
		 return -1;
	 }

	int i;

	pkg->m_priority = 0;

	if (profileFieldIsNull(db->txnsrc))
	{
		pkg->m_txnSrc[0] = '\0';
		pkg->m_priority += 2;
	}

	else
	{
		ICInstId_pure(pkg->m_txnSrc, db->txnsrc);
	}

	if (profileFieldIsNull(db->txndest))
	{
		pkg->m_txnDest[0] = '\0';
		pkg->m_priority += 2;
	}
	else
	{
		ICInstId_pure(pkg->m_txnDest, db->txndest);
	}

	if (profileFieldIsNull(db->iss_entity_id))
	{
		pkg->m_iss_entityId[0] = '\0';
		pkg->m_priority += 2;
	}
	else
	{
		// ICInstId_pure(pkg->m_iss_entityId, db->iss_entity_id); R021833
		strtrim(db->iss_entity_id, pkg->m_iss_entityId);  // R021833
	}

	if (profileFieldIsNull(db->msgtype))
	{
		pkg->m_msgType[0] = '\0';
		pkg->m_priority += 2;
	}
	else
		strcpy(pkg->m_msgType, db->msgtype);

	if (profileFieldIsNull(db->externalid))
		pkg->m_externalId[0] = '\0';
	else
		strcpy(pkg->m_externalId, db->externalid);

	if (profileFieldIsNull(db->ext_id_desc))
		pkg->m_externalIdDesc[0] = '\0';
	else
		strcpy(pkg->m_externalIdDesc, db->ext_id_desc);

	if (profileFieldIsNull(db->member_id))
		pkg->m_member_ID[0] = '\0';
	else
		strcpy(pkg->m_member_ID, db->member_id);

	if (profileFieldIsNull(db->f_id))
		pkg->m_F_ID[0] = '\0';
	else
		strcpy(pkg->m_F_ID, db->f_id);

	ICInstId_pure(db->inst_id, db->inst_id);

	//if (shc_externalBin2InternalBin(pkg->m_bin, db->inst_id, db->userbin_id) < 0)
	struct shcpkg *binpkg;
	newlyFoundShcBinKey = NULL;
	if(shc_locate_bin(&binpkg, db->inst_id, db->userbin_id) < 0)
	{
		OTraceError("E-SHC-139022: can't map %s:%s to internal bin\n", 
			db->inst_id, db->userbin_id);
		return -1;
	}
	else if (newlyFoundShcBinKey)
		strcpy(pkg->m_bin, newlyFoundShcBinKey->bin);
	else
		strcpy(pkg->m_bin, binpkg->bin.networkid);
	if ((!binpkg->bin.node[0]) ||(strcmp(binpkg->bin.node, mbcurrentnode)==0))
		//Give higher priority to local bin
		pkg->m_priority -= 1;
	if (stricmp(argv[RULES_PARM_MODE], "init")==0)
	{
		pkg->status = (db->init_status=='U')?BIN_ROUTE_STATUS_UP:BIN_ROUTE_STATUS_DOWN;
	}
	else
	{
		//Note1:
		//For update, we need to keep the existing balance info and status.
		//This only applies to entries with id > 0.
		//We first keep an index of the existing entry in balInfo[0].
		//Then after sorting and get the lock, we copy the balInfo and status from old
		//entry to new entry quickly.
		if (db->id > 0)
		{
			//Find the index in rule shared memory, if found, set balInfo[0] to 1, 
			if ((pkg->balInfo[1] = shcApp->instProfileObj->locateById(db->id))>=0)
			{
				pkg->balInfo[0] = 1;
			}
		}
		else
			pkg->status = BIN_ROUTE_STATUS_UP;
	}
	
	pkg->id = db->id;
    if (db->binroute_group[0])
        strcpy(pkg->binrouteGroup, db->binroute_group);
    else
        sprintf(pkg->binrouteGroup, "%-d", db->id);

	//Find the key in shared memory
	format_securitykeys(db, pkg, binpkg);														/* 10001935 */

	
	OTraceDebug("D-SHC-139023:[%s][%s][%s][%s][%s][%s][%s][%s][%s][%d][%c][%d][%d][%s][%s]\n",
		pkg->m_txnSrc, pkg->m_txnDest, pkg->m_iss_entityId, pkg->m_msgType,pkg->m_externalId,
		pkg->m_externalIdDesc,pkg->m_member_ID, pkg->m_F_ID,pkg->m_bin, pkg->m_priority, 
			((pkg->status)?pkg->status:' '), pkg->keyparm,pkg->id, pkg->instId, pkg->keyparamStr);

	return(0);
}




int load_servers()
{
	/* Nothing to load */
	return(0);
}

/* It's difficult to speicify which entry should be updated, so only update all is supported */
int update_record()
{
	int	i, retval, key_count = 0;
	struct rules_keytab *keyp;
	struct	IssuerProfile 	*pMemoryIssProfile = NULL;
	struct	AcquirerProfile 	*pMemoryAcqProfile = NULL;
	struct	InstitutionProfileShm *pMemoryInstProfile = NULL;
	char *pApplicationKey;
	char *pBufLocal = NULL, *pMemoryBuf = NULL;
	char dbBuf[10000];

	int aRet = 0;

	initSys(tableName);

	if(rm_isMultiVerSupported(appid))
	{
		int version = 0;
		rm_init();
		// Create new shared memory version
		if(rm_createNewVersion(appid, &gRuleVer) < 0)
		{
			OTraceError("E-SHC-139055: Unable to create new version\n");
			aRet = -1;
		}
		else
		{
			OTraceDebug("D-SHC-139056: New version created appid [%d] version [%d]\n",appid, gRuleVer);
			// Wait for the shared memory version to be Ready
			aRet = rm_waitstate(appid, gRuleVer, RM_STATE_READY, -1) ;
		}
		return (aRet);

	}


	if((pApplicationKey = rm_getappkey(appid)) == NULL)
		log_msg(FATAL, TO_CC, "F-SHC-139024:couldn't locate the shared memory for %s!\n",argv[RULES_PARM_RULENAME]);
	
	switch(msgtype)
	{
	case ISS_REC:
		pMemoryIssProfile = (struct IssuerProfile *)pApplicationKey;
		size = sizeof(struct IssuerProfile); 
		break;
	case ACQ_REC:
		pMemoryAcqProfile = (struct AcquirerProfile *)pApplicationKey;
		size = sizeof(struct AcquirerProfile);
		break;
	case INST_REC:
		pMemoryInstProfile = (struct InstitutionProfileShm *)pApplicationKey;
		size = sizeof(struct InstitutionProfileShm);
		break;
	}
	

	keyp = rm_getapphead(appid);

	if((pBufLocal = (char *)calloc(keyp->nkeys, size)) == NULL)
		log_msg(FATAL, TO_CC, "F-SHC-139025:Unable to allocate %ld bytes of memory.\n",
				keyp->nkeys * size);

	pMemoryBuf = pBufLocal;
	
	for(i = 0;i<keyp->nkeys; ++i)
	{
		memset(dbBuf, 0, size);
		if(i==0)
			retval = dbm_read(fd, dbBuf, DBM_RFIRST);
		else
			retval = dbm_read(fd, dbBuf, DBM_RNEXT);

		if(retval == -1)
			if(dbm_errno == DBME_NOTFOUND || dbm_errno == DBME_EOF)
				break;
			else
				log_msg(FATAL, TO_CC, "F-SHC-139026:Database error: %d\n", dbm_errno);
		
		if ((msgtype == ISS_REC) && !allowedForThisNode((struct iss_profile *)dbBuf))
			continue;

		/*
		 *	insert the key and the text into shared memory
		 */
		switch(msgtype)
		{
		case ACQ_REC:
			retval=format_record((struct acq_profile *)dbBuf, (struct AcquirerProfile *)pBufLocal);
			break;
		case ISS_REC:
			retval=format_record((struct iss_profile *)dbBuf, (struct IssuerProfile *)pBufLocal);
			break;
		case INST_REC:
			retval=format_record((struct inst_profile *)dbBuf, (struct InstitutionProfileShm *)pBufLocal);
			break;
		}
		
		if (retval < 0)
			continue;
		pBufLocal += size;
		key_count++;
	}

	OTraceDebug("I-SHC-139027: %d %s entries are initialized\n", key_count, tableName);
	
	if(i == keyp->nkeys)
		log_msg(FATAL, TO_CC, "F-SHC-139028:Can't estimate shared memory needed.\n");

	/*
	 *	Now sort the bin entries for faster look up
	 */
	switch(msgtype)
	{
	case ISS_REC:
		qsort((struct IssuerProfile *)pMemoryBuf, key_count, size, iss_profile_cmp);
		break;
	case ACQ_REC:
		qsort((struct AcquirerProfile *)pMemoryBuf, key_count, size, acq_profile_cmp);
		break;
	case INST_REC:
		qsort((struct InstitutionProfileShm *)pMemoryBuf, key_count, size, inst_profile_cmp);
		break;
	}

	dbm_close_all(getpid());
	
			/* 	R022481 >> */
	
	if (msgtype == INST_REC)
	{
		//Copy balInfo and status from existing entries
		struct	InstitutionProfileShm *p=(struct	InstitutionProfileShm *)pMemoryBuf;
		struct	InstitutionProfileShm *pold=(struct	InstitutionProfileShm *)pApplicationKey;
		
		for (i=0;i<keyp->nkeys;i++)
		{
			if ( p[i].balInfo[0] == 1)
			{
				memcpy(p[i].balInfo, pold[p[i].balInfo[1]].balInfo, sizeof(p[i].balInfo));
				p[i].status = pold[p[i].balInfo[1]].status;
			}
		}
	}

	memcpy((char *)pApplicationKey, (char *)pMemoryBuf, keyp->nkeys * size);
		
	rm_appUnlockMemory(appid);
	OTraceDebug("D-SHC-139027.2: Unlocked rm.appid[%d]\n", appid);
			/* 	R022481 << */
	
	keyp->keysused = key_count;
	return( 0 );
}

/* Dump the record. This only works when shcinitprofiles.debug is 'Y' */
int dump_record()
{
	int	i;
	struct rules_keytab *keyp;
	struct	IssuerProfile 	*pMemoryIssProfile = NULL;
	struct	AcquirerProfile 	*pMemoryAcqProfile = NULL;
	struct	InstitutionProfileShm *pMemoryInstProfile = NULL;
	char *pApplicationKey;

	initSys(tableName);

	if ( rm_attach( appid, RULES_VER_CURRENT) != 0)
	{
		OTraceError("E-SHC-139057: Unable to attach to CURRENT version \n");
		return(-1);
	}

	if((pApplicationKey = rm_getappkey(appid)) == NULL)
		log_msg(FATAL, TO_CC, "F-SHC-139029:couldn't locate the shared memory for %s!\n",argv[RULES_PARM_RULENAME]);
	
	switch(msgtype)
	{
	case ISS_REC:
		pMemoryIssProfile = (struct IssuerProfile *)pApplicationKey;
		break;
	case ACQ_REC:
		pMemoryAcqProfile = (struct AcquirerProfile *)pApplicationKey;
		break;
	case INST_REC:
		pMemoryInstProfile = (struct InstitutionProfileShm *)pApplicationKey;
		break;
	}
	

	keyp = rm_getapphead(appid);

	char *p= (char *)pApplicationKey;

	for(i = 0;i<keyp->keysused; ++i, p+=keyp->keysize)
	{
		switch(msgtype)
		{
			case ISS_REC:
					pMemoryIssProfile = (struct IssuerProfile *)p;
					OTraceDebug("D-SHC-139030:[%s][%s][%s][%s][%s][%s][%s][%c][%s][%s][%d][%s]\n",
						pMemoryIssProfile->m_txnSrc, pMemoryIssProfile->m_txnDest, 
						pMemoryIssProfile->m_entityId,
						pMemoryIssProfile->m_cardProduct, 
						pMemoryIssProfile->m_msgType, pMemoryIssProfile->m_deviceType, pMemoryIssProfile->m_pcode, 
						(pMemoryIssProfile->m_hasPIN == '\0'?'.':pMemoryIssProfile->m_hasPIN), 
						pMemoryIssProfile->m_bin, pMemoryIssProfile->m_routing_bin, (int)pMemoryIssProfile->m_priority,
						pMemoryIssProfile->m_addCondition);

				break;
			case ACQ_REC:
					pMemoryAcqProfile = (struct AcquirerProfile *)p;
				OTraceDebug("[%s][%s][%s][%s][%s][%s][%s][%d]\n",
						pMemoryAcqProfile->m_txnSrc, pMemoryAcqProfile->m_txnDest, pMemoryAcqProfile->m_entityId, 
						pMemoryAcqProfile->m_currencyCode, pMemoryAcqProfile->m_deviceType, 
						pMemoryAcqProfile->m_bin, pMemoryAcqProfile->m_alternateBin, pMemoryAcqProfile->m_priority);
			break;
		case INST_REC:
				pMemoryInstProfile = (struct InstitutionProfileShm *)p;
				OTraceDebug("D-SHC-139031:[%s][%s][%s][%s][%s][%s][%s][%s][%s][%d][%c][%d][%d][%s][%s][%s]\n",
						pMemoryInstProfile->m_txnSrc, 
						pMemoryInstProfile->m_txnDest, pMemoryInstProfile->m_iss_entityId,
						pMemoryInstProfile->m_msgType,
						pMemoryInstProfile->m_externalId, pMemoryInstProfile->m_externalIdDesc,
						pMemoryInstProfile->m_member_ID, pMemoryInstProfile->m_F_ID,
						pMemoryInstProfile->m_bin, 
						pMemoryInstProfile->m_priority, 
						pMemoryInstProfile->status?pMemoryInstProfile->status:' ', 
						pMemoryInstProfile->keyparm,
						pMemoryInstProfile->id,
						pMemoryInstProfile->instId,
						pMemoryInstProfile->keyparamStr,
						pMemoryInstProfile->binrouteGroup);
				OTraceHexDump((unsigned char *)pMemoryInstProfile->balInfo, sizeof(pMemoryInstProfile->balInfo));

			break;
		}
	}
	return( 0 );
}

int dump_keys()
{
	static	struct rules_keytab *sec_keyp = NULL;	
	int i;
	char *pApplicationText;
	struct  shcsecurity            *pMemorySecurity=NULL;

	if (shc_initsys() < 0)
	{
		OTraceDebug("D-SHC-139031.1: INITSYS Failed : Error: %d\n", errno);
		pexit(1);
	}
	if ( rm_attach( shcSecurityAppid, RULES_VER_CURRENT) != 0)
	{
		 OTraceError("E-SHC-139031.2: Unable to attach to CURRENT version \n");
		  return(-1);
	}

	if(sec_keyp == NULL)
		if((sec_keyp = rm_getapphead(shcSecurityAppid)) == NULL)
		{
			printf("Can't find security rule, keys cannot be displayed\n");
			return(-1);
		}

	if((pApplicationText = rm_getapptext(shcSecurityAppid)) == NULL)
		log_msg(FATAL, TO_CC, "F-SHC-139031.3:couldn't locate the shared memory for %s!\n",argv[RULES_PARM_RULENAME]);

	pMemorySecurity = (struct shcsecurity*)pApplicationText;

	OTraceDebug("D-SHC-139031.4: Displaying key info:\n");
	for(i = 0; i < sec_keyp->textused; ++i)
	{
		OTraceDebug("D-SHC-139031.5: InstId[%s]ubinid[%s]bin[%s]ktype[%c]KEK[%s]KEK_LEN[%d]\n",
							pMemorySecurity[i].k.institutionid, pMemorySecurity[i].k.userbinid,
							pMemorySecurity[i].k.bin,		pMemorySecurity[i].k.keytypes,
							pMemorySecurity[i].k.kek,		pMemorySecurity[i].k.kek_len);
	}
	printf("No. of records displayed [%d]\n", i);
	OTraceDebug("D-SHC-139031.6: No. of records displayed [%d]\n", i);
	return (0);
}
int initCfg()
{
	char buf[80];
	long i;
	
	if(cf_open("files/shc.cfg") < 0)
		log_msg(FATAL, TO_CC, "F-SHC-139032:Unable to open config:\n");
		
	cf_close();	
	return 0;
}

int initSys(const char *tableName)
{
	if (dbm_init() == -1)
	{
		OTraceDebug("F-SHC-139033: Unable to connect to DB Manager : Error: %d\n",
		    errno);
		pexit(1);
	}

	if (rm_init() < 0)
	{
		OTraceDebug("F-SHC-139034: Unable to connect to RuleManager : Error: %d\n",
		    errno);
		pexit(1);
	}

	/* Get pin and key pointers */

	if (shc_initsys() < 0)
	{
		OTraceDebug("P-SHC-139035: INITSYS Failed : Error: %d\n", errno);
		pexit(1);
	}

	/* open using status field as index */
	if( (fd = dbm_open(dbm_getfirstindex(tableName), getpid())) < 0 )
	{
		OTraceDebug("F-SHC-139036: Unable to open '%s' table\n", tableName);
		pexit(1);
	}
	call_dbm_init = 1;
	return(0);
}

int pexit(int n)
{
	HaPtmCctHelper::cleanUp() ;
	OTraceOff();
	return(n);
}
