/* @(#) %M% %I% %E% %U% */
/* Which cpu, vendor and OS is this */
#define TARGET 0

/* Byte order */
#undef WORDS_BIGENDIAN

/* Structures, globals, declarations and types */
#undef GETTOD_NOT_DECLARED
#undef HAVE_TM_TZADJ
#undef HAVE_TM_GMTOFF
#undef HAVE_TIMEZONE_VAR
#undef USE_DELTA_FOR_TZ
#undef HAVE_ST_BLOCKSIZE
#undef GETTOD_NOT_DECLARED
#undef __CHAR_UNSIGNED__
#undef HAVE_SIGNED_CHAR

/* Shared libraries and dynamic link loader */
#undef HAVE_DLFCN_H
#undef HAVE_DL_H
#undef HAVE_DLL_H

/* If defined, the function is not available in system libraries */
#undef NO_GETCWD
#undef NO_STRERROR
#undef NO_GETED
#undef NO_WAIT3
#undef NO_UNAME
#undef NO_GETTOD

/* If defined, the function is available from the system libs */
#undef HAVE_BSDGETTIMEOFDAY
#undef HAVE_STPCHR
#undef HAVE_STPCPY
#undef HAVE_GETHOSTNAME
#undef HAVE_STRICMP
#undef HAVE_STRNICMP
#undef HAVE_MEMMOVE

/* If defined, the system header is not available or is broken */
#undef NO_DIRENT_H
#undef NO_ERRNO_H
#undef NO_FLOAT_H
#undef NO_VALUES_H
#undef NO_LIMITS_H
#undef NO_STDLIB_H
#undef NO_SYS_WAIT_H

/* If defined, we have the header */
/* #undef HAVE_UNISTD_H */
#undef HAVE_SYS_SELECT_H
#undef HAVE_SYS_TIME_H
#undef HAVE_SYS_IOCTL_H
#undef HAVE_NET_ERRNO_H

/* tty (serial port) model */
#undef USE_TERMIOS
#undef USE_TERMIO
#undef USE_SGTTY

/* Broken system calls, libc functions or structures */
#undef NO_STRSTR
#undef NO_STRTOUL
#undef NO_STRTOD
#undef NO_UNION_WAIT


#ifndef HAVE_STRUCT_SEMUN
#undef HAVE_STRUCT_SEMUN
#endif

#ifndef NO_FD_SET
#undef NO_FD_SET
#endif

#ifndef NO_GETWD
#undef NO_GETWD
#endif

#ifndef NO_STRING_H
#undef NO_STRING_H
#endif

#ifndef RTLD_GLOBAL
#undef RTLD_GLOBAL
#endif

#ifndef RTLD_LAZY
#undef RTLD_LAZY
#endif

#ifndef RTLD_NOW
#undef RTLD_NOW
#endif

#ifndef HAVE_INFORMIX
#undef HAVE_INFORMIX
#endif

#ifndef HAVE_ORACLE
#undef HAVE_ORACLE
#endif

#ifndef HAVE_SYBASE
#undef HAVE_SYBASE
#endif

#ifndef HAVE_DB2
#undef HAVE_DB2
#endif

/* wchar_t is defined and istream support wchar_t */
#undef HAVE_WCHAR_IN_IOSTREAM

/* dynamic_cast<> is supported */
#undef USE_DYNAMIC_CAST 

/* _iob[] or __iob[] is defined in stdio.h */
#undef HAVE_ARRAY_IOB 

/* The SA_RESTART bit of SIGUSR1 is ON by default */
#undef HAVE_SIGUSR1_SA_RESTART

/* Hi-Res timer support, the one list first has higher prioity */
#undef USE_CLOCK_GETTIME
#undef USE_GETCLOCK
#undef USE_TIMER_GETTIME
#undef USE_FTIME

#undef USE_CLOCK_GETRES

#undef HAVE_64BIT_LONG
#undef HAVE_64BIT_LONG_LONG
#undef HAVE_STATIC_CONST_STDOUT

#undef HAVE_ULONG
#undef HAVE_MSG_CBYTES

#undef USE_NANOSLEEP
#undef USE_USLEEP
#undef USE_SETITIMER

/* Which termio family is used by curses.h */
#undef HAVE_TERMIO_IN_CURSES_H
#undef HAVE_TERMIOS_IN_CURSES_H

/* Member msg_accright is in struct msghdr */
/* Default is have member msg_control */
#undef HAVE_accrights_IN_msghdr

/* whether the compiler support keyword mutable */
#undef USE_MUTABLE

/* whether the machine speak EBCDIC natively */
#undef USE_EBCDIC

/* whether tzfile.h defines isleap() */
#undef HAVE_ISLEAP_IN_TZFILE_H

/* whether stderror() is defined (in string.h) */
#undef HAVE_STRERROR

/* whether wctype.h present */
#undef HAVE_WCTYPE_H

/* whether strings.h present */
#undef HAVE_STRINGS_H

/* whether strcasecmp() is defined in strings.h by default */
#undef NO_STRCASECMP_IN_STRINGS_H

/* whether class template can be explicitly instaniated */
#undef HAVE_X_CLS_TMPL_INSTANTIATION

/* whether class ostream defines member class sentry */
#undef HAVE_SENTRY_IN_OSTREAM

/* thread specific macros */
#undef HAVE_SEMAPHORE_H
#undef HAVE_POSIX_SEMAPHORE
#undef HAVE_SYNCH_H
#undef HAVE_THREAD_H
#undef HAVE_PTHREAD_H
#undef HAVE_PTHREAD_ATTR_INIT
#undef HAVE_PTHREAD_ATTR_DEFAULT
#undef HAVE_PTHREAD_MUTEXATTR_DEFAULT
#undef HAVE_PTHREAD_CONDATTR_DEFAULT
#undef HAVE_PTHREAD_ADDR_T
#undef HAVE_PTHREAD_MUTEXATTR_SETTYPE
#undef HAVE_PTHREAD_MUTEXATTR_SETKIND_NP
#undef HAVE_PTHREAD_KEY_CREATE
#undef HAVE_PTHREAD_KEYCREATE
#undef HAVE_PTHREAD_KEY_DELETE
#undef HAVE_PTHREAD_RWLOCK
#undef HAVE_PTHREAD_KILL
#undef HAVE_PTHREAD_SIGMASK
#undef UNARY_PTHREAD_GETSPECIFIC
#undef PTHREAD_DETACH_USE_VALUE
#undef PTHREAD_USE_ATTR_ADDRESS
#undef HAVE_THREAD_EXCEPTION_HANDLE
#undef IS_SELECT_CANCEL_POINT
#undef HAVE_PTHREAD_TESTCANCEL
#undef HAVE_LOCALTIME_T

/* whether the C+ compiler has the conversion operator lookup bug (HP) */
#undef HAS_CONV_OPERATOR_LOOKUP_BUG

/* whether license checking is enabled */
#undef MB_LICENSE_CHECK

#undef STD_CLASS_PREFIX
#undef GETSOCKETOPT_ACCEPT_SOCKLEN
