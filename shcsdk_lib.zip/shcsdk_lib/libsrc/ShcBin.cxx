static char _ShcBin_cxx_what[] = "@(#) ShcBin.cxx 1.34.7.7 20/05/15 14:17:14";

/*
 *  Copyright (C) 2004 eFunds Corporation ("eFunds").  All Rights Reserved.
 *  eFunds Canada Corporation is an authorized user.
 *
 *  IST is a registered trademark of eFunds Corporation.  Other brand or
 *  product names are trademarks or registered trademarks of their respective
 *  holders.
 *
 *  The information contained herein is the unpublished proprietary property
 *  of eFunds.  Except as specifically authorized in writing by eFunds, the
 *  holder of this document shall: i) keep all information contained herein
 *  confidential, and ii) protect the information, in whole or in part, from
 *  disclosure and dissemination to all third parties.
 *
 *  This document and the software described in it are furnished under license
 *  and may be used or copied only in accordance with the terms of such license.
 *  This document is supplied for information purposes only, is subject to
 *  change without notice, and should not be construed as a commitment by
 *  either eFunds Corporation or eFunds Canada Corporation.
 *
 *
 *
 *                        MODIFICATION HISTORY                  REVIEW
 *
 *	SPR#	Who	Date	Description			Who	Date
 * ===========================================================================
 * R014598 jyang 31Aug05 leave flag SH_REPLAY alone
 * R016305 Emj 20Apr06 Log actual response code in security log
 * R016654 Emj 19Jun06 Fixed debug info to print correct BIN
 * R016871 spa 06Jul06 Modified ShcBin::setInstUp for saf interleave support
 * R016871 pve 07Jul06 Correct the circular dependency problem
 * R016347 Emj 01May06 Updated functions to use key and pin pointers 
 * R017808 emj 22Sep06 Broadcast change of shckeys to other nodes
 * R019505 pve 10Apr07 Set newlyFoundShcBinKey in shc_locate_bin(..)
 *R022481 jyang 29Jan08 Supported for locking shared memory of rules
 * R026021 sel 18Feb09 Key Sync change; modified broadcast fn call
 * R029171 Emj 03Mar11 Use Institutionid and userbinid for shckeys table
 * R031154 Dipa 21Dec12 Clone of R030931
 */

//File Number 22

#include <rules.h>
#include <shc.h>
#include <shcdef.h>
#include <shcextbuf.h>
#include <security.h>
#include <ic/ic_instid.h>
#include <ic/ic_bin.h>
#include <rules.h>
#include <osysinfo.h>
#include <BinRoute.h>

#include <ShcSdkCommon.h>
#include <ShcmsgHeader.h>
#include <ShcBin.h>
#include <ShcAppBase.h>

#include <ShckeyParamsList.h>
#include <ShcKeyHelper.h>
#include <ShcDKEHelper.h>
#include <ShcMacHelper.h>
#include <ShcmsgHelper.h>
#include <ShcSafIOHelper.h>	//	---	R016871
#include <ShcHelper.h>
#include <UpdateMemHelper.h>
#include <ShcSharedMemoryHelper.h>
#include <istsafe.h>

#include <ist_seg_name.h>
#include <ist_seg_elf_id_map.h>
#include <ist_seg_id.h>
#include <ist_seg_msg_replication_data.h>
#include <ShcAsynchApi.h>

static	struct rules_keytab *pShcAppHead = NULL;

static int shcUseDefaulKeyIdx = 0;
int shcUseDefaultKeyIndex();

int ShcBin::shc_keys_set_pointers( struct shckey_buf *bufp )
{
	bufp->akeyp = bufp->achkp = bufp->astatp = NULL;
	bufp->ikeyp = bufp->ichkp = bufp->istatp = NULL;

	short nxt_aidxp,nxt_iidxp;
	/* Set index pointers to shared memory */
	switch( bufp->type )
	{
		case SH_KEYTYPE_PIN:
			bufp->aidxp = &bufp->keyp->k.acqpinidx;
			bufp->iidxp = &bufp->keyp->k.isspinidx;
			strcpy(bufp->ctype, "PIN");
			break;

		case SH_KEYTYPE_MAC:
			bufp->aidxp = &bufp->keyp->k.acqmacidx;
			bufp->iidxp = &bufp->keyp->k.issmacidx;
			strcpy(bufp->ctype, "MAC");
			break;

		case SH_KEYTYPE_KME:
			bufp->aidxp = &bufp->keyp->k.acqkmeidx;
			bufp->iidxp = &bufp->keyp->k.isskmeidx;
			strcpy(bufp->ctype, "KME");
			break;
	}


	/* Set key pointers to shared memory */
	if( shcChangeAcqKeys(bufp->key_class) )
	{
	//	*bufp->aidxp = bufp->index - '0';	//This seems a bug, not HA change for now
		nxt_aidxp = bufp->index - '0';
		OTraceDebug("D-SHC-022044: shc_keys_set_pointers AcqKeys next index [%d]\n", nxt_aidxp);

		switch( bufp->type )
		{
			case SH_KEYTYPE_PIN:	/* Acquirer PIN keys */
				switch( nxt_aidxp )
				{
					case 1:
						bufp->akeyp = bufp->keyp->k.acqpin1;
						bufp->achkp = bufp->keyp->k.acqpin1chk;
						bufp->astatp = &bufp->keyp->k.acqpin1stat;
						bufp->acntp = &bufp->keyp->k.acqpin1cnt[0];
						break;

					case 2:
						bufp->akeyp = bufp->keyp->k.acqpin2;
						bufp->achkp = bufp->keyp->k.acqpin2chk;
						bufp->astatp = &bufp->keyp->k.acqpin2stat;
						bufp->acntp = &bufp->keyp->k.acqpin2cnt[0];
						break;

					case 3:
						bufp->akeyp = bufp->keyp->k.acqpin3;
						bufp->achkp = bufp->keyp->k.acqpin3chk;
						bufp->astatp = &bufp->keyp->k.acqpin3stat;
						bufp->acntp = &bufp->keyp->k.acqpin3cnt[0];
						break;
				}
				break;

			case SH_KEYTYPE_MAC:	/* Acquirer MAC keys */
				switch( nxt_aidxp )
				{
					case 1:
						bufp->akeyp = bufp->keyp->k.acqmac1;
						bufp->achkp = bufp->keyp->k.acqmac1chk;
						bufp->astatp = &bufp->keyp->k.acqmac1stat;
						break;

					case 2:
						bufp->akeyp = bufp->keyp->k.acqmac2;
						bufp->achkp = bufp->keyp->k.acqmac2chk;
						bufp->astatp = &bufp->keyp->k.acqmac2stat;
						break;

					case 3:
						bufp->akeyp = bufp->keyp->k.acqmac3;
						bufp->achkp = bufp->keyp->k.acqmac3chk;
						bufp->astatp = &bufp->keyp->k.acqmac3stat;
						break;
				}
				break;

			case SH_KEYTYPE_KME:	/* Acquirer KME keys */
				switch( nxt_aidxp )
				{
					case 1:
						bufp->akeyp = bufp->keyp->k.acqkme1;
						bufp->achkp = bufp->keyp->k.acqkme1chk;
						bufp->astatp = &bufp->keyp->k.acqkme1stat;
						break;

					case 2:
						bufp->akeyp = bufp->keyp->k.acqkme2;
						bufp->achkp = bufp->keyp->k.acqkme2chk;
						bufp->astatp = &bufp->keyp->k.acqkme2stat;
						break;

					case 3:
						bufp->akeyp = bufp->keyp->k.acqkme3;
						bufp->achkp = bufp->keyp->k.acqkme3chk;
						bufp->astatp = &bufp->keyp->k.acqkme3stat;
						break;
				}
				break;
		}
	}

	if( shcChangeIssKeys(bufp->key_class) )
	{
		//*bufp->iidxp = bufp->index - '0';//This seems a bug, not HA change for now
		nxt_iidxp = bufp->index - '0';
		OTraceDebug("D-SHC-022045: shc_keys_set_pointers IssKeys next index [%d]\n", nxt_iidxp);

		switch( bufp->type )
		{
			case SH_KEYTYPE_PIN:	/* Acquirer PIN keys */
				switch( nxt_iidxp )
				{
					case 1:
						bufp->ikeyp = bufp->keyp->k.isspin1;
						bufp->ichkp = bufp->keyp->k.isspin1chk;
						bufp->istatp = &bufp->keyp->k.isspin1stat;
						bufp->acntp = &bufp->keyp->k.isspin1cnt[0];
						break;

					case 2:
						bufp->ikeyp = bufp->keyp->k.isspin2;
						bufp->ichkp = bufp->keyp->k.isspin2chk;
						bufp->istatp = &bufp->keyp->k.isspin2stat;
						bufp->acntp = &bufp->keyp->k.isspin2cnt[0];
						break;

					case 3:
						bufp->ikeyp = bufp->keyp->k.isspin3;
						bufp->ichkp = bufp->keyp->k.isspin3chk;
						bufp->istatp = &bufp->keyp->k.isspin3stat;
						bufp->acntp = &bufp->keyp->k.isspin2cnt[0];
						break;
				}
				break;

			case SH_KEYTYPE_MAC:	/* Acquirer MAC keys */
				switch( nxt_iidxp )
				{
					case 1:
						bufp->ikeyp = bufp->keyp->k.issmac1;
						bufp->ichkp = bufp->keyp->k.issmac1chk;
						bufp->istatp = &bufp->keyp->k.issmac1stat;
						break;

					case 2:
						bufp->ikeyp = bufp->keyp->k.issmac2;
						bufp->ichkp = bufp->keyp->k.issmac2chk;
						bufp->istatp = &bufp->keyp->k.issmac2stat;
						break;

					case 3:
						bufp->ikeyp = bufp->keyp->k.issmac3;
						bufp->ichkp = bufp->keyp->k.issmac3chk;
						bufp->istatp = &bufp->keyp->k.issmac3stat;
						break;
				}
				break;

			case SH_KEYTYPE_KME:	/* Acquirer MAC keys */
				switch( nxt_iidxp )
				{
					case 1:
						bufp->ikeyp = bufp->keyp->k.isskme1;
						bufp->ichkp = bufp->keyp->k.isskme1chk;
						bufp->istatp = &bufp->keyp->k.isskme1stat;
						break;

					case 2:
						bufp->ikeyp = bufp->keyp->k.isskme2;
						bufp->ichkp = bufp->keyp->k.isskme2chk;
						bufp->istatp = &bufp->keyp->k.isskme2stat;
						break;

					case 3:
						bufp->ikeyp = bufp->keyp->k.isskme3;
						bufp->ichkp = bufp->keyp->k.isskme3chk;
						bufp->istatp = &bufp->keyp->k.isskme3stat;
						break;
				}
				break;
		}
	}

	return( 0 );
}

int ShcBin::shcnet_keys_init( ShcmsgHeader *header, struct shckey_buf *bufp)
{
	int ret = SHC_RC_Approved;

	if( ! bufp->keyp )
	{
		if( ! (binPkg->bin.bintype & SH_USES_KEYS) )
		{
			header->msg.respcode = SHC_RC_FunctionNotAvailable;
			OTraceError("E-SHC-022001: Network keys not configured for this bin\n");
			return( -1 );
		}


   		if( !key )
   		{
       		OTraceFatal("F-SHC-022002: Attempting to accept keys for %s. No key parms.\n", header->msg.issuer);
       		header->msg.respcode = SHC_RC_SystemError;
       		return( -1 );
   		}
    	bufp->keyp = key; 
	}

	/*
	 * R001283
	 */
	{
		char keytype = header->msg.format_code[1];
		char keyidx;

		switch(keytype)
		{
			case	'P': keyidx = header->msg.pin_index; break;
			case	'M': keyidx = header->msg.mac_index; break;
			default	   : keyidx = header->msg.pin_index; break;

		}

    	ret = shcApp->shcKeyObj->shc_keys_init_buf(bufp, header->msg.format_code[0],
			                    keytype, keyidx);
	}

	if( ret != SHC_RC_Approved )
	{
		header->msg.respcode = ret;
		return( -1 );
	}

        switch(header->msg.format_code[1])
        {
        case SH_KEYTYPE_MAC:
                memcpy(header->msg.acquirer_data, bufp->keyp->k.acqmac1chk, 4);
                memcpy(header->msg.acquirer_data+4, bufp->keyp->k.acqmac2chk, 4);
                memcpy(header->msg.acquirer_data+8, bufp->keyp->k.acqmac3chk, 4);
                memcpy(header->msg.issuer_data, bufp->keyp->k.issmac1chk, 4);
                memcpy(header->msg.issuer_data+4, bufp->keyp->k.issmac2chk, 4);
                memcpy(header->msg.issuer_data+8, bufp->keyp->k.issmac3chk, 4);
                break;
        case SH_KEYTYPE_PIN:
                memcpy(header->msg.acquirer_data, bufp->keyp->k.acqpin1chk, 4);
                memcpy(header->msg.acquirer_data+4, bufp->keyp->k.acqpin2chk, 4);
                memcpy(header->msg.acquirer_data+8, bufp->keyp->k.acqpin3chk, 4);
                memcpy(header->msg.issuer_data, bufp->keyp->k.isspin1chk, 4);
                memcpy(header->msg.issuer_data+4, bufp->keyp->k.isspin2chk, 4);
                memcpy(header->msg.issuer_data+8, bufp->keyp->k.isspin3chk, 4);
        }
        memcpy(header->msg.acceptorname, bufp->keyp->k.flags, sizeof(bufp->keyp->k.flags));

    return( 0 );
}

void ShcBin::shckeys_setindex_ptr(struct shckey_buf *bufp )
{

	bufp->keklen = &bufp->keyp->k.kek_len;

	/* Set index pointers to shared memory */
	switch( bufp->type )
	{
		case SH_KEYTYPE_PIN:
			if( bufp->key_class == SH_KEYTYPE_PIN_ISS )
			{
				bufp->aidxp = &bufp->keyp->k.isspinidx;
				bufp->akeylen = &bufp->keyp->k.isskpe_len;
			}
			else
			{
				bufp->aidxp = &bufp->keyp->k.acqpinidx;
				bufp->akeylen = &bufp->keyp->k.acqkpe_len;
			}
			break;

		case SH_KEYTYPE_KME:
			if( bufp->key_class == SH_KEYTYPE_PIN_ISS )
			{
				bufp->aidxp = &bufp->keyp->k.isskmeidx;
				bufp->akeylen = &bufp->keyp->k.isskme_len;
			}
			else
			{
				bufp->aidxp = &bufp->keyp->k.acqkmeidx;
				bufp->akeylen = &bufp->keyp->k.acqkme_len;
			}
			break;

		case SH_KEYTYPE_MAC:
			if( bufp->key_class == SH_KEYTYPE_PIN_ISS )
			{
				bufp->aidxp = &bufp->keyp->k.issmacidx;
				bufp->akeylen = &bufp->keyp->k.issmac_len;
			}
			else
			{
				bufp->aidxp = &bufp->keyp->k.acqmacidx;
				bufp->akeylen = &bufp->keyp->k.acqmac_len;

			}
			break;
	}
}



void ShcBin::shckeys_setkey_ptr(  struct shckey_buf *bufp, struct shcsecurity *secp,
			char key_class, char key_type, char key_index )
{
	/* Set key pointers to shared memory */
	if( key_class == SH_KEYTYPE_PIN_ISS )
	{
		switch( key_type )
		{
			case SH_KEYTYPE_PIN:	/* Acquirer PIN keys */
				switch( key_index )							/* R000587 */
				{
					case '1':
						bufp->akeyp = secp->k.isspin1;
						bufp->achkp = secp->k.isspin1chk;
						bufp->astatp = &secp->k.isspin1stat;
						bufp->acntp = secp->k.isspin1cnt; /* R000587 */
						break;

					case '2':
						bufp->akeyp = secp->k.isspin2;
						bufp->achkp = secp->k.isspin2chk;
						bufp->astatp = &secp->k.isspin2stat;
						bufp->acntp = secp->k.isspin2cnt; /* R000587 */
						break;

					case '3':
						bufp->akeyp = secp->k.isspin3;
						bufp->achkp = secp->k.isspin3chk;
						bufp->astatp = &secp->k.isspin3stat;
						bufp->acntp = secp->k.isspin3cnt; /* R000587 */
						break;
				}
				break;

			case SH_KEYTYPE_KME:	/* Acquirer MAC keys */
				switch( key_index )							/* R000587 */
				{
					case '1':
						bufp->akeyp = secp->k.isskme1;
						bufp->achkp = secp->k.isskme1chk;
						bufp->astatp = &secp->k.isskme1stat;
						bufp->acntp = secp->k.isskme1cnt; /* R000587 */
						break;

					case '2':
						bufp->akeyp = secp->k.isskme2;
						bufp->achkp = secp->k.isskme2chk;
						bufp->astatp = &secp->k.isskme2stat;
						bufp->acntp = secp->k.isskme2cnt; /* R000587 */
						break;

					case '3':
						bufp->akeyp = secp->k.isskme3;
						bufp->achkp = secp->k.isskme3chk;
						bufp->astatp = &secp->k.isskme3stat;
						bufp->acntp = secp->k.isskme3cnt; /* R000587 */
						break;
				}
				break;

			case SH_KEYTYPE_MAC:	/* Acquirer MAC keys */
				switch( key_index )							/* R000587 */
				{
					case '1':
						bufp->akeyp = secp->k.issmac1;
						bufp->achkp = secp->k.issmac1chk;
						bufp->astatp = &secp->k.issmac1stat;
						bufp->acntp = secp->k.issmac1cnt; /* R000587 */
						break;

					case '2':
						bufp->akeyp = secp->k.issmac2;
						bufp->achkp = secp->k.issmac2chk;
						bufp->astatp = &secp->k.issmac2stat;
						bufp->acntp = secp->k.issmac2cnt; /* R000587 */
						break;

					case '3':
						bufp->akeyp = secp->k.issmac3;
						bufp->achkp = secp->k.issmac3chk;
						bufp->astatp = &secp->k.issmac3stat;
						bufp->acntp = secp->k.issmac3cnt; /* R000587 */
						break;
				}
				break;
		}
	}
	else
	{
		switch( key_type )
		{
			case SH_KEYTYPE_PIN:	/* Acquirer PIN keys */
				switch( key_index )							/* R000587 */
				{
					case '1':
						bufp->akeyp = secp->k.acqpin1;
						bufp->achkp = secp->k.acqpin1chk;
						bufp->astatp = &secp->k.acqpin1stat;
						bufp->acntp = secp->k.acqpin1cnt; /* R000587 */
						break;

					case '2':
						bufp->akeyp = secp->k.acqpin2;
						bufp->achkp = secp->k.acqpin2chk;
						bufp->astatp = &secp->k.acqpin2stat;
						bufp->acntp = secp->k.acqpin2cnt; /* R000587 */
						break;

					case '3':
						bufp->akeyp = secp->k.acqpin3;
						bufp->achkp = secp->k.acqpin3chk;
						bufp->astatp = &secp->k.acqpin3stat;
						bufp->acntp = secp->k.acqpin3cnt; /* R000587 */
						break;
				}
				break;

			case SH_KEYTYPE_KME:	/* Acquirer KME keys */
				switch( key_index )							/* R000587 */
				{
					case '1':
						bufp->akeyp = secp->k.acqkme1;
						bufp->achkp = secp->k.acqkme1chk;
						bufp->astatp = &secp->k.acqkme1stat;
						bufp->acntp = secp->k.acqkme1cnt; /* R000587 */
						break;

					case '2':
						bufp->akeyp = secp->k.acqkme2;
						bufp->achkp = secp->k.acqkme2chk;
						bufp->astatp = &secp->k.acqkme2stat;
						bufp->acntp = secp->k.acqkme2cnt; /* R000587 */
						break;

					case '3':
						bufp->akeyp = secp->k.acqkme3;
						bufp->achkp = secp->k.acqkme3chk;
						bufp->astatp = &secp->k.acqkme3stat;
						bufp->acntp = secp->k.acqkme3cnt; /* R000587 */
						break;
				}
				break;

			case SH_KEYTYPE_MAC:	/* Acquirer MAC keys */
				switch( key_index )							/* R000587 */
				{
					case '1':
						bufp->akeyp = secp->k.acqmac1;
						bufp->achkp = secp->k.acqmac1chk;
						bufp->astatp = &secp->k.acqmac1stat;
						bufp->acntp = secp->k.acqmac1cnt; /* R000587 */
						break;

					case '2':
						bufp->akeyp = secp->k.acqmac2;
						bufp->achkp = secp->k.acqmac2chk;
						bufp->astatp = &secp->k.acqmac2stat;
						bufp->acntp = secp->k.acqmac2cnt; /* R000587 */
						break;

					case '3':
						bufp->akeyp = secp->k.acqmac3;
						bufp->achkp = secp->k.acqmac3chk;
						bufp->astatp = &secp->k.acqmac3stat;
						bufp->acntp = secp->k.acqmac3cnt; /* R000587 */
						break;
				}
				break;

		}
	}
}

int ShcBin::shckeys_setpkg( struct shckey_buf *bufp)
{

	if( ! (binPkg->bin.bintype & SH_USES_KEYS) || !key )
	{
		OTraceDebug("D-SHC-022003: shckeys_setpkg():Keys not configured for bin '%s'\n",
						binPkg->bin.networkid);
		return( -1 );
	}

   	bufp->keyp = key;

	return( 0 );
}

int ShcBin::shckeys_setclass( struct shckey_buf *bufp, char key_class )
{
	switch( key_class )
	{
		case SH_KEYTYPE_PIN_ACQ:
		case SH_KEYTYPE_PIN_ISS:
			bufp->key_class = key_class;
			break;

		default:
			char tmpKeyClass = shcApp->shckeyParamsList->getShccfg()->def_class;
			if( tmpKeyClass == 'N' )
			{
				OTraceFatal("F-SHC-022004: shcckeys_setclass():Invalid value '%d'\n",
						key_class);
				return( -1 );
			}

			bufp->key_class = tmpKeyClass;
			break;
	}


	return( 0 );
}

int ShcBin::shckeys_settype(struct shckey_buf *bufp, char key_type )
{
	/* Determine key index */
	switch( key_type )
	{
		case SH_KEYTYPE_PIN:
			bufp->type = key_type;
			strcpy(bufp->ctype, "PIN");
			break;

		case SH_KEYTYPE_KME:
			bufp->type = key_type;
			strcpy(bufp->ctype, "KME");
			break;

		case SH_KEYTYPE_MAC:
			bufp->type = key_type;
			strcpy(bufp->ctype, "MAC");
			break;

		default:
			OTraceFatal("F-SHC-022005: shckeys_settype():Invalid value '%d'\n",
					key_type);
			return( -1 );
	}

	return( 0 );
}

int ShcBin::shckeys_getindex_next(struct shckey_buf *bufp, char *key_index )
{
	OTraceDebug("D-SHC-022006:Current Index '%c'\n", *key_index);
	*key_index = *key_index + 1;
	OTraceDebug("D-SHC-022007:Next Index '%c'\n", *key_index);
	if( *key_index > bufp->keyp->k.flags[1] )
		*key_index = '1';
	OTraceDebug("D-SHC-022008:Index '%c'  max = '%c'\n", *key_index, bufp->keyp->k.flags[1]);

	return( 0 );
}

char ShcBin::shckeys_getindex(struct shckey_buf *bufp, char key_index )
{
	char	idx = '0';

	switch( key_index )
	{
		case SH_KEYIDX_CURRENT:
			idx = (char)(*bufp->aidxp + '0');
			break;

		case SH_KEYIDX_NEXT:
			idx = (char)(*bufp->aidxp + '1');
			if( idx > bufp->keyp->k.flags[1] )
				idx = '1';
			break;

		case '1': case '2': case '3':
			idx = key_index;
			break;

		default:
			if((key_index=='\0') && shcUseDefaultKeyIndex())
			{
				idx = (char)(*bufp->aidxp + '0');
				OTraceDebug("D-SHC-001121 Use Default Key Index[%d]\n",idx);
			}
			else
			{
				OTraceFatal("F-SHC-022009: shckeys_getindex():Invalid value '%d'\n",
							key_index);
				return( '0' );
			}
	}

	if( idx < '1' || idx > '3' )
		return( '0' );

	return( idx );
}

int ShcBin::shckeys_setindex(struct shckey_buf *bufp, char key_index )
{
	shckeys_setindex_ptr(bufp);

	bufp->index = shckeys_getindex(bufp, key_index);

	if( bufp->index == '0' )
		return( -1 );

	OTraceDebug("D-SHC-022010:   Set buffer index %s.%s.%c%c: '%c'\n",
			bufp->keyp->k.institutionid, bufp->keyp->k.userbinid, bufp->key_class, bufp->type, bufp->index);

	return( 0 );
}

int ShcBin::shckeys_getkey( struct shckey_buf *bufp, char key_class, char key_type, char key_index )
{
	shcApp->shcKeyObj->shc_keys_init();

	memset((void *)bufp, 0, sizeof(struct shckey_buf));

	OTraceDebug("D-SHC-022011: Get key %s.%c%c%c\n", binPkg->bin.networkid,
			key_class, key_type, key_index);

	if( shckeys_setpkg(bufp) < 0
		|| shckeys_setclass(bufp, key_class) < 0
		|| shckeys_settype(bufp, key_type) < 0
		|| shckeys_setindex(bufp, key_index) < 0 )
		return( -1 );

	shckeys_setkey_ptr(bufp, bufp->keyp, bufp->key_class,
		bufp->type, bufp->index);

	OTraceDebug("D-SHC-022012:   Key    [%-16s]\n", bufp->akeyp);
	OTraceDebug("          :   Count  [%-20s]\n", bufp->acntp);
	OTraceDebug("          :   Status [%c]\n", *bufp->astatp);

	return( 1 );
}

/*
	Return Values:	1  - Key is invalid
					0  - OK
					-1 - Error
*/
int ShcBin::shckeys_GetKey(struct shckey_buf *bufp, char key_class, char key_type, char key_index )
{
	shcApp->shcKeyObj->shc_keys_init();	// R010416
	shcApp->shckeyParamsList = (ShckeyParamsList *)shcApp->shckeyParams.getInst(binPkg->bin.institutionid);
	if( shckeys_getkey(bufp, key_class, key_type, key_index) < 0 )
		return( -1 );

	if( strncmp(bufp->akeyp, "0000000000000000", IST_SECURITY_KEY_SZ) == 0
		|| *bufp->astatp == SH_KEYSTAT_INACTIVE )
		return( 1 );

	return( 0 );
}


int ShcBin::shckeys_UpdIndex(struct shckey_buf *bufp, char index )
{
	if( ! bufp->aidxp )
		return( -1 );

	shckeys_setindex(bufp, index);

	*bufp->aidxp = (int)(bufp->index - '0');	//Seems a bug


	return( 0 );
}

int ShcBin::shckeys_SetStatus(struct shckey_buf *bufp, char status )
{
	int isLocked = 0;
	if( ! bufp->astatp )
		return( -1 );

	OTraceDebug("D-SHC-022013:   Set status for key %s.%s.%c%c%c: '%c'\n",
			bufp->keyp->k.institutionid, bufp->keyp->k.userbinid, bufp->key_class, bufp->type, bufp->index,
			status);

	shcSharedMemoryHelperObj->lockRule(sharedCashSecurityRuleName, &isLocked, &shcSecurityAppid);

	if( status == SH_KEYSTAT_ACTIVE )
		*bufp->aidxp = (int)(bufp->index - '0');		//HA

	*bufp->astatp = status;		//HA

	shcSharedMemoryHelperObj->updateCurrentVersion(sharedCashSecurityRuleName, isLocked, 
				shcSecurityAppid, (char *)&bufp->keyp->k, sizeof(bufp->keyp->k));
	
	return( 0 );
}


/* R000587 */
int ShcBin::shckeys_GenerateKey(struct shckey_buf *bufp, char *k_kpe, char *k_chk )
{
	char	k_mfk[IST_SECURITY_KEY_SZ + 1] = {0};
	char	c_mfk[CHECK_DIGIT_LEN + 1] = {0};
	int isLocked = 0;

	int keyType = 0;
	int keylen = 0;
	char keyVer = 'A';
	int atalla_var = 0;
	keylen = *bufp->akeylen;

    shcApp->shckeyParamsList = (ShckeyParamsList *)shcApp->shckeyParams.getInst(bufp->keyp->k.institutionid);


	OTraceDebug("D-SHC-022015: Generating new key\n");
	OTraceDebug("          :  E(KEK)LMK: [%-16s]\n", bufp->keyp->k.kek);
	OTraceDebug("          :  E(key)KEK: [%-16s]\n", k_kpe);

	switch( bufp->type )
	{
		case SH_KEYTYPE_PIN:
			if((binPkg->bin.bin_cfg & SH_CFG_KPE_KEYBLOCK) ||(binPkg->bin.bin_cfg & SH_KB_VERSIONID_A))
			{
				keyType = 1;
				keyVer = 'A';
			}
			else if((binPkg->bin.bin_cfg & SH_KB_VERSIONID_B))
			{
				keyType = 1;
				keyVer = 'B';
			}
			else if((binPkg->bin.bin_cfg & SH_KB_VERSIONID_C))
			{
				keyType = 1;
				keyVer = 'C';
			}
			else if((binPkg->bin.bin_cfg & SH_KB_VERSIONID_D))
			{
				keyType = 1;
				keyVer = 'D';
			}
			if(binPkg->bin.bin_cfg & SH_KB_RACL_ATL_VAR)
			{
				OTraceDebug("D-SHC-022095: BIN has Thales Atalla Variant enabled\n");
				atalla_var = 1;
			}

			if(keyType == 1)
			{
//				if( ! generate_netkpe_td_xt(bufp->keyp->k.kek, bufp->keyp->k.kek_len, keylen, k_kpe, k_mfk, k_chk, keyType) )
				if( ! asynchGenerateNetKpeTd_xt(bufp->keyp->k.kek, bufp->keyp->k.kek_len, keylen, k_kpe, k_mfk, k_chk,NULL, keyType, keyVer, atalla_var) )
				{
					OTraceError("E-SHC-022016: Unable to generate PIN key for Key Block\n");
					return( SHC_RC_PINKeyError );
				}
			}
			else
			{
			if( ! generate_netkpe(bufp->keyp->k.kek, k_kpe, k_mfk, k_chk, atalla_var) )
			{
				OTraceError("E-SHC-022016: Unable to generate PIN key\n");
				return( SHC_RC_PINKeyError );
			}
			}
			break;

		/* R000587 > */
		case SH_KEYTYPE_KME:	/* Translate: Balance key */
            if( ! generate_netkme(bufp->keyp->k.kek, k_kpe, k_mfk, k_chk) )
			{
				OTraceError("E-SHC-022017: Unable to generate KME key\n");
				return( SHC_RC_KMESyncError );
			}
			break;
		/* R000587 > */

		case SH_KEYTYPE_MAC:
			/* Generate: E(mac)kek -> E(mac)mfk */
            /* R000573 */
            if( ! generate_netmac(bufp->keyp->k.kek, shcApp->shckeyParamsList->getShccfg()->tkpe,
                k_kpe, k_mfk, k_chk, atalla_var) )
			{
				OTraceError("E-SHC-022018: Unable to generate MAC key\n");
				return( SHC_RC_MACSyncError );
			}
			break;
	}

	OTraceDebug("D-SHC-022019:  E(key)LMK: [%-16s]\n", k_mfk);
	OTraceDebug("          :  C(key)LMK: [%-16s]\n", k_chk);

	/*
	 * Update pointers in memory
	 */
	shcSharedMemoryHelperObj->lockRule(sharedCashSecurityRuleName, &isLocked, &shcSecurityAppid);

	memcpy(bufp->akeyp, k_mfk, IST_SECURITY_KEY_SZ);
	memcpy(bufp->achkp, k_chk, CHECK_DIGIT_LEN);
	memcpy(bufp->acntp, bufp->keyp->k.acqkekcnt, KEY_CNT_LEN);

	shcSharedMemoryHelperObj->updateCurrentVersion(sharedCashSecurityRuleName, isLocked, 
				shcSecurityAppid, (char *)&bufp->keyp->k, sizeof(bufp->keyp->k));

	shcApp->shcKeyObj->shc_counter_inc(bufp->keyp->k.acqkekcnt);			/* R000587 */

	return( SHC_RC_Approved );								/* R000587 */
}

int ShcBin::shckeys_TranslateKey(struct shckey_buf *bufp, char *k_kpe, char *k_chk, char *k_cnt )
{
	char	k_mfk[IST_SECURITY_KEY_SZ + 1] = {0};
	char	c_mfk[CHECK_DIGIT_LEN + 1] = {0};
	int		ret = SHC_RC_Approved;
	int		isLocked = 0;

	shcApp->shckeyParamsList = (ShckeyParamsList *)shcApp->shckeyParams.getInst( bufp->keyp->k.institutionid);

	/* R000925 > */
	if( shcApp->shckeyParamsList->getShccfg()->val_seq == 'Y' )
	{
		OTraceDebug("D-SHC-022021: Verifying counter sequence\n");

		if( memcmp(k_cnt, bufp->keyp->k.isskekcnt, KEY_CNT_LEN) < 0 )
		{
			OTraceError("E-SHC-022022: Verifying counter sequence\n");
			OTraceError("E-SHC-022023: received [%20s] < expected [%20s]\n",
				k_cnt, bufp->keyp->k.isskekcnt);

			return( SHC_RC_CounterSyncError );
		}
	}
	/* R000925 < */

	OTraceDebug("D-SHC-022024: Translating new key\n");
	OTraceDebug("          :  E(KEK)LMK: [%-16s]\n", bufp->keyp->k.kek);
	OTraceDebug("          :  E(key)KEK: [%-16s]\n", k_kpe);

	switch( bufp->type )
	{
		case SH_KEYTYPE_PIN:
			/* Translate: E(kpe)kek -> E(kpe)mfk */
			if( ! translate_netkpe_mfkkpe(bufp->keyp->k.kek, k_kpe, k_mfk,
				c_mfk) )
			{
				OTraceError("E-SHC-022025: Unable to translate PIN key\n");
				return( SHC_RC_PINKeyError );
			}
			break;

		/* R000587 > */
		case SH_KEYTYPE_KME:	/* Translate: Balance key */
			/* Translate: E(kme)kek -> E(kme)mfk */
			if( !translate_netkme_mfkkme(bufp->keyp->k.kek, k_kpe, k_mfk, c_mfk) )
			{
				OTraceError("E-SHC-022026: Unable to translate KME key\n");
				return( SHC_RC_KMESyncError );
			}
			break;
		/* R000587 > */

		case SH_KEYTYPE_MAC:
			/* Translate: E(mac)kek -> E(mac)mfk */
			if( ! translate_netmac_mfkmac(bufp->keyp->k.kek, k_kpe,
				k_mfk, c_mfk) )
			{
				OTraceError("E-SHC-022027: Unable to translate MAC key\n");
				return( SHC_RC_MACSyncError );
			}
			break;
	}

	if( shcApp->shckeyParamsList->getShccfg()->val_chk == 'Y' && c_mfk[0]
		&& strncmp(c_mfk, k_chk, CHECK_DIGIT_LEN) )
	{
		OTraceError("E-SHC-022028: Check digits do not match\n");
		return( SHC_RC_KeyValidationError );
	}

	OTraceDebug("D-SHC-022029:  E(key)LMK: [%-16s]\n", k_mfk);
	OTraceDebug("          :  C(key)LMK: [%-16s]\n", k_chk);

	shcSharedMemoryHelperObj->lockRule(sharedCashSecurityRuleName, &isLocked, &shcSecurityAppid);


	/*
	 * Update pointers in memory
	 */
	memcpy(bufp->acntp, k_cnt, KEY_CNT_LEN);					/* R000587 */
	memcpy(bufp->keyp->k.isskekcnt, k_cnt, KEY_CNT_LEN);

	memcpy(bufp->akeyp, k_mfk, IST_SECURITY_KEY_SZ);
	memcpy(bufp->achkp, k_chk, CHECK_DIGIT_LEN);

	shcSharedMemoryHelperObj->updateCurrentVersion(sharedCashSecurityRuleName, isLocked, 
				shcSecurityAppid, (char *)&bufp->keyp->k, sizeof(bufp->keyp->k));

	return( SHC_RC_Approved );									/* R000587 */
}

int ShcBin::shckeys_ClrKeys( char *classp, char *typep,	char *indexp, char status )
{
	struct	shckey_buf keybuf = {0};
	const char	*cp = NULL, *tp = NULL, *ip = NULL;

	OTraceDebug("D-SHC-022030:  Clearing Keys for %s\n", binPkg->bin.networkid);

	if( status != SH_KEYSTAT_INACTIVE )
		status = SH_KEYSTAT_MARKED;

	for( tp = (typep ? typep : "MPK"); *tp; tp++ )
	{
		for( ip = (indexp ? indexp : "123"); *ip; ip++ )
		{
			for( cp = (classp ? classp : "AI"); *cp; cp++ )
			{
				if( shckeys_GetKey(&keybuf, *cp, *tp, *ip) < 0 )
					continue;

				if( *keybuf.astatp != SH_KEYSTAT_STATIC )
				{
					OTraceDebug("D-SHC-022031:   Clear status for key %c%c%c: '%c'\n",
						*cp, *tp, *ip, status);
/*
					memset(bufp->akeyp, '0', IST_SECURITY_KEY_SZ);
					memset(bufp->achkp, '0', CHECK_DIGIT_LEN);
*/
					*keybuf.astatp = status;
					*keybuf.aidxp = 1;
				}
			}
		}
	}

	return( 0 );
}

int ShcBin::shckeys_RstKeys()
{
	struct	shckey_buf keybuf = {0};

	if( shckeys_GetKeyUsage(&keybuf) < 0 )
		return( -1 );

	shckeys_ClrKeys((char *)"A", NULL, NULL, SH_KEYSTAT_INACTIVE);

	return( 0 );
}

int ShcBin::shckeys_Key2Shc(struct shckey_buf *bufp, ShcmsgHeader *header )
{
	char	*keyp = NULL, *cntp = NULL, *idxp = NULL;

	switch( bufp->type )
	{
       	case SH_KEYTYPE_PIN:
			keyp = header->msg.kpe_mfk;
			cntp = header->msg.kpe_kekcnt;
			idxp = &header->msg.pin_index;
			break;

       	case SH_KEYTYPE_MAC:
			keyp = header->msg.kmac_mfk;
			cntp = header->msg.kmac_kekcnt;
			idxp = &header->msg.mac_index;
			break;

       	case SH_KEYTYPE_KME:
			keyp = header->msg.kme_mfk;
			cntp = header->msg.kme_kekcnt;
			idxp = &header->msg.kme_index;
			break;
	}

	memcpy((void *)keyp, bufp->akeyp, IST_SECURITY_KEY_SZ);
	memcpy((void *)cntp, bufp->acntp, KEY_CNT_LEN);
	*idxp = bufp->index;

	OTraceDebug("D-SHC-022032: Update shcmsg key fields\n");
	OTraceDebug("          :  Key: %c%c%c\n", bufp->key_class, bufp->type, bufp->index);
	return( 0 );
}

/*  R001654.  */
int ShcBin::shckeys_FillMsg( ShcmsgHeader *header, char key_class, char type )
{
	struct shckey_buf	keybuf = {0};
	char				index = SH_KEYIDX_CURRENT;

	if( type == SH_KEYTYPE_MAC )
		index = header->msg.mac_index;

	if( shcmsgIsNetwork(&header->msg) && header->msg.netcode == SHC_NET_KEYS
		&& header->msg.format_code[1] == SH_KEYTYPE_MAC )
	{
		if( shckeys_GetKey(&keybuf, key_class, type, index) < 0 )
			return( -1 );
	}
	else
	{
		if( shckeys_GetKey(&keybuf, key_class, type, index) != 0 )
			return( -1 );
	}

	shcApp->shcDKEApiObj->shc_inc_kmaccnt(binPkg->bin.networkid);	/* R004681 */

	shckeys_Key2Shc(&keybuf, header);

	return( 0 );
}

/* ??????? < */


int ShcBin::shckeys_Mem2Dbm(struct shckey_buf *bufp)
{
	struct shckeys		keydb = {0};							/* 10001935 */
	int 				sec_fd = -1;

	shcApp->shckeyParamsList = (ShckeyParamsList *)shcApp->shckeyParams.getInst(bufp->keyp->k.institutionid);

	/*
	 * Update database
	 */
	if( shcApp->shckeyParamsList->getShccfg()->upd_tbl == 'N' )
		return( SHC_RC_Approved );

	if( (sec_fd = shcApp->shcKeyObj->shckeys_getdbmfd()) < 0 )
		return( -1 );

	//strcpy(keydb.bin, bufp->keyp->k.bin);
	strcpy(keydb.institutionid, bufp->keyp->k.institutionid);
	strcpy(keydb.userbinid, bufp->keyp->k.userbinid);
        keydb.site_id = bufp->keyp->k.site_id;

	if(dbm_read(sec_fd, (char *)&keydb, DBM_REQUAL | DBM_RLOCK) < 0)
	{
		OTraceFatal("F-SHC-022034: Unable to locate/lock key record\n");
		dbm_rollback(getpid());
		return(-1);
	}
	ICInstId_pure(keydb.institutionid, keydb.institutionid);

	if( dbm_write(sec_fd, (char *)&bufp->keyp->k, 0) < 0 )
	{
		OTraceFatal("F-SHC-022035: Unable to update key record\n");
		dbm_rollback(getpid());
		return( -1 );
	}

	OTraceDebug("D-SHC-022036: Update shckey record for bin '%s.%s'\n", bufp->keyp->k.institutionid, bufp->keyp->k.userbinid);

	/*	15jan96	*/

    /* R008150 */
	if( sec_fd >= 0)
    if (dbm_rewind(sec_fd) < 0)
	{
		OTraceFatal("F-SHC-022037: Unable to update key record\n");
		dbm_rollback(getpid());
		return( -1 );
	}

	if (dbm_commit(getpid()) < 0)
	{
		OTraceFatal("F-SHC-022038: Unable to update key record\n");
		dbm_rollback(getpid());
		return(-1);
	}


	char cmdbuf[256];
	sprintf(cmdbuf, "shccmd keys %s %s UPDLOCAL", keydb.institutionid, keydb.userbinid);
        mcastHelperObj->broadcast("shccmd", 0, cmdbuf , strlen(cmdbuf), NULL, 0);
	return( 0 );
}

int gShckeysSetDBLock = 0;	//Function as extra argument
int ShcBin::shckeys_Dbm2Mem( struct shcsecurity *keyp )
{
	struct shckeys		keydb = {0};							/* 10001935 */
	int 				sec_fd = -1;
	int _gShckeysSetDBLock = gShckeysSetDBLock;	
	gShckeysSetDBLock = 0;

	if (_gShckeysSetDBLock == SHCKEYS_DB_UNLOCK)
		goto unlock;

	if( (sec_fd = shcApp->shcKeyObj->shckeys_getdbmfd()) < 0 )
		return( -1 );

	//strcpy(keydb.bin, keyp->k.bin);
	strcpy(keydb.institutionid, keyp->k.institutionid);
	strcpy(keydb.userbinid, keyp->k.userbinid);
        keydb.site_id = keyp->k.site_id;

	if(dbm_read(sec_fd, (char *)&keyp->k, DBM_REQUAL | DBM_RLOCK) < 0)
	{
		OTraceFatal("F-SHC-022039: Unable to locate key record '%s'\n", keydb.bin);
		dbm_rollback(getpid());
		return( -1 );
	}
	ICInstId_pure(keyp->k.institutionid, keyp->k.institutionid);

	if (_gShckeysSetDBLock)		//should leave the lock to prevent racing of two simultaneous key exchange
		return 0;

    /* R008150 */

unlock:
    	if (dbm_rewind(sec_fd) < 0)
	{
		OTraceFatal("F-SHC-022040: Unable to update key record\n");
		dbm_rollback(getpid());
		return( -1 );
	}
	if (dbm_commit(getpid()) < 0)
	{
		OTraceFatal("F-SHC-022041: Unable to update key record\n");
		dbm_rollback(getpid());
		return(-1);
	}

	return( 0 );
}



int ShcBin::shckeys_GetKeyUsage( struct shckey_buf *bufp)
{
	shcApp->shcKeyObj->shc_keys_init();

	memset((void *)bufp, 0, sizeof(struct shckey_buf));

	if( shckeys_setpkg(bufp) < 0 )
		return( -1 );

	switch( bufp->keyp->k.flags[0] )
	{
		case '1':	bufp->list_type = (char *)"P";		break;
		case '2':	bufp->list_type = (char *)"M";		break;
		case '3':	bufp->list_type = (char *)"MP";		break;
		case '4':	bufp->list_type = (char *)"K";		break;
		case '5':	bufp->list_type = (char *)"PK";		break;
		case '6':	bufp->list_type = (char *)"MK";		break;
		case '7':	bufp->list_type = (char *)"MPK";		break;
	}

	switch( bufp->keyp->k.flags[1] )
	{
		case '1':	bufp->list_index = (char *)"1";		break;
		case '2':	bufp->list_index = (char *)"12";		break;
		case '3':	bufp->list_index = (char *)"123";	break;
	}

	bufp->list_xgen = (char *)"";
	bufp->list_xreq = (char *)"";

	switch( bufp->keyp->k.flags[2] )
	{
		case 'G':
			switch( bufp->keyp->k.flags[3] )
			{
				case 'A':	bufp->list_xgen = (char *)"A";	break;
				case 'I':	bufp->list_xgen = (char *)"I";	break;
				case 'B':	bufp->list_xgen = (char *)"AI";	break;
			}
			break;

		case 'R':
			switch( bufp->keyp->k.flags[3] )
			{
				case 'A':	bufp->list_xreq = (char *)"A";	break;
				case 'I':	bufp->list_xreq = (char *)"I";	break;
				case 'B':	bufp->list_xreq = (char *)"AI";	break;
			}
			break;
	}

	return( 0 );
}

int ShcBin::shc_setkeypointers(ShcmsgHeader *header)
{
	/*	Given a package, set the 'key' variable in shcmsg */

	return ( 0 );
}

/* R001072 > */
/* This function will verify the MAC field and key.
	Returns: 	1	Passed
				-1	Failed
				0 	Not tested.
*/
int ShcBin::shcmac_verify( ShcmsgHeader *header, char key_class )
{
    /*
     *  This function verifies the MAC for the response messages
     *  if the following conditions are true:
     *
     *      1.  KMAC keys exist
     */

	struct shckey_buf	keybuf = {0};
	int					ret = 0;
	ist_ElfId_t			NetDataRqid=ist_ElfId_t(-1);
	char				sBuf[2048];
	int					sBufLen;
	char				srcId[128];
	char				*ptrSrc=NULL;
	/*
	 * Bypass the MAC verification for the response message
	 * when CIL bounces back the request message.
	 */
	 if ( header->msg.formatter_devcap & SH_FORMATDEVCAP_NOROUTE )
		return(0);

	OTraceDebug("D-SHC-022042: Verifing MAC for bin %s\n", binPkg->bin.networkid);
	OTraceDebug("D-SHC-022043:  Key to Use: %c%c%c\n", key_class, SH_KEYTYPE_MAC,
		header->msg.mac_index);
	OTraceDebug("D-SHC-022044:  Respcode: %d\n", header->msg.respcode);

	/*
	 * Not verify MAC for certain response code in response messages.
	 */
	if ( shcApp->shcMacObj->shcRespNotVerifyMac(header) )
	{
		OTraceDebug("D-SHC-022045:  Status  : cancelled\n");

		if ( header->msg.respcode == SHC_RC_MACKeyError )
			shcApp->shcDKEApiObj->shc_inc_macerrcnt_x( header );
		else if ( header->msg.respcode == SHC_RC_MACSyncError )
			shcApp->shcDKEApiObj->shc_inc_akmacsyncerrcnt_x( header );

		return( 0 );
	}

	if( shcIsNetwork(header) && header->msg.netcode == SHC_NET_KEYS
		&& header->msg.format_code[1] == SH_KEYTYPE_MAC )
	{
		if( shckeys_GetKey(&keybuf, key_class, SH_KEYTYPE_MAC,
			header->msg.mac_index) < 0 )
   		{
			header->msg.respcode = SHC_RC_NoKeysToUse;
			OTraceError("E-SHC-022046:  Status  : cancelled - No MAC key available\n");

      		return( -1 );
   		}
	}
	else
	{
		if( shckeys_GetKey(&keybuf, key_class, SH_KEYTYPE_MAC,
			header->msg.mac_index) != 0 )
   		{
			header->msg.respcode = SHC_RC_NoKeysToUse;
			OTraceError("E-SHC-022047:  Status  : cancelled - No MAC key available\n");

      		return( -1 );
   		}
	}

   	shcApp->shcDKEApiObj->shc_inc_kmaccnt(binPkg->bin.networkid);

	struct shcseg   *shcsegP;
	struct shcsegstart      *sp;


	shcsegP = shcmsgLocateSegmentStart(&header->msg);

	if((sp=shc_segfind(shcsegP, "MAC_DATA_BUF")))
	{
		if(shcIsAsynchSecMode())
		{
			setAsynchHeader(header);
			if(setAsynchWait())
			{
				setAsynchSrcId(srcId,sizeof(srcId));
			}
			ptrSrc=srcId;
		}
		ret = asynchVerifyMacTd(keybuf.akeyp, *keybuf.akeylen, header->msg.mac_value,
								shc_seggetdata_pointer(shcsegP, sp), 
								shc_seggetdata_len(shcsegP, sp), srcId);
	}
	else if(shcIsAsynchSecMode())
	{
		sBufLen = 0;
		memset(sBuf, 0x00, sizeof(sBuf));
		NetDataRqid = ElfIdMap::elf_to_id(IST_SEG_NETWORK_DATA_REQ);
		header->getSegmentData((char*)sBuf,&sBufLen,NetDataRqid,ISO_MAC_DATA);
		if(sBufLen > 0)
		{
			setAsynchHeader(header);
			if(setAsynchWait())
			{
				setAsynchSrcId(srcId,sizeof(srcId));
			}
			ptrSrc=srcId;
			ret = asynchVerifyMacTd(keybuf.akeyp,*keybuf.akeylen,header->msg.mac_value,sBuf,sBufLen,srcId);
		}
		else
		{
			OTraceDebug("D-SHC-022048.0:  Skipping MAC verification - NO mac value\n");
			return (1);
		}
	}

	if(ret==SEC_ASYNCH_WAIT)
		return(SEC_ASYNCH_WAIT);
	else if( ret > 0 )
	{
		OTraceDebug("D-SHC-022048:  Status  : passed\n");

		return( 1 );
	}


    /* check the kmac counter for KMAC synchronization failure */
	if( ret == 0
		&& memcmp(header->msg.kmac_kekcnt, keybuf.acntp, KEY_CNT_LEN) != 0 )
    {
		OTraceDebug("D-SHC-022049:  Status  : failed - Counter sync. error\n");
		OTraceDebug("D-SHC-022050:   in Msg : [%s]\n", header->msg.kmac_kekcnt);
		OTraceDebug("D-SHC-022051:   in Mem : [%s]\n", keybuf.acntp);

		shcApp->shcDKEApiObj->shc_inc_akmacsyncerrcnt_x( header, SHC_RC_MACSyncError );
       	header->msg.respcode = SHC_RC_MACSyncError;
	}
	else
	{
		OTraceError("E-SHC-022052:  Status  : failed - Security device error [%d]\n",
				sec_error());

		shcApp->shcDKEApiObj->shc_inc_macerrcnt( header, SHC_RC_MACKeyError );
    	header->msg.respcode = SHC_RC_MACKeyError;

	}

	return( -1 );
}

int ShcBin::shc_get_pin_translate_parameters_xt_xt(ShcmsgHeader *header,
												  int		is_issuer,
												  struct shcsecurity **secp,
												  PINVERPARM	**pinp,
												  char		**key,
												  int *keylen,
												  char *keyidx)
{
	struct shckey_buf keybuf = {0};

	/*
	 * Make sure shckeys & pinverparm table is in memory
	 */
	if( ! (binPkg->bin.bintype & SH_USES_KEYS) )
	{
		header->msg.respcode = SHC_RC_FunctionNotAvailable;
		OTraceError("E-SHC-022053: Network keys not configured for this bin\n");
		return( -1 );
	}

	if( !this->key )
	{
		OTraceError("E-SHC-022054: Attempting to accept keys for %s %s. No key parms.\n", binPkg->bin.institutionid, binPkg->bin.userbinid);
		header->msg.respcode = SHC_RC_SystemError;
		return( -1 );
	}
	if(binPkg->bin.pinparm < 0)
	{	/*	no pin parameters */
		OTraceError("E-SHC-022055: No pin translation: No pinverparm.\n");
		header->msg.respcode = SHC_RC_SystemError; /* R009438 */
		return( -1 );
	}

	/*
	 * Get the keys
	 */

	if(!isInterac())
	{
		/*
		 * Non-Interac Version
		 */
		int		ret = SHC_RC_Approved;

		keybuf.keyp = this->key;

		/* R001283
		ret = shcApp->shcKeyObj->shc_keys_init_buf(&keybuf,
			(is_issuer ? SH_KEYTYPE_PIN_ACQ : SH_KEYTYPE_PIN_ISS), SH_KEYTYPE_PIN,
				'1');
		*/
		if(is_issuer)
		{
			ret = shcApp->shcKeyObj->shc_keys_init_buf(&keybuf,
									SH_KEYTYPE_PIN_ACQ,
									SH_KEYTYPE_PIN,
									'0' + keybuf.keyp->k.acqpinidx);
		}
		else
		{
		   	/* R008032 */
		   	if (   header->msg.pin_index == '1'
			   	|| header->msg.pin_index == '2'
			   	|| header->msg.pin_index == '3' )
			{
			   	ret = shcApp->shcKeyObj->shc_keys_init_buf(&keybuf,
										SH_KEYTYPE_PIN_ISS,
									    SH_KEYTYPE_PIN,
									    header->msg.pin_index );
            }
			else
			{
				ret = shcApp->shcKeyObj->shc_keys_init_buf(&keybuf,
										SH_KEYTYPE_PIN_ISS,
										SH_KEYTYPE_PIN,
										'0' + keybuf.keyp->k.isspinidx);
            }
		}

		if( ret != SHC_RC_Approved )
		{
			header->msg.respcode = ret;
			return( -1 );
		}

		*pinp = pin;
		*secp = keybuf.keyp;

		if( is_issuer )
		{
			if( keybuf.akeyp && *keybuf.astatp != SH_KEYSTAT_ACTIVE )
			{
				OTraceError("E-SHC-022056: Acquirer key not active - Type %s  Index %d  Status %c\n", keybuf.ctype, *keybuf.aidxp, *keybuf.astatp);
				header->msg.respcode = SHC_RC_FunctionNotAvailable;
				return( -2 );
			}

			*key = keybuf.akeyp;
			*keylen = *keybuf.akeylen;
			*keyidx = '0' + *keybuf.aidxp;   /* R008099 */
		}
		else
		{
			if( keybuf.ikeyp && *keybuf.istatp != SH_KEYSTAT_ACTIVE )
			{
				if ((header->msg.device_cap & SH_DEVCAP_FROM_NETWORK) && (*keybuf.istatp == SH_KEYSTAT_EXCHANGE))
				{
					//This may happen for MC, let's try to use the key under exchange
					OTraceError("E-SHC-022083: Issuer key not active - Type %s  Index %d  Status %c. Still try to use it.\n", 
							keybuf.ctype, *keybuf.iidxp, *keybuf.istatp);
				
				}
				else
				{
					OTraceError("E-SHC-022057: Issuer key not active - Type %s  Index %d  Status %c\n", keybuf.ctype, *keybuf.iidxp, *keybuf.istatp);
					header->msg.respcode = SHC_RC_FunctionNotAvailable;
					return( -2 );
				}
			}

			*key = keybuf.ikeyp;
			*keylen = *keybuf.ikeylen;
			*keyidx = '0' + *keybuf.iidxp;   /* R008099 */
		}

	}
	else
	{
		/*
		 * The Interac Version
		 */
		if( shckeys_GetKey(&keybuf,
			(is_issuer ? SH_KEYTYPE_PIN_ACQ : SH_KEYTYPE_PIN_ISS),
			SH_KEYTYPE_PIN, SH_KEYIDX_CURRENT) != 0 )
		{
			header->msg.respcode = SHC_RC_NoKeysToUse;
			return( -1 );
		}
		*pinp = pin;
		*secp = keybuf.keyp;

		/* R000925 */
		if( ! keybuf.akeyp || *keybuf.astatp != SH_KEYSTAT_ACTIVE )
		{
				OTraceError("E-SHC-022058: Key not active - Type %s  Index %d  Status %c\n", keybuf.ctype, *keybuf.aidxp, *keybuf.astatp);
				header->msg.respcode = SHC_RC_FunctionNotAvailable;
				return( -1 );
		}

		*key = keybuf.akeyp;
		*keylen = *keybuf.akeylen;
		*keyidx = '0' + *keybuf.aidxp;   /* R008099 */

	}

	/*
	 * Return 0 if everything goes OK
	 */
	return( 0 );
}

int ShcBin::shc_get_pin_translate_parameters_xt(ShcmsgHeader *header,
												int		is_issuer,
												struct shcsecurity **secp,
												PINVERPARM	**pinp,
												char		**key,
												int *keylen)
{

	char keyidx;

	return ( shc_get_pin_translate_parameters_xt_xt(header,
												    is_issuer,
												    secp,
												  	pinp,
												  	key,
												    keylen,
													&keyidx));
}

/*****************************************************************************/

int ShcBin::shckme_DecryptBalance( ShcmsgHeader *header,
							char key_class, char index )
{
    /*
     *  This function performs the encryption on the balance field.
     *
     *  A balance field needs to be encrypted under the following conditions
     *
     *      1.  a balance exists in the response message
     *      2.  Switch has the "shc.encrypt_balance" turned on in istparam.cfg
     *      3.  KME keys exist
     */
	struct shckey_buf	keybuf = {0};

	if( ! shcIsFinancialRequest(header) && ! shcIsInquiry(header->msg.pcode) )
		return( 0 );

    OTraceDebug("D-SHC-022059: Decrypting Balance Field\n");
    OTraceDebug("D-SHC-022060:  E(PIN)KME: [%s]\n", header->msg.pin);
    OTraceDebug("D-SHC-022061:  Src. BIN : %s\n", binPkg->bin.networkid);
    OTraceDebug("D-SHC-022062:  Src. Key : %c%c%c\n", key_class, SH_KEYTYPE_KME,
			index);

	if( shckeys_GetKey(&keybuf, key_class, SH_KEYTYPE_KME, index) != 0 )
    {
        OTraceDebug("D-SHC-022063:  Status  : cancelled - No MAC key available\n");

        header->msg.respcode = SHC_RC_NoKeysToUse;
        return( -1 );
    }

	shcApp->shcDKEApiObj->shc_inc_kmecnt(binPkg->bin.networkid);
	if( shcApp->shcmsgHelperObj->shc_balance_encryption(header, keybuf.akeyp, 'D') == SHC_RC_Approved
		&& shcApp->shcmsgHelperObj->data_edit_error(header->msg.pin) >= 0 )
	{
		ICShcmsg_putFld(&header->msg, (char *)"SHC_AVAL_BALANCE", &header->msg.pin[1]);
		/* R007363 */
		if (header->msg.pin[0] == 'D')
			dbm_decnmul(&header->msg.aval_balance, -1);

		return( 0 );
	}

    if( memcmp(header->msg.kme_kekcnt, keybuf.acntp, KEY_CNT_LEN) != 0 )
    {
        OTraceDebug("D-SHC-022064:  Status  : failed - Counter sync. error\n");
        OTraceDebug("D-SHC-022065:   in Msg : [%s]\n", header->msg.kme_kekcnt);
        OTraceDebug("D-SHC-022066:   in Mem : [%s]\n", keybuf.acntp);

		shcApp->shcDKEApiObj->shc_inc_akmesyncerrcnt_x( header ); /* R004649 */
       	header->msg.respcode = SHC_RC_KMESyncError;
    }
	else
	{
        OTraceDebug("D-SHC-022067:  Status  : failed\n");

       	header->msg.respcode = SHC_RC_InvalidTransactionTerm;
	}

	return( -1 );
}

/*****************************************************************************/

int ShcBin::shckme_EncryptBalance( ShcmsgHeader *header,
							char key_class, char index )
{
    /*
     *  This function performs the encryption on the balance field.
     *
     *  A balance field needs to be encrypted under the following conditions
     *
     *      1.  a balance exists in the response message
     *      2.  Switch has the "shc.encrypt_balance" turned on in istparam.cfg
     *      3.  KME keys exist
     */
	struct shckey_buf	keybuf = {0};

	if( ! shcIsFinancialRequest(header) && ! shcIsInquiry(header->msg.pcode) )
		return( 0 );

	if(ist_otrace_get_level() >= OTRACE_DEBUG)
	{
            OTraceDebug("D-SHC-022068: Encrypting Balance\n");
            OTraceDebug("D-SHC-022069:  E(PIN)KME: [%s]\n", header->msg.pin);
            OTraceDebug("D-SHC-022070:  Dst. BIN : %s\n", binPkg->bin.networkid);
            OTraceDebug("D-SHC-022071:  Dst. Key : %c%c%c\n", key_class, SH_KEYTYPE_KME,
					index);
	}

	if( shckeys_FillMsg(header, key_class, SH_KEYTYPE_KME) < 0 )
	{
        OTraceError("E-SHC-022072:  Status  : failed - System Error\n");

        header->msg.respcode = SHC_RC_NoKeysToUse;
		return( -1 );
	}

	shcApp->shcDKEApiObj->shc_inc_kmecnt(binPkg->bin.networkid);
	shcApp->shcmsgHelperObj->shc_build_balance_data(header->msg.pin, &header->msg.aval_balance);

	if( shcApp->shcmsgHelperObj->shc_balance_encryption(header, header->msg.kme_mfk, 'E')
		!= SHC_RC_Approved )
	{
        OTraceError("E-SHC-022073:  Status  : failed - Security device error [%d]\n",
        	sec_error());

        header->msg.respcode = SHC_RC_KMESyncError;
		return( -1 );
	}

   	OTraceDebug("D-SHC-022074:  Status  : passed\n");

	return( 0 );
}
int ShcBin::setInstUp(int force)
{
        if ((ofThisSite && (ofThisSite != mbGetSiteId())) && !(binPkg->bin.bin_cfg & SH_CFG_ENABLE_DUAL_SITE_BRIDGE))
        {
                OTraceDebug("D-SHC-022100:set bin up from other site. Ignore.\n");
                return 0;
        }

	int shcAppidLocked = 0;
//      >>>     R016871
	shcSharedMemoryHelperObj->lockRule(sharedCashRuleName, &shcAppidLocked, &shcAppid);

    if (shcApp&&shcApp->saf_interleave&&((binPkg->saf.type & SH_SAF_POSFILE)||(binPkg->saf.type & SH_SAF_NEGFILE)))
    {
            if (shcApp->shcSafIOHelperObj->net_saf_exists(binPkg))
            {
                    binPkg->bin.flags |= SH_REPLAY;
                    binPkg->bin.flags &= ~(SH_DOWN | SH_KEY_EXCHANGE );
					shcSharedMemoryHelperObj->updateCurrentVersion(sharedCashRuleName, 
						shcAppidLocked, shcAppid, (char *)binPkg, sizeof(*binPkg));
                    return( 0 );
            }
    }
    binPkg->bin.flags &= ~(SH_DOWN | SH_KEY_EXCHANGE | SH_REPLAY);

	shcSharedMemoryHelperObj->updateCurrentVersion(sharedCashRuleName, 
		shcAppidLocked, shcAppid, (char *)binPkg, sizeof(*binPkg));
	
    if ((!noBraodcastFlag) && (istswIsReady()))

    {
	    char cmdbuf[256];
            snprintf(cmdbuf, sizeof(cmdbuf),"shccmd -site %hd -s force %s %s up", mbGetSiteId(), binPkg->bin.institutionid, binPkg->bin.userbinid);
                mcastHelperObj->broadcast("shccmd", 2, cmdbuf , strlen(cmdbuf), NULL, 0);
	}
    return( 0 );
//      <<<     R016871
}

int ShcBin::setInstDown(int force)
{
	int shcAppidLocked = 0;
	
        if ((ofThisSite && (ofThisSite != mbGetSiteId())) && !(binPkg->bin.bin_cfg & SH_CFG_ENABLE_DUAL_SITE_BRIDGE))
        {
                OTraceDebug("D-SHC-022100:set bin down from other site. Ignore.\n");
                return 0;
        }
        else
        {
		shcSharedMemoryHelperObj->lockRule(sharedCashRuleName, &shcAppidLocked, &shcAppid);

    binPkg->bin.flags |= SH_DOWN;
    binPkg->bin.flags &= ~SH_KEY_EXCHANGE;

	shcSharedMemoryHelperObj->updateCurrentVersion(sharedCashRuleName, 
		shcAppidLocked, shcAppid, (char *)binPkg, sizeof(*binPkg));

    if ((!noBraodcastFlag) && (istswIsReady()))
    {
	    char cmdbuf[256];
                snprintf(cmdbuf, sizeof(cmdbuf),"shccmd -site %hd -s force %s %s down", mbGetSiteId(), binPkg->bin.institutionid, binPkg->bin.userbinid);
                        mcastHelperObj->broadcast("shccmd", 2, cmdbuf , strlen(cmdbuf), NULL, 0);
                }
        }

	struct RoutingInfo routingInfo = {0};
        if (ofThisSite)
                routingInfo.siteId = ofThisSite;
        else
                routingInfo.siteId = mbGetSiteId();

	int binStatusChanged = 1;
	if (binRouteObj)
	{
		binRouteObj->markRouteDown(binPkg->bin.networkid, &routingInfo, &binStatusChanged);
	}
    return( 0 );
}

int ShcBin::clearInst()
{
//    binPkg->bin.flags &= ~SH_REPLAY;
    binPkg->bin.flags |= SH_KEY_EXCHANGE;

    shckeys_RstKeys();

    return( 0 );
}

int ShcBin::shc_locate_bin(struct shcpkg **shcpkg, bin_t bin)
{
	/*
	 *	Input:		shcpkg			gets the address of the found bin entry
	 *				bin				bin which to locate in our tables
	 *
	 *	Action:		This function locates the bin entry for 'bin' in the
	 *				global bin tables. If it is found then the address
	 *				of the entry is placed in shcbin.
	 *
	 *	Returns:	i		index of the key entry if found
	 *				-1		if bin not found
	 */
	char	binentry[sizeof(bin_t) * 2];
	char	*bps, *bpe;
	struct shckeysmem *pTmp = NULL;
	int		i;
	int		n;
	char	savebps[sizeof(bin_t)];

	/*
	 *	Normialize the bin entry
	 */

	/*
	 * R000973
	 */
	memset(binentry, ' ', sizeof(binentry));
	binentry[sizeof(binentry)-1]='\0';
// R005156	ICBin_rjfy(binentry+sizeof(bin_t),bin);
	ICBin_rjfy( (ICBINp) binentry+sizeof(bin_t), (ICBINp) bin);

	/*	Set pointers to start and end of bin string */
	bps = binentry + sizeof(bin_t);
	bpe = bps + sizeof(bin_t) - 1;
	snprintf(savebps,sizeof(savebps),"%s",bps); //IST_S_0157721-34
	
	if (shcSharedMemoryHelperObj->attachCurrent(&shcAppid, &pShcAppHead) < 0)
		{
			OTraceError("E-SHC-022076:Can't attach appid(%d), failed to find bin.\n", shcAppid);
			return -1;
		}

	for(n = 0; n < SHC_BIN_LEN; ++n)
	{
		if((i = shc_search_bintable(bps)) != -1)
		{
				break;
		}

		/*	Decrease size of bin */
		bps--;
		bpe--;
		*bpe = '\0';
	}

	if(i >= 0)
	{
		/*memcpy(bin, bps, sizeof(bin_t));*/
		//shcApp->shcmsgHelperObj->shc_normalizebin(bin);
		char *p = rm_getappkey(shcAppid);
		if (p==NULL)
		{
			OTraceError("E-SHC-022077:Can't find text of appid(%d), failed to find bin.\n", shcAppid);
			return -1;
		}
		p += i*pShcAppHead->keysize;
		pTmp = (struct shckeysmem *)p;
		newlyFoundShcBinKey = pTmp;
		if(pTmp->textid < 0)
		{
			OTraceError("E-SHC-022075:search for bin %s found textid = %d\n",
				bin, pTmp->textid);
			return(-1);
		}

		
		if(shcpkg)
			*shcpkg = (struct shcpkg *)(rm_getapptext(shcAppid)+pTmp->textid*pShcAppHead->textsize);

		return(i);
	}
	else
		return(-1);
}

int ShcBin::shc_locate_bin(struct shcpkg **shcpkg, char *institutionId, char *userBinId)
{
	/*
	 *	Input:		shcpkg			gets the address of the found bin entry
	 *				institutionId	institution by which to locate in our tables
	 *				userBinId		user bin id by which to locate in our tables
	 *
	 *	Action:		This function locates the bin entry in the
	 *				global bin tables. If it is found then the address
	 *				of the entry is placed in shcbin.
	 *
	 *	Returns:	i		index of the text entry if found
	 *				-1		if bin not found
	 */
	bin_t	tmpInstitutionId;
	bin_t	tmpUserBinId;
	int		i;
	int		n;
	char *p=NULL;
	struct      shckeysmem      *pTmp = NULL;

	if (shcSharedMemoryHelperObj->attachCurrent(&shcAppid, &pShcAppHead) < 0)
	{
		OTraceError("E-SHC-022078:Can't attach to appid(%d)\n, failed to find bin", shcAppid);
		return -1;
	}
	/*
	 *	Normialize the bin entry
	 */

	ICInstId_pure( (ICBINp) tmpInstitutionId, (ICBINp ) institutionId);
	ICBin_rjfy( (ICBINp) tmpUserBinId, (ICBINp ) userBinId);

	p = rm_getappkey(shcAppid);
	if (p==NULL)
	{
		OTraceError("E-SHC-022079:Can't get to key appid(%d)\n, failed to find bin", shcAppid);
		return -1;
	}
	for(i = 0; i < pShcAppHead->keysused; ++i, p += pShcAppHead->keysize)
	{
		pTmp = (struct shckeysmem *)p;
		if(	(stricmp(tmpInstitutionId, pTmp->institutionid) == 0) &&
			(stricmp(tmpUserBinId, pTmp->userbinid) == 0) )
			break;
	}

	if(i < pShcAppHead->keysused)
	{
		newlyFoundShcBinKey = pTmp;	//	R019505
		if(shcpkg)
		{
			p = rm_getapptext(shcAppid);
			if (p==NULL)
			{
				OTraceError("E-SHC-022080:Can't get to text appid(%d)\n, failed to find bin", shcAppid);
				return -1;
			}
			
			if (pTmp->textid < 0)
			{
				OTraceError("E-SHC-022081:Can't get to text appid(%d)\n, failed to find bin", shcAppid);
				return -1;
			}
			*shcpkg = (struct shcpkg *)(p + pShcAppHead->textsize*pTmp->textid);
		}
		return(i);
	}
	else
		return(-1);
}


int ShcBin::shc_search_bintable(bin_t bin)
{
	/*
	 *	search the incore tables for the correct bin entry
	 */
	int	hi, low;
	int	ret;
	register	int mid;
	register	int i;
	char *p = NULL;
	struct shckeysmem *pTmp;

	if (shcSharedMemoryHelperObj->attachCurrent(&shcAppid, &pShcAppHead) < 0)
	{
		OTraceError("E-SHC-022082:Can't attach to appid(%d)\n, failed to find bin", shcAppid);
		return -1;
	}

	if(!(pShcAppHead->flags & RULES_KEY_SORTED))
	{
		p = rm_getappkey(shcAppid);
		for(i = 0; i < pShcAppHead->keysused; ++i, p += pShcAppHead->keysize)
		{
			pTmp = (struct shckeysmem *)p;
			if(stricmp(bin, pTmp->bin) == 0)
				return(i);
		}
	}
	else
	{
		low = 0;
		hi  = pShcAppHead->keysused - 1;
		for(;;)
		{
			if(hi < low)
				break;

			mid = (hi + low) / 2;
			pTmp = (struct shckeysmem *)(rm_getappkey(shcAppid)+mid*pShcAppHead->keysize);
			ret = stricmp(bin, pTmp->bin);

			if(ret == 0)
				return(mid);
			if(ret < 0)
				hi = mid - 1;
			else
				low = mid + 1;
		}

	}

	return(-1);
}

int ShcBin::shc_test_compare(char *bin, char *lowbin, char *highbin)
{
    if(strcmp(bin, lowbin) >= 0)
    {
        if(strcmp(bin, highbin) > 0)
            return(1);
        else
            return(0);
    }
    else
        return(-1);
}

int ShcBin::internalBin2ExternalBin(char *institutionId, char *userBinId, const char *networkid)
{
	struct	shcpkg		*pBinPkg;
	int i;

	newlyFoundShcBinKey = NULL;
	i=shc_locate_bin(&pBinPkg, (char *)networkid);
	if(i == -1)
		return(-1);
	else
	{
		istsafe_strcpy(institutionId, sizeof(bin_t), newlyFoundShcBinKey->institutionid);
		istsafe_strcpy(userBinId, sizeof(bin_t), newlyFoundShcBinKey->userbinid);
		return(0);
	}
}

int ShcBin::externalBin2InternalBin(char *networkid, const char *institutionId, const char *userBinId)
{
	struct shcpkg *pBinPkg;
	int i;

	newlyFoundShcBinKey = NULL;
	i=shc_locate_bin(&pBinPkg, (char *)institutionId, (char *)userBinId);
	if(i == -1)
		return(-1);
	else
	{
		strcpy(networkid, newlyFoundShcBinKey->bin);
		return(0);
	}
}

int ShcBin::isFullEntry()
{
	if (this && binPkg && binPkg->bin.bin_cfg & SH_CFG_FULL_ENTRY)
		return 1;
	else
		return 0;
}

int ShcBin::isVerifyARQCReq()
{
	if (this && binPkg && binPkg->bin.bin_cfg & SH_CFG_CARD_AUTH)
		return 1;
	else
		return 0;
}

int ShcBin::isGenARPCReq()
{
	if (this && binPkg && binPkg->bin.bin_cfg & SH_CFG_ISS_AUTH)
		return 1;
	else
		return 0;
}

int ShcBin::declineIfARQCFails()
{
	if (this && binPkg && binPkg->bin.bin_cfg & SH_CFG_DECL_AUTH_FAI)
		return 1;
	else
		return 0;
}

int ShcBin::logChipData()
{
	if (this && binPkg && binPkg->bin.bin_cfg & SH_CFG_CHIP_LOG)
		return 1;
	else
		return 0;
}

int ShcBin::isEmvStip()
{
	if (this && binPkg && binPkg->bin.bin_cfg & SH_CFG_EMV_STIP)
		return 1;
	else
		return 0;
}

int ShcBin::isInterac()
{
	if (this && binPkg && binPkg->bin.bin_cfg & SH_CFG_INTERAC)
		return 1;
	else
		return 0;
}
int ShcBin::isDynamicSQL()
{
	if (this && binPkg && binPkg->bin.bin_cfg & SH_CFG_DSQL)
		return 1;
	else
		return 0;
}
int ShcBin::isNDKE()
{
	if (this && binPkg && binPkg->bin.bin_cfg & SH_CFG_NDKE)
		return 1;
	else
		return 0;
}
int ShcBin::isCheckDupRev()
{
	if (this && binPkg && binPkg->bin.bin_cfg & SH_CFG_CHKDUPREV)
		return 1;
	else
		return 0;
}
int ShcBin::isRestoreTranTime()
{
	if (this && binPkg && binPkg->bin.bin_cfg & SH_CFG_TRANTIME)
		return 1;
	else
		return 0;
}

int ShcBin::isCapdateOverride()
{
	if (this && binPkg && binPkg->bin.bin_cfg & SH_CFG_CAPDATEOVERRIDE)
		return 1;
	else
		return 0;
}

int ShcBin::isTokenTxnChkSkip()
{
	if (this && binPkg && binPkg->bin.bin_cfg & SH_CFG_TOKEN_TXN_CHK)
		return 1;
	else if (this && binPkg && binPkg->bin.bin_cfg & SH_CFG_TOKEN_TXN_NO_CHK)
                return 2;
	else
		return 0;
}

ShcBin::ShcBin(ShcBin *pBin)
{
	binPkg = pBin->binPkg;
	pin    = pBin->pin;
	key    = pBin->key;
}

ShcBin::ShcBin(ShcBin &sBin)
{
	binPkg = sBin.binPkg;
	pin = sBin.pin;
	key = sBin.key;
}

/* int shc_getissnetkpe(ShcmsgHeader *header, struct shcpkg *pkg) R004752 */
int ShcBin::shc_getissnetkpe(ShcmsgHeader *header, char *kpe_cnt)
{
	struct shckey_buf keybuf = {0}; /* R001835 */

	/*
	 * R001835
	 */
	if(!isInterac())
	{
		/*
         * Non-Interac Version
         */
		if(key == NULL)
			return(-1);

		/* R008032 Check pin_index first */
	   	if ((header->msg.pin_index == '1')||(header->msg.pin_index == 1))
			memcpy(header->msg.mac.key, key->k.isspin1, key->k.isskpe_len);
	   	else if ((header->msg.pin_index == '2')||(header->msg.pin_index == 2))
			memcpy(header->msg.mac.key, key->k.isspin2, key->k.isskpe_len);
	   	else if ((header->msg.pin_index == '3')||(header->msg.pin_index == 3))
			memcpy(header->msg.mac.key, key->k.isspin3, key->k.isskpe_len);
		else if(key->k.isspinidx == 1)
			memcpy(header->msg.mac.key, key->k.isspin1, key->k.isskpe_len);
		else if(key->k.isspinidx == 3)
					memcpy(header->msg.mac.key, key->k.isspin3, key->k.isskpe_len);
		else
			memcpy(header->msg.mac.key, key->k.isspin2, key->k.isskpe_len);

        header->msg.keylen = key->k.isskpe_len;
		OTraceDebug("D-SHC-022079:pin_index[0x%x] active index[%d].\n", (int)header->msg.pin_index, 
						key->k.isspinidx);
	}
	else
	{
		/*
         * Interac Version
         */
		if( shckeys_GetKey(&keybuf, SH_KEYTYPE_PIN_ISS, SH_KEYTYPE_PIN,
       		 SH_KEYIDX_CURRENT) != 0 )
       		 return( -1 );

    	memcpy(header->msg.mac.key, keybuf.akeyp, IST_SECURITY_KEY_SZ);
    	memcpy(header->msg.mac.chk, keybuf.achkp, CHECK_DIGIT_LEN);
		memcpy(kpe_cnt, keybuf.acntp, KEY_CNT_LEN); /* R004752 */
	}

	return(0);
}

int ShcBin::setBinPkg( bin_t bin )
{
	binPkg = NULL;
	int ret;
	ret =  shc_locate_bin( &binPkg, bin );
					
	key = NULL;
    pin = NULL;
	if (binPkg && binPkg->bin.pinparm >= 0)
	{
//		if (shcApp == NULL)
//			shcApp = (ShcAppBase *)shcHelperRegister.getTargetObj(SHC_ShcAppBase);
		pin = shcApp->shcHelperObj->shc_getpinparm(binPkg->bin.pinparm);
	}
	return ret;
}

int ShcBin::setBinPkg( char *instId, char *userBinId )
{
	int ret;
	binPkg = NULL;
	ret =  shc_locate_bin( &binPkg, instId, userBinId );
					
	key = NULL;
	pin = NULL;
	if (binPkg && binPkg->bin.pinparm >=0 )
	{
		if (shcApp == NULL)
	    	shcApp = (ShcAppBase *)shcHelperRegister.getTargetObj(SHC_ShcAppBase);
	    pin = shcApp->shcHelperObj->shc_getpinparm(binPkg->bin.pinparm);
	}
	return ret;
}

void  ShcBin::setBinPkg( shcpkg *p)
{
	binPkg = p;
  	if (binPkg && binPkg->bin.pinparm >=0 )
	{
		if (shcApp == NULL)
	    	shcApp = (ShcAppBase *)shcHelperRegister.getTargetObj(SHC_ShcAppBase);
	    pin = shcApp->shcHelperObj->shc_getpinparm(binPkg->bin.pinparm);
	}

}

struct shcpkg *ShcBin::getBinPkg(char *shcDefaultIssuerId)
{
	struct shcpkg *ret = NULL;
	shc_locate_bin(&ret, shcDefaultIssuerId);
	return ret;
}


int ShcBin::setKey ( struct InstitutionProfile *ip )
{
	struct shcsecurity * keyParm = NULL;
	if (ip && (strlen(ip->keyparamStr) >= 0)) //Uses SHM versioning
	{
		keyParm = shcApp->shcKeyObj->getKey(ip->instId, ip->keyparamStr);
		if (keyParm)
			setKey(keyParm);
		else
		{
			OTraceError("E-SHC-022098:Can't find issuer key(%s,%s)\n", ip->instId, ip->keyparamStr);
			return(-1);
		}
	}
	else if(ip->keyparm >= 0) //Uses old rules
	{
		setKey(&shcSecurity[ip->keyparm]);
	}
	else
	{
		OTraceError("E-SHC-022099:No key configured for inst_profile entry[%d]\n", ip->id);
		return(-1);
	}

	return 0;
}

int shcUseDefaultKeyIndex()
{
	char buf[80];
	static bool readFlg=false;

	if(!readFlg)
	{
		if(cf_open("files/shc.cfg") >= 0)
		{
			if(cf_locate("shc.use_default_keyidx", buf) > 0)
			{
				switch(buf[0])
				{
					case 'Y':
					case '1':
					case 'y':
						shcUseDefaulKeyIdx=1;
						break;
					default:
						shcUseDefaulKeyIdx=0;
				}
			}
		}
		OTraceDebug("D-SHC-001120 Use Default Key Index[%d]\n",shcUseDefaulKeyIdx);
		readFlg=true;
	}
	return(shcUseDefaulKeyIdx);
}
