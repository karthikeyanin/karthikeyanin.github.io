/*
 *  Copyright (C) 2010 FIS Corporation ("FIS").  All Rights Reserved.
 *  FIS Canada Corporation is an authorized user.
 *
 *  IST is a registered trademark of FIS Corporation.  Other brand or
 *  product names are trademarks or registered trademarks of their respective
 *  holders.
 *
 *  The information contained herein is the unpublished proprietary property
 *  of FIS.  Except as specifically authorized in writing by FIS, the
 *  holder of this document shall: i) keep all information contained herein
 *  confidential, and ii) protect the information, in whole or in part, from
 *  disclosure and dissemination to all third parties.
 *
 *  This document and the software described in it are furnished under license
 *  and may be used or copied only in accordance with the terms of such license.
 *  This document is supplied for information purposes only, is subject to
 *  change without notice, and should not be construed as a commitment by
 *  either FIS Corporation or FIS Canada Corporation.
 *
 *
 *                        MODIFICATION HISTORY                  REVIEW
 *
 *	SPR#	Who	Date	Description			Who	Date
 * ===========================================================================
 * R030491	dipa	20Apr12		Fix in accessing alt-mechant-id SHM
 */

/* File Number 156 */

static char _DNSegHelper_cxx_what[] = "@(#) DNSegHelper.cxx 1.17.3.1 20/01/30 13:01:02";

#include <stdio.h>
#include <string.h>
#include <ctype.h>
#include <oasis.h>
#include <dbm.h>
#include <mb.h>
#include <rules.h>
#include <ist_otrace.h>
#include <shc.h>
#include <shcseg.h>
#include <ShcSdkCommon.h>
#include <ShcmsgHelper.h>
#include <ShcBin.h>
#include <ShcmsgHeader.h>
#include <FMCMDHeader.h>
#include <shcmerchant.h>
#include <DNSegHelper.h>
#include <cardprod_types.h>
#include <ist_seg_elf_id_map.h>
#include <ShcAppBase.h>
#include <ist_seg_id.h>
#include <istsafe.h>

DNSegHelper *DNSegHelperObj=NULL;
int DNSegHelper::dnCardCategoryBasedOnCardPdt = -1;

DNSegHelper::DNSegHelper()
{
	rm_keyp			= NULL;
	ptr_startrec	= NULL;
	altmerchid		= NULL;
	dnSeg_ElfId		= -1;
	pid				= -1;
	tbl_fd			= -1;
	rm_appid		= -1;
	re_init();
}



// Needed this to ensure that the buffer is always
// updated but without the hustle of always destroying and creating object 
// use only if headerP was initialzed already
int	DNSegHelper::re_init()
{
	char *p;	//R030491
	char buf[3] = { 0 };

	pid 		= getpid();							// 19Apr2010

	altmerchid = NULL;
	if ( rm_appid < 0 )
	{
		rm_init();
		rm_appid = rm_getappid((char*)"pos-alt_merchant-t");
		if (rm_appid < 0)
		{
			OTraceError("E-DNSEG-00001: Unable to locate alt merch ID in shm\n");
			rm_appid = 0;				// no way shared-memory ID for this will be zero
		}
		else
		{
			rm_keyp 		= rm_getapphead(rm_appid);
			p	= rm_getappkey(rm_appid); //R030491
			if (!p)
			{
				OTraceError("E-DNSEG-00002: Error in SHM--memory possibly corrupted\n");
				rm_appid = 0;				// no way shared-memory ID for this will be zero
			}
			else
			{
				//R030491 >>>
				// -rc- pointer may be 64-bit & intptr_t is not available on older compilers
				long long x = (long long)p & POS_SHM_MASK;	
				if (x)
					p += POS_SHM_OFFSET - x;
				ptr_startrec    = (DNSHMEntry_alt_merchant_id*)p;
				//R030491 <<<
				recordSize = rm_keyp->keysize;
			}
		}	
	}	// this needs to be done only once

	if ( dnCardCategoryBasedOnCardPdt < 0 )
	{
		if(cf_open(NULL) >= 0)
		{
			cf_rewind();
			if( (cf_locate("shc.setDNCardCategoryBasedOnCardPdt", buf)) >= 0 )
			{
				if ( toupper(buf[0]) == 'Y' || buf[0] == '1' )
				{
					OTraceDebug("D-DNSEG-00001.1: Parameter shc.setDNCardCategoryBasedOnCardPdt is set on\n");
					dnCardCategoryBasedOnCardPdt = 1;
				}
				else
					dnCardCategoryBasedOnCardPdt = 0;
			}
			else
				dnCardCategoryBasedOnCardPdt = 0;
			cf_close();
		}
		else
		{
			dnCardCategoryBasedOnCardPdt = 0;
		}
	}

	return 0;

}	// re_init()



// arguments must be null-terminated
// This is technically searching for a matching entry in the shared-memory based on the
// keys (args passed).  If none if found, access the DB and read from there.  In theory,
// one should find it in the shared-memory and DB access is more of an exception condition
int DNSegHelper::setAlternateMerchantID(ShcmsgHeader *header, char* instId, char* entId, char* cdscheme)
{
	int		rec	= 0;
	int		found = 0;

	if (   !instId	 || strlen(instId)   == 0
		|| !entId	 || strlen(entId)  	 == 0
		|| !cdscheme || strlen(cdscheme) == 0 )
	{
		OTraceError("E-DNSEG-00003: Invalid arg/s detected\n");
		return -1;
	}

	if (rm_appid > 0)								// I have entries in shm
	{
		char key[sizeof(DNSHMEntry_alt_merchant_id)];
		sprintf(key, "%-10.10s%-30.30s%-2.2s", instId, entId, cdscheme);
		char *p = (char *)ptr_startrec;
		while (rec < rm_keyp->keysused)
		{
			DNSHMEntry_alt_merchant_id *tmpEntry = (DNSHMEntry_alt_merchant_id *)p;
			if( strcmp(tmpEntry->key, key)== 0)
			{
				found 	   = 1;						// found a match
				altmerchid = tmpEntry->cs_merchant_id;
				break;
			}
			p += recordSize;
			rec++;
		}
	}
	
	if ( !found )									// try DB
	{
		OTraceWarning("W-DNSEG-00004: Using DB to get alt merchant ID\n");

		if (tbl_fd < 0)
			tbl_fd = dbm_open((char*)"xpkalt_merchant_id", pid);

		memset((char*)&dbRec, 0, sizeof(ALT_MERCHANT_ID));
		//strcpy(dbRec.institution_id, instId);
		//strcpy(dbRec.entity_id, entId);
		//strcpy(dbRec.card_scheme, cdscheme);
		istsafe_strcpy(dbRec.institution_id, sizeof(dbRec.institution_id), instId);
		istsafe_strcpy(dbRec.entity_id, sizeof(dbRec.entity_id), entId);
		istsafe_strcpy(dbRec.card_scheme, sizeof(dbRec.card_scheme), cdscheme);
		if (dbm_read(tbl_fd, (char*)&dbRec, DBM_REQUAL) >= 0)
		{
			altmerchid = dbRec.cs_merchant_id;	
			found	   = 1;
		}
	}

	if (found)
	{
		header->setSegmentData((char *)altmerchid, sizeof(ptr_startrec->cs_merchant_id), DN_SEG_id, DN_ALT_MERCHANT_ID);
		return 1;
	}
	else
		return -1;
}

// 04Feb2010 - R027759
// This should be called only if dn segment initialization
// was successful
int DNSegHelper::setDNSegmentValue(ShcmsgHeader *headerP)
{
	struct shcmsg	*msg 			= &(headerP->msg);
	IstSegDN *dnObj = (IstSegDN*)headerP->getSegmentObj(DN_SEG_id, IST_SEG_CREATE);
	struct shc_data *shc_data		= (struct shc_data*)&(msg->shc_data_buffer[0]);
	long 			pan_entry_code 	= (msg->pos_entry_code & SH_POS_PINPANENTRY_MASK)/10;
	
	OTraceDebug("D-DNSEG-00005: setDNSegmentValue\n");

	dnObj->setCardType(setDNCardCategory(headerP));

	// Following fields not populated:
	//		alt_terminal_id
	//		alt_merchant_id
	//		issuer_proc_id
	//		debit_proc_busday
	
	if (!dnObj->getClerkID())
		dnObj->setClerkID(msg->checker_id);
	
	const char *p2 = dnObj->getShclogID();
	if (!p2 or !p2[0])
		dnObj->setShclogID(msg->shclog_id);
	
	const char *p3 = dnObj->getPOSGeoLocation();
	if (!p3 or !p3[0])
		dnObj->setPOSGeoLocation(msg->pos_geo_loc);
	
	const char *p4 = dnObj->getDeviceType();
	if (!p4 or !p4[0])
	{
		if (msg->merchant_type == 6011)
			dnObj->setDeviceType("ATM");
		else
			dnObj->setDeviceType("POS");
	}

	//R029567 >>>
	const char *p5 = dnObj->getAcquiringChannel();
	if(!p5 or !p5[0])
	{
		if (msg->merchant_type == 6011)
			dnObj->setAcquiringChannel("02");
		else 
			dnObj->setAcquiringChannel("01");
	}
	//R029567 <<<
	
	// now copy back the data to the segment object
//	istSegDNObj->unflattenSegMemcpy((char*)&dnseg_rec, sizeof(dnseg_rec));
//	msg->device_cap |= SH_DEVCAP_USER_SEGMENT;

	return 0;
}


// 04Feb2010 - R027759
// Added because this will be used more than once
char DNSegHelper::setDNCardCategory(ShcmsgHeader *headerP)
{
	struct shcmsg	*msg 			= &(headerP->msg);
	IstSegDN *dnObj = (IstSegDN *)headerP->getSegmentObj(DN_SEG_id, IST_SEG_CREATE);
	struct shc_data *shc_data		= (struct shc_data*)&(msg->shc_data_buffer[0]);
	long 			pan_entry_code 	= (msg->pos_entry_code & SH_POS_PINPANENTRY_MASK)/10;
	char			card_category   = ' ';				// space
	char *p = NULL;
	int CardProdAppid =0;
	struct rules_keytab *appHead;
	struct card_product *ptrCardProd =  NULL;


	OTraceDebug("D-DNSEG-00006: setDNCardCategory\n");

    if ( dnCardCategoryBasedOnCardPdt )
	{
		rm_init();
		if((CardProdAppid = rm_getappid("card-product")) < 0)
		{
			OTraceWarning ("W-DNSEG-00006.1 Unable to locate appid for card-product...fallback to existing logic of deriving card category \n");
		}
		else
		{
			if ( rm_attach (CardProdAppid, RULES_VER_CURRENT) != 0 )
			{
				OTraceWarning("W-DNSEG-00006.2 Unable to attach to CURRENT version for card-product...fallback to existing logic of deriving card category \n");
			}
			else
			{
				appHead  =  rm_getapphead(CardProdAppid);
				p = rm_getappkey(CardProdAppid);
				if ( p ==  NULL )
				{
					OTraceWarning("W-DNSEG-00006.3 Unable to get appkey for card-product...fallback to existing logic of deriving card category \n");
				}
				else
				{
					for ( int  i=0; i < appHead->keysused; p+=appHead->keysize,i++)
					{
						ptrCardProd = ( struct card_product*)p;
						if ( strcmp(ptrCardProd->CardProduct ,msg->cardProduct) == 0 )
						{
							card_category = ptrCardProd->CardType[0];
							OTraceDebug("D-DNSEG-00006.4 Setting Card Category[%c] from card-product\n",card_category);
							return card_category;
						}
					}
				}
			}
		}
	}
	
	// it is expected that if coming from voice_auth app, device_type was set accordingly
	const char *deviceType = dnObj->getDeviceType();
	if (deviceType && (stricmp(deviceType, (char*)VOICE_AUTHORIZATION) == 0))
		card_category = CREDIT_CARDCATEGORY;
	else
	if (pan_entry_code != SH_POS_PANENTRY_ECOMMERCE)	
	{
		// if(msg->pos_condition_code & SH_POS_COND_CREDIT_TXN)
		if(msg->txntype & SH_TX_CREDIT || msg->txntype & SH_TX_CC)
		{
			OTraceDebug("D-DNSEG-00007:Set CR/DB Value Got a credit transaction\n");
			if(shc_data->network_data[OFFSET_SDI] == SIGNATURE_DEBIT)
				card_category = SIGNATURE_DEBIT;
			else
				card_category = CREDIT_CARDCATEGORY;
		}
		else
		if(msg->txntype & SH_TX_DEBIT)
		{
			OTraceDebug("D-DNSEG-00008:CR/DB Value: Got a debit transaction(%d)(%d)(%p)\n",
						 msg->msgtype, msg->flipped_msgtype, msg->txntype);
			card_category = DEBIT_CARDCATEGORY;
		}
		else			// life is never easy -- this next test is not perfect
		if (strlen(msg->pin) == 0)
		{
			OTraceDebug("D-DNSEG-00009: db/cr flag not set--pin block is empty--set to credit\n");
			if(shc_data->network_data[OFFSET_SDI] == SIGNATURE_DEBIT)
				card_category = SIGNATURE_DEBIT;
			else
				card_category = CREDIT_CARDCATEGORY;
		}
		else			// maybe this is debit
		{	// if this was a reversal, it will be overridden later to go to
			// where the original txn was sent
			OTraceDebug("D-DNSEG-00010:CR/DB Value: Got a debit transaction(%d)(%d)\n",
						 msg->msgtype, msg->flipped_msgtype);
			card_category = DEBIT_CARDCATEGORY;
		}
	}
	else
	if (   strlen(msg->pin) == 0
		&& shc_data->network_data[OFFSET_SDI] == SIGNATURE_DEBIT )
	{
		OTraceDebug("D-DNSEG-00011:CR/DB Value: Got a signature debit transaction\n");
		card_category = SIGNATURE_DEBIT;
	}
	else
	if(   (msg->shc_devcap & SH_DEVCAP_SHC_PIN_BASED)
	   || (msg->pin[0])
	   || (msg->merchant_type == 6011)
	  )
		card_category = DEBIT_CARDCATEGORY;
	else
	{
		if(shc_data->network_data[OFFSET_SDI] == SIGNATURE_DEBIT)
			card_category = SIGNATURE_DEBIT;
		else
			card_category = CREDIT_CARDCATEGORY;
	}

	return card_category;
}

