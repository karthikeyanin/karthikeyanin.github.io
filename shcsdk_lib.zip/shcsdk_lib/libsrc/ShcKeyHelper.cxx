static char _ShcKey_what[] = "@(#) ShcKeyHelper.cxx 1.14.10.2 19/11/20 03:28:41";

/*
 *  Copyright (C) 2004 eFunds Corporation ("eFunds").  All Rights Reserved.     
 *  eFunds Canada Corporation is an authorized user.                            
 *                                                                              
 *  IST is a registered trademark of eFunds Corporation.  Other brand or        
 *  product names are trademarks or registered trademarks of their respective   
 *  holders.                                                                    
 *                                                                              
 *  The information contained herein is the unpublished proprietary property    
 *  of eFunds.  Except as specifically authorized in writing by eFunds, the     
 *  holder of this document shall: i) keep all information contained herein     
 *  confidential, and ii) protect the information, in whole or in part, from    
 *  disclosure and dissemination to all third parties.                          
 *                                                                          
 *  This document and the software described in it are furnished under license  
 *  and may be used or copied only in accordance with the terms of such license.
 *  This document is supplied for information purposes only, is subject to      
 *  change without notice, and should not be construed as a commitment by       
 *  either eFunds Corporation or eFunds Canada Corporation. 
 *
 *
 *
 *                        MODIFICATION HISTORY                  REVIEW
 *
 *	SPR#	Who	Date	Description			Who	Date   
 * ===========================================================================
 * R015209 Emj 01Dec05  Support for double and triple length MAC keys for Racal
 * R016654 Emj 19Jun06  Use Institutionid specified in shckeys_buf 
 * R017808 Emj 22Sep06  Broadcast change of shckeys to other nodes
 * R026021 sel 18Feb09	Key sync change; modified broadcast fn call
 * R029171 Emj 03Mar11  Use Institutionid and userbinid for shckeys table
 * R030556 Dipa	13Jun12	SHM versioning b/w compatibility - renaming arguments from keyparam to keyparamStr
 */


/* File Number 27 */
#include <algorithm>
#include <stdio.h>
#include <string.h>
#include <ctype.h>
#include <oasis.h>
#include <oasisenv.h>
#include <shcmsgdef.h>
#include <dbm_private.h>
#include <istsafe.h>
/*
#include <dbm.h>
#include <oc/oc_string.h>
#include <Ccard_scheme.h>
#include <Cinstitution.h>
#include <rules.h>
#include <shcauthnum.h>
#include <shcpreauth.h>
#include <ic/ic_shcmsg.h>
#include <emvchipcond.h>
#include <ShcSender.h>
#include <istcurrency.h>
#include <shc500std.h>
#include <ShcmsgHelper.h>
*/
#include <ist_otrace.h>
#include <ic/ic_instid.h>
#include <rules.h>
#include <shc.h>
#include <shcextbuf.h>
#include <security.h>
#include <shcfmt.h>

#include <ShcSdkCommon.h>
#include <ShcBin.h>
#include <ShcKeyHelper.h>
#include <ShcDKEHelper.h>
#include <ShcMacHelper.h>
#include <ShcmsgHelper.h>
//#include <ShcNetworkMsgFunc.h>
#include <ShcAppBase.h>
#include <UpdateMemHelper.h>
#include <ShckeyParamsList.h>

#include <HaPtmCctHelper.h>
#include <ShcSharedMemoryHelper.h>

#include <ist_seg_name.h>
#include <ist_seg_elf_id_map.h>
#include <ist_seg_id.h>

#include <ist_seg_msg_replication_data.h>
#include <ShcKeysMRHelper.h>
#include <InstProfile.h>
#include <switch_state_apis.h>

#include <ShcAsynchApi.h>
#include <asynchSecApi.h>

#define KEYLEN 160
#define KEYLEN_AS2805	32
extern  int shcIsAsynchSecMode();

struct rules_keytab *pShckeyAppHead = NULL;

static char sec_dev_name[50];

KeyXchgHelper *keyXchgHelpObj=NULL;

static char *getSecDeviceType()
{

        static int init_val = 0;
        if ( init_val )
                return sec_dev_name;

        memset(sec_dev_name, 0x00, sizeof(sec_dev_name));
        if ( cf_locate(( char * ) "sec.device", sec_dev_name ) < 0 )
        {
                OTraceInfo("L-SEC-0102:security device  is not configured\n");
        }
        OTraceInfo("L-SEC-0103:security device is <%s>\n", sec_dev_name);

        init_val = -1;
        return sec_dev_name;
}

bool isKeyBlockDevice()
{

        char device_name[50];

        memset(device_name, 0x00, sizeof(device_name));
        strcpy(device_name, getSecDeviceType());

        if( strcmp(device_name, RACAL_NAME_KB) == 0)
                return true;
        else if( strcmp(device_name, ERACOM_NAME_KB) == 0)
                return true;
        else if( strcmp(device_name, EXCRYPT_NAME_KB) == 0)
                return true;
        else
                return false;
}

int ShcKeyHelper::shc_keys_init()
{
	static int	init = 0;

	if( init )
		return( 0 );

	ShckeyParamsList shckeyParamsList;
	shcApp->shckeyParams.Load(shckeyParamsList);
	
	init = 1;	
	return( 0 );
}

void ShckeyParamsList::Load()
{
	char 		xbuf[256];

	HaPtmCctHelper::addHandler( "system.dcs.shc" ) ;

	shccfg.def_class = 'A';
	if( cf_locate("shc.keys_default_class", xbuf) > 0
		&& strchr("NAIB", *xbuf) )
		shccfg.def_class = xbuf[0];
 
	shccfg.def_index = '2';
	if( cf_locate("shc.keys_default_index", xbuf) > 0
		&& strchr("123", *xbuf) )
		shccfg.def_index = xbuf[0];
 
	shccfg.val_new = 'N';
	if( cf_locate("shc.keys_validate_new", xbuf) > 0 && strchr("YN", xbuf[0]) )
		shccfg.val_new = xbuf[0];

	shccfg.val_seq = 'N';
	if( cf_locate("shc.keys_validate_seq", xbuf) > 0 && strchr("YN", xbuf[0]) )
		shccfg.val_seq = xbuf[0];

	shccfg.val_chk = 'N';
	if( cf_locate("shc.keys_validate_chk", xbuf) > 0 && strchr("YN", xbuf[0]) )
		shccfg.val_chk = xbuf[0];

	shccfg.upd_tbl = 'F';
	if( cf_locate("shc.keys_update_table", xbuf) > 0 && strchr("FIN", xbuf[0]) )
		shccfg.upd_tbl = xbuf[0];

	shccfg.clr_all = 'N';
	if( cf_locate("shc.keys_clear_all", xbuf) > 0 && strchr("YN", xbuf[0]) )
		shccfg.clr_all = xbuf[0];

    /* R000573 > */
    memset(shccfg.tkpe, 0, IST_SECURITY_KEY_SZ + 1);
    if( cf_locate("shc.keys_terminal_racal", xbuf) > 0 )
        memcpy(shccfg.tkpe, xbuf, IST_SECURITY_KEY_SZ);
    else
        OTraceError("E-SHC-027001: MAC key not defined\n");
    /* R000573 < */

	memset(shccfg.tkr_double, 0, 32 + 1);
	if( cf_locate("shc.keys_terminal_racal_double", xbuf) > 0 )
		memcpy(shccfg.tkr_double, xbuf, 32);
	else
		OTraceError("E-SHC-9300: Double length MAC key not defined\n");

	memset(shccfg.tkr_triple, 0, 48 + 1);
	if( cf_locate("shc.keys_terminal_racal_triple", xbuf) > 0 )
		memcpy(shccfg.tkr_triple, xbuf, 48);
	else
		OTraceError("E-SHC-9300: Triple Length MAC key not defined\n");

}

/*============================================================================*/
/*
 * Non-Interac Version APIs
 */
/*============================================================================*/

/*
 *  R001654. 
 */
int ShcKeyHelper::shc_keys_set_class( char key_class, char *dest )
{
	OTraceDebug("D-SHC-9300: key_class value = %c\n", key_class );
	switch( key_class )
	{
		case SH_KEYTYPE_PIN_ACQ:
		case SH_KEYTYPE_PIN_ISS:
		case SH_KEYTYPE_PIN_BOTH:
			dest[0] = key_class;
			break;	

		default:
			char tmpKeyClass = shcApp->shckeyParamsList->getShccfg()->def_class;
			if( tmpKeyClass == 'N' )
				return( -1 );

			dest[0] = tmpKeyClass;
			break;
	}	


	return( 0 );
}

int ShcKeyHelper::shc_keys_set_type( char type, char *dest )
{
	/* Determine key index */
	switch( type )
	{
		case SH_KEYTYPE_PIN:
		case SH_KEYTYPE_MAC:
		case SH_KEYTYPE_KME:
			dest[0] = type;
			break;	

		default:
			dest[0] = SH_KEYTYPE_PIN;							/* R000593 */
			break;												/* R000593 */
	}	

	return( 0 );
}

int ShcKeyHelper::shc_keys_set_index( char index, char *dest )
{
	switch( index )
	{
		case '1':
		case '2':
		case '3':
			dest[0] = index;
			break;	
	
		default:
			dest[0] = shcApp->shckeyParamsList->getShccfg()->def_index;
			break;
	}	

	return( 0 );
}


/* 
 *  R001654.
 */
int ShcKeyHelper::shc_keys_init_buf(  struct shckey_buf *bufp, char key_class, char type, char index )
{
	shc_keys_init();

	bufp->change = 'F';

	shcApp->shckeyParamsList = (ShckeyParamsList *)shcApp->shckeyParams.getInst(bufp->keyp->k.institutionid);

	if( shcApp->shcKeyObj->shc_keys_set_class(key_class, &bufp->key_class) < 0 )
	{
		OTraceError("E-SHC-027003: Invalid key class [x%X]\n", (int)key_class);
		return( SHC_RC_MessageFormatError );
	}

	if( shcApp->shcKeyObj->shc_keys_set_type(type, &bufp->type) < 0 )
	{
		OTraceError("E-SHC-027004: Invalid key type [x%X]\n", (int)type);
		return( SHC_RC_MessageFormatError );
	}

	if( shcApp->shcKeyObj->shc_keys_set_index(index, &bufp->index) < 0 )
	{
		OTraceError("E-SHC-027005: Invalid index value [x%X]\n", (int)index);
		return( SHC_RC_MessageFormatError );
	}

	shc_keys_get_pointers(bufp, bufp->index - '0');	/* R002203 */

	return( SHC_RC_Approved );
}

int ShcKeyHelper::shc_keys_set_status(struct shckey_buf *bufp, char status)
{
	int isLocked = 0;
	int t_acqpinidx = 0,t_isspinidx = 0,t_acqmacidx = 0,t_issmacidx = 0,t_acqkmeidx = 0,t_isskmeidx = 0;
	char t_acqkekstat,t_acqpin1stat,t_acqmac1stat,t_acqkme1stat,t_acqpin2stat,t_acqmac2stat,t_acqkme2stat,t_acqpin3stat,t_acqmac3stat,t_acqkme3stat;
	char t_isskekstat,t_isspin1stat,t_issmac1stat,t_isskme1stat,t_isspin2stat,t_issmac2stat,t_isskme2stat,t_isspin3stat,t_issmac3stat,t_isskme3stat;

	t_acqpinidx = bufp->keyp->k.acqpinidx;
	t_isspinidx = bufp->keyp->k.isspinidx;
	t_acqmacidx = bufp->keyp->k.acqmacidx;
	t_issmacidx = bufp->keyp->k.issmacidx;
	t_acqkmeidx = bufp->keyp->k.acqkmeidx;
	t_isskmeidx = bufp->keyp->k.isskmeidx;

	t_acqkekstat = bufp->keyp->k.acqkekstat;
	t_acqpin1stat = bufp->keyp->k.acqpin1stat;
	t_acqmac1stat = bufp->keyp->k.acqmac1stat;
	t_acqkme1stat = bufp->keyp->k.acqkme1stat;
	t_acqpin2stat = bufp->keyp->k.acqpin2stat;
	t_acqmac2stat = bufp->keyp->k.acqmac2stat;
	t_acqkme2stat = bufp->keyp->k.acqkme2stat;
	t_acqpin3stat = bufp->keyp->k.acqpin3stat;
	t_acqmac3stat = bufp->keyp->k.acqmac3stat;
	t_acqkme3stat = bufp->keyp->k.acqkme3stat;

	t_isskekstat = bufp->keyp->k.isskekstat;
	t_isspin1stat = bufp->keyp->k.isspin1stat;
	t_issmac1stat = bufp->keyp->k.issmac1stat;
	t_isskme1stat = bufp->keyp->k.isskme1stat;
	t_isspin2stat = bufp->keyp->k.isspin2stat;
	t_issmac2stat = bufp->keyp->k.issmac2stat;
	t_isskme2stat = bufp->keyp->k.isskme2stat;
	t_isspin3stat = bufp->keyp->k.isspin3stat;
	t_issmac3stat = bufp->keyp->k.issmac3stat;
	t_isskme3stat = bufp->keyp->k.isskme3stat;

	
	shcSharedMemoryHelperObj->lockRule(sharedCashSecurityRuleName, &isLocked, &shcSecurityAppid);
	gShckeysSetDBLock = SHCKEYS_DB_LOCK;
	shcApp->shcBinObj->shckeys_Dbm2Mem(bufp->keyp);

	bufp->keyp->k.acqpinidx = t_acqpinidx;
	bufp->keyp->k.isspinidx = t_isspinidx;
	bufp->keyp->k.acqmacidx = t_acqmacidx;
	bufp->keyp->k.issmacidx = t_issmacidx;
	bufp->keyp->k.acqkmeidx = t_acqkmeidx;
	bufp->keyp->k.isskmeidx = t_isskmeidx;

	bufp->keyp->k.acqkekstat = t_acqkekstat;
	bufp->keyp->k.acqpin1stat = t_acqpin1stat;
	bufp->keyp->k.acqmac1stat = t_acqmac1stat;
	bufp->keyp->k.acqkme1stat = t_acqkme1stat;
	bufp->keyp->k.acqpin2stat = t_acqpin2stat;
	bufp->keyp->k.acqmac2stat = t_acqmac2stat;
	bufp->keyp->k.acqkme2stat = t_acqkme2stat;
	bufp->keyp->k.acqpin3stat = t_acqpin3stat;
	bufp->keyp->k.acqmac3stat = t_acqmac3stat;
	bufp->keyp->k.acqkme3stat = t_acqkme3stat;

	bufp->keyp->k.isskekstat = t_isskekstat;
	bufp->keyp->k.isspin1stat = t_isspin1stat;
	bufp->keyp->k.issmac1stat = t_issmac1stat;
	bufp->keyp->k.isskme1stat = t_isskme1stat;
	bufp->keyp->k.isspin2stat = t_isspin2stat;
	bufp->keyp->k.issmac2stat = t_issmac2stat;
	bufp->keyp->k.isskme2stat = t_isskme2stat;
	bufp->keyp->k.isspin3stat = t_isspin3stat;
	bufp->keyp->k.issmac3stat = t_issmac3stat;
	bufp->keyp->k.isskme3stat = t_isskme3stat;

	
	if( bufp->astatp )
	{
		*bufp->astatp = status;	//HA
		bufp->change = 'T';
	}

	if( bufp->istatp )
	{
		*bufp->istatp = status; //HA
		bufp->change = 'T';
	}

	shcSharedMemoryHelperObj->updateCurrentVersion(sharedCashSecurityRuleName, isLocked, 
				shcSecurityAppid, (char *)&bufp->keyp->k, sizeof(bufp->keyp->k));

        //ShcKeysMRHelper::getInstance()->setMRDataUnique(bufp, status);

	return( shc_keys_upd_db(bufp) );
}

int ShcKeyHelper::shc_keys_set_status_as2805(struct shckey_buf *bufp, char status, int device_flag )
{
	int isLocked = 0;
	int t_acqpinidx = 0,t_isspinidx = 0,t_acqmacidx = 0,t_issmacidx = 0,t_acqkmeidx = 0,t_isskmeidx = 0;
	char t_acqkekstat,t_acqpin1stat,t_acqmac1stat,t_acqkme1stat,t_acqpin2stat,t_acqmac2stat,t_acqkme2stat,t_acqpin3stat,t_acqmac3stat,t_acqkme3stat;
	char t_isskekstat,t_isspin1stat,t_issmac1stat,t_isskme1stat,t_isspin2stat,t_issmac2stat,t_isskme2stat,t_isspin3stat,t_issmac3stat,t_isskme3stat;

	char t_isspin1cnt[20+1];
	char t_isspin2cnt[20+1];
	char t_isspin3cnt[20+1];
	char t_acqpin1cnt[20+1];
	char t_acqpin2cnt[20+1];
	char t_acqpin3cnt[20+1];
	t_acqpinidx = bufp->keyp->k.acqpinidx;
	t_isspinidx = bufp->keyp->k.isspinidx;
	t_acqmacidx = bufp->keyp->k.acqmacidx;
	t_issmacidx = bufp->keyp->k.issmacidx;
	t_acqkmeidx = bufp->keyp->k.acqkmeidx;
	t_isskmeidx = bufp->keyp->k.isskmeidx;

	t_acqkekstat = bufp->keyp->k.acqkekstat;
	t_acqpin1stat = bufp->keyp->k.acqpin1stat;
	t_acqmac1stat = bufp->keyp->k.acqmac1stat;
	t_acqkme1stat = bufp->keyp->k.acqkme1stat;
	t_acqpin2stat = bufp->keyp->k.acqpin2stat;
	t_acqmac2stat = bufp->keyp->k.acqmac2stat;
	t_acqkme2stat = bufp->keyp->k.acqkme2stat;
	t_acqpin3stat = bufp->keyp->k.acqpin3stat;
	t_acqmac3stat = bufp->keyp->k.acqmac3stat;
	t_acqkme3stat = bufp->keyp->k.acqkme3stat;

	t_isskekstat = bufp->keyp->k.isskekstat;
	t_isspin1stat = bufp->keyp->k.isspin1stat;
	t_issmac1stat = bufp->keyp->k.issmac1stat;
	t_isskme1stat = bufp->keyp->k.isskme1stat;
	t_isspin2stat = bufp->keyp->k.isspin2stat;
	t_issmac2stat = bufp->keyp->k.issmac2stat;
	t_isskme2stat = bufp->keyp->k.isskme2stat;
	t_isspin3stat = bufp->keyp->k.isspin3stat;
	t_issmac3stat = bufp->keyp->k.issmac3stat;
	t_isskme3stat = bufp->keyp->k.isskme3stat;

	istsafe_strcpy( t_isspin1cnt, sizeof(t_isspin1cnt), bufp->keyp->k.isspin1cnt );
	istsafe_strcpy( t_isspin2cnt, sizeof(t_isspin2cnt), bufp->keyp->k.isspin2cnt );
	istsafe_strcpy( t_isspin3cnt, sizeof(t_isspin3cnt), bufp->keyp->k.isspin3cnt );
	istsafe_strcpy( t_acqpin1cnt, sizeof(t_acqpin1cnt), bufp->keyp->k.acqpin1cnt );
	istsafe_strcpy( t_acqpin2cnt, sizeof(t_acqpin2cnt), bufp->keyp->k.acqpin2cnt );
	istsafe_strcpy( t_acqpin3cnt, sizeof(t_acqpin3cnt), bufp->keyp->k.acqpin3cnt );
	
	shcSharedMemoryHelperObj->lockRule(sharedCashSecurityRuleName, &isLocked, &shcSecurityAppid);
	gShckeysSetDBLock = SHCKEYS_DB_LOCK;
	if (shcApp->shcBinObj->shckeys_Dbm2Mem(bufp->keyp) < 0)
	{
		if (isLocked)
			rm_appUnlockMemory(shcSecurityAppid);
		return -1;
	}

	bufp->keyp->k.acqpinidx = t_acqpinidx;
	bufp->keyp->k.isspinidx = t_isspinidx;
	bufp->keyp->k.acqmacidx = t_acqmacidx;
	bufp->keyp->k.issmacidx = t_issmacidx;
	bufp->keyp->k.acqkmeidx = t_acqkmeidx;
	bufp->keyp->k.isskmeidx = t_isskmeidx;

	bufp->keyp->k.acqkekstat = t_acqkekstat;
	bufp->keyp->k.acqpin1stat = t_acqpin1stat;
	bufp->keyp->k.acqmac1stat = t_acqmac1stat;
	bufp->keyp->k.acqkme1stat = t_acqkme1stat;
	bufp->keyp->k.acqpin2stat = t_acqpin2stat;
	bufp->keyp->k.acqmac2stat = t_acqmac2stat;
	bufp->keyp->k.acqkme2stat = t_acqkme2stat;
	bufp->keyp->k.acqpin3stat = t_acqpin3stat;
	bufp->keyp->k.acqmac3stat = t_acqmac3stat;
	bufp->keyp->k.acqkme3stat = t_acqkme3stat;

	bufp->keyp->k.isskekstat = t_isskekstat;
	bufp->keyp->k.isspin1stat = t_isspin1stat;
	bufp->keyp->k.issmac1stat = t_issmac1stat;
	bufp->keyp->k.isskme1stat = t_isskme1stat;
	bufp->keyp->k.isspin2stat = t_isspin2stat;
	bufp->keyp->k.issmac2stat = t_issmac2stat;
	bufp->keyp->k.isskme2stat = t_isskme2stat;
	bufp->keyp->k.isspin3stat = t_isspin3stat;
	bufp->keyp->k.issmac3stat = t_issmac3stat;
	bufp->keyp->k.isskme3stat = t_isskme3stat;

	istsafe_strcpy( bufp->keyp->k.isspin1cnt, sizeof(bufp->keyp->k.isspin1cnt), t_isspin1cnt );
	istsafe_strcpy( bufp->keyp->k.isspin2cnt, sizeof(bufp->keyp->k.isspin2cnt), t_isspin2cnt );
	istsafe_strcpy( bufp->keyp->k.isspin3cnt, sizeof(bufp->keyp->k.isspin3cnt), t_isspin3cnt );
	istsafe_strcpy( bufp->keyp->k.acqpin1cnt, sizeof(bufp->keyp->k.acqpin1cnt), t_acqpin1cnt );
	istsafe_strcpy( bufp->keyp->k.acqpin2cnt, sizeof(bufp->keyp->k.acqpin2cnt), t_acqpin2cnt );
	istsafe_strcpy( bufp->keyp->k.acqpin3cnt, sizeof(bufp->keyp->k.acqpin3cnt), t_acqpin3cnt );
	
	if( bufp->astatp )
	{
		*bufp->astatp = status;	//HA
		bufp->change = 'T';

		// AS2805 update
		if (device_flag==1)
		{
			if (bufp->astatp == &bufp->keyp->k.acqpin1stat)
				bufp->keyp->k.acqmac1stat = status;
			else if (bufp->astatp == &bufp->keyp->k.acqpin2stat)
				bufp->keyp->k.acqmac2stat = status;

			bufp->keyp->k.acqmacidx = bufp->keyp->k.acqpinidx;
		}

	}

	if( bufp->istatp )
	{
		*bufp->istatp = status; //HA
		bufp->change = 'T';

		// AS2805 update
		if (device_flag==1)
		{
			if (bufp->istatp == &bufp->keyp->k.isspin1stat)
				bufp->keyp->k.issmac1stat = status;
			else if (bufp->istatp == &bufp->keyp->k.isspin2stat)
				bufp->keyp->k.issmac2stat = status;

			bufp->keyp->k.issmacidx = bufp->keyp->k.isspinidx;
		}
	}

	shcSharedMemoryHelperObj->updateCurrentVersion(sharedCashSecurityRuleName, isLocked, 
				shcSecurityAppid, (char *)&bufp->keyp->k, sizeof(bufp->keyp->k));

        //ShcKeysMRHelper::getInstance()->setMRDataUnique(bufp, status);

	return( shc_keys_upd_db(bufp) );
}

int ShcKeyHelper::shc_keys_upd_db(struct shckey_buf *bufp)
{
	struct shckeys		keydb = {0};							/* 10001935 */
        int tmpi =  bufp->keyp->k.site_id;



	strcpy(keydb.institutionid, bufp->keyp->k.institutionid);
	strcpy(keydb.userbinid, bufp->keyp->k.userbinid);
	keydb.site_id = bufp->keyp->k.site_id;

	OTraceDebug("D-SHC-027031: Fetching the data using DB read operation:: shc_keys_upd_db\n");

	if(dbm_read(shckeys_getdbmfd(), (char *)&keydb, DBM_REQUAL | DBM_RLOCK) < 0)
	{
		checkDbCon();
		OTraceFatal("F-SHC-027008: Unable to locate/lock key record\n");
		if (dbm_errno == DBME_DISCONNECT)
		{
			OTraceFatal("F-SHC-027025: disconnected from database, exiting\n");
			kill(getpid(),1);
		}
		dbm_rollback(getpid());
		return(-1);
	}
	ICInstId_pure(keydb.institutionid, keydb.institutionid);

	if( dbm_write(shckeys_getdbmfd(), (char *)&bufp->keyp->k, 0) < 0 )
	{
		checkDbCon();
		OTraceFatal("F-SHC-027009: Unable to update key record\n");
		if (dbm_errno == DBME_DISCONNECT)
		{
			OTraceFatal("F-SHC-027024: disconnected from database, exiting\n");
			kill(getpid(),1);
		}
		dbm_rollback(getpid());
		return( -1 );
	}
        if (mbIsDualSite() && (keydb.flags[1] == 'S'))
        {
                //keys are shared across site, need to change record of the other site
                if (keydb.site_id == 2)
                        keydb.site_id = 1;
                else
                        keydb.site_id = 2;

                if(dbm_read(shckeys_getdbmfd(), (char *)&keydb, DBM_REQUAL | DBM_RLOCK) < 0)
                {
			checkDbCon();
                        OTraceError("E-SHC-027026: Unable to locate/lock key record site %d\n", keydb.site_id);
                        if (dbm_errno == DBME_DISCONNECT)
                        {
                                OTraceFatal("F-SHC-027028: disconnected from database, exiting\n");
                                kill(getpid(),1);
                        }
                        goto finish;
                }
                ICInstId_pure(keydb.institutionid, keydb.institutionid);

                bufp->keyp->k.site_id = keydb.site_id;
                if( dbm_write(shckeys_getdbmfd(), (char *)&bufp->keyp->k, 0) < 0 )
                {
			checkDbCon();
                        OTraceFatal("F-SHC-027029: Unable to update key record on site %d\n", keydb.site_id);
                        if (dbm_errno == DBME_DISCONNECT)
                        {
                                OTraceFatal("F-SHC-027030: disconnected from database, exiting\n");
                                kill(getpid(),1);
                        }
                }

        }
        /*      15jan96 */
        /* R008150 */
finish:
         bufp->keyp->k.site_id = tmpi;

	/*	15jan96	*/
	/* R008150 */
	if (dbm_rewind (shckeys_getdbmfd()) < 0)
	{
		OTraceFatal("F-SHC-027010: Unable to rewind table\n");
		if (dbm_errno == DBME_DISCONNECT)
		{
			OTraceFatal("F-SHC-027022: disconnected from database, exiting\n");
			kill(getpid(),1);
		}
		dbm_rollback(getpid());

		return( -1 );
	}

	if (dbm_commit(getpid()) < 0)
	{
		OTraceFatal("F-SHC-027011: Unable to rewind table\n");
		if (dbm_errno == DBME_DISCONNECT)
		{
			OTraceFatal("F-SHC-027023: disconnected from database, exiting\n");
			kill(getpid(),1);
		}
		dbm_rollback(getpid());
		return( -1 );
	}

	bufp->change = 'F';


	char cmdbuf[256];
	sprintf(cmdbuf, "shccmd keys %s %s UPDLOCAL", keydb.institutionid, keydb.userbinid);
        mcastHelperObj->broadcast("shccmd", 0, cmdbuf , strlen(cmdbuf), NULL, 0);


	return( 0 );
}

int ShcKeyHelper::shc_keys_xchg(struct shckey_buf *bufp, char *k_kpe, char *k_chk, char status )
{
	int keylen = 16;

	return (shc_keys_xchg_td(bufp, k_kpe, k_chk, status, &keylen ));
}

int ShcKeyHelper::shc_keys_xchg_td( struct shckey_buf *bufp, char *k_kpe, char *k_chk, char status, int *keylen )
{
	int keyType = 0;
	return (shc_keys_xchg_td_xt(bufp, k_kpe, k_chk, status, keylen, keyType ));
}

int ShcKeyHelper::shc_keys_xchg_td_xt( struct shckey_buf *bufp, char *k_kpe, char *k_chk, char status, int *keylen, int keyType)
{
	char keyVer = 'A';
	int atalla_var = 0;
	return (shc_keys_xchg_td_xt_xt(bufp, k_kpe, k_chk, status, keylen, keyType, keyVer, atalla_var));
}

int ShcKeyHelper::shc_keys_xchg_td_xt_xt( struct shckey_buf *bufp, char *k_kpe, char *k_chk, char status, int *keylen, int keyType, char keyVer, int atalla_var)
{
	char	k_mfk[KEYLEN + 1] = {0};
	char	c_mfk[CHECK_DIGIT_LEN_FULL + 1] = {0};
	char 		   *terminal_key_racal = NULL;
	int		ret = SHC_RC_Approved;
	int 	isLocked = 0;
	int 	isDBLocked = 0;
	int 	lockret = 0;
	char cardScheme[3] = "";
	NetworkInfo networkInfo;
	char fnStatus = status;
	ist_ElfId_t NetDataRqid=ist_ElfId_t(-1);
	int		segLen;
	//char fnStatus = SH_KEYSTAT_ACTIVE;

	memset(cardScheme,0,sizeof(cardScheme));
	if(keyXchgHelpObj==NULL)
		keyXchgHelpObj = new KeyXchgHelper();
	ret = keyXchgHelpObj->collect(*this, bufp,networkInfo,fnStatus);
	if( ret != SHC_RC_Approved )
		return( ret );

	keyXchgHelpObj->preProc(*this,bufp,networkInfo,fnStatus,keylen,(char *)cardScheme,terminal_key_racal);
	if(!isAsynchResume())
	{
		ret=keyXchgHelpObj->proc_xt_xt(bufp,k_kpe,k_chk,fnStatus,keylen,k_mfk,c_mfk,cardScheme,terminal_key_racal,keyType,keyVer,atalla_var);
		if(!ret || (ret==SEC_ASYNCH_WAIT))
		{
			return( ret );
		}
		if( (ret == SHC_RC_PINKeyError) || (ret == SHC_RC_MACSyncError) || (ret == SHC_RC_KeyValidationError) )
		{
			return( ret );
		}
	}
	else if(shcIsAsynchSecMode())
	{
		asynchParseResp(asynchSecResp.cmdId,asynchSecResp.addRsp,&asynchSecResp);
		strncpy(k_mfk,asynchSecResp.kpeMfk,asynchSecResp.lenKpe);
		strncpy(c_mfk,asynchSecResp.checkVal,CHECK_DIGIT_LEN);
	}
	ret=keyXchgHelpObj->resume(*this, bufp,k_chk,fnStatus,keylen,k_mfk,c_mfk);
	return( ret );
}


int ShcKeyHelper::shc_keys_xchg_as2805( struct shckey_buf *bufp, char *k_kpe, char *k_kpe_chk, char *k_mac, char *k_mac_chk, char *k_kme, char *k_kme_chk, char status)
{
	int keylen = 32;
	return (shc_keys_xchg_as2805_td(bufp, k_kpe, k_kpe_chk, k_mac, k_mac_chk, k_kme, k_kme_chk, status, &keylen));
}

int ShcKeyHelper::shc_keys_xchg_as2805_td( struct shckey_buf *bufp, char *k_kpe, char *k_kpe_chk, char *k_mac, char *k_mac_chk, char *k_kme, char *k_kme_chk, char status, int *keylen )
{
	int keyType = 0;
	return (shc_keys_xchg_as2805_td_xt(bufp, k_kpe, k_kpe_chk, k_mac, k_mac_chk, k_kme, k_kme_chk,  status, keylen, keyType ));
}


int ShcKeyHelper::shc_keys_xchg_as2805_td_xt( struct shckey_buf *bufp, char *k_kpe, char *k_kpe_chk, char *k_mac, char *k_mac_chk, char *k_kme, char *k_kme_chk, char status, int *keylen, int keyType )
{
	char	k_mfk_kpe[128+1] = {0};
	char	c_mfk_kpe[CHECK_DIGIT_LEN * 2] = {0};	// AS2805 check digit is 6 bytes 
	char	k_mfk_mac[128+1] = {0};
	char	c_mfk_mac[CHECK_DIGIT_LEN * 2] = {0};	// AS2805 check digit is 6 bytes 
	char	*terminal_key_racal = NULL;
	int	ret = SHC_RC_Approved;
	int 	isLocked = 0;
	int 	isDBLocked = 0;
	int 	lockret = 0;
	char cardScheme[3] = "";
	NetworkInfo networkInfo;
	char fnStatus = status;
	ist_ElfId_t NetDataRqid=ist_ElfId_t(-1);
	int	segLen;
	//char fnStatus = SH_KEYSTAT_ACTIVE;

	memset(cardScheme,0,sizeof(cardScheme));
	if(keyXchgHelpObj==NULL)
		keyXchgHelpObj = new KeyXchgHelper();
	ret = keyXchgHelpObj->collect(*this, bufp,networkInfo,fnStatus);
	if( ret != SHC_RC_Approved )
		return( ret );

	keyXchgHelpObj->preProc(*this,bufp,networkInfo,fnStatus,keylen,(char *)cardScheme,terminal_key_racal);
	if(!isAsynchResume())
	{
		OTraceInfo("I-SHC-027018: inside shc_keys_xchg_as2805_td(), call proc_as2805\n");
		ret=keyXchgHelpObj->proc_as2805(bufp, k_kpe, k_kpe_chk, k_mac, k_mac_chk, k_kme, k_kme_chk, fnStatus, keylen,
							k_mfk_kpe, c_mfk_kpe, k_mfk_mac, c_mfk_mac, cardScheme, terminal_key_racal);
		if(!ret || (ret==SEC_ASYNCH_WAIT))
		{
			return( ret );
		}
	}
	else if(shcIsAsynchSecMode())
	{
		asynchParseResp(asynchSecResp.cmdId,asynchSecResp.addRsp,&asynchSecResp);
		strncpy(k_mfk_kpe,asynchSecResp.kpeMfk,asynchSecResp.lenKpe);
		strncpy(k_mfk_mac,asynchSecResp.kpeMfk,asynchSecResp.lenKpe);
		strncpy(c_mfk_kpe,asynchSecResp.checkVal,CHECK_DIGIT_LEN);
		strncpy(c_mfk_mac,asynchSecResp.checkVal,CHECK_DIGIT_LEN);
	}
	OTraceInfo("I-SHC-027019: inside shc_keys_xchg_as2805_td(), call resume_as2805()\n");
	ret=keyXchgHelpObj->resume_as2805(*this, bufp, k_kpe_chk, k_mac_chk, fnStatus, keylen, k_mfk_kpe, c_mfk_kpe, k_mfk_mac, c_mfk_mac);
	return( ret );
}


int ShcKeyHelper::shc_keyidx(struct shckeys *shckeys)
{
	/*
	 * R001835 
	 */
	OTraceDebug("D-SHC-027018: AcqPinIdx (%d)\n", shckeys->acqpinidx); 
	OTraceDebug("          : IssPinIdx (%d)\n", shckeys->isspinidx); 
	OTraceDebug("          : AcqMacIdx (%d)\n", shckeys->acqmacidx); 
	OTraceDebug("          : IssMacIdx (%d)\n", shckeys->issmacidx); 
	return ( 0 );
}

/*
 * qd 15sep98 R001283 
 *
 *    This function will get the key pointers by bufp->type and p_keyidx
 *    It was introduced because shc_keys_set_pointers() is destructive
 */
int ShcKeyHelper::shc_keys_get_pointers(struct shckey_buf *bufp, short p_keyidx)
{
	bufp->akeyp = bufp->achkp = bufp->astatp = NULL;
	bufp->ikeyp = bufp->ichkp = bufp->istatp = NULL;

	bufp->keklen = &bufp->keyp->k.kek_len;

	/* Set index pointers to shared memory */
	switch( bufp->type )
	{
		case SH_KEYTYPE_PIN:
			bufp->aidxp = &bufp->keyp->k.acqpinidx;
			bufp->iidxp = &bufp->keyp->k.isspinidx;
			bufp->ikeylen = &bufp->keyp->k.isskpe_len;
			bufp->akeylen = &bufp->keyp->k.acqkpe_len;
			strcpy(bufp->ctype, "PIN");
			break;

		case SH_KEYTYPE_MAC:
			bufp->aidxp = &bufp->keyp->k.acqmacidx;
			bufp->iidxp = &bufp->keyp->k.issmacidx;
			bufp->ikeylen = &bufp->keyp->k.issmac_len;
			bufp->akeylen = &bufp->keyp->k.acqmac_len;
			strcpy(bufp->ctype, "MAC");
			break;

		case SH_KEYTYPE_KME:
			bufp->aidxp = &bufp->keyp->k.acqkmeidx;
			bufp->iidxp = &bufp->keyp->k.isskmeidx;
			bufp->ikeylen = &bufp->keyp->k.isskme_len;
			bufp->akeylen = &bufp->keyp->k.acqkme_len;
			strcpy(bufp->ctype, "KME");
			break;
	}

	
	/* Set key pointers to shared memory */
	if( shcChangeAcqKeys(bufp->key_class) )
	{
		switch( bufp->type )
		{
			case SH_KEYTYPE_PIN:	/* Acquirer PIN keys */
				switch( p_keyidx )
				{
					case 1:
						bufp->akeyp = bufp->keyp->k.acqpin1;
						bufp->achkp = bufp->keyp->k.acqpin1chk;
						bufp->astatp = &bufp->keyp->k.acqpin1stat;
						break;
				
					case 2:
						bufp->akeyp = bufp->keyp->k.acqpin2;
						bufp->achkp = bufp->keyp->k.acqpin2chk;
						bufp->astatp = &bufp->keyp->k.acqpin2stat;
						break;
				
					case 3:
						bufp->akeyp = bufp->keyp->k.acqpin3;
						bufp->achkp = bufp->keyp->k.acqpin3chk;
						bufp->astatp = &bufp->keyp->k.acqpin3stat;
						break;
				}
				break;

			case SH_KEYTYPE_MAC:	/* Acquirer MAC keys */
				switch( p_keyidx )
				{
					case 1:
						bufp->akeyp = bufp->keyp->k.acqmac1;
						bufp->achkp = bufp->keyp->k.acqmac1chk;
						bufp->astatp = &bufp->keyp->k.acqmac1stat;
						break;
				
					case 2:
						bufp->akeyp = bufp->keyp->k.acqmac2;
						bufp->achkp = bufp->keyp->k.acqmac2chk;
						bufp->astatp = &bufp->keyp->k.acqmac2stat;
						break;
				
					case 3:
						bufp->akeyp = bufp->keyp->k.acqmac3;
						bufp->achkp = bufp->keyp->k.acqmac3chk;
						bufp->astatp = &bufp->keyp->k.acqmac3stat;
						break;
				}
				break;

			case SH_KEYTYPE_KME:	/* Acquirer KME keys */
				switch( p_keyidx )
				{
					case 1:
						bufp->akeyp = bufp->keyp->k.acqkme1;
						bufp->achkp = bufp->keyp->k.acqkme1chk;
						bufp->astatp = &bufp->keyp->k.acqkme1stat;
						break;
				
					case 2:
						bufp->akeyp = bufp->keyp->k.acqkme2;
						bufp->achkp = bufp->keyp->k.acqkme2chk;
						bufp->astatp = &bufp->keyp->k.acqkme2stat;
						break;
				
					case 3:
						bufp->akeyp = bufp->keyp->k.acqkme3;
						bufp->achkp = bufp->keyp->k.acqkme3chk;
						bufp->astatp = &bufp->keyp->k.acqkme3stat;
						break;
				}
				break;
		}
	}

	if( shcChangeIssKeys(bufp->key_class) )
	{
		switch( bufp->type )
		{
			case SH_KEYTYPE_PIN:	/* Acquirer PIN keys */
				switch(p_keyidx )
				{
					case 1:
						bufp->ikeyp = bufp->keyp->k.isspin1;
						bufp->ichkp = bufp->keyp->k.isspin1chk;
						bufp->istatp = &bufp->keyp->k.isspin1stat;
						break;
				
					case 2:
						bufp->ikeyp = bufp->keyp->k.isspin2;
						bufp->ichkp = bufp->keyp->k.isspin2chk;
						bufp->istatp = &bufp->keyp->k.isspin2stat;
						break;
				
					case 3:
						bufp->ikeyp = bufp->keyp->k.isspin3;
						bufp->ichkp = bufp->keyp->k.isspin3chk;
						bufp->istatp = &bufp->keyp->k.isspin3stat;
						break;
				}
				break;

			case SH_KEYTYPE_MAC:	/* Acquirer MAC keys */
				switch( p_keyidx )
				{
					case 1:
						bufp->ikeyp = bufp->keyp->k.issmac1;
						bufp->ichkp = bufp->keyp->k.issmac1chk;
						bufp->istatp = &bufp->keyp->k.issmac1stat;
						break;
				
					case 2:
						bufp->ikeyp = bufp->keyp->k.issmac2;
						bufp->ichkp = bufp->keyp->k.issmac2chk;
						bufp->istatp = &bufp->keyp->k.issmac2stat;
						break;
				
					case 3:
						bufp->ikeyp = bufp->keyp->k.issmac3;
						bufp->ichkp = bufp->keyp->k.issmac3chk;
						bufp->istatp = &bufp->keyp->k.issmac3stat;
						break;
				}
				break;

			case SH_KEYTYPE_KME:	/* Acquirer MAC keys */
				switch( p_keyidx )
				{
					case 1:
						bufp->ikeyp = bufp->keyp->k.isskme1;
						bufp->ichkp = bufp->keyp->k.isskme1chk;
						bufp->istatp = &bufp->keyp->k.isskme1stat;
						break;
				
					case 2:
						bufp->ikeyp = bufp->keyp->k.isskme2;
						bufp->ichkp = bufp->keyp->k.isskme2chk;
						bufp->istatp = &bufp->keyp->k.isskme2stat;
						break;
				
					case 3:
						bufp->ikeyp = bufp->keyp->k.isskme3;
						bufp->ichkp = bufp->keyp->k.isskme3chk;
						bufp->istatp = &bufp->keyp->k.isskme3stat;
						break;
				}
				break;
		}
	}
	OTraceDebug( "D-SHC-299200 shc_keys_get_pointers value of key_class=%c, p_keyidx=%d\n",
					bufp->key_class, p_keyidx );

	return( 0 );
}

/*
 * R001835 Interac version APIs 
 */

int ShcKeyHelper::shckeys_getnext_index(char *instid, char *key_index )
{
	shc_keys_init();
	shcApp->shckeyParamsList = (ShckeyParamsList *)shcApp->shckeyParams.getInst(instid);

	*key_index = *key_index + 1;

    if( *key_index < '1' || *key_index > shcApp->shckeyParamsList->getShccfg()->def_index )
        *key_index = '1';

    return( 0 );
}


/* R000587 > */
int ShcKeyHelper::shc_counter_check( char *buf )
{
	int i = 0;

	for( i = 0; i < KEY_CNT_LEN; i++ )
		if( ! isdigit(buf[i]) )
			buf[i] = '0';

	return( 0 );
}

int ShcKeyHelper::shc_counter_inc( char *buf )
{
	char *p;

	p = (char *)strchr(buf, '\0');
	for( --p; p >= buf; --p )
	{
		(*p)++;
		if( *p <= '9' )
			break;
		
		*p -= 10;
	}

	return( 0 );
}
/* R000587 < */


int ShcKeyHelper::shckeys_getdbmfd()
{
	static int 			sec_fd = -1; 	

	if( sec_fd < 0 )
		if( (sec_fd = dbm_open("shckeys_2", getpid())) < 0 )
			OTraceFatal("F-SHC-027019:Unable to open database 'shckeys_2': error:%d\n",
				dbm_errno);

	return( sec_fd );
}

int ShcKeyHelper::getKeyParam(const char *instId, const char *keyparamStr)
{
	long hashValue = getHashValue(keyparamStr);

	if (shcSharedMemoryHelperObj->attachCurrent(&shcSecurityAppid, &pShckeyAppHead) < 0)
	{
		OTraceError("E-SHC-027020:Can't find security rule, no keys operation avialable\n");
		return -1;
	}
	
	int i;
	char *p= rm_getapptext(shcSecurityAppid);
	struct shcsecurity *pTmp = NULL;
	for(i = 0; i < pShckeyAppHead->textused; ++i, p += pShckeyAppHead->textsize)
	{
		pTmp = (struct shcsecurity *)p;
		if (hashValue != pTmp->hash)
			continue;
 		if(stricmp(instId, pTmp->k.institutionid) == 0 &&
	   		stricmp(keyparamStr, pTmp->k.userbinid) == 0)
		{
			break;
		}
	}
	
	if (i >= pShckeyAppHead->textused)
	{
		OTraceInfo("I-SHC-027021:Can't find shckeys record(%s,%s)\n", instId, keyparamStr);
		return -1;
	}
	else
		return i;
}

struct shcsecurity *ShcKeyHelper::getKey(const char *instId, const char *keyparamStr)
{
	int i = getKeyParam(instId, keyparamStr);

	if (i>=0)
		return (struct shcsecurity *)(rm_getapptext(shcSecurityAppid)+pShckeyAppHead->textsize*i);
	else
		return NULL;
		
}
long ShcKeyHelper::getHashValue(const char *ptr)
{
    if(ptr == NULL)
        return 0;

    int sum = 0;
    for(;*ptr;ptr++)
        sum += *ptr;
    return sum;

}

int KeyXchgHelper::collect(ShcKeyHelper &shcKeyHelper,struct shckey_buf *bufp,NetworkInfo &networkInfo,char status)
{
	static const char* fnDesc = "KeyXchgHelper::collect";
	int ret=-1;

	ret = shcKeyHelper.shc_keys_init_buf(bufp, bufp->key_class, bufp->type, bufp->index);
	OTraceDebug("D-SHC-027040 %s InitBuf ret[%d]\n", fnDesc, ret );
	if((bufp->type==SH_KEYTYPE_PIN) && (status == SH_KEYSTAT_ACTIVE))
	{
		// Get networkInfo and check if the dest is AMEX
		shcApp->instProfileObj->locateNetworkInfoByKeyParamStr(bufp->keyp->k.institutionid,bufp->keyp->k.userbinid,networkInfo);
		OTraceDebug("D-SHC-027041 %s FoundNetId[%d] TxnDesc[%s]\n",fnDesc,networkInfo.foundNetworkInfo(),networkInfo.getTxnDest());
	}

	return(ret);
}

int KeyXchgHelper::preProc(ShcKeyHelper &shcKeyHelper,struct shckey_buf *bufp,NetworkInfo &networkInfo,char status,int *keylen,char *cardScheme, char *&trmKey)
{
	static const char* fnDesc = "KeyXchgHelper::preProc";
	int ret=0;

	OTraceDebug("D-SHC-027042 %s KeyBufType[%c] Status[%c]\n",fnDesc,bufp->type,status);
	if( status == SH_KEYSTAT_EXCHANGE )
	{
		if( bufp->akeyp )
		{
			*keylen = *bufp->akeylen;
		}
		else if ( bufp->ikeyp )
		{
			*keylen = *bufp->ikeylen;
		}
	}
	OTraceDebug("D-SHC-027043 %s InitBuf ret[%d] keylen[%d]\n",fnDesc,ret,*keylen);

	snprintf(cardScheme,3,"00");
	if((bufp->type==SH_KEYTYPE_PIN) && (status == SH_KEYSTAT_ACTIVE))
	{
		if((networkInfo.foundNetworkInfo()) && (strcmp(networkInfo.getTxnDest(), "03") == 0))
		{
			snprintf(cardScheme,3,"03");
		}
	}
	OTraceDebug("D-SHC-027044 %s CardScheme[%s]\n",fnDesc,cardScheme);
	if((bufp->type==SH_KEYTYPE_MAC) && (status == SH_KEYSTAT_EXCHANGE))
	{
		/* Get the corret length key for racal */
		if (bufp->keyp->k.kek_len == 48 || bufp->keyp->k.kek_len == 49)
		{
			trmKey = shcApp->shckeyParamsList->getShccfg()->tkr_triple;
		}
		else if (bufp->keyp->k.kek_len == 32 || bufp->keyp->k.kek_len == 33)
		{
			trmKey = shcApp->shckeyParamsList->getShccfg()->tkr_double;
		}
		else
		{
			trmKey = shcApp->shckeyParamsList->getShccfg()->tkpe;
		}
	}

	return(ret);
}
int KeyXchgHelper::proc(struct shckey_buf *bufp,char *k_kpe,char *k_chk,char status,int *keylen,char *k_mfk,char *c_mfk,char *cardScheme, char *trmKey)
{
	static const char* fnDesc = "KeyXchgHelper::proc";
	return(proc_xt(bufp,k_kpe,k_chk,status,keylen,k_mfk,c_mfk,cardScheme,trmKey,0));
}

int KeyXchgHelper::proc_xt(struct shckey_buf *bufp,char *k_kpe,char *k_chk,char status,int *keylen,char *k_mfk,char *c_mfk,char *cardScheme, char *trmKey, int keyType)
{
	static const char* fnDesc = "KeyXchgHelper::proc_xt";
	return(proc_xt_xt(bufp,k_kpe,k_chk,status,keylen,k_mfk,c_mfk,cardScheme,trmKey,keyType,'A',0));
}

int KeyXchgHelper::proc_xt_xt(struct shckey_buf *bufp,char *k_kpe,char *k_chk,char status,int *keylen,char *k_mfk,char *c_mfk,char *cardScheme, char *trmKey, int keyType, char keyVer, int atalla_var)
{
	static const char* fnDesc = "KeyXchgHelper::proc_xt_xt";
	ist_ElfId_t NetDataRqid=ist_ElfId_t(-1);
	int ret=SHC_RC_Approved;

	char	srcId[128];
	char	*ptrSrc=NULL;

	if(shcIsAsynchSecMode())
	{
		if(isAsynchHeaderSet(fnDesc))
		{
			NetDataRqid = ElfIdMap::elf_to_id(IST_SEG_NETWORK_DATA_REQ);
			asynchSecResp.lenKek=bufp->keyp->k.kek_len;
			asynchSecResp.lenKpe=bufp->keyp->k.isskpe_len;
			getAsynchHeader()->setSegmentData((char*)&asynchSecResp,sizeof(struct asynchSecSrvResp),NetDataRqid,KEY_MANAGEMENT_DATA);
		}

		if(setAsynchWait())
		{
			setAsynchSrcId(srcId,sizeof(srcId));
		}
		ptrSrc=srcId;
	}

	/* Translate: E(kpe)kek -> E(kpe)mfk */
	if((bufp->type==SH_KEYTYPE_PIN) && (status==SH_KEYSTAT_ACTIVE))
	{
		OTraceDebug("D-SHC-027046 %s KeyKpeStatAct KeyBufType[%c] Status[%c] Atalla Variant(%c)\n",
					 fnDesc,bufp->type,status, bufp->keyp->k.flags[2]);
		// Original call: translate_netkpe_mfkkpe_td_xt(...)
		if(!(ret=asynchTrnsltNetKpeMfkKpeTdX(bufp->keyp->k.kek,bufp->keyp->k.kek_len,k_kpe,*keylen,k_mfk,c_mfk,cardScheme,ptrSrc,bufp->keyp->k.flags[2],atalla_var)))
		{
			OTraceFatal("F-SHC-027012: Unable to translate PIN key\n");
			return( SHC_RC_PINKeyError );
		}
	}
	/* Generate: E(kpe)kek -> E(kpe)mfk */
	else if((bufp->type==SH_KEYTYPE_PIN) && (status==SH_KEYSTAT_EXCHANGE))
	{
		OTraceDebug("D-SHC-027046 %s KeyKpeStaXch KeyBufType[%c] Status[%c]\n",fnDesc,bufp->type,status);
		// Original call: generate_netkpe_td(...)
		if(keyType != 1)
		{
		if(!(ret=asynchGenerateNetKpeTd(bufp->keyp->k.kek, bufp->keyp->k.kek_len,*keylen,k_kpe,k_mfk,k_chk,ptrSrc,atalla_var)))
		{
			OTraceError("E-SHC-027013: Unable to generate PIN key\n");
			return( SHC_RC_PINKeyError );
		}
		}
		else
		{
		if(!(ret=asynchGenerateNetKpeTd_xt(bufp->keyp->k.kek, bufp->keyp->k.kek_len,*keylen,k_kpe,k_mfk,k_chk,ptrSrc,keyType,keyVer,atalla_var)))
		{
			OTraceError("E-SHC-027013: Unable to generate keyblock PIN key\n");
			return( SHC_RC_PINKeyError );
		}
		}
	}
	/* Translate: E(mac)kek -> E(mac)mfk */
	else if((bufp->type==SH_KEYTYPE_MAC) && (status == SH_KEYSTAT_ACTIVE))
	{
		OTraceDebug("D-SHC-027046 %s KeyMacStatAct KeyBufType[%c] Status[%c]\n",fnDesc,bufp->type,status);
		// Original call: translate_netmac_mfkmac_td(...)
		if(!(ret=asynchTrnsltNetMacMfkMacTd(bufp->keyp->k.kek,bufp->keyp->k.kek_len, k_kpe, *keylen, k_mfk, c_mfk,ptrSrc, atalla_var)))
		{
			OTraceFatal("F-SHC-027014: Unable to translate MAC key\n");
			return( SHC_RC_MACSyncError );
		}
	}
	/* Generate: E(mac)kek -> E(mac)mfk */
	else if((bufp->type==SH_KEYTYPE_MAC) && (status == SH_KEYSTAT_EXCHANGE))
	{
		OTraceDebug("D-SHC-027046 %s KeyMacStatXch KeyBufType[%c] Status[%c]\n",fnDesc,bufp->type,status);
		// Original call: generate_netmac_td(...)
		if(keyType != 1)
		{
		if(!(ret=asynchGenerateNetMacTd(bufp->keyp->k.kek,bufp->keyp->k.kek_len,*keylen,trmKey,k_kpe,k_mfk,k_chk,ptrSrc,atalla_var)))
		{
			OTraceError("E-SHC-027015: Unable to generate MAC key\n");
			return( SHC_RC_MACSyncError );
		}
		}
		else
		{
		if(!(ret=asynchGenerateNetMacTd_xt(bufp->keyp->k.kek,bufp->keyp->k.kek_len,*keylen,trmKey,k_kpe,k_mfk,k_chk,ptrSrc,keyType,keyVer,atalla_var)))
		{
			OTraceError("E-SHC-027015: Unable to generate keyblock MAC key\n");
			return( SHC_RC_MACSyncError );
		}
		}
	}
	else if(bufp->type==SH_KEYTYPE_KME)	/* Translate: Balance key */
	{
		OTraceError("E-SHC-027016: Unable to generate/translate KME key\n");
		return( SHC_RC_KeyValidationError );
	}

	if(shcIsAsynchSecMode() && (ret==SEC_ASYNCH_WAIT))
	{
		OTraceDebug("D-SHC-001102 %s Asynch response [%d]\n",fnDesc,SEC_ASYNCH_WAIT);
	}

	return(ret);
}

int KeyXchgHelper::proc_as2805(struct shckey_buf *bufp,char *k_kpe,char *k_kpe_chk, char *k_mac,char *k_mac_chk, char *k_kme, char *k_kme_chk, char status,
				int *keylen, char *k_mfk_kpe, char *c_mfk_kpe, char *k_mfk_mac, char *c_mfk_mac, char *cardScheme, char *trmKey)
{
	static const char* fnDesc = "KeyXchgHelper::proc_as2805";
	ist_ElfId_t NetDataRqid=ist_ElfId_t(-1);
	int ret=SHC_RC_Approved;

	char	zpk_lmk[MAX_KEYLEN+1], zak_lmk[MAX_KEYLEN+1], zak_zmk[MAX_KEYLEN+1], zek_lmk[MAX_KEYLEN+1], zek_zmk[MAX_KEYLEN+1];
	char	zpk_zmk[MAX_KEYLEN+1], zek_kek[MAX_KEYLEN+1];

	char	kcv_zpk[MAX_CHECK_DIGIT_LEN] = {0};
	char	kcv_zak[MAX_CHECK_DIGIT_LEN] = {0};
	char	kcv_zek[MAX_CHECK_DIGIT_LEN] = {0};

	char	zpk_cvv[MAX_CHECK_DIGIT_LEN] = {0};
	char	zak_cvv[MAX_CHECK_DIGIT_LEN] = {0};
	char	zek_cvv[MAX_CHECK_DIGIT_LEN] = {0};

	int	kcv_proc_flag = 2;
	int	zpk_proc_flag = 1;
	int	zak_proc_flag = 1;
	int	zek_proc_flag = 0;

	char	srcId[128];
	char	*ptrSrc=NULL;

	memset(zpk_lmk,		0x00,		sizeof(zpk_lmk));
	memset(zak_lmk,		0x00,		sizeof(zak_lmk));
	memset(zek_lmk,		0x00,		sizeof(zek_lmk));
	memset(zpk_zmk,		0x00,		sizeof(zpk_zmk));
	memset(zak_zmk,		0x00,		sizeof(zak_zmk));
	memset(zek_zmk,		0x00,		sizeof(zek_zmk));

	if(shcIsAsynchSecMode())
	{
		if(isAsynchHeaderSet(fnDesc))
		{
			NetDataRqid = ElfIdMap::elf_to_id(IST_SEG_NETWORK_DATA_REQ);
			asynchSecResp.lenKek=bufp->keyp->k.kek_len;
			asynchSecResp.lenKpe=bufp->keyp->k.isskpe_len;
			getAsynchHeader()->setSegmentData((char*)&asynchSecResp,sizeof(struct asynchSecSrvResp),NetDataRqid,KEY_MANAGEMENT_DATA);
		}

		if(setAsynchWait())
		{
			setAsynchSrcId(srcId,sizeof(srcId));
		}
		ptrSrc=srcId;
	}
	OTraceDebug("D-SHC-027046 %s KeyKpeStatAct KeyBufType[%c] Status[%c]\n",fnDesc,bufp->type,status);
	/* Translate: E(kpe)kek -> E(kpe)mfk */
	if((bufp->type==SH_KEYTYPE_PIN) && (status==SH_KEYSTAT_ACTIVE))
	{
		OTraceDebug("D-SHC-027046 %s KeyKpeStatAct KeyBufType[%c] Status[%c]\n",fnDesc,bufp->type,status);
#if 0
		// Original call: translate_netkpe_mfkkpe_td_xt(...)
		if(!(ret=asynchTrnsltNetKpeMfkKpeTdX(bufp->keyp->k.kek,bufp->keyp->k.kek_len,k_kpe,*keylen,k_mfk,c_mfk,cardScheme,ptrSrc)))
		{
			OTraceFatal("F-SHC-027012: Unable to translate PIN key\n");
			return( SHC_RC_PINKeyError );
		}
#endif
		OTraceDebug("D-SHC-027046 %s KeyKpeStatAct KeyBufType[%c] Status[%c]\n",fnDesc,bufp->type,status);
		// Original call: translate_netkpe_mfkkpe_td_xt(...)
		//if(!(ret=asynchTrnsltNetKpeMfkKpeTdX(bufp->keyp->k.kek,bufp->keyp->k.kek_len,k_kpe,*keylen,k_mfk,c_mfk,cardScheme,ptrSrc)))
		//{
		//	OTraceFatal("F-SHC-027012: Unable to translate PIN key\n");
		//	return( SHC_RC_PINKeyError );
		//}

		OTraceInfo("I-SHCNET-027010: Starting process KEYs - KPE key and MAC key.\n");
		OTraceInfo("I-SHCNET-027012: Start to call translate_setof_zone_keys, KEKs=[%s]\n", bufp->keyp->k.acqkek);
		OTraceInfo("I-SHCNET       : PIN Key [%s], MAC Key[%s]\n", k_kpe, k_mac);
		OTraceInfo("I-SHCNET-027017: k_kpe          [%s]\n",        k_kpe );
		OTraceInfo("               : k_mac          [%s]\n",        k_mac );
		if ( !(ret = asynchAS2805TranslateSetOfZoneKeys(
						bufp->keyp->k.acqkek,
						bufp->keyp->k.kek_len,
						kcv_proc_flag,
						zpk_proc_flag,
						k_kpe,                  // <- PIN KEY zpk_kekr : store in mac.key
						*keylen,                // <- zpk_kekr length
						k_kpe_chk,              // <- PIN KEY KCV of zpk : store in mac.chk
						zak_proc_flag,
						k_mac,                  // <- MAC KEY zak_kekr : store in filler3
						*keylen,                // <- zak_kekr Length
						k_mac_chk,              // <- MAC KEY KCV of zaka: store in filler4
						zek_proc_flag,
						zek_kek,
						*keylen,
						kcv_zek,
						zpk_lmk,
						zpk_cvv,
						zak_lmk,
						zak_cvv,
						zek_lmk,
						zek_cvv,
						NULL ) ) )
		{
			OTraceFatal("F-SHCNET-027013:  Unable to translate PIN Key and MAC Key\n");
			return( SHC_RC_PINKeyError );
		}
		else
		{
			OTraceInfo("I-SHCNET-027015: Succeeded in calling translate_setof_zone_keys()\n");
			OTraceInfo("I-SHCNET-027017: k_kpe		[%s]\n",        k_kpe );
			OTraceInfo("I-SHCNET-027017: zpk_lmk		[%s]\n",        zpk_lmk );
			OTraceInfo("               : k_mac		[%s]\n",        k_mac );
			OTraceInfo("               : zak_lmk		[%s]\n",        zak_lmk );
			OTraceInfo("               : zek_lmk		[%s]\n",        zek_lmk );
			OTraceInfo("               : ZPK_CVV		[%s]\n",        zpk_cvv );
			OTraceInfo("               : ZAK_KCV		[%s]\n",        zak_cvv );
			OTraceInfo("               : ZEK_KCV		[%s]\n",        zek_cvv );
			OTraceInfo("               : k_kpe_chk		[%s]\n",        k_kpe_chk);
			OTraceInfo("               : k_mac_chk		[%s]\n",        k_mac_chk);
                                    

			memset(k_kpe_chk, 0, sizeof(k_kpe_chk));
			memset(k_mac_chk, 0, sizeof(k_mac_chk));
			strncpy(k_kpe_chk,      zpk_cvv,        6);
			strncpy(k_mac_chk,      zak_cvv,        6);

			OTraceInfo("I-SHCNET-027017: zpk_lmk    BB	[%s]\n",        zpk_lmk );
			//memset(k_mfk, 0, sizeof(k_mfk));
			memcpy(k_mfk_kpe, zpk_lmk, 32);
			*(k_mfk_kpe + 32) = '\0';
			memcpy(k_mfk_mac, zak_lmk, 32);
			*(k_mfk_mac + 32) = '\0';
			OTraceInfo("I-SHCNET-027017: zpk_lmk    CC	[%s]\n",        zpk_lmk );
			OTraceInfo("I-SHCNET-027017: k_mfk_kpe  CC	[%s]\n",        k_mfk_kpe);
			OTraceInfo("I-SHCNET-027017: k_mfk_mac  CC	[%s]\n",        k_mfk_mac);
			
			memcpy(c_mfk_kpe, zpk_cvv, 6);
                        *(c_mfk_kpe + 6) = '\0';
			memcpy(c_mfk_mac, zak_cvv, 6);
                        *(c_mfk_mac + 6) = '\0';

			OTraceInfo("I-SHCNET-027017: zpk_cvv    CC	[%s]\n",        zpk_cvv );

			*(k_kpe_chk + 6) = '\0';
			*(k_mac_chk + 6) = '\0';


			*(zpk_lmk + 32) = '\0';
			*(zak_lmk + 32) = '\0';
			OTraceInfo("I-SHCNET-027018: zpk_lmk		[%s]\n",	zpk_lmk );
			OTraceInfo("I-SHCNET-027018: zak_lmk		[%s]\n",	zak_lmk );
			OTraceInfo("I-SHCNET-027018: k_kpe_chk		[%s]\n",	k_kpe_chk);
			OTraceInfo("I-SHCNET-027018: k_mac_chk		[%s]\n",	k_mac_chk);
			memcpy(k_mac, zak_zmk, sizeof(zak_zmk));
			OTraceInfo("I-SHCNET-027018: k_mac (ZMK)	[%s]\n",	k_mac );
		}
	}
	/* Generate: E(kpe)kek -> E(kpe)mfk */
	else if((bufp->type==SH_KEYTYPE_PIN) && (status==SH_KEYSTAT_EXCHANGE))
	{
		OTraceDebug("D-SHC-027046 %s KeyKpeStaXch KeyBufType[%c] Status[%c]\n",fnDesc,bufp->type,status);

		// Original call: generate_netkpe_td(...)
#if 0
		if(keyType != 1)
		{
			if(!(ret=asynchGenerateNetKpeTd(bufp->keyp->k.kek, bufp->keyp->k.kek_len,*keylen,k_kpe,k_mfk,k_chk,ptrSrc)))
			{
				OTraceError("E-SHC-027013: Unable to generate PIN key\n");
				return( SHC_RC_PINKeyError );
			}
		}
		else
		{
			if(!(ret=asynchGenerateNetKpeTd_xt(bufp->keyp->k.kek, bufp->keyp->k.kek_len,*keylen,k_kpe,k_mfk,k_chk,ptrSrc,keyType)))
			{
				OTraceError("E-SHC-027013: Unable to generate keyblock PIN key\n");
				return( SHC_RC_PINKeyError );
			}
		}
#endif

		OTraceDebug("D-SHC-027046 %s KeyKpeStatAct KeyBufType[%c] Status[%c]\n",fnDesc,bufp->type,status);
		// Original call: translate_netkpe_mfkkpe_td_xt(...)
		//if(!(ret=asynchTrnsltNetKpeMfkKpeTdX(bufp->keyp->k.kek,bufp->keyp->k.kek_len,k_kpe,*keylen,k_mfk,c_mfk,cardScheme,ptrSrc)))
		//{
		//	OTraceFatal("F-SHC-027012: Unable to translate PIN key\n");
		//	return( SHC_RC_PINKeyError );
		//}

		OTraceInfo("I-SHCNET-027019: Start to call generate_setof_zone_keys, KEKs=[%s]\n", bufp->keyp->k.kek);
		if( !(ret = asynchAS2805GenerateSetOfZoneKeys(
						bufp->keyp->k.kek,
						bufp->keyp->k.kek_len,
						zpk_lmk,                        // <- PIN KEY under LMK pair 06-07, store in shckeys
						*keylen,
						k_kpe,                          // <- PIN KEY under ZMK, store in mac.key
						*keylen,
						k_kpe_chk,                      // <- PIN KEY KCV : store in mac.chk
						zak_lmk,                        // <- MAC KEY under LMK: store in shckeys
						zak_zmk,			// <- MAC KEY under ZMK, store in filler3
						k_mac_chk,                      // <- MAC KEY KCV : store in filler4
						zek_lmk,
						zek_zmk,
						kcv_zek, 
						NULL ) ) )
		{
			OTraceError("E-SHCNET-027021:  Unable to generate PIN key and MAC key in 'OI' HSM call\n");
			return( SHC_RC_PINKeyError );
		}
		else
		{
#if 1
			OTraceInfo("I-SHCNET-027023: Succeeded in calling generate_setof_zone_keys()\n");
			OTraceInfo("                   : k_kpe (LMK)    [%s]\n",        zpk_lmk );
			OTraceInfo("I-SHCNET-027025    : k_kpe (ZMK)    [%s]\n",        k_kpe );
			OTraceInfo("                   : k_mac (LMK)    [%s]\n",        zak_lmk );
			OTraceInfo("                   : k_mac (ZMK)    [%s]\n",       	zak_zmk ); 
			OTraceInfo("                   : zek   (LMK)    [%s]\n",        zek_lmk );
			OTraceInfo("                   : zek   (ZMK)    [%s]\n",        zek_zmk );
			OTraceInfo("                   : ZPK_CVV        [%s]\n",        k_kpe_chk );
			OTraceInfo("                   : MAC_KCV        [%s]\n",        k_mac_chk );

			memcpy(k_mac, zak_zmk, strlen(zak_zmk));
			memcpy(k_mfk_kpe, zpk_lmk, strlen(zpk_lmk));
			memcpy(c_mfk_kpe, k_kpe_chk, strlen(k_kpe_chk));
			memcpy(k_mfk_mac, zak_lmk, strlen(zak_lmk));
			memcpy(c_mfk_mac, k_mac_chk, strlen(k_mac_chk));
			OTraceInfo("                   : k_mac (ZMK)    [%s]\n",        k_mac );
			OTraceInfo("                   : k_mfk_kpe          [%s]\n",        k_mfk_kpe );
			OTraceInfo("                   : c_mfk_kpe          [%s]\n",        c_mfk_kpe );
			OTraceInfo("                   : k_mfk_mac          [%s]\n",        k_mfk_mac );
			OTraceInfo("                   : c_mfk_mac          [%s]\n",        c_mfk_mac );
#endif
		}
	}
#if 0
	/* Translate: E(mac)kek -> E(mac)mfk */
	else if((bufp->type==SH_KEYTYPE_MAC) && (status == SH_KEYSTAT_ACTIVE))
	{
		OTraceDebug("D-SHC-027046 %s KeyMacStatAct KeyBufType[%c] Status[%c]\n",fnDesc,bufp->type,status);
		// Original call: translate_netmac_mfkmac_td(...)
		if(!(ret=asynchTrnsltNetMacMfkMacTd(bufp->keyp->k.kek,bufp->keyp->k.kek_len, k_kpe, *keylen, k_mfk, c_mfk,ptrSrc)))
		{
			OTraceFatal("F-SHC-027014: Unable to translate MAC key\n");
			return( SHC_RC_MACSyncError );
		}
	}
	/* Generate: E(mac)kek -> E(mac)mfk */
	else if((bufp->type==SH_KEYTYPE_MAC) && (status == SH_KEYSTAT_EXCHANGE))
	{
		OTraceDebug("D-SHC-027046 %s KeyMacStatXch KeyBufType[%c] Status[%c]\n",fnDesc,bufp->type,status);

		// Original call: generate_netmac_td(...)
		if(keyType != 1)
		{
			if(!(ret=asynchGenerateNetMacTd(bufp->keyp->k.kek,bufp->keyp->k.kek_len,*keylen,trmKey,k_kpe,k_mfk,k_chk,ptrSrc)))
			{
				OTraceError("E-SHC-027015: Unable to generate MAC key\n");
				return( SHC_RC_MACSyncError );
			}
		}
		else
		{
			if(!(ret=asynchGenerateNetMacTd_xt(bufp->keyp->k.kek,bufp->keyp->k.kek_len,*keylen,trmKey,k_kpe,k_mfk,k_chk,ptrSrc,keyType)))
			{
				OTraceError("E-SHC-027015: Unable to generate keyblock MAC key\n");
				return( SHC_RC_MACSyncError );
			}
		}

	}
#endif
	else if(bufp->type==SH_KEYTYPE_KME)	/* Translate: Balance key */
	{
		OTraceError("E-SHC-027016: Unable to generate/translate KME key\n");
		return( SHC_RC_KeyValidationError );
	}

	if(shcIsAsynchSecMode() && (ret==SEC_ASYNCH_WAIT))
	{
		OTraceDebug("D-SHC-001102 %s Asynch response [%d]\n",fnDesc,SEC_ASYNCH_WAIT);
	}

	return(ret);
}

int KeyXchgHelper::resume(ShcKeyHelper &shcKeyHelper,struct shckey_buf *bufp,char *k_chk,char status,int *keylen,char *k_mfk,char *c_mfk)
{
	static const char* fnDesc = "KeyXchgHelper::resume";
	int isLocked = 0;
	int ret=0;

	OTraceDebug("D-SHC-027017: ValChk [%c]\n",shcApp->shckeyParamsList->getShccfg()->val_chk);
	if( shcApp->shckeyParamsList->getShccfg()->val_chk == 'Y' && c_mfk[0] && strncmp(c_mfk, k_chk, CHECK_DIGIT_LEN) )
	{
		OTraceError("E-SHC-027017: Failed validation - check digits do not match\n");
		return( SHC_RC_KeyValidationError );
	}

	if( (k_chk[0] == 0x00) && c_mfk[0] )
		memcpy(k_chk, c_mfk, CHECK_DIGIT_LEN);

	/*
	 * Update pointers in memory
	 */

	//  If generating key and key is shared need to sync to other site
	if (bufp->keyp->k.flags[1] == 'S')
	{
		if( mbIsDualSite() )
		{
			if( mbGetSiteId() == 2 )
			{
				if(IST_MR::check_if_site_is_up(1))
					return(SHC_RC_UnableToProcess);
			}
		}

		if((status==SH_KEYSTAT_EXCHANGE) || (status==SH_KEYSTAT_ACTIVE))
		{
			//generating new key send to other site
			if(ShcKeysMRHelper::getInstance()->sendKeyWait(bufp,k_mfk,k_chk,status)<0)
			{
				OTraceError("E-SHCKEY-????: Unable to sync keys\n");
				return (SHC_RC_UnableToProcess);
			}
		}
	}

	shcKeyHelper.shc_keyidx(&bufp->keyp->k);
	shcSharedMemoryHelperObj->lockRule(sharedCashSecurityRuleName, &isLocked, &shcSecurityAppid);

	if( bufp->akeyp )
	{
		memset(bufp->akeyp, 0, KEYLEN);
		if(isKeyBlockDevice() || isAtallaAkb() )
		{
			memcpy(bufp->akeyp, k_mfk, std::min<int>(getHostKeyBlkLen(k_mfk), KEYLEN));
		}
		else
		{
			//In Case of Atalla_AKB, key length should be 74. getHostKeyLen() retuns 74 for atalla_akb
			*bufp->akeylen = getHostKeyLen(*keylen);	//HA
			memcpy(bufp->akeyp, k_mfk, getHostKeyLen(*bufp->akeylen));	//HA
		}
		memcpy(bufp->achkp, k_chk, CHECK_DIGIT_LEN_FULL);	//HA
		bufp->change = 'T';
		*bufp->astatp = status;
	}

	if( bufp->ikeyp )
	{
		memset(bufp->ikeyp, 0, sizeof(bufp->ikeyp));
		if(isKeyBlockDevice() || isAtallaAkb())
		{
			memcpy(bufp->ikeyp, k_mfk, getHostKeyBlkLen(k_mfk));
		}
		else
		{
			//In Case of Atalla_AKB, key length should be 74. getHostKeyLen() retuns 74 for atalla_akb
			*bufp->ikeylen = getHostKeyLen(*keylen);	//HA
			memcpy(bufp->ikeyp, k_mfk, getHostKeyLen(*bufp->ikeylen));	//HA
		}
		memcpy(bufp->ichkp, k_chk, CHECK_DIGIT_LEN_FULL);	//HA
		bufp->change = 'T';
		*bufp->istatp = status;
	}

	if (status == SH_KEYSTAT_ACTIVE)
	{
		if( bufp->akeyp )
		{
			*bufp->aidxp = bufp->index - '0';
		}

		if(bufp->ikeyp )
		{
			*bufp->iidxp = bufp->index - '0';
		}
	}

	shcSharedMemoryHelperObj->updateCurrentVersion(sharedCashSecurityRuleName, isLocked, 
		shcSecurityAppid, (char *)&bufp->keyp->k, sizeof(bufp->keyp->k));

	if (bufp->keyp->k.flags[1] != 'S')
	{
		ShcKeysMRHelper::getInstance()->setMRDataUnique(bufp, status);
	}

	return( shcKeyHelper.shc_keys_upd_db(bufp) );
}


int KeyXchgHelper::resume_as2805(ShcKeyHelper &shcKeyHelper,struct shckey_buf *bufp,char *k_chk_kpe, char *k_chk_mac, char status,int *keylen,
						char *k_mfk_kpe, char *c_mfk_kpe, char *k_mfk_mac, char *c_mfk_mac)
{
	static const char* fnDesc = "KeyXchgHelper::resume_as2805";
	int isLocked = 0;
	int ret=0;

	OTraceDebug("D-SHC-027017: ValChk [%c]\n",shcApp->shckeyParamsList->getShccfg()->val_chk);
	if( shcApp->shckeyParamsList->getShccfg()->val_chk == 'Y' && c_mfk_kpe[0] && strncmp(c_mfk_kpe, k_chk_kpe, AS2805_CHECK_DIGIT_LEN) )
	{
		OTraceError("E-SHC-027017: Failed validation - check digits do not match\n");
		return( SHC_RC_KeyValidationError );
	}

	if( (k_chk_kpe[0] == 0x00) && c_mfk_kpe[0] )
		memcpy(k_chk_kpe, c_mfk_kpe, CHECK_DIGIT_LEN);

	/*
	 * Update pointers in memory
	 */

	//  If generating key and key is shared need to sync to other site
	if (bufp->keyp->k.flags[1] == 'S')
	{
		if( mbIsDualSite() )
		{
			if( mbGetSiteId() == 2 )
			{
				if(IST_MR::check_if_site_is_up(1))
					return(SHC_RC_UnableToProcess);
			}
		}

		if((status==SH_KEYSTAT_EXCHANGE) || (status==SH_KEYSTAT_ACTIVE))
		{
			//generating new key send to other site
			if(ShcKeysMRHelper::getInstance()->sendKeyWait(bufp, k_mfk_kpe, k_chk_kpe, status)<0)
			{
				OTraceError("E-SHCKEY-????: Unable to sync keys\n");
				return (SHC_RC_UnableToProcess);
			}
		}
	}

	shcKeyHelper.shc_keyidx(&bufp->keyp->k);
	shcSharedMemoryHelperObj->lockRule(sharedCashSecurityRuleName, &isLocked, &shcSecurityAppid);

	if( bufp->akeyp )
	{
		memset(bufp->akeyp, 0, KEYLEN_AS2805);

		*bufp->akeylen = *keylen;	//HA
		//memcpy(bufp->akeyp, k_mfk, getHostKeyLen(*bufp->akeylen));	//HA
		//memcpy(bufp->akeyp, k_mfk_kpe, strlen(k_mfk_kpe) );		//HA

		if (bufp->akeyp == bufp->keyp->k.acqpin1)
		{
			memcpy(bufp->keyp->k.acqpin1,	k_mfk_kpe, strlen(k_mfk_kpe) );
			memcpy(bufp->keyp->k.acqpin1chk,c_mfk_kpe, CHECK_DIGIT_LEN );
			memcpy(bufp->keyp->k.acqmac1,	k_mfk_mac, strlen(k_mfk_mac) );
			memcpy(bufp->keyp->k.acqmac1chk,c_mfk_mac, CHECK_DIGIT_LEN );
			bufp->keyp->k.acqpin1stat	= SH_KEYSTAT_EXCHANGE;
			//bufp->keyp->k.acqpinidx		= 1;
			bufp->keyp->k.acqmac1stat	= SH_KEYSTAT_EXCHANGE;
			//bufp->keyp->k.acqmacidx		= 1;
			//bufp->akeyp			= bufp->keyp->k.acqpin1;
		}
		else if (bufp->akeyp == bufp->keyp->k.acqpin2)
		{
                        memcpy(bufp->keyp->k.acqpin2,   k_mfk_kpe, min<long>(sizeof(bufp->keyp->k.acqpin2),  strlen(k_mfk_kpe) ));
			memcpy(bufp->keyp->k.acqpin2chk,c_mfk_kpe, CHECK_DIGIT_LEN );
                        memcpy(bufp->keyp->k.acqmac2,   k_mfk_mac, min<long>(sizeof(bufp->keyp->k.acqmac2),  strlen(k_mfk_mac) ));
			memcpy(bufp->keyp->k.acqmac2chk,c_mfk_mac, CHECK_DIGIT_LEN );
			bufp->keyp->k.acqpin2stat	= SH_KEYSTAT_EXCHANGE;
			//bufp->keyp->k.acqpinidx		= 2;
			bufp->keyp->k.acqmac2stat	= SH_KEYSTAT_EXCHANGE;
			//bufp->keyp->k.acqmacidx		= 2;
			//bufp->akeyp			= bufp->keyp->k.acqpin2;
		}

		memcpy(bufp->achkp, k_chk_kpe, CHECK_DIGIT_LEN);	//HA
		bufp->change = 'T';
		*bufp->astatp = status;
	}
	else if( bufp->ikeyp )
	{
		memset(bufp->ikeyp, 0, sizeof(bufp->ikeyp));

		if (bufp->ikeyp == bufp->keyp->k.isspin1)
		{
			memcpy(bufp->keyp->k.isspin1,	k_mfk_kpe, strlen(k_mfk_kpe) );
			memcpy(bufp->keyp->k.isspin1chk,c_mfk_kpe, CHECK_DIGIT_LEN );
			memcpy(bufp->keyp->k.issmac1,	k_mfk_mac, strlen(k_mfk_mac) );
			memcpy(bufp->keyp->k.issmac1chk,c_mfk_mac, CHECK_DIGIT_LEN );
			bufp->keyp->k.isspin1stat	= SH_KEYSTAT_EXCHANGE;
			//bufp->keyp->k.isspinidx		= 1;
			bufp->keyp->k.issmac1stat	= SH_KEYSTAT_EXCHANGE;
			//bufp->keyp->k.issmacidx		= 1;
			//bufp->ikeyp			= bufp->keyp->k.isspin1;
		}
		else if (bufp->ikeyp == bufp->keyp->k.isspin2)
		{
                        memcpy(bufp->keyp->k.isspin2,   k_mfk_kpe, min<long>(sizeof(bufp->keyp->k.isspin2),  strlen(k_mfk_kpe) ));
			memcpy(bufp->keyp->k.isspin2chk,c_mfk_kpe, CHECK_DIGIT_LEN );
                        memcpy(bufp->keyp->k.issmac2,   k_mfk_mac, min<long>(sizeof(bufp->keyp->k.issmac2),  strlen(k_mfk_mac) ));
			memcpy(bufp->keyp->k.issmac2chk,c_mfk_mac, CHECK_DIGIT_LEN );
			bufp->keyp->k.isspin2stat	= SH_KEYSTAT_EXCHANGE;
			//bufp->keyp->k.isspinidx		= 2;
			bufp->keyp->k.issmac2stat	= SH_KEYSTAT_EXCHANGE;
			//bufp->keyp->k.issmacidx		= 2;
			bufp->ikeyp			= bufp->keyp->k.isspin2;
		}
		memcpy(bufp->ichkp, k_chk_kpe, CHECK_DIGIT_LEN);	//HA
		bufp->change = 'T';
		*bufp->istatp = status;
	}

	if (status == SH_KEYSTAT_ACTIVE || status == SH_KEYSTAT_EXCHANGE)
	{
		if( bufp->akeyp )
		{
			*bufp->aidxp = bufp->index - '0';
		}

		if(bufp->ikeyp )
		{
			*bufp->iidxp = bufp->index - '0';
		}
	}

	shcSharedMemoryHelperObj->updateCurrentVersion(sharedCashSecurityRuleName, isLocked, 
					shcSecurityAppid, (char *)&bufp->keyp->k, sizeof(bufp->keyp->k));

	if (bufp->keyp->k.flags[1] != 'S')
	{
		ShcKeysMRHelper::getInstance()->setMRDataUnique(bufp, status);
	}

	return( shcKeyHelper.shc_keys_upd_db(bufp) );
}
/*
 *                        MODIFICATION HISTORY                  REVIEW
 *
 *	SPR#	Who	Date	Description			Who	Date   
 * ===========================================================================
 *	ad		21dec91		Check for duplicate advice transactions and
 *						avoid logging them. Also check the return of
 *						logRepeate to determine if error, duplicate or new.
 *	ad		03Jan92		Do not assign origtrace if already set
 *	ad		18jun92		Added more descriptive ODebug's for denial resons
 *	ad		17aug92		If exp date flag is NOT set then call validate_date
 *	ss		05Nov92		Check if txn amount over SAF MaxTxnLimit if issuer down.
 *	ad		16nov92		Modified fix of 05nov92 to include POS txn's as well
 *	ad		26nov92		Added check for 'PREAUTH_ON_VALIDATE'
 *						If sending pre-auth, then set the saf flag if the
 *						issuer is down.
 *	ss		12Jan93		if msg is PREAUTH_RESP, set timer up
 *	ad		29apr93		Added support for duplicate txn checking.
 *	ad		05may93		Changed repeat checking NOT to include 101 messages
 *	jsn		06May93		shc_verify_check_digit(): now skip lead zeroes 	 
 *	ss		11Jun93		Reconstruct missing code from Oasis machine. Seem
 *						missing code to log transaction into DB.
 *	MI		22Jun93		Dropped preauth request if not supported.
 *	MI		26Jul93		Do not need any edits for processed conf req
 *	ad		22dec93		Removed PIN requiremnt for service codes
 *	pk		17Feb94		This is due to reversals being mirrored across 
 *						the alt node
 *	jsn		30mar94		shc_checkscode() comment out check between country
 *						codes of acq and iss.
 *	ad		14may94		Added code to mark a duplicate advice for later
 *						use in shc
 *	ad		16nov94		Corrected change made by PAHIA. Moved code AFTER
 *						check for pre-auth resp. We cannot lose the response
 *						code generated by the response agent.
 *						Added code that rejects a transaction if it is a
 *						duplicate.
 *	ss		09Mar95		Check iss_minamount and acq_minamount for transaction.
 * 10001592 qd  18mar96	Check txn.amount if acq and iss has the same currency 
 * 10001592 la  27mar96 Instead check the txn.amount if the txn.currency and
 *                       the iss.currency is the same.
 * 10001455 la  28mar96 Expect shc_iscardexpired() to set the response code.
 *  2002847 qd  27mar97 Set origmsg, origdate and origtime iff origmsg is zero 
 *  R001538 qd  03mar99 Added CVV2 support
 *	R003357	HJ	01Nov99 Delete leading zero in pan
 *	R004595	HJ	01Jun00	Original capture date in 420 should be tomorow's date
 *	R004832, R004686 jy	05Dec00	Checking duplicate 100 msg of Europay)
 *	R005871 jy	03Apr01	Truncate trailing spaces of PAN in shc_verify_check_digit()
 *	R005887	jy	04Apr01 Added shc_setCvvResultCode(), shc_getCvvResultCode() 
 * 						and shc_checkCvvCvv2() functions
 *R006401 ztang	21Jun01	set new field cvv_resultcode with '\0', 'M' and 'N'
 * R007062	gbeeng	26Nov2001	C++ Migration
 *R007206 jyang 04Oct01	Add a new func to check Europay BIN/MBR table
 *R007237 jyang 05Dec01 Support to validate "Acquirer Profiles" for Europay
 *R007211 ztang 22Jan02 Changed logic of processing repeat messages
 *R007615 jyang 19Mar02 Prevent from logging duplicate advice/repeat txn
 *R007612 jyang 20Mar02 Enable to handle cash advance with pcode=01 for 
 *						Europay Profiles checking
 *R007672 jyang 04Apr02 Instead of return DuplcateTxn, relay advice message 
 *						which original being reversed
 *R007855 jyang 02Jun02 Switch the sequence of checking PIN and HotCard
 *R007909 Emj   13Jun02 Added new callback shc_edit_transaction
 *R008224 ztang 13Sep02 Added void transaction support
 *R008464 jyang 25Oct02 Refresh the pointer of pin_data for VOID txn
 *R009100 jyang 11Feb03 Set SH_DEVCAP_NOPIN flag as no pin data
 *R009807 jyang 10Jun03 Check duplicate for financial txn
 */
