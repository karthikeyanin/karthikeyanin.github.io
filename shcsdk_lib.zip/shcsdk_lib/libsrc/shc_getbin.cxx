/*
 *  Copyright (C) 2004 eFunds Corporation ("eFunds").  All Rights Reserved.     
 *  eFunds Canada Corporation is an authorized user.                            
 *                                                                              
 *  IST is a registered trademark of eFunds Corporation.  Other brand or        
 *  product names are trademarks or registered trademarks of their respective   
 *  holders.                                                                    
 *                                                                              
 *  The information contained herein is the unpublished proprietary property    
 *  of eFunds.  Except as specifically authorized in writing by eFunds, the     
 *  holder of this document shall: i) keep all information contained herein     
 *  confidential, and ii) protect the information, in whole or in part, from    
 *  disclosure and dissemination to all third parties.                          
 *                                                                          
 *  This document and the software described in it are furnished under license  
 *  and may be used or copied only in accordance with the terms of such license.
 *  This document is supplied for information purposes only, is subject to      
 *  change without notice, and should not be construed as a commitment by       
 *  either eFunds Corporation or eFunds Canada Corporation. 
 */
/*
#pragma ident "@(#) shc_getbin.cxx 1.4 20/03/19 10:26:35"
 *
 *                        MODIFICATION HISTORY                  REVIEW
 *
 *	SPR#	Who	Date	Description			Who	Date   
 * ===========================================================================
 *	Sunny	13Jan92		Add support for shcextbin.
 *						shc_locate_extbin, shc_search_extbin
 *	av		09Mar94		fix some bugs for locate extbin info.
 *						No need for shc_locate_extbin and shc_search_extbin.
 *	edc		10Feb95		For new extbin process and table format
 *  qd 		28feb96		Added shc_gettransferee() to support IBFT
 * 10001935 la  09may96 Fixed return value for when external BIN.
 *  2002700 qd  21feb97 Provide correct parameter to locate_compare()
 *                      Extended extbin search for response msg as well
 *  R000973 qd  02may98 Leading Zero BIN
 * R002639  zt	07Sep99	Store network_data from external bin table into
 *						acquirer_data in shcmsg.
 * R003309  fg  29Oct99 Move SHC configuration parameters to bin level
 *                      shc.device_encrypt, shc.leading_zero_bin,
 *                      shc.leading_zero_char
 * R004214  fg  22Mar00 No removing the leading zero
 * R004460 ztang26Apr00 Put network_data in shc_data_buf
 * R004454	rlo	26Apr00	Fix typo.
 * R004723	HJ	12Jun00	Get acquirer and issuer bin before exit
 * R005124 jsun 19Sep00 Try to locate forward_inst_id if can not locate acquirer
 *R008717 ztang 13Nov02 Moved from shc_lib to mt_lib to support 
 *						multi-institution.
 *R009025 ztang 04Feb03 Use different variable to check whether dbm_init 
 *						is called
 *R009248 ztang 24Feb03 Remove spaces from instituion id fields
 *
 */

//File Number 11

#if defined( WIN32 )
#       define SHCDLLEXPORT __declspec(dllexport)
#else
#       define SHCDLLEXPORT
#endif


#include <stdio.h>
#include <oasis.h>
//#include <rules.h>
//#include <shc.h>
///* R005156 */
#include <string.h>
//#include <ic/ic_bin.h>
//#include<ic/ic_instid.h>
#include <ctype.h>
//#include <dbm_private.h>
//#include <Ccard_scheme.h>
/* R005156 */
#include <ist_otrace.h>
#include <istsafe.h>
/*
 *	Input:		shcmsg		pointer to uninitialised message
 *	Action:		Reads the bin table and gets paramaters for
 *					acquirer
 *					issuer
 *					originator
 *
 *	Returns:	0		if all went well
 *				-1		on error and shcmsg->msg.respcode is set
 */


int shc_denormalizenumber(register char *nbp, register char *obp, size_t nbplen)
{
	int len, i;
	len = strlen(obp); 
	for(i = 0; i < len; ++i) 
		if(isspace(*obp) || *obp == '0') ++obp; 
		else 
			break; 
	istsafe_strcpy(nbp, nbplen, obp); 
	return (0); 
} 




