/*
 *  Copyright (C) 2004 eFunds Corporation ("eFunds").  All Rights Reserved.     
 *  eFunds Canada Corporation is an authorized user.                            
 *                                                                              
 *  IST is a registered trademark of eFunds Corporation.  Other brand or        
 *  product names are trademarks or registered trademarks of their respective   
 *  holders.                                                                    
 *                                                                              
 *  The information contained herein is the unpublished proprietary property    
 *  of eFunds.  Except as specifically authorized in writing by eFunds, the     
 *  holder of this document shall: i) keep all information contained herein     
 *  confidential, and ii) protect the information, in whole or in part, from    
 *  disclosure and dissemination to all third parties.                          
 *                                                                          
 *  This document and the software described in it are furnished under license  
 *  and may be used or copied only in accordance with the terms of such license.
 *  This document is supplied for information purposes only, is subject to      
 *  change without notice, and should not be construed as a commitment by       
 *  either eFunds Corporation or eFunds Canada Corporation. 
 */
/*
#pragma ident "@(#) shc_fmtutil.cxx 1.5 06/06/28 18:12:42"
 *
 *                        MODIFICATION HISTORY                  REVIEW
 *
 *	SPR#	Who	Date	Description			Who	Date   
 * ===========================================================================
 *	ad		02feb92		Created.
 *	jsn		02feb95		Added shc_fmtgetdate_from_mmdd() to allow retrieving
 *						the correct century for dates supplied from ISO 
 *						messages.
 *	la		28mar96		Added function shc_fmt_balance() to format a balance
 *						 field.
 *  R002086 sl 06Oct99  In order to get the correct month and day,Added the
 *                      month and the day check in shc_fmtgetdate_from_mmdd()
 *                      function.
 *R007641 ztang 26Mar02 Change default balance type from 0 to C
 *R007781 ztang 02May02 Added shc_is_empty_buf()
 */

//File Number 10

#if defined( WIN32 )
#       define SHCDLLEXPORT __declspec(dllexport)
#else
#       define SHCDLLEXPORT
#endif



#include <stdio.h>
#include <ctype.h>
#include <string.h>
#include <oasis.h>
#include <dbm.h>
#include <shc.h>



int shcmsgIsContactless(struct shcmsg *msg)
{
	long pos_entry_code = (msg->pos_entry_code & SH_POS_PINPANENTRY_MASK)/10;
	
	switch(pos_entry_code)
	{
	case SH_POS_PANENTRY_CONTACTLESS_IC:
	case SH_POS_PANENTRY_CONTACTLESS_MAGSTRIP:
	case SH_POS_PANENTRY_CONTACTLESS_PAYPASS:
		return 1;
	}
	return 0;
}


/* R007781 END */

