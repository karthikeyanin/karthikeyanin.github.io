static char _binRoute_cxx_what[] = "@(#) BinRoute.cxx 1.25.8.4 20/02/12 12:27:42";

/*
 *  Copyright (C) 2004 eFunds Corporation ("eFunds").  All Rights Reserved.     
 *  eFunds Canada Corporation is an authorized user.                            
 *                                                                              
 *  IST is a registered trademark of eFunds Corporation.  Other brand or        
 *  product names are trademarks or registered trademarks of their respective   
 *  holders.                                                                    
 *                                                                              
 *  The information contained herein is the unpublished proprietary property    
 *  of eFunds.  Except as specifically authorized in writing by eFunds, the     
 *  holder of this document shall: i) keep all information contained herein     
 *  confidential, and ii) protect the information, in whole or in part, from    
 *  disclosure and dissemination to all third parties.                          
 *                                                                          
 *  This document and the software described in it are furnished under license  
 *  and may be used or copied only in accordance with the terms of such license.
 *  This document is supplied for information purposes only, is subject to      
 *  change without notice, and should not be construed as a commitment by       
 *  either eFunds Corporation or eFunds Canada Corporation. 
 *
 *
 *                        MODIFICATION HISTORY                  REVIEW
 *
 *	SPR#	Who	Date	Description			Who	Date   
 * ===========================================================================
 *R0xxxxx ztang 28Feb08 Creation
 *R023095 jyang 13May08 Supported for locking shared memory of BinRoute
 *R023551 jyang 09Jun08 Added a member function createPseudoSharedMemory()
 *ITM-1567 ram  09Jul08 Changes to find firstDownRoute
 *R028828 Emj   17Dec10 Skip inst_profile check if no inst_profile provided
 *R028925 Dipa  24Jan11 New API to choose the first binroute that is UP.
 *R029136 Dipa  24Feb11 Fix bug in tidyUpBinStatus()
 *R029275 Dipa  08Apr11 Add balancer node info
 *R030556 Dipa  14Jun12 Clone of R030592
 *R031154 Dipa  21Dec12 Clone of R031026
 */

/* File Number 235 */

#include <stdio.h>
#include <string.h>
#include <ist_types.h>
#include <istiso.h>
#include <oasis.h>
#include <oasisenv.h>
#include <dbm.h>
#include <tm.h>
#include <sys/timeb.h>
#include <dbm_private.h>
#include <oc/oc_string.h>
#include <ist_otrace.h>
#include <Ccard_scheme.h>
#include <Cinstitution.h>
#include <shc_callback.h>
#include <rules.h>
#include <authnumber.h>
#include <shcmsgdef.h>
#include <security.h>
#include <shc.h>
#include <shcpreauth.h>
#include <ic/ic_shcmsg.h>
#include <ic/ic_instid.h>
#include <ic/ic_bin.h>
#include <ic/ic_pan.h>
//#include <emvchipcond.h>
#include <ShcSender.h>
#include <istcurrency.h>
#include <shc500std.h>

#include <ShcSdkCommon.h>
#include <ShcmsgHelper.h>
#include <ShcKeyHelper.h>
#include <ShcTimerHelper.h>
#include <hotrange.h>
#include <CShcLog.h>
#include <ShcDKEHelper.h>
#include <ShcAppBase.h>
#include <ShcHelper.h>
#include <ShcBin.h>
#include <ShcSafIOHelper.h>
#include <BusinessDay.h>
#include <BinRoute.h>
#include <InstProfile.h>

#include <ist_seg_name.h> //R027876
#include <ist_seg_elf_id_map.h> //R027876
#include <ist_seg_id.h> //R027876

#include <InstProfile.h>
#include <istsafe.h>

BinRoute *binRouteObj=NULL;
static int setBinUp = 0;

static char staticBroadcastStr[16384];
static int appidBinRoute = 0;
int _shouldUpdateCounter = 1;

long getRouteEntries_match_IP_ID  = -1;

char getRouteEntriesBinrouteGroup[sizeof(_nouse->binroute_group)] = { 0 };

BinRoute::BinRoute()
{
	rm_init();

	appidBinRoute = rm_getappid(BIN_ROUTE_MESSAGE_NAME);
	
	if (appidBinRoute < 0)
	{
		OTraceInfo("I-SHC-23501:No shc-bin-route rule in shared memory\n");
		createPseudoSharedMemory();
	}
	else
	{
		appHead = rm_getapphead(appidBinRoute);
		appKey = rm_getappkey(appidBinRoute);
	}
	candidates = NULL;
	numOfCandidates = 0;
	maxNumOfCandidates = 0;
}

BinRoute::~BinRoute()
{
	if (candidates)
		free(candidates);
}
long BinRoute::getHashValue(char *ptr)
{
	if(ptr == NULL) 
	    return 0;
	
	int sum = 0;
	for(;*ptr;ptr++)
	    sum += *ptr;
	return sum;
	
}

void BinRoute::resetBalanceInfo()
{
	numOfCandidates = 0;
}

void BinRoute::addRouteCandidate(struct s_binroute *c)
{
	if (maxNumOfCandidates <= numOfCandidates)
	{
		int n = maxNumOfCandidates + 10;
		struct s_binroute **newCandidates = NULL;
		newCandidates = (struct s_binroute **)calloc(sizeof(struct s_binroute *), n);
		if (!newCandidates)
		{
			OTraceError("E-SHC-23502:Can't allocate in BinRoute. Balancing not done.\n");
			throw 1;
		}
		
		
		if (candidates)
		{
			memcpy(newCandidates, candidates, numOfCandidates*sizeof(struct s_binroute *));
			free(candidates);
		}
		candidates = newCandidates;

		maxNumOfCandidates = n;
	}
	
	candidates[numOfCandidates] = c;
	numOfCandidates++;
	return;

}

struct s_binroute *BinRoute::decideRoute()
{
	//Check the balance info
	int i;
	struct s_RoundRobinBalInfo *info;
	long oldest = -1;
	long oldestCount = 0;
	int routeToUse = -1;
	
	struct timeb tmpTime;
	ftime(&tmpTime);
	long lastTime = tmpTime.time;
	for (i=0;i<numOfCandidates;i++)
	{
		info = (struct s_RoundRobinBalInfo *)candidates[i]->balanceInfo;
		if (oldest < 0)
		{
			routeToUse = i;
			oldest = info->lastTime;
			oldestCount = info->count;
		}
		else if (	(oldest > info->lastTime) ||
					((oldest == info->lastTime) && (oldestCount > info->count))
				)
		{
			routeToUse = i;
			oldest = info->lastTime;
			oldestCount = info->count;
		}
		else if (info->lastTime > lastTime)
		{
			//time is in future, this is not correct
			OTraceWarning("W-SHC-15305:route[%s]has balance time[%ld], current[%ld]\n", candidates[i]->port, info->lastTime, lastTime);
			info->lastTime = lastTime;
		}
	}
	
	if (oldest < 0)	//Should not happen
	{
		OTraceDebug("E-SHC-23503: Impossible, this must be a bug\n");
		throw 1;	
	}
					
	info = (struct s_RoundRobinBalInfo *)candidates[routeToUse]->balanceInfo;

	if (_shouldUpdateCounter)
	{		
		if (info->lastTime != lastTime)
		{
			info->lastTime = lastTime;
			info->count = 1;
		}
		else
		{
			++info->count;
		}
	}
	return candidates[routeToUse];

}

void BinRoute::useRoute(struct s_binroute *tmpRoute, struct RoutingInfo *routingInfo, int *outbound)
{

        routingInfo->siteId = tmpRoute->siteId;
        routingInfo->srcSiteId = mbGetSiteId();
	istsafe_strcpy(routingInfo->destNode, sizeof(routingInfo->destNode), tmpRoute->node);
	istsafe_strcpy(routingInfo->mailbox, sizeof(routingInfo->mailbox), tmpRoute->mailbox);
	//strcpy(routingInfo->port, tmpRoute->port);
	istsafe_strcpy(routingInfo->port, sizeof(routingInfo->port), tmpRoute->port);
	routingInfo->flag |= ROUTE_INFO_FLAG_USE_BINROUTE;
	if (outbound && (tmpRoute->mailboxId >= 0))
        *outbound = tmpRoute->mailboxId;

	
}

int BinRoute::chooseRoute(ShcmsgHeader *header, ShcBin *bin, struct RoutingInfo *routingBuf, int *outbound, struct InstitutionProfile *ip)
{
	int i;
	struct s_binroute *tmpRoute = NULL;
	struct s_binroute *firstDownRoute = NULL;
	struct s_binroute *firstUpRoute = NULL;
	int foundRoute = 0;
	struct InstitutionProfileShm *ipShm = NULL;

	char *p = NULL;

	if (ip)
	{
		i = shcApp->instProfileObj->locateById(ip->id);
		if (i >=0)
		{
			ipShm = shcApp->instProfileObj->getEntry(i);
			OTraceDebug("D-SHC-23520:Binroute Group used[%s]\n", ipShm->binrouteGroup);
		}
		else
			OTraceDebug("D-SHC-23524: Can't find inst_profile id[%d]. binroute group not used.\n", ip->id);
	}
	try
	{
		if (setBnrtRuleParam() < 0)
			return (-1);

		long routeHashValue = getHashValue(bin->binPkg->bin.networkid);
		
		OTraceDebug("D-SHC-23504:hash value to find [%ld]\n", routeHashValue);
		
		//if ( appidBinRoute>0 && rm_waitForLockedShdMem(appidBinRoute) )	// R023095
		//{
		//	OTraceWarning("W-SHC-23504a: rm.appid[%d] was locked. Go ahead\n", appidBinRoute);
		//}
		resetBalanceInfo();
		
		for (i=0, p=appKey ;i<appHead->keysused;i++, p+= appHead->keysize)
		{
			tmpRoute = (struct s_binroute *)p;
			if (tmpRoute->hashValue != routeHashValue)
			{
				if (firstUpRoute)
					break;
				else
					continue;
			}
			
			if (strcmp(tmpRoute->internalid, bin->binPkg->bin.networkid))
			{
				if (firstUpRoute)
					break;
				else
					continue;
			}
                        if (tmpRoute->siteId && (tmpRoute->siteId != mbGetSiteId()))
                        {
                                if (header->msg.device_cap & SH_DEVCAP_FROM_REPLAY)
                                {
                                        if (!shc_safBridgeEnabled(header->issShcBin->binPkg))
                                                continue;
                                }
                                else if (!(bin->binPkg->bin.bin_cfg & SH_CFG_ENABLE_DUAL_SITE_BRIDGE))
                                {
                                        continue;
                                }
                        }
			
                        if ( !ip || (ip && (strcmp(tmpRoute->binrouteGroup, ip->binrouteGroup)==0)))
			{}
			else
			{
				if (firstUpRoute)
					break;
				else
					continue;
			}
			
			if (firstUpRoute)
			{
				if (firstUpRoute->priority != tmpRoute->priority)
					break;
				
				if (strcmp(firstUpRoute->node, tmpRoute->node)!= 0)
					break;
			}
			
			if (tmpRoute->status == BIN_ROUTE_STATUS_DOWN)
			{
				if (!firstDownRoute)
					firstDownRoute = tmpRoute;
				continue;
			}
			
			addRouteCandidate(tmpRoute);
			
			if (!firstUpRoute)
				firstUpRoute = tmpRoute;
				
			foundRoute = 1;
		}
		
		if (!routingBuf)
			//Just checking whether an up route can be found
			return foundRoute;
			
		if (foundRoute)
		{
			tmpRoute = decideRoute();
			if (tmpRoute)
			{
				useRoute(tmpRoute, routingBuf, outbound);
				return 1;
			}
			else
			{
				OTraceDebug("D-SHC-23505:Error when choosing route.\n");
				return -1;
			}
		}
		
		//Can't find the route that is up, see whether a route can be found that is down
		if ( firstDownRoute )
		{
			OTraceDebug("D-SHC-23506:Only a down route is found\n");
			useRoute(firstDownRoute, routingBuf, outbound);
			return 2;
		}
		
		//Nothing can be found, just use the mailbox and port from bin
		OTraceDebug("D-SHC-23507:No binroute entry found, take info from bin\n");
		strcpy(routingBuf->destNode, bin->binPkg->bin.node);
		strcpy(routingBuf->mailbox, mbMailBoxName(bin->binPkg->bin.mailbox));
		strcpy(routingBuf->port, mbMailBoxName(bin->binPkg->bin.port));
		routingBuf->misc[0] = '\0';
		return 3;
	}
	catch(...)
	{
		return -1;
	}
}






int BinRoute::markRouteUp( char *networkId, struct RoutingInfo *routingInfo, int *needBinUp, char nodeType ) //R029275
{
	if ( needBinUp )
		*needBinUp = 0;
	
	char *tmpStr = staticBroadcastStr;
        snprintf(staticBroadcastStr,sizeof(staticBroadcastStr), "shccmd  -site %hd -s nodeupdate %s ", mbGetSiteId(), mbcurrentnode);

	tmpStr += strlen(staticBroadcastStr);
	int ret = changeRouteStatus( networkId, routingInfo, BIN_ROUTE_STATUS_UP, tmpStr, sizeof(staticBroadcastStr), nodeType ); //R029275
	
	if (tmpStr[0] && nodeType!=BIN_ROUTE_BALANCER_NODE) //R029275
                mcastHelperObj->broadcast("shccmd", 2, staticBroadcastStr , strlen(staticBroadcastStr), NULL, 0);
	if ( networkId && *networkId )
	{
		if ( needBinUp )
		{
			OTraceDebug("D-SHC-23508: marked %d route up, iss[%s] should up\n", numOfCandidates, networkId);
			*needBinUp = 1;
		}
		else
		{
			changeBinStatus( networkId, 1 );	// mark bin UP
		}
	}
	
	return ret;
}


int BinRoute::markRouteDown( char *networkId, struct RoutingInfo *routingInfo, int *needBinDown , char nodeType ) //R029275
{
	int i = 0;
	
	if ( needBinDown )
		*needBinDown = 0;

	char *tmpStr = staticBroadcastStr;
        snprintf(staticBroadcastStr, sizeof(staticBroadcastStr),"shccmd  -site %hd -s nodeupdate %s -down ", mbGetSiteId(), mbcurrentnode);
	tmpStr += strlen(staticBroadcastStr);

	int ret = changeRouteStatus( networkId, routingInfo, BIN_ROUTE_STATUS_DOWN, tmpStr, sizeof(staticBroadcastStr), nodeType); //R029275
//	if (tmpStr[0] && nodeType!=BIN_ROUTE_BALANCER_NODE) //R029275
	if (tmpStr[0])
                mcastHelperObj->broadcast("shccmd", 2, staticBroadcastStr , strlen(staticBroadcastStr), NULL, 0);
	
	if ( networkId && *networkId )
	{
		getRouteEntries( networkId, NULL , nodeType); //R029275
		
		int foundUpRoute = 0;
		for ( i=0; i<numOfCandidates; i++)
		{
			if ( candidates[i]->status != BIN_ROUTE_STATUS_DOWN )
			{
                                if(!candidates[i]->siteId || (candidates[i]->siteId == mbGetSiteId()))
                                {
                                        foundUpRoute = 1;
                                        break;
                                }
                                else
                                {
                                        if(shcApp->shcBinObj->setBinPkg(networkId) >= 0)
                                        {
                                                if (shcApp->shcBinObj->binPkg->bin.bin_cfg & SH_CFG_ENABLE_DUAL_SITE_BRIDGE)
                                                        foundUpRoute = 1;
                                        }
                                }
			}
		}
		
		if ( !foundUpRoute )
		{
			if ( needBinDown )
			{
				OTraceDebug("D-SHC-23509: All %d routes down, iss[%s] should down\n", numOfCandidates, networkId);
				*needBinDown = 1;
			}
			else
			{
				OTraceDebug("D-SHC-23510: All %d routes down, mark iss[%s] down\n", numOfCandidates, networkId);
				changeBinStatus( networkId, 0 );	// mark bin DOWN
			}
		}
		else if ( needBinDown )
		{
                        if (i <numOfCandidates)
			OTraceDebug("D-SHC-23511: route [n:%s/p:%s] is still up, keep iss[%s] up\n", candidates[i]->node, 
						candidates[i]->port, networkId);
			*needBinDown = 0;
		} 
		
		resetBalanceInfo();
	}
	
	return ret;
}


int BinRoute::changeBinStatus( char *bin, int upStatus )
{
	struct  shcpkg *pkg = NULL;
	
	if (shcApp->shcBinObj->setBinPkg(bin) < 0)
	{
		OTraceDebug("D-SHC-23512: Unable to locate shcpkg for bin[%s]\n", bin );
		
		return (-1);
	}
	
	if ( upStatus )
	{
		shcApp->shcBinObj->setInstUp();
	}
	else
	{
		shcApp->shcBinObj->setInstDown();
	}
	
	return 0;
}

//From position i to search back and forth, if all the binroute entries changed to
//status, the inst_profile entry should also be changed to status
//No lock here because it should belongs to an operation that already has locks
//The status in the parameter should always been down
int BinRoute::instProfileImpacted(struct s_binroute*changeEntry, int status)
{
	struct s_binroute *tmpRoute = NULL;
	char *p = NULL;
	
	int j;
	if (setBnrtRuleParam() < 0)
		return (-1);

	for (p=(char *)changeEntry; p>=appKey; p-=appHead->keysize )
	{
		tmpRoute = (struct s_binroute *)p;
                if (strcmp(tmpRoute->binrouteGroup, changeEntry->binrouteGroup)==0)
		{
			//End of searching backward, continue to forward
			break;
		}
		if (tmpRoute->status != status)
		{
			//Some status not changed, instProfile status should not change.
			return 0;
		}
	}

	char *endp = appKey + appHead->keysused*appHead->keysize;
	for ( p=((char *)changeEntry)+appHead->keysize; p < endp; p+=appHead->keysize )
	{
		tmpRoute = (struct s_binroute *)p;
                if (strcmp(tmpRoute->binrouteGroup, changeEntry->binrouteGroup)==0)
		{
			//End of searching forward, return
			break;
		}
		if (tmpRoute->status != status)
		{
			//Some status not changed, instProfile status should not change.
			return 0;
		}
	}
	return 1;

}

int BinRoute::changeRouteStatus( char *networkId, struct RoutingInfo *routingInfo, char routeStatus, char *broadcastStr, size_t brdcastStrSize, char nodeType) //R029275
{
	char *binAffected = NULL;
	static ShcBin *bin=NULL;
	int savedNoBroadcastFlag = noBraodcastFlag;

	noBraodcastFlag = 1;
	getRouteEntries( networkId, routingInfo , nodeType); //R029275
	
	for ( int i=0; i<numOfCandidates; i++)
	{
		if (candidates[i]->status == routeStatus)
			continue;
			
		if (broadcastStr)
		{
			broadcastStr += createBroadcastStr(broadcastStr, (brdcastStrSize - strlen(broadcastStr)), candidates[i]);
		}
		
		candidates[i]->status = routeStatus;
//              if (candidates[i]->inst_profile_id > 0)
//              {
//                      if ((routeStatus==BIN_ROUTE_STATUS_UP) || instProfileImpacted(candidates[i], routeStatus))
//                      {
//                              if (!shcApp)
//                                      shcApp = (ShcAppBase *)shcHelperRegister.getTargetObj(SHC_ShcAppBase);
//                              if (!shcApp)
//                              {
//                                      OTraceDebug("F-SHC-23518:Can't allocate ShcApp, quit...\n");
//                                      throw 1;
//                              }
//                              shcApp->instProfileObj->changeInstProfileStatus(candidates[i]->inst_profile_id, routeStatus, broadcastStr);
//                              if (broadcastStr)
//                                      broadcastStr += strlen(broadcastStr);
//                      }
//              }
                if (!ofThisSite || (ofThisSite == mbGetSiteId()))
                {
                        if (setBinUp)
                        {
                                if (!bin)
                                        bin = (ShcBin *)shcHelperRegister.getTargetObj(SHC_ShcBin);
                                if ((!binAffected)||((strcmp(binAffected, candidates[i]->internalid)!=0)))
                                {
                                        binAffected = candidates[i]->internalid;
                                        if (bin->setBinPkg(binAffected)>=0)
                                        {
                                                bin->setInstUp(1);
                                                if (broadcastStr)
                                                        broadcastStr += snprintf(broadcastStr, (brdcastStrSize-strlen(broadcastStr)), " -up %s", binAffected);
                                        }
                                        else
                                        {
                                                OTraceDebug("D-SHC-:Not a valid bin, do not mark up[%s/%s]\n",
                                                                candidates[i]->institutionid,
                                                                candidates[i]->userbinid);
                                        }
                                }
                        }
                }
	}
	
	noBraodcastFlag = savedNoBroadcastFlag;

	return numOfCandidates;
}


int BinRoute::getRouteEntries( char *networkId, struct RoutingInfo *routingInfo, char nodeType ) //R029275
{
	struct s_binroute *tmpRoute = NULL;
	char *p = NULL;

	char group [sizeof(_nouse->binroute_group)];
	istsafe_strcpy(group, sizeof(group),getRouteEntriesBinrouteGroup);
	getRouteEntriesBinrouteGroup[0] = 0;

	if ( !routingInfo && !(networkId && *networkId) )
	{
		OTraceError("E-SHC-23513: routingInfo and networkId is NULL\n");
		return (-1);
	}

	if (setBnrtRuleParam() < 0)
		return (-1);

	//if ( appidBinRoute>0 && rm_waitForLockedShdMem(appidBinRoute) )	// R023095
	//{
	//	OTraceWarning("W-SHC-23513a: rm.appid[%d] was locked. Go ahead\n", appidBinRoute);
	//}
	
	resetBalanceInfo();
	
	int i;
	for ( i=0,p=appKey; i<appHead->keysused; i++,p+=appHead->keysize )
	{
		tmpRoute = (struct s_binroute *)p;
		
		if ( networkId && *networkId )
		{
			if ( strcmp(tmpRoute->internalid, networkId) != 0 )
				continue;
		}
		
		if ( group[0] )
		{
			if ( strcmp(tmpRoute->binrouteGroup, group) != 0 )
				continue;
		}

		if ( routingInfo )
		{
                        if (( routingInfo->siteId)&& (routingInfo->siteId != tmpRoute->siteId))
                                continue;

			if ( routingInfo->destNode[0] )
			{
				//R029275 >>>
				if(nodeType==BIN_ROUTE_BALANCER_NODE)
				{
					if ( stricmp(tmpRoute->blrnode, routingInfo->destNode) != 0 )
						continue;
					//Only interested in local nodes
					if (stricmp(tmpRoute->node, mbcurrentnode) != 0 )
						continue;
				}
				else
				{
					if ( stricmp(tmpRoute->node, routingInfo->destNode) != 0 )
						continue;
				}
				//R029275 <<<
			}
			
                        if ( group[0] )
                        {
                                if ( stricmp(tmpRoute->binrouteGroup, group) != 0 )
                                        continue;
                        }

			
			if ( routingInfo->port[0] )
			{
				if ( stricmp(tmpRoute->port, routingInfo->port) != 0 )
					continue;
			}
		}
		
		addRouteCandidate(tmpRoute);
	}
	
	if ( routingInfo )
	{
		if(nodeType==BIN_ROUTE_BALANCER_NODE) //R029275
			OTraceDebug("D-SHC-23514: Found %d routes on balancer node[%s] mbox[%s] port[%s] for iss[%s]\n", numOfCandidates
				, routingInfo->destNode, routingInfo->mailbox, routingInfo->port, networkId?networkId:"*");
		else
			OTraceDebug("D-SHC-23514: Found %d routes on node[%s] mbox[%s] port[%s] for iss[%s]\n", numOfCandidates
				, routingInfo->destNode, routingInfo->mailbox, routingInfo->port, networkId?networkId:"*");
	}
	
	return numOfCandidates;
}


struct s_binroute* BinRoute::getRoute( int n )
{
	if ( n>=numOfCandidates || n<0 )
	{
		OTraceError("E-SHC-23515: Unable to get route entry. [%d]/[%d]\n", n, numOfCandidates);
		return NULL;
	}
	
	return candidates[n];
}
	
	
int BinRoute::createBroadcastStr( char *buf, size_t bufSize, struct s_binroute *route)
{
        if (route->siteId && (route->siteId != mbGetSiteId()))
                return 0;
        int len = snprintf(buf, bufSize, " -r %s %s %s %s ", route->node, route->binrouteGroup, route->port, route->internalid );
	return len;
}

int BinRoute::tidyUpBinStatus()
{
	struct s_binroute *pTmp;
	char *p;
	bin_t currentBin = { 0 };
	int haveRouteUp = 0;
        int haveRemoteRouteUp = 0;
	int key_count;
	if (setBnrtRuleParam() < 0)
		return (-1);

        int _ofThisSite = ofThisSite;
        ofThisSite = mbGetSiteId();     //We may be processing nodeupdate from other site, but it should affect this site

	int tmpFlag = noBraodcastFlag;
	noBraodcastFlag = 1; /* prevent broadcast bin status change */ 
	
	for(key_count = 0,p = appKey; key_count < appHead->keysused; key_count++, p+=appHead->keysize)
	{
		pTmp=(struct s_binroute*)p;
		if (!currentBin[0])
		{
			strcpy(currentBin, pTmp->internalid);
			haveRouteUp = 0;
			haveRemoteRouteUp = 0;
		}
		else if (strcmp(currentBin, pTmp->internalid)!=0)
		{
			if (!haveRouteUp)
			{
                                if(shcApp->shcBinObj->setBinPkg(currentBin) >= 0) //R029136
                                {
                                        if (((shcApp->shcBinObj->binPkg->bin.bin_cfg & SH_CFG_ENABLE_DUAL_SITE_BRIDGE) && haveRemoteRouteUp) ||
											shc_isdown(shcApp->shcBinObj->binPkg))
                                        {}
                                        else
                                                shcApp->shcBinObj->setInstDown();
                                }
			}
			strcpy(currentBin, pTmp->internalid);
			haveRouteUp = 0;
			haveRemoteRouteUp = 0;
		}
		if (pTmp->status == BIN_ROUTE_STATUS_UP)
                {
                        if      (!pTmp->siteId ||(pTmp->siteId == mbGetSiteId()))
                                haveRouteUp = 1;
                        else
                                haveRemoteRouteUp = 1;
                }
	}
        if (pTmp && !haveRouteUp && currentBin[0])
	{
                if (shcApp->shcBinObj->setBinPkg(currentBin) < 0)
                        OTraceDebug("E-SHC-23516:Can't find bin [%s]\n",currentBin);
                else
                {
			if (((shcApp->shcBinObj->binPkg->bin.bin_cfg & SH_CFG_ENABLE_DUAL_SITE_BRIDGE) && haveRemoteRouteUp) ||
								shc_isdown(shcApp->shcBinObj->binPkg))
                        {}
                        else
                        shcApp->shcBinObj->setInstDown();
                }
	}
        ofThisSite = _ofThisSite;
	noBraodcastFlag = tmpFlag;
	return 0;
}


int BinRoute::setRemoteRouteStatus(int status)
{
	struct s_binroute *pTmp;
	char *p;
	int key_count;
	if (setBnrtRuleParam() < 0)
		return (-1);
	
	//if ( appidBinRoute>0 && rm_waitForLockedShdMem(appidBinRoute) )	// R023095
	//{
	//	OTraceWarning("W-SHC-23517: rm.appid[%d] was locked. Go ahead\n", appidBinRoute);
	//}

	for(key_count = 0,p = appKey; key_count < appHead->keysused; key_count++, p+=appHead->keysize)
	{
		pTmp=(struct s_binroute*)p;
		if(strcmp(pTmp->node, mbcurrentnode)== 0)
			continue;
		pTmp->status = status;
	}
	tidyUpBinStatus();
	return 0;
	
}



int BinRoute::markRouteAndBinUp( char *networkId, struct RoutingInfo *routingInfo )
{
	char *tmpStr = staticBroadcastStr;
        snprintf(staticBroadcastStr,sizeof(staticBroadcastStr), "shccmd  -site %hd -s nodeupdate %s ", mbGetSiteId(), mbcurrentnode);

	tmpStr += strlen(staticBroadcastStr);
	setBinUp = 1;
	int ret = changeRouteStatus( networkId, routingInfo, BIN_ROUTE_STATUS_UP, tmpStr, sizeof(staticBroadcastStr) );
	setBinUp = 0;
	
	if (tmpStr[0])
                mcastHelperObj->broadcast("shccmd", 2, staticBroadcastStr , strlen(staticBroadcastStr), NULL, 0);
	return ret;
}


int BinRoute::createPseudoSharedMemory()
{
	static struct rules_keytab myKeytab = {0};
	static char myAppKey[BIN_ROUTE_SIZE_MEM] = {0};
	
	appHead = &myKeytab;
	appKey  = myAppKey;
	
	myKeytab.keysused = 0;
	myKeytab.textused = 0;
	myKeytab.keysize  = BIN_ROUTE_SIZE_MEM;
	myKeytab.nkeys    = 0;
	myKeytab.textsize = BIN_ROUTE_SIZE_MEM;
	myKeytab.ntext    = 0;
	
	return 0;
}

//R028925 >>>
struct s_binroute* BinRoute::getFirstUpRoute()
{
	int i;
	for(i=0;i<numOfCandidates;i++)
	{
                if((candidates[i]->status == BIN_ROUTE_STATUS_UP)&&(!candidates[i]->siteId ||(candidates[i]->siteId == mbGetSiteId())))
			break;
	}
	if(i==numOfCandidates)
	{
		OTraceError("E-SHC-23518: No Binroute with UP status found.\n");
		return NULL;
	}
	else
		return candidates[i];
}
//<<< R028925

int BinRoute::changeRouteStatus(struct s_binroute *pBinRoute, int status, char *broadcastStr, size_t brdcastStrSize)
{
	if (pBinRoute->status == status)
		return 0;	//Already at this status, no change
		
	if (broadcastStr)
	{
		broadcastStr += createBroadcastStr(broadcastStr, (brdcastStrSize-strlen(broadcastStr)), pBinRoute);
	}
	
	pBinRoute->status = status;
	
	return 1;
}

// >>> R029583
int BinRoute::setBnrtRuleParam()
{
	if (appidBinRoute < 0)
	{
		if(rm_init() < 0)
		{
			OTraceFatal("F-SHC-23521: Unable to connect to Rule manager\n");
			return(-1);
		}
		if((appidBinRoute = rm_getappid((char*)BIN_ROUTE_MESSAGE_NAME)) < 0)
		{
			OTraceFatal("F-SHC-23522:unable to locate message name: shc-bin-route\n");
			createPseudoSharedMemory();
		}
	}
	if ( rm_attach( appidBinRoute, RULES_VER_CURRENT) != 0)
	{
		OTraceError("E-SHC-23523: Unable to attach to CURRENT version \n");
		return(-1);
	}
	appHead = rm_getapphead(appidBinRoute);
	/*      Find the first entry of my key table */
	appKey = rm_getappkey(appidBinRoute);

	return 0;
}
// <<< R029583

//      >>>     R030592
BinRouteForInstProfile::BinRouteForInstProfile()
{
	_nbrOfIps = 0;
	_ipFirst = NULL;
}

BinRouteForInstProfile::~BinRouteForInstProfile()
{
}

int BinRouteForInstProfile::setInstProfiles( struct InstProfilesList* ip, int cnt )
{
	_ipFirst = ip;
	_nbrOfIps = cnt;
	return 0;
}

int BinRouteForInstProfile::indxInstProfileInList( int id, char* networkId, long routeHashValue )
{
    char    binrouteGroup[sizeof(_nouse->binroute_group)];
    sprintf(binrouteGroup, "%d", id);
    int r = indxInstProfileInList(binrouteGroup, networkId, routeHashValue);
    return r;

}
int BinRouteForInstProfile::indxInstProfileInList( char *group, char* networkId, long routeHashValue )
{
	int i;
	for ( i = 0; i < _nbrOfIps; i++ )
	{
		InstitutionProfileShm* p =  _ipFirst[i].p;
		if ( p == NULL )
		{
			OTraceDebug("E-SHC-23505: inst profile pointer null index[%d]\n", i);
			return -2;
		}

		if ( strcmp(group, p->binrouteGroup)!=0 )
			continue;

		struct shcpkg *binpkg = NULL;
		shcApp->shcBinObj->shc_locate_bin(&binpkg, p->m_bin);
		if ( !binpkg )
		{
			OTraceDebug("E-SHC-23505: error locating bin\n");
			return -2;
		}

		if ( strcmp(networkId, binpkg->bin.networkid) != 0 )
			continue;

		long ipHashValue = getHashValue(binpkg->bin.networkid);
		if ( ipHashValue != routeHashValue )
			continue;

		return i;
	}
	return -1;
}

int BinRouteForInstProfile::chooseRouteByIPList(struct RoutingInfo *routingBuf, int* outbound, int routeRemoteSite )
{
	int i;
	struct s_binroute *tmpRoute = NULL;
	struct s_binroute *firstDownRoute = NULL;
	struct s_binroute *firstUpRoute = NULL;
	int foundRoute = 0;
	
	char *p = NULL;

	if ( (_nbrOfIps == 0) || (_ipFirst == NULL) )
	{
		OTraceDebug("D-SHC-23506:Error no institution profile list\n");
		return -1;
	}
	if (setBnrtRuleParam() < 0)
		return (-1);

	try
	{
		int idx = -1;
		if ( appidBinRoute>0 && rm_waitForLockedShdMem(appidBinRoute) ) // R023095
		{
			OTraceWarning("W-SHC-23507: rm.appid[%d] was locked. Go ahead\n", appidBinRoute);
		}
		resetBalanceInfo();
		for (i=0, p=appKey ;i<appHead->keysused;i++, p+= appHead->keysize)
		{
			tmpRoute = (struct s_binroute *)p;
			
                        if (!routeRemoteSite && tmpRoute->siteId && (tmpRoute->siteId != mbGetSiteId()))
                                continue;

                        if ( (idx = indxInstProfileInList( tmpRoute->binrouteGroup,
				tmpRoute->internalid, tmpRoute->hashValue )) >= 0 )
			{}
			else
			{
				if ( firstUpRoute )
				{
					if (tmpRoute->hashValue != firstUpRoute->hashValue)
						break;
				}

				continue;
			}

			if (firstUpRoute)
			{
				if (firstUpRoute->priority != tmpRoute->priority)
					break;

				if (strcmp(firstUpRoute->node, tmpRoute->node)!= 0)
					break;
			}

			if (tmpRoute->status == BIN_ROUTE_STATUS_DOWN)
			{
				if (!firstDownRoute)
					firstDownRoute = tmpRoute;
				continue;
			}

			addRouteCandidate(tmpRoute);
                        OTraceDebug ( "D-SHC-23509 adding route candidate node[%s],group[%s],port[%s]\n",
                                        tmpRoute->node, tmpRoute->binrouteGroup, tmpRoute->port );

			if (!firstUpRoute)
				firstUpRoute = tmpRoute;

			foundRoute = 1;
		}
		
		if (foundRoute)
		{
			tmpRoute = decideRoute();
			if (tmpRoute)
			{
				useRoute(tmpRoute, routingBuf, outbound);
                                OTraceDebug ( "D-SHC-23510 use route:node[%s],group[%s],port[%s]\n",
                                                tmpRoute->node, tmpRoute->binrouteGroup, tmpRoute->port );
                                return (indxInstProfileInList ( tmpRoute->binrouteGroup,
                                                                                                tmpRoute->internalid,
                                                                                                tmpRoute->hashValue ));
			}
			else
			{
				OTraceDebug("D-SHC-23508:Error when choosing route.\n");
				return -1;
			}
		}

		//Can't find the route that is up, see whether a route can be found that is down
		if ( firstDownRoute )
		{
                        OTraceDebug ( "D-SHC-23511 only down route found. use route:node[%s],group[%s],port[%s]\n",
                                        firstDownRoute->node, firstDownRoute->binrouteGroup, firstDownRoute->port );
			useRoute(firstDownRoute, routingBuf, outbound);
                        return (indxInstProfileInList ( firstDownRoute->binrouteGroup,
                                                        firstDownRoute->internalid,
                                                        firstDownRoute->hashValue ));
		}

	}
	catch(...)
	{
	}
	return -1;
}
//      <<<     R030592
/* increment timeout counter value*/
void BinRoute::incCounter(struct RoutingInfo *routingInfo)
{
	if(getRouteEntries(routingInfo)>0)
	{
		for ( int i=0; i<numOfCandidates; i++)
		{
			candidates[i]->timeoutCounter++;
		}
	}
}

/* Reset timeout counter value*/
void BinRoute::resetCounter(struct RoutingInfo *routingInfo)
{
	if(getRouteEntries( routingInfo)>0)
	{
		for ( int i=0; i<numOfCandidates; i++)
		{
			candidates[i]->timeoutCounter=0;
		}
	}
}
int BinRoute::getRouteEntries(struct RoutingInfo *routingInfo)
{
	struct s_binroute *tmpRoute = NULL;
	char *p = NULL;

	char group [sizeof(_nouse->binroute_group)];
	istsafe_strcpy(group, sizeof(group),getRouteEntriesBinrouteGroup);
	getRouteEntriesBinrouteGroup[0] = 0;

	if ( !routingInfo)
	{
		OTraceError("E-SHC-23573: routingInfo is NULL\n");
		return (-1);
	}

	if (setBnrtRuleParam() < 0)
		return (-1);

	resetBalanceInfo();

	int i;
	for ( i=0,p=appKey; i<appHead->keysused; i++,p+=appHead->keysize )
	{
		tmpRoute = (struct s_binroute *)p;
		if ( group[0] )
		{
			if ( strcmp(tmpRoute->binrouteGroup, group) != 0 )
				continue;
		}
		if ( routingInfo )
		{
			if (( routingInfo->siteId)&& (routingInfo->siteId != tmpRoute->siteId))
				continue;
			if ( routingInfo->port[0] )
			{
				if ( stricmp(tmpRoute->port, routingInfo->port) != 0 )
					continue;
			}
		}
		addRouteCandidate(tmpRoute);
	}
	if ( routingInfo )
	{
		OTraceDebug("D-SHC-23594: Found %d routes \n", numOfCandidates);
	}
	return numOfCandidates;
}
int BinRoute::checkTimeoutCounterVal(struct RoutingInfo *routingInfo, int maxNoTimeout)
{
	if(getRouteEntries( routingInfo)>0)
	{
		for ( int i=0; i<numOfCandidates; i++)
		{
			OTraceDebug("D-SHC-23595: current retry count[%d]\n", candidates[i]->timeoutCounter);
			if(candidates[i]->timeoutCounter >= maxNoTimeout)
				return 0;
		}
	}
	return -1;
}
