//
// Copyright (C) 2004 eFunds Corporation ("eFunds").  All Rights Reserved.
// eFunds Canada Corporation is an authorized user.
//
// IST is a registered trademark of eFunds Corporation.  Other brand or
// product names are trademarks or registered trademarks of their respective
// holders.
//
// The information contained herein is the unpublished proprietary property
// of eFunds.  Except as specifically authorized in writing by eFunds, the
// holder of this document shall: i) keep all information contained herein
// confidential, and ii) protect the information, in whole or in part, from
// disclosure and dissemination to all third parties.
//
// This document and the software described in it are furnished under license
// and may be used or copied only in accordance with the terms of such license.
// This document is supplied for information purposes only, is subject to
// change without notice, and should not be construed as a commitment by
// either eFunds Corporation or eFunds Canada Corporation.
//
static char _UpdateMemHelper_cxx_what[] = "@(#) UpdateMemHelper.cxx 1.4 20/03/25 13:15:39";
/*
 *      IST and IST/Share are registered trademarks of Oasis Technology Ltd.
 *
 *      Copyright (C) 1990 - 1996 Oasis Technology Ltd.
 *      All Rights Reserved
 *      This Module contains Proprietary Information of
 *      Oasis Technology Ltd., and should be treated as Confidential.
 *
 *      THIS IS UNPUBLISHED PROPRIETARY SOURCE CODE OF OASIS TECHNOLOGY LTD.
 *      The copyright notice above does not evidence any
 *      actual or intended publication of such source code.
 *
 *                        MODIFICATION HISTORY                  REVIEW
 *
 *      SCR#    Who    Date       Description
 * ===========================================================================
 */

#include <str.h>
#include <UpdateMemHelper.h>

#include <ist_otrace.h>
#include <istsafe.h>
#include <algorithm>

static char cmdBuf[UPD_MEM_MAX_LEN];
UpdateMemHelper:: UpdateMemHelper( int _fromMbId ) 
{
	//Assuming mb_init is called alrready
	shccmdMailboxId = mb_locatemailbox("ShccmdDaemon");
	fromMbId = _fromMbId;
	return;
}


int UpdateMemHelper:: sendMemUpdate( char *ruleName, const char * ruleData, int ruleDataLen )
{
	char *cmdp;
	int len = snprintf(cmdBuf, sizeof(cmdBuf),"shccmd memupdate %20s ", ruleName);
	cmdp = cmdBuf+len;
 	ruleDataLen = std::min<int>(ruleDataLen, sizeof(cmdBuf) - len);	
	memcpy(cmdp, ruleData, ruleDataLen); 
	len = (IstSafeInt(len) + ruleDataLen).getInt();
	int ret;
	if ((ret = mb_write_nothrottle(shccmdMailboxId, fromMbId>0?fromMbId:shccmdMailboxId, cmdBuf, len))< 0)
	{
		OTraceError("E-UPDMEM-xxxxx:Failed to send to mailbox id(%d)\n", shccmdMailboxId);
		return -1;
	}
	else
	{
		OTraceDebug("D-UPDMEM-xxxxx:send (%d) bytes to mailbox(%s)\n", len, mbMailBoxName(shccmdMailboxId));
		OTraceTitleDump("D-UPDMEM-xxxxx:Following msg sent to (%s)\n", mbMailBoxName(shccmdMailboxId));
		OTraceHexDump((unsigned char *)cmdBuf, len);
	}
	
	return 0 ;
}

 
