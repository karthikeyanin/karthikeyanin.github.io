/*
 *	CUSC and CUSC/Share are registered trademarks of Oasis Technology Ltd.
 *
 *	Copyright (C) 1990 - 2003 Oasis Technology Ltd.
 *	All Rights Reserved
 *	This Module contains Proprietary Information of
 *	Oasis Technology Ltd., and should be treated as Confidential.
 *
 *	THIS IS UNPUBLISHED PROPRIETARY SOURCE CODE OF OASIS TECHNOLOGY LTD.
 *	The copyright notice above does not evidence any
 *	actual or intended publication of such source code.
 *
 *                        MODIFICATION HCUSCORY                  REVIEW
 *
 *	SCR#	Who		Date	Description			Who	Date
 * ===========================================================================
 *
#pragma ident "@(#) Shc300ReqDB.cxx 1.13.1.22 19/12/16 15:18:11"
*/

#include <stdio.h>
#include <string.h>
#include <dbm.h>
#include <shc.h>
#include <shcseg.h>
#include <ist_otrace.h>
#include <Shc300ReqDB.h>
#include <shccardstatus.h>
#include <shccardstatus.h>
#include <shccardstatushist.h>
#include <ShcmsgHeader.h>
#include <ShcmsgHelper.h>
#include <ic/ic_instid.h>
#include <DBM3.h>
#include <dbm_private.h>
#include <HaPtmCctHelper.h>
#include <ist_seg_tlv.h>
#include <ist_tlv_data.h>
#include <ist_seg_elf_id_map.h>
#include <ist_seg_name.h>
#include <ist_seg_shc300_req.h>
#include <ist_seg_shc300_resp.h>
#include <ExceptionObject.h>
#include <MRApplHelper.h>
#include <MRShccardTagDefs.h>
#include <ShcCardStatusChngAlw.h>
//#include <ShcApp.h>
//#include <ShcmsgTxnHelper.h>
#include <istsafe.h>
#include <sys/timeb.h>
#include <istsafe.h>

static  int chkshccardstat = 0;
int InsertHistFlagSet = 0;
int pre_status_change_not_allowed_flag = 0;
static bool GetCardStatusHistoryInsertFlag();

void Shc300ReqDB::dbInit()
{
	if( _dbConn != NULL )
		return;

	_dbConn = new DBMConn(dbm_dbconn);
}

void handleDBException(DBMConn* conObj, DBMStmt* stmt, const DBMException& e );

/**  Constructor  **/
Shc300ReqDB::Shc300ReqDB()
{
	_dbConn = NULL;
	_updateShcCardStatus = NULL;
	_deleteShcCardStatus = NULL;
	_insertShcCardStatus = NULL;
	_selectShcCardStatus = NULL;
	_insertShcCardStatusHiststmt = NULL;
	_insertShcCardStatusHiststmt1 = NULL;
}

/** Destructor **/
Shc300ReqDB::~Shc300ReqDB()
{
	dbm_close_all(getpid());
}

int Shc300ReqDB::update_shc300(ShcmsgHeader *header)
{
	ShcmsgHeader *thisHeader = (ShcmsgHeader *)header;
	int ret = 0;
	char req_status[5];
	char pre_status[5];
	int len=25;

	char data[25] ={0};
	char tmpdate[25] ={0};
	int  pre_date;
	int  req_date;
	int  ldata;
	pre_status_change_not_allowed_flag = 0;

	m_shcmsg = &header->msg;
	OTraceDebug("D-SHCCRDST-164001: SHC03XMSG for Update\n");
	ret = checkdbshccard(thisHeader);
	if(ret == 1)
	{
		if(shcApp->issuerShcParamsList->GetBool((char *)"shc.performcardstatuschangevalidation"))
		{
			static ShcCardStatusChngAlw *alwObj=NULL;
			if (!alwObj)
			{
			     alwObj=new ShcCardStatusChngAlw;
			}
			IstSegShc300Req *shc300req = NULL;
			shc300req = (IstSegShc300Req *)thisHeader->getSegmentObj(ElfIdMap::elf_to_id(IST_SEG_SHC300_REQ), 0);
			if(shc300req)
			{
				shc300req->getActioncode(req_status, &len);
			}
			strtrim(_shccardstatus.Status,pre_status);
			if((alwObj->checkallowance(header,(char*)_shccardstatus.Status,req_status))==0)
			{
				OTraceInfo("I-SHCCRDST-164002: Pan [%s] not Allowed for 300Update Card status[%s] req_status[%s] \n",shc_maskpan(m_shcmsg->pan),pre_status,req_status);
				return -2;
			}
		}
		else
		{
			IstSegShc300Req *shc300req = NULL;
			shc300req = (IstSegShc300Req *)thisHeader->getSegmentObj(ElfIdMap::elf_to_id(IST_SEG_SHC300_REQ), 0);
			if(shc300req)
			{
				shc300req->getActioncode(req_status, &len);
				memset(data, 0x00, sizeof(data)); len=25;
				shc300req->getDateaction(data, &len);
			}
			ldata=atoi(data);
			int i_tmp = 0;
			memset(&dt_time, 0x00, sizeof(dt_time));
			if(ldata>0 )
			{
				i_tmp      = ldata % 10000;
				int tmpvar = (IstSafeInt(ldata) / 10000).getInt();
				dt_time.yy = (IstSafeUInt(2000) + tmpvar).getUInt();
				dt_time.mm = i_tmp /100;
				dt_time.dd = i_tmp % 100;
				snprintf(tmpdate,sizeof(tmpdate),"%04d%02d%02d",dt_time.yy,dt_time.mm,dt_time.dd);
				req_date = atoi(tmpdate);
			}
			strtrim(_shccardstatus.Status,pre_status);
			pre_date=_shccardstatus.Effective_to;

			if((strcmp(pre_status,req_status) == 0) && (pre_date == req_date))
			{
				OTraceInfo("I-SHCCRDST-164002: Duplicate status/Effective_to is not Allowed for 300Update:[%s][%s][%d][%d]\n",pre_status,req_status,pre_date,req_date);
				return -3;
			}
			if((pre_date != req_date) && (strcmp(pre_status,req_status) == 0))
			{
				   pre_status_change_not_allowed_flag = 1;
				   OTraceInfo("I-SHCCRDST-164002: Changing effective_to date Only,Not Prestatus \n");
			}


		}

		if (updateShcCardStatus(thisHeader) == 1 )
		{
			if(GetCardStatusHistoryInsertFlag())
			{
				ret = checkdbshccard(thisHeader);			
				OTraceInfo("I-SHCCRDST-164015: Insert Flag is enabled for SHCCARDSTATUSHIST Table \n");
			
				if (insertShcCardStatusHist(thisHeader) == 1 )
					return 1;
				else
					return -1;
			}
			else
			{
				if (insertShcCardStatusHist(thisHeader) == 1 )
					return 1;
				else
					return -1;
			}	
		}
		else
			return -1;
	}
	else
	{
		OTraceInfo("I-SHCCRDST-164003: Pan [%s] not present for 300Update \n",shc_maskpan(m_shcmsg->pan));
		return -1;
	}
}

int Shc300ReqDB::delete_shc300(ShcmsgHeader *header)
{
	ShcmsgHeader *thisHeader = (ShcmsgHeader *)header;
	int ret = 0;
	m_shcmsg = &header->msg;
	OTraceDebug("D-SHCCRDST-164001: SHC03XMSG for Delete\n");
	ret = checkdbshccard(thisHeader);
	if(ret == 1)
	{
		if (deleteShcCardStatus(thisHeader) == 1 )
		{
                                  if (insertShcCardStatusHist(thisHeader) == 1 )
					  return 1;
                                  else
					  return -1;
		}
		else
			return -1;
	}
	else
	{
		OTraceInfo("I-SHCCRDST-164004: Pan [%s] not present for 300Delete \n",shc_maskpan(m_shcmsg->pan));
		return -1;
	}
}

int Shc300ReqDB::add_shc300(ShcmsgHeader *header)
{
	ShcmsgHeader *thisHeader = (ShcmsgHeader *)header;
	int ret = 0;
	char req_status[5];
	char pre_status[5];
	int len=25;
	char data[25] ={0};
	char tmpdate[25] ={0};
	int  pre_date;
	int  req_date;
	int  ldata;
	pre_status_change_not_allowed_flag = 0;

	OTraceDebug("D-SHCCRDST-164001: SHC03XMSG for Add/Replace\n");
	m_shcmsg = &header->msg;
	ret = checkdbshccard(thisHeader);
	IstSegShc300Req *shc300req = NULL;
	shc300req = (IstSegShc300Req *)thisHeader->getSegmentObj(ElfIdMap::elf_to_id(IST_SEG_SHC300_REQ), 0);
	if(shc300req)
	{
		shc300req->getActioncode(req_status, &len);
		memset(data, 0x00, sizeof(data)); len=25;
		shc300req->getDateaction(data, &len);

	}
	ldata=atoi(data);
	int i_tmp = 0;
	memset(&dt_time, 0x00, sizeof(dt_time));
	if(ldata>0 )
	{
		i_tmp      = ldata % 10000;
		int tmpvar = (IstSafeInt(ldata) / 10000).getInt();
		dt_time.yy = (IstSafeUInt(2000) + tmpvar).getUInt();
		dt_time.mm = i_tmp /100;
		dt_time.dd = i_tmp % 100;
		snprintf(tmpdate,sizeof(tmpdate),"%04d%02d%02d",dt_time.yy,dt_time.mm,dt_time.dd);
		req_date = atoi(tmpdate);
	}

	if(_shccardstatus.Status[0] != '\0')
        {
                strtrim(_shccardstatus.Status,pre_status);
		pre_date=_shccardstatus.Effective_to;
                if((strcmp(pre_status,req_status) == 0) && (pre_date == req_date))
                {
                        OTraceInfo("I-SHCCRDST-164002: Duplicate status/Effective_to is not Allowed for 300Update:[%s][%s][%d][%d]\n",pre_status,req_status,pre_date,req_date);
                        return -3;
                }
		if((pre_date != req_date) && (strcmp(pre_status,req_status) == 0))
		{
			pre_status_change_not_allowed_flag = 1;
			OTraceInfo("I-SHCCRDST-164002: Changing effective_to date Only,Not Prestatus \n");
		}
        }

	if(ret == 1)
	{
		if((strcmp(header->msg.txnSrc,"FN") != 0) && (shcApp->issuerShcParamsList->GetBool((char *)"shc.performcardstatuschangevalidation")))
		{
			static ShcCardStatusChngAlw *alwObj=NULL;
			if (!alwObj)
			{
				alwObj=new ShcCardStatusChngAlw;
			}
			if((alwObj->checkallowance(header,(char*)_shccardstatus.Status,req_status))==0)
			{
				OTraceInfo("I-SHCCRDST-164005: Pan [%s] not Allowed for 300Update \n",shc_maskpan(m_shcmsg->pan));
				return -2;
			}
		}
		if((strcmp(header->msg.txnSrc,"FN") == 0) && ((strcmp(req_status,SHC300_UNBLOCK)==0) || (strcmp(req_status,SHC300_BLOCK)==0)) && (strncmp((char*)_shccardstatus.Status,SHC300_HOTBLOCK,2)==0))
                {
                        OTraceInfo("I-SHCCRDST-164006: Unable to unblock/block the card [%s] since it is marked as hotcard \n",shc_maskpan(m_shcmsg->pan));
                        return -1;
                }
		if (updateShcCardStatus(thisHeader) == 1 )
		{
			if(GetCardStatusHistoryInsertFlag())
			{
				ret = checkdbshccard(thisHeader);			
				
				OTraceInfo("I-SHCCRDST-164016: Insert Flag is enabled for SHCCARDSTATUSHIST Table\n");
			
				if (insertShcCardStatusHist(thisHeader) == 1 )
					return 1;
				else
					return -1;
			}
			else
			{
				if (insertShcCardStatusHist(thisHeader) == 1 )
					return 1;
				else
					return -1;
			}	
		}
		return -1;
	}
	else
	{
              if(strcmp(req_status,SHC300_UNBLOCK)==0)
                {
                        OTraceInfo("I-SHCCRDST-164007: No record for pan [%s] , No Need to Insert a record \n",shc_maskpan(m_shcmsg->pan));
                        return -1;
                }
           else if((strcmp(header->msg.txnSrc,"FN") != 0) && (shcApp->issuerShcParamsList->GetBool((char *)"shc.performcardstatuschangevalidation")))
                {
                      OTraceDebug("D-SHCCRDST: Inserting  the Record from GUI\n");
                        static ShcCardStatusChngAlw *alwObj=NULL;
                        if (!alwObj)
                        {
                                alwObj=new ShcCardStatusChngAlw;
                        }
                        if((alwObj->checkallowance(header,req_status,req_status))==0)
                        {
                                OTraceInfo("I-SHCCRDST-164005: Pan [%s] not Allowed for 300insert \n",shc_maskpan(m_shcmsg->pan));
                                return -2;
                        }
                }
                if ((insertShcCardStatus(thisHeader)) == 1)
                {
                     if(GetCardStatusHistoryInsertFlag())
                      {
                                OTraceInfo("I-SHCCRDST-164017: Initial Insert Flag is enabled for SHCCARDSTATUSHIST Table\n");
                                if (InitialinsertShcCardStatusHist(thisHeader) == 1 )
                                        return 1;
                                else
                                        return -1;
                      }
                        else
                                return 1;
                }
                else
                        return -1;
	}

}

int Shc300ReqDB::select_shc300(ShcmsgHeader *header)
{
	int ret = 0;
	ShcmsgHeader *thisHeader = (ShcmsgHeader *)header;
	m_shcmsg = &header->msg;
	OTraceDebug("D-SHCCRDST-164001: SHC03XMSG for Select\n");
	ret = checkdbshccard(thisHeader);
	if(ret == 1)
	{
		IstSegShc300Req *shc300req = NULL;
		shc300req = (IstSegShc300Req *)header->getSegmentObj(ElfIdMap::elf_to_id(IST_SEG_SHC300_REQ), 0);
		if(shc300req)
		{
			shc300req->setActioncode((char *)_shccardstatus.Status, strlen(_shccardstatus.Status));
		}
	}
	else
	{
		OTraceInfo("I-SHCCRDST-164008: Pan [%s] not present for 300Select \n",shc_maskpan(m_shcmsg->pan));
		return -1;
	}
	return 1;
}

int Shc300ReqDB::prepareinsertShcCardStatusHiststmt()
{
	if(!_insertShcCardStatusHiststmt)
	{
		_insertShcCardStatusHiststmt=_dbConn->getStmt();
		try
		{
			int sno=1;
			_insertShcCardStatusHiststmt->prepare("insert into shccardstatushist(siteid,pan,effective_from,effective_to,status,prestatus,created,changetype,source,created_time_msec)"
													"values"
													"(?,?,to_date(?,'DD-MON-YY HH24:MI:SS'),to_date(?,'DD-MON-YY HH24:MI:SS'),?,?,?,?,?,?)");
			_insertShcCardStatusHiststmt->bindParam(sno++, siteid );
			_insertShcCardStatusHiststmt->bindParam(sno++, DBM_PANTOKENTYPE, _shccardstatushist.Pan, sizeof(_shccardstatushist.Pan), NULL );
			_insertShcCardStatusHiststmt->bindParam(sno++, DBM_STRINGTYPE, &_tmpshccardstatushist.Effective_from , sizeof(_tmpshccardstatushist.Effective_from ), NULL );
			_insertShcCardStatusHiststmt->bindParam(sno++, DBM_STRINGTYPE, &_tmpshccardstatushist.Effective_to , sizeof(_tmpshccardstatushist.Effective_to ), NULL );
			_insertShcCardStatusHiststmt->bindParam(sno++, DBM_STRINGTYPE, _shccardstatushist.Status , sizeof(_shccardstatushist.Status), NULL );
			_insertShcCardStatusHiststmt->bindParam(sno++, DBM_STRINGTYPE, _shccardstatushist.Prestatus , sizeof(_shccardstatushist.Prestatus), NULL );
			_insertShcCardStatusHiststmt->bindParam(  sno++, updated);
			_insertShcCardStatusHiststmt->bindParam(sno++, changetype );
			_insertShcCardStatusHiststmt->bindParam(sno++, DBM_STRINGTYPE, _shccardstatushist.Source , sizeof(_shccardstatushist.Source), NULL );
			_insertShcCardStatusHiststmt->bindParam(sno++, created_msec );

		}
		catch( const DBMException& e )
		{
			handleDBException( _dbConn, _insertShcCardStatusHiststmt, e );
			OTraceError
				(
					"E-SHCCRDST-5128:caught exception in prepare insert shccardstatushist  "
					"native error=%d, sqlstate=%.5s, msg=%s\n",
					e.getNativeError(), e.getSQLState().data(), e.getErrMsg().data()
				);
			return -1;
		}
	}
	return 1;
}

int Shc300ReqDB::insertShcCardStatusHist(ShcmsgHeader *header)
{
    ShcmsgHeader *thisHeader = (ShcmsgHeader *)header;
    m_shcmsg = &header->msg;
    char  data[25] ={0};
    char status[4] = {0};
    int len = 25;

	 try
	    {
			if(prepareinsertShcCardStatusHiststmt())
			{
				OCDateTime current;
				updated.setValue(current);

				if(_insertShcCardStatusHiststmt->execute()!=DBM_SUCCESS)
				{
					OTraceError("E-SHCCRDST-5128: Cannot insert ShcCardStatushist\n");
					return ( -1 );
				}
				_insertShcCardStatusHiststmt->close();
			}
			else
			{
				OTraceDebug("E-SHCCRDST-5128:Failed in ShcDardStatusHist Prepare Stmt\n");
			}
		}
		catch( const DBMException& e )
			{
				handleDBException( _dbConn, _insertShcCardStatusHiststmt, e );
				OTraceError
				(
					"E-SHCCRDST-5128:caught exception in insert shccardstatushist"
					"native error=%d, sqlstate=%.5s, msg=%s\n",
					e.getNativeError(), e.getSQLState().data(), e.getErrMsg().data()
				);
				return -1;
			}
			return 1;
}


int Shc300ReqDB::insertShcCardStatus(ShcmsgHeader *header)
{
    MRApplHelper *mrHelper =  MRApplHelper::getInstance(IST_MR_SERVICE_NAME_SHCCARD);
    ShcmsgHeader *thisHeader = (ShcmsgHeader *)header;
    m_shcmsg = &header->msg;

    char  data[25] ={0};
    char status[4] = {0};
    int len = 25;

    try
    {
		if(prepareInsertShcCardStatus())
		{
			memcpy(_shccardstatus.Pan,m_shcmsg->pan,strlen(_shccardstatus.Pan));
			shc_normalizepan(_shccardstatus.Pan);

			site_id= mbGetSiteId();
			siteid.setValue(site_id);

			istsafe_strcpy(_shccardstatus.Source,sizeof(_shccardstatus.Source),m_shcmsg->txnSrc);

			OCDateTime current;
			updated.setValue(current);

			IstSegShc300Req *shc300req = NULL;
			shc300req = (IstSegShc300Req *)thisHeader->getSegmentObj(ElfIdMap::elf_to_id(IST_SEG_SHC300_REQ), 0);
			if(shc300req)
			{
				shc300req->getActioncode((char *)status, &len);
				memset(data, 0x00, sizeof(data)); len=25;
				shc300req->getDateaction(data, &len);
			}
			else
				return -1;

			int  ldata;
			ldata=atoi(data);

			int i_tmp = 0;

			memset(&dt_time, 0x00, sizeof(dt_time));
			if(ldata>0 )
			{
				i_tmp      = ldata % 10000;
				dt_time.yy = 2000 +(ldata / 10000);
				dt_time.mm = i_tmp /100;
				dt_time.dd = i_tmp % 100;
				dt_time.hrs = 23;
                                dt_time.mins = 59;
                                dt_time.secs = 59;

			}
			OCDateTime efftodate(dt_time.yy, dt_time.mm, dt_time.dd,dt_time.hrs,dt_time.mins,dt_time.secs);
			effectiveto.setValue(efftodate);

			strcpy(_shccardstatus.Status,status);
			_shccardstatus.Siteid = mbGetSiteId();

			mrHelper->setReplicateOn(INSERT_SHCCARDSTATUS);
			mrHelper->setData(TAG_SITE_ID, _shccardstatus.Siteid);
			mrHelper->setData(TAG_PAN, _shccardstatus.Pan, OPT_DATA_IS_PAN );
			mrHelper->setData(TAG_INSTITUTION_ID, _shccardstatus.Source);
			mrHelper->setData(TAG_CARD_STATUS, _shccardstatus.Status);
			mrHelper->setData(TAG_PRESTATUS, _shccardstatus.Prestatus);
			mrHelper->setData(TAG_EFFECTIVE_TO, ldata);
		}
		if(_insertShcCardStatus->execute()!=DBM_SUCCESS)
		{
			OTraceError("E-SHCCRDST-5128: Cannot insert ShcCardStatus\n");
			return ( -1 );
		}
		_insertShcCardStatus->close();
	}
	catch( const DBMException& e )
	{
		handleDBException( _dbConn, _insertShcCardStatus, e );
		OTraceError
		(
			"E-SHCCRDST-5128:caught exception in insert shccardstatus"
			"native error=%d, sqlstate=%.5s, msg=%s\n",
			e.getNativeError(), e.getSQLState().data(), e.getErrMsg().data()
		);
		return -1;
	}
	return 1;
}

int Shc300ReqDB::prepareInsertShcCardStatus()
{
	 if (!_insertShcCardStatus)
    {
		_insertShcCardStatus=_dbConn->getStmt();
		try
		{
			int sno = 1;
			_insertShcCardStatus->prepare ("insert into shccardstatus (siteid,pan,source,effective_from, effective_to,status, updated)"
											"values"
											"(?,?,?,?,?,?,?)");
			_insertShcCardStatus->bindParam(  sno++, siteid );
			_insertShcCardStatus->bindParam(  sno++, DBM_PANTOKENTYPE, _shccardstatus.Pan, sizeof(_shccardstatus.Pan), NULL );
			_insertShcCardStatus->bindParam(  sno++, DBM_STRINGTYPE, _shccardstatus.Source, sizeof(_shccardstatus.Source), NULL );
			_insertShcCardStatus->bindParam(  sno++, updated );
			_insertShcCardStatus->bindParam( sno++, effectiveto );
			_insertShcCardStatus->bindParam(  sno++, DBM_STRINGTYPE, _shccardstatus.Status , sizeof(_shccardstatus.Status), NULL );
			_insertShcCardStatus->bindParam(  sno++, updated );
		}
		catch( const DBMException& e )
		{
			handleDBException( _dbConn, _insertShcCardStatus, e );
			OTraceError
					(
					     "E-SHCCRDST-5128:caught exception in prepare insert shccardstatus status "
						 "native error=%d, sqlstate=%.5s, msg=%s\n",
						 e.getNativeError(), e.getSQLState().data(), e.getErrMsg().data()
					);
			return -1;
		}
	}
	return 1;
}

int Shc300ReqDB::prepareUpdateShcCardStatus()
{
	if (!_updateShcCardStatus)
	{
		_updateShcCardStatus = _dbConn->getStmt();

		try
		{
			_updateShcCardStatus->prepare ("update shccardstatus set status = ? , prestatus = ?, source = ?, effective_to = ? , updated = ? where pan = ? and siteid = ? ");
			int i = 1;
			int cnt=2;
			_updateShcCardStatus->bindParam(i++, DBM_STRINGTYPE, _shccardstatus.Status, sizeof(_shccardstatus.Status), NULL);
			_updateShcCardStatus->bindParam(i++, DBM_STRINGTYPE, _shccardstatus.Prestatus, sizeof(_shccardstatus.Prestatus), NULL);
			_updateShcCardStatus->bindParam(i++, DBM_STRINGTYPE, _shccardstatus.Source, sizeof(_shccardstatus.Source), NULL);
			_updateShcCardStatus->bindParam(i++,effectiveto);
			_updateShcCardStatus->bindParam( i++, updated);
			_updateShcCardStatus->bindParam(i++, DBM_PANTOKENTYPE, _shccardstatus.Pan, sizeof(_shccardstatus.Pan), NULL);
			_updateShcCardStatus->bindParam(i++, siteid );

		}

		catch( const DBMException& e )
		{
			handleDBException( _dbConn, _updateShcCardStatus, e );
		 	OTraceError
			(
			     "E-SHCCRDST-5128:caught exception in prepare update shccardstatus status "
						 "native error=%d, sqlstate=%.5s, msg=%s\n",
						 e.getNativeError(), e.getSQLState().data(), e.getErrMsg().data()
			);
			return -1;
		}
	}
	return 1;
}

int Shc300ReqDB::updateShcCardStatus(ShcmsgHeader *header)
{

	ShcmsgHeader *thisHeader = (ShcmsgHeader *)header;
	m_shcmsg = &header->msg;

	MRApplHelper *mrHelper =  MRApplHelper::getInstance(IST_MR_SERVICE_NAME_SHCCARD);

	int len=25;
	char  data[25] ={0};
	char    prestatus[5];

	if (prepareUpdateShcCardStatus() < 0)
	{
		return -1;
	}

	memset(prestatus,0x00,sizeof(prestatus));
	if(pre_status_change_not_allowed_flag == 1)
	memcpy(prestatus,_shccardstatus.Prestatus,sizeof(_shccardstatus.Prestatus));
	else
	memcpy(prestatus,_shccardstatus.Status,sizeof(_shccardstatus.Status));


	memset (&_shccardstatus, 0, sizeof(struct shccardstatus));

	IstSegShc300Req *shc300req = NULL;
	shc300req = (IstSegShc300Req *)thisHeader->getSegmentObj(ElfIdMap::elf_to_id(IST_SEG_SHC300_REQ), 0);
	if(shc300req)
	{
		shc300req->getActioncode((char *)_shccardstatus.Status, &len);
		memset(data, 0x00, sizeof(data));
		shc300req->getDateaction(data, &len);
	}
	memcpy(_shccardstatus.Pan,m_shcmsg->pan,sizeof(_shccardstatus.Pan));
	shc_normalizepan(_shccardstatus.Pan);

        site_id=mbGetSiteId();
        siteid.setValue(site_id);

	istsafe_strcpy(_shccardstatus.Source,sizeof(_shccardstatus.Source),m_shcmsg->txnSrc);
	memcpy(_shccardstatus.Prestatus,prestatus,sizeof(_shccardstatus.Prestatus));
	
	OCDateTime current;
	updated.setValue(current);

	int  ldata;
	ldata=atoi(data);

	int i_tmp = 0;

	memset(&dt_time, 0x00, sizeof(dt_time));
	if(ldata>0 )
	{
		i_tmp      = ldata % 10000;
		dt_time.yy = 2000 +(ldata / 10000);
		dt_time.mm = i_tmp /100;
		dt_time.dd = i_tmp % 100;
		dt_time.hrs = 23;
		dt_time.mins = 59;
		dt_time.secs = 59;

	}
	OCDateTime efftodate(dt_time.yy, dt_time.mm, dt_time.dd,dt_time.hrs, dt_time.mins, dt_time.secs);
	effectiveto.setValue(efftodate);


	_shccardstatus.Siteid = mbGetSiteId();

 	try
	{
		 mrHelper->setReplicateOn(UPDATE_SHCCARDSTATUS);
		 mrHelper->setData(TAG_SITE_ID, _shccardstatus.Siteid);
		 mrHelper->setData(TAG_PAN, _shccardstatus.Pan, OPT_DATA_IS_PAN );
		 mrHelper->setData(TAG_INSTITUTION_ID, _shccardstatus.Source);
		 mrHelper->setData(TAG_CARD_STATUS, _shccardstatus.Status);
		 mrHelper->setData(TAG_PRESTATUS, _shccardstatus.Prestatus);
		 mrHelper->setData(TAG_EFFECTIVE_TO, ldata);
		 _updateShcCardStatus->execute();
		 _updateShcCardStatus->close();
	}
	catch( const DBMException& e )
	{
		handleDBException( _dbConn, _updateShcCardStatus, e );
		OTraceError
		(
			"E-SHCCRDST-5128:caught exception in update shccardstatus"
			"native error=%d, sqlstate=%.5s, msg=%s\n",
			e.getNativeError(), e.getSQLState().data(), e.getErrMsg().data()
		);
		return -1;
	}
	return 1;
}

int Shc300ReqDB::prepareDeleteShcCardStatus()
{

	if (!_deleteShcCardStatus)
	{
		int i = 1;
		_deleteShcCardStatus = _dbConn->getStmt();

		try
		{
			_deleteShcCardStatus->prepare ("delete  from shccardstatus where pan = ?  and siteid = ?");

			_deleteShcCardStatus->bindParam(i++, DBM_PANTOKENTYPE, _shccardstatus.Pan, sizeof(_shccardstatus.Pan), NULL);
			_deleteShcCardStatus->bindParam(i++, siteid );
		}

		catch( const DBMException& e )
		{
			handleDBException( _dbConn, _deleteShcCardStatus, e );
		 	OTraceError
			(
			     "E-SHCCRDST-5128:caught exception in prepare delete shccardstatus status "
						 "native error=%d, sqlstate=%.5s, msg=%s\n",
						 e.getNativeError(), e.getSQLState().data(), e.getErrMsg().data()
			);
			return -1;
		}
	}
	return 1;
}

int Shc300ReqDB::deleteShcCardStatus(ShcmsgHeader *header)
{
	MRApplHelper *mrHelper =  MRApplHelper::getInstance(IST_MR_SERVICE_NAME_SHCCARD);
	m_shcmsg = &header->msg;
	if (prepareDeleteShcCardStatus() < 0)
	{
		return -1;
	}
	memset (&_shccardstatus, 0, sizeof(struct shccardstatus));
	istsafe_strcpy(_shccardstatus.Pan,sizeof(_shccardstatus.Pan),m_shcmsg->pan);
	shc_normalizepan(_shccardstatus.Pan);

        site_id=mbGetSiteId();
        siteid.setValue(site_id);

	_shccardstatus.Siteid=mbGetSiteId();
 	try
	{
		  mrHelper->setReplicateOn(DELETE_SHCCARDSTATUS);
		  mrHelper->setData( TAG_PAN, _shccardstatus.Pan, OPT_DATA_IS_PAN  );
		  mrHelper->setData(TAG_SITE_ID, _shccardstatus.Siteid);

		 _deleteShcCardStatus->execute();
		 _deleteShcCardStatus->close();
	}
	catch( const DBMException& e )
	{
		handleDBException( _dbConn, _deleteShcCardStatus, e );
		OTraceError
		(
			"E-SHCCRDST-5128:caught exception in delete shccardstatus"
			"native error=%d, sqlstate=%.5s, msg=%s\n",
			e.getNativeError(), e.getSQLState().data(), e.getErrMsg().data()
		);
		return -1;
	}
	return 1;
}
int Shc300ReqDB::checkdbshccard(ShcmsgHeader *header)
{

	int ret = 0;
	int rc;
	int mseconds = 0;
	struct timeb tmpTime;

	dbInit();
	m_shcmsg = &header->msg;
	if ( _selectShcCardStatus == NULL )
		_selectShcCardStatus = _dbConn->getStmt();
	if (chkshccardstat != 1)
	{
		rc = prepareshccardstatusselect();
		if ( rc != 0 )
		{
			OTraceError( "E-SHCCRDST-164013: Failed in Prepare for shccardstatus\n" );
			return -1;
		}
	}
	memset( &_shccardstatushist, 0, sizeof(_shccardstatushist) );
	memset( &_shccardstatus, 0, sizeof(_shccardstatus) );
	try
	{
		memcpy( _shccardstatus.Pan, m_shcmsg->pan,sizeof(_shccardstatus.Pan));
		shc_normalizepan(_shccardstatus.Pan);
	    site_id=mbGetSiteId();
	    siteid.setValue(site_id);

	    _shccardstatus.Siteid=mbGetSiteId();
		_selectShcCardStatus->execute();

		rc = _selectShcCardStatus->fetch();
		_selectShcCardStatus->close();


		if( rc == DBM_NO_DATA )
		{
			OTraceInfo("I-SHCCRDST-164014: Pan not found for processing \n");
			return 0;
		}
		else
		{
			memcpy( _shccardstatushist.Pan, _shccardstatus.Pan, strlen(_shccardstatus.Pan) );
			istsafe_strcpy(_tmpshccardstatushist.Effective_from,sizeof(_tmpshccardstatushist.Effective_from),_tmpshccardstatus.Effective_from);
			istsafe_strcpy(_tmpshccardstatushist.Effective_to,sizeof(_tmpshccardstatushist.Effective_to),_tmpshccardstatus.Effective_to);

			_shccardstatushist.Effective_to=_shccardstatus.Effective_to;
			memcpy( _shccardstatushist.Status, _shccardstatus.Status,strlen(_shccardstatus.Status));
			memcpy( _shccardstatushist.Prestatus, _shccardstatus.Prestatus,strlen(_shccardstatus.Prestatus));
			time_t curr_time = time(NULL);
			_shccardstatushist.Created = curr_time;
			_shccardstatushist.Siteid = _shccardstatus.Siteid;
			memcpy( _shccardstatushist.Source, _shccardstatus.Source,strlen(_shccardstatus.Source));
			int len=25;int datacd;
			char fbuf[2]="";
			IstSegShc300Req *shc300req = NULL;
			shc300req = (IstSegShc300Req *)header->getSegmentObj(ElfIdMap::elf_to_id(IST_SEG_SHC300_REQ), 0);
			if(shc300req)
			{
				shc300req->getFileupdatecode(fbuf, &len);
				datacd=atoi(fbuf);
				changetype.setValue(datacd);
			}

			ftime(&tmpTime);
			mseconds = tmpTime.millitm;
			created_msec.setValue(mseconds);

	    		return 1;
		}
	}
		catch(const DBMException& e)
		{
			handleDBException( _dbConn, _selectShcCardStatus, e );
			OTraceError
			(
				"E-SHCCRDST caught exception in select shccardstatus,"
				"native error=%d, sqlstate=%.5s, msg=%s\n",
				e.getNativeError(), e.getSQLState().data(), e.getErrMsg().data()
			);
			return -1;
		}
}

int Shc300ReqDB::prepareshccardstatusselect()
{
	memset( _ind, 0, sizeof(_ind) );

	try
	{
		_selectShcCardStatus->prepare("SELECT siteid, pan, source, (to_char(effective_from,'DD-MON-YY HH24:MI:SS')), (to_char(effective_to,'DD-MON-YY HH24:MI:SS')), status, prestatus FROM shccardstatus where pan= ? and siteid = ?");
		int sno = 1;
			int cnt = 2;
			_selectShcCardStatus->bindCol(sno++,siteid );
			_selectShcCardStatus->bindCol(sno++, DBM_PANTOKENTYPE, _shccardstatus.Pan, sizeof(_shccardstatus.Pan), &_ind[cnt++] );
			_selectShcCardStatus->bindCol(sno++, DBM_STRINGTYPE, _shccardstatus.Source, sizeof(_shccardstatus.Source),&_ind[cnt++] );
			_selectShcCardStatus->bindCol(sno++, DBM_STRINGTYPE, &_tmpshccardstatus.Effective_from , sizeof(_tmpshccardstatus.Effective_from ), &_ind[cnt++] );
			_selectShcCardStatus->bindCol(sno++, DBM_STRINGTYPE, &_tmpshccardstatus.Effective_to , sizeof(_tmpshccardstatus.Effective_to ),&_ind[cnt++] );
			_selectShcCardStatus->bindCol(sno++, DBM_STRINGTYPE, _shccardstatus.Status , sizeof(_shccardstatus.Status), &_ind[cnt++] );
			_selectShcCardStatus->bindCol(sno++, DBM_STRINGTYPE, _shccardstatus.Prestatus, sizeof(_shccardstatus.Prestatus), &_ind[cnt++] );
			_selectShcCardStatus->bindParam(1, DBM_PANTOKENTYPE, _shccardstatus.Pan, sizeof(_shccardstatus.Pan),NULL );
		   _selectShcCardStatus->bindParam(2, siteid );

		}
		catch (const DBMException& e)
		{
			handleDBException( _dbConn, _selectShcCardStatus, e );
			OTraceError
			(
				"E-SHCCRDST caught exception in prepare shccardstatus,"
				"native error=%d, sqlstate=%.5s, msg=%s\n",
				e.getNativeError(), e.getSQLState().data(), e.getErrMsg().data()
			);
			return -1;

		}
		chkshccardstat = 1;
		return 0;
}

void handleDBException(DBMConn* conObj, DBMStmt* stmt, const DBMException& e )
{
	OTraceError
	(
		"E-SHCCRDST-17009:Caught DBM Exception"
		"native error=%d, sqlstate=%.5s, msg=%s\n",
		e.getNativeError(), e.getSQLState().data(), e.getErrMsg().data()
	);

	try
	{
		if( stmt )
			stmt->close();
	}
	catch(const DBMException& se )
	{
	}
}

int Shc300ReqDB::InitialinsertShcCardStatusHist(ShcmsgHeader *header)
{
    ShcmsgHeader *thisHeader = (ShcmsgHeader *)header;
    m_shcmsg = &header->msg;
    char  data[25] ={0};
	char status[4] = {0};
	int filecd,len = 25;
	char fbuf[2]={0};
	int mseconds = 0;
	struct timeb tmpTime;
    
                 try
                    {
                        if(prepareInitialinsertShcCardStatusHiststmt())
                        {
                                istsafe_strcpy(_shccardstatushist.Pan,sizeof(_shccardstatushist.Pan),m_shcmsg->pan);
                                site_id= mbGetSiteId();
                                siteid.setValue(site_id);
                                istsafe_strcpy(_shccardstatushist.Source,sizeof(_shccardstatushist.Source),m_shcmsg->txnSrc);
                                OCDateTime current;
                                updated.setValue(current);
                                IstSegShc300Req *shc300req = NULL;
                                shc300req = (IstSegShc300Req *)thisHeader->getSegmentObj(ElfIdMap::elf_to_id(IST_SEG_SHC300_REQ), 0);
                                if(shc300req)
                                {
                                        shc300req->getActioncode((char *)status, &len);
                                        memset(data, 0x00, sizeof(data)); len=25;
                                        shc300req->getDateaction(data, &len);
                                        shc300req->getFileupdatecode(fbuf, &len);
                                        filecd=atoi(fbuf);
                                        changetype.setValue(filecd);

                                }
				else
                                        return -1;

                                OCString efftodt;
                                efftodt = (char *)data;
                                strcpy(_shccardstatushist.Status,status);
                                effectiveto.setValue(efftodt);
                                strcpy(_shccardstatushist.Status,status);
                                _shccardstatushist.Siteid = mbGetSiteId();

				ftime(&tmpTime);
				mseconds = tmpTime.millitm;
				created_msec.setValue(mseconds);

                                if(_insertShcCardStatusHiststmt1->execute()!=DBM_SUCCESS)
                                {
                                        OTraceError("E-SHCCRDST-5128: Cannot insert Initial ShcCardStatushist\n");
                                        return ( -1 );
                                }
                                _insertShcCardStatusHiststmt1->close();
                        }
                        else
                        {
                                OTraceDebug("E-SHCCRDST-5128:Failed in Initial ShcDardStatusHist Prepare Stmt\n");
                        }
                }
                catch( const DBMException& e )
                        {
                                handleDBException( _dbConn, _insertShcCardStatusHiststmt1, e );
                                OTraceError
                                (
                                        "E-SHCCRDST-5128:caught exception in insert shccardstatushist"
                                        "native error=%d, sqlstate=%.5s, msg=%s\n",
                                        e.getNativeError(), e.getSQLState().data(), e.getErrMsg().data()
                                );
                                return -1;
                        }
                        return 1;
}

int Shc300ReqDB::prepareInitialinsertShcCardStatusHiststmt()
{
        if(!_insertShcCardStatusHiststmt1)
        {
                _insertShcCardStatusHiststmt1=_dbConn->getStmt();
                try
                {
                        int sno=1;
                        _insertShcCardStatusHiststmt1->prepare("insert into shccardstatushist(siteid,pan,effective_from,effective_to,status,prestatus,created,changetype,source,created_time_msec)"
                                                                                                        "values"
                                                                                                        "(?,?,?,?,?,?,?,?,?,?)");
                        _insertShcCardStatusHiststmt1->bindParam(sno++, siteid );
                        _insertShcCardStatusHiststmt1->bindParam(sno++, DBM_PANTOKENTYPE, _shccardstatushist.Pan, sizeof(_shccardstatushist.Pan), NULL );
                        _insertShcCardStatusHiststmt1->bindParam(sno++, updated );
                        _insertShcCardStatusHiststmt1->bindParam(sno++, effectiveto );
                        _insertShcCardStatusHiststmt1->bindParam(sno++, DBM_STRINGTYPE, _shccardstatushist.Status , sizeof(_shccardstatushist.Status), NULL );
                        _insertShcCardStatusHiststmt1->bindParam(sno++, DBM_STRINGTYPE, _shccardstatushist.Prestatus , sizeof(_shccardstatushist.Prestatus), NULL );
                        _insertShcCardStatusHiststmt1->bindParam(  sno++, updated);
                        _insertShcCardStatusHiststmt1->bindParam(sno++, changetype );
                        _insertShcCardStatusHiststmt1->bindParam(sno++, DBM_STRINGTYPE, _shccardstatushist.Source , sizeof(_shccardstatushist.Source), NULL );
                        _insertShcCardStatusHiststmt1->bindParam(sno++, created_msec );

                }
                catch( const DBMException& e )
                {
                        handleDBException( _dbConn, _insertShcCardStatusHiststmt1, e );
                        OTraceError
                                (
                                        "E-SHCCRDST-5128:caught exception in prepare insert shccardstatushist  "
                                        "native error=%d, sqlstate=%.5s, msg=%s\n",
                                        e.getNativeError(), e.getSQLState().data(), e.getErrMsg().data()
                                );
                        return -1;
                }
        }
        return 1;
}

static bool GetCardStatusHistoryInsertFlag()
{
	static bool	sInit = false;
	static bool	sRetVal = false;

	if ( ! sInit )
	{
		if(shcApp->issuerShcParamsList->GetBool((char *)"shc.performcardstatushistinsert"))
		{
			sRetVal = true;
		}
		sInit = true;
	}
	return sRetVal;		
}

/*----------------------------------------------------------------------------
 * End of file
 *---------------------------------------------------------------------------*/
