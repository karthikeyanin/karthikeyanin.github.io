/*
 *  Copyright (C) 2004 eFunds Corporation ("eFunds").  All Rights Reserved.     
 *  eFunds Canada Corporation is an authorized user.                            
 *                                                                              
 *  IST is a registered trademark of eFunds Corporation.  Other brand or        
 *  product names are trademarks or registered trademarks of their respective   
 *  holders.                                                                    
 *                                                                              
 *  The information contained herein is the unpublished proprietary property    
 *  of eFunds.  Except as specifically authorized in writing by eFunds, the     
 *  holder of this document shall: i) keep all information contained herein     
 *  confidential, and ii) protect the information, in whole or in part, from    
 *  disclosure and dissemination to all third parties.                          
 *                                                                          
 *  This document and the software described in it are furnished under license  
 *  and may be used or copied only in accordance with the terms of such license.
 *  This document is supplied for information purposes only, is subject to      
 *  change without notice, and should not be construed as a commitment by       
 *  either eFunds Corporation or eFunds Canada Corporation. 
 */
/*
#pragma ident "@(#) shc_settle.cxx 1.5.1.4 12/05/29 06:43:16"
 *
 *                        MODIFICATION HISTORY                  REVIEW
 *
 *	SPR#	Who	Date	Description			Who	Date   
 * ===========================================================================
 *	ad		08jan92		Added support for amt_auth, amt_auth_rev
 *	ad		08jan92		Use shcmsg->msg.settlement_date
 *	ad		08jan92		Use acqagent, issagent instead of issuer, acquirer
 *	ad		08jan92		Changed the algorithim which determines if a txn
 *						is an authorization or not. Now it is based on the
 *						message number. 01xx are authorizations.
 *	ad		09sep92		Commented out entire module until we know what we
 *						want to do.
 * 1002376  cw 11Dec96  Added code to handle void sale, void refund, reversal
 *						of void sale and reversal of void refund.
 * 2002529  yh 14oct97  Enhancement for void txn processing (original txn is 100)
 * 0001303  yh 10Mar99  Do not locate STD500 SERVER for each transaction.
 * R001564  yh 23Mar99  Also use new_amount for partial reversal 
 * R002517	fg 13Aug99  Only locate mailbox SHC500STD_MAILBOX for once no 
 *						matter succeed or fail in shc_settlement_route()
 * R003932  fg 28Jan00  Mailbox Throttling
 * R006864  rzhou 30Oct01  Support original amount reverse in std500 table 
 * 							according to the CREDIT_ADJUST and DEBIT_ADJUST
 * R028271  dipa  18Jun10  Txn Statistics
 * R030381  dipa  10Mar12  Txn Statistics - more changes
 */

//File Number 17

#if defined( WIN32 )
#       define SHCDLLEXPORT __declspec(dllexport)
#else
#       define SHCDLLEXPORT
#endif


#include <stdio.h>
#include <oasis.h>
#include <ist_otrace.h>
#include <mb.h>
#include <mb_umi.h>
#include <shc.h>
#include <shc500std.h>
#include <string.h>
#include <ShcmsgHelper.h>
#include <ShcmsgHeader.h>
#include <ShcAppBase.h>
#include <ShcBin.h>

//R028271 >>>
#include <TxnStat.h>
//<<< R028271

/*
 *	Interface to on-line settlement
 */

/* R002517 */

int ShcmsgHelper::shc_route_settlement(ShcmsgHeader *header)
{
	/*
	 *	Route the settlement transaction to the proper settlement
	 *	task
	 */
	struct	shc500std	std500;

	return(0);
}


int ShcmsgHelper::shc_settlement_findroute(ShcmsgHeader *header)
{
	/* R002517 */
	 static int first_try = True;

	 if ( (shcApp->settlementid < 0) && (first_try == True) )
	 {
	 	if( (shcApp->settlementid = mb_locatemailbox(SHC500STD_MAILBOX)) < 0 )
	 		OTraceError("E-SHC-017001: Unable to locate mailbox '%s'\n", SHC500STD_MAILBOX);
		first_try = False;
	}

	return(shcApp->settlementid);
}

#define headerOrigIsAuthorizationRequest(header) (((header)->msg.origmsg / 100) == 1)/*void*/  

int ShcmsgHelper::shc_settlement_format_message(ShcmsgHeader *header, struct shc500std *std500)
{
	int		i, type, org_txntype;

	memset(std500, 0, sizeof(struct shc500std));

	strcpy(std500->issuer, header->issShcBin->binPkg->bin.networkid);
	strcpy(std500->acquirer, header->acqShcBin->binPkg->bin.networkid);
	std500->currency_code = header->issShcBin->binPkg->bin.currency_code;
	org_txntype = header->msg.txntype; 	

    if( shcIsAuthorizationRequest(header) 
     || (shcIsReversal(header) && headerOrigIsAuthorizationRequest(header)) /* rev 100*/
     || (shcIsFinancialRequest(header) && headerOrigIsAuthorizationRequest(header)) ) 
									/* 200 void for 100 original txn SPR 2002529 */
		type = SHC_TXNTYPE_AUTHORIZE;
	else
	{
	/* R006864 */
		if (header->msg.msgtype == SHC_FINREQ_ADVICE_RESPONSE && shcGetProcessCode(header->msg.pcode)==SH_ISO_DEBIT_ADJUST) 
				header->msg.txntype = SH_TX_DEP;
		else if (header->msg.msgtype == SHC_FINREQ_ADVICE_RESPONSE && shcGetProcessCode(header->msg.pcode)==SH_ISO_CREDIT_ADJUST) 
				header->msg.txntype = SH_TX_WD;


		/*	locate the message entry in our in core definitions */
		for(i = 0; ShcAppBase::shc_txn_def[i].offset >= 0; ++i)
			if(ShcAppBase::shc_txn_def[i].flag == header->msg.txntype)
				break;
			
		if(ShcAppBase::shc_txn_def[i].offset < 0)
			type = SHC_TXNTYPE_INQUIRY;
		else
			type = ShcAppBase::shc_txn_def[i].type;
	}
	
	{
		char	buf1[50];

		OTraceDebug("D-SHC-017002:   current header values\n");	
		OTraceDebug("D-SHC-017003:    msgtype          : %04d\n", header->msg.msgtype);
		OTraceDebug("D-SHC-017004:    response code    : %03d\n", header->msg.respcode);
		OTraceDebug("D-SHC-017005:    reverse code     : %03d\n", header->msg.revcode);
		dbm_dectochar(&header->msg.amount, buf1);
		OTraceDebug("D-SHC-017006:    amount           : %12s\n", buf1);
		dbm_dectochar(&header->msg.aval_balance, buf1);
		OTraceDebug("D-SHC-017007:    available balance: %12s\n", buf1);
		/* R001564. */
		dbm_dectochar(&header->msg.new_amount, buf1);
		OTraceDebug("D-SHC-017008:    new amount: %12s\n", buf1);
		OTraceDebug("D-SHC-017009:    txn type:   %12d\n", header->msg.txntype);
	}

	switch(type){
	case	SHC_TXNTYPE_CREDIT:
		shc_settlement_get_values(std500, header, 
			&std500->num_credit, &std500->amt_credit,
			&std500->num_credit_rev, &std500->amt_credit_rev);
		break;
	
	case	SHC_TXNTYPE_DEBIT:
		shc_settlement_get_values(std500, header,
			&std500->num_debit, &std500->amt_debit,
			&std500->num_debit_rev, &std500->amt_debit_rev);
		break;
			
	case	SHC_TXNTYPE_INQUIRY:
		std500->num_inquiry = 1;
		break;
	
	case	SHC_TXNTYPE_TRANSFER:
		shc_settlement_get_values(std500, header,
			&std500->num_transfer, NULL, &std500->num_transfer_rev, NULL);
		break;
	
	case	SHC_TXNTYPE_AUTHORIZE:
		shc_settlement_get_values(std500, header, 
			&std500->num_auth, &std500->amt_auth,
			&std500->num_auth_rev, &std500->amt_auth_rev);

	default:
		break;
	}

	std500->advice_reason = type;
	std500->msgtype = SHC500_MSG_TRANSACTION;
	std500->settlement_date = header->msg.settlement_date;
	mb_getUmi(std500->shclog_id, sizeof(std500->shclog_id));
	header->msg.txntype = org_txntype;
	
	return ( 0 );
}

int ShcmsgHelper::shc_settlement_inquire(struct shc500std *msg)
{
	int		save_msgtype;
	int		myid;

	if(shc_settlement_findroute(NULL) < 0)
		 return(-1);

	myid = mb_createmailbox_private();
	if(myid < 0)
		return(-1);

	save_msgtype = msg->msgtype;
	msg->msgtype = SHC500_MSG_INQUIRE;
	char saveid[sizeof(msg->shclog_id)];
	strcpy(saveid, msg->shclog_id);
	mb_getUmi(msg->shclog_id, sizeof(msg->shclog_id));
	/* R003932 */
	TxnStatReport(msg->shclog_id,TS_SHC,TSR_SEND,msg->msgtype,0,shcApp->settlementid);
	if (mb_write_nothrottle(shcApp->settlementid, myid, msg, sizeof(struct shc500std))<0)
	{
		OTraceLog("L-SHC-017017: Failed to send msg ID[%s] /m%04d to %s\n",
			msg->shclog_id, msg->msgtype, mbMailBoxName(shcApp->settlementid));
	}
	else
	{
		OTraceLog("L-SHC-017018: Sent msg ID[%s] /m%04d to %s\n",
			msg->shclog_id, msg->msgtype, mbMailBoxName(shcApp->settlementid));
	}
	int len = mb_read(myid, msg, sizeof(struct shc500std));
	OTraceLog("L-SHC-017019: Received %d bytes from %s ID[%s] /m%04d\n",
		len, mbMailBoxName(mbLastSenderId()),
		msg->shclog_id, msg->msgtype);

	mb_deletemailbox(myid);
	strcpy(msg->shclog_id, saveid);
	msg->msgtype = save_msgtype;

	return(msg->respcode);
}

/* 10002243 */
int ShcmsgHelper::shc_settlement_get_values( struct shc500std *std500, ShcmsgHeader *header,
	long *count, dec_t *amount, long *revcount, dec_t *revamount )
{
	int vflag = 0; /* flag indicating a void type pcode */

	OTraceDebug("D-SHC-017010:SHC500:  Get settlement values amounts\n");	

	/* 1002376 */
	vflag =	shcGetProcessCode(header->msg.pcode) == SH_ISO_DEBIT_ADJUST ||
			shcGetProcessCode(header->msg.pcode) == SH_ISO_CREDIT_ADJUST ;

	if( shcIsReversal(header) ||
		header->msg.msgtype == SHC_FINREQ_RESPONSE && vflag )
	{
		std500->flags = SHC500_TXN_REVERSAL;
		*revcount = (long)1;
		if( revamount )
		{
			if( header->msg.respcode == SHC_RC_PartialDispense
				|| header->msg.revcode == SHC_RR_PartialDispense )
			{
				/* 
				 * R001564.
				 * Use new_amount for partial amount if it is not zero
				 * without removing the aval_balance usage for 
				 * compatibility reason.
				 */
				dec_t	partial_amount;

        		dbm_deccopy(&partial_amount, &header->msg.aval_balance);   
				if(dbm_decncmp(&header->msg.new_amount, (double)0) > 0)
        			dbm_deccopy(&partial_amount, &header->msg.new_amount);   

				OTraceDebug("D-SHC-017011:   partial amount used\n");
				/* R001564. */
				dbm_decminus(revamount, &header->msg.amount, &partial_amount);

			}
			else
			{
				OTraceDebug("D-SHC-017012:   reversal amount used\n");
				/* 1002376 */
				if (header->msg.origmsg == SHC_FINREQ &&
					header->msg.pcode == header->msg.origpcode && vflag ) 
				{	/* reverse the previous void transaction (200)  */
					dbm_decsubx(revamount, &header->msg.amount);
				}
				else
					dbm_deccopy(revamount, &header->msg.amount);
			}

			if( ist_otrace_get_level() >= OTRACE_DEBUG )
			{
				char	buf1[50];
				dbm_dectochar(revamount, buf1);
				OTraceDebug("D-SHC-017013:   reversal amount: %12s\n", buf1);
			}
		}
	}
	/* R006864 >> */
	else if	( header->msg.msgtype == SHC_FINREQ_ADVICE_RESPONSE && vflag )
	{
		*count = (long)1;
		dbm_deccopy(amount, &header->msg.new_amount);
		if( ist_otrace_get_level() >= OTRACE_DEBUG )
		{
			char	buf1[50];
			dbm_dectochar(amount, buf1);
			OTraceDebug("D-SHC-017014:   original amount: %12s used.\n", buf1);
		}
	}
	/* << R006864 */
	else
	{
		*count = (long)1;
		if( amount )
		{
			dbm_deccopy(amount, &header->msg.amount);
			if( ist_otrace_get_level() >= OTRACE_DEBUG )
			{
				char	buf1[50];
				dbm_dectochar(amount, buf1);
				OTraceDebug("D-SHC-017015:   amount : %12s\n", buf1);
			}
		}
	}

	return( 0 );
}
