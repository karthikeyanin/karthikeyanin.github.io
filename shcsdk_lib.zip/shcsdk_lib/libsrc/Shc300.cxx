//
// Copyright (C) 2004 eFunds Corporation ("eFunds").  All Rights Reserved.
// eFunds Canada Corporation is an authorized user.
//
// IST is a registered trademark of eFunds Corporation.  Other brand or
// product names are trademarks or registered trademarks of their respective
// holders.
//
// The information contained herein is the unpublished proprietary property
// of eFunds.  Except as specifically authorized in writing by eFunds, the
// holder of this document shall: i) keep all information contained herein
// confidential, and ii) protect the information, in whole or in part, from
// disclosure and dissemination to all third parties.
//
// This document and the software described in it are furnished under license
// and may be used or copied only in accordance with the terms of such license.
// This document is supplied for information purposes only, is subject to
// change without notice, and should not be construed as a commitment by
// either eFunds Corporation or eFunds Canada Corporation.
//
/*
 *	IST and IST/Share are registered trademarks of Oasis Technology Ltd.
 *
 *	Copyright (C) 1990 - 1996 Oasis Technology Ltd.
 *	All Rights Reserved
 *	This Module contains Proprietary Information of
 *	Oasis Technology Ltd., and should be treated as Confidential.
 *
 *	THIS IS UNPUBLISHED PROPRIETARY SOURCE CODE OF OASIS TECHNOLOGY LTD.
 *	The copyright notice above does not evidence any
 *	actual or intended publication of such source code.
 */


/*----------------------------------------------------------------------------*
 *                                                                            *
 * File:
 * Description:
 * Notes:
 *
 * Modification History:
 * YYMMDD SCR#    WHO	Description
 *----------------------------------------------------------------------------*/
static const char _SHC300_cxx_what[] = "@(#)Shc300.cxx 1.7 15/03/05 10:40:17";


#include "ShcBin.h"
#include "BinRoute.h"
#include "ShcmsgHeader.h"
#include <ShcmsgHelper.h>
#include "ShcAppBase.h"
#include <InstProfile.h>
#include "ist_seg_name.h"
#include "ist_seg_network_data_req.h"
#include "oc/oc_string.h"
#include <Shc3XX.h>
#include <ist_seg_list.h>
#include <shc.h>
#include <ist_seg_tlv.h>
#include <ist_tlv_data.h>
#include <ist_seg_elf_id_map.h>
#include <ist_seg_name.h>
#include <ist_seg_shc300_req.h>
#include <ist_seg_shc300_resp.h>
#include "ist_otrace.h"
#include <memory>
#include <istsafe.h>

extern "C" {
#include <shcerror.h>
#include <debug.h>
}

int SHC300::setShc300Route(ShcmsgHeader *header)
{
	static char *FnDesc = "SHC300::setShc300";
	struct shc300fileupdt shcm300;

	OCString bin;
	int len = 25;
	struct shc300fileupdt *shc300data;
	struct shcpkg *pkg = NULL;

	IstSegShc300Req *shc300req = NULL;
	shc300req = (IstSegShc300Req *)header->getSegmentObj(ElfIdMap::elf_to_id(IST_SEG_SHC300_REQ), 0);
	if(shc300req)
	{
		shc300req->getISO_RECEIVER(shcm300.receiveBin, &len);
		if(len < 0)
			return -1;
	}

	if (shcm300.receiveBin)
	{
		bin = shcm300.receiveBin;
		if (shc_locate_bin(&pkg, bin) < 0 )
		{
			OTraceError("E-SHC300-002005:Can't find bin[%s]\n", (char *)bin);
			return -1;
		}
		if(header->setIssShcBin (bin) == -1)
		{
			OTraceError("E-SHC-121009: Failed to find bin for [%s]\n", (char*)bin);
			return -1;
		}
		return 1;
	}
}

int SHC300::shc3xxSegmentData(ShcmsgHeader *header,struct shc300fileupdt *shc3xxmsg )
{
	char  data[25] ={0};
	int len,j,i;
	long flag=0;
	memset(shc3xxmsg, 0, sizeof(struct shc300fileupdt));

	if((header->msg.msgtype == SHC_FILEUPD_ISSREQ) || (header->msg.msgtype == SHC_LOCAL_FILEUPD_ISSREQ))
	{
	IstSegShc300Req *shc300req = NULL;
	shc300req = (IstSegShc300Req *)header->getSegmentObj(ElfIdMap::elf_to_id(IST_SEG_SHC300_REQ), 0);
	if(shc300req)
	{
		//Get SHC300 Flags
		memset(data, 0x00, sizeof(data)); len=25;
		shc300req->getFlags(&data,&len);
		flag=atol(data);

		//Get Date Action
		memset(data, 0x00, sizeof(data)); len=25;
		shc300req->getDateaction(data, &len);
		strcpy(shc3xxmsg->DateAction, (char *)data);

		//Get ISO_RECEIVER
		memset(data, 0, sizeof(data)); len=25;
		shc300req->getISO_RECEIVER(data, &len);
		strcpy(shc3xxmsg->receiveBin, (char *)data);

		//Get Fileupdatecode
		int filecode; len=25;
		shc300req->getFileupdatecode(data, &len);
		filecode=atoi(data);
		shc3xxmsg->nFileUpdateCode=filecode;

		//Get Operatorid
		memset(data, 0x00, sizeof(data)); len=25;
		len =sizeof(data);
		shc300req->getOperatorid(data, &len);
		if(len>0)
		{
		 	data[len]='\0';
		 	strcpy(shc3xxmsg->OperatorId, (char *)data);
		}

		//Get Filename
		memset(data, 0, sizeof(data)); len=25;
		shc300req->getFilename(data, &len);

		strcpy(shc3xxmsg->strFileName, data);

		if ( !strncmp(shc3xxmsg->strFileName, "E", 1))
		{

			//DE127  Record Data
			memset(data, 0, sizeof(data)); len=25;
			shc300req->getExceptionRecord(data, &len);

			//Get Action Code
			memset(data, 0x00, sizeof(data)); len=25;
			shc300req->getActioncode(data, &len);
			strcpy(shc3xxmsg->ActionCode, data);

			//Get REGION CODE field
			memset(data, 0x00, sizeof(data)); len=25;
			shc300req->getRegioncode(data, &len);
			if(len<=0)
			{
				strcpy(shc3xxmsg->RegionCoding, "Z");
			}
			else
				strcpy(shc3xxmsg->RegionCoding, data);
				j = strlen(shc3xxmsg->RegionCoding);
				for (i=j; i<9; i++)
					shc3xxmsg->RegionCoding[i] = ' ';
				shc3xxmsg->RegionCoding[9]='\0';
		}
		else if ( !strncmp(shc3xxmsg->strFileName, "P2", 2) )	//	for PVV
		{
			//Get Pinverdata
			memset(data, 0x00, sizeof(data)); len=25;
			shc300req->getPin_ver_data(data, &len);
			if (len<=0)
			{
				shc3xxmsg->Pinverdata[0]= '\0';
				OTraceInfo("I-SHC300-002010: Node is not valid no PIN verify data logged\n");
			}
			else
				strcpy(shc3xxmsg->Pinverdata, data);
		}
		else if(!strncmp(shc3xxmsg->strFileName, "A2", 2))
		{
			//Get POSTALCODE
			memset(data, 0x00, sizeof(data)); len=25;
			shc300req->getPostalcode(data, &len);
			if(len<=0)
			{
				shc3xxmsg->Postalcd[0]= '\0';
				OTraceInfo("I-SHC300-002011: Node is not valid no POSTAL_CD logged\n");
			}
			else
			strcpy(shc3xxmsg->Postalcd,data);

			//Get Addrvv
			memset(data, 0x00, sizeof(data)); len=25;
			shc300req->getAddr_ver_val(data, &len);
			if(len<=0)
			{
				shc3xxmsg->Addrvv[0]= '\0';
				OTraceInfo("I-SHC300-002012: Node is not valid no ADDR_VERIFI_VALUE logged\n");
			}
			else
			strcpy(shc3xxmsg->Addrvv, data);
		}
		else if(!strncmp(shc3xxmsg->strFileName, "CG", 2))
		{
		    // Get STATECODE_IDENT
		    memset(data, 0x00, sizeof(data)); len=25;
		    shc300req->getStatecodeIdent(data, &len);
		    if(len<=0)
		    {
			 shc3xxmsg->StatecdIdent[0]= '\0';
			 OTraceInfo("L-GSV-3xx-0056: Node is not valid no STATECODE_IDENT logged\n");
		    }
		    else
			    strcpy(shc3xxmsg->StatecdIdent,data);

		    // Get STATECODE
		    int statecode; len=25;
		    shc300req->getStatecode(data, &len);
		    statecode=atoi(data);
		    shc3xxmsg->Statecd=statecode;
		}

		//error message from SHC300
		memset(data, 0x00, sizeof(data)); len=25;
		shc300req->getErrorMessage(data, &len);

		if (len<=0)
			OTraceInfo("I-SHC300-002013: No error message from SHC300\n");
		else
			OTraceDebug("I-SHC300-002014: Error message from SHC300 is %s\n",data);
	}
	}
	else
	{
	IstSegShc300Resp *shc300resp = NULL;
	shc300resp = (IstSegShc300Resp *)header->getSegmentObj(ElfIdMap::elf_to_id(IST_SEG_SHC300_RESP), 0);
	if(shc300resp)
	{
		//Get SHC300 Flags
		memset(data, 0x00, sizeof(data)); len=25;
		shc300resp->getFlags(&data,&len);
		flag=atol(data);

		//Get Date Action
		memset(data, 0x00, sizeof(data)); len=25;
		shc300resp->getDateaction(data, &len);
		strcpy(shc3xxmsg->DateAction, (char *)data);

		//Get ISO_RECEIVER
		memset(data, 0, sizeof(data)); len=25;
		shc300resp->getISO_RECEIVER(data, &len);
		strcpy(shc3xxmsg->receiveBin, (char *)data);

		//Get Fileupdatecode
		int filecode; len=25;
		shc300resp->getFileupdatecode(data, &len);
		filecode=atoi(data);
		shc3xxmsg->nFileUpdateCode=filecode;

		//Get Operatorid
		memset(data, 0x00, sizeof(data)); len=25;
		len =sizeof(data);
		shc300resp->getOperatorid(data, &len);
		if(len>0)
		{
		 	data[len]='\0';
		 	strcpy(shc3xxmsg->OperatorId, (char *)data);
		}

		//Get Filename
		memset(data, 0, sizeof(data)); len=25;
		shc300resp->getFilename(data, &len);

		strcpy(shc3xxmsg->strFileName, data);

		if ( !strncmp(shc3xxmsg->strFileName, "E", 1))
		{

			//DE127  Record Data
			memset(data, 0, sizeof(data)); len=25;
			shc300resp->getExceptionRecord(data, &len);

			//Get Action Code
			memset(data, 0x00, sizeof(data)); len=25;
			shc300resp->getActioncode(data, &len);
			strcpy(shc3xxmsg->ActionCode, data);

			//Get REGION CODE field
			memset(data, 0x00, sizeof(data)); len=25;
			shc300resp->getRegioncode(data, &len);
			if(len<=0)
			{
				strcpy(shc3xxmsg->RegionCoding, "Z");
			}
			else
				strcpy(shc3xxmsg->RegionCoding, data);
				j = strlen(shc3xxmsg->RegionCoding);
				for (i=j; i<9; i++)
					shc3xxmsg->RegionCoding[i] = ' ';
				shc3xxmsg->RegionCoding[9]='\0';
		}
		else if ( !strncmp(shc3xxmsg->strFileName, "P2", 2) )	//	for PVV
		{
			//Get Pinverdata
			memset(data, 0x00, sizeof(data)); len=25;
			shc300resp->getPin_ver_data(data, &len);
			if (len<=0)
			{
				shc3xxmsg->Pinverdata[0]= '\0';
				OTraceInfo("I-SHC300-002015: Node is not valid no PIN verify data logged\n");
			}
			else
				strcpy(shc3xxmsg->Pinverdata, data);
		}
		else if(!strncmp(shc3xxmsg->strFileName, "A2", 2))
		{
			//Get POSTALCODE
			memset(data, 0x00, sizeof(data)); len=25;
			shc300resp->getPostalcode(data, &len);
			if(len<=0)
			{
				shc3xxmsg->Postalcd[0]= '\0';
				OTraceInfo("I-SHC300-002016: Node is not valid no POSTAL_CD logged\n");
			}
			else
			strcpy(shc3xxmsg->Postalcd,data);

			//Get Addrvv
			memset(data, 0x00, sizeof(data)); len=25;
			shc300resp->getAddr_ver_val(data, &len);
			if(len<=0)
			{
				shc3xxmsg->Addrvv[0]= '\0';
				OTraceInfo("I-SHC300-002017: Node is not valid no ADDR_VERIFI_VALUE logged\n");
			}
			else
			strcpy(shc3xxmsg->Addrvv, data);
		}
		else if(!strncmp(shc3xxmsg->strFileName, "CG", 2))
		{
		    // Get STATECODE_IDENT
		    memset(data, 0x00, sizeof(data)); len=25;
		    shc300resp->getStatecodeIdent(data, &len);
		    if(len<=0)
		    {
			 shc3xxmsg->StatecdIdent[0]= '\0';
			 OTraceInfo("L-GSV-3xx-0056: Node is not valid no STATECODE_IDENT logged\n");
		    }
		    else
			    strcpy(shc3xxmsg->StatecdIdent,data);

		    // Get STATECODE
		    int statecode; len=25;
		    shc300resp->getStatecode(data, &len);
		    statecode=atoi(data);
		    shc3xxmsg->Statecd=statecode;
		}

		//error message from SHC300
		memset(data, 0x00, sizeof(data)); len=25;
		shc300resp->getErrorMessage(data, &len);

		if (len<=0)
			OTraceInfo("I-SHC300-002018: No error message from SHC300\n");
		else
			OTraceDebug("I-SHC300-002019: Error message from SHC300 is %s\n",data);
	}
	}

	istsafe_strcpy(shc3xxmsg->pan,sizeof(shc3xxmsg->pan),(char *)header->msg.pan);
	return (1);

}
