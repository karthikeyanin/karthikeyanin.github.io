/*
 *  Copyright (C) 2004 eFunds Corporation ("eFunds").  All Rights Reserved.     
 *  eFunds Canada Corporation is an authorized user.                            
 *                                                                              
 *  IST is a registered trademark of eFunds Corporation.  Other brand or        
 *  product names are trademarks or registered trademarks of their respective   
 *  holders.                                                                    
 *                                                                              
 *  The information contained herein is the unpublished proprietary property    
 *  of eFunds.  Except as specifically authorized in writing by eFunds, the     
 *  holder of this document shall: i) keep all information contained herein     
 *  confidential, and ii) protect the information, in whole or in part, from    
 *  disclosure and dissemination to all third parties.                          
 *                                                                          
 *  This document and the software described in it are furnished under license  
 *  and may be used or copied only in accordance with the terms of such license.
 *  This document is supplied for information purposes only, is subject to      
 *  change without notice, and should not be construed as a commitment by       
 *  either eFunds Corporation or eFunds Canada Corporation. 
 */
/*
#pragma ident "@(#) AcqProfile.cxx 1.12 16/06/21 04:57:29"
 *
 *                        MODIFICATION HISTORY                  REVIEW
 *
 *	SPR#	Who	Date	Description
 * ===========================================================================
 *R008717 ztang	13Nov02	Created to support multi-institution 
 *R009248 ztang 24Feb03 Remove spaces from instituion id fields
 *R022481 jyang 29Jan08 Supported for locking shared memory of rules
 *R023231	Ram	23May08 The SDK header should refer to external header
 */


//File Number 1
#if defined( WIN32 )
#       define SHCDLLEXPORT __declspec(dllexport)
#else
#       define SHCDLLEXPORT
#endif



#include <stdio.h>
#include <string.h>
#include <str.h>
#include <oasis.h>
#include <rules.h>
#include <ist_otrace.h>
#include <shc.h>
#include <ic/ic_bin.h>
#include<ic/ic_instid.h>
#include <ctype.h>
#include <mt_extbin.h>
#include <AcqProfile.h>
#include <ShcBin.h>	//	---	R023231
#include <ShcAppBase.h>


int AcqProfile::initialized = 0;
struct AcquirerProfile *AcqProfile::acquirerProfileData = NULL;
struct rules_keytab    *AcqProfile::acquirerRuleKeyp = NULL;
int AcqProfile:: acquirerProfileAppid = -1;

int acqProfileFindUpBin = 0;

int AcqProfile::Match(const struct AcquirerProfile &ap, const char *txnSrc, 
	const char *txnDest, const char *entityId, const char *deviceType, const char *currencyCode)
{
	if 	(	(!(ap.m_txnSrc[0]) || (txnSrc && (strcmp((char *)ap.m_txnSrc, (char *)txnSrc) == 0) )) &&
			(!(ap.m_txnDest[0]) || (txnDest && (strcmp((char *)ap.m_txnDest, (char *)txnDest) == 0))) &&
			(!(ap.m_entityId[0]) || (entityId && ist_regexpcv((char *)ap.m_entityId, (char *)entityId, 0))) &&
			(!(ap.m_currencyCode[0]) || (currencyCode && ist_regexpcv((char *)ap.m_currencyCode, (char *)currencyCode, 0))) &&
			(!(ap.m_deviceType[0]) || (deviceType && ist_regexpcv((char *)ap.m_deviceType, (char *)deviceType, 0)))
		)
		return 1;
	else
		return 0;
}

int AcqProfile::initialize()
{
	int appid;

	if((appid = rm_getappid("acq_profile")) < 0)
	{
		OTraceFatal("F-SHC-001001:unable to locate message name: acq_profile\n");
		return(-1);
	}
	else {
		rm_attach( appid, RULES_VER_CURRENT );
		acquirerRuleKeyp = rm_getapphead(appid);

		/*	Find the first entry of my key table */
		acquirerProfileData = (struct AcquirerProfile *)rm_getappkey(appid);
		acquirerProfileAppid   = appid;
		initialized = 1;
	}

	return 0;
}

void AcqProfile::locateAcquirer(const char *txnSrc, const char *txnDest, const char *entityId, 
			const int currency, const int merchantType, AcquirerInfo &acquirerInfo, ShcmsgHeader *header)
{
	char tmpDeviceType[5];
	
	if (merchantType == 6011)
		sprintf(tmpDeviceType, "ATM");
	else
		sprintf(tmpDeviceType, "POS");
	locateAcquirer(txnSrc, txnDest, entityId, currency, tmpDeviceType, acquirerInfo, header);
	return;
}
void AcqProfile::locateAcquirer(const char *txnSrc, const char *txnDest, const char *entityId, 
			const int currency, const char *deviceType, AcquirerInfo &acquirerInfo, ShcmsgHeader *header)
{
	char currencyBuf[4];
	bin_t tmpTxnSrc;
	bin_t tmpTxnDest;
	int findUp = acqProfileFindUpBin;
	acqProfileFindUpBin = 0;
	int firstDownBin = -1;
	int i;
	

	if (currency > 0)
		snprintf(currencyBuf, sizeof(currencyBuf), "%03.3d", currency);
	else
		currencyBuf[0]='\0';

	ICInstId_pure(tmpTxnSrc, (char *)txnSrc);
	ICInstId_pure(tmpTxnDest, (char *)txnDest);

	acquirerInfo.reset();

	if (!initialized)
	{
		if (initialize() < 0)
			return;
	}
	else // R029583
	{
		rm_attach( acquirerProfileAppid, RULES_VER_CURRENT );
		acquirerRuleKeyp = rm_getapphead(acquirerProfileAppid);
		acquirerProfileData = (struct AcquirerProfile *)rm_getappkey(acquirerProfileAppid);
	}

	if ( rm_waitForLockedShdMem(acquirerProfileAppid) )	// R022481
	{
		OTraceWarning("W-SHC-001001: rm.appid[%d] was locked. Go ahead\n", acquirerProfileAppid);
	}


	char* start_p = (char*) acquirerProfileData;
	for (i = 0; i<acquirerRuleKeyp->keysused; i++)
	{
		acquirerProfileData = (struct AcquirerProfile *)(start_p + (acquirerRuleKeyp->keysize * i));
		if (Match(*acquirerProfileData, tmpTxnSrc, tmpTxnDest, entityId, deviceType, currencyBuf))
		{
			if (findUp)
			{
				struct shcpkg *binpkg = NULL;
				shcApp->shcBinObj->shc_locate_bin(&binpkg, acquirerProfileData->m_bin);
				if (binpkg && (shc_isdown(binpkg)))
				{
					if (firstDownBin < 0)
						firstDownBin = i;
					continue;
				}
			}

			strcpy(acquirerInfo.m_acqBin, acquirerProfileData->m_bin);
			strcpy(acquirerInfo.m_alternateAcqBin, acquirerProfileData->m_alternateBin);
			break;
		}
	}
	if ((i >= acquirerRuleKeyp->keysused) && (firstDownBin >= 0))
	{
			acquirerProfileData = (struct AcquirerProfile *)(start_p + (acquirerRuleKeyp->keysize * firstDownBin));
		//Didn't find an up bin, use the first found down bin
			strcpy(acquirerInfo.m_acqBin, acquirerProfileData->m_bin);
			strcpy(acquirerInfo.m_alternateAcqBin, acquirerProfileData->m_alternateBin);
	}		

	return;
}
