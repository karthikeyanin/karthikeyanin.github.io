static char _ShcAsynchApi_cxx_what[] = "@(#) ShcAsynchApi.cxx 1.5 19/10/29 17:43:52";

/*
 *  Copyright (C) 2004 eFunds Corporation ("eFunds").  All Rights Reserved.     
 *  eFunds Canada Corporation is an authorized user.                            
 *                                                                              
 *  IST is a registered trademark of eFunds Corporation.  Other brand or        
 *  product names are trademarks or registered trademarks of their respective   
 *  holders.                                                                    
 *                                                                              
 *  The information contained herein is the unpublished proprietary property    
 *  of eFunds.  Except as specifically authorized in writing by eFunds, the     
 *  holder of this document shall: i) keep all information contained herein     
 *  confidential, and ii) protect the information, in whole or in part, from    
 *  disclosure and dissemination to all third parties.                          
 *                                                                          
 *  This document and the software described in it are furnished under license  
 *  and may be used or copied only in accordance with the terms of such license.
 *  This document is supplied for information purposes only, is subject to      
 *  change without notice, and should not be construed as a commitment by       
 *  either eFunds Corporation or eFunds Canada Corporation. 
 *
 *
 *                        MODIFICATION HISTORY                  REVIEW
 *
 *	SPR#	Who	Date	Description			Who	Date   
 * ===========================================================================
 *
*/
#include <algorithm>
#include <stdio.h>
#include <string.h>
#include <math.h>
#include <ist_types.h>
#include <oasis.h>
#include <ist_otrace.h>
#include <shcdef.h>
#include <ShcTimerHelper.h>
#include <ShcAppBase.h>

#include <ShcmsgHeader.h>
#include <ShcAsynchApi.h>
#include <asynchSecApi.h>
#include <security.h>

static int shcAsynchSecMode = 0;
static ShcmsgHeader *shcAsynchHeader=NULL;
static char shcAsynchMbName[128];

ShcmsgHeader *getAsynchHeader()
{
	if(shcAsynchHeader != NULL)
		return(shcAsynchHeader);
	else
		return(NULL);
}

int isAsynchHeaderSet(const char *fnDesc)
{
	int ret=0;

	if(shcAsynchHeader != NULL)
	{
		ret=1;
	}
	else
	{
		OTraceError("E-SHC-001103 %s Null Source Header\n",fnDesc);
	}

	return(ret);
}

int setAsynchMbName(const char *mbName)
{
	static const char*	fnDesc = "setAsynchMbName";
	int ret=0;

	if(mbName)
		strncpy(shcAsynchMbName,mbName,sizeof(shcAsynchMbName));
	else
		strncpy(shcAsynchMbName,SHC_SERVER_NAME,sizeof(shcAsynchMbName));
	OTraceDebug("D-SHC-001104 %s [%s]\n",fnDesc,shcAsynchMbName);

	return(ret);
}

int setAsynchWait()
{
	static const char*	fnDesc = "setAsynchWait";
	int ret=0;

	if(isAsynchHeaderSet(fnDesc))
	{
		shcApp->shcTimerObj->shc_set_timers(shcAsynchHeader);
		// Creates event
		shcApp->shcTimerObj->shc_time_message_x(shcAsynchHeader,(unsigned char *)shcAsynchHeader->segment );
		OTraceDebug("D-SHC-001103 %s Event creation [%d]\n",fnDesc,shcAsynchHeader->eventId);
		ret=1;
	}

	return(ret);
}

int isAsynchResume()
{
	static const char*	fnDesc = "isAsynchResume";
	int ret=0;

	if(isAsynchHeaderSet(fnDesc) && (shcAsynchHeader->shcerr & SH_ASYNCH_RESUME))
	{
		ret=1;
	}

	return(ret);
}

int setAsynchHeader(ShcmsgHeader *header)
{
	static const char*	fnDesc = "setAsynchHeader";
	int ret=0;

	if(header!=NULL)
	{
		shcAsynchHeader = header;
		OTraceDebug("D-SHC-001102 %s [m%d/p%06d/t%06d]\n",fnDesc,
						header->msg.msgtype,header->msg.pcode,header->msg.trace);
		ret=1;
	}
	else
	{
		OTraceError("E-SHC-001102 %s Null Source Header\n",fnDesc);
	}

	return(ret);
}

int setAsynchSrcId(ShcmsgHeader *header,const char *mbName,char *srcId,int srcLen)
{
	static const char*	fnDesc = "setAsynchSrcId";
	int ret=0;

	if(header)
	{
		memset(srcId,0,srcLen);
		snprintf(srcId,srcLen,"%d-%s-%08d~%s",
			header->msg.msgtype,mbName,header->eventId,header->msg.shclog_id);
		OTraceDebug("D-SHC-001101 %s SrcId [%s]\n",fnDesc,srcId);
		ret=1;
	}
	else
	{
		OTraceError("E-SHC-001103 %s Null Source Header\n",fnDesc);
	}

	return(ret);
}

int setAsynchSrcId(ShcmsgHeader *header,char *srcId,int srcLen)
{
	int ret=0;

	ret=setAsynchSrcId(shcAsynchHeader,(const char *)shcAsynchMbName,srcId,srcLen);

	return(ret);
}

int setAsynchSrcId(char *srcId,int srcLen)
{
	static const char*	fnDesc = "setAsynchSrcId";
	int ret=0;

	memset(srcId,0,srcLen);
	if(isAsynchHeaderSet(fnDesc))
	{
		ret=setAsynchSrcId(shcAsynchHeader,(const char *)shcAsynchMbName,srcId,srcLen);
	}

	return(ret);
}

int shcIsAsynchSecMode()
{
	char buf[80];
	static bool readFlg=false;

	if(!readFlg)
	{
		if(cf_open("files/shc.cfg") >= 0)
		{
			if(cf_locate("shc.asynch_sec", buf) > 0)
			{
				switch(buf[0])
				{
					case 'Y':
					case '1':
					case 'y':
						shcAsynchSecMode=1;
					break;
					default:
						shcAsynchSecMode=0;
				}
			}
		}
		OTraceDebug("D-SHC-001100 Asynch HSM Mod [%d]\n",shcAsynchSecMode);
		readFlg=true;

		memset(shcAsynchMbName,0,sizeof(shcAsynchMbName));
	}
	return(shcAsynchSecMode);
}

int isAsynchCmdTrnsltPin(int iCmd)
{
	int iRes=0;

	if(	iCmd==TranslatePinBlkBdkToNet	||
		iCmd==TranslatePinBlkNetToNet	||
		iCmd==TranslatePinBlkAtmToNet	)
		iRes=1;

	return(iRes);
}

int setAsynchTxnFlgs(ShcHeader *header,struct  shcmsg *shcmsgP)
{
	static const char*	fnDesc = "setAsynchTxnFlgs";
	int ret=0;
	long skipFlg;

	skipFlg=TXN_PROC_SKIP_ENRICH|TXN_PROC_SKIP_RESTORE|TXN_PROC_SKIP_EDIT;

	// Trasnslate PIN Blk is into doWork, verify() is done
	if(isAsynchCmdTrnsltPin(asynchSecResp.cmdId) && (shcmsgP -> respcode == SHC_RC_Approved) )
		skipFlg |= TXN_PROC_SKIP_VERIFY;
	// no SKIP required for failure PIN txn. 
	else if(isAsynchCmdTrnsltPin(asynchSecResp.cmdId) && (shcmsgP -> respcode != SHC_RC_Approved) )
		skipFlg=0;
	// Verify MAC is done inside enrich(), no SKIP required
	else if(asynchSecResp.cmdId==VerifyMac || asynchSecResp.cmdId==VerifyMacLarge)
		skipFlg=0;

	header->shcerr|=SH_ASYNCH_RESUME;
	header->setSkipFlag(skipFlg);

	header->logFlag = 0;
	OTraceDebug("D-SHC-001103 %s Set Proc Flags [0x%08x] ShcErr[0x%08x] Log[%08x] Cmd[%d]\n",fnDesc,
		header->procFlag,header->shcerr,header->logFlag,
		asynchSecResp.cmdId);

	return(1);
}

int setAsynchSecResp(int iCmd,struct shcmsg *oMsg,char *ptrSecResp)
{
	static const char*	fnDesc="setAsynchSecResp";
	char secData[DEVICEBUFSIZE];
	char secRespCode[4];
	char *ptrResp;
	int	iRes=-1;

	ptrResp=ptrSecResp;
	if(strlen(ptrResp)>0)
	{
		memset(secRespCode,0,sizeof(secRespCode));
		memset(secData,0,sizeof(secData));
		strncpy(secRespCode,ptrResp,3);
		ptrResp+=3;
		if(strlen(ptrResp)>0)
		{
			strncpy(secData,ptrResp,sizeof(secData));
			if(isAsynchCmdTrnsltPin(iCmd))
			{
				// Copy new block
				memcpy(oMsg->pin, secData, sizeof(oMsg->pin));
			}
			iRes=atoi(secRespCode);
			OTraceDebug("D-SHC-001102 %s Security Resp[%s|%s]\n",fnDesc,secRespCode,secData);
		}
		else {
			// map to internal response code
			if(isAsynchCmdTrnsltPin(iCmd))	
			{
				
				switch(atoi(secRespCode)){
					case ESEC_PINLENERR:
						iRes = SHC_RC_PinLengthError;
						break;
					case ESEC_TIMEOUT:
						iRes = SHC_RC_SystemError;
						break;
					default:
						iRes = SHC_RC_InvalidPinBlock;
						break;
				} // end of switch
					
			} // if end 
			OTraceDebug("D-SHC-001102 %s Security Resp[%d|%d]\n",fnDesc,iRes, iCmd);
		} 
	}

	return(iRes);
}

int getAsynchEvent(char *readBuf,int &len,int readSize,struct shcmsg *oMsg,
		struct asynchSecSrvResp *asynchResp)
{
	static const char*	fnDesc="getAsynchEvent";

	char strSecSrv[DEVICEBUFSIZE];
	char *ptrMsgId;
	char *ptrMbId;
	char *ptrEventId;
	char *ptrChipLog;
	char *ptrWrkr;
	int secSrvEvent;
	char *ptrSecFunc;
	char *ptrSecResp;
	int iCmd;
	struct shcmsg *ptrShcMsg;

	memcpy(strSecSrv,readBuf,std::min<int>(len,DEVICEBUFSIZE));
	ptrWrkr=strSecSrv;
	ptrMsgId=strtok(ptrWrkr,"-");
	ptrMbId=strtok(NULL,"-");
	ptrEventId = strtok(NULL,"~");
	ptrChipLog = strtok(NULL,"-");
	ptrSecFunc = strtok(NULL,"-");
	ptrSecResp = strtok(NULL,"|");

	iCmd=atoi(ptrSecFunc);
	OTraceDebug("D-SHC-001211 From SecSrv [%s|%s|%s|%d|%s]\n",ptrMsgId,ptrEventId,
		ptrChipLog,iCmd,ptrSecResp);
	secSrvEvent=atoi(ptrEventId);
	if(tm_locate_eventid(secSrvEvent)!=-1)
	{
		ptrShcMsg=(struct shcmsg *)readBuf;
		ptrShcMsg->msgtype = atoi(ptrMsgId);
		len=tm_getdata(secSrvEvent,readBuf,readSize);
		ptrShcMsg->respcode=setAsynchSecResp(iCmd,ptrShcMsg,ptrSecResp);
		OTraceLog("L-SHC-001230 %s Remove Event ID[%d|%d] [%s]/m%04d/t%06ld/p%06ld\n",
			fnDesc, secSrvEvent,tm_dequeue(secSrvEvent),
			oMsg->shclog_id, oMsg->msgtype, oMsg->trace, oMsg->pcode);
		if(asynchResp)
		{
			asynchResp->cmdId=iCmd;
			asynchResp->respCode=ptrShcMsg->respcode;
			memcpy(asynchResp->addRsp,ptrSecResp,sizeof(asynchResp->addRsp));
		}
	}
	else
	{
		OTraceDebug("D-SHC-001230 Event Not Found ID[%d]\n",secSrvEvent);
	}

	return(1);
}

int getAsynchEvent(char *readBuf,int &len,int readSize,struct shcmsg *oMsg)
{
	return(getAsynchEvent(readBuf,len,readSize,oMsg,&asynchSecResp));
}

int getAsynchEvent(ShcmsgHeader *header)
{
	static const char*	fnDesc = "getAsynchEvent";
	const int			readSize=sizeof(struct shcmsg)+sizeof(struct shcsegrec);
	char				strBuf[readSize+1];
	char				*readBuf;
	struct shcmsg		*oMsg;
	int					len;

	memset(strBuf,0,readSize);
	readBuf=strBuf;
	if( tm_locate_eventid(header->eventId) )
	{
		((struct shcmsg *)readBuf)->msgtype=header->msg.msgtype;
		len=tm_getdata(header->eventId,readBuf,readSize);
		oMsg=(struct shcmsg *)readBuf;
		OTraceLog("L-SHC-001230 %s Remove Event ID[%d|%d] [%s]/m%04d/t%06ld/p%06ld\n",fnDesc,
			header->eventId,tm_dequeue(header->eventId),
			oMsg->shclog_id, oMsg->msgtype, oMsg->trace, oMsg->pcode);
	}

	return(1);
}

