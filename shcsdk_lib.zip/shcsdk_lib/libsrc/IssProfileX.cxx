/*
 *  Copyright (C) 2004 eFunds Corporation ("eFunds").  All Rights Reserved.     
 *  eFunds Canada Corporation is an authorized user.                            
 *                                                                              
 *  IST is a registered trademark of eFunds Corporation.  Other brand or        
 *  product names are trademarks or registered trademarks of their respective   
 *  holders.                                                                    
 *                                                                              
 *  The information contained herein is the unpublished proprietary property    
 *  of eFunds.  Except as specifically authorized in writing by eFunds, the     
 *  holder of this document shall: i) keep all information contained herein     
 *  confidential, and ii) protect the information, in whole or in part, from    
 *  disclosure and dissemination to all third parties.                          
 *                                                                          
 *  This document and the software described in it are furnished under license  
 *  and may be used or copied only in accordance with the terms of such license.
 *  This document is supplied for information purposes only, is subject to      
 *  change without notice, and should not be construed as a commitment by       
 *  either eFunds Corporation or eFunds Canada Corporation. 
 */
/*
#pragma ident "@(#) IssProfileX.cxx 1.5 18/08/24 10:14:48"
 *
 *                        MODIFICATION HISTORY                  REVIEW
 *
 *	SPR#	Who	Date	Description
 * ===========================================================================
 *R008717 ztang	13Nov02	Created to support multi-institution 
 *R009030 ztang 03Feb03 The pcode checking should be >= 0
 #R009248 ztang 24Feb03 Remove spaces from instituion id fields
 *R009399 jyang 11Mar03 Added PAN length checking for Visa when searching extbin
 *R012134 emj   04Oct04 Issuer Entity Support
 *IST_S_120107-5	Dipa	20Feb14	Spring Compliance 2014 - Support Token Id field in SHCEXTBINDB
 */

#if defined( WIN32 )
#       define SHCDLLEXPORT __declspec(dllexport)
#else
#       define SHCDLLEXPORT
#endif

//File Number 4

#include <stdio.h>
#include <str.h>
#include <oasis.h>
#include <rules.h>
#include <shc.h>
#include <string.h>
#include <ic/ic_bin.h>
#include<ic/ic_instid.h>
#include <ctype.h>
#include <ist_otrace.h>
#include <mt_extbin.h>
#include <IssProfile.h>
#include <mt_acq_profile.h>
#include <mt_iss_profile.h>
#include <mt_inst_profile.h>
#include <ShcAppBase.h>
#include <IssProfileX.h>
#include <shcdef.h>

/*
 *	Input:		pan		
 *	Action:		Search the extended bin records in shared memroy to find
 *				the matching records. Each brand name of the card will be
 *				one record.
 */
void IssProfileX::search_extbin_x(const char *pan, ExtBinResult &searchResult)
{
    pHdr = NULL;
    search_extbin(pan, searchResult);

	return;
}


/*
 *	Input:		pan		
 *	Action:		Search the extended bin records in shared memroy to find
 *				the matching records. Loop thru the matching records to see
 *				if token identifier flag is set.
 */
bool IssProfileX::isTokenIdSet(const char *pan)
{
	ExtBinResult extBinDbResult;

	search_extbin_x(pan, extBinDbResult );

	if( extBinDbResult.m_numOfResult > 0 )
	{
		int idx;
		for(idx=0; idx<gExtBinResultExt.m_numOfResult; idx++)
		{
			if (strlen(gExtBinResultExt.result[idx]->network_config)>0)	
			{
				return (shcIsTokenInd(gExtBinResultExt.result[idx]->network_config));
			}
		}
	}
	else
		return false;

	return false;
}
