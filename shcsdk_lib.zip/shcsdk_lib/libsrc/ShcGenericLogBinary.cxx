//
// Copyright (C) 2004 eFunds Corporation ("eFunds").  All Rights Reserved.
// eFunds Canada Corporation is an authorized user.
//
// IST is a registered trademark of eFunds Corporation.  Other brand or
// product names are trademarks or registered trademarks of their respective
// holders.
//
// The information contained herein is the unpublished proprietary property
// of eFunds.  Except as specifically authorized in writing by eFunds, the
// holder of this document shall: i) keep all information contained herein
// confidential, and ii) protect the information, in whole or in part, from
// disclosure and dissemination to all third parties.
//
// This document and the software described in it are furnished under license
// and may be used or copied only in accordance with the terms of such license.
// This document is supplied for information purposes only, is subject to
// change without notice, and should not be construed as a commitment by
// either eFunds Corporation or eFunds Canada Corporation.
//
 /*
 *  Date    SCR     Who     Description
 *  ===========================================================================
 *  09Feb10 Rxxxxxx ztang Initial Version.
 *  11Apr12 R030464 Dipa  Use map76seg in rstore()
 */

/* File Number 166 */

#include <ShcGenericLogBinary.h>
#include <ShcGenericLogHelper.h>
#include <dbm_private.h>
#include <dbm.h>
#include <shcdef.h>
#include <shc.h>
#include <ist_seg_list.h>
#include <ist_otrace.h>
#include <oc/oc_datetime.h>


ShcGenericLogBinary:: ShcGenericLogBinary()
{
	noOfGenLogItem = 0;
	//R030114 >>>
	if( segmentList )
		delete []segmentList;

	if(bufList)
	{
		//first free the memory allocated for buf
		for(int i=0;i<SHC_GENERIC_LOG_FIELD_NUM;i++)
		{
			if( (bufList+i)->buf != NULL )
				delete[] (bufList+i)->buf;
		}
		delete []bufList;
	}
	//R030114 <<<

	segmentList = NULL;
	bufList = NULL;
	map76seg = 0;
	shUpdate = NULL;
	valueBuf = NULL;
	valueBufLen = 0;

	try
	{
		initialize();
	}
	catch(...)
	{
		OTraceError("E-SHC-xxxxx:initialization failed, no generic log enabled\n");
		noOfGenLogItem = 0;
	}
}

void ShcGenericLogBinary:: initialize()
{
	//read the configured parameters from istparam.cfg
	char buf[3];
	if(cf_open(NULL) >= 0)
	{
		cf_rewind();
		if( (cf_locate("shc.map760segments", buf)) >= 0 )
		{
			if ( toupper(buf[0]) == 'Y' || buf[0] == '1' )
			{
				OTraceDebug("D-SHC-131048: Paremeter shc.map760segments is set on\n");
				map76seg = 1;
			}
			else
				map76seg = 0;
		}
		else
			map76seg = 0;
		cf_close();
	}
	if(map76seg)
	{
		shcGenLogHelperObj->initialize();
		return;
	}

	int i;
	
	shcGenericLogBinaryFieldSize = 2000;	//default value
	SHC_GENERIC_LOG_BINARY_FIELD_NUM = 5;
	valueBuf = NULL;
	valueBufLen = 0;


	bufList = new dbBuffer[SHC_GENERIC_LOG_BINARY_FIELD_NUM];
	valueBuf = (char *)calloc(shcGenericLogBinaryFieldSize,SHC_GENERIC_LOG_BINARY_FIELD_NUM);
	struct dbBuffer *tmpBufList = bufList;

	//set default values
	memset(bufList, 0, sizeof(struct dbBuffer)*SHC_GENERIC_LOG_BINARY_FIELD_NUM);


	//compose and bind sql statements

	tmpBufList = bufList;	//point to the start
	char fields[512] = "";
        char valuesInsert[128] = " values(?,?,?,?,?";
	for(i=0;i<SHC_GENERIC_LOG_BINARY_FIELD_NUM;i++)
	{
		snprintf(fields+strlen(fields),(sizeof(fields)-strlen(fields)), ",binfield%d", i+1);
		snprintf(valuesInsert + strlen(valuesInsert), sizeof(valuesInsert)-strlen(valuesInsert), ",?");
		tmpBufList->buf = &valueBuf[i*shcGenericLogBinaryFieldSize];
		tmpBufList++;
	}

	//insert query

	char sqlStmtDefaultInsert[512] = "insert into shcgenericlog(log_id,msgtype,reqresp, site_id, switch_date";
    char sqlStatementInsert[512] = { 0 }; 

	int bindCount;

	snprintf(sqlStatementInsert, sizeof(sqlStatementInsert), "%s%s)%s)", sqlStmtDefaultInsert, fields, valuesInsert);

    if (dbm_connect() >=0)
    {
        OTraceDebug("D-SHC-131011:Connecting to database successful\n");
        ch=dbm_dbconn;
    }
    else
    {
        //OTraceError("E-SHC-131012: Connecting to database failed\n");
        //throw 1;
		OTraceFatal("F-SHC-131012: Connecting to database failed..Exiting\n");
		kill(getpid(),1);
  	}


	if( DBMAllocStmt(ch, &shInsert) < 0)
	{
		OTraceError("E-SHC-131013: Insert query allocate error:\n%s\n", sqlStatementInsert);
	}

	if( DBMPrepare(shInsert, sqlStatementInsert) != DBM_SUCCESS )
	{
		OTraceError("E-SHC-131014: Insert query prepare error:\n%s\n", sqlStatementInsert);
	}

        static short int site_id = mbGetSiteId();

	if( (DBMBindParam(shInsert,1,DBM_PARAM_INPUT,DBM_STRINGTYPE,logid,sizeof(logid),&ind[0]) != DBM_SUCCESS) ||
		(DBMBindParam(shInsert,2,DBM_PARAM_INPUT,DBM_LONGTYPE,&msgType,sizeof(msgType),NULL) != DBM_SUCCESS) ||
		(DBMBindParam(shInsert,3,DBM_PARAM_INPUT,DBM_CHARTYPE,&reqresp,sizeof(reqresp),NULL) != DBM_SUCCESS) ||
                (DBMBindParam(shInsert,4,DBM_PARAM_INPUT,DBM_INTTYPE, &site_id, sizeof(site_id), NULL) != DBM_SUCCESS) ||
                (DBMBindParam(shInsert,5,DBM_PARAM_INPUT,DBM_DATETYPE,&switch_date,sizeof(switch_date),NULL) != DBM_SUCCESS)  )
	{
		OTraceError("E-SHC-131015: Insert query bind error \n");
	}

	//bind the fields
	tmpBufList = bufList;	//point to the start
	bindCount = 5;
	int mergedFieldsCount = 0;
	for(i=0;i<SHC_GENERIC_LOG_BINARY_FIELD_NUM;i++)
	{
		bindCount++;
		if( DBMBindParam(shInsert,bindCount,DBM_PARAM_INPUT,DBM_BINTYPE,
			tmpBufList[i].buf,shcGenericLogBinaryFieldSize,&ind[i+3]) != DBM_SUCCESS )// --- R016790
			{
				OTraceError("E-SHC-xxxxx: Insert query bind error for the binfield: %d \n", i+1);
			}
	}

	//update query(not really a query)

	strcpy(sqlStatementInsert, "update shcgenericlog set binfield1 = ?, binfield2 = ?, binfield3 = ?, binfield4 = ?, binfield5 = ? where log_id = ? AND msgtype = ?");

	if( DBMAllocStmt(ch, &shUpdate) < 0)
	{
		OTraceError("E-SHC-131013: Updte query allocate error:\n%s\n", sqlStatementInsert);
	}

	if( DBMPrepare(shUpdate, sqlStatementInsert) != DBM_SUCCESS )
	{
		OTraceError("E-SHC-xxxxx: Insert query prepare error:\n%s\n", sqlStatementInsert);
	}


	if( (DBMBindParam(shUpdate,6,DBM_PARAM_INPUT,DBM_STRINGTYPE,logid,sizeof(logid),&ind[0]) != DBM_SUCCESS) ||
		(DBMBindParam(shUpdate,7,DBM_PARAM_INPUT,DBM_LONGTYPE,&msgType,sizeof(msgType),NULL) != DBM_SUCCESS) 
	  )
	{
		OTraceError("E-SHC-xxxxx: Update query bind error \n");
	}

	//bind the fields
	tmpBufList = bufList;	//point to the start
	bindCount = 0;
	for(i=0;i<SHC_GENERIC_LOG_BINARY_FIELD_NUM;i++)
	{
		bindCount++;
		if( DBMBindParam(shUpdate,bindCount,DBM_PARAM_INPUT,DBM_BINTYPE,
			tmpBufList[i].buf,shcGenericLogBinaryFieldSize,&ind[i+3]) != DBM_SUCCESS )// --- R016790
			{
				OTraceError("E-SHC-xxxxx: Update query bind error for the binfield: %d \n", i+1);
			}
	}

	//load entry for both request and response

	char sqlStatementLoadBoth[512] = "select msgtype,reqresp";
	strcat(sqlStatementLoadBoth, fields);
	strcat(sqlStatementLoadBoth, " from shcgenericlog where log_id=?");

	if( DBMAllocStmt(ch, &shLoadBoth) < 0)
	{
		OTraceError("E-SHC-131018: query both statement allocate error:\n%s\n", sqlStatementInsert);
	}

	if( DBMPrepare(shLoadBoth, sqlStatementLoadBoth) != DBM_SUCCESS )
	{
		OTraceError("E-SHC-131019: Load query prepare error:\n%s \n", sqlStatementLoadBoth);
	}

	if( (DBMBindCol(shLoadBoth,1,DBM_LONGTYPE,&msgType,sizeof(msgType),&ind[1]) != DBM_SUCCESS) ||
	    (DBMBindCol(shLoadBoth,2,DBM_CHARTYPE,&reqresp,sizeof(reqresp),&ind[2]) != DBM_SUCCESS)  )
	{
		OTraceError("E-SHC-131020: Load query bind error \n");
	}

	bindCount = 2;
	mergedFieldsCount = 0;
	tmpBufList = bufList;	//point to the start
	for(i=0;i<SHC_GENERIC_LOG_BINARY_FIELD_NUM;i++)
	{
		bindCount++;
		if( DBMBindCol(shLoadBoth,bindCount,DBM_BINTYPE,tmpBufList[i].buf,(shcGenericLogBinaryFieldSize+1),&ind[i+3]) != DBM_SUCCESS )//---R016790
		{
			OTraceError("E-SHC-131021: Insert query bind error for the binfield: %d \n", i+1);
		}
	}

	// bindCount for BindCol and BindParam are not related, so use 1 here
	if( DBMBindParam(shLoadBoth,1,DBM_PARAM_INPUT,DBM_STRINGTYPE,logid,sizeof(logid),&ind[0]) != DBM_SUCCESS )
	{
		OTraceError("E-SHC-131023: Load query bind error \n");
	}


	//load entry for either request or response

	char sqlStatementLoad1[512] = "";
	strcat(sqlStatementLoad1, sqlStatementLoadBoth);
	strcat(sqlStatementLoad1, " and reqresp=?");

	if( DBMAllocStmt(ch, &shLoad1) < 0)
	{
		OTraceError("E-SHC-131024: query 1 statement allocate error:\n%s\n", sqlStatementInsert);
	}
	if( DBMPrepare(shLoad1, sqlStatementLoad1) != DBM_SUCCESS )
	{
		OTraceError("E-SHC-131025: Load query prepare error:\n%s \n", sqlStatementLoad1);
	}

	if( (DBMBindCol(shLoad1,1,DBM_LONGTYPE,&msgType,sizeof(msgType),&ind[1]) != DBM_SUCCESS) ||
	    (DBMBindCol(shLoad1,2,DBM_CHARTYPE,&reqresp,sizeof(reqresp),&ind[2]) != DBM_SUCCESS) )
	{
		OTraceError("E-SHC-131026: Load query bind error \n");
	}

	bindCount = 2;
	mergedFieldsCount = 0;
	tmpBufList = bufList;	//point to the start
	for(i=0;i<SHC_GENERIC_LOG_BINARY_FIELD_NUM;i++)
	{
		bindCount++;
		if( DBMBindCol(shLoad1,bindCount,DBM_BINTYPE,tmpBufList[i].buf,(shcGenericLogBinaryFieldSize+1),&ind[i+3]) != DBM_SUCCESS )//---R016790
		{
			OTraceError("E-SHC-131027: Insert query bind error for the field: %d \n", i+1);
		}
	}

	if( (DBMBindParam(shLoad1,1,DBM_PARAM_INPUT,DBM_STRINGTYPE,logid,sizeof(logid),&ind[0]) != DBM_SUCCESS) ||
		(DBMBindParam(shLoad1,2,DBM_PARAM_INPUT_OUTPUT,DBM_CHARTYPE,&reqresp,sizeof(reqresp),NULL) != DBM_SUCCESS) )
	{
		OTraceError("E-SHC-131029: Load query bind error \n");
	}
}


void ShcGenericLogBinary:: fillSegment(ShcmsgHeader *header, char *logHeader, int *logHeaderLen)
{
	if (map76seg)
	{
		shcGenLogHelperObj->fillSegment(header, logHeader, logHeaderLen);
		return;
	}

	int i,j;

//	if (noOfGenLogItem <= 0)
//	{
//		OTraceDebug("D-SHC-131031:No segments configured to log\n");
//		return;
//	}

	struct dbBuffer *tmpBufList = bufList;
	strcpy(logid, header->msg.shclog_id);
	msgType = header->msg.msgtype;
	switch_date = header->msg.settlement_date;
	OCDateTime settleDate(switch_date/10000, switch_date/100 % 100, switch_date % 100, 0, 0, 0, 0 ); 

	if ( !settleDate.isValid() ) 
		switch_date = 0; 
	if (!switch_date)
	{
		switch_date = header->msg.processor_busday;
		OCDateTime procDate(switch_date/10000, switch_date/100 % 100, switch_date % 100, 0, 0, 0, 0 );
		if( !procDate.isValid() )
			switch_date =  header->msg.local_date;
	}

	if( shcIsResponse(header) )	//response messages like 110,210,430,432
		reqresp = 'P';
	else
		reqresp = 'Q';

	//Clear buffer
	for(i=0;i<SHC_GENERIC_LOG_BINARY_FIELD_NUM;i++)
	{
		bufList[i].buf[0] = '\0';

	}
	
	for(i=0;i<(SHC_GENERIC_LOG_BINARY_FIELD_NUM+3);i++)
		ind[i] = 0;

	//fill segmentList from message segments

	int len = shcGenericLogBinaryFieldSize*SHC_GENERIC_LOG_BINARY_FIELD_NUM;
	IstSegList *segList = header->getSegList();
	if (!segList)
	{
		OTraceDebug("D-SHC-131032: No SegList. Nothing to Log\n");
		return ;
	}
	
	logHeader[0] = '\0';valueBufLen= sizeof(valueBuf);

	segList->compose(header->msg.msgtype, valueBuf, &valueBufLen, logHeader, logHeaderLen);
	if ((*logHeaderLen)<=0)	//No segment
	{
		OTraceDebug("D-SHC-131032: No segment to log.\n");
		return ;
	}

	//Fill in ind.
	len = valueBufLen;
	for(i=0;i<SHC_GENERIC_LOG_BINARY_FIELD_NUM;i++)
	{
		if (len > shcGenericLogBinaryFieldSize)
		{
			ind[i+3] = shcGenericLogBinaryFieldSize;
			len -= shcGenericLogBinaryFieldSize;
		}
		else if (len > 0)
		{
			ind[i+3] = len;
			len = 0;
		}
		else
		{
			ind[i+3] = DBM_NULL_DATA;
		}
	}
}

void ShcGenericLogBinary:: insert()
{
	if (map76seg)
	{
		shcGenLogHelperObj->insert();
		return;
	}

	int dataInMergedField;
	int i;

	if (valueBufLen <= 0)
	{
		OTraceDebug("D-SHC-131038:No segments configured to log\n");
		return;
	}

	//set the length
	ind[0] = strlen(logid);		//no need for ind[1] & ind[2]

	OTraceDebug("D-SHC-131043:ShcGenericLogBinary::insert ID=%s\n",logid);


	//	>>>	R024803
	int ret;
	ret = DBMExecute(shInsert);
	if( ret != DBM_SUCCESS )
	{
		OTraceError("E-SHC-131040: Error when executing insert query.\n");
		processError(ret,shInsert);
	//	<<<	R024803
	}
	DBMFreeStmt(shInsert, DBM_CLOSE);
}

void ShcGenericLogBinary:: update()
{
	int dataInMergedField;
	int i;

	if (valueBufLen <= 0)
	{
		OTraceDebug("D-SHC-131038:No segments configured to log\n");
		return;
	}

	//set the length
	ind[0] = strlen(logid);		//no need for ind[1] & ind[2]

	OTraceDebug("D-SHC-0000 ShcGenericLogBinary::update ID=%s\n",logid);

	//	>>>	R024803
	int ret;
	ret = DBMExecute(shUpdate);
	if( ret != DBM_SUCCESS )
	{
		OTraceError("E-SHC-131040: Error when executing insert query.\n");
		processError(ret,shInsert);
	//	<<<	R024803
	}
	DBMFreeStmt(shUpdate, DBM_CLOSE);
}

IstSegList *ShcGenericLogBinary:: restore(ShcmsgHeader *header, char _reqresp, char *reqBufHeader, int reqBufHeaderLen, char *respBufHeader, int respBufHeaderLen)
{
	if (map76seg)
	{
		return(shcGenLogHelperObj->restore(header,_reqresp,reqBufHeader,reqBufHeaderLen,respBufHeader,respBufHeaderLen));
	}
	int i;
//	if (noOfGenLogItem <= 0)
//	{
//		OTraceDebug("D-SHC-131041:No segments configured to log\n");
//		return;
//	}

	DBMHSTMT currentHdl;

	struct dbBuffer *tmpBufList = bufList;
	if (header->origMsg)
		strcpy(logid, header->origMsg->shclog_id);
	else
		strcpy(logid, header->msg.shclog_id);

	ind[0] = strlen(logid);

	if( (_reqresp == 'B') || (_reqresp == 'A') )		//	R018777
	{
		currentHdl = shLoadBoth;
	}
	else	//either request or response
	{
		reqresp = _reqresp;
		currentHdl = shLoad1;
	}

	//	>>>	R024803
	//if( DBMExecute(currentHdl) != DBM_SUCCESS )
	int ret;
	ret = DBMExecute(currentHdl);
	if ( ret != DBM_SUCCESS )
	{
		OTraceError("E-SHC-131042: Error when executing load query [%c].\n", _reqresp);
		processError(ret,currentHdl);
		return NULL;
	//	<<<	R024803
	}

	IstSegList *segList = new IstSegList;
	
	try
	{
		ind[3] = ind[4] =ind[5] =ind[6] =ind[7] = 0 ;
		while((ret = DBMFetch(currentHdl)) == DBM_SUCCESS)
		{
			valueBufLen = (ind[3]>0?ind[3]:0) + (ind[4]>0?ind[4]:0) + (ind[5]>0?ind[5]:0) + (ind[6]>0?ind[6]:0) + (ind[7]>0?ind[7]:0);
			if ((reqresp == 'Q') && reqBufHeader)
				segList->parse(valueBuf, valueBufLen, reqBufHeader, reqBufHeaderLen);
			else if (respBufHeader)
				segList->parse(valueBuf, valueBufLen,respBufHeader, respBufHeaderLen);
			
		}
	
		processError(ret, currentHdl);
	
		DBMFreeStmt(currentHdl, DBM_CLOSE);
	}
	catch(...)
	{
		delete segList;
		return NULL;
	}
	return segList;
}

ShcGenericLogBinary:: ~ShcGenericLogBinary()
{

	if (shUpdate)
		DBMFreeStmt(shUpdate, DBM_DROP);

	if( bufList )
	{
		// >>> R029856 del 7 lines
		delete []bufList;
		bufList = NULL;
	}
	if (valueBuf)
		free(valueBuf);
}

