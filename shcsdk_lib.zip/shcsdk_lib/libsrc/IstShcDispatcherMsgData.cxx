/*
 *  Copyright (C) 2004 eFunds Corporation ("eFunds").  All Rights Reserved.     
 *  eFunds Canada Corporation is an authorized user.                            
 *                                                                              
 *  IST is a registered trademark of eFunds Corporation.  Other brand or        
 *  product names are trademarks or registered trademarks of their respective   
 *  holders.                                                                    
 *                                                                              
 *  The information contained herein is the unpublished proprietary property    
 *  of eFunds.  Except as specifically authorized in writing by eFunds, the     
 *  holder of this document shall: i) keep all information contained herein     
 *  confidential, and ii) protect the information, in whole or in part, from    
 *  disclosure and dissemination to all third parties.                          
 *                                                                          
 *  This document and the software described in it are furnished under license  
 *  and may be used or copied only in accordance with the terms of such license.
 *  This document is supplied for information purposes only, is subject to      
 *  change without notice, and should not be construed as a commitment by       
 *  either eFunds Corporation or eFunds Canada Corporation. 
 *
 *
 *
 *                        MODIFICATION HISTORY                  REVIEW
 *
 *	SPR#	Who	Date	Description			Who	Date   
 * ===========================================================================
 *R000000 ztang 7May13 Creation
 */

//File Number 157

#if defined( WIN32 )
#       define SHCDLLEXPORT __declspec(dllexport)
#else
#       define SHCDLLEXPORT
#endif

static const char* _IstShcDispatcherMsgData_cxx_what = "@(#) IstShcDispatcherMsgData.cxx 1.3 17/09/11 02:40:39";


#include <stdio.h>
#include <string.h>
#include <oasis.h>
#include <ist_otrace.h>
#include <mb.h>
#include <ShcMsgCache.h>
#include <shcmsgdef.h>
#include <shc.h>
#include <ShcmsgHelper.h>
#include <istdispatcher_access.h>
#include <istdispatcher_shcdata.h>



static char _istdispatcher_access_cxx_what[] = "@(#) IstShcDispatcherMsgData.cxx 1.3 17/09/11 02:40:39";
static IstDispatcherAccess *iDispatcherObj=NULL;
static struct shcmsg tmpmsg = { 0 };
static IstShcDispatcherMsgData lShcDispatcherData;

int IstShcDispatcherMsgData::dispatch(const char *dispatchPoint, struct shcmsg *msg, int len)
{


	lShcDispatcherData.Set((char *)msg,len);
	if (!iDispatcherObj)
	{
		iDispatcherObj = new IstDispatcherAccess();
		if (!iDispatcherObj)
		{
			OTraceError("E-SHC-157001: Unable to create object iDispatcherObj. Not dispatching.\n");
			return -1;
		}
	}

	int dRet = iDispatcherObj->doDispatcher(dispatchPoint,&lShcDispatcherData);
	if( dRet == -2)
		OTraceInfo("I-SHC-157002: sending txn to DispatcherExe disabled\n");
	else if (dRet < 0)
		OTraceError("E-SHC-157003: Unable to send txn to DispatcherExe\n");
	else
		OTraceDebug("D-SHC-157004: Txn sent to DispatcherExe m[%d] pc[%ld] t[%d] rc[%d] shcerror[%d]\n",
			msg->msgtype, msg->pcode, msg->trace, msg->respcode,msg->shcerror);

	return dRet;
}

//Dispatch a empty msg, used when a message can't even be parsed
int IstShcDispatcherMsgData::dispatch(const char *dispatchPoint, const char *logId, int msgtype, int respcode, const char *txnSrc, const char *acquirer, const char *txnDest, const char *issuer)
{
	snprintf(tmpmsg.shclog_id, sizeof(tmpmsg.shclog_id), "%s", logId);
	tmpmsg.msgtype = msgtype;
	tmpmsg.respcode = respcode;
	if (txnSrc)
		snprintf(tmpmsg.txnSrc, sizeof(tmpmsg.txnSrc), "%s", txnSrc);
	else
		tmpmsg.txnSrc[0] = 0;
	if (acquirer)
		snprintf(tmpmsg.acquirer, sizeof(tmpmsg.acquirer), "%s", acquirer);
	else
		tmpmsg.acquirer[0] = 0;
	if (txnDest)
		snprintf(tmpmsg.txnDest, sizeof(tmpmsg.txnDest), "%s", txnDest);
	else
		tmpmsg.txnDest[0] = 0;
	if (issuer)
		snprintf(tmpmsg.issuer, sizeof(tmpmsg.issuer), "%s", issuer);
	else
		tmpmsg.issuer[0] = 0;
		
	int dRet = dispatch(dispatchPoint, &tmpmsg, sizeof(tmpmsg));
	return dRet;
}


