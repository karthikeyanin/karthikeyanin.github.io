//
// Copyright (C) 2004 eFunds Corporation ("eFunds").  All Rights Reserved.
// eFunds Canada Corporation is an authorized user.
//
// IST is a registered trademark of eFunds Corporation.  Other brand or
// product names are trademarks or registered trademarks of their respective
// holders.
//
// The information contained herein is the unpublished proprietary property
// of eFunds.  Except as specifically authorized in writing by eFunds, the
// holder of this document shall: i) keep all information contained herein
// confidential, and ii) protect the information, in whole or in part, from
// disclosure and dissemination to all third parties.
//
// This document and the software described in it are furnished under license
// and may be used or copied only in accordance with the terms of such license.
// This document is supplied for information purposes only, is subject to
// change without notice, and should not be construed as a commitment by
// either eFunds Corporation or eFunds Canada Corporation.
// "@(#) ShcGenericLog.cxx 1.13.3.6 20/02/27 15:22:30";
 /*
 *  Date    SCR     Who     Description
 *  ===========================================================================
 *  29Jun06 R016790 spa	 Fixed binding problem:if 1st field not used, 2nd field can't be logged
 *  27Nov06 R018276 pve	 Remove excessive syslg messages
 *  29Jan07 R018777 pve	 Enhance restore() method for new restore flag 'A'(restore all segments)
 *  02Feb07 R018777 pve	 Fix the bug in setting SH_DEVCAP_USER_SEGMENT
 *  16Feb07 R018932 spa  Fix bug in restore(..) method to correct segment length
 *  25Sep08 R024803 sks  Some changes in insert(),restore() to display db error 
 */

/* File Number 131 */

#include <CShcGenericLog.h>
#include <shcfmt.h>
#include <istcurrency.h>
#include <shcgenericlog.h>
#include <dbm_private.h>
#include <dbm.h>
#include <shcdef.h>
#include <shc.h>

#include <HaPtmCctHelper.h>
#include <oc/oc_datetime.h>

int shcGenericLogFieldSize;
int noOfGenLogItem;
static int noOfSegToLog = 0;

int processError(int ret, DBMHSTMT sh)
{
    int recnum=1;
    char sqlstate[6];
    int native_error;
    char msg_text[200];

    switch(ret)
    {
    case DBM_SUCCESS:
        return false;
    case DBM_SUCCESS_WITH_INFO:
        return false;
    case DBM_NO_DATA:
    	OTraceDebug ("D-SHC-131000:End of data\n");
		return false;
    case DBM_ERROR:
        while(DBMGetDiagRec(DBM_HANDLE_STMT, sh, recnum++,
                sqlstate, &native_error, msg_text, sizeof(msg_text), NULL)
                == DBM_SUCCESS)
        {
            OTraceError("E-SHC-131001:%s\n", msg_text);
        }
        if (recnum <= 2)
        {
            OTraceError("E-SHC-131002:Unknown DB error:%d\n", ret);
        }
        return true;
    case DBM_INVALID_HANDLE:
        OTraceError("E-SHC-131003:Invalid handle(internel error)\n");
        return true;
    default:
        OTraceError("E-SHC-131004:Unknow db error:%d\n", ret);
        return true;
    }
}

extern "C"
int compareValues(const void * a, const void * b)
{
	struct SegmentItem *ptr1, *ptr2;
	ptr1 = (struct SegmentItem*)a;
	ptr2 = (struct SegmentItem*)b;

	if(ptr1->fieldNum == ptr2->fieldNum)
		return (ptr1->sequence - ptr2->sequence);
	else
		return (ptr1->fieldNum - ptr2->fieldNum);
}


ShcGenericLog :: ShcGenericLog()
{
	shcGenericLogFieldSize = 512;	//default value
	noOfGenLogItem = 0;
	segmentList = NULL;
	bufList = NULL;
	try
	{
		initialize();
	}
	catch(...)
	{
		OTraceError("E-SHC-131005:initialization failed, no generic log enabled\n");
		noOfGenLogItem = 0;
	}
}

void ShcGenericLog :: initialize()
{
	HaPtmCctHelper::addHandler( "system.dcs.shc_generic" ) ;

	//read the configured parameters from istparam.cfg
	if(cf_open(NULL) >= 0)
	{
		//read shc.genericLogFieldSize
		int fieldSize;
		int i;
		cf_rewind();
		if( (cf_locatenum("shc.genericLogFieldSize", &fieldSize)) < 0 )
		{
			OTraceError("E-SHC-131006: Parameter shc.genericLogFieldSize not found \n");
		}
		else if(fieldSize == 0)
		{
			OTraceError("E-SHC-131007: Invalid value for the parameter shc.genericLogFieldSize \n");
		}
		else
		{
			shcGenericLogFieldSize = fieldSize;
		}


		//read shc.genericLogMerge
		cf_rewind();

		//set shcGenericLogFieldList[] to default values
		for(i=0;i<SHC_GENERIC_LOG_FIELD_NUM;i++)
			shcGenericLogFieldList[i] = i;

		bufList = new dbBuffer[SHC_GENERIC_LOG_FIELD_NUM];
		struct dbBuffer *tmpBufList = bufList;

		//set default values
		memset(bufList, 0, sizeof(struct dbBuffer)*SHC_GENERIC_LOG_FIELD_NUM);

		char temp_config_data[128];
		char sss[sizeof(temp_config_data)];
		int noOfFieldsMerged;
		int smallNum;
		char *ptr;

		while( (cf_nextparm("shc.genericLogMerge", temp_config_data) ) > 0 )
		{
			//Find the smallNum as field numbers may not be sorted
			strcpy(sss, temp_config_data);
			ptr = strtok(sss, " \t\n");
			smallNum = atoi(ptr);
			while(ptr != NULL)
			{
				if (atoi(ptr) < smallNum)
					smallNum = atoi(ptr);
				ptr = strtok(NULL, " \t\n");
			}

			ptr = strtok(temp_config_data, " \t\n");
			noOfFieldsMerged = 0;

			while(ptr != NULL)
			{
				shcGenericLogFieldList[atoi(ptr)-1] = smallNum-1;
				noOfFieldsMerged++;
				( bufList + (atoi(ptr)-1))->flag = 2;	//	merged fields
				ptr = strtok(NULL, " \t\n");
			}

			tmpBufList = bufList + smallNum-1;
			tmpBufList->buf = new char[noOfFieldsMerged*shcGenericLogFieldSize+1];
			tmpBufList->bufferSize = noOfFieldsMerged * shcGenericLogFieldSize;
			tmpBufList->flag = 3;		//first field of the merged field set
		}

		//read shc.genericLogItem
		cf_rewind();

		noOfGenLogItem = cf_countparams("shc.genericLogItem");

		if( noOfGenLogItem <= 0 )
		{
			OTraceDebug("W-SHC-131008: Parameter shc.genericLogItem not found \n");
		}
		else
		{
			segmentList = new SegmentItem[noOfGenLogItem];
			struct SegmentItem* tmpSegmentList = segmentList;
			int noOfTokens;
			cf_rewind();

			while( (cf_nextparm("shc.genericLogItem", temp_config_data) ) > 0 )
			{
				strcpy(sss, temp_config_data);
				ptr = strtok(temp_config_data, " \t\n");
				noOfTokens = 0;
				while(ptr != NULL)
				{
					switch( noOfTokens )
					{
						case 0:
							snprintf(tmpSegmentList->segmentName, sizeof(tmpSegmentList->segmentName),"%s", ptr);
							tmpSegmentList->segmentHashValue = hashValue(ptr);
							break;
						case 1:
							if( shcGenericLogFieldList[atoi(ptr)-1] != (atoi(ptr)-1) )	//merged field
								tmpSegmentList->fieldNum = shcGenericLogFieldList[atoi(ptr)-1];
							else
								tmpSegmentList->fieldNum = (unsigned char)atoi(ptr);

							//allocate memory for buf of bufList
							tmpBufList = bufList + (atoi(ptr)-1);
							if( tmpBufList->flag == 0 )
							{
								tmpBufList->buf = new char[shcGenericLogFieldSize+1];
								tmpBufList->bufferSize = shcGenericLogFieldSize;
								tmpBufList->flag = 1;
							}
							break;
						case 2:
							tmpSegmentList->sequence = (unsigned char)atoi(ptr);
							break;
						case 3:
							if( !stricmp(ptr, "int") )
								tmpSegmentList->dataType = 'I';
							else if( !stricmp(ptr, "char") )
								tmpSegmentList->dataType = 'C';
							else if( !stricmp(ptr, "binary") )
								tmpSegmentList->dataType = 'B';
							else if( !stricmp(ptr, "money") )
								tmpSegmentList->dataType = 'M';
							else
								tmpSegmentList->dataType = 0;
							break;
						case 4:
							if( !stricmp(ptr, "request") )
								tmpSegmentList->restoreFlag = 'Q';
							else if( !stricmp(ptr, "response") )
								tmpSegmentList->restoreFlag = 'P';
							else if( !stricmp(ptr, "always") )
								tmpSegmentList->restoreFlag = 'B';
							else
								tmpSegmentList->restoreFlag = 0;
							break;
						case 5:
							if( strlen(ptr) == 1 )
								tmpSegmentList->separator = *ptr;
							else if (strlen(ptr) >= 2 ) //ascii value may be 2 or 3 char, I have changed design for it.
								tmpSegmentList->separator = (char)atoi(ptr);
							else
							{
								tmpSegmentList->separator = 0x10;
								OTraceError("E-SHC-131009: No separator specified for the segment: %s, default value is used at line:\n%s\n", tmpSegmentList->segmentName, sss);
								//R018276
								//syslg("E-SHC-131009: No separator specified for the segment: %s, default value is used at line:\n%s\n", tmpSegmentList->segmentName, sss);
							}
							break;
					}
					noOfTokens++;
					ptr = strtok(NULL, " \t\n");
				}
				tmpSegmentList->value = NULL;	//set to NULL initially

				if( (noOfTokens < 5) || (noOfTokens > 6) )
				{
					OTraceError("E-SHC-131010: Error in shc.genericLogItem parameter config. format at line:\n%s\n", sss);
				}
				else if( noOfTokens == 5 )	//No separator, use default separator
				{
					tmpSegmentList->separator = 0x10;
				}

				tmpSegmentList++;
			}
		}

		//sort the segment list using qsort
		qsort(segmentList, noOfGenLogItem, sizeof(struct SegmentItem), compareValues);

		cf_close();

		//compose and bind sql statements

		tmpBufList = bufList;	//point to the start
		char fields[512] = "";
                char valuesInsert[128] = " values(?,?,?,?,?,?";
		for(i=0;i<SHC_GENERIC_LOG_FIELD_NUM;i++)
		{
			if( (tmpBufList->flag == 1) || (tmpBufList->flag == 2) || (tmpBufList->flag == 3) )
			{
				snprintf(fields+strlen(fields), (sizeof(fields)-strlen(fields)),",field%d", i+1);
				snprintf(valuesInsert + strlen(valuesInsert), sizeof(valuesInsert)-strlen(valuesInsert),  ",?");
			}
			tmpBufList++;
		}

		//insert query

		char sqlStmtDefaultInsert[512] = "insert into shcgenericlog(log_id,msgtype,reqresp, site_id, switch_date";
        char sqlStatementInsert[512] = {0};

		int bindCount;
		snprintf(sqlStatementInsert, sizeof(sqlStatementInsert), "%s%s)%s)", sqlStmtDefaultInsert, fields, valuesInsert);

	    if (dbm_connect() >=0)
	    {
	        OTraceDebug("D-SHC-131011:Connecting to database successful\n");
	        ch=dbm_dbconn;
	    }
	    else
	    {
	        //OTraceError("E-SHC-131012: Connecting to database failed\n");
	        //throw 1;
			OTraceFatal("F-SHC-131012: Connecting to database failed..Exiting\n");
			kill(getpid(),1);
  	  	}


		if( DBMAllocStmt(ch, &shInsert) < 0)
		{
			OTraceError("E-SHC-131013: Insert query allocate error:\n%s\n", sqlStatementInsert);
		}

		if( DBMPrepare(shInsert, sqlStatementInsert) != DBM_SUCCESS )
		{
			OTraceError("E-SHC-131014: Insert query prepare error:\n%s\n", sqlStatementInsert);
		}

                static short int site_id = mbGetSiteId();

		if( (DBMBindParam(shInsert,1,DBM_PARAM_INPUT,DBM_STRINGTYPE,logid,sizeof(logid),&ind[0]) != DBM_SUCCESS) ||
			(DBMBindParam(shInsert,2,DBM_PARAM_INPUT,DBM_LONGTYPE,&msgType,sizeof(msgType),NULL) != DBM_SUCCESS) ||
			(DBMBindParam(shInsert,3,DBM_PARAM_INPUT,DBM_CHARTYPE,&reqresp,sizeof(reqresp),NULL) != DBM_SUCCESS) ||
                        (DBMBindParam(shInsert,4,DBM_PARAM_INPUT,DBM_INTTYPE, &site_id, sizeof(site_id), NULL) != DBM_SUCCESS) ||
			(DBMBindParam(shInsert,4,DBM_PARAM_INPUT,DBM_DATETYPE,&switch_date,sizeof(switch_date),NULL) != DBM_SUCCESS)  )
		{
			OTraceError("E-SHC-131015: Insert query bind error \n");
		}

		//bind the fields
		tmpBufList = bufList;	//point to the start
		bindCount = 5;
		int mergedFieldsCount = 0;
		for(i=0;i<SHC_GENERIC_LOG_FIELD_NUM;i++)
		{
			if( (tmpBufList->flag == 2) || (tmpBufList->flag == 3) )	//merged fields
			{
				if( tmpBufList->flag == 3 )		//reset mergedFieldsCount when it goes to the next merged fields set
					(bufList+shcGenericLogFieldList[i])->bufferSize = 0;
				bindCount++;
				if( DBMBindParam(shInsert,bindCount,DBM_PARAM_INPUT,DBM_STRINGTYPE,&(bufList+shcGenericLogFieldList[i])->buf[
					(bufList+shcGenericLogFieldList[i])->bufferSize],shcGenericLogFieldSize,&ind[i+3]) != DBM_SUCCESS )// --- R016790
				{
					OTraceError("E-SHC-131016: Insert query bind error for the field: %d \n", i+1);
				}
				(bufList+shcGenericLogFieldList[i])->bufferSize += shcGenericLogFieldSize;
			}
			else if( tmpBufList->flag == 1 )	//used fields
			{
				bindCount++;
				if( DBMBindParam(shInsert,bindCount,DBM_PARAM_INPUT,DBM_STRINGTYPE,tmpBufList->buf,shcGenericLogFieldSize,&ind[i+3]) 
					!= DBM_SUCCESS )	//	---	R016790
				{
					OTraceError("E-SHC-131017: Insert query bind error for the field: %d \n", i+1);
				}
			}
			tmpBufList++;
		}

		//load entry for both request and response

		char sqlStatementLoadBoth[512] = "select msgtype,reqresp";
		strcat(sqlStatementLoadBoth, fields);
		strcat(sqlStatementLoadBoth, " from shcgenericlog where log_id=?");

		if( DBMAllocStmt(ch, &shLoadBoth) < 0)
		{
			OTraceError("E-SHC-131018: query both statement allocate error:\n%s\n", sqlStatementInsert);
		}

		if( DBMPrepare(shLoadBoth, sqlStatementLoadBoth) != DBM_SUCCESS )
		{
			OTraceError("E-SHC-131019: Load query prepare error:\n%s \n", sqlStatementLoadBoth);
		}

		if( (DBMBindCol(shLoadBoth,1,DBM_LONGTYPE,&msgType,sizeof(msgType),&ind[1]) != DBM_SUCCESS) ||
		    (DBMBindCol(shLoadBoth,2,DBM_CHARTYPE,&reqresp,sizeof(reqresp),&ind[2]) != DBM_SUCCESS)  )
		{
			OTraceError("E-SHC-131020: Load query bind error \n");
		}

		bindCount = 2;
		mergedFieldsCount = 0;
		tmpBufList = bufList;	//point to the start
		for(i=0;i<SHC_GENERIC_LOG_FIELD_NUM;i++)
		{
			if( (tmpBufList->flag == 2) || (tmpBufList->flag == 3) )	//merged fields
			{
				if( tmpBufList->flag == 3 )		//reset mergedFieldsCount when it goes to the next merged fields set
					(bufList+shcGenericLogFieldList[i])->bufferSize = 0;
				bindCount++;
				if( DBMBindCol(shLoadBoth,bindCount,DBM_CHARTYPE,&(bufList+shcGenericLogFieldList[i])->buf[
					(bufList+shcGenericLogFieldList[i])->bufferSize],(shcGenericLogFieldSize+1),&ind[i+3]) != DBM_SUCCESS )//---R016790
				{
					OTraceError("E-SHC-131021: Insert query bind error for the field: %d \n", i+1);
				}
				(bufList+shcGenericLogFieldList[i])->bufferSize += shcGenericLogFieldSize;
			}
			else if(tmpBufList->flag == 1)	//used fields
			{
				bindCount++;
				//	---	R016790
				if( DBMBindCol(shLoadBoth,bindCount,DBM_CHARTYPE,tmpBufList->buf,(shcGenericLogFieldSize+1),&ind[i+3]) != DBM_SUCCESS )
				{
					OTraceError("E-SHC-131022: Load query bind error for the field: %d \n", i+1);
				}
			}
			tmpBufList++;
		}

		// bindCount for BindCol and BindParam are not related, so use 1 here
		if( DBMBindParam(shLoadBoth,1,DBM_PARAM_INPUT,DBM_STRINGTYPE,logid,sizeof(logid),&ind[0]) != DBM_SUCCESS )
		{
			OTraceError("E-SHC-131023: Load query bind error \n");
		}


		//load entry for either request or response

		char sqlStatementLoad1[512] = "";
		strcat(sqlStatementLoad1, sqlStatementLoadBoth);
		strcat(sqlStatementLoad1, " and reqresp=?");

		if( DBMAllocStmt(ch, &shLoad1) < 0)
		{
			OTraceError("E-SHC-131024: query 1 statement allocate error:\n%s\n", sqlStatementInsert);
		}
		if( DBMPrepare(shLoad1, sqlStatementLoad1) != DBM_SUCCESS )
		{
			OTraceError("E-SHC-131025: Load query prepare error:\n%s \n", sqlStatementLoad1);
		}

		if( (DBMBindCol(shLoad1,1,DBM_LONGTYPE,&msgType,sizeof(msgType),&ind[1]) != DBM_SUCCESS) ||
		    (DBMBindCol(shLoad1,2,DBM_CHARTYPE,&reqresp,sizeof(reqresp),&ind[2]) != DBM_SUCCESS) )
		{
			OTraceError("E-SHC-131026: Load query bind error \n");
		}

		bindCount = 2;
		mergedFieldsCount = 0;
		tmpBufList = bufList;	//point to the start
		for(i=0;i<SHC_GENERIC_LOG_FIELD_NUM;i++)
		{
			if( (tmpBufList->flag == 2) || (tmpBufList->flag == 3) )	//merged fields
			{
				if( tmpBufList->flag == 3 )		//reset mergedFieldsCount when it goes to the next merged fields set
					(bufList+shcGenericLogFieldList[i])->bufferSize = 0;
				bindCount++;
				if( DBMBindCol(shLoad1,bindCount,DBM_CHARTYPE,&(bufList+shcGenericLogFieldList[i])->buf[
					(bufList+shcGenericLogFieldList[i])->bufferSize],(shcGenericLogFieldSize+1),&ind[i+3]) != DBM_SUCCESS )//---R016790
				{
					OTraceError("E-SHC-131027: Insert query bind error for the field: %d \n", i+1);
				}
				(bufList+shcGenericLogFieldList[i])->bufferSize += shcGenericLogFieldSize;
			}
			else if(tmpBufList->flag == 1)	//used fields
			{
				bindCount++;
				//	---	R016790
				if( DBMBindCol(shLoad1,bindCount,DBM_CHARTYPE,tmpBufList->buf,(shcGenericLogFieldSize+1),&ind[i+3]) != DBM_SUCCESS )
				{
					OTraceError("E-SHC-131028: Load query bind error for the field: %d \n", i+1);
				}
			}
			tmpBufList++;
		}

		if( (DBMBindParam(shLoad1,1,DBM_PARAM_INPUT,DBM_STRINGTYPE,logid,sizeof(logid),&ind[0]) != DBM_SUCCESS) ||
			(DBMBindParam(shLoad1,2,DBM_PARAM_INPUT_OUTPUT,DBM_CHARTYPE,&reqresp,sizeof(reqresp),NULL) != DBM_SUCCESS) )
		{
			OTraceError("E-SHC-131029: Load query bind error \n");
		}

	}

	else
	{
		OTraceError("E-SHC-131030: Can not open istparam.cfg configuration file.\n");
	}
}

void ShcGenericLog :: fillSegment(ShcmsgHeader *header, char *logHeader, int *logHeaderLen)
{
	int i,j;
	noOfSegToLog = 0;

	if (noOfGenLogItem <= 0)
	{
		OTraceDebug("D-SHC-131031:No segments configured to log\n");
		return;
	}

	struct dbBuffer *tmpBufList = bufList;
	strcpy(logid, header->msg.shclog_id);
	msgType = header->msg.msgtype;
	switch_date = header->msg.settlement_date;
 	OCDateTime settleDate(switch_date/10000, switch_date/100 % 100, switch_date % 100, 0, 0, 0, 0 );

        if ( !settleDate.isValid() )
                switch_date = 0;
        if (!switch_date)
        {
                switch_date = header->msg.processor_busday;
                OCDateTime procDate(switch_date/10000, switch_date/100 % 100, switch_date % 100, 0, 0, 0, 0 );
                if( !procDate.isValid() )
                        switch_date =  header->msg.local_date;
        }

	//if (!switch_date)
	//	switch_date = header->msg.processor_busday;

	if( (msgType%20) == 10 )	//response messages like 110,210,430
		reqresp = 'P';
	else
		reqresp = 'Q';

	//reset segmentList and bufList
	for(i=0;i<noOfGenLogItem;i++)
		(segmentList+i)->value = NULL;

	for(i=0;i<SHC_GENERIC_LOG_FIELD_NUM;i++)
	{
		if( (bufList+i)->buf != NULL )
			(bufList+i)->buf[0] = '\0';

	}
	for(i=0;i<(SHC_GENERIC_LOG_FIELD_NUM+3);i++)
		ind[i] = 0;

	//fill segmentList from message segments

//	if (!(header->msg.device_cap & SH_DEVCAP_USER_SEGMENT))	//No segment
//		return ;

	IstSegList *segList = header->getSegList();
	if (!segList->getNextSegItem(IST_SEG_FROM_BEGIN))
		return ;
		
	char segBuf[SHC_SEG_MAX];
	struct shcseg *seg = (struct shcseg *)segBuf;

	int noOfSegments = shc_segnsegments(seg);

	OTraceDebug("D-SHC-131032: No. of segments found in the message: %d\n", noOfSegments);

	struct shcsegstart * segStart = shc_segfirst(seg);
	char *ptr;

	for(i=0;i<noOfSegments;i++)
	{
		ptr = shc_segname(seg, segStart);

		for(j=0;j<noOfGenLogItem;j++)
		{
			int tmpHashValue = hashValue(ptr);
			if( (tmpHashValue == (segmentList+j)->segmentHashValue)
				&& ( stricmp(ptr, (segmentList+j)->segmentName) == 0 ) )
			{
				(segmentList+j)->value = shc_seggetdata_pointer(seg, segStart);
				(segmentList+j)->segmentDataLen = shc_seggetdata_len(seg, segStart);

			}

		}
		segStart = shc_segnext(seg, segStart);
		if( segStart == NULL)
			break;
	}

	//fill the bufList from segmentList

	int *dataLen;
	amount_t *amt;

	for(i=0;i<noOfGenLogItem;i++)
	{
		tmpBufList = bufList + ( (segmentList+i)->fieldNum - 1);
		dataLen = &ind[(segmentList+i)->fieldNum + 2];

		if( (segmentList+i)->value != NULL )
		{

			switch( (segmentList+i)->dataType )
			{
				case 'C':
					segmentList[i].segmentDataLen = strlen(segmentList[i].value);
					if( ((*dataLen) +(segmentList+i)->segmentDataLen)  >  tmpBufList->bufferSize )
					{
						OTraceError("E-SHC-131033: Buffer overflow, unable to write the segment %s\n", (segmentList+i)->segmentName );
					}
					else
					{
						*dataLen += format_out((unsigned char*)(&tmpBufList->buf[*dataLen]),
								(segmentList+i)->value,FMT_CHAR, (segmentList+i)->segmentDataLen );
					}
					if( (*dataLen) < tmpBufList->bufferSize)	//to separate the segments/to indicate no data
						tmpBufList->buf[(*dataLen)++] = (segmentList+i)->separator;

					tmpBufList->buf[*dataLen] = 0;
					break;
				case 'I':
					(segmentList+i)->segmentDataLen = sprintf(&tmpBufList->buf[*dataLen],"%d",*(int*)(segmentList+i)->value);
					if( ((*dataLen) +(segmentList+i)->segmentDataLen)  >  tmpBufList->bufferSize )
					{
						OTraceError("E-SHC-131034: Buffer overflow, unable to write the segment %s\n", (segmentList+i)->segmentName );
					}
					else
					{
						*dataLen += format_out((unsigned char*)(&tmpBufList->buf[*dataLen]),
								(segmentList+i)->value,FMT_ITOA,(segmentList+i)->segmentDataLen );
					}
					if( (*dataLen) < tmpBufList->bufferSize)	//to separate the segments/to indicate no data
						tmpBufList->buf[(*dataLen)++] = (segmentList+i)->separator;

					tmpBufList->buf[*dataLen] = 0;
					break;
				case 'B':
					if( ((*dataLen) +(segmentList+i)->segmentDataLen*2)  >  tmpBufList->bufferSize )
					{
						OTraceError("E-SHC-131035: Buffer overflow, unable to write the segment %s\n", (segmentList+i)->segmentName );
					}
					else
					{
						*dataLen += format_out((unsigned char*)(&tmpBufList->buf[*dataLen]),
								(segmentList+i)->value,FMT_HTOA, (segmentList+i)->segmentDataLen*2 );
					}
					if( (*dataLen) < tmpBufList->bufferSize)	//to separate the segments/to indicate no data
						tmpBufList->buf[(*dataLen)++] = (segmentList+i)->separator;

					tmpBufList->buf[*dataLen] = 0;
					break;
				case 'M':
					amt = (amount_t*)(segmentList+i)->value;
					(segmentList+i)->segmentDataLen = strlen(amt->v.esql_decimal.digits);	//it may require correction
					if( ((*dataLen) +(segmentList+i)->segmentDataLen)  >  tmpBufList->bufferSize )
					{
						OTraceError("E-SHC-131036: Buffer overflow, unable to write the segment %s\n", (segmentList+i)->segmentName );
					}
					else
					{
						*dataLen += ccy_format_out((unsigned char*)(&tmpBufList->buf[*dataLen]),
								amt,FMT_CTOM, (segmentList+i)->segmentDataLen, header->msg.acq_currency_code );
					}
					if( (*dataLen) < tmpBufList->bufferSize)	//to separate the segments/to indicate no data
						tmpBufList->buf[(*dataLen)++] = (segmentList+i)->separator;

					tmpBufList->buf[*dataLen] = 0;
					break;
				default:
					OTraceError("E-SHC-131037: Unknown data type\n");
					break;

			}
			noOfSegToLog ++;
		}
		else	// segment doesn't have any data
		{
			tmpBufList->buf[(*dataLen)++] = (segmentList+i)->separator;
			tmpBufList->buf[*dataLen] = 0;
		}

	}

}

void ShcGenericLog :: insert()
{
	int dataInMergedField;
	int i;

	if (noOfGenLogItem <= 0)
	{
		OTraceDebug("D-SHC-131038:No segments configured to log\n");
		return;
	}
	if (noOfSegToLog <= 0)
	{
		OTraceDebug("D-SHC-131039:No segments found to log\n");
		return;
	}

	//set the length
	ind[0] = strlen(logid);		//no need for ind[1] & ind[2]

	for(i=0;i<SHC_GENERIC_LOG_FIELD_NUM;i++)
	{
		if (bufList[i].flag == 2)
		{
			//This field is merged to a smaller number field
			int actualField = shcGenericLogFieldList[i];
			struct dbBuffer *actualBuf = &bufList[actualField];

			if (ind[actualField+3] <= shcGenericLogFieldSize )
			{
				ind[i+3] = 0; //No data spilled into this field
			}
			else
			{
				//Data from smaller number field extends to this field
				int spill = ind[actualField+3] - shcGenericLogFieldSize;

				if (spill > shcGenericLogFieldSize)
					//This field can only hold this much
					ind[i+3] = shcGenericLogFieldSize;
				else
					//This is the last field needed to hold the spill
					ind[i+3] = spill;

				ind[actualField+3] -= ind[i+3];
			}
		}
		else if( bufList[i].flag == 3 )		//merged fields
		{
			//Nothing to do, ind for this field will be reduced by other merged fields
		}
		//for all other fields, the ind already has the length of data
	}

	//	>>>	R024803
	//if( DBMExecute(shInsert) != DBM_SUCCESS )
	int ret;
	ret = DBMExecute(shInsert);
	if( ret != DBM_SUCCESS )
	{
		OTraceError("E-SHC-131040: Error when executing insert query.\n");
		processError(ret,shInsert);
	//	<<<	R024803
	}
	DBMFreeStmt(shInsert, DBM_CLOSE);
}

IstSegList *ShcGenericLog :: restore(ShcmsgHeader *header, char _reqresp, char *reqBufHeader, int reqBufHeaderLen, char *respBufHeader, int respBufHeaderLen)
{
	int i;
	if (noOfGenLogItem <= 0)
	{
		OTraceDebug("D-SHC-131041:No segments configured to log\n");
		return NULL;
	}

	DBMHSTMT currentHdl;

	struct dbBuffer *tmpBufList = bufList;
	strcpy(logid, header->msg.shclog_id);
	ind[0] = strlen(logid);

	if( (_reqresp == 'B') || (_reqresp == 'A') )		//	R018777
	{
		currentHdl = shLoadBoth;
	}
	else	//either request or response
	{
		reqresp = _reqresp;
		currentHdl = shLoad1;
	}

	//	>>>	R024803
	//if( DBMExecute(currentHdl) != DBM_SUCCESS )
	int ret;
	ret = DBMExecute(currentHdl);
	if ( ret != DBM_SUCCESS )
	{
		OTraceError("E-SHC-131042: Error when executing load query [%c].\n", _reqresp);
		processError(ret,currentHdl);
	//	<<<	R024803
	}

	char *ptrStart;
	char *ptrSeparator;
	char tmp[4];
	int fieldNumPrev = -1;
	char tmpSegBuf[SHC_SEG_MAX];
	char tmpNewSegBuf[SHC_SEG_MAX];
	
	struct shcseg *seg = (struct shcseg *)tmpNewSegBuf;

    shc_segbegin(seg);

	//header->msg.device_cap |= SH_DEVCAP_USER_SEGMENT;		//	R018777

	//int ret;	//	---	R024803

	for(i=0;i<SHC_GENERIC_LOG_FIELD_NUM;i++)
	{
		if(tmpBufList->flag)
		{
			memset(tmpBufList->buf, 0, tmpBufList->bufferSize);
		}
		tmpBufList++;
	}

	while((ret = DBMFetch(currentHdl)) == DBM_SUCCESS)
	{
		fieldNumPrev = -1;

		for(i=0;i<noOfGenLogItem;i++)
		{
			tmpBufList = bufList + ( (segmentList+i)->fieldNum -1);

			if( fieldNumPrev != (segmentList+i)->fieldNum )
			{
				ptrStart = tmpBufList->buf;
				fieldNumPrev = (segmentList+i)->fieldNum;
			}

			if ((segmentList+i)->separator)
			{
				tmp[0] = (segmentList+i)->separator;
				tmp[1] = '\0';
				ptrSeparator = strpbrk(ptrStart, tmp);
			}
			else
				//No separator, use rest of the buffer
				ptrSeparator = ptrStart + strlen(ptrStart);

			if (!ptrSeparator)
			{
				if( strlen(ptrStart) == 0)	//No valid data in this record
					continue;
				else
					ptrSeparator = ptrStart + strlen(ptrStart);
			}

			if( ptrSeparator == ptrStart )	//No data for this segment
			{
				ptrStart++;	//skip the separator
				continue;
			}

			if( (_reqresp == 'A') || ((segmentList+i)->restoreFlag == 'B') || ((segmentList+i)->restoreFlag == reqresp))	//	R018777
			{
				shc_segaddsegment(seg, (segmentList+i)->segmentName);

				//format the data to IMF then add into segment
				switch( (segmentList+i)->dataType )
				{
					case 'C':
						format_in((unsigned char*)ptrStart, tmpSegBuf, FMT_CHAR, (ptrSeparator-ptrStart) );
						tmpSegBuf[(ptrSeparator-ptrStart)] = '\0';
						shc_segadddata(seg, tmpSegBuf, (ptrSeparator-ptrStart)); //	---	R018932
						break;
					case 'I':
						int value;
						format_in((unsigned char*)ptrStart, &value, FMT_ATOI, (ptrSeparator-ptrStart));
						shc_segadddata(seg, (char*)&value, sizeof(value));
						break;
					case 'M':
						amount_t amt;
						ccy_format_in((unsigned char*)ptrStart, &amt, FMT_CTOM,
								(ptrSeparator-ptrStart), header->msg.acq_currency_code );
						shc_segadddata(seg, (char*)&amt, sizeof(amt));
						break;
					case 'B':
						format_in((unsigned char*)ptrStart, tmpSegBuf, FMT_ATOH, (ptrSeparator-ptrStart) );
						shc_segadddata(seg, tmpSegBuf, (ptrSeparator-ptrStart)/2);
						break;
					default:
						OTraceError("E-SHC-131043: Unknown data type\n");
						break;
				}
			}
			ptrStart = ptrSeparator + 1;	// 1 added to skip separator

		}
	}

	processError(ret, currentHdl);

	shc_segend( seg );

	DBMFreeStmt(currentHdl, DBM_CLOSE);

	//	>>>	R018777
	IstSegList *segList=NULL;
	if( seg->nsegments > 0 )
	{
		segList=new IstSegList();
		segList->unflattenSegMemcpy_shc_segments((struct shcsegment *)seg);
	}
	//	<<<	R018777


	return segList;
}

int ShcGenericLog :: hashValue(const char* ptr)
{
	if( (ptr == NULL) || (noOfGenLogItem == 0) )
		return 0;

	int sum = 0;
	for(;*ptr;ptr++)
		sum += *ptr;
	return sum;
}

ShcGenericLog :: ~ShcGenericLog()
{

	DBMFreeStmt(shLoadBoth, DBM_DROP);
	DBMFreeStmt(shLoad1, DBM_DROP);
	DBMFreeStmt(shInsert, DBM_DROP);

	if( bufList )
	{
		//first free the memory allocated for buf
		for(int i=0;i<SHC_GENERIC_LOG_FIELD_NUM;i++)
		{
			if( (bufList+i)->buf != NULL )
				delete (bufList+i)->buf;
		}
	delete []bufList;
	}
	if( segmentList )
		delete []segmentList;
}

