/*
 *  Copyright (C) 2004 eFunds Corporation ("eFunds").  All Rights Reserved.     
 *  eFunds Canada Corporation is an authorized user.                            
 *                                                                              
 *  IST is a registered trademark of eFunds Corporation.  Other brand or        
 *  product names are trademarks or registered trademarks of their respective   
 *  holders.                                                                    
 *                                                                              
 *  The information contained herein is the unpublished proprietary property    
 *  of eFunds.  Except as specifically authorized in writing by eFunds, the     
 *  holder of this document shall: i) keep all information contained herein     
 *  confidential, and ii) protect the information, in whole or in part, from    
 *  disclosure and dissemination to all third parties.                          
 *                                                                          
 *  This document and the software described in it are furnished under license  
 *  and may be used or copied only in accordance with the terms of such license.
 *  This document is supplied for information purposes only, is subject to      
 *  change without notice, and should not be construed as a commitment by       
 *  either eFunds Corporation or eFunds Canada Corporation. 
 */
/*
#pragma ident "@(#) InstProfile.cxx 1.14.9.2 20/02/27 15:21:33";
 *
 *                        MODIFICATION HISTORY                  REVIEW
 *
 *	SPR#	Who	Date	Description
 * ===========================================================================
 *R008717 ztang	13Nov02	Created to support multi-institution 
 *R009248 ztang 24Feb03 Remove spaces from instituion id fields
 *R012134 Emj   02Oct04 Issuer Entity Support
 *R015416 Emj   06Jan06 Set ExternalID Desc in Networkinfo
 *R022481 jyang 29Jan08 Supported for locking shared memory of rules
 *R030556 dipa  14Jun12 Clone of R030592
 *R030643 las   20Jun12 clone of R030592 - add routing info to network info
 *R031154 dipa  21Dec12 Clone of R030947,R031026
 */

//File Number 3
#if defined( WIN32 )
#       define SHCDLLEXPORT __declspec(dllexport)
#else
#       define SHCDLLEXPORT
#endif



#include <stdio.h>
#include <sys/timeb.h>
#include <oasis.h>
#include <rules.h>
#include <shc.h>
#include <string.h>
#include <ic/ic_bin.h>
#include<ic/ic_instid.h>
#include <ctype.h>
#include <ist_otrace.h>
#include <mt_extbin.h>
#include <IssProfile.h>
#include <InstProfile.h>
#include <shc.h>
#include <stl/set.h>
#include <oc/oc_string.h>
#include <ShcmsgHelper.h>
#include <ShcAppBase.h>
#include <BinRoute.h>
#include <ShcSharedMemoryHelper.h>
#include <ShcKeyHelper.h>
#include <ShcmsgHeader.h>
#include <ist_seg_id.h>
#include <istsafe.h>

int instProfileFindUpBin = 0;
int instProfNeedPause = 1;
int setRoutingWithInstProfile = 1;

struct rules_keytab *instProfileAppHead = NULL;
int InstProfile::institutionProfileAppid = -1;
struct     rules_keytab    *InstProfile::institutionRuleKeyp = NULL;
struct InstitutionProfileShm *InstProfile::institutionProfileData = NULL;
int	instProfileIdLocateByKeyParam = -1;

int InstProfile::MatchBin(const struct InstitutionProfile &ip, const char *txnSrc,
					      const char *txnDest, const char *iss_entityId,
			              const char *msgType, const bin_t bin)
{
	if ( (!ip.m_txnSrc[0] || (txnSrc && (strcmp((char *)ip.m_txnSrc, (char *)txnSrc) == 0))) && 
	     (!txnDest || !ip.m_txnDest[0] || (txnDest && (strcmp((char *)ip.m_txnDest, (char *)txnDest) == 0))) && 
	     (!iss_entityId || !ip.m_iss_entityId[0] || (iss_entityId && (strcmp((char *)ip.m_iss_entityId, (char *)iss_entityId) == 0))) && 
		 (!ip.m_msgType[0] || (msgType && ist_regexpcv((char *)ip.m_msgType, (char *)msgType, 0))) &&
		 (strcmp(ip.m_bin, bin)==0))
		return 1;
	else
		return 0;
}

int InstProfile::Match(const struct InstitutionProfile &ip, const char *txnSrc, 
		const char *msgType, const char *externalId, const char *member_ID, const char *F_ID)
{
	if (	(txnSrc && (strcmp((char *)ip.m_txnSrc, (char *)txnSrc)==0)) && 
			(!(ip.m_msgType[0]) || (msgType && ist_regexpcv( (char *)ip.m_msgType, (char *)msgType, 0))) &&
			(	!(ip.m_externalId[0]) || 
				( externalId && ist_regexpcv((char *)ip.m_externalId, (char *)externalId, 0))) &&
			(!ip.m_member_ID[0] || ( member_ID && ist_regexpcv((char *)ip.m_member_ID, (char *)member_ID, 0) )) &&
			(!ip.m_F_ID[0] || ( F_ID && ist_regexpcv((char *)ip.m_F_ID, (char *)F_ID, 0) ))
		)
		return 1;
	else
		return 0;
}

int InstProfile::reverseMatch(const struct InstitutionProfile *ip, const char *txnSrc,
                const char *msgType, const char *externalId, const char *member_ID, const char *F_ID)
{
        if (    (!txnSrc || !txnSrc[0]|| !ip->m_txnSrc[0] ||(strcmp((char *)ip->m_txnDest, (char *)txnSrc)==0)) &&
                        (!(ip->m_msgType[0]) || !msgType||!msgType[0]||(msgType && ist_regexpcv( (char *)ip->m_msgType, (char *)msgType, 0))) &&
                        (       !(ip->m_externalId[0]) || !externalId || !externalId[0]||
                                ( externalId && ist_regexpcv((char *)ip->m_externalId, (char *)externalId, 0))) &&
                        (!ip->m_member_ID[0] || !member_ID|| !member_ID[0]||( member_ID && ist_regexpcv((char *)ip->m_member_ID, (char *)member_ID, 0) )) &&
                        (!ip->m_F_ID[0] || !F_ID|| !F_ID[0]||( F_ID && ist_regexpcv((char *)ip->m_F_ID, (char *)F_ID, 0) ))
                )
                return 1;
        else
                return 0;
}

int InstProfile::Match(const struct InstitutionProfile &ip, const char *inst, const char *iss_entityId, const char *msgType)
{
	if (	(inst && (strcmp((char *)ip.m_txnSrc, (char *)inst)==0)) && 
			(inst && (strcmp((char *)ip.m_txnDest, (char *)inst)==0)) &&
	        (!ip.m_iss_entityId[0] || (iss_entityId && (strcmp((char *)ip.m_iss_entityId, (char *)iss_entityId) == 0))) && 
			(!(ip.m_msgType[0]) || (msgType && ist_regexpcv( (char *)ip.m_msgType, (char *)msgType, 0)))
		)
		return 1;
	else
		return 0;
}

int InstProfile::initialized = 0;

int InstProfile::initialize()
{
	int appid;

	if((appid = rm_getappid("inst_profile")) < 0)
	{
		OTraceFatal("F-SHC-003001:unable to locate message name: inst_profile\n");
		return(-1);
	}
	else {
		/*	Find the first entry of my key table */
		institutionProfileAppid   = appid;
		institutionRuleKeyp = rm_getapphead(appid);
		institutionProfileData = (struct InstitutionProfileShm *)rm_getappkey(appid);
	}
	initialized = 1;
	return 0;
}

ShcmsgHeader *headerForLocateNetworkInfo = NULL;
void InstProfile::locateNetworkInfo(const char * txnSrc, 
									const char *txnDest, const char *iss_entityId, 
									const int msgType, const bin_t bin, NetworkInfo &networkInfo)
{
	bin_t tmpTxnSrc;
	char msgTypeBuf[8];
	bin_t tmpBin;
	int downEntry = -1;
        ShcmsgHeader *header = NULL;
        if (headerForLocateNetworkInfo)
        {
                header = headerForLocateNetworkInfo;
                headerForLocateNetworkInfo = NULL;
        }

	resultNum = 0;
	
	snprintf(msgTypeBuf, sizeof(msgTypeBuf), "%04d", msgType);
 	ICInstId_pure(tmpTxnSrc, (char *)txnSrc);
	snprintf(tmpBin, sizeof(tmpBin), "%s", bin);

	shcApp->shcmsgHelperObj->shc_normalizebin(tmpBin);

	networkInfo.reset();
        if (shcApp->shcBinObj->setBinPkg(tmpBin) < 0)
        {
                OTraceError("E-SHC-003014:Can't find bin[%s] in locateNetworkInfo. return.\n", tmpBin);
                return;
        }

	if (!initialized)
	{
		if (initialize() < 0)
			return;
	}

	if (setInstRuleParam() < 0)
			return;


//	if ( rm_waitForLockedShdMem(institutionProfileAppid) )		// R022481
//	{
//		OTraceWarning("W-SHC-003002.1: rm.appid[%d] was locked. Go ahead\n", institutionProfileAppid);
//	}


	for (int i = 0; i<institutionRuleKeyp->keysused; i++)
	{
		// First iteration resultNum == 0
		if ( resultNum > 0)
		{
			//if ((institutionProfileData[i].m_priority != profileResult[resultNum-1].p->m_priority) ||
			if( strcmp(institutionProfileData[i].m_bin, profileResult[resultNum-1].p->m_bin)!=0)
			break;
		}
		if (MatchBin((*(InstitutionProfile *)&institutionProfileData[i]), tmpTxnSrc, txnDest, iss_entityId, msgTypeBuf, tmpBin))
		{
//			if(institutionProfileData[i].status == BIN_ROUTE_STATUS_DOWN)
//			{
//				if (downEntry < 0)
//				{
//					downEntry = i;
//				}
//			}
//			else
//			{
				profileResult[resultNum].p = &institutionProfileData[i];		
				OTraceDebug("D-SHC-003008:added inst_profile to result list[%d]\n",
					profileResult[resultNum].p->id);
				resultNum++;
//			}
//			continue;
		}
	}
	InstitutionProfile *p = NULL;
	m_route_set = false;
	if (!setRoutingWithInstProfile)
			_shouldUpdateCounter = 0;

	if (resultNum > 0)
	{
		OTraceDebug("D-SHC-003006:Found %d inst_profile entries, choose one\n", resultNum);
                int routeRemote = 0;
        if (header && header->msg.device_cap & SH_DEVCAP_FROM_REPLAY)
        {
            if (shc_safBridgeEnabled(shcApp->shcBinObj->binPkg))
                routeRemote = 1;
        }
        else if ((shcApp->shcBinObj->binPkg->bin.bin_cfg & SH_CFG_ENABLE_DUAL_SITE_BRIDGE))
        {
            routeRemote = 1;
        }

                p = chooseEntry(routeRemote);

	}
//	else if (downEntry >= 0)
//	{
//		OTraceDebug("D-SHC-003007:Only down inst_profile entry %d found\n", downEntry);
//		p = &institutionProfileData[downEntry];
//	}
	if (p)
	{
//		networkInfo.putExternalId(p->m_externalId);
//		networkInfo.putExternalIdDesc(p->m_externalIdDesc);
//		networkInfo.putMember_ID(p->m_member_ID);
//		networkInfo.putF_ID(p->m_F_ID);
		networkInfo.putInstProfileEntry(p);
		OTraceDebug("D-SHC-003008:inst_profile with id(%d) found\n", p->id);
		//	>>>	R030643
		if ( m_route_set == true )
		{
			networkInfo.putRoutingInfo(&m_route);
		}
		//	<<<	R030643
		
	}
	_shouldUpdateCounter = 1;
	return;
}
void InstProfile::locateNetworkInfoByKeyParam(int keyParam, NetworkInfo &networkInfo)
{
	int i;
    int id = instProfileIdLocateByKeyParam;
    instProfileIdLocateByKeyParam = -1; //Clear it immediately to avoid impact to next call

	
	networkInfo.reset();

	if (!initialized)
	{
		if (initialize() < 0)
			return;
	}

	if (setInstRuleParam() < 0)
		return;


//	if ( rm_waitForLockedShdMem(institutionProfileAppid) )		// R022481
//	{
//		OTraceWarning("W-SHC-003002.1: rm.appid[%d] was locked. Go ahead\n", institutionProfileAppid);
//	}


	struct RoutingInfo routingInfo = { 0 };
	int routingInfoSet = 0;
	resultNum = 0;
	InstitutionProfileShm *firstMatch = NULL;
	for (i = 0; i<institutionRuleKeyp->keysused; i++)
	{
		if (institutionProfileData[i].keyparm == keyParam)
		{
			InstitutionProfileShm *ip = &institutionProfileData[i];

            if (id>=0)
            {
                if (ip->id == id)
                {
                    //inst_profile id specified, if matched return immediately
                    resultNum = 1;
                    break;
                }
                continue;
            }

			if (!firstMatch)
				firstMatch = &institutionProfileData[i];
			memset( &routingInfo, 0x00, sizeof(struct RoutingInfo) );
			strcpy(routingInfo.destNode, mbcurrentnode);
			strcpy(getRouteEntriesBinrouteGroup, ip->binrouteGroup);
			int noOfRoutes = binRouteObj->getRouteEntries(ip->m_bin, &routingInfo);
			int index;
			
			for (index=0; index < noOfRoutes; index++)
			{
				struct s_binroute *rte = binRouteObj->getRoute(index);
				if ( (rte->status == BIN_ROUTE_STATUS_UP) )
				{
					profileResult[resultNum].p = &institutionProfileData[i];
					binRouteObj->useRoute(rte, &routingInfo, NULL);
					routingInfoSet = 1;
					resultNum++;
					break;
				}
			}
			if ( resultNum == 1 )
				break;
		}
	}

	if (resultNum <=0 )
	{
		if (firstMatch)
		{
			//No inst_profile with associated binroute was found, just use the first inst_profile
			networkInfo.putInstProfileEntry((InstitutionProfile *)firstMatch);
		}
		return;
	}

	networkInfo.putInstProfileEntry((InstitutionProfile *)&institutionProfileData[i]);
	if (routingInfoSet)
		networkInfo.putRoutingInfo(&routingInfo);
	return;
}

//keyParam must have be normalized(pad space at left)
void InstProfile::locateNetworkInfoByKeyParamStr(const char *instId, const char * keyParam, NetworkInfo &networkInfo, const char *bin)
{
	int i;
	struct InstitutionProfileShm *pTmp = NULL;
	char *p = NULL;
    int id = instProfileIdLocateByKeyParam;
    instProfileIdLocateByKeyParam = -1; //Clear it immediately to avoid impact to next call

					
	networkInfo.reset();

	if (!initialized)
	{
		if (initialize() < 0)
			return;
	}

	if (setInstRuleParam() < 0)
		return;

	if (shcSharedMemoryHelperObj->attachCurrent(&institutionProfileAppid, &instProfileAppHead) < 0)
	{
		OTraceError("E-SHC-003002.1: Can't attach to inst_profile memory. Can't locate inst_profile entry for (%s,%s)\n", 
				instId, keyParam);
		return;
	}
	p = rm_getappkey(institutionProfileAppid);
	if (p == NULL)
	{
		OTraceError("E-SHC-003010: Can't get pointer to text. failed to get key for (%s,%s)\n", 
				instId, keyParam);
		return;
	}

	struct RoutingInfo routingInfo = { 0 };
	resultNum = 0;
	int routingInfoSet = 0;
	InstitutionProfileShm *firstMatch = NULL;
	for (i = 0; i<instProfileAppHead->keysused; i++, p += instProfileAppHead->keysize)
	{
		pTmp = (struct InstitutionProfileShm *)p;
		if (	(strcmp(pTmp->keyparamStr, keyParam)==0) &&
			(strcmp(pTmp->instId,instId)==0))
		{
			if (bin)
			{
				if (strcmp(bin, pTmp->m_bin)!=0)
					continue;
			}
            if (id>=0)
            {
                if (pTmp->id == id)
                {
                    //inst_profile id specified, if matched return immediately
                    resultNum = 1;
                    break;
                }
                continue;
            }

			if (!firstMatch)
				firstMatch = &institutionProfileData[i];

			memset( &routingInfo, 0x00, sizeof(struct RoutingInfo) );
			strcpy(routingInfo.destNode, mbcurrentnode);
			strcpy(getRouteEntriesBinrouteGroup, pTmp->binrouteGroup);
			int noOfRoutes = binRouteObj->getRouteEntries(pTmp->m_bin, &routingInfo);
			int index;

			for (index=0; index < noOfRoutes; index++)
			{
				struct s_binroute *rte = binRouteObj->getRoute(index);
				if  (rte->status == BIN_ROUTE_STATUS_UP) 
				{
					profileResult[resultNum].p = pTmp;
					binRouteObj->useRoute(rte, &routingInfo, NULL);
					routingInfoSet = 1;
					resultNum++;
					break;
				}
			}
			if ( resultNum == 1 )
				break;
		}
	}
	if (resultNum <=0 )
	{
		if (firstMatch)
		{
			//No inst_profile with associated binroute was found, just use the first inst_profile
			networkInfo.putInstProfileEntry((InstitutionProfile *)firstMatch);
		}
		return;
	}

	networkInfo.putInstProfileEntry((InstitutionProfile *)pTmp);
	if (routingInfoSet)
		networkInfo.putRoutingInfo(&routingInfo);
	return;
}

int InstProfile::locateById(int id)
{
	resultNum = 0;
	int i;
	
	if(id <= 0)
		return -1;
		
	if (!initialized)
	{
		if (initialize() < 0)
			return -1;
	}
	if (setInstRuleParam() < 0)
		return -1;

//	if ( rm_waitForLockedShdMem(institutionProfileAppid) )
//	{
//		OTraceWarning("W-SHC-003002.1: rm.appid[%d] was locked. Go ahead\n", institutionProfileAppid);
//	}


	for (i = 0; i<institutionRuleKeyp->keysused; i++)
	{
		if (institutionProfileData[i].id != id)
			continue;

		profileResult[resultNum].p = &institutionProfileData[i];
		resultNum++;
		break;
	}
	if (resultNum <=0 )
		return -1;

	return i;
}

struct InstitutionProfileShm *InstProfile::getEntry(int i)
{
	char *p = (char *)institutionProfileData + institutionRuleKeyp->keysize*i;
	return (InstitutionProfileShm *)p;
}

int InstProfile::changeInstProfileStatus(int id, int status, char *broadcastStr)
{
	char tempbroadcastStr[16384]; //staticBroadcastStr[16384] defined in BinRoute.cxx
	int i = locateById(id);
	if (i <= 0)
	{
		OTraceDebug("D-SHC-003004: id(%d) not associated with inst_profile.\n");
		return 0;
	}
	if (institutionProfileData[i].status != status)
	{
	//	if ( rm_waitForLockedShdMem(institutionProfileAppid) )		// R022481
	//	{
	//		OTraceWarning("W-SHC-003005: rm.appid[%d] was locked. Go ahead\n", institutionProfileAppid);
	//	}	
		institutionProfileData[i].status = status;
		if (broadcastStr)
			snprintf(broadcastStr, sizeof(tempbroadcastStr)," -%0s -i %d", status==BIN_ROUTE_STATUS_UP?"up":"down", id);
	}
	return 0;	
}
int InstProfile::addAllBroadcastString(char *broadcastStr, size_t broadcastStr_size)
{
	int lastStatus = -1;
	if (!initialized)
	{
		if (initialize() < 0)
			return -1;
	}

	if (setInstRuleParam() < 0)
		return (-1);

//	if ( rm_waitForLockedShdMem(institutionProfileAppid) )
//	{
//		OTraceWarning("W-SHC-003009: rm.appid[%d] was locked. Go ahead\n", institutionProfileAppid);
//	}

	int i;
	for (i = 0; i<institutionRuleKeyp->keysused; i++)
	{
		if (institutionProfileData[i].id <= 0)
			continue;
		if (lastStatus != institutionProfileData[i].status)
		{
			lastStatus = institutionProfileData[i].status;
			istsafe_strcat(broadcastStr, broadcastStr_size, lastStatus == BIN_ROUTE_STATUS_UP?" -up ":" -down ");
		}

		sprintf(broadcastStr, "%s -i %1d", broadcastStr, institutionProfileData[i].id);
	}

	return i;
}
InstitutionProfile *InstProfile::chooseEntry(int routeRemoteSite)
{

	BinRouteForInstProfile binRouteIpObj;
	struct RoutingInfo routingBuf;
	int outbound = -1;

	binRouteIpObj.setInstProfiles( profileResult, resultNum );
        int ret = binRouteIpObj.chooseRouteByIPList( &routingBuf, &outbound, routeRemoteSite );
	if ( (ret >= 0) && (ret < resultNum) )
	{
		OTraceDebug( "D-SHC-003009 route found, return value is %d\n", ret );
		if (_shouldUpdateCounter)
			memcpy( &m_route, &routingBuf, sizeof(struct RoutingInfo) );
		m_route_set = true;
		return ((struct InstitutionProfile *)profileResult[ret].p);
	}
	else
	{
		OTraceDebug( "D-SHC-003009 no routes available, return value is [%d]\n", ret );
	}

	if ( resultNum > 0 )
	{
		OTraceDebug( "D-SHC-003010 no bin routes found, use first inst_profile entry\n" );
		return ((struct InstitutionProfile *)profileResult[0].p);
	}
	return NULL;
}

void InstProfile::locateIssuerFromNetwork(const char *txnSrc, const int msgType, const char *externalId, 
					const char *member_ID, const char *F_ID, IssuerInfo &issuerInfo)
{
	char msgTypeBuf[5];
	bin_t tmpTxnSrc;
	int findUp = instProfileFindUpBin;
	instProfileFindUpBin = 0;
	InstitutionProfile *firstDownBin = NULL;
        InstitutionProfile *reverseEntry = NULL;
	int i;
	char *p = NULL;
	InstitutionProfile *pTmp = NULL;
        memset(&routingRecord, 0, sizeof(struct routingpkg));
	
	if (msgType > 0)
		snprintf(msgTypeBuf, sizeof(msgTypeBuf), "%04.4d", msgType);
	else
		msgTypeBuf[0] = '\0';
	
	ICInstId_pure(tmpTxnSrc, (char *)txnSrc);

	issuerInfo.reset();

	if (!initialized)
	{
		if (initialize() < 0)
			return;
	}

	if (setInstRuleParam() < 0)
		return;

//	if ( rm_waitForLockedShdMem(institutionProfileAppid) )		// R022481
//	{
//		OTraceWarning("W-SHC-003002.2: rm.appid[%d] was locked. Go ahead\n", institutionProfileAppid);
//	}

	for (i=0, p = (char *)institutionProfileData; i <institutionRuleKeyp->keysused; i++, p+=institutionRuleKeyp->keysize)
	{
		pTmp = (InstitutionProfile *)p;
		if (Match(*pTmp, tmpTxnSrc, msgTypeBuf, externalId, 
										member_ID, F_ID))
		{
			if (findUp)
			{
				struct shcpkg *binpkg = NULL;
				shcApp->shcBinObj->shc_locate_bin(&binpkg, pTmp->m_bin);
				if (binpkg && (shc_isdown(binpkg)))
				{
					if (!firstDownBin)
						firstDownBin = pTmp;
					continue;
				}
			}

			issuerInfo.setIssuerBin(pTmp->m_bin);
			issuerInfo.setTxnDest(pTmp->m_txnDest);
			issuerInfo.setEntityId(pTmp->m_iss_entityId);
                        istsafe_strcpy(routingRecord.bin,sizeof(routingRecord.bin),pTmp->m_bin);
			return;
		}
                else if ((!reverseEntry) && (reverseMatch(pTmp, tmpTxnSrc, msgTypeBuf, externalId, member_ID, F_ID)))
                {
                        reverseEntry = pTmp;
                }
	}
	if ((i >= institutionRuleKeyp->keysused) && (firstDownBin))
	{
                //Didn't find an up bin, use the first found down bin
                        issuerInfo.setIssuerBin(firstDownBin->m_bin);
                        issuerInfo.setTxnDest(firstDownBin->m_txnDest);
                        issuerInfo.setEntityId(firstDownBin->m_iss_entityId);
                        istsafe_strcpy(routingRecord.bin,sizeof(routingRecord.bin),firstDownBin->m_bin);
        }
        else if (reverseEntry)
        {
                //Only found a match when reversed txnsrc and txndest, use it
                issuerInfo.setIssuerBin(reverseEntry->m_bin);
                issuerInfo.setTxnDest(reverseEntry->m_txnDest);
                issuerInfo.setEntityId(reverseEntry->m_iss_entityId);
                istsafe_strcpy(routingRecord.bin,sizeof(routingRecord.bin),reverseEntry->m_bin);
        }

	return;
}

void InstProfile::locateAcquirerNetworkInfo(const char *txnSrc, const int msgType, const char *externalId, 
					const char *member_ID, const char *F_ID, NetworkInfo &networkInfo)
{
	char msgTypeBuf[5];
	bin_t tmpTxnSrc;
	int findUp = instProfileFindUpBin;
	instProfileFindUpBin = 0;
	InstitutionProfile *firstDownBin = NULL;
	InstitutionProfile *reverseEntry = NULL;
	int i;
	char *p = NULL;
	InstitutionProfile *pTmp = NULL;


	
	if (msgType > 0)
		snprintf(msgTypeBuf, sizeof(msgTypeBuf), "%04.4d", msgType);
	else
		msgTypeBuf[0] = '\0';
	
	ICInstId_pure(tmpTxnSrc, (char *)txnSrc);

	networkInfo.reset();

	if (!initialized)
	{
		if (initialize() < 0)
			return;
	}
	if (setInstRuleParam() < 0)
		return;

//	if ( rm_waitForLockedShdMem(institutionProfileAppid) )		// R022481
//	{
//		OTraceWarning("W-SHC-003002.2: rm.appid[%d] was locked. Go ahead\n", institutionProfileAppid);
//	}

	for (i=0, p=(char *)institutionProfileData; i <institutionRuleKeyp->keysused; i++, p+=institutionRuleKeyp->keysize)
	{
		pTmp = (InstitutionProfile *)p;
		if (Match(*pTmp, tmpTxnSrc, msgTypeBuf, externalId, 
										member_ID, F_ID))
		{
			if (findUp)
			{
				struct shcpkg *binpkg = NULL;
				shcApp->shcBinObj->shc_locate_bin(&binpkg, pTmp->m_bin);
				if (binpkg && (shc_isdown(binpkg)))
				{
					if (!firstDownBin)
						firstDownBin = pTmp;
					continue;
				}
			}

			networkInfo.putInstProfileEntry(pTmp);
			return;
		}
                else if ((!reverseEntry) && (reverseMatch(pTmp, tmpTxnSrc, msgTypeBuf, externalId, member_ID, F_ID)))
                {
                        reverseEntry = pTmp;
                }
	}
	if ((i >= institutionRuleKeyp->keysused) && firstDownBin )
	{
                //Didn't find an up bin, use the first found down bin
                networkInfo.putInstProfileEntry(firstDownBin);
        }
        else if (reverseEntry)
        {
                //Only found a match when reversed txnsrc and txndest, use it
                networkInfo.putInstProfileEntry(reverseEntry);
        }

	return;
}

SHCDLLEXPORT void InstProfile::locateIssuerFromInstitution(const char *inst, const char *entityId, const int msgType, IssuerInfo &issuerInfo)
{
	char msgTypeBuf[5]={0};
	bin_t tmpTxnSrc;
	int findUp = instProfileFindUpBin;
	instProfileFindUpBin = 0;
	int firstDownBin = -1;
	int i;
        memset(&routingRecord, 0, sizeof(struct routingpkg));

	
	if (msgType > 0)
		snprintf(msgTypeBuf, sizeof(msgTypeBuf), "%04.4d", msgType);
	else
		msgTypeBuf[0] = '\0';
	
	ICInstId_pure(tmpTxnSrc, (char *)inst);

	issuerInfo.reset();

	if (!initialized)
	{
		if (initialize() < 0)
			return;
	}
	if (setInstRuleParam() < 0)
		return;

//	if ( rm_waitForLockedShdMem(institutionProfileAppid) )		// R022481
//	{
//		OTraceWarning("W-SHC-003002.3: rm.appid[%d] was locked. Go ahead\n", institutionProfileAppid);
//	}

	for (i=0; i <institutionRuleKeyp->keysused; i++)
	{
		if (Match(*(InstitutionProfile *)&institutionProfileData[i], tmpTxnSrc, entityId, msgTypeBuf))
		{
			if (findUp)
			{
				struct shcpkg *binpkg = NULL;
				shcApp->shcBinObj->shc_locate_bin(&binpkg, institutionProfileData[i].m_bin);
				if (binpkg && (shc_isdown(binpkg)))
				{
					if (firstDownBin < 0)
						firstDownBin = i;
					continue;
				}
			}
			issuerInfo.setIssuerBin(institutionProfileData[i].m_bin);
			issuerInfo.setTxnDest(institutionProfileData[i].m_txnDest);
			issuerInfo.setEntityId(institutionProfileData[i].m_iss_entityId);
                        istsafe_strcpy(routingRecord.bin,sizeof(routingRecord.bin),institutionProfileData[i].m_bin);
			return;
		}
	}
	if ((i >= institutionRuleKeyp->keysused) && (firstDownBin >= 0))
	{
		//Didn't find an up bin, use the first found down bin
			issuerInfo.setIssuerBin(institutionProfileData[firstDownBin].m_bin);
			issuerInfo.setTxnDest(institutionProfileData[firstDownBin].m_txnDest);
			issuerInfo.setEntityId(institutionProfileData[firstDownBin].m_iss_entityId);
                        istsafe_strcpy(routingRecord.bin,sizeof(routingRecord.bin),institutionProfileData[firstDownBin].m_bin);
	}		

	return;
}

/* Updates for shccmd support at txnsrc -> txndst commands */



void InstProfile::print(int i, struct InstitutionProfile *InstProf)
{
	char instId[11];
	char userBinId[11];


	shc_internalBin2ExternalBin(instId, userBinId, InstProf->m_bin);

	printf ("[%03d] TxnSrc %-10s   TxnDest %-10s EntityID %-10s MsgType %-40s\n",
				i,
				InstProf->m_txnSrc,
				InstProf->m_txnDest,
				InstProf->m_iss_entityId[0]?InstProf->m_iss_entityId:"*",
				InstProf->m_msgType[0]?InstProf->m_msgType:"*");

	printf ("      ExtId              ExtDesc    MemberID   ForwardID Inst              Bin\n");
	printf ("%11s %20s %11s %11s %-10s %10s\n",
					InstProf->m_externalId[0]?InstProf->m_externalId:"*",
					InstProf->m_externalIdDesc[0]?InstProf->m_externalIdDesc:"*",
					InstProf->m_member_ID[0]?InstProf->m_member_ID:"*",
					InstProf->m_F_ID[0]?InstProf->m_F_ID:"*",
					instId, userBinId);
        printf ("keyoffset   keyparam     id group_name        status\n");
        printf ("%9d %10s %6d %-18s%6s\n\n",InstProf->keyparm,
                        InstProf->keyparamStr, InstProf->id, InstProf->binrouteGroup[0]?InstProf->binrouteGroup:"------",
			InstProf->status == BIN_ROUTE_STATUS_UP?"UP":"DOWN");


}


int InstProfile::pauseDisplay(int i)
{

   	char buf [10];

	if (!instProfNeedPause)
		return 1;
	if ( i % 5 == 0)
	{
  		printf("More (Y/N): "); fflush(stdout);
  		fgets(buf, sizeof(buf), stdin);
    	if(buf[0] != 'Y' && buf[0] != 'y')
			return(0);
    }
	return (1);
}


void InstProfile::display(char *txnSrc, char *txnDest)
{
    int count = 0;

	if (!initialized)
	{
		if (initialize() < 0)
			return;
	}

	if (setInstRuleParam() < 0)
			return;

//	if ( rm_waitForLockedShdMem(institutionProfileAppid) )		// R022481
//	{
//		OTraceWarning("W-SHC-003002.4: rm.appid[%d] was locked. Go ahead\n", institutionProfileAppid);
//	}

	InstitutionProfile *pTmp = NULL;
	char *p = NULL;
	int i;

	if (txnSrc == NULL && txnDest == NULL) // Print All entries
	{
		for (int i=0; i <institutionRuleKeyp->keysused; i++)
		{
			print(i, (struct InstitutionProfile *)&institutionProfileData[i]);
			count++;
			if (pauseDisplay(count) == 0)
				break;	
		}
	}
	else if (txnDest == NULL)  // Prints all entries for given txnsrc
	{
		for (i=0, p=(char *)institutionProfileData; i <institutionRuleKeyp->keysused; i++, p+=institutionRuleKeyp->keysize)
		{
			pTmp = (InstitutionProfile *)p;
			if (strcmp (pTmp->m_txnSrc, txnSrc) == 0)
			{
				print(i, pTmp);
				count++;
				if (pauseDisplay(count) == 0)
					break;	
			}
		}
	} 
	else
	{
		for (i=0, p=(char *)institutionProfileData; i <institutionRuleKeyp->keysused; i++, p+=institutionRuleKeyp->keysize)
		{
			pTmp = (InstitutionProfile *)p;
			if (strcmp(pTmp->m_txnSrc, txnSrc) == 0 &&
				strcmp(pTmp->m_txnDest, txnDest) == 0)
			{
				print(i, pTmp);
				count++;
				if (pauseDisplay(count) == 0)
					break;	
			}
		}
	}
}


int InstProfile::MatchNetMsg (const struct InstitutionProfile &ip,
									  char *txnSrc, char *txnDest, char *iss_entityId)
{
	if (((!ip.m_txnSrc[0]) || ((!txnSrc || strcmp(ip.m_txnSrc, (char *)txnSrc) == 0) ))&&
	    ((!ip.m_txnDest[0]) || (!txnDest || strcmp((char *)ip.m_txnDest, (char *)txnDest) == 0)) &&
		((!ip.m_iss_entityId[0]) || (!iss_entityId || strcmp((char *)ip.m_iss_entityId, iss_entityId) == 0)) &&
		 (!ip.m_msgType[0] || (ist_regexpcv((char *)ip.m_msgType, (char *)"0800", 0))))
	{
   		return 1;
	}
	else
	{
		return 0;
	}
}

int InstProfile::addInstProfile(InstProfileList &ipList, const struct InstitutionProfile &ip)
{

	for (int x = 0; x < ipList.size(); x++)
	{
		if (strcmp(ipList[x].getBin(), ip.m_bin) == 0)
		{
			return (0);
		}
	}
	ipList.push_back(ip);
	return (1);
}

int InstProfile::getInstProfileList(const char *txnSrc, 
									const char *txnDst, 
									const char *iss_entityId,
									InstProfileList &ipList,
									InstProfileList &groupList)
{

	int found = 0;
	char *tmptxnSrc = NULL;
	char *tmptxnDest = NULL;
	char *tmpissEnt = NULL;


	if (txnSrc && (txnSrc[0] != '\0'))
		tmptxnSrc = (char *)txnSrc;

	if (txnDst && (txnDst[0] != '\0'))
		tmptxnDest = (char *)txnDst;

	if (iss_entityId && (iss_entityId[0] != '\0'))
		tmpissEnt = (char *)iss_entityId;


   	if (!initialized)
   	{
		if (initialize() < 0)
		   return(0);
   	}
	if (setInstRuleParam() < 0)
			return (0);

//	if ( rm_waitForLockedShdMem(institutionProfileAppid) )		// R022481
//	{
//		OTraceWarning("W-SHC-003002.5: rm.appid[%d] was locked. Go ahead\n", institutionProfileAppid);
//	}

   	for (int i=0; i <institutionRuleKeyp->keysused; i++)
   	{
	  	if (MatchNetMsg (*(InstitutionProfile *)&institutionProfileData[i],
										  tmptxnSrc, tmptxnDest, tmpissEnt))
		{ 
			if (stricmp(institutionProfileData[i].m_externalIdDesc, "ICA") == 0 ||
				stricmp(institutionProfileData[i].m_externalIdDesc, "ICA                 ") == 0)
			{
				addInstProfile (groupList, *(InstitutionProfile *)&institutionProfileData[i]);
				found = 1;
			}
			else if (stricmp(institutionProfileData[i].m_externalIdDesc, "PREFIX") != 0 &&
					stricmp(institutionProfileData[i].m_externalIdDesc, "PREFIX              ") != 0)
			{
				addInstProfile (ipList, *(InstitutionProfile *)&institutionProfileData[i]);
				found = 1;
			}

		}
	}
	return (found);
}


int InstProfile::getInstProfileList (const char *txnSrc, 
									 const char *txnDst, 
									 const char *iss_entityId,
									 InstProfileList &ipList,
									 char *bin)

{

	int found = 0;
	char *tmptxnSrc = NULL;
	char *tmptxnDest = NULL;
	char *tmpissEnt = NULL;


	if (txnSrc && (txnSrc[0] != '\0'))
		tmptxnSrc = (char *)txnSrc;

	if (txnDst && (txnDst[0] != '\0'))
		tmptxnDest = (char *)txnDst;

	if (iss_entityId && (iss_entityId[0] != '\0'))
		tmpissEnt = (char *)iss_entityId;

   	if (!initialized)
   	{
		if (initialize() < 0)
		   return(0);
   	}
	if (setInstRuleParam() < 0)
			return (0);

//	if ( rm_waitForLockedShdMem(institutionProfileAppid) )		// R022481
//	{
//		OTraceWarning("W-SHC-003002.6: rm.appid[%d] was locked. Go ahead\n", institutionProfileAppid);
//	}


   	for (int i=0; i <institutionRuleKeyp->keysused; i++)
   	{
	  	if (MatchNetMsg (*(InstitutionProfile *)&institutionProfileData[i],
										  tmptxnSrc, tmptxnDest, tmpissEnt))
		{
			if (bin)
			{
				if (strcmp(bin, institutionProfileData[i].m_bin)!=0)
					continue;	//When bin is specified, bin must match
			}
			addInstProfile (ipList, *(InstitutionProfile *)&institutionProfileData[i]);
			found = 1;;
		}
	}
	return (found);
}



// >>> R029583
int InstProfile::setInstRuleParam()
{
	static int appid = -1;
	if (appid == -1)
	{
		if(rm_init() < 0)
		{
			OTraceFatal("F-SHC-003011: Unable to connect to Rule manager\n");
			return(-1);
		}

		if((appid = rm_getappid("inst_profile")) == -1)
		{
			OTraceFatal("F-SHC-003012:unable to locate message name: inst-business-day\n");
			return(-1);
		}
	}
	
	if ( rm_attach( appid, RULES_VER_CURRENT) != 0)
	{
		OTraceError("E-SHC-003013: Unable to attach to CURRENT version \n");
		return(-1);
	}
	institutionRuleKeyp = rm_getapphead(appid);
	/*      Find the first entry of my key table */
	institutionProfileData = (struct InstitutionProfileShm *)rm_getappkey(appid);
	institutionProfileAppid   = appid;
	return 0;
}
// <<< R029583

struct InstitutionProfile *InstProfile::locateByBinroute(struct s_binroute *pBinRoute)
{
        resultNum = 0;
        int i;

        if (!initialized)
        {
                if (initialize() < 0)
                        return NULL;
        }
        if (setInstRuleParam() < 0)
                return NULL;

        struct InstitutionProfile *pTmp = NULL;
        char *p = NULL;
        for (i = 0, p =(char *)institutionProfileData; i<institutionRuleKeyp->keysused; i++, p+=institutionRuleKeyp->keysize)
        {
                pTmp = (struct InstitutionProfile *)p;
                if (    (strcmp(pTmp->binrouteGroup, pBinRoute->binrouteGroup)!= 0) ||
                                (strcmp(pTmp->m_bin, pBinRoute->internalid)!=0))
                        continue;

                return  pTmp;
        }
        return NULL;
}

