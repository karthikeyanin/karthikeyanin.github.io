/*
 *  Copyright (C) 2004 eFunds Corporation ("eFunds").  All Rights Reserved.     
 *  eFunds Canada Corporation is an authorized user.                            
 *                                                                              
 *  IST is a registered trademark of eFunds Corporation.  Other brand or        
 *  product names are trademarks or registered trademarks of their respective   
 *  holders.                                                                    
 *                                                                              
 *  The information contained herein is the unpublished proprietary property    
 *  of eFunds.  Except as specifically authorized in writing by eFunds, the     
 *  holder of this document shall: i) keep all information contained herein     
 *  confidential, and ii) protect the information, in whole or in part, from    
 *  disclosure and dissemination to all third parties.                          
 *                                                                          
 *  This document and the software described in it are furnished under license  
 *  and may be used or copied only in accordance with the terms of such license.
 *  This document is supplied for information purposes only, is subject to      
 *  change without notice, and should not be construed as a commitment by       
 *  either eFunds Corporation or eFunds Canada Corporation. 
 */

// "@(#) ShcBillToAddress.cxx 1.0.0.0 02/04/21 21:07:36"

/*----------------------------------------------------------------------------*
 *                                                                            *
 * File:				
 * Description:	
 * Notes:
 *
 * Modification History:
 * YYMMDD SCR#    WHO	Description
 * ------ ------- ---	------------------------------------------------------*
 * 210402 R000000 basker Created.
 *----------------------------------------------------------------------------*/

/* File Number 20 */

#if defined(WIN32)
#	define ShcBillToAddress_h_export_directive	__declspec(dllexport)
#else
#	define ShcBillToAddress_h_export_directive
#endif

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <ctype.h>
#include <errno.h>
#include <oasis.h>
#include <ist_otrace.h>
#include <ShcBillToAddress.h>
#include <ccMapTable.h>
#include <shcseg.h>
#include <shc.h>
#include <ist_seg_name.h>
#include <ist_seg_id.h>
#include <ist_seg_elf_id_map.h>
#include <ShcmsgHeader.h>

#include <HaPtmCctHelper.h>
#include <istsafe.h>

int ShcBillToAddress::nameLen = 30;
int ShcBillToAddress::lastnameLen = 30;
int ShcBillToAddress::cityLen = 20;
int ShcBillToAddress::stateLen = 2;
int ShcBillToAddress::countryLen = 2;
int ShcBillToAddress::address1Len = 30;
int ShcBillToAddress::address2Len = 28;
int ShcBillToAddress::postalLen = 10;
int ShcBillToAddress::initialized = 0;
unsigned short ShcBillToAddress::mySegmentId = 0;

const char *ShcBillToAddress::getName()
{
	return (const char *)SHC_ShcBillToAddress;
}


ShcBillToAddress::ShcBillToAddress()
{
	if (!initialized)
		initialize();
		
	resetData();
	
	memset(name, ' ', nameLen);
	name[nameLen] = '\0';
	memset(lastname, ' ',lastnameLen);
	lastname[lastnameLen] = '\0';
	memset(city, ' ', cityLen);
	city[cityLen] = '\0';
	if (stateLen > 0)
	{
		memset(state, ' ', stateLen);
		state[stateLen] = '\0';
	}
	else
		state[0]='\0';
}

void ShcBillToAddress::loadBillToAddress(char *billtoaddress)
{
	char buf[100]={0};
	char *p = buf;
	strncpy( buf, billtoaddress, sizeof(buf)-1 );
	
	if (!initialized)
		initialize();
	
	resetData();
	
	p[40] = '\0';
	for (register int i=0; i<40;i++)
		if (!p[i])
			p[i]= ' ';
	if (nameLen>0)
	{
		memcpy(name, p, nameLen);
		name[nameLen] = '\0';
		p += nameLen;
		setNameSeg( name );
	}
	
	if (cityLen>0)
	{
		memcpy(city, p, cityLen);
		city[cityLen] = '\0';
		p += cityLen;
		setCitySeg( city );
	}
	
	if (stateLen>0)
	{
		memcpy(state, p, stateLen);
		state[stateLen] = '\0';
		p += stateLen;
		setStateSeg( state );
	}
	else
		state[0] = '\0';

        if (countryLen==2)
        {
                memcpy(CountryCode, p, 2);
                CountryCode[2] = '\0';
                p += countryLen;
                setCountrySeg( CountryCode );
        }
}

void ShcBillToAddress::initialize(void)
{
	char buf[200];
	int tmpNameLen, tmpCityLen, tmpStateLen, tmpCountryLen, sum; 

	HaPtmCctHelper::addHandler( "system.dcs.shc" ) ;

	if (cf_open(u_constructfile("files/shc.cfg")) >= 0)
	{
		if ( cf_locate("shc.bill_to_address_name_length",buf) > 0)
			tmpNameLen = atoi(buf);
		else
			tmpNameLen = nameLen;

		if ( cf_locate("shc.bill_to_address_city_length",buf) > 0)
			tmpCityLen = atoi(buf);
		else
			tmpCityLen = cityLen;

		if ( cf_locate("shc.bill_to_address_state_length",buf) > 0)
			tmpStateLen = atoi(buf);
		else
			tmpStateLen = stateLen;

		if ( cf_locate("shc.bill_to_address_country_length",buf) > 0)
			tmpCountryLen = atoi(buf);
		else
			tmpCountryLen = countryLen;

		sum = tmpNameLen+tmpCityLen+tmpStateLen+tmpCountryLen; 

		if ((sum != 54) || (tmpNameLen >30) || (tmpCityLen > 20) || (tmpStateLen > 2) || (tmpCountryLen > 2))
		{
			OTraceError("E-SHC-020001:Lengthes of bill to address fields[%d %d %d %d] not valid. Default value [%d %d %d %d] is used.",
				tmpNameLen, tmpCityLen, tmpStateLen, tmpCountryLen, nameLen, cityLen, stateLen, countryLen);
		}
		else
		{
			nameLen = tmpNameLen;
			cityLen = tmpCityLen;
			stateLen = tmpStateLen; 
			countryLen = tmpCountryLen;
		}
			
		cf_close();
	}
	
	setLayoutDef( "SHC", nameLen, cityLen, stateLen, countryLen);
	
	mySegmentId = ElfIdMap::elf_to_id(IST_SEG_NETWORK_SETTLEMENT_DATA);

	OTraceDebug("D-SHC-020002:bill to address len:name:(%d),city(%d),state(%d), countrycode(%d).\n",
              nameLen, cityLen, stateLen, countryLen);
	initialized = 1;
}

static int shcfmt_btoaflds[4];

int * ShcBillToAddress::getBillToAddressFieldsLength()
{
	shcfmt_btoaflds[0] = nameLen;
	shcfmt_btoaflds[1] = cityLen;
	shcfmt_btoaflds[2] = stateLen;
	shcfmt_btoaflds[3] = countryLen;
	
    return shcfmt_btoaflds;
}

void ShcBillToAddress::getBillToAddress(char * billtoaddressBuf)
{
	char tempBillToAddressBuf[SHC_BILLTO_LEN];// length of billtoaddress[] defined in shcimf.h
	int len = 0;

	istsafe_strcpy(billtoaddressBuf, sizeof(tempBillToAddressBuf),name);
	len = istsafe_strlen(billtoaddressBuf, sizeof(tempBillToAddressBuf));

	istsafe_strcat(billtoaddressBuf,sizeof(tempBillToAddressBuf), city);
        len = istsafe_strlen(billtoaddressBuf, sizeof(tempBillToAddressBuf));

	if (stateLen > 0)
	{	
		istsafe_strcat(billtoaddressBuf,sizeof(tempBillToAddressBuf), state);
	}
	return;
}


void ShcBillToAddress::setLastName(const char *newLastName)
{
	int len;
	
	setLastNameSeg( newLastName );
	
	memset(lastname, ' ', lastnameLen);
	if (strlen(newLastName)>lastnameLen)
		len=lastnameLen;
	else
		len=strlen(newLastName);
	memcpy(lastname, newLastName, len);
	lastname[lastnameLen] = '\0';
	return;
}

void ShcBillToAddress::setPhoneType(const char *phonetypeBuf)
{
	setPhoneTypeSeg( phonetypeBuf );
	return;
}

////////////////////////////////////////////////////////////////////////////////
// Enhance to support segment BILL_TO_ADDRESS
////////////////////////////////////////////////////////////////////////////////


void ShcBillToAddress::resetData()
{
	memset( nameSeg,    0, sizeof(nameSeg) );
	memset( lastnameSeg,    0, sizeof(lastnameSeg) );
	memset( citySeg,    0, sizeof(citySeg) );
	memset( stateSeg,   0, sizeof(stateSeg) );
	memset( countrySeg, 0, sizeof(countrySeg) );
	memset( postalSeg,  0, sizeof(postalSeg) );
	memset( phoneSeg,   0, sizeof(phoneSeg) );
	memset( addressSeg, 0, sizeof(addressSeg) );
	memset( address1Seg, 0, sizeof(address1Seg) );
	memset( address2Seg, 0, sizeof(address2Seg) );
	memset( phonetypeSeg, 0, sizeof(phonetypeSeg) );
    memset( emailSeg, 0, sizeof(emailSeg) );

	memset( segBuffer, 0, sizeof(segBuffer) );
	memset( outputBuffer, 0, sizeof(outputBuffer) );
	memset( (char*)&acceptorLayout, 0, sizeof(ACCEPTORNAME_LAYOUT) );

	return;
}
	
char *ShcBillToAddress::getBillToAddressFromSegment( const char *segData, int segLen, const char *network )
{
	if ( parseSegBillToAddress(segData, segLen) < 0 )
	{
		strcpy( outputBuffer, "Unable to parse BillToAddress from segmnt" );
		return outputBuffer;
	}
	
	return outputBillToAddress( network );
}
	

int ShcBillToAddress::parseSegBillToAddress( const char *segDataIn, int segLen )
{
	char segData[sizeof(segBuffer)]={0};
	memset(segData, 0x00, sizeof(segData));
	segLen = segLen<sizeof(segBuffer) ? segLen : sizeof(segBuffer);
	memcpy( segData, segDataIn, segLen );
	const char *ptr = segData;
	
	resetData();

	int i=0;
	char *p;
	while(segData[i]=='|')
		i++;
	for (p=strtok(segData, "|"); i<11; i++)
	{
		if (p==NULL)
			break;
		if (p[0])
			switch(i)
			{
			case 0:
				istsafe_strcpy(nameSeg, sizeof(nameSeg), p);
				break;
			case 1:
				istsafe_strcpy(lastnameSeg, sizeof(lastnameSeg), p);
				break;
			case 2:
				istsafe_strcpy(citySeg, sizeof(citySeg), p);
				break;
			case 3:
				istsafe_strcpy(stateSeg, sizeof(stateSeg), p);
				break;
			case 4:
				istsafe_strcpy(countrySeg, sizeof(countrySeg), p);
				break;
			case 5:
				istsafe_strcpy(address1Seg, sizeof(address1Seg), p);
				break;
			case 6:
				istsafe_strcpy(address2Seg, sizeof(address2Seg), p);
				break;
			case 7:
				istsafe_strcpy(postalSeg, sizeof(postalSeg), p);
				break;
			case 8:
				istsafe_strcpy(phoneSeg, sizeof(phoneSeg), p);
				break;
			case 9:
				istsafe_strcpy(phonetypeSeg, sizeof(phonetypeSeg), p);
				break;
			case 10:
				istsafe_strcpy(emailSeg, sizeof(emailSeg), p);
				break;
			default:
				OTraceError("W-SHC-020003: billToAddress(%s) has too many fields, extra fields ignored.\n", segDataIn);
			}

		p+=strlen(p)+1;
		if (*p == '|')
			*p = '\0';
		else
			p=strtok(p, "|");
	}	
	return 0;
}


char *ShcBillToAddress::outputBillToAddress( const char *network )
{
	if ( ! isDataReady() )
	{
		OTraceError("E-SHC-020005: data not ready yet in getBillToAddress(%s)\n", network);
		sprintf( outputBuffer, "%.4s data not ready yet                 ", network );
		return outputBuffer;
	}
	
	ACCEPTORNAME_LAYOUT *myLayout = getLayoutDef( network );
	memset( outputBuffer, 0, sizeof(outputBuffer) );
	char *ptr=outputBuffer;
	
	ptr += formatIt( ptr, nameSeg, myLayout->lenName );
	ptr += formatIt( ptr, citySeg, myLayout->lenCity );
	ptr += formatIt( ptr, stateSeg, myLayout->lenState );
	ptr += formatIt( ptr, countrySeg, myLayout->lenCountry%10 );
	
	const char *pCC = NULL;
	if ( myLayout->lenCountry == 2 )
	{
		pCC = getCountryChar2();
	}
	else if ( myLayout->lenCountry == 3 )
	{
		pCC = getCountryChar3();
	}
	else if ( myLayout->lenCountry == 13 )	// 3 char in digits
	{
		pCC = getCountryChar3Digits();
	}
	
	if ( ! pCC )
	{
		
		ptr += formatIt( ptr, (char*)pCC, myLayout->lenCountry%10 );
	}
	
	*ptr = '\0';
	
	OTraceError( "D-SHC-020006: Acceptor name for [%s]='%s'\n", network, outputBuffer );
	
	return outputBuffer;
}


char *ShcBillToAddress::generateSegmentData(const char *aName, const char *aCity, const char *aState, const char *aCountry)
{
	setBillToAddress( aName, aCity, aState, aCountry );

	return generateSegmentData();
}


char *ShcBillToAddress::generateSegmentData()
{
	memset( segBuffer, 0, sizeof(segBuffer) );
/*	
	if ( ! isDataReady() )
	{
		return segBuffer;
	}
*/		
	snprintf( segBuffer, sizeof(segBuffer), "%-s|%-s|%-s|%-s|%-s|%-s|%-s|%-s|%-s|%-s|%-s", nameSeg, lastnameSeg, citySeg, stateSeg, countrySeg,
					address1Seg, address2Seg, postalSeg, phoneSeg, phonetypeSeg, emailSeg);

	segBuffer[sizeof(segBuffer)-1] = '\0';
	
	OTraceDebug("D-SHC-020011: generateSegmentData()=[%d][%s]\n", strlen(segBuffer), segBuffer );
	
	return segBuffer;
}


void ShcBillToAddress::setBillToAddress(const char *aName, const char *aCity, const char *aState, const char *aCountry)
{
	setName( aName );
	setCityName( aCity );
	setStateName( aState );
	setCountryCode( aCountry );
	return;
}

char *ShcBillToAddress::getAddress1Seg()
{
	strtrim(address1Seg, address1Seg);
	return address1Seg;
}

char *ShcBillToAddress::getAddress2Seg()
{
	strtrim(address2Seg, address2Seg);
	return address2Seg;
}

int ShcBillToAddress::saveSegment( ShcmsgHeader *hdr )
{
	if ( ! isDataReady() )
	{
		OTraceError("E-SHC-: Bill to Address segment data not ready\n");
		return -1;
	}
	
	char *segData = generateSegmentData();
	
// append segment here !!!

	hdr->setSegmentData(segData, strlen(segData)+1, mySegmentId, BILL_TO_ADDRESS);
	
	OTraceDebug( "D-SHC-: saveSegment segid[%d] subid[%d] '%s'\n", mySegmentId, BILL_TO_ADDRESS, segData );

	return 0;
}


int ShcBillToAddress::loadSegment( ShcmsgHeader *hdr )
{
	int  segLen=sizeof(segBuffer);
// get BILL_TO_ADDRESS segment data here !!!
	hdr->getSegmentData(segBuffer, &segLen, mySegmentId, BILL_TO_ADDRESS);
	OTraceDebug( "D-SHC-: loadSegment segid[%d] subid[%d] [%d]'%s'\n", mySegmentId, BILL_TO_ADDRESS, segLen, segBuffer );
	
// found segment 
	if ( segLen > 0 )
	{
		return parseSegBillToAddress( segBuffer, segLen );
	}
	else
		OTraceDebug( "D-SHC-: Bill to Address segment data not available \n");	
	
	return 0;
}

