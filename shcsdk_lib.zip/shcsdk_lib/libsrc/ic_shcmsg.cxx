static char ver[]="IST:: r1.00.00 ddmmmyy";
/*
 *  Copyright (C) 2004 eFunds Corporation ("eFunds").  All Rights Reserved.     
 *  eFunds Canada Corporation is an authorized user.                            
 *                                                                              
 *  IST is a registered trademark of eFunds Corporation.  Other brand or        
 *  product names are trademarks or registered trademarks of their respective   
 *  holders.                                                                    
 *                                                                              
 *  The information contained herein is the unpublished proprietary property    
 *  of eFunds.  Except as specifically authorized in writing by eFunds, the     
 *  holder of this document shall: i) keep all information contained herein     
 *  confidential, and ii) protect the information, in whole or in part, from    
 *  disclosure and dissemination to all third parties.                          
 *                                                                          
 *  This document and the software described in it are furnished under license  
 *  and may be used or copied only in accordance with the terms of such license.
 *  This document is supplied for information purposes only, is subject to      
 *  change without notice, and should not be construed as a commitment by       
 *  either eFunds Corporation or eFunds Canada Corporation. 
 */
/*
#pragma ident "@(#) ic_shcmsg.cxx 1.16 20/02/12 12:34:20"
 *
 *                        MODIFICATION HISTORY                  REVIEW
 *
 *	SPR#	Who	Date	Description			Who	Date   
 * ===========================================================================
 *  R001835 qd  16feb99 Remove hard code values
 *  R004058 fg  02Mar00 Remove platform dependent directory for shcmsg.map
 *  R006365 rzhou 07Aug01 Add a new type check of shcmsg.map for DUKPT support 
 *  R008996 jyang 11Mar03 Compare fields correctly
 *  R019859 jyang 04May07 make fields mark under control	
 *  R022022 sks	 20Nov07 Some changes in ic_shcmsg.cxx for ITMX. 
 *	R023121 Ram	14May08 Pan not masked in shcdump.debug for the first time
 *  R027170 Dipa  01Sep09 PA-DSS changes - tokenization of PAN in where clause done
 */

//File Number 2
#if defined( WIN32 )
#       define SHCDLLEXPORT __declspec(dllexport)
#else
#       define SHCDLLEXPORT
#endif


#include "stdlib.h"
#include "stdio.h"
#include "string.h"

#include <ic/ic_shcmsg.h>
#include <oasis.h>
#include <ist_otrace.h>
#include <debug.h>
#include <oasisenv.h>
#include <dbm.h>
#include <ShcAppBase.h>
#include <ShcHelper.h>
#include <tokenizer.h>   //R027170
#include <ist_check.h>

/* 
 * Note: Each enumerated value if Ist3Type_t represents an ist3 type.
 * Changing the enumerated value requires changing  $ISTDIR/files/$A/ *.map
 * Failure to keep the 2 files in sync will lead to incorrect translation
 * from elf to C struct and vice versa.
 */
typedef enum {
	Char 			= 1, /* single chars and null terminated strings */
	UnsignedChar	= 2, /* binary data buffers */
	Short			= 11,
	UnsignedShort	= 15,		
	Int				= 10,			
	UnsignedInt		= 14,
	Long			= 12,			
	UnsignedLong	= 16,
	Float			= 7,
	Double			= 18,
	Dec_t			= 9,
	Bin_t			= 3,    
	Amount_t		= 8,
	Date_t			= 13,  
	Seckey_t		= 17,
	Secdukpt_t		= 19,  /* R006365 */
	shouldmask		= 200,
	confidential	= 201
} SHC_TYPEE;

typedef struct _shcmsgelm
{
	char			name[64];
	int				offset;
	size_t			length;
	SHC_TYPEE		type;
    ICReturn		status;
} SHCMSGELM;


static SHCMSGELM ShcMsgTbl[ICSHCMSG_NFLDS] = {0};


/*----------------------------------------------------------------------*/
/* Private Functions */

#define setBit(b, i, v)	(*b[i] = v)
#define tstBit(b, i, v)	(*b[i] == v)

#define getOff(i)	(ShcMsgTbl[i].offset)
#define getLen(i)	(ShcMsgTbl[i].length)
#define getName(i)	(ShcMsgTbl[i].name)
#define getType(i)	(ShcMsgTbl[i].type)

//	---	R022022
///* R001835 move to local
static char	xbuf[16385] = {0};
static char	ybuf[16385] = {0};
//	---	R022022
//*/

static int cmpFld( char *s1, char *s2, int len )
{
	return( stricmp(s1, s2) );	// R008996
}


static int parseFld( char *srcp, char *dstp, int *lenp,
						char tokenl, char tokenr )
{
	char	*dp = NULL;

	if( ! srcp )
		return( -1 );

	if( lenp )
		*lenp = 0;

	if( tokenl != CHAR_NULL && *srcp != tokenl )
		return( -1 );

	srcp++;
	
	for( dp = dstp; *srcp != CHAR_NULL && *srcp != tokenr; *dp++ = *srcp++ )
		;

	*dp = CHAR_NULL;

	if( lenp )
		*lenp = (int)(dp - dstp);

	return( 0 );
}
int ICShcmsg_getId_idx( char *id )
{
	int		idx;


	if( ICShcmsg_shcmsg() < 0 || ! id )
		return( -1 );

	for( idx = 0; idx < ICSHCMSG_NFLDS ; idx++ )
	{
		if( cmpFld(ShcMsgTbl[idx].name, id, strlen(ShcMsgTbl[idx].name)) == 0 )
		{
			return( idx );
		}
	}

	return( -1 );
}
static SHCMSGELM *elm_get_ptr( char *id )
{
	int		idx;

	if( (idx = ICShcmsg_getId_idx(id)) < 0 )
	{
		return( NULL );
	}

	return( &ShcMsgTbl[idx] );
}


/*----------------------------------------------------------------------*/
/* Public Functions */

ICReturn ICShcmsg_shcmsg( void )
{
	static int			shcmsg_init = -1;

	if( shcmsg_init == 1 )
		return( 0 );
	else
	{

	SHCMSGELM			*elmp = NULL;
	FILE				*fd = NULL;
	char				*bp = NULL;
	char    			filepath[512]; /* R001835 */
	char				xbuf[16385] = {0}; /* R001835 */
	char fname[1024] = {0};

	elmp = &ShcMsgTbl[0];

	/* R001835 Start */
	/* R004058 no platform dependency */	
   	sprintf(filepath, "files/shcmsg.map"); 

	/* R001835 End */

	/* Read SHCMSG map */
	if( ! (fd = istcheck_val_fopen(uenv_constructfile_r(ISTDIR_ENV, filepath, fname, sizeof(fname)), "r")) )
	{
		OTraceError("E-SHC-002001: Can NOT find file [%s]\n", uenv_constructfile_r(ISTDIR_ENV, filepath, fname, sizeof(fname)));
		return( -1 );
	}

	while( fgets(xbuf, sizeof(xbuf) - 1, fd) )
	{
		if( xbuf[0] == '#' || strncmp("root_name", xbuf, 9) == 0 )
			continue;
	
		if( (bp = strtok(xbuf, " \t\n")) )
			snprintf(elmp->name, sizeof(elmp->name), "%s", bp);

		if( (bp = strtok(NULL, " \t\n")) )
			elmp->offset = atoi(bp);

		if( (bp = strtok(NULL, " \t\n")) )
			elmp->length = atoi(bp);

		if( (bp = strtok(NULL, " \t\n")) )
			elmp->type = (SHC_TYPEE) atoi(bp);	// R005156
// R005156			elmp->type = atoi(bp);

		elmp++;
	}

	fclose(fd);

	shcmsg_init = 1;
	}
	return( 0 );

}

ICReturn ICShcmsg_putFld( struct shcmsg* shcmsgp, char *id, char* data )
{
	SHCMSGELM	*elmp = NULL;
	char		*sp = NULL;

	if( ! shcmsgp || ! id || ! data || ! (elmp = elm_get_ptr(id)) )
		return( -1 );

	sp = (char *)shcmsgp;

	switch( elmp->type )
	{
		case Short:
		case UnsignedShort:
			*((short*)(sp+elmp->offset)) = (short)atoi(data);
			break;

		case Int:
		case UnsignedInt:
		case Date_t:
			*((int*)(sp+elmp->offset)) = atoi(data);
			break;

		case Long:
		case UnsignedLong:
			*((long*)(sp+elmp->offset)) = atol(data);
			break;

		case Float:
			*((float*)(sp+elmp->offset)) = (float)atof(data);
			break;

		case Double:
			*((double*)(sp+elmp->offset)) = atof(data);
			break;

		case Dec_t:
		case Amount_t:
			dbm_chartodec( (dec_t*)(sp+elmp->offset), data,
				strchr(data, (int)'.') == NULL ? 2 : 0);
			break;

		case Seckey_t:
			/* is type struct { char key[16]; char chk[4]; } */
			memcpy(sp+elmp->offset, data, elmp->length);
			break;

		/* R006365 >> */
		case Secdukpt_t:
		/* is type struct { char KSNdesc[4]; char KSN[21]; } */
			memcpy(sp+elmp->offset, data, elmp->length);
			break;
		/* << R006365 */

		case UnsignedChar:
			memcpy(sp+elmp->offset, data, elmp->length);
			break;

		case confidential:
		case shouldmask:
		case Char:
		case Bin_t:
			memcpy(sp+elmp->offset, data, elmp->length);
			break;
			

		default:
			return( -1 );
	}

	return( elmp->length );
}

/*
	This function will convert structure field to string 
*/
ICReturn ICShcmsg_getFld( ICSHCMSGp shcmsgp, char *id, char *dstp, int *dlen )
{
	return ICShcmsg_getFld(shcmsgp, id, dstp, dlen, 0);	// R019859 - no mask
}

ICReturn ICShcmsg_getFld( ICSHCMSGp shcmsgp, char *id, char *dstp, int *dlen, int needMask ) // R019859
{
	SHCMSGELM	*elmp = NULL;
	char		*sp = NULL;
	int			x = 0;
	//	>>>	R022022
	//char	xbuf[16385] = {0}; /* R001835 local copy*/
	xbuf[0] = 0;
	//	<<<	R022022

	if( ! shcmsgp || ! id || ! dstp || ! (elmp = elm_get_ptr(id)) )
	{
		return( -1 );
	}

	
	if( ! dlen )
		dlen = &x;
	
	sp = (char *)shcmsgp;
	
	int fieldType = elmp->type;		// R019859
	if ( needMask )
	{
		if (strstr(elmp->name, "PAN"))
		//	>>>	R022022
		//	>>> R023121
			fieldType = shouldmask;
			//elmp->type = shouldmask;
		//	>>> R023121
		//	<<<	R022022
		else if (strstr(elmp->name, "TRACK"))
			fieldType = confidential; 
		else if (strcmp(elmp->name,"SHC_PIN")==0)
			fieldType = confidential; 
		else if (strcmp(elmp->name,"SHC_MAC")==0)
			fieldType = confidential; 
		else if (strcmp(elmp->name,"SHC_CVV2")==0)
			fieldType = confidential; 
	}

	switch( fieldType )
	{
		case Short:
			*dlen = sprintf(xbuf, "%d", *(short*)(sp +elmp->offset));
			break;

		case UnsignedShort:
			*dlen = sprintf(xbuf, "%d", *(unsigned short*)(sp +elmp->offset));
			break;

		case Int:
		case Date_t:
			*dlen = sprintf(xbuf, "%d", *(int*)(sp +elmp->offset));
			break;

		case UnsignedInt:
			*dlen = sprintf(xbuf, "%d", *(unsigned int*)(sp +elmp->offset));
			break;

		case Long:
			*dlen = sprintf(xbuf, "%d", *(long*)(sp +elmp->offset));
			break;

		case UnsignedLong:
			*dlen = sprintf(xbuf, "%d", *(unsigned long*)(sp +elmp->offset));
			break;

		case Float:
			*dlen = sprintf(xbuf, "%f", *(float*)(sp +elmp->offset));
			break;

		case Double:
			*dlen = sprintf(xbuf, "%f", *(double*)(sp +elmp->offset));
			break;

		case Dec_t:
		case Amount_t:
			dbm_dectochar((dec_t*)(sp +elmp->offset), xbuf);
			*dlen = strlen(xbuf);
			break;

		case Secdukpt_t: /* is type struct { char KSNdesc[4]; char KSN[21]; }  ** R006365 **/
		case Seckey_t: /* is type struct { char key[16]; char chk[4]; } */
		case UnsignedChar:
		case Char:
		case Bin_t:
			//	---	R022022
			//memset((void *)xbuf, 0, sizeof(xbuf));
			memcpy((void *)xbuf, (char *)sp +elmp->offset, elmp->length);
			//	---	R022022
			xbuf[elmp->length] = '\0';
			*dlen = strlen(xbuf);
			break;
		case confidential:
			//	>>>	R022022
			//memset(xbuf, '\0', elmp->length);
			memset(xbuf, '\0', elmp->length+1);
			//	<<<	R022022
			if (strlen(sp +elmp->offset) <= sizeof(xbuf))
				memset(xbuf, '*',strlen(sp +elmp->offset));
			*dlen = strlen(xbuf);
			break;
		case shouldmask:
			//	>>>	R022022
			//memset(xbuf, '\0', elmp->length);
			memset(xbuf, '\0', elmp->length+1);
			//      <<<     R022022

			// R027170 >>>>
			if(strstr(elmp->name,"PAN"))
			{
				memcpy((void *)xbuf, (char *)sp +elmp->offset, elmp->length);
				xbuf[elmp->length] = '\0';
				if(xbuf[0]=='\0' || strlen(xbuf)==0)
					return -1;
				strcpy(dstp,shcApp->shcHelperObj->shc_maskpan(xbuf));
				*dlen = strlen(dstp);
				dstp[*dlen] = CHAR_NULL;
				return 0;
			}
			else
			{
				if((char *)sp +elmp->offset != NULL && *((char *)sp +elmp->offset) != '\0')
					strcpy(xbuf, shcApp->shcHelperObj->shc_maskpan((char *)sp +elmp->offset));
				*dlen = strlen(xbuf);
			}
			// <<<< R027170
			break;

		default:
			return( -1 );
	}

	memcpy((void *)dstp, xbuf, *dlen);

	if( dlen == &x )
		dstp[*dlen] = CHAR_NULL;

	return( 0 );
}


ICReturn ICShcmsg_clrBit( ICSHCMSGBIT *shcmsgbitp )
{
	if( ! shcmsgbitp )
		return( -1 );

	memset((void *)shcmsgbitp, 0, sizeof(ICSHCMSGBIT));

	return( 0 );
}

ICReturn ICShcmsg_setBit( ICSHCMSGBIT *shcmsgbitp, char *name )
{
	int		idx = 0;

	if( ! shcmsgbitp || (idx = ICShcmsg_getId_idx(name)) < 0 )
		return( -1 );

	setBit(shcmsgbitp, idx, -1);

	return(0);
}

ICReturn ICShcmsg_rstBit( ICSHCMSGBIT *shcmsgbitp, char *name )
{ 
	int		idx = 0;

	if( ! shcmsgbitp || (idx = ICShcmsg_getId_idx(name)) < 0 )
		return( -1 );

	setBit(shcmsgbitp, idx, 0);

	return(0);
}

static ICReturn ICShcmsg_cpyFld_idx( ICSHCMSG *srcp, ICSHCMSG *dstp, int idx )
{
	char	*sp = NULL;
	char	*dp = NULL;

	if( ! srcp || ! dstp || idx < 0 || idx > ICSHCMSG_NFLDS )
		return( -1 );
	
	sp = (char *)srcp;
	dp = (char *)dstp;

	memcpy((void *)(sp + getOff(idx)), (dp + getOff(idx)), getLen(idx));

	return( 0 );
}
ICReturn ICShcmsg_cpyFld( ICSHCMSG *srcp, ICSHCMSG *dstp, char *name )
{
	int		idx = 0;

	if( ! srcp || ! dstp || ! name || (idx = ICShcmsg_getId_idx(name)) < 0 )
		return( -1 );
	
	ICShcmsg_cpyFld_idx(srcp, dstp, idx);

	return( 0 );
}
ICReturn ICShcmsg_cpyMsg( ICSHCMSG *srcp, ICSHCMSG *dstp, ICSHCMSGBIT *bitp )
{
	int		idx = 0;

	ICShcmsg_shcmsg();

	if( ! srcp || ! dstp )
		return( -1 );
	
	for( idx = 0; idx < ICSHCMSG_NFLDS; idx++ )
		if( ! bitp || ! tstBit(bitp, idx, 0) )
			ICShcmsg_cpyFld_idx(srcp, dstp, idx);

	return( 0 );
}

static ICReturn ICShcmsg_cmpFld_idx( ICSHCMSG *srcp, ICSHCMSG *dstp, int idx )
{
	char	*sp = NULL;
	char	*dp = NULL;

	if( ! srcp || ! dstp || idx < 0 || idx > ICSHCMSG_NFLDS )
		return( -1 );
	
	sp = (char *)srcp;
	dp = (char *)dstp;

	memcmp((void *)(sp + getOff(idx)), (dp + getOff(idx)), getLen(idx));

	return( 0 );
}
ICReturn ICShcmsg_cmpFld( ICSHCMSG *srcp, ICSHCMSG *dstp, char *name )
{
	int		idx = 0;

	if( ! srcp || ! dstp || ! name || (idx = ICShcmsg_getId_idx(name)) < 0 )
		return( -1 );
	
	ICShcmsg_cmpFld_idx(srcp, dstp, idx);

	return( 0 );
}
ICReturn ICShcmsg_cmpMsg( ICSHCMSG *srcp, ICSHCMSG *dstp, ICSHCMSGBIT *bitp )
{
	int		idx = 0;

	ICShcmsg_shcmsg();

	if( ! srcp || ! dstp || ! bitp )
		return( -1 );
	
	ICShcmsg_clrBit(bitp);
	
	for( idx = 0; idx < ICSHCMSG_NFLDS; idx++ )
		if( ICShcmsg_cmpFld_idx(srcp, dstp, idx) != 0 )
			setBit(bitp, idx, -1);

	return( 0 );
}


ICReturn ICShcmsg_printMsg( ICSHCMSG *shcmsgp, ICSHCMSGBIT *bitp,
							FILE *fd, char *fmt )
{
	int		idx = 0;
	//	>>>	R022022
	//char	xbuf[16385] = {0}; /* R001835 */
	//char	ybuf[16385] = {0}; /* R001835 */
	xbuf[0] = 0;
	ybuf[0] = 0;
	//	<<<	R022022
	char 	tmpString[] = " %s\n";	// R005156

	if (ICShcmsg_shcmsg() < 0)
		return -1;

	if( ! shcmsgp )
		return( -1 );

//	fd is no longer used as the dump message always go to dump file
//	if( ! fd )
//		fd = stdout;

	if( ! fmt )
		fmt = tmpString;
// R005156		fmt = " %s\n";

	for( idx = 0; idx < ICSHCMSG_NFLDS; idx++ )
		if( ! bitp || tstBit(bitp, idx, 0) )
			if( ICShcmsg_getFld(shcmsgp, getName(idx), xbuf, NULL, 1) >= 0 )	// R019859
			{
				snprintf(ybuf, sizeof(ybuf), "%c%s%c [%s]", ICSHCMSG_TOKEN_L, getName(idx), 
					ICSHCMSG_TOKEN_R, xbuf);
				
				OTraceFieldDump(fmt, ybuf);
			}

	return( 0 );
}


ICReturn ICShcmsg_expand( ICSHCMSG *shcmsgp, char *src, char *dst )
{
	int		xlen = 0;
	int		ylen = 0;
	int		type = 0;
	//	>>>	R022022
	//char	xbuf[16385] = {0}; /* R001835 */
	//char	ybuf[16385] = {0}; /* R001835 */
	xbuf[0] = 0;
	ybuf[0] = 0;
	//	<<<	R022022

	// R027170 >>>>
	char    xbuf1[16385] = {0}; 
	char pan_token[(Tokenizer::MAX_PAN_SIZE > Tokenizer::MAX_TOKEN_SIZE ? 
					Tokenizer::MAX_PAN_SIZE : Tokenizer::MAX_TOKEN_SIZE) + 1]; 
	// <<<< R027170

	if( ! shcmsgp || ! src || ! dst )
		return( -1 );

	for( ; *src != CHAR_NULL; src++ )
	{
		type = 0;

		if( *src == CHAR_ESCAPE )
		{
			*dst++ = *++src;
			continue;
		}

		if( *src == ICSHCMSG_TOKEN_L )
		{
			if( *(src + 1) == '@' )
			{
				src++;
				type = 1;
			}

			parseFld(src, xbuf, &xlen, CHAR_NULL, ICSHCMSG_TOKEN_R);
			src += xlen + 1;

			// R027170 >>>>
			memset(xbuf1,0x00,sizeof(xbuf1)); 
			memcpy(xbuf1,xbuf,xlen);  
			// <<<< R027170
 
			//	>>>	R022022
			//if( ICShcmsg_getFld(shcmsgp, xbuf, ybuf, &ylen, 0) < 0 )	// R019859
			if( ICShcmsg_getFld(shcmsgp, xbuf1, ybuf, &ylen, 1) < 0 )  // R027170
			//	<<<	R022022
			{

				
				*dst++ = '[';
				memcpy((void *)dst, xbuf, xlen);
				dst += xlen;
				*dst++ = ']';
				continue;
			}

			if( type == 1 )
			{
				ybuf[8] = CHAR_NULL;
				dbm_ist_date_to_vendor(xbuf, atol(ybuf));
				ylen = strlen(xbuf) - 2;
				strcpy(ybuf, &xbuf[1]);
			}
		
			// R027170 >>>>
            if (!strcmp(xbuf1,"SHC_PAN"))
			{
				Tokenizer *tkn_ptr = Tokenizer::create();
				int tkn_ret = tkn_ptr->getToken(xbuf,pan_token,false);
				delete tkn_ptr;
				if(tkn_ret != 0)
				{
					if(tkn_ret == Tokenizer::PAN_NOT_FOUND)
						OTraceDebug("D-SHC-002002: PAN not found\n");
					else
						OTraceError("E-SHC-002002: Unable to tokenize Pan [%d]\n", tkn_ret);
					return -1;
				}
				OTraceDebug("D-SHC-002002: Tokenized PAN [%s]\n",
							strcmp(xbuf,pan_token)? pan_token:shc_maskpan(pan_token));

				memset(ybuf,0x00,sizeof(ybuf));
				strcpy(ybuf,pan_token);
				ylen=strlen(ybuf);
			}
			// <<<< R027170

			memcpy((void *)dst, ybuf, ylen);
			dst += ylen;
			continue;
		}

		*dst++ = *src;
	}

	*dst = CHAR_NULL;

	return( 0 );
}



char *ICShcmsg_getFieldName( int idx )
{
	if( ICShcmsg_shcmsg() < 0 || ! idx >= ICSHCMSG_NFLDS )
		return NULL;
	
	return ShcMsgTbl[idx].name;
}

int ICShcmsg_getNumOfShcmsg()
{
	int i;
	if( ICShcmsg_shcmsg() < 0 )
		return 0;

	for (i=0; i<ICSHCMSG_NFLDS; i++ )
	{
		if ( ! ShcMsgTbl[i].name[0] )
			return i;
	}
	return 0;
}

int  ICShcmsg_getFieldDataType( char *id )
{
	SHCMSGELM	*elmp = NULL;

	if( elmp = elm_get_ptr(id) )
	{
		return( -1 );
	}

	return ( elmp->type );
}


