/*
 *  Copyright (C) 2004 eFunds Corporation ("eFunds").  All Rights Reserved.     
 *  eFunds Canada Corporation is an authorized user.                            
 *                                                                              
 *  IST is a registered trademark of eFunds Corporation.  Other brand or        
 *  product names are trademarks or registered trademarks of their respective   
 *  holders.                                                                    
 *                                                                              
 *  The information contained herein is the unpublished proprietary property    
 *  of eFunds.  Except as specifically authorized in writing by eFunds, the     
 *  holder of this document shall: i) keep all information contained herein     
 *  confidential, and ii) protect the information, in whole or in part, from    
 *  disclosure and dissemination to all third parties.                          
 *                                                                          
 *  This document and the software described in it are furnished under license  
 *  and may be used or copied only in accordance with the terms of such license.
 *  This document is supplied for information purposes only, is subject to      
 *  change without notice, and should not be construed as a commitment by       
 *  either eFunds Corporation or eFunds Canada Corporation. 
 */


/* File Number 181 */

#if defined(WIN32)
#	define ShcAcceptorName_h_export_directive	__declspec(dllexport)
#else
#	define ShcAcceptorName_h_export_directive
#endif

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <ctype.h>
#include <errno.h>
#include <oasis.h>
#include <ist_otrace.h>
#include <shc.h>
#include <ShcAppBase.h>
#include <ist_seg_name.h>
#include <ist_seg_id.h>
#include <ShcmsgHeader.h>

#include <HaPtmCctHelper.h>
#include <istsafe.h>
#include <dbm_private.h>
#include <mst_shclog_map.h>
#include <MSTShclogMap.h>

using namespace DBMWrapper;

DBMConn* MSTShclogMap::dbConn = NULL;
DBMStmt* MSTShclogMap::stmtInsert = NULL;
DBMStmt* MSTShclogMap::stmtSelect = NULL;
DBMStmt* MSTShclogMap::stmtUpdate = NULL;
MSTShclogMap *MSTShclogMapinstance = NULL;
//MST: Merchant Supplied Transaction ID

int MSTShclogMap::record(ShcmsgHeader *h)
{
	if (!MSTShclogMapinstance)
		MSTShclogMapinstance = new MSTShclogMap();

	return MSTShclogMapinstance->_record(h);
}
int MSTShclogMap::record(ShcmsgHeader *h, char *msgId)
{
	if (!MSTShclogMapinstance)
		MSTShclogMapinstance = new MSTShclogMap();

	return MSTShclogMapinstance->_record(h, msgId);
}

const char * MSTShclogMap::findShclogId(const char *MSTId, int msgtype, int pcode)
{
	if (!MSTShclogMapinstance)
		MSTShclogMapinstance = new MSTShclogMap();

	return MSTShclogMapinstance->_findShclogId(MSTId, (short)(msgtype%10000/100), (short)(pcode%1000000/10000));
}

long MSTShclogMap::getExistingTrace()
{
        if (!MSTShclogMapinstance)
                MSTShclogMapinstance = new MSTShclogMap();

        return MSTShclogMapinstance->_getExistingTrace();
}

MSTShclogMap::MSTShclogMap()
{
	mMSTId[0] = '\0';
	mShclogId[0] = '\0';
	mMsgType = 0;
	mWeight = 0;
	mTrace = 0;
	memset(_ind, 0, sizeof(_ind));
	if (!dbConn)
	{
		try
		{
			dbConn = new DBMConn(dbm_dbconn);
			stmtInsert=dbConn->getStmt();
			stmtInsert->prepare("insert into mst_shclog_map ("
						"mst_id,"
						"shclog_id,"
						"msgtype,"
						"pcode,"
						"created,"
						"weight,"
						"trace"
					")values"
					"(?,?,?,?,?,?,?)");

			int sno = 1;
			stmtInsert->bindParam(  sno++, DBM_STRINGTYPE, mMSTId, sizeof(mMSTId), NULL );
			stmtInsert->bindParam(  sno++, DBM_STRINGTYPE, mShclogId, sizeof(mShclogId), NULL );
			stmtInsert->bindParam(  sno++, DBM_INTTYPE, &mMsgType, sizeof(mMsgType), NULL);
			stmtInsert->bindParam(  sno++, DBM_INTTYPE, &mPcode, sizeof(mPcode), NULL);
			stmtInsert->bindParam(  sno++, createdTime);
			stmtInsert->bindParam(  sno++, DBM_INTTYPE, &mWeight, sizeof(mWeight), NULL);
			stmtInsert->bindParam(  sno++, DBM_LONGTYPE, &mTrace, sizeof(mTrace), NULL);

			stmtSelect=dbConn->getStmt();
			stmtSelect->prepare
					(
					"SELECT "
					"shclog_id, "
					"weight, "
					"trace "
					"FROM mst_shclog_map "
					"WHERE mst_id = ? and msgtype = ? and pcode = ?"
					);
			sno = 1;
			int cnt = 1;
			stmtSelect->bindCol(  sno++, DBM_STRINGTYPE, mShclogId, sizeof(mShclogId), &_ind[cnt++] );
			stmtSelect->bindCol(  sno++, DBM_INTTYPE, &mWeight, sizeof(mWeight), &_ind[cnt++] );
			stmtSelect->bindCol(  sno++, DBM_LONGTYPE, &mTrace, sizeof(mTrace), &_ind[cnt++] );
			stmtSelect->bindParam(  1, DBM_STRINGTYPE, mMSTId, sizeof(mMSTId), NULL );
			stmtSelect->bindParam(  2, DBM_INTTYPE, &mMsgType, sizeof(mMsgType), NULL);
			stmtSelect->bindParam(  3, DBM_INTTYPE, &mPcode, sizeof(mPcode), NULL);

			stmtUpdate=dbConn->getStmt();
			stmtUpdate->prepare ("update mst_shclog_map set "
					"shclog_id = ?, weight = ?"
					" where mst_id = ? and msgtype = ? and pcode = ?");
			sno = 1;
			stmtUpdate->bindParam(  sno++, DBM_STRINGTYPE, mShclogId, sizeof(mShclogId), NULL );
			stmtUpdate->bindParam(  sno++, DBM_INTTYPE, &mWeight, sizeof(mWeight), NULL);
			stmtUpdate->bindParam(  sno++, DBM_STRINGTYPE, mMSTId, sizeof(mMSTId), NULL );
			stmtUpdate->bindParam(  sno++, DBM_INTTYPE, &mMsgType, sizeof(mMsgType), NULL);
			stmtUpdate->bindParam(  sno++, DBM_INTTYPE, &mPcode, sizeof(mPcode), NULL);
		}
		catch (const DBMException& e)
		{
			OTraceError
			(
				"E-SHC-18103: Caught exception during init,"
				"native error=%d, sqlstate=%.5s, msg=%s\n",
				e.getNativeError(), e.getSQLState().data(), e.getErrMsg().data()
			);
			throw 1;
		}
	}
}
void MSTShclogMap::reset()
{
	mMsgType=0;
	mPcode=0;
	mWeight=0;
	memset(mShclogId, 0x00, sizeof(mShclogId));
	memset(mMSTId, 0x00, sizeof(mMSTId));
}
int MSTShclogMap::_record(ShcmsgHeader *h, char *msgId)
{
	reset();
    if(shcmsgIsRequest(&h->msg))
    {
        mMsgType = h->msg.msgtype/100;
        mPcode = h->msg.pcode/10000;

        if ((mPcode == SH_ISO_PREAUTHREQ)||(mPcode == SH_ISO_PREAUTHCONF))
            mPcode = SH_ISO_G_AND_S;
        else if (h->msg.shc_devcap & SH_DEVCAP_SHC_VOID)
            mPcode += 100;

	mTrace = h->msg.trace;
        OCDateTime currTime;
        createdTime = currTime;
        short weight = 0;
        weight = calcWeight(h);
        mWeight = weight;
        istsafe_strcpy(mShclogId, sizeof(mShclogId), h->msg.shclog_id);
		istsafe_strcpy(mMSTId, sizeof(mMSTId), msgId);
        return insert(h);
    }
}

int MSTShclogMap::_record(ShcmsgHeader *h)
{
	if (!h)
		return MST_SHCLOG_NO_HEADER_NO_CHANGE;
	
	int len = sizeof(mMSTId);
    h->getSegmentData(mMSTId, &len, NETWORK_SETTLEMENT_DATA_id, MERCH_SUPPLIED_TXNID);
	if (len <= 0)
	{
		len = sizeof(mMSTId);
	    h->getReqSegmentData(mMSTId, &len, NETWORK_SETTLEMENT_DATA_id, MERCH_SUPPLIED_TXNID);
	}
	if (len <= 0)
	{
		len = sizeof(mMSTId);
	    h->getReqSegmentData(mMSTId, &len, NETWORK_SETTLEMENT_DATA_id, MERCH_SUPPLIED_TXNID);
	}
	if (len <= 0)
	{
		len = sizeof(mMSTId);
	    h->getReqSegmentData(mMSTId, &len, NETWORK_SETTLEMENT_DATA_id, MERCH_SUPPLIED_TXNID);
	}
	if (len <= 0)
	{
		OTraceDebug("D-SHC-18101:MST not found, no mst_shclog_map recorded\n");
		return MST_SHCLOG_NO_MST_NO_CHANGE;
	}
	mMsgType = h->msg.msgtype/100;
	mPcode = h->msg.pcode/10000;
	if ((mPcode == SH_ISO_PREAUTHREQ)||(mPcode == SH_ISO_PREAUTHCONF))
		mPcode = SH_ISO_G_AND_S;		//preauth and completion shoujld be purchase as well
	else if (h->msg.shc_devcap & SH_DEVCAP_SHC_VOID)
		mPcode += 100;		//Void pcode may be same as orig pcode, add 100 to distinguish

	OCDateTime currTime;
	createdTime = currTime;
	short weight = 0;
	weight = calcWeight(h);
	short weightExistingRecord = getExistingRecord();

	mWeight = weight;
	istsafe_strcpy(mShclogId, sizeof(mShclogId), h->msg.shclog_id);

	if (weightExistingRecord == MST_SHCLOG_WEIGHT_NON_EXIST)
	{
		//no record found, just insert
		return insert(h);
	}
	if (weight > weightExistingRecord)
	{
		//current record has bigger weight, replace existing record
		return update(h);
	}
	OTraceDebug("D-SHC-18102:current weight(%d), existing weight(%d), skip change\n", weight, weightExistingRecord);
	return MST_SHCLOG_SMALL_WEIGHT_NO_CHANGE;
}

//Weight is calculated as below:
// Authorization: +500
// Completion: +600
// Reversal: +600
// From issuer (with alpha_response_code): +50
// Approved: +20
// Shc timeout declined: +0
// Declined: +10
// Initial transaction(opposed to incremental): +5

short MSTShclogMap::calcWeight(ShcmsgHeader *h)
{
	short weight = 0;
	switch(h->msg.msgtype/100)
	{
	case 1:
		//1xx message
		if (h->msg.pcode/10000 == SH_ISO_PREAUTHCONF)
			weight += MST_WEIGHT_COMPLETION;
		else
		{
			if(shcmsgIsRequest(&h->msg))
				weight += MST_WEIGHT_AUTHORIZATION_REQ;
			else
				weight += MST_WEIGHT_AUTHORIZATION;
		}
		break;
	case 2:
		if(shcmsgIsRequest(&h->msg))
			weight += MST_WEIGHT_FINANCIAL_REQ;
		else
			weight += MST_WEIGHT_FINANCIAL;
		break;
	case 4:
		weight += MST_WEIGHT_REVERSAL;
		break;
	}

	if (h->msg.alpha_response_code[0]) 
		weight += MST_WEIGHT_FROM_ISSUER;
	if (h->msg.respcode == SHC_RC_Approved)
		weight += MST_WEIGHT_APPROVED;
	if (h->msg.respcode != SHC_RC_IssuerTimeout)
		weight += MST_WEIGHT_DECLINED;
	
	return weight;
}

const char * MSTShclogMap::_findShclogId(const char *MSTId, short msgtype, short pcode)
{
	int len = sizeof(mMSTId);
	istsafe_strcpy(mMSTId, sizeof(mMSTId), MSTId);
	mMsgType = msgtype;
	mPcode = pcode;
	if ((mPcode == SH_ISO_PREAUTHREQ)||(mPcode == SH_ISO_PREAUTHCONF))
		mPcode = SH_ISO_G_AND_S;		//preauth and completion shoujld be purchase as well

	short existingWeight = getExistingRecord();
	if (existingWeight == MST_SHCLOG_WEIGHT_NON_EXIST)
		return NULL;
	return mShclogId;
}

short MSTShclogMap::getExistingRecord()
{
	int rc = 0;
	try
	{
		stmtSelect->execute();
		rc = stmtSelect->fetch();
		stmtSelect->close();

		if(rc ==DBM_SUCCESS)
		{
			return mWeight;
		}
		return MST_SHCLOG_WEIGHT_NON_EXIST;
	}
	catch (const DBMException& e)
	{
		OTraceError
		(
			"E-SHC-18104: Caught exception during select,"
			"native error=%d, sqlstate=%.5s, msg=%s\n",
			e.getNativeError(), e.getSQLState().data(), e.getErrMsg().data()
		);
		return MST_SHCLOG_DB_ERROR;
	}
}

short MSTShclogMap::insert(ShcmsgHeader *h)
{
	int rc = 0;
	
	try
	{
		rc = stmtInsert->execute();
		stmtInsert->close();

		if(rc ==DBM_SUCCESS)
		{
			return mWeight;
		}
		return MST_SHCLOG_WEIGHT_NON_EXIST;
	}
	catch (const DBMException& e)
	{
		OTraceError
		(
			"E-SHC-18105: Caught exception during insert,"
			"native error=%d, sqlstate=%.5s, msg=%s\n",
			e.getNativeError(), e.getSQLState().data(), e.getErrMsg().data()
		);
		return MST_SHCLOG_DB_ERROR;
	}
}

short MSTShclogMap::update(ShcmsgHeader *h)
{
	int rc = 0;
	
	try
	{
		rc = stmtUpdate->execute();
		int recCount  = 0;
		stmtUpdate->getRowCount(&recCount);
		stmtUpdate->close();
		OTraceDebug("D-SHC-18107:%d rows updated. rc(%d)\n", recCount, rc);
		if(rc ==DBM_SUCCESS)
		{
			return mWeight;
		}
		return MST_SHCLOG_WEIGHT_NON_EXIST;
	}
	catch (const DBMException& e)
	{
		OTraceError
		(
			"E-SHC-18106: Caught exception during update,"
			"native error=%d, sqlstate=%.5s, msg=%s\n",
			e.getNativeError(), e.getSQLState().data(), e.getErrMsg().data()
		);
		return MST_SHCLOG_DB_ERROR;
	}
}

long MSTShclogMap::_getExistingTrace()
{
	int rc = 0;
	try
	{
		stmtSelect->execute();
		rc = stmtSelect->fetch();
		stmtSelect->close();

		if(rc ==DBM_SUCCESS)
		{
			return mTrace;
		}
		return MST_SHCLOG_WEIGHT_NON_EXIST;
	}
	catch (const DBMException& e)
	{
		OTraceError
		(
			"E-SHC-18104: Caught exception during select,"
			"native error=%d, sqlstate=%.5s, msg=%s\n",
			e.getNativeError(), e.getSQLState().data(), e.getErrMsg().data()
		);
		return MST_SHCLOG_DB_ERROR;
	}
}
