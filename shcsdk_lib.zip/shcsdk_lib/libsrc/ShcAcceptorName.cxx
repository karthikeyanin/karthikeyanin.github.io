/*
 *  Copyright (C) 2004 eFunds Corporation ("eFunds").  All Rights Reserved.     
 *  eFunds Canada Corporation is an authorized user.                            
 *                                                                              
 *  IST is a registered trademark of eFunds Corporation.  Other brand or        
 *  product names are trademarks or registered trademarks of their respective   
 *  holders.                                                                    
 *                                                                              
 *  The information contained herein is the unpublished proprietary property    
 *  of eFunds.  Except as specifically authorized in writing by eFunds, the     
 *  holder of this document shall: i) keep all information contained herein     
 *  confidential, and ii) protect the information, in whole or in part, from    
 *  disclosure and dissemination to all third parties.                          
 *                                                                          
 *  This document and the software described in it are furnished under license  
 *  and may be used or copied only in accordance with the terms of such license.
 *  This document is supplied for information purposes only, is subject to      
 *  change without notice, and should not be construed as a commitment by       
 *  either eFunds Corporation or eFunds Canada Corporation. 
 */

// "@(#) ShcAcceptorName.cxx 1.9.3.4 20/04/14 21:07:36"

/*----------------------------------------------------------------------------*
 *                                                                            *
 * File:				
 * Description:	
 * Notes:
 *
 * Modification History:
 * YYMMDD SCR#    WHO	Description
 * ------ ------- ---	------------------------------------------------------*
 * 020303 R007555 ztang Created.
 * 020403 R007655 ztang Added code to convert from numeric country code
 * 020425 R007733 rzhou Added country code compare function 
 * 030201 R009021 ztang Moved from misc_api to shc_lib
 * 061102 R018101 spa	Pad zeros at beginning of state when numeric
 * R027879 jyang 05Feb10 Acceptor name enhancement
 * R028078 dipa  20Apr10 Added store number and mall name
 * R028206 jyang 27May10 Fixed setNumericCountryCode 
 *----------------------------------------------------------------------------*/

/* File Number 20 */

#if defined(WIN32)
#	define ShcAcceptorName_h_export_directive	__declspec(dllexport)
#else
#	define ShcAcceptorName_h_export_directive
#endif

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <ctype.h>
#include <errno.h>
#include <oasis.h>
#include <ist_otrace.h>
#include <ShcAcceptorName.h>
#include <ccMapTable.h>
#include <shcseg.h>
#include <shc.h>
#include <ist_seg_name.h>
#include <ist_seg_id.h>
#include <ist_seg_elf_id_map.h>
#include <ShcmsgHeader.h>

#include <HaPtmCctHelper.h>
#include <istsafe.h>

int ShcAcceptorName::nameLen = 25;
int ShcAcceptorName::cityLen = 13;
int ShcAcceptorName::stateLen = 0;
int ShcAcceptorName::countryLen = 2;
int ShcAcceptorName::initialized = 0;
unsigned short ShcAcceptorName::mySegmentId = 0;
		
ShcAcceptorName::ACCEPTORNAME_LAYOUT ShcAcceptorName::networkLayout[MAX_NETWORKS] = {
				{"SHC" , 25, 13, 0, 2},
				{"VISA", 25, 13, 0, 2},
				{"MC"  , 23, 13, 2, 2},
				{"DISC", 23, 14, 0, 13},	// country code: 1x= x digits / 0x= x char / 13= 3 digits / 3= 3 char 
				{"",     0,   0, 0, 0}
			};
	
////////////////////////////////////////////////////////////////////////////////
const char *ShcAcceptorName::getName()
{
	return (const char *)SHC_ShcAcceptorName;
}


ShcAcceptorName::ShcAcceptorName()
{
	if (!initialized)
		initialize();
		
	resetData();
	
	memset(name, ' ', nameLen);
	name[nameLen] = '\0';
	memset(city, ' ', cityLen);
	city[cityLen] = '\0';
	if (stateLen > 0)
	{
		memset(state, ' ', stateLen);
		state[stateLen] = '\0';
	}
	else
		state[0]='\0';
	memset(twoCharCountryCode, 0, 4);
	memset(threeCharCountryCode, 0, 4);
	numericCountryCode = -1;
}


void ShcAcceptorName::loadShcmsgAcceptorname(char *acceptorname)
{
	char buf[100]={0};
	char *p = buf;
	strncpy( buf, acceptorname, sizeof(buf)-1 );
	
	if (!initialized)
		initialize();
	
	resetData();
	
	p[40] = '\0';
	for (register int i=0; i<40;i++)
		if (!p[i])
			p[i]= ' ';
	if (nameLen>0)
	{
		memcpy(name, p, nameLen);
		name[nameLen] = '\0';
		p += nameLen;
		setNameSeg( name );
	}
	
	if (cityLen>0)
	{
		memcpy(city, p, cityLen);
		city[cityLen] = '\0';
		p += cityLen;
		setCitySeg( city );
	}
	
	if (stateLen>0)
	{
		memcpy(state, p, stateLen);
		state[stateLen] = '\0';
		p += stateLen;
		setStateSeg( state );
	}
	else
		state[0] = '\0';
	
	if (countryLen==2)
	{
		memcpy(twoCharCountryCode, p, 2);
		twoCharCountryCode[2] = '\0';
		threeCharCountryCode[0] = '\0';
		numericCountryCode = -1;
		setCountrySeg( twoCharCountryCode );
	}
	else if (countryLen == 3)
	{
		memcpy(threeCharCountryCode, p, 3);
		threeCharCountryCode[3] = '\0';
		twoCharCountryCode[0] = '\0';
		numericCountryCode = -1;
		setCountrySeg( threeCharCountryCode );
	}

}

void ShcAcceptorName::getTwoCharCountryCode(char *countryCodeBuf)
{
	if (twoCharCountryCode[0])
	{
		istsafe_strcpy(countryCodeBuf, 3, twoCharCountryCode);
		return;
	}

													//R007655
	if (numericCountryCode >= 0)
	{
		if (CountryCodeMapTable::countryCodeNumericTo2( numericCountryCode, twoCharCountryCode) == 
				CountryCodeMapTable::Successful)
		{
			istsafe_strcpy(countryCodeBuf, 3, twoCharCountryCode);
			return;
		}
	}
	else if (threeCharCountryCode[0])
	{
		if (CountryCodeMapTable::countryCode3to2( threeCharCountryCode, twoCharCountryCode) == 
					CountryCodeMapTable::Successful)
		{
			istsafe_strcpy(countryCodeBuf, 3, twoCharCountryCode);
			return;
		}
	}

	//Can't map, Just take the first two char from threeCharCountryCode	
	if (threeCharCountryCode)
	{
		memcpy(twoCharCountryCode, threeCharCountryCode, 2);
		twoCharCountryCode[2] = '\0';
		istsafe_strcpy(countryCodeBuf, 3, twoCharCountryCode);
	}
	else
		istsafe_strcpy(countryCodeBuf, 3,"  ");
	return;
}

void ShcAcceptorName::getThreeCharCountryCode(char *countryCodeBuf)
{
	if (threeCharCountryCode[0])
	{
		istsafe_strcpy(countryCodeBuf, 4, threeCharCountryCode);
		return;
	}

													//R007655
	if (numericCountryCode >= 0)
	{
		if (CountryCodeMapTable::countryCodeNumericTo3( numericCountryCode, threeCharCountryCode) == 
				CountryCodeMapTable::Successful)
		{
			istsafe_strcpy(countryCodeBuf, 4, threeCharCountryCode);
			return;
		}
	}
	else if (twoCharCountryCode[0])
	{
		if (CountryCodeMapTable::countryCode2to3( twoCharCountryCode, threeCharCountryCode) == 
			CountryCodeMapTable::Successful)
		{
			istsafe_strcpy(countryCodeBuf, 4, threeCharCountryCode);
			return;
		}
	}

	//Can't map, Just take the first two char from twoCharCountryCode and add a space
	if (twoCharCountryCode[0])
	{
		memcpy(threeCharCountryCode, twoCharCountryCode, 2);
		threeCharCountryCode[2] = ' '; 
		threeCharCountryCode[3] = '\0';
		istsafe_strcpy(countryCodeBuf, 4, threeCharCountryCode);
	}
	else
		istsafe_strcpy(countryCodeBuf, 4, "   ");

	return;
}

void ShcAcceptorName::getNumericCountryCode(short *countryCode)
{
	if (numericCountryCode >= 0)
	{
		*countryCode = numericCountryCode;
		return;
	}

													//R007655
	if (threeCharCountryCode[0])
	{
		if (CountryCodeMapTable::countryCode3toNumeric( threeCharCountryCode, &numericCountryCode ) == 
				CountryCodeMapTable::Successful)
		{
			*countryCode=numericCountryCode;
			return;
		}
	}
	else if (twoCharCountryCode[0])
	{
		if (CountryCodeMapTable::countryCode2toNumeric( twoCharCountryCode, &numericCountryCode) == 
			CountryCodeMapTable::Successful)
		{
			*countryCode=numericCountryCode;
			return;
		}
	}

	//Can't map, Just return 0
	*countryCode = 0;
	return;
}


void ShcAcceptorName::initialize(void)
{
	char buf[200];
	int tmpNameLen, tmpCityLen, tmpStateLen, tmpCountryLen, sum; 

	HaPtmCctHelper::addHandler( "system.dcs.shc" ) ;

	if (cf_open(u_constructfile("files/shc.cfg")) >= 0)
	{
		if ( cf_locate("shc.acceptor_name_name_length",buf) > 0)
			tmpNameLen = atoi(buf);
		else
			tmpNameLen = nameLen;

		if ( cf_locate("shc.acceptor_name_city_length",buf) > 0)
			tmpCityLen = atoi(buf);
		else
			tmpCityLen = cityLen;

		if ( cf_locate("shc.acceptor_name_state_length",buf) > 0)
			tmpStateLen = atoi(buf);
		else
			tmpStateLen = stateLen;

		if ( cf_locate("shc.acceptor_name_country_length",buf) > 0)
			tmpCountryLen = atoi(buf);
		else
			tmpCountryLen = countryLen;

		sum = tmpNameLen+tmpCityLen+tmpStateLen+tmpCountryLen; 

		if ((sum != 40) || (tmpNameLen <15) || (tmpNameLen >26) ||
			(tmpCityLen < 5) || (tmpCityLen > 16) || (tmpStateLen < 0) || 
			(tmpStateLen > 16) || (tmpCountryLen < 2) || (tmpCountryLen > 3))
		{
			OTraceError("E-SHC-020001:Lengthes of acceptor name fields[%d %d %d %d] not valid. Default value [%d %d %d %d] is used.",
				tmpNameLen, tmpCityLen, tmpStateLen, tmpCountryLen, nameLen, cityLen, stateLen, countryLen);
		}
		else
		{
			nameLen = tmpNameLen;
			cityLen = tmpCityLen;
			stateLen = tmpStateLen; 
			countryLen = tmpCountryLen;
		}
			
		cf_close();
	}
	
	setLayoutDef( "SHC", nameLen, cityLen, stateLen, countryLen);
	
	mySegmentId = ElfIdMap::elf_to_id(IST_SEG_NETWORK_SETTLEMENT_DATA);

	OTraceDebug("D-SHC-020002:card acceptor len:name:(%d),city(%d),state(%d), countrycode(%d).\n",
              nameLen, cityLen, stateLen, countryLen);
	initialized = 1;
}

static int shcfmt_acptflds[4];

int * ShcAcceptorName::getAcceptorFieldsLength()
{
	shcfmt_acptflds[0] = nameLen;
	shcfmt_acptflds[1] = cityLen;
	shcfmt_acptflds[2] = stateLen;
	shcfmt_acptflds[3] = countryLen;
	
    return shcfmt_acptflds;
}

int ShcAcceptorName::compareToCountryCode(char *cc_2, char *cc_3)
{
      int cmpRet = 0;

      if ( !strncmp(twoCharCountryCode, cc_2, 2)) cmpRet = 2;
      else if ( !strncmp(threeCharCountryCode, cc_3, 3)) cmpRet = 3;
      
      return cmpRet;
}

void ShcAcceptorName::setName(const char *newName)
{
	int len;
	
	setNameSeg( newName );
	
	memset(name, ' ', nameLen);
	if (strlen(newName)>nameLen)
		len=nameLen;
	else
		len=strlen(newName);
	memcpy(name, newName, len);
	name[nameLen] = '\0';
	return;
}

void ShcAcceptorName::setCityName(const char *newCity)
{
	int len;
	
	setCitySeg( newCity );
	
	memset(city, ' ', cityLen);
	if (strlen(newCity)>cityLen)
		len=cityLen;
	else
		len=strlen(newCity);
	memcpy(city, newCity, len);
	city[cityLen] = '\0';
	return;
}

void ShcAcceptorName::setStateName(const char *newState)
{
	int len, posn;
	
	setStateSeg( newState );
	
	if (stateLen <= 0)
	{
		state[0]='\0';
		return;
	}
	
	//	>>>	R018101
	len = strlen(newState);
	if(len > stateLen)
		len = stateLen;
	if(newState[0] >= '0' && newState[0] <= '9')
	{
		memset(state, '0', stateLen);
		posn = stateLen - len;
		if (len <= (sizeof(state)-posn)) //IST_S_0157721-34
			memcpy(state+posn, newState, len);
	}
	else
	{
		memset(state, ' ', stateLen);
		if (len <= sizeof(state)) //IST_S_0157721-34
			memcpy(state, newState, len);
	}
	state[stateLen] = '\0';
	//      <<<     R018101
	return;
}

void ShcAcceptorName::setCountryCode(const char *newCountryCode)
{
	setCountrySeg( newCountryCode );
	
	if (newCountryCode[0] >= '0' && newCountryCode[0] <= '9')
	{
		numericCountryCode=atoi(newCountryCode);
		twoCharCountryCode[0] = '\0';
		threeCharCountryCode[0] = '\0';
	}
	else if (strlen(newCountryCode) == 2)
	{
		istsafe_strcpy(twoCharCountryCode,sizeof(twoCharCountryCode), newCountryCode);
		threeCharCountryCode[0] = '\0';
		numericCountryCode = -1;
	}
	else if (strlen(newCountryCode) >= 3)
	{
		strncpy(threeCharCountryCode, newCountryCode, 3);
		threeCharCountryCode[3] = '\0';
		twoCharCountryCode[0] = '\0';
		numericCountryCode = -1;
	}

	return;
}	

void ShcAcceptorName::setNumericCountryCode(const short newCountryCode)
{
	numericCountryCode=newCountryCode;
	twoCharCountryCode[0] = '\0';
	threeCharCountryCode[0] = '\0';
	
	getThreeCharCountryCode(threeCharCountryCode);
	if ( strcmp(threeCharCountryCode, "   ") )
	{
		setCountrySeg( threeCharCountryCode );
	}
	else
	{
		sprintf( threeCharCountryCode, "%03.3d", newCountryCode );
		setCountrySeg( threeCharCountryCode );
		threeCharCountryCode[0] = '\0';
	}

	return;
}	

void ShcAcceptorName::getAcceptorName(char * acceptorNameBuf)
{
	char tempAcceptorNameBuf[SHC_ACCEPT_LEN];// length of acceptorname[] defined in shcimf.h
	int len = 0;

	istsafe_strcpy(acceptorNameBuf, sizeof(tempAcceptorNameBuf),name);
	len = istsafe_strlen(acceptorNameBuf, sizeof(tempAcceptorNameBuf));

	istsafe_strcat(acceptorNameBuf,sizeof(tempAcceptorNameBuf), city);
        len = istsafe_strlen(acceptorNameBuf, sizeof(tempAcceptorNameBuf));

	if (stateLen > 0)
	{	
		istsafe_strcat(acceptorNameBuf,sizeof(tempAcceptorNameBuf), state);
	}
	if (countryLen == 2)
		getTwoCharCountryCode(acceptorNameBuf+nameLen+cityLen+stateLen);
	else
		getThreeCharCountryCode(acceptorNameBuf+nameLen+cityLen+stateLen);
	
	return;
}




////////////////////////////////////////////////////////////////////////////////
// Enhance to support segment ACCEPTOR_NAME
////////////////////////////////////////////////////////////////////////////////


void ShcAcceptorName::resetData()
{
	memset( nameSeg,    0, sizeof(nameSeg) );
	memset( citySeg,    0, sizeof(citySeg) );
	memset( stateSeg,   0, sizeof(stateSeg) );
	memset( countrySeg, 0, sizeof(countrySeg) );
	memset( postalSeg,  0, sizeof(postalSeg) );
	memset( phoneSeg,   0, sizeof(phoneSeg) );
	memset( addressSeg, 0, sizeof(addressSeg) );
	memset( storeSeg,   0, sizeof(storeSeg) ); //R028078
	memset( mallSeg,   0, sizeof(mallSeg) );   //R028078
	memset( additional_data, 0, sizeof(additional_data) );
        memset( emailSeg,   0, sizeof(emailSeg) );

	memset( segBuffer, 0, sizeof(segBuffer) );
	memset( outputBuffer, 0, sizeof(outputBuffer) );
	memset( (char*)&acceptorLayout, 0, sizeof(ACCEPTORNAME_LAYOUT) );

	return;
}
	

int ShcAcceptorName::isDataReady()
{
	if ( strtrim(nameSeg, nameSeg) > 0 )
		return 1;
	return 0;
}


int ShcAcceptorName::formatIt( char *target, char *source, int len, char c )
{
	if ( len<=0 || !target || !source )
	{
		return 0;
	}
	
	int i;
	int l = strlen(source);
	for( i=0; i<l && i<len; i++ )
	{
		target[i]=source[i];
	}
	for(;i<len;i++)
	{
		target[i]=c;
	}
	target[i]='\0';
	
	return len;
}


char *ShcAcceptorName::getAcceptorNameFromSegment( const char *segData, int segLen, const char *network )
{
	if ( parseSegAcceptorName(segData, segLen) < 0 )
	{
		strcpy( outputBuffer, "Unable to parse AcceptorName from segmnt" );
		return outputBuffer;
	}
	
	return outputAcceptorName( network );
}
	

int ShcAcceptorName::parseSegAcceptorName( const char *segDataIn, int segLen )
{
	char segData[sizeof(segBuffer)]={0};
	segLen = segLen<sizeof(segBuffer) ? segLen : sizeof(segBuffer);
	memcpy( segData, segDataIn, segLen );
	
	const char *ptr = segData;
	
	resetData();
	
	if ( segLen <= OFST_COUNTRY )
	{
		OTraceError( "E-SHC-020003: Length of segment AcceptorName is too short[%d]<[%d]\n", segLen, OFST_COUNTRY );
		return -1;
	}
	
	if ( segLen > LEN_SEG_MAX )
	{
		OTraceWarning( "W-SHC-020004: Length of segment ACEEPTOR_NAME is too long[%d]>[%d]\n", segLen, LEN_SEG_MAX );
		segLen = LEN_SEG_MAX;
	}
	
	memcpy( segBuffer, segData, segLen );
	
	setName( ptr );
	ptr += LEN_NAME;
	
	setCityName( ptr );
	ptr += LEN_CITY;
	
	setStateName( ptr );
	ptr += LEN_STATE;
	
	setCountryCode( ptr );
	ptr += LEN_COUNTRY;
	
	if ( segLen > OFST_ADDRESS )
	{
		memcpy( addressSeg, ptr, LEN_ADDRESS );
		ptr += LEN_ADDRESS;
	}
	
	if ( segLen > OFST_POSTAL )
	{
		memcpy( postalSeg, ptr, LEN_POSTAL );
		ptr += LEN_POSTAL;
	}
	
	if ( segLen > OFST_PHONE )
	{
		memcpy( phoneSeg, ptr, LEN_PHONE );
		ptr += LEN_PHONE;
	}
	
	//R028078 >>>
	if ( segLen > OFST_STORE)
	{
		memcpy( storeSeg, ptr, LEN_STORE);
		ptr += LEN_STORE;
	}

	if ( segLen > OFST_MALL)
	{
		memcpy( mallSeg, ptr, LEN_MALL);
		ptr += LEN_MALL;
	}
	//<<< R028078

	if ( segLen > OFST_ADDITIONAL )
	{
		memcpy( additional_data, ptr, segData+segLen-ptr );
	}
	
	return 0;
}


char *ShcAcceptorName::outputAcceptorName( const char *network )
{
	if ( ! isDataReady() )
	{
		OTraceError("E-SHC-020005: data not ready yet in getAcceptorName(%s)\n", network);
		sprintf( outputBuffer, "%.4s data not ready yet                 ", network );
		return outputBuffer;
	}
	
	ACCEPTORNAME_LAYOUT *myLayout = getLayoutDef( network );
	memset( outputBuffer, 0, sizeof(outputBuffer) );
	char *ptr=outputBuffer;
	
	ptr += formatIt( ptr, nameSeg, myLayout->lenName );
	ptr += formatIt( ptr, citySeg, myLayout->lenCity );
	ptr += formatIt( ptr, stateSeg, myLayout->lenState );
	ptr += formatIt( ptr, countrySeg, myLayout->lenCountry%10 );
	
	const char *pCC = NULL;
	if ( myLayout->lenCountry == 2 )
	{
		pCC = getCountryChar2();
	}
	else if ( myLayout->lenCountry == 3 )
	{
		pCC = getCountryChar3();
	}
	else if ( myLayout->lenCountry == 13 )	// 3 char in digits
	{
		pCC = getCountryChar3Digits();
	}
	
	if ( ! pCC )
	{
		
		ptr += formatIt( ptr, (char*)pCC, myLayout->lenCountry%10 );
	}
	
	*ptr = '\0';
	
	OTraceError( "D-SHC-020006: Acceptor name for [%s]='%s'\n", network, outputBuffer );
	
	return outputBuffer;
}


char *ShcAcceptorName::generateSegmentData(const char *aName, const char *aCity, const char *aState, const char *aCountry)
{
	setAcceptorName( aName, aCity, aState, aCountry );
//	OTraceDebug( "[%s\\%s\\%s\\%s]\n", nameSeg, citySeg, stateSeg, countrySeg );

	return generateSegmentData();
}


char *ShcAcceptorName::generateSegmentData()
{
	char *ptr = segBuffer;
	memset( segBuffer, 0, sizeof(segBuffer) );
	
	if ( ! isDataReady() )
	{
		return segBuffer;
	}
		
	ptr += snprintf( ptr, sizeof(segBuffer), "%-40s%-20s%-20s%-3s", nameSeg, citySeg, stateSeg, countrySeg );
	
	if ( strlen(additional_data) > 0 )
	{
		ptr += formatIt( ptr, addressSeg, LEN_ADDRESS );
		ptr += formatIt( ptr, postalSeg,  LEN_POSTAL );
		ptr += formatIt( ptr, phoneSeg,   LEN_PHONE );
		
		ptr += formatIt( ptr, storeSeg,   LEN_STORE ); //R028078
		ptr += formatIt( ptr, mallSeg,   LEN_MALL );   //R028078

		ptr += sprintf( ptr, "%s", additional_data );
		ptr += formatIt( ptr, emailSeg,   LEN_EMAIL );	
	        	OTraceDebug("D-SHC-020007: found additional data[%s]\n", additional_data );

	}
	else
	{
		if ( strlen(addressSeg) > 0 )
		{
			ptr += formatIt( ptr, addressSeg, LEN_ADDRESS );
			OTraceDebug("D-SHC-020008: found address data[%s]\n", (ptr-LEN_ADDRESS) );
		}
		if ( strlen(postalSeg) > 0 )
		{
		ptr += formatIt( ptr, postalSeg,  LEN_POSTAL );
			OTraceDebug("D-SHC-020009: found postal data[%s]\n", (ptr-LEN_POSTAL) );
		}
		if ( strlen(phoneSeg) > 0 )
		{
		ptr += formatIt( ptr, phoneSeg,   LEN_PHONE );
			OTraceDebug("D-SHC-020010: found phone data[%s]\n", (ptr-LEN_PHONE) );
		}
		//R028078 >>>
		if ( strlen(storeSeg) > 0 )
		{
		ptr += formatIt( ptr, storeSeg,   LEN_STORE );
			OTraceDebug("D-SHC-020010: found store data[%s]\n", (ptr-LEN_STORE) );
		}
		if ( strlen(mallSeg) > 0 )
		{
		ptr += formatIt( ptr, mallSeg,   LEN_MALL );
			OTraceDebug("D-SHC-020010: found mall data[%s]\n", (ptr-LEN_MALL) );
		}
		//<<< R028078
		if ( strlen(emailSeg) > 0 )
		{
		ptr += formatIt( ptr, emailSeg,   LEN_EMAIL );
			OTraceDebug("D-SHC-020010: found email data[%s]\n", (ptr-LEN_EMAIL) );
		}
	}
	*ptr = '\0';
	
	OTraceDebug("D-SHC-020011: generateSegmentData()=[%d][%s]\n", strlen(segBuffer), segBuffer );
	
	return segBuffer;
}


void ShcAcceptorName::setAcceptorName(const char *aName, const char *aCity, const char *aState, const char *aCountry)
{
	setName( aName );
	setCityName( aCity );
	setStateName( aState );
	setCountryCode( aCountry );
	return;
}


int  ShcAcceptorName::setLayoutDef(const char* network, int lenName, int lenCity, int lenState, int lenCountry)
{
	for ( int i=0; i<MAX_NETWORKS; i++ )
	{
		if (networkLayout[i].lenName > 0 )
		{
			if ( stricmp(networkLayout[i].network, network)!=0 )
				continue;
		}
		
		strncpy( networkLayout[i].network, network, sizeof(acceptorLayout.network)-1 );
		networkLayout[i].lenName    = lenName;
		networkLayout[i].lenCity    = lenCity;
		networkLayout[i].lenState   = lenState;
		networkLayout[i].lenCountry = lenCountry;
		//networkLayout[i].lenAddtional
		return 0;
	}
	
	OTraceError( "E-SHC-020012: number of network exceeds limit[%d]\n", MAX_NETWORKS );
	return -1;
}



ShcAcceptorName::ACCEPTORNAME_LAYOUT* ShcAcceptorName::getLayoutDef( const char* network )
{
	static int last = 0;
	
	if ( stricmp(networkLayout[last].network, network)==0 )
	{
		return &networkLayout[last];
	}
	
	for ( int i=0; networkLayout[i].lenName>0 && i<MAX_NETWORKS; i++ )
	{
		if ( stricmp(networkLayout[i].network, network)==0 )
		{
			last = i;
			return &networkLayout[i];
		}
	}
	
	OTraceWarning("W-SHC-020013: Acceptor Name def for Network name[%s] not found, default used\n", network);
	return &networkLayout[0];
}


char *ShcAcceptorName::getCountryChar2()
{
	static char emptyCC[4]="  ";
	char aCountryCode[LEN_COUNTRY+1] = {0};
	int len = strtrim( countrySeg, countrySeg );
	
	if ( len<2 || len>3 )
	{
		OTraceError("E-SHC-020014: invalid Country Code length[%d]\n", len );
		return emptyCC;
	}
	
	if ( len == 2 )
	{
		return countrySeg;
	}
	
	strcpy( aCountryCode, countrySeg );
	
	if ( isdigit( countrySeg[0]) )
	{
		if (CountryCodeMapTable::countryCodeNumericTo2( atoi(aCountryCode), countrySeg) == 
				CountryCodeMapTable::Successful)
		{
			return countrySeg;
		}
		else
		{
			OTraceError("E-SHC-020015: countryCodeNumericTo2() mapping failed[%s]\n", aCountryCode);
		}
	}
	else
	{
		if (CountryCodeMapTable::countryCode3to2( aCountryCode, countrySeg) == 
					CountryCodeMapTable::Successful)
		{
			return countrySeg;
		}
		else
		{
			OTraceError("E-SHC-020016: countryCode3to2() mapping failed[%s]\n", aCountryCode);
		}
	}
	
	return emptyCC;
}


char *ShcAcceptorName::getCountryChar3()
{
	static char emptyCC[4]="   ";
	char aCountryCode[LEN_COUNTRY+1] = {0};
	int len = strtrim( countrySeg, countrySeg );
	
	strcpy( aCountryCode, countrySeg );
	
	if ( len == 3 )
	{
		if ( !isdigit(countrySeg[0]) )
		{
			return countrySeg;
		}
		
		if (CountryCodeMapTable::countryCodeNumericTo3(atoi(aCountryCode), countrySeg) == 
				CountryCodeMapTable::Successful)
		{
			return countrySeg;
		}
		else
		{
			OTraceError("E-SHC-020017: countryCodeNumericTo3() mapping failed[%s]\n", aCountryCode);
			return countrySeg;
		}
	}
	else if ( len == 2 )
	{
		if (CountryCodeMapTable::countryCode2to3(aCountryCode, countrySeg) == 
			CountryCodeMapTable::Successful)
		{
			return countrySeg;
		}
		else
		{
			OTraceError("E-SHC-020018: countryCode2to3() mapping failed[%s]\n", aCountryCode);
			strcat( countrySeg, " " );
			return countrySeg;
		}
	}
	
	return emptyCC;
}


char *ShcAcceptorName::getCountryChar3Digits()
{
	static char emptyCC[]="000";
	char aCountryCode[LEN_COUNTRY+1] = {0};
	short int iCountryCode = 0;
	
	strcpy( aCountryCode, countrySeg );
	
	strtrim( countrySeg, countrySeg );
	int  len = strlen( countrySeg );

	if ( len == 3 )
	{
		if ( isdigit(countrySeg[0]) )
		{
			return countrySeg;
		}
		
		if (CountryCodeMapTable::countryCode3toNumeric( aCountryCode, &iCountryCode ) != 
				CountryCodeMapTable::Successful)
		{
			OTraceError("E-SHC-020019: countryCode3toNumeric() mapping failed[%s]\n", aCountryCode);
			return emptyCC;
		}	
	}
	else if ( len == 2 )
	{
		if (CountryCodeMapTable::countryCode2toNumeric(aCountryCode, &iCountryCode) != 
			CountryCodeMapTable::Successful)
		{
			OTraceError("E-SHC-020020: countryCode2toNumeric() mapping failed[%s]\n", aCountryCode);
			return emptyCC;
		}
	}
	else
	{
		OTraceError("E-SHC-020021: Invalid Country Code length[%d]\n", len );
		return emptyCC;
	}
	
	sprintf( countrySeg, "%03.3d", iCountryCode );
	return countrySeg;
}


char *ShcAcceptorName::getNameSeg()
{
	strtrim(nameSeg   , nameSeg   ); 
	return nameSeg; 
}

char *ShcAcceptorName::getCitySeg()
{
	strtrim(citySeg   , citySeg   ); 
	return citySeg; 
}

char *ShcAcceptorName::getStateSeg()
{
	strtrim(stateSeg  , stateSeg  ); 
	return stateSeg; 
}

char *ShcAcceptorName::getCountrySeg()
{
	strtrim(countrySeg, countrySeg); 
	return countrySeg; 
}

char *ShcAcceptorName::getPostalSeg()
{
	strtrim(postalSeg , postalSeg ); 
	return postalSeg; 
}

char *ShcAcceptorName::getPhoneSeg()
{
	strtrim(phoneSeg  , phoneSeg  ); 
	return phoneSeg; 
}

char *ShcAcceptorName::getAddressSeg()
{
	strtrim(addressSeg, addressSeg); 
	return addressSeg; 
}

char *ShcAcceptorName::getAdditionalData()
{
	strtrim(additional_data,additional_data);
	return additional_data; 
}

//R028078 >>>
char *ShcAcceptorName::getStoreSeg()
{
	strtrim(storeSeg  , storeSeg  ); 
	return storeSeg; 
}

char *ShcAcceptorName::getMallSeg()
{
	strtrim(mallSeg  , mallSeg  ); 
	return mallSeg; 
}
//<<< R028078

char *ShcAcceptorName::getEmailSeg()
{
	strtrim(emailSeg, emailSeg);
	return emailSeg;
}

int ShcAcceptorName::saveSegment( ShcmsgHeader *hdr )
{
	if ( ! isDataReady() )
	{
		OTraceError("E-SHC-: Acceptor name segment data not ready\n");
		return -1;
	}
	
	char *segData = generateSegmentData();
	
// append segment here !!!

	hdr->setSegmentData(segData, strlen(segData)+1, mySegmentId, ACCEPTOR_NAME);
	
	OTraceDebug( "D-SHC-: saveSegment segid[%d] subid[%d] '%s'\n", mySegmentId, ACCEPTOR_NAME, segData );
	
	if ( hdr->msg.acceptorname[0] == '\0' )
	{
		getAcceptorName(hdr->msg.acceptorname);	//original method
//		strncpy( hdr->acceptorname, outputAcceptorName("SHC"), sizeof(hdr->acceptorname)-1 );
//		hdr->acceptorname[sizeof(hdr->acceptorname)-1] = '\0';
	}
	
	return 0;
}


int ShcAcceptorName::loadSegment( ShcmsgHeader *hdr )
{
	int  segLen=sizeof(segBuffer);
// get ACCEPTOR_NAME segment data here !!!
	hdr->getSegmentData(segBuffer, &segLen, mySegmentId, ACCEPTOR_NAME);
	OTraceDebug( "D-SHC-: loadSegment segid[%d] subid[%d] [%d]'%s'\n", mySegmentId, ACCEPTOR_NAME, segLen, segBuffer );
	
// found segment 
	if ( segLen > 0 )
	{
		return parseSegAcceptorName( segBuffer, segLen );
	}
	
	loadShcmsgAcceptorname( hdr->msg.acceptorname );
	
	return 0;
}





