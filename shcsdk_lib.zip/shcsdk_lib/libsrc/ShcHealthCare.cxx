//
// Copyright (C) 2009 eFunds Corporation ("eFunds").  All Rights Reserved.
// eFunds Canada Corporation is an authorized user.
//
// IST is a registered trademark of eFunds Corporation.  Other brand or
// product names are trademarks or registered trademarks of their respective
// holders.
//
// The information contained herein is the unpublished proprietary property
// of eFunds.  Except as specifically authorized in writing by eFunds, the
// holder of this document shall: i) keep all information contained herein
// confidential, and ii) protect the information, in whole or in part, from
// disclosure and dissemination to all third parties.
//
// This document and the software described in it are furnished under license
// and may be used or copied only in accordance with the terms of such license.
// This document is supplied for information purposes only, is subject to
// change without notice, and should not be construed as a commitment by
// either eFunds Corporation or eFunds Canada Corporation.
//
/*
 * Description:
 *
 *      MODIFICATION HISTORY
 *
 *  Date         SCR            Who        Description
 *  ===========================================================================
*/

static const char _ShcHealthCare_cxx_what[] = "@(#)ShcHealthCare.cxx 1.4 14/08/19 10:03:42";
#include <auto_ptr.h>
#include <dbm.h>
#include <dbm_private.h>
#include <istsafe.h>

#include <ShcHealthCare.h> 
#include <shc.h>
#include <ExceptionObject.h>
ShcHealthCare::ShcHealthCare()
{
	memset(buff, 0x00, sizeof(buff));
	len = 0;
}
ShcHealthCare::~ShcHealthCare()
{

}
void ShcHealthCare::setTagValue(char *TagName, char *TagValue)
{
	snprintf(buff+len, sizeof(buff)-len, "%s%03d%s", TagName, strlen(TagValue), TagValue);
	len += strlen(TagName) + 3 + strlen(TagValue);
}
void ShcHealthCare::setTagValue(char *TagName, int TagValue)
{
	char tbuf[14]={0};
	snprintf(tbuf, sizeof(tbuf),"%d", TagValue);
	snprintf(buff+len, sizeof(buff)-len, "%s%03d%s", TagName, strlen(tbuf), tbuf);
	len += strlen(TagName) + 3 + strlen(tbuf);
}
void ShcHealthCare::setTagValue(char *TagName, double TagValue)
{
	char tbuf[14]={0};
	snprintf(tbuf, sizeof(tbuf),"%0.2f", TagValue);
	snprintf(buff+len, sizeof(buff)-len, "%s%03d%s", TagName, strlen(tbuf), tbuf);
	len += strlen(TagName) + 3 + strlen(tbuf);
}
int ShcHealthCare::getBufferlength()
{
	return len;
}
char *ShcHealthCare::getBuffer()
{
	return (char *)buff;
}
void ShcHealthCare::setIndex(int index)
{
	snprintf(buff+len, sizeof(buff)-len, "HCare%02d[", index);
	len += 8;
}
void  ShcHealthCare::closeIndex()
{
	snprintf(buff+len, sizeof(buff)-len, "]");
	len += 1;
}