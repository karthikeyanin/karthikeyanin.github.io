static char _ShcmsgHeader_cxx_what[] = "@(#) ShcmsgHeader.cxx 1.21.8.6 16/10/21 10:16:29";

/*
 *  Copyright (C) 2004 eFunds Corporation ("eFunds").  All Rights Reserved.     
 *  eFunds Canada Corporation is an authorized user.                            
 *                                                                              
 *  IST is a registered trademark of eFunds Corporation.  Other brand or        
 *  product names are trademarks or registered trademarks of their respective   
 *  holders.                                                                    
 *                                                                              
 *  The information contained herein is the unpublished proprietary property    
 *  of eFunds.  Except as specifically authorized in writing by eFunds, the     
 *  holder of this document shall: i) keep all information contained herein     
 *  confidential, and ii) protect the information, in whole or in part, from    
 *  disclosure and dissemination to all third parties.                          
 *                                                                          
 *  This document and the software described in it are furnished under license  
 *  and may be used or copied only in accordance with the terms of such license.
 *  This document is supplied for information purposes only, is subject to      
 *  change without notice, and should not be construed as a commitment by       
 *  either eFunds Corporation or eFunds Canada Corporation. 
 *
 *
 *                        MODIFICATION HISTORY                  REVIEW
 *
 * SCR#     Who    Date  Description
 * ===========================================================================
 * R028104 	Dipa	29Apr10	routingInfo fix - removed routingInfo references
 */

//File Number 29
 
#include <ist_otrace.h>
#include <tm.h>
#include <sys/timeb.h>
#include <shc.h>
#include <ShcSender.h>
#include <ShcSdkCommon.h>
#include <ShcMsgCache.h>
#include <ShcmsgHelper.h>
#include <ShcAppBase.h>
#include <ShcmsgHeader.h>
#include <ShcHelper.h>
#include <ShcBin.h>
#include <ist_seg_list.h>
#include <shcseg.h>
#include <ist_seg_name.h>
#include <ist_seg_elf_id_map.h>
#include <ist_seg_msg_replication_data.h>


void ShcmsgHeader::reset()
{
        memset(&msg, 0, sizeof(ShcmsgWithSegment));
        segListFlag = reqSegListFlag = origSegListFlag = 0;

        if( segList != NULL ) {
                delete (segList);
                segList = NULL;
        }
        if( reqSegList != NULL ) {
                delete (reqSegList);
                reqSegList = NULL;
        }
        if( origSegList != NULL ) {
                delete (origSegList);
                origSegList = NULL;
        }
        if( origMsg != NULL ) {
                delete (origMsg);
                origMsg = NULL;
        }
        if( reqMsg != NULL ) {
                delete (reqMsg);
                reqMsg = NULL;
        }
        pindata = NULL;
        emvbuf = NULL;
        if( transfereeShcBin != NULL ) {
                delete (transfereeShcBin);
                transfereeShcBin = NULL;
        }
}

int ShcmsgHeader::allocateAndCopyReqMsg(struct shcmsg *newmsg)
{
	if (reqMsg)
		delete reqMsg;
	if (reqSegList)
	{
		delete reqSegList;
		reqSegList = NULL;
	}
		
	struct ShcmsgWithSegment *tmpBuf = NULL;
	
	if( newmsg )
	{
		if ((tmpBuf = new struct ShcmsgWithSegment) == NULL)
			return -1;
	
		memcpy(&tmpBuf->msg, newmsg, truelength(newmsg));
		reqMsg = &tmpBuf->msg;
	}
	
	reqSegListFlag &= ~SHCMSG_HEADER_SEG_PARSED;
	return 0;
}

int ShcmsgHeader::allocateAndCopyOrigMsg(struct shcmsg *newmsg)
{
	if (origMsg)
		delete origMsg;
	if (origSegList)
	{
		delete origSegList;
		origSegList = NULL;
	}
	
	struct ShcmsgWithSegment *tmpBuf = NULL;
	
	if( newmsg )
	{
		if ((tmpBuf = new struct ShcmsgWithSegment) == NULL)
			return -1;
	
		memcpy(&tmpBuf->msg, newmsg, truelength(newmsg));
		origMsg = &tmpBuf->msg;
	}
	
	origSegListFlag &= ~SHCMSG_HEADER_SEG_PARSED;
	return 0;
}

int ShcmsgHeader::toShcStruct(struct shc *shcP)
{
	shcP->shcerr = shcerr;
	shcP->time_in = time_in;
	shcP->time_out = time_out;
	shcP->eventid = eventId;
	shcP->applmbid = applMailboxId;

	if (issShcBin)
	{
		shcP->issbin = issShcBin->binPkg;
		shcP->pin = issShcBin->pin;
		shcP->key = issShcBin->key;
	}
	else
	{
		shcP->issbin = NULL;
		shcP->pin = NULL;
		shcP->key = NULL;
	}
	
	if (acqShcBin)
		shcP->acqbin = acqShcBin->binPkg;
	else
		shcP->acqbin = NULL;
		
	if (transfereeShcBin)
		shcP->trabin = transfereeShcBin->binPkg;
	else
		shcP->trabin = NULL;

	shcP->pindata = pindata;
	
	memcpy(&shcP->msg, &msg, truelength(NULL));
	return 0;
}
int ShcmsgHeader::fromShcStruct(struct shc *shcP)
{
    shcerr = shcP->shcerr;
    time_in = shcP->time_in;
    time_out = shcP->time_out;
    eventId = shcP->eventid;
    applMailboxId = shcP->applmbid;

	if (shcP->issbin)
	{
		if (!issShcBin)
			issShcBin=(ShcBin *)shcHelperRegister.getTargetObj(SHC_ShcBin);
	    issShcBin->binPkg = shcP->issbin;
	    issShcBin->pin = shcP->pin;
	    issShcBin->key = shcP->key;
	}
	if (shcP->acqbin)
	{
		if (!acqShcBin)
			acqShcBin=(ShcBin *)shcHelperRegister.getTargetObj(SHC_ShcBin);
	    acqShcBin->binPkg = shcP->acqbin;
	}
	if (shcP->trabin)
	{
		if (!transfereeShcBin)
			transfereeShcBin=(ShcBin *)shcHelperRegister.getTargetObj(SHC_ShcBin);
	    transfereeShcBin->binPkg = shcP->trabin;
	}
	
    pindata = shcP->pindata;

    memcpy(&msg, &shcP->msg, truelength(&shcP->msg));
	if (segListFlag & SHCMSG_HEADER_SEG_PARSED)
	{
		if(segList)
			delete segList;
		segList = NULL;
		segListFlag = 0;
	}
    return 0;
}


int ShcmsgHeader::isVoidTxn()
{
	return msg.shc_devcap & SH_DEVCAP_SHC_VOID;
}

ShcmsgHeader::ShcmsgHeader(struct shcmsg *newMsg)
{
	static int minMsgWithSegLen = sizeof(struct shcmsg) 
						+ sizeof(struct  shcseg) + sizeof(struct shcsegstart);

	int len = truelength(newMsg);
	if (len <= minMsgWithSegLen)
	{
		newMsg->device_cap &= ~SH_DEVCAP_USER_SEGMENT;
		len = sizeof(struct shcmsg);
	}

	memset(&msg, 0, sizeof(ShcmsgWithSegment));

	memcpy(&msg, newMsg, truelength(newMsg));

	origMsg = NULL;
	reqMsg = NULL;
	pindata = NULL;
	emvbuf = NULL;
	transfereeShcBin = NULL;
	segList = reqSegList = origSegList = NULL;
	segListFlag = reqSegListFlag = origSegListFlag = 0;
}

ShcmsgHeader::ShcmsgHeader(ShcmsgHeader &hdr):ShcHeader(hdr)
{
	memcpy(&msg, &hdr.msg, hdr.truelength());
	origMsg = NULL;
	//  >>> R029858
	segList = reqSegList = origSegList = NULL;
	segListFlag = reqSegListFlag = origSegListFlag = 0;
	//  <<< R029858
	allocateAndCopyOrigMsg(hdr.origMsg);
	reqMsg = NULL;
	allocateAndCopyReqMsg(hdr.reqMsg);
	pindata = hdr.pindata;
	emvbuf = NULL;		// how to copy this ???
        if (!hdr.transfereeShcBin)
                transfereeShcBin = NULL;
        else
        {
//		transfereeShcBin = NULL;
    transfereeShcBin = (ShcBin *)shcHelperRegister.getTargetObj(SHC_ShcBin);
    *transfereeShcBin = *hdr.transfereeShcBin;
	}
}

ShcmsgHeader::ShcmsgHeader()
{
	memset(&msg, 0, sizeof(ShcmsgWithSegment));
	origMsg = NULL;
	reqMsg = NULL;
	pindata = NULL;
	emvbuf = NULL;
	transfereeShcBin = NULL;

	segList = reqSegList = origSegList = NULL;
	segListFlag = reqSegListFlag = origSegListFlag = 0;
	
}


ShcmsgHeader::~ShcmsgHeader()
{
	if (reqMsg)
	{
		delete reqMsg;
		reqMsg = NULL;
		OTraceDebug("D-SHC-029001: Free *reqMsg in ~ShcmsgHeader()\n");
	}

	if (origMsg)
	{
		delete origMsg;
		origMsg = NULL;
		OTraceDebug("D-SHC-029002: Free *origMsg in ~ShcmsgHeader()\n");
	}
	if (transfereeShcBin)
	{
		delete transfereeShcBin;
		transfereeShcBin = NULL;
	}
	if (segList)
		delete segList;
	if (origSegList)
		delete origSegList;
	if (reqSegList)
		delete reqSegList;
}

void ShcmsgHeader::setSenderId(int newSenderId)
{
	 msg.senderid = newSenderId;
}

void ShcmsgHeader::setTxnStartTime()
{
	struct timeb tmpTime;
	ftime(&tmpTime);

	if ((shcmsgIsRequest(&msg)) && msg.txn_start_time <= 0 && msg.msgtype != 0)
	{
		struct tm *tmpGmtime = gmtime(&tmpTime.time);
		msg.txn_start_time =tmpGmtime->tm_hour*10000000 +
									tmpGmtime->tm_min*100000 +
									tmpGmtime->tm_sec*1000 +
									tmpTime.millitm;
		OTraceDebug("D-SHC-029003 : msg.txn_start_time [%d]  msg.msgtype [%d]\n",msg.txn_start_time,msg.msgtype);
		if(shcSetTxnStartDate){
			char tbuf[10]={0};
			snprintf(tbuf, sizeof(tbuf), "%04d%02d%02d", tmpGmtime->tm_year+1900, tmpGmtime->tm_mon+1, tmpGmtime->tm_mday);
			setSegmentData((char *)tbuf, sizeof(tbuf), NETWORK_SETTLEMENT_DATA_id, TXN_START_DATE);
		}
	}
	if (shcmsgIsResponse(&msg))
	{
		char buf[32];
		snprintf(buf, sizeof(buf), "%ld.%3.3d", tmpTime.time, (int)tmpTime.millitm);
		setSegmentData(buf, strlen(buf), NETWORK_SETTLEMENT_DATA_RESP_id, TS_FROM_ISSUER);
	}
}

int ShcmsgHeader::setTransfereeShcBin(char *bin)
{
	if (!transfereeShcBin)
		transfereeShcBin = (ShcBin *)shcHelperRegister.getTargetObj(SHC_ShcBin);
	return transfereeShcBin->setBinPkg(bin);
}

int ShcmsgHeader::transfereeBinValid()
{
	if (transfereeShcBin && transfereeShcBin->binPkg)
		return 1;
	else
		return 0;
}
IstSegList *ShcmsgHeader::getSegList()
{
	if (segListFlag& SHCMSG_HEADER_SEG_PARSED)
	{
		return segList;
	}
	try
	{
		segList = new IstSegList();
		if (shcmsgHasSegment(&msg) && segList)
		{
			segList->unflattenSegMemcpy_shc_segments(reinterpret_cast<struct shcsegment*>(shcmsgLocateSegmentStart(&msg)));
		}
		segListFlag |= SHCMSG_HEADER_SEG_PARSED;
	}
	catch(...)
	{
		OTraceError("E-SHC-029003:Error parsing segment, return NULL\n");
		return NULL;
	}
	return segList;
}
IstSegList *ShcmsgHeader::getOrigSegList()
{
	if (!origMsg)
		return NULL;
		
	if (origSegListFlag& SHCMSG_HEADER_SEG_PARSED)
		return origSegList;
	try
	{
		origSegList = new IstSegList();
		if (shcmsgHasSegment(origMsg))
		{
			origSegList->unflattenSegMemcpy_shc_segments(reinterpret_cast<struct shcsegment*>(shcmsgLocateSegmentStart(origMsg)));
		}
		origSegListFlag |= SHCMSG_HEADER_SEG_PARSED;
	}
	catch(...)
	{
		OTraceError("E-SHC-029004:Error parsing segment, return NULL\n");
		return NULL;
	}
	return origSegList;
}
IstSegList *ShcmsgHeader::getReqSegList()
{
	if (!reqMsg)
		return NULL;
	if (reqSegListFlag& SHCMSG_HEADER_SEG_PARSED)
		return reqSegList;
	try
	{
		reqSegList = new IstSegList();
		if (shcmsgHasSegment(reqMsg))
		{
			reqSegList->unflattenSegMemcpy_shc_segments(reinterpret_cast<struct shcsegment*>(shcmsgLocateSegmentStart(reqMsg)));
		}
		reqSegListFlag |= SHCMSG_HEADER_SEG_PARSED;
	}
	catch(...)
	{
		OTraceError("E-SHC-029004:Error parsing segment, return NULL\n");
		return NULL;
	}
	return reqSegList;
}

int ShcmsgHeader::setSegList(IstSegList *newList)
{
	if (newList == segList)
		return 0;

	if (segList)
		delete segList;
	
	segList = newList;
	
	segListFlag |= SHCMSG_HEADER_SEG_PARSED;
	return 0;
}
int ShcmsgHeader::setReqSegList(IstSegList *newList)
{
	if (newList == reqSegList)
		return 0;
	
	if (reqSegList)
		delete reqSegList;	//	---	IST_S761SP7-167 delete reqSegList instead of segList
	
	reqSegList = newList;
	
	reqSegListFlag |= SHCMSG_HEADER_SEG_PARSED;
	return 0;
}
int ShcmsgHeader::setOrigSegList(IstSegList *newList)
{
	if (newList == origSegList)
		return 0;
	
	if (origSegList)
		delete origSegList;
	
	origSegList = newList;
	
	origSegListFlag |= SHCMSG_HEADER_SEG_PARSED;
	return 0;
}
int ShcmsgHeader::truelength(struct shcmsg *_msg)
{
	struct  shcseg  *seg = NULL;

	if (!_msg)
	{
		IstSegList *sl = getSegList();
		sl->flattenSegMemcpy_shc_segments((struct shcsegment *)segment);
		seg = (struct shcseg *)segment;
		_msg = &msg;
	}
	else if(shcmsgHasSegment(_msg))
    {
        seg = shcmsgLocateSegmentStart(_msg);
    }

	
	
    if(seg &&(seg->nsegments > 0))
    {
    	_msg->device_cap |= SH_DEVCAP_USER_SEGMENT;
        return(sizeof(struct shcmsg) + seg->totalsize);
    }
    else
        _msg->device_cap &= ~SH_DEVCAP_USER_SEGMENT;
    

    return(sizeof(struct shcmsg));
}

int ShcmsgHeader::appendReplicationData(const char* service, const char* msgtosave, int msglen){
        static int lSegmentId = ElfIdMap::elf_to_id(IST_SEG_MSG_REPLICATION_DATA);
        IstSegMsgReplicationData* msgReplSegObj = (IstSegMsgReplicationData*) getSegmentObj( lSegmentId, IST_SEG_CREATE );
        if ( msgReplSegObj ){
                msgReplSegObj->appendData(service, (char*)msgtosave, msglen);
                OTraceTitleDump("[message replication segment for service(%s) added to shcmsg(%s)]\n",
                                service,
                                msg.shclog_id );
                OTraceHexDump((unsigned char*)msgtosave, msglen );
        }else{
                OTraceError( "E-SHC-MR-10000 unable to create message replication segment object\n" );
                return -1;
        }
        return 0;
}
int ShcmsgHeader::getMsgSiteId()
{
        if (msg.site_id == 0)
        {
                msg.site_id = mbGetSiteId();
        }
        return (msg.site_id);
}

