/*
 *  Copyright (C) 2004 eFunds Corporation ("eFunds").  All Rights Reserved.
 *  eFunds Canada Corporation is an authorized user.
 *
 *  IST is a registered trademark of eFunds Corporation.  Other brand or
 *  product names are trademarks or registered trademarks of their respective
 *  holders.
 *
 *  The information contained herein is the unpublished proprietary property
 *  of eFunds.  Except as specifically authorized in writing by eFunds, the
 *  holder of this document shall: i) keep all information contained herein
 *  confidential, and ii) protect the information, in whole or in part, from
 *  disclosure and dissemination to all third parties.
 *
 *  This document and the software described in it are furnished under license
 *  and may be used or copied only in accordance with the terms of such license.
 *  This document is supplied for information purposes only, is subject to
 *  change without notice, and should not be construed as a commitment by
 *  either eFunds Corporation or eFunds Canada Corporation.
 */
/*
 *
 *                        MODIFICATION HISTORY                  REVIEW
 *
 *      SPR#    Who     Date    Description                     Who     Date
 * ===========================================================================
 */

//File Number 180

#if defined( WIN32 )
#       define SHCDLLEXPORT __declspec(dllexport)
#else
#       define SHCDLLEXPORT
#endif


#include <stdio.h>
#include <sys/types.h>
#include <time.h>
#include <oasis.h>
#include <ist_otrace.h>
#include <shcfmt.h>
#include <shc.h>
#include <string.h>
#include <istsafe.h>
#include <dbm_private.h>

int parseMSSegment(char *f104MTData, SenderReciverData *sender, SenderReciverData *receiver, TxnData *txnData)
{
    char tagValue[50], senderDataBuff[200], receiverDataBuff[200], txnDataBuff[200];
    int tagValueLen=0, length=0, retval;

    memset(receiverDataBuff, 0x00, sizeof(receiverDataBuff));
    memset(senderDataBuff, 0x00, sizeof(senderDataBuff));
    memset(txnDataBuff, 0x00, sizeof(txnDataBuff));

    retval = getTagValue(f104MTData, TAG_RECEIVER_DATA, receiverDataBuff, sizeof(receiverDataBuff));
    if(retval<=0)
    {
	OTraceDebug("D-VFMT-0111 failed to get receiver data from money send segment.\n");
        return -1;
    }
    length = retval;
    retval = getTagValue(f104MTData+length, TAG_SENDER_DATA, senderDataBuff, sizeof(senderDataBuff));
    if(retval<=0)
    {
	OTraceDebug("D-VFMT-0112 failed to get sender data from money send segment.\n");
        return -1;
    }
    length += retval;
    length += getTagValue(f104MTData+length, TAG_TXN_DATA, txnDataBuff, sizeof(txnDataBuff));

    parseSRSegment(receiverDataBuff, receiver);
    parseSRSegment(senderDataBuff, sender);
    parseTXNSegment(txnDataBuff, txnData);
    return(1);
}

int getTagValue(char *srcData, int tagNumber, char *tagValue, int tagValueLen)
{
    char *ptr=NULL, tagBuff[4], lenbuff[4], tagNumbuff[4];
    int ret =0, len=0, TagNum;

    memset(tagBuff, 0x00, sizeof(tagBuff));
    memset(lenbuff, 0x00, sizeof(lenbuff));
    memset(tagNumbuff, 0x00, sizeof(tagNumbuff));

    switch(tagNumber)
    {
        case TAG_SENDER_DATA:
            strncpy(tagBuff, srcData, 2);
            TagNum = atoi(tagBuff);
            if(TagNum == TAG_SENDER_DATA/100)
            {
                strncpy(lenbuff, srcData+2, 3);
                len =  atoi(lenbuff);
                //strncpy(tagValue, srcData+5, len);
                len = (len < sizeof(tagValue)) ?len :sizeof(tagValue);
                istsafe_strcpy( tagValue, len,  srcData+5); //Veracode fix
                ret = IstSafeInt(len+2+3).getInt();
            }
            else
                ret = -1;
            break;
        case TAG_RECEIVER_DATA:
            strncpy(tagBuff, srcData, 2);
            TagNum = atoi(tagBuff);
            if(TagNum == TAG_RECEIVER_DATA/100)
            {
                strncpy(lenbuff, srcData+2, 3);
                len =  atoi(lenbuff);
                //strncpy(tagValue, srcData+5, len);
                len = (len < sizeof(tagValue)) ?len :sizeof(tagValue);
                istsafe_strcpy( tagValue, len,  srcData+5); //Veracode fix
                ret = IstSafeInt(len+2+3).getInt();
            }
            else
                ret = -1;
            break;
        case TAG_TXN_DATA:
            strncpy(tagBuff, srcData, 2);
            TagNum = atoi(tagBuff);
            if(TagNum == TAG_TXN_DATA/100)
            {
                strncpy(lenbuff, srcData+2, 3);
                len =  atoi(lenbuff);
                //strncpy(tagValue, srcData+5, len);
                len = (len < sizeof(tagValue)) ?len :sizeof(tagValue);
                istsafe_strcpy( tagValue, len,  srcData+5); //Veracode fix
                ret = IstSafeInt(len+2+3).getInt();
            }
            else
                ret = -1;
            break;
        default:
            ret = -1;
            break;
    }
    return(ret);
}
int  parseSRSegment(char *srcData, SenderReciverData *dataBuff)
{
    char *ptr=NULL, tagBuff[4], lenbuff[4], tagNumbuff[4];
    int len=0, TagNum;

    memset(tagBuff, 0x00, sizeof(tagBuff));
    memset(lenbuff, 0x00, sizeof(lenbuff));
    memset(tagNumbuff, 0x00, sizeof(tagNumbuff));

    if(srcData==NULL || *srcData=='\0')
        return(-1);

    for(;srcData!=NULL && *srcData!='\0';)
    {
        strncpy(tagBuff, srcData, 2);
        srcData += 2;
        TagNum = atoi(tagBuff);
        switch(TagNum)
        {
            case TAG_FIRST_NAME:
                strncpy(lenbuff, srcData, 2);
                srcData += 2;
                len =  atoi(lenbuff);
                //strncpy(dataBuff->FirstName, srcData, len);
                len = (len < sizeof(dataBuff->FirstName)) ?len :sizeof(dataBuff->FirstName);
                istsafe_strcpy( dataBuff->FirstName, len,  srcData); //Veracode fix
                srcData += len;
                break;
            case TAG_MIDDLE_NAME:
                strncpy(lenbuff, srcData, 2);
                srcData += 2;
                len =  atoi(lenbuff);
                //strncpy(dataBuff->MiddleName, srcData, len);
                len = (len < sizeof(dataBuff->MiddleName)) ?len :sizeof(dataBuff->MiddleName);
                istsafe_strcpy( dataBuff->MiddleName, len,  srcData); //Veracode fix
                srcData += len;
                break;
            case TAG_LAST_NAME:
                strncpy(lenbuff, srcData, 2);
                srcData += 2;
                len =  atoi(lenbuff);
                //strncpy(dataBuff->LastName, srcData, len);
                len = (len < sizeof(dataBuff->LastName)) ?len :sizeof(dataBuff->LastName);
                istsafe_strcpy( dataBuff->LastName, len,  srcData); //Veracode fix
                srcData += len;
                break;
            case TAG_STREET_ADDRESS:
                strncpy(lenbuff, srcData, 2);
                srcData += 2;
                len =  atoi(lenbuff);
                //strncpy(dataBuff->StreetAddress, srcData, len);
                len = (len < sizeof(dataBuff->StreetAddress)) ?len :sizeof(dataBuff->StreetAddress);
                istsafe_strcpy( dataBuff->StreetAddress, len,  srcData); //Veracode fix
                srcData += len;
                break;
            case TAG_CITY:
                strncpy(lenbuff, srcData, 2);
                srcData += 2;
                len =  atoi(lenbuff);
                //strncpy(dataBuff->City, srcData, len);
                len = (len < sizeof(dataBuff->City)) ?len :sizeof(dataBuff->City);
                istsafe_strcpy( dataBuff->City, len,  srcData); //Veracode fix
                srcData += len;
                break;
            case TAG_STATE:
                strncpy(lenbuff, srcData, 2);
                srcData += 2;
                len =  atoi(lenbuff);
                //strncpy(dataBuff->StateProvinceCode, srcData, len);
                len = (len < sizeof(dataBuff->StateProvinceCode)) ?len :sizeof(dataBuff->StateProvinceCode);
                istsafe_strcpy( dataBuff->StateProvinceCode, len,  srcData); //Veracode fix
                srcData += len;
                break;
            case TAG_CNTRY:
                strncpy(lenbuff, srcData, 2);
                srcData += 2;
                len =  atoi(lenbuff);
                //strncpy(dataBuff->Country, srcData, len);
                len = (len < sizeof(dataBuff->Country)) ?len :sizeof(dataBuff->Country);
                istsafe_strcpy( dataBuff->Country, len,  srcData); //Veracode fix
                srcData += len;
                break;
            case TAG_ACCT_NUM:
                strncpy(lenbuff, srcData, 2);
                srcData += 2;
                len =  atoi(lenbuff);
                //strncpy(dataBuff->AccountNumber, srcData, len);
                len = (len < sizeof(dataBuff->AccountNumber)) ?len :sizeof(dataBuff->AccountNumber);
                istsafe_strcpy( dataBuff->AccountNumber, len,  srcData); //Veracode fix
                srcData += len;
                break;
            case TAG_IDENTIFICATION_NUMBER:
                strncpy(lenbuff, srcData, 2);
                srcData += 2;
                len =  atoi(lenbuff);
                //strncpy(dataBuff->IdentificationNumber, srcData, len);
                len = (len < sizeof(dataBuff->IdentificationNumber)) ?len :sizeof(dataBuff->IdentificationNumber);
                istsafe_strcpy( dataBuff->IdentificationNumber, len,  srcData); //Veracode fix
                srcData += len;
                break;
            case TAG_POSTAL_CODE:
                strncpy(lenbuff, srcData, 2);
                srcData += 2;
                len =  atoi(lenbuff);
                //strncpy(dataBuff->postalCode, srcData, len);
                len = (len < sizeof(dataBuff->postalCode)) ?len :sizeof(dataBuff->postalCode);
                istsafe_strcpy( dataBuff->postalCode, len,  srcData); //Veracode fix
                srcData += len;
                break;
            default:
                strncpy(lenbuff, srcData, 2);
                srcData += 2;
                len =  atoi(lenbuff);
                srcData += len;
                break;
        }
    }
    return(1);
}
int  parseTXNSegment(char *srcData, TxnData *dataBuff)
{
    char *ptr=NULL, tagBuff[4], lenbuff[4], tagNumbuff[4];
    int len=0, TagNum;

    memset(tagBuff, 0x00, sizeof(tagBuff));
    memset(lenbuff, 0x00, sizeof(lenbuff));
    memset(tagNumbuff, 0x00, sizeof(tagNumbuff));

   if(srcData==NULL || *srcData=='\0')
        return(-1);
    for(;srcData!=NULL && *srcData!='\0';)
    {
        strncpy(tagBuff, srcData, 2);
        srcData += 2;
        TagNum = atoi(tagBuff);
        switch(TagNum)
        {
            case TAG_SOURCE_OF_FUNDS:
                strncpy(lenbuff, srcData, 2);
                srcData += 2;
                len =  atoi(lenbuff);
                //strncpy(dataBuff->FundingSrc, srcData, len);
                len = (len < sizeof(dataBuff->FundingSrc)) ?len :sizeof(dataBuff->FundingSrc);
                istsafe_strcpy( dataBuff->FundingSrc, len,  srcData); //Veracode fix
                srcData += len;
                break;
            default:
                strncpy(lenbuff, srcData, 2);
                srcData += 2;
                len =  atoi(lenbuff);
                srcData += len;
                break;
        }
    }
    return(1);
}


/*
 * End of file shc_sender.cxx
 */
