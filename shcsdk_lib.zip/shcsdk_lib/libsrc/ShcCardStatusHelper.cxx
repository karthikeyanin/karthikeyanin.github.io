static char _ShcCardStatusHelper_cxx_what[] = "";


/*
 *  Copyright (C) 2004 eFunds Corporation ("eFunds").  All Rights Reserved.     
 *  eFunds Canada Corporation is an authorized user.                            
 *                                                                              
 *  IST is a registered trademark of eFunds Corporation.  Other brand or        
 *  product names are trademarks or registered trademarks of their respective   
 *  holders.                                                                    
 *                                                                              
 *  The information contained herein is the unpublished proprietary property    
 *  of eFunds.  Except as specifically authorized in writing by eFunds, the     
 *  holder of this document shall: i) keep all information contained herein     
 *  confidential, and ii) protect the information, in whole or in part, from    
 *  disclosure and dissemination to all third parties.                          
 *                                                                          
 *  This document and the software described in it are furnished under license  
 *  and may be used or copied only in accordance with the terms of such license.
 *  This document is supplied for information purposes only, is subject to      
 *  change without notice, and should not be construed as a commitment by       
 *  either eFunds Corporation or eFunds Canada Corporation. 
 *
 *
 *                        MODIFICATION HISTORY                  REVIEW
 *
 *	SPR#	Who	Date	Description			Who	Date   
 * ===========================================================================
*/

/* File Number 30 */

#include <stdio.h>
#include <string.h>
#include <ist_types.h>
#include <istiso.h>
#include <oasis.h>
#include <oasisenv.h>
#include <dbm.h>
#include <tm.h>
#include <dbm_private.h>
#include <oc/oc_string.h>
#include <ist_otrace.h>
#include <Ccard_scheme.h>
#include <Cinstitution.h>
#include <shc_callback.h>
#include <rules.h>
#include <authnumber.h>
#include <shcmsgdef.h>
#include <security.h>
#include <shc.h>
#include <shcpreauth.h>
#include <ic/ic_shcmsg.h>
#include <ic/ic_instid.h>
#include <ic/ic_bin.h>
#include <ic/ic_pan.h>
//#include <emvchipcond.h>
#include <ShcSender.h>
#include <istcurrency.h>
#include <shc500std.h>

#include <ShcSdkCommon.h>
#include <ShcCardStatusHelper.h>
#include <ShcKeyHelper.h>
#include <ShcTimerHelper.h>
#include <hotrange.h>
#include <CShcLog.h>
#include <ShcDKEHelper.h>
#include <ShcAppBase.h>
#include <ShcHelper.h>
#include <ShcBin.h>
#include <ShcSafIOHelper.h>
#include <BusinessDay.h>
#include <ShcmsgFMHeader.h>	// --- R026113
#include <BrandBlocked.h>
#include <ist_seg_name.h> //R027876
#include <ist_seg_elf_id_map.h> //R027876
#include <ist_seg_id.h> //R027876
#include <shccardstatus.h>
#include <shccardstatusmap.h>
#include <ISTRulCardStatusMap.h>
#include <ISTRulCardStatusMapShmReader.h>


ShcCardStatusHelper::ShcCardStatusHelper()
{
        _smtSelOne = NULL;
        _dbConn = NULL;
}

void ShcCardStatusHelper::dbInit()
{
	if( _dbConn != NULL )
		return;

	_dbConn = new DBMConn(dbm_dbconn);
}

int ShcCardStatusHelper::checkCardStatus (ShcmsgHeader *header, struct FResult *result,char *flag_to_trace_nodata_tbl)
{
	char instid[11];
	char userbinid[11];

	ISTCardStatusMap keyObj;
	ISTCardStatusMapShmReader readObj;
	char *ptr;
	ptr = flag_to_trace_nodata_tbl;
	
	dbInit();
	memset( _ind, 0, sizeof(_ind) );

	strcpy(instid,header->issShcBin->binPkg->bin.institutionid);
	strcpy(userbinid,header->issShcBin->binPkg->bin.userbinid);

	try
	{
		int sno = 1;
		int cnt = 0;
		memset( _ind, 0, sizeof(_ind) );

		if(!_smtSelOne)
		{
			_smtSelOne = _dbConn->getStmt();
			_smtSelOne->prepare
			(
			"SELECT "
			"Status ,"
			"Effective_to ,"
			"Effective_from "
			"FROM shccardstatus "
			"WHERE Pan = ? and siteid = ?"
			 );

			_smtSelOne->bindCol(  sno++, DBM_STRINGTYPE, (_status), sizeof(_status), &_ind[cnt++] );
			_smtSelOne->bindCol(  sno++, effective );
			_smtSelOne->bindCol(  sno++, effectivefrom );
			_smtSelOne->bindParam( 1, DBM_PANTOKENTYPE, Pan, sizeof(Pan),NULL );
			_smtSelOne->bindParam(  2, siteid );
		}
		memset(Pan,0x00,sizeof(Pan));
		site_id=0;
		siteid.setValue(0);
		memset(_status,0x00,sizeof(_status));
		effective.setValue(0);
		effectivefrom.setValue(0);

		memcpy(Pan,header->msg.pan,sizeof(Pan));
		shc_normalizepan(Pan);
		site_id=header->getMsgSiteId();
		siteid.setValue(site_id);
		OTraceDebug("D-SHCCARDSTATUS-61000: Inside checkCardStatus for pan [%s] , siteid[%d] with instid [%s] and userbinid [%s]\n",shcApp->shcHelperObj->shc_maskpan(Pan),site_id,instid,userbinid);

		_smtSelOne->execute();
                int rc = _smtSelOne->fetch();
		_smtSelOne->close();
                if (rc == DBM_NO_DATA)
                {
			if(ptr !=NULL)
				*ptr = 'C';
			else
				OTraceDebug("D-SHCCARDSTATUS-61001: No Record in shccardstatus\n");		
			return 0;
                }
		else if( rc != DBM_SUCCESS )
		{
		 	OTraceError("E-SHCCARDSTATUS-61002: Cannot fetch from shccardstatus\n");
			return ( -1 );
		}

	}
	catch( const DBMException& e )
	{
		OTraceError
		( 
			"E-SHCCARDSTATUS-61003: Caught exception in getCount," 
			"native error=%d, sqlstate=%.5s, msg=%s\n",
			e.getNativeError(), e.getSQLState().data(), e.getErrMsg().data() 
		);
		return ( -2 );
	}
	OCDateTime current;
	effective.getValue(effective_to);
	effectivefrom.getValue(effective_from);
	OTraceDebug("D-SHCCARDSTATUS-61004: Status [%s] effective date[%s] current [%s] effective from [%s] in shccardstatus \n",_status,(char*)(effective_to).asString(),(char *)(current).asString(), (char *)(effective_from).asString());

	if(strlen(_status))
	{

		//here we need call the shccardstatusmap rule for get  the respcode 
		OCString inst_id;
		OCString userbin_id;
		OCString status;
		inst_id = userbin_id = "";

		inst_id = (char *)instid;
		userbin_id = (char *)userbinid ;

		status = (char *) _status;
		OTraceDebug("D-SHCCARDSTATUS-61004: Status [%s][%d] InstId[%s][%d] userbinid [%s][%d] in shccardstatus \n",status.data(),status.length(),inst_id.data(),inst_id.length(),userbin_id.data(),userbin_id.length());

		if ( (effective_to<current) && (current>effective_from) )
		{
			strcpy(result->status,_status);
			result->eff_to = effective_to;
			result->eff_from = effective_from;
			return (3);
		}

		keyObj.setInstId(inst_id);
		keyObj.setUserBinId(userbin_id);
		keyObj.setStatus(status);
		if( readObj.getData(keyObj) < 0 )
		{
			if(ptr !=NULL)
				*ptr = 'M';
			else
				OTraceDebug( "D-SHCCARDSTATUS-61005: Response Code not Found\n");
			return 0;
		}
		strcpy(result->status,_status);
		result->respCode=keyObj.getResponseCode();
		OTraceDebug( "D-SHCCARDSTATUS-61006: Status [%s] RespCode [%d] in shccardstatus \n",result->status,result->respCode); 
		return(1);
	}
	else 
		OTraceDebug( "D-SHCCARDSTATUS-61007 : Status is NULL in shccardstatus \n "); 
	return(0);
}

