/*
 *  Copyright (C) 2004 eFunds Corporation ("eFunds").  All Rights Reserved.     
 *  eFunds Canada Corporation is an authorized user.                            
 *                                                                              
 *  IST is a registered trademark of eFunds Corporation.  Other brand or        
 *  product names are trademarks or registered trademarks of their respective   
 *  holders.                                                                    
 *                                                                              
 *  The information contained herein is the unpublished proprietary property    
 *  of eFunds.  Except as specifically authorized in writing by eFunds, the     
 *  holder of this document shall: i) keep all information contained herein     
 *  confidential, and ii) protect the information, in whole or in part, from    
 *  disclosure and dissemination to all third parties.                          
 *                                                                          
 *  This document and the software described in it are furnished under license  
 *  and may be used or copied only in accordance with the terms of such license.
 *  This document is supplied for information purposes only, is subject to      
 *  change without notice, and should not be construed as a commitment by       
 *  either eFunds Corporation or eFunds Canada Corporation. 
 */
/*
#pragma ident "@(#) NetworkInfo.cxx 1.5 20/01/30 13:02:25";
 *
 *                        MODIFICATION HISTORY                  REVIEW
 *
 *	SPR#	Who	Date	Description
 * ===========================================================================
 *R000000 ztang	08Jun11	Created 
 *R030556 dipa  13Jun12 SHM versioning b/w compatibility
 *R030643 las   20Jun12 add routing info in network info
 */

//File Number 173
#if defined( WIN32 )
#       define SHCDLLEXPORT __declspec(dllexport)
#else
#       define SHCDLLEXPORT
#endif



#include <stdio.h>
#include <sys/timeb.h>
#include <oasis.h>
#include <rules.h>
#include <shc.h>
#include <string.h>
#include <ic/ic_bin.h>
#include<ic/ic_instid.h>
#include <ctype.h>
#include <ist_otrace.h>
#include <mt_extbin.h>
#include <IssProfile.h>
#include <InstProfile.h>
#include <shc.h>
#include <stl/set.h>
#include <oc/oc_string.h>
#include <ShcmsgHelper.h>
#include <ShcAppBase.h>

#include <BinRoute.h>
#include <ShcKeyHelper.h>
#include <multi_institution.h>
#include <istsafe.h>

NetworkInfo::NetworkInfo()
{
    memset(&m_ip, 0, sizeof(struct InstitutionProfile));
    memset(&m_ri, 0, sizeof(struct RoutingInfo));
    m_isRouteSet = false;
}

NetworkInfo::NetworkInfo(struct InstitutionProfile ip)
{
    memcpy(&m_ip, &ip, sizeof(struct InstitutionProfile));
    memset(&m_ri, 0, sizeof(struct RoutingInfo));
    m_isRouteSet = false;
}

int NetworkInfo::foundNetworkInfo () 
{ 
	return m_ip.m_externalId[0]||m_ip.m_member_ID[0]||m_ip.m_F_ID[0]||m_ip.m_bin[0]?1:0; 
}

const char *NetworkInfo::getTxnSrc() 
{
	return m_ip.m_txnSrc; 
}

const char *NetworkInfo::getTxnDest() 
{
	return m_ip.m_txnDest; 
}

const char *NetworkInfo::getDestEntityId() 
{
	return m_ip.m_iss_entityId; 
}

const char *NetworkInfo::getExternalId() 
{ 
	return m_ip.m_externalId; 
}

const char *NetworkInfo::getExternalIdDesc() 
{ 
	return m_ip.m_externalIdDesc; 
}

const char *NetworkInfo::getMember_ID() 
{ 
	return m_ip.m_member_ID; 
}

const char *NetworkInfo::getF_ID() 
{ 
	return m_ip.m_F_ID; 
}

const char *NetworkInfo::getBin() 
{
	return m_ip.m_bin; 
}

int   NetworkInfo::getKeyparam() 
{ 
	if (strlen(m_ip.keyparamStr)>0)	//Uses SHM versioning
		return shcApp->shcKeyObj->getKeyParam(m_ip.instId, m_ip.keyparamStr); 
	else	//Uses old rules
		 return m_ip.keyparm;
}
struct shcsecurity *NetworkInfo::getKey() 
{ 
	return shcApp->shcKeyObj->getKey(m_ip.instId, m_ip.keyparamStr); 
}

const char  *NetworkInfo::getInstId() 
{ 
	return m_ip.instId; 
}
const char  *NetworkInfo::getKeyparamStr() 
{ 
	return m_ip.keyparamStr; 
}

const struct InstitutionProfile *NetworkInfo::getInstProfileEntry() 
{ 
	return &m_ip; 
}

void NetworkInfo::putExternalId(const char *externalId) 
{ 
	//strcpy(m_ip.m_externalId, externalId); 
	istsafe_strcpy(m_ip.m_externalId, sizeof(m_ip.m_externalId), externalId); 
}

void NetworkInfo::putExternalIdDesc(const char *externalIdDesc) 
{ 
	//strcpy(m_ip.m_externalIdDesc, externalIdDesc); 
	istsafe_strcpy(m_ip.m_externalIdDesc, sizeof(m_ip.m_externalIdDesc), externalIdDesc); 
}

void NetworkInfo::putMember_ID(const char *member_ID) 
{ 
	//strcpy(m_ip.m_member_ID, member_ID); 
	istsafe_strcpy(m_ip.m_member_ID, sizeof(m_ip.m_member_ID), member_ID); 
}

void NetworkInfo::putF_ID(const char *F_ID) 
{ 
	//strcpy(m_ip.m_F_ID, F_ID); 
	istsafe_strcpy(m_ip.m_F_ID, sizeof(m_ip.m_F_ID), F_ID); 
}

void NetworkInfo::putInstProfileEntry(struct InstitutionProfile *p) 
{ 
	memcpy(&m_ip, p, sizeof(m_ip)); 
}

//	>>>	R030643
void NetworkInfo::reset()
{
    memset(&m_ip, 0, sizeof(struct InstitutionProfile));
    memset(&m_ri, 0, sizeof(struct RoutingInfo));
    m_isRouteSet = false;
}

void NetworkInfo::putRoutingInfo(struct RoutingInfo* ri)
{
	memcpy(&m_ri, ri, sizeof(struct RoutingInfo));
	m_isRouteSet = true;
}

const struct RoutingInfo* NetworkInfo::getRoutingInfo()
{
	return &m_ri;
}

bool NetworkInfo::isRouteSet()
{
	return m_isRouteSet;
}
//	<<<	R030643
