static char _ShcmsgHelperfunc_cxx_what[] = "@(#) ShcmsgHelper3.cxx 1.4 14/04/16 17:17:25";

/*
 *  Copyright (C) 2004 eFunds Corporation ("eFunds").  All Rights Reserved.     
 *  eFunds Canada Corporation is an authorized user.                            
 *                                                                              
 *  IST is a registered trademark of eFunds Corporation.  Other brand or        
 *  product names are trademarks or registered trademarks of their respective   
 *  holders.                                                                    
 *                                                                              
 *  The information contained herein is the unpublished proprietary property    
 *  of eFunds.  Except as specifically authorized in writing by eFunds, the     
 *  holder of this document shall: i) keep all information contained herein     
 *  confidential, and ii) protect the information, in whole or in part, from    
 *  disclosure and dissemination to all third parties.                          
 *                                                                          
 *  This document and the software described in it are furnished under license  
 *  and may be used or copied only in accordance with the terms of such license.
 *  This document is supplied for information purposes only, is subject to      
 *  change without notice, and should not be construed as a commitment by       
 *  either eFunds Corporation or eFunds Canada Corporation. 
 *
 *
 *                        MODIFICATION HISTORY                  REVIEW
 *
 *	SPR#	Who	Date	Description			Who	Date   
 * ===========================================================================
 *	R026570 ztang 09May19 Add function shcIsChipTxn
 */

/* File Number 30 */

#include <stdio.h>
#include <string.h>
#include <ctype.h>
#include <oasis.h>
#include <oasisenv.h>
#include <dbm.h>
#include <mb_umi.h>
#include <tm.h>
#include <dbm_private.h>
#include <mb.h>
#include <oc/oc_string.h>
#include <ist_otrace.h>
#include <Ccard_scheme.h>
#include <Cinstitution.h>
#include <shc_callback.h>
#include <rules.h>
#include <authnumber.h>
#include <shcmsgdef.h>
#include <security.h>
#include <shc.h>
#include <shcpreauth.h>
#include <ic/ic_shcmsg.h>
#include <ic/ic_instid.h>
#include <ic/ic_bin.h>
#include <ic/ic_pan.h>
#include <ShcSender.h>
#include <ShcMsgCache.h>
#include <istcurrency.h>
#include <shc500std.h>
#include <ShcSdkCommon.h>
#include <ShcmsgHelper.h>
#include <ShcKeyHelper.h>
#include <ShcTimerHelper.h>
#include <ShcMacHelper.h>
#include <hotrange.h>
#include <CShcLog.h>
#include <CShcNotify.h>
#include <ShcDKEHelper.h>
#include <ShcAppBase.h>
#include <ShcHelper.h>
#include <ShcBin.h>
#include <ShcSafIOHelper.h>
#include <BusinessDay.h>



static int checkMsg(struct shcmsg *msg)
{
	switch (msg->formatter_devcap & SH_FORMATDEVCAP_EMV_MASK)
	{
		case SH_FORMATDEVCAP_EMV_YES:
			return 1;
		case SH_FORMATDEVCAP_EMV_NO:
			return 0;
		case SH_FORMATDEVCAP_EMV_UNKNOWN:
			break;
		default:
			OTraceError("E-SHC-xxxx:Unknown emv flag in formatter_devcap:lx\n", msg->formatter_devcap);
			return 0;
	}
	
	//Unknown emv flag, check pos_entry_code and emv segment
	int pos_entry_code = (msg->pos_entry_code & SH_POS_PINPANENTRY_MASK)/10;
    if 	((pos_entry_code == 5)|| 
	     (pos_entry_code == 7)|| 
    	 (pos_entry_code == 95 ))
	{
		msg->formatter_devcap |= SH_FORMATDEVCAP_EMV_YES;
		return 1;
	}

	return -1;	//No sure it's emv or not
}


/*** Ssc 007561 print emv data to shcdump ***/
//FILE *fd is no longer used

#ifdef SWITCH77
int ShcmsgHelper::shcmsgIsChipTxn( struct shcmsg *msg)
#else
int shcmsgIsChipTxn( struct shcmsg *msg)
#endif
{
	int ret;

	if ((ret = checkMsg(msg)) >=0)
		return ret;

//	char	tmpBuf[64] = {0};
	emv* emvbufp = NULL;
//	struct shcseg   *shcsegP;
//	struct shcsegstart      *sp;
	int len;

	emvbufp = (emv *)get_seg_from_shcmsg(msg, (char *)"EMV_BUF", &len);

	if(!emvbufp)
	{
		msg->formatter_devcap |= SH_FORMATDEVCAP_EMV_NO;
		return 0;
	}
	else
	{
		msg->formatter_devcap |= SH_FORMATDEVCAP_EMV_YES;
		return 1;
	}
}


int shcmsgHeaderIsChipTxn( ShcmsgHeader *header)
{
	int ret;

	if ((ret = checkMsg(&header->msg)) >=0)
		return ret;
	
	int len;

	len = sizeof(emvbuf);

	if(header->getSegList()->exists(EMV_BUF_id))
	{
		header->msg.formatter_devcap |= SH_FORMATDEVCAP_EMV_YES;
		return 1;
	}
	else
	{
		header->msg.formatter_devcap |= SH_FORMATDEVCAP_EMV_NO;
		return 0;
	}
}





