/*
 *  Copyright (C) 2004 eFunds Corporation ("eFunds").  All Rights Reserved.
 *  eFunds Canada Corporation is an authorized user.
 *
 *  IST is a registered trademark of eFunds Corporation.  Other brand or
 *  product names are trademarks or registered trademarks of their respective
 *  holders.
 *
 *  The information contained herein is the unpublished proprietary property
 *  of eFunds.  Except as specifically authorized in writing by eFunds, the
 *  holder of this document shall: i) keep all information contained herein
 *  confidential, and ii) protect the information, in whole or in part, from
 *  disclosure and dissemination to all third parties.
 *
 *  This document and the software described in it are furnished under license
 *  and may be used or copied only in accordance with the terms of such license.
 *  This document is supplied for information purposes only, is subject to
 *  change without notice, and should not be construed as a commitment by
 *  either eFunds Corporation or eFunds Canada Corporation.
 */
/*
#pragma ident "@(#) shc_wrapper.cxx 1.24 14/02/10 05:31:19"
 *
 *                        MODIFICATION HISTORY                  REVIEW
 *
 *      SPR#    Who     Date    Description                     Who     Date
 * ===========================================================================
 *Rxxxxxx ztang 16Apr04 Creation
 *R012134 Emj   01Oct04 Issuer Entity Support
 *R012339 Emj   08Nov04 Emv Buffer Bitmap
 *R016347 Emj   01May06 Added delete of shcbin
 *R024052 sks	25Jul08	Some changes to avoid segmentation fault
 *R032576 Dipa  06Feb14 Spring Compliance 2014 - VISA - new API: shc_getextbin_networkconfig()
 */

//File Number 19

#if defined( WIN32 )
#       define SHCDLLEXPORT __declspec(dllexport)
#else
#       define SHCDLLEXPORT
#endif


#include <stdio.h>
#include <sys/types.h>
#include <time.h>
#include <oasis.h>
#include <ist_otrace.h>
#include <shcfmt.h>
#include <shc.h>
#include <string.h> /* R005156 */
#include <ShcAppBase.h>
#include <ShcmsgHeader.h>
#include <ShcmsgHelper.h>
#include <ShcHelper.h>
#include <ShcBin.h>
#include <IssProfile.h>
#include <InstProfile.h>
#include <ShcTimerHelper.h>
#include <ShcKeyHelper.h>
#include <InstProfile.h>
#include <ShcMacHelper.h>
#include <CShcNotify.h>
#include <ShcDKEHelper.h>
#include <ShcSafIOHelper.h>
#include <EntityStatus.h>
#include <istsafe.h>
#include <dbm_private.h>


int shc_makekey(struct shc *shcP)
{
	//	>>>	R024052
	if (shcApp == NULL)
		shcApp = (ShcAppBase *)shcHelperRegister.getTargetObj(SHC_ShcAppBase);
	//	<<<	R024052

	ShcmsgHeader msgHeader;
	msgHeader.fromShcStruct(shcP);
	int ret;
	
	//	>>>	R024052
	//if (shcApp == NULL)
	//	shcApp = (ShcAppBase *)shcHelperRegister.getTargetObj(SHC_ShcAppBase);
	//	<<<	R024052
	
	return shcApp->shcmsgHelperObj->shcMakeKey(&msgHeader);
}

int shc_gettrace(int eventKey)
{
	if (shcApp == NULL)
		shcApp = (ShcAppBase *)shcHelperRegister.getTargetObj(SHC_ShcAppBase);
	return shcApp->shcmsgHelperObj->shcGetTrace(eventKey);
}

int shc_gentrace()
{
	if (shcApp == NULL)
		shcApp = (ShcAppBase *)shcHelperRegister.getTargetObj(SHC_ShcAppBase);
	
	return( shcApp->shcHelperObj->shc_gentrace() );
}

int shc_init()
{
	if (shcApp == NULL)
		shcApp = (ShcAppBase *)shcHelperRegister.getTargetObj(SHC_ShcAppBase);
	
	return( shcApp->shcHelperObj->shc_init() );
}


int shc_locate_bin(struct shcpkg **shcpkg, bin_t bin)
{
	if (shcApp == NULL)
		shcApp = (ShcAppBase *)shcHelperRegister.getTargetObj(SHC_ShcAppBase);
	
	return( shcApp->shcBinObj->shc_locate_bin(shcpkg, bin));
}

int shc_locate_bin(struct shcpkg **shcpkg, char *institutionId, char *userBinId)
{
	if (shcApp == NULL)
		shcApp = (ShcAppBase *)shcHelperRegister.getTargetObj(SHC_ShcAppBase);
	
	return( shcApp->shcBinObj->shc_locate_bin(shcpkg, institutionId, userBinId));
}

int shc_set_return_msgno(struct shc *shcP)
{
	if (shcApp == NULL)
		shcApp = (ShcAppBase *)shcHelperRegister.getTargetObj(SHC_ShcAppBase);
	
	return( shcApp->shcmsgHelperObj->shc_set_return_msgno(&shcP->msg));
}

int shc_normalizebin(char *bin)
{
	if (shcApp == NULL)
		shcApp = (ShcAppBase *)shcHelperRegister.getTargetObj(SHC_ShcAppBase);
	
	return( shcApp->shcmsgHelperObj->shc_normalizebin(bin));
}

int shc_denormalizebin(char *bin)
{
	if (shcApp == NULL)
		shcApp = (ShcAppBase *)shcHelperRegister.getTargetObj(SHC_ShcAppBase);
	
	return( shcApp->shcmsgHelperObj->shc_denormalizebin(bin));
}

int shc_get_iss_acq(struct shc *shcmsg)
{
	//	>>>	R024052
	if (shcApp == NULL)
		shcApp = (ShcAppBase *)shcHelperRegister.getTargetObj(SHC_ShcAppBase);
	//	<<<	R024052

	ShcmsgHeader msgHeader;
	msgHeader.fromShcStruct(shcmsg);
	int ret;
	
	//	>>>	R024052
	//if (shcApp == NULL)
	//	shcApp = (ShcAppBase *)shcHelperRegister.getTargetObj(SHC_ShcAppBase);
	//	<<<	R024052
	
	ret = shcApp->shcmsgHelperObj->shcGetIssAcq(&msgHeader, 0);
	msgHeader.toShcStruct(shcmsg);
	return ret;
}

int shc_get_iss_acq_xt(struct shc *shcmsg, int useextbin )
{
	//	>>>	R024052
	if (shcApp == NULL)
		shcApp = (ShcAppBase *)shcHelperRegister.getTargetObj(SHC_ShcAppBase);
	//	<<<	R024052

	ShcmsgHeader msgHeader;
	msgHeader.fromShcStruct(shcmsg);
	int ret;
	
	//	>>>	R024052
	//if (shcApp == NULL)
	//	shcApp = (ShcAppBase *)shcHelperRegister.getTargetObj(SHC_ShcAppBase);
	//	<<<	R024052
	
	ret = shcApp->shcmsgHelperObj->shcGetIssAcq(&msgHeader, useextbin);
	msgHeader.toShcStruct(shcmsg);
	return ret;
}

int shc_locate_extbin(  const char *txnSrc, const char *pan, const int msgType,
					const int merchantType, const long pcode, const int hasPIN,
					IssuerInfo &issuerInfo)
{
	if (shcApp == NULL)
		shcApp = (ShcAppBase *)shcHelperRegister.getTargetObj(SHC_ShcAppBase);
	
	return( shcApp->issProfileObj->locate_extbin(txnSrc, pan, msgType, merchantType, pcode,
					hasPIN, issuerInfo, NULL));
}

int shc_locate_extbin(  const char *txnSrc, const char *pan, const int msgType,
					const char *deviceType, const long pcode, const int hasPIN,
					IssuerInfo &issuerInfo)
{
	if (shcApp == NULL)
		shcApp = (ShcAppBase *)shcHelperRegister.getTargetObj(SHC_ShcAppBase);
	
	return( shcApp->issProfileObj->locate_extbin(txnSrc, pan, msgType, deviceType, pcode,
					hasPIN, issuerInfo, NULL));
}


void shc_locate_issuer_from_network(const char *txnSrc, const int msgType, const char *externalId,
					const char *member_ID, const char *F_ID, IssuerInfo &issuerInfo)
{
	if (shcApp == NULL)
		shcApp = (ShcAppBase *)shcHelperRegister.getTargetObj(SHC_ShcAppBase);
	
	shcApp->instProfileObj->locateIssuerFromNetwork(txnSrc, msgType, externalId, 
			member_ID, F_ID, issuerInfo);
}

void shc_locate_acquirer(const char *txnSrc, const char *txnDest, const char *entityId,
			const int currency, const int merchantType, AcquirerInfo &acquirerInfo)
{
	if (shcApp == NULL)
		shcApp = (ShcAppBase *)shcHelperRegister.getTargetObj(SHC_ShcAppBase);
	
	shcApp->acqProfileObj->locateAcquirer(txnSrc, txnDest, entityId, currency, 
				merchantType, acquirerInfo, NULL);
}


void shc_locate_acquirer(const char *txnSrc, const char *txnDest, const char *entityId,
			const int currency, const char *deviceType, AcquirerInfo &acquirerInfo)
{
	if (shcApp == NULL)
		shcApp = (ShcAppBase *)shcHelperRegister.getTargetObj(SHC_ShcAppBase);
	
	shcApp->acqProfileObj->locateAcquirer(txnSrc, txnDest, entityId, currency, 
				deviceType, acquirerInfo, NULL);
}

int shc_internalBin2ExternalBin(char *institutionId, char *userBinId, const char *networkid)
{
	if (shcApp == NULL)
		shcApp = (ShcAppBase *)shcHelperRegister.getTargetObj(SHC_ShcAppBase);
	
	return shcApp->shcBinObj->internalBin2ExternalBin(institutionId, userBinId, networkid);
}

int shc_externalBin2InternalBin(char *networkid, const char *institutionId, const char *userBinId)
{
	if (shcApp == NULL)
		shcApp = (ShcAppBase *)shcHelperRegister.getTargetObj(SHC_ShcAppBase);
	
	return shcApp->shcBinObj->externalBin2InternalBin(networkid, institutionId, userBinId);
}

int shc_normalizepan(char *pan)
{
	if (shcApp == NULL)
		shcApp = (ShcAppBase *)shcHelperRegister.getTargetObj(SHC_ShcAppBase);
	
	return (shcApp->shcmsgHelperObj->shc_normalizepan(pan));
}

int split_issuer_app_data_vsdc(emv *emvbuf)
{
	if (shcApp == NULL)
		shcApp = (ShcAppBase *)shcHelperRegister.getTargetObj(SHC_ShcAppBase);
	
	return (shcApp->shcHelperObj->split_issuer_app_data_vsdc(emvbuf));
}

int split_issuer_app_data_mchip(emv *emvbuf)
{
	if (shcApp == NULL)
		shcApp = (ShcAppBase *)shcHelperRegister.getTargetObj(SHC_ShcAppBase);
	
	return (shcApp->shcHelperObj->split_issuer_app_data_mchip(emvbuf));
}

int shc_resptomsg(int respcode, char *msg, size_t msg_size)
{
	if (shcApp == NULL)
		shcApp = (ShcAppBase *)shcHelperRegister.getTargetObj(SHC_ShcAppBase);
	
	return (shcApp->shcHelperObj->shc_resptomsg(respcode, msg, msg_size));
}


int scan(FILE *fp, int error, char *msg, size_t msg_size)
{
	if (shcApp == NULL)
		shcApp = (ShcAppBase *)shcHelperRegister.getTargetObj(SHC_ShcAppBase);
	
	return (shcApp->shcHelperObj->scan(fp, error, msg, msg_size));

}


int default_msg(int respcode, char *msg, size_t msg_size)
{
	if (shcApp == NULL)
		shcApp = (ShcAppBase *)shcHelperRegister.getTargetObj(SHC_ShcAppBase);
	
	return (shcApp->shcHelperObj->default_msg(respcode, msg, msg_size));
}

void shc_getIssuerAcquirerInfo(const char *txnSrc, const char *pan, const int msgType, 
							const int merchantType, const long pcode, const int hasPIN,
							const char *entityId, const int currency, 
							IssuerInfo &issuerInfo, AcquirerInfo &acquirerInfo )
{
	if (shcApp == NULL)
		shcApp = (ShcAppBase *)shcHelperRegister.getTargetObj(SHC_ShcAppBase);
	
	shcApp->shcHelperObj->shc_getIssuerAcquirerInfo(txnSrc, pan, msgType, merchantType,
						pcode, hasPIN, entityId, currency, issuerInfo, acquirerInfo,NULL);
	return;
}

void shc_getIssuerAcquirerInfo(const char *txnSrc, const char *pan, const int msgType, 
							const char *deviceType, const long pcode, const int hasPIN,
							const char *entityId, const int currency, 
							IssuerInfo &issuerInfo, AcquirerInfo &acquirerInfo )
{
	if (shcApp == NULL)
		shcApp = (ShcAppBase *)shcHelperRegister.getTargetObj(SHC_ShcAppBase);
	
	shcApp->shcHelperObj->shc_getIssuerAcquirerInfo(txnSrc, pan, msgType, deviceType,
						pcode, hasPIN, entityId, currency, issuerInfo, acquirerInfo,NULL);
	return;
}

struct pinverparm *shc_getpinparm(char *bin)
{
	if (shcApp == NULL)
		shcApp = (ShcAppBase *)shcHelperRegister.getTargetObj(SHC_ShcAppBase);
	
	return shcApp->shcHelperObj->shc_getpinparm(bin);
}

int shc_normalizenumber(register char *nbp, register char *obp, int len)
{
	if (shcApp == NULL)
		shcApp = (ShcAppBase *)shcHelperRegister.getTargetObj(SHC_ShcAppBase);
	
	return shcApp->shcHelperObj->shc_normalizenumber(nbp, obp, len);
}

int shc_locate_event(register struct shc *shcmsg, struct shc *omsg)
{
	//	>>>	R024052
	if (shcApp == NULL)
		shcApp = (ShcAppBase *)shcHelperRegister.getTargetObj(SHC_ShcAppBase);
	//	<<<	R024052

	ShcmsgHeader msgHeader;
	
	msgHeader.fromShcStruct(shcmsg);

	//	>>>	R024052
	//if (shcApp == NULL)
	//	shcApp = (ShcAppBase *)shcHelperRegister.getTargetObj(SHC_ShcAppBase);
	//	<<<	R024052
	
	if (omsg)
		return shcApp->shcTimerObj->shc_locate_event(&msgHeader, &omsg->msg);	
	else
		return shcApp->shcTimerObj->shc_locate_event(&msgHeader, NULL);	
}

int shc_locate_event_x( register struct shc *shcmsg, struct shc *omsg, unsigned char *seg )
{
	//	>>>	R024052
	if (shcApp == NULL)
		shcApp = (ShcAppBase *)shcHelperRegister.getTargetObj(SHC_ShcAppBase);
	//	<<<	R024052

	ShcmsgHeader msgHeader;
	
	msgHeader.fromShcStruct(shcmsg);

	//	>>>	R024052
	//if (shcApp == NULL)
	//	shcApp = (ShcAppBase *)shcHelperRegister.getTargetObj(SHC_ShcAppBase);
	//	<<<	R024052
	
	if (omsg)
		return shcApp->shcTimerObj->shc_locate_event_x(&msgHeader, &omsg->msg, seg);	
	else
		return shcApp->shcTimerObj->shc_locate_event_x(&msgHeader, NULL, seg);	

}

int shc_is_empty_buf(register char *buf, register int len)
{
	if (shcApp == NULL)
		shcApp = (ShcAppBase *)shcHelperRegister.getTargetObj(SHC_ShcAppBase);
	
	return shcApp->shcHelperObj->shc_is_empty_buf(buf, len);
}

int shc_fmt_balance( char *buf,
				int accttype, int amttype, int currency, amount_t *amount)
{
	if (shcApp == NULL)
		shcApp = (ShcAppBase *)shcHelperRegister.getTargetObj(SHC_ShcAppBase);
	
	return shcApp->shcHelperObj->shc_fmt_balance(buf, accttype, amttype, currency, amount);
}
				
long shc_fmtgetdate_from_mmdd( long	mmdd )
{
	if (shcApp == NULL)
		shcApp = (ShcAppBase *)shcHelperRegister.getTargetObj(SHC_ShcAppBase);
	
	return shcApp->shcHelperObj->shc_fmtgetdate_from_mmdd(mmdd);
}

char *shc_locate_track_data(struct shc *shcmsg)
{
	char *p;
	
	p = shcmsg_locate_track_data(&shcmsg->msg);
	return p;
}

char *shcmsg_locate_track_data(struct shcmsg *msg)
{
	char *p;
	
	if (shcApp == NULL)
		shcApp = (ShcAppBase *)shcHelperRegister.getTargetObj(SHC_ShcAppBase);
	
	p = shcApp->shcmsgHelperObj->shc_locate_track_data(msg);
	return p;
}

int shc_determine_track(struct shc *shcmsg)
{
	//	>>>	R024052
	if (shcApp == NULL)
		shcApp = (ShcAppBase *)shcHelperRegister.getTargetObj(SHC_ShcAppBase);
	//	<<<	R024052

	int ret;
	
	ShcmsgHeader tmpHeader;
	tmpHeader.fromShcStruct(shcmsg);
	
	//	>>>	R024052
	//if (shcApp == NULL)
	//	shcApp = (ShcAppBase *)shcHelperRegister.getTargetObj(SHC_ShcAppBase);
	//	<<<	R024052
	
	ret = shcApp->shcmsgHelperObj->shc_determine_track(&tmpHeader);
	tmpHeader.toShcStruct(shcmsg);
	return ret;
}

int shc_get_pin_data(struct shc *shcmsg)
{
	//	>>>	R024052
	if (shcApp == NULL)
		shcApp = (ShcAppBase *)shcHelperRegister.getTargetObj(SHC_ShcAppBase);
	//	<<<	R024052

	int ret;
	ShcmsgHeader tmpHeader;
	tmpHeader.fromShcStruct(shcmsg);
	
	//	>>>	R024052
	//if (shcApp == NULL)
	//	shcApp = (ShcAppBase *)shcHelperRegister.getTargetObj(SHC_ShcAppBase);
	//	<<<	R024052
	
	ret = shcApp->shcmsgHelperObj->shc_get_pin_data(&tmpHeader);
	tmpHeader.toShcStruct(shcmsg);
	return ret;
}

int shc_keys_set_status(struct shckey_buf *bufp, char status)
{
	if (shcApp == NULL)
		shcApp = (ShcAppBase *)shcHelperRegister.getTargetObj(SHC_ShcAppBase);
	
	return shcApp->shcKeyObj->shc_keys_set_status(bufp, status);
	
}

int shc_keys_set_status_as2805(struct shckey_buf *bufp, char status, int device_flag )
{
	if (shcApp == NULL)
		shcApp = (ShcAppBase *)shcHelperRegister.getTargetObj(SHC_ShcAppBase);
	
	return shcApp->shcKeyObj->shc_keys_set_status_as2805(bufp, status, device_flag);
	
}

int shc_denormalizepan(char *pan)
{
	if (shcApp == NULL)
		shcApp = (ShcAppBase *)shcHelperRegister.getTargetObj(SHC_ShcAppBase);
	
	return( shcApp->shcmsgHelperObj->shc_denormalizepan(pan));
}

int shc_GetCurrencyRate( int code, bin_t inst_id, struct istcurrency_key *r )
{
	if (shcApp == NULL)
		shcApp = (ShcAppBase *)shcHelperRegister.getTargetObj(SHC_ShcAppBase);
	
	return shcApp->shcHelperObj->shc_GetCurrencyRate(code, inst_id, r);
}

void shc_locate_network_info(const char * txnSrc, const int msgType, const bin_t bin, NetworkInfo &networkInfo)
{
	if (shcApp == NULL)
		shcApp = (ShcAppBase *)shcHelperRegister.getTargetObj(SHC_ShcAppBase);
	
	shcApp->instProfileObj->locateNetworkInfo(txnSrc, NULL, NULL, msgType, bin, networkInfo);
	return;
}

void shc_locate_network_info(const char * txnSrc, const char * txnDest,
							 const char *iss_entityId, const int msgType, 
							 const bin_t bin, NetworkInfo &networkInfo)
{
	if (shcApp == NULL)
		shcApp = (ShcAppBase *)shcHelperRegister.getTargetObj(SHC_ShcAppBase);
	
	shcApp->instProfileObj->locateNetworkInfo(txnSrc, txnDest, iss_entityId, msgType, bin, networkInfo);
	return;
}

int shcnet_keys_init( struct shc *shcmsg, struct shcpkg *pkgp, struct shckey_buf *keybufp )
{
	//	>>>	R024052
	if (shcApp == NULL)
		shcApp = (ShcAppBase *)shcHelperRegister.getTargetObj(SHC_ShcAppBase);
	//	<<<	R024052

	int ret;
	ShcmsgHeader tmpHeader;
	tmpHeader.fromShcStruct(shcmsg);
	
	//	>>>	R024052
	//if (shcApp == NULL)
	//	shcApp = (ShcAppBase *)shcHelperRegister.getTargetObj(SHC_ShcAppBase);
	//	<<<	R024052
	
	ShcBin *bin = (ShcBin *)shcHelperRegister.getTargetObj(SHC_ShcBin);
	bin->setBinPkg(pkgp);
	ret = bin->shcnet_keys_init(&tmpHeader, keybufp);
	tmpHeader.toShcStruct(shcmsg);
	delete bin;
	return ret;
}

int shc_truelength(struct shc *shcmsg)
{
    ShcmsgHeader *h = NULL;

    return h->truelength(&shcmsg->msg);
}

int shc_init_formatter(const char *name, int *m_in, int *m_out, int *s_id, int *st_id, int single_formatter)
{
	if (shcApp == NULL)
		shcApp = (ShcAppBase *)shcHelperRegister.getTargetObj(SHC_ShcAppBase);
	return shcApp->shcHelperObj->shc_init_formatter(name, m_in, m_out, s_id, st_id, single_formatter);
}

void shc_locate_issuer_from_institution(const char *inst, const int msgType, IssuerInfo &issuerInfo)
{
	if (shcApp == NULL)
		shcApp = (ShcAppBase *)shcHelperRegister.getTargetObj(SHC_ShcAppBase);
	shcApp->instProfileObj->locateIssuerFromInstitution(inst, NULL, msgType, issuerInfo);
	return;
}

void shc_locate_issuer_from_institution(const char *inst, const char *entityId, const int msgType, IssuerInfo &issuerInfo)
{
	if (shcApp == NULL)
		shcApp = (ShcAppBase *)shcHelperRegister.getTargetObj(SHC_ShcAppBase);
	shcApp->instProfileObj->locateIssuerFromInstitution(inst, entityId, msgType, issuerInfo);
	return;
}

int shc_getInstitutionIdFromCardScheme(char *institutionId, const char *cardScheme)
{
	if (shcApp == NULL)
		shcApp = (ShcAppBase *)shcHelperRegister.getTargetObj(SHC_ShcAppBase);
	return shcApp->shcHelperObj->shc_getInstitutionIdFromCardScheme(institutionId, cardScheme);
}

int shc_initsys()
{
	if (shcApp == NULL)
		shcApp = (ShcAppBase *)shcHelperRegister.getTargetObj(SHC_ShcAppBase);
	return shcApp->shcHelperObj->shc_initsys();
}

int shc_getissnetmac(struct shc *shcmsg, struct shcpkg *pkg, char *mackey)
{
	//	>>>	R024052
	if (shcApp == NULL)
		shcApp = (ShcAppBase *)shcHelperRegister.getTargetObj(SHC_ShcAppBase);
	//	<<<	R024052

	ShcmsgHeader header;
	ShcBin *bin = (ShcBin *)shcHelperRegister.getTargetObj(SHC_ShcBin);
	bin->setBinPkg(pkg);
	header.fromShcStruct(shcmsg);

	//	>>>	R024052
	//if (shcApp == NULL)
	//	shcApp = (ShcAppBase *)shcHelperRegister.getTargetObj(SHC_ShcAppBase);
	//	<<<	R024052

 	int ret = shcApp->shcMacObj->shc_getissnetmac(&header, bin, mackey);
	header.toShcStruct(shcmsg);
	delete bin;
	return ret;
}

int shc_get_return_msgno(int msgno)
{
	if (shcApp == NULL)
		shcApp = (ShcAppBase *)shcHelperRegister.getTargetObj(SHC_ShcAppBase);
	return shcApp->shcmsgHelperObj->shc_get_return_msgno(msgno);
}
void beginCacheMsg()
{
	if (shcApp == NULL)
		shcApp = (ShcAppBase *)shcHelperRegister.getTargetObj(SHC_ShcAppBase);
	shcApp->shcHelperObj->beginCacheMsg();
}
void endCacheMsg()
{
	if (shcApp == NULL)
		shcApp = (ShcAppBase *)shcHelperRegister.getTargetObj(SHC_ShcAppBase);
	shcApp->shcHelperObj->endCacheMsg();
}
int cache_mb_write(int dest_id, int src_id, char *msg, int len)
{
	if (shcApp == NULL)
		shcApp = (ShcAppBase *)shcHelperRegister.getTargetObj(SHC_ShcAppBase);
	return shcApp->shcHelperObj->cache_mb_write(dest_id, src_id, msg, len);
}
int flush_mb_cache()
{
	if (shcApp == NULL)
		shcApp = (ShcAppBase *)shcHelperRegister.getTargetObj(SHC_ShcAppBase);
	return shcApp->shcHelperObj->flush_mb_cache();
}
int shc_logrepeat(struct shc *shcmsg)
{
	//	>>>	R024052
	if (shcApp == NULL)
		shcApp = (ShcAppBase *)shcHelperRegister.getTargetObj(SHC_ShcAppBase);
	//	<<<	R024052

	ShcmsgHeader msgHeader;
	msgHeader.fromShcStruct(shcmsg);
	int ret;
	
	//	>>>	R024052
	//if (shcApp == NULL)
	//	shcApp = (ShcAppBase *)shcHelperRegister.getTargetObj(SHC_ShcAppBase);
	//	<<<	R024052
	
	ret = shcApp->shcmsgLogObj->logRepeat(&msgHeader);
	msgHeader.toShcStruct(shcmsg);
	return(ret);
}

int shc_logtransaction(struct shc *shcmsg)
{
	//	>>>	R024052
	if (shcApp == NULL)
		shcApp = (ShcAppBase *)shcHelperRegister.getTargetObj(SHC_ShcAppBase);
	//	<<<	R024052

	ShcmsgHeader msgHeader;
	msgHeader.fromShcStruct(shcmsg);
	int ret;
	
	//	>>>	R024052
	//if (shcApp == NULL)
	//	shcApp = (ShcAppBase *)shcHelperRegister.getTargetObj(SHC_ShcAppBase);
	//	<<<	R024052
	
	ret = shcApp->shcmsgLogObj->logTxn(&msgHeader);
	msgHeader.toShcStruct(shcmsg);
	return(ret);
}

int shc_notify_echo( struct shc *smsg )
{
	//	>>>	R024052
	if (shcApp == NULL)
		shcApp = (ShcAppBase *)shcHelperRegister.getTargetObj(SHC_ShcAppBase);
	//	<<<	R024052

	ShcmsgHeader msgHeader;
	msgHeader.fromShcStruct(smsg);

	//	>>>	R024052
	//if (shcApp == NULL)
	//	shcApp = (ShcAppBase *)shcHelperRegister.getTargetObj(SHC_ShcAppBase);
	//	<<<	R024052

	return shcApp->shcNotifyObj->shc_notify_echo( &msgHeader );


}

int shc_getissnetkpe(struct shc *shcmsg, struct shcpkg *pkg, char *kpe_cnt)
{
	if (shcApp == NULL)
		shcApp = (ShcAppBase *)shcHelperRegister.getTargetObj(SHC_ShcAppBase);
	
	ShcmsgHeader msgHeader;
	msgHeader.fromShcStruct(shcmsg);
	
	ShcBin *shcBin = (ShcBin *)shcHelperRegister.getTargetObj(SHC_ShcBin);
	shcBin->setBinPkg(pkg);
	int ret = shcBin->shc_getissnetkpe(&msgHeader, kpe_cnt);
	msgHeader.toShcStruct(shcmsg);
	delete shcBin;
	return ret;
}

long shc_next_auth_number()
{
	if (shcApp == NULL)
		shcApp = (ShcAppBase *)shcHelperRegister.getTargetObj(SHC_ShcAppBase);
	return shcApp->shcmsgHelperObj->shc_next_auth_number();
}


int shc_invert_rate(amount_t *in_rate)
{
	if (shcApp == NULL)
		shcApp = (ShcAppBase *)shcHelperRegister.getTargetObj(SHC_ShcAppBase);
	return shcApp->shcmsgHelperObj->shc_invert_rate(in_rate);
}


void setEmvBitMapOn(emv  *emvbuf, shcemvbit field)
{
	if (shcApp == NULL)
		shcApp = (ShcAppBase *)shcHelperRegister.getTargetObj(SHC_ShcAppBase);
	shcApp->shcHelperObj->setEmvBitMapOn(emvbuf, field);
}

void setEmvBitMapOff(emv  *emvbuf, shcemvbit field)
{
	if (shcApp == NULL)
		shcApp = (ShcAppBase *)shcHelperRegister.getTargetObj(SHC_ShcAppBase);
	shcApp->shcHelperObj->setEmvBitMapOff(emvbuf, field);
}

int isEmvBitMap (emv  *emvbuf, shcemvbit field)
{
	if (shcApp == NULL)
		shcApp = (ShcAppBase *)shcHelperRegister.getTargetObj(SHC_ShcAppBase);
	return (shcApp->shcHelperObj->isEmvBitMap(emvbuf, field));

}

char *shc_maskpan (const char *pan)
{
	if (shcApp == NULL)
		shcApp = (ShcAppBase *)shcHelperRegister.getTargetObj(SHC_ShcAppBase);
	return shcApp->shcHelperObj->shc_maskpan(pan);

}

int isMC( ShcmsgHeader *hd)
{
	if (shcApp == NULL)
		shcApp = (ShcAppBase *)shcHelperRegister.getTargetObj(SHC_ShcAppBase);
	return shcApp->shcHelperObj->isMC(hd);
}

int shcIsReplay(ShcmsgHeader *hd)	// Use EntityStatus
{
	return shcIsReplay( hd->issShcBin->binPkg, hd->msg.iss_entityId );
}


int shcIsReplay(struct shcpkg *bp, char *issEntity)
{
	int ret = 0;
//	struct shcpkg *bp = hd->issShcBin->binPkg;
//	char *issEntity   = hd->msg.iss_entityId;
	
	if ( bp==NULL )
	{
		OTraceError("E-SHC-019001: shcpkg is NULL in shc_isreplay()\n");
		return (-1);
	}
	
	if ( strlen(issEntity) > 0 )
	{
		ret = shcApp->entityStatusObj->isReplaying( bp->bin.institutionid, issEntity );
	}
	else
	{
		ret = shcApp->entityStatusObj->isReplaying( bp->bin.institutionid, bp->bin.userbinid );
	}
	
	return ret && (((bp)->saf.type & SH_SAF_POSFILE)||((bp)->saf.type & SH_SAF_NEGFILE));
}


int shc_setSafMode( char *dest, int mode )
{
	char instId[20] = {0};
	char entityId[20] = {0};
	char *p;
	
	strncpy( instId, dest, sizeof(instId)-1 );
	if ( (p=strchr( instId, '.' )) ) 		// it's a route
	{
		*p = '\0';
		strncpy( entityId, p+1, sizeof(entityId)-1 );
	}
	else
	{
		strncpy( entityId, dest, sizeof(entityId)-1 );
		
		OTraceInfo("I-SHC-019002: '%s' is not a route\n", dest);
		return 0;
	}
	
	OTraceDebug("I-SHC-019002: Set [%s/%s] SAF %s\n", instId, entityId, mode ? "ON":"OFF" );
	
	if ( mode ) 
	{
		return shcApp->entityStatusObj->setSafOn( instId, entityId );
	}
	
	return shcApp->entityStatusObj->setSafOff( instId, entityId );
}

int shc_setSafOn( char *dest )
{
	return shc_setSafMode( dest, 1 );
}

int shc_setSafOff( char *dest )
{
	return shc_setSafMode( dest, 0 );
}

int shc_setSafOn( char *instId, char *entityId )
{
	return shcApp->entityStatusObj->setSafOn( instId, entityId );
}

int shc_setSafOff( char *instId, char *entityId )
{
	return shcApp->entityStatusObj->setSafOff( instId, entityId );
}


int shc_alterIssuerByEntityId( struct shcmsg *msg, struct shcpkg **pkg )
{
	return shc_getIssuerByEntityId( msg, pkg, msg->issuer, sizeof(msg->issuer) );
}

int shc_getIssuerByEntityId( struct shcmsg *msg, struct shcpkg **pkg, char *issuer, size_t issuerSize )
{
	bin_t newIssuer = {0};
	int  ret = shcApp->shcmsgHelperObj->getAlterIssuerByEntityId( msg, newIssuer, pkg, sizeof(newIssuer) );
	
	if ( ret > 0 )
	{
		if ( newIssuer[0] && issuer && issuer[0] )
		{
			//strcpy( issuer, newIssuer );
			istsafe_strcpy( issuer, issuerSize, newIssuer );
		}
	}
	return ret;
	
}



int shc_saf_toistadvice(ShcBin *shcBin, ShcmsgHeader *header)
{
	return shcApp->shcSafIOHelperObj->shc_saf_toistadvice(shcBin, header);
}

//R032576 >>>
char* shc_getextbin_networkconfig( const char *txnSrc, const char *pan, const int msgType,
						const int merchantType, const long pcode, const int hasPIN,
						IssuerInfo &issuerInfo)
{
	char *network_config;

	if (shcApp == NULL)
		shcApp = (ShcAppBase *)shcHelperRegister.getTargetObj(SHC_ShcAppBase);
																									  
	if ( shcApp->issProfileObj->locate_extbin(txnSrc, pan, msgType, merchantType, pcode, hasPIN, issuerInfo, NULL) == 1)
		return(shcApp->issProfileObj->getExtBin_networkconfig());

	return NULL;
}


char* shc_getextbin_networkconfig(  const char *txnSrc, const char *pan, const int msgType,
					const char *deviceType, const long pcode, const int hasPIN,
					IssuerInfo &issuerInfo)
{
	char *network_config;

	if (shcApp == NULL)
		shcApp = (ShcAppBase *)shcHelperRegister.getTargetObj(SHC_ShcAppBase);

	if( shcApp->issProfileObj->locate_extbin(txnSrc, pan, msgType, deviceType, pcode, hasPIN, issuerInfo, NULL) == 1)
		return(shcApp->issProfileObj->getExtBin_networkconfig());

	return NULL;
}
//R032576 <<<

char* shc_getextbin_fileversion( const char *txnSrc, const char *pan, const int msgType,
                                                const int merchantType, const long pcode, const int hasPIN,
                                                IssuerInfo &issuerInfo)
{

        if (shcApp == NULL)
                shcApp = (ShcAppBase *)shcHelperRegister.getTargetObj(SHC_ShcAppBase);


        if ( shcApp->issProfileObj->locate_extbin(txnSrc, pan, msgType, merchantType, pcode, hasPIN, issuerInfo, NULL) == 1)
                return(shcApp->issProfileObj->getExtBin_file_version());

        return NULL;
}


char* shc_getextbin_fileversion(  const char *txnSrc, const char *pan, const int msgType,
                                        const char *deviceType, const long pcode, const int hasPIN,
                                        IssuerInfo &issuerInfo)
{

        if (shcApp == NULL)
                shcApp = (ShcAppBase *)shcHelperRegister.getTargetObj(SHC_ShcAppBase);

        if( shcApp->issProfileObj->locate_extbin(txnSrc, pan, msgType, deviceType, pcode, hasPIN, issuerInfo, NULL) == 1)
                return(shcApp->issProfileObj->getExtBin_file_version());

        return NULL;
}

void checkDbCon()
{
        int ind = 0;
        OTraceDebug("I-SHC-019002: Checking DB connection:\n");
        if(DBMGetConnectAttribute(dbm_dbconn, DBM_ATTR_CONNECTION_DEAD, &ind, sizeof(ind), 0) == DBM_SUCCESS)
        {
                if(ind)
                {
                        OTraceFatal("F-SHC-019003: disconnected from database, exiting\n");
                        kill(getpid(),1);
                }
                else
                        OTraceDebug("I-SHC-019004: Getting Connect Attribute failed\n");
        }
        else{
                OTraceFatal("F-SHC-019005: Unable to detect db connection status, exiting\n");
        }

        return;
}
/*
 * End of file shc_wrapper.cxx
 */
