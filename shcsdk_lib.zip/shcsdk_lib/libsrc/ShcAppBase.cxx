/*
 *  Copyright (C) 2004 eFunds Corporation ("eFunds").  All Rights Reserved.
 *  eFunds Canada Corporation is an authorized user.
 *
 *  IST is a registered trademark of eFunds Corporation.  Other brand or
 *  product names are trademarks or registered trademarks of their respective
 *  holders.
 *
 *  The information contained herein is the unpublished proprietary property
 *  of eFunds.  Except as specifically authorized in writing by eFunds, the
 *  holder of this document shall: i) keep all information contained herein
 *  confidential, and ii) protect the information, in whole or in part, from
 *  disclosure and dissemination to all third parties.
 *
 *  This document and the software described in it are furnished under license
 *  and may be used or copied only in accordance with the terms of such license.
 *  This document is supplied for information purposes only, is subject to
 *  change without notice, and should not be construed as a commitment by
 *  either eFunds Corporation or eFunds Canada Corporation.
 */
/*
static char SCCSid[] = "@(#) ShcAppBase.cxx 1.18.7.7 18/07/06 17:20:29";
 *
 *  MODIFICATION HISTORY                              REVIEW
 *
 *      SPR#    Who     Date    Description                       Who   Date
 * ===========================================================================
 *R00xxxx ztang 05Nov03 Creation
 *R011925 jyang 16Sep04 Saf interleave support
 *R015826 pve   07Mar06 Support for Generic Log
 *R000000 jyang 17Oct06 Entity status support
 */
/*------------------------------------------------------------------------*
 * Include Block
 *------------------------------------------------------------------------*/


//File Number 21

#if defined( WIN32 )
#       define SHCDLLEXPORT __declspec(dllexport)
#else
#       define SHCDLLEXPORT
#endif


#include <stdio.h>
#include <oasis.h>
#include <ist_otrace.h>
#include <shc.h>
#include <string.h>
#include <security.h>	/* R005156 */
#include <CShcLog.h>
#include <ShcSdkCommon.h>
#include <ShcSafIOHelper.h>
#include <ShcDKEHelper.h>
#include <ShcmsgHelper.h>
#include <IssProfile.h>
#include <ShcAppBase.h>
#include <ist_seg_elf_id_map.h>

#include <ShcmsgHelper.h>
#include <ShcKeyHelper.h>
#include <ShcMacHelper.h>
#include <CShcNotify.h>
#include <ShcTimerHelper.h>
#include <ShcHelper.h>
#include <AcqProfile.h>
#include <InstProfile.h>
#include <Shc600Log.h>
#include <ShcHelperBase.h>
#include <McastHelper.h>
#include <ShcBalancer.h>
#include <EntityStatus.h>
#include <BinRoute.h>
#include <CShcGenericLog.h>		//	R015826
#include <UpdateMemHelper.h>
#include <ShcDuplicateChk.h>
#include <ShcPinTryCounter.h>
#include <ShcCardStatusHelper.h>
#include <ShcCardStatusChngAlw.h>
#include <Shc3XX.h>
#include <Shc300ReqDB.h>
#include <IssProfileExtended.h>

IssProfileExtended *issProfileExtObj=NULL;

/*------------------------------------------------------------------------*/
/*
 *	global data for the shc system
 */
struct  shc_txn_def ShcAppBase::shc_txn_def[11] =
{
{SH_TXIDX_WD,		SH_TX_WD,		"Withdrawal",	SHC_TXNTYPE_DEBIT},
{SH_TXIDX_DEP,		SH_TX_DEP,		"Deposit",		SHC_TXNTYPE_CREDIT},
{SH_TXIDX_TSF,		SH_TX_TSF,		"Transfers",	SHC_TXNTYPE_TRANSFER},
{SH_TXIDX_BAL,		SH_TX_BAL,		"Balance Inquirey", SHC_TXNTYPE_INQUIRY},
{SH_TXIDX_BILLPAY,	SH_TX_BILLPAY,	"Bill Payment",	SHC_TXNTYPE_CREDIT},
{SH_TXIDX_LOANPAY,	SH_TX_LOANPAY,	"Loan Payment",	SHC_TXNTYPE_CREDIT},
{SH_TXIDX_CC,		SH_TX_CC,		"Credit Cards", SHC_TXNTYPE_AUTHORIZE},
{SH_TXIDX_SERVICES,	SH_TX_SERVICES,	"Goods and Services", SHC_TXNTYPE_AUTHORIZE},
{SH_TXIDX_CHECK_GUARANTEE,SH_TX_CHECK_GUARANTEE,"Check Guarantee",SHC_TXNTYPE_AUTHORIZE},
{SH_TXIDX_AUTHENTICATE,SH_TX_AUTHENTICATE,"Authenticate",SHC_TXNTYPE_AUTHENTICATE}, /* R001952 */
{-1}
};

/*
 * R001835	 Bin Level Configuration
 */
struct shc_bin_cfg ShcAppBase::shc_bin_cfg[30] =
{
        {SH_CFGIX_INTERAC,              SH_CFG_INTERAC,         "Interac" },
        {SH_CFGIX_DSQL,                 SH_CFG_DSQL,            "Dynamic SQL Search" },
        {SH_CFGIX_NDKE,                 SH_CFG_NDKE,            "Network Dynamic Key Exchange" },
        {SH_CFGIX_CHKDUPREV,            SH_CFG_CHKDUPREV,       "Check Duplicate Reversal" },
        {SH_CFGIX_TRANTIME,             SH_CFG_TRANTIME,        "Restore Transmission Time"},
        {SH_CFGIX_CAPDATEOVERRIDE,      SH_CFG_CAPDATEOVERRIDE, "Capture Date Override"},
        {SH_CFGIX_AVS_FLAG,             SH_CFGIX_AVS_FLAG,      "AVS Option"},
        {SH_CFGIX_ACQ_ISS_FLAG,         SH_CFGIX_ACQ_ISS_FLAG,  "ACQ Iss Flag"},
        {SH_CFGIX_REFUND_VOID_FLAG,     SH_CFGIX_REFUND_VOID_FLAG,      "Refund Void"},
        /* 2007336 R004671 Dds 26Jun00 -add 5 lines for chipdata enhancement */
        {SH_CFGIX_FULL_ENTRY,           SH_CFG_FULL_ENTRY,      "Chip Option" },
        {SH_CFGIX_CARD_AUTH,            SH_CFG_CARD_AUTH,       "Card Authentication" },
        {SH_CFGIX_ISS_AUTH,             SH_CFG_ISS_AUTH,        "Issuer Authentication" } ,
        {SH_CFGIX_DECL_AUTH_FAI,        SH_CFG_DECL_AUTH_FAI,   "Decline Card Auth Failed" },
        {SH_CFGIX_CHIP_LOG,             SH_CFG_CHIP_LOG,        "Log Chip Data"},
        {SH_CFGIX_EMV_STIP,             SH_CFG_EMV_STIP,        "Card/Issuer Auth in STIP"},
        {SH_CFGIX_ACCOUNT_FUNDING,      SH_CFG_ACCOUNT_FUNDING, "Account Funding Transaction"}, //R007502
        {SH_CFGIX_DCVV_CVC3,      	SH_CFGIX_DCVV_CVC3, 	"DCVV CVC3"}, 
        {SH_CFGIX_CHECK_MERCHANT,      	SH_CFG_CHECK_MERCHANT,"Check Merchant"},
        {SH_CFGIX_DCVVCVC3_TYPE,      	SH_CFGIX_DCVVCVC3_TYPE, "check DCVV/CVC3 type"},
        {SH_CFGIX_REV_LATERESP,         SH_REV_LATERESP,        "Reversal on late response"},
        {SH_CFGIX_CAAV_CAVV_VERIFY,    	SH_CFGIX_CAAV_CAVV_VERIFY, "CAVV Verify"}, 
        {SH_CFGIX_AMEX_CSC,      	SH_CFGIX_AMEX_CSC, 	"Amex CSC"}, 
        {SH_CFGIX_ENABLE_DUAL_SITE_BRIDGE,      SH_CFG_ENABLE_DUAL_SITE_BRIDGE, "Route msg across site"},
        {SH_CFGIX_ALLOW_ZERO_AMT_PREAUTH, SH_CFG_ALLOW_ZERO_AMT_PREAUTH, "Allow zero amount Pre Auth Transaction"},
        {SH_CFGIX_SUBSECOND_TIMEOUT,    SH_ADDFLAG_TIMEOUT_DECISECOND,"Deci-second timeout"},
	{SH_CFGIX_CAAV_CAVV_3DS_VERIFY_STAND_IN_ONLY, SH_CFGIX_CAAV_CAVV_3DS_VERIFY_STAND_IN_ONLY, "Verify CAVV/3DS only in Stand-in"},
	{SH_CFGIX_TOKEN_TXN_CHK, SH_CFGIX_TOKEN_TXN_CHK, "Token Transaction Processing Checks"},
	{SH_CFGIX_KPE_KEYBLOCK,         SH_CFG_KPE_KEYBLOCK,"Key Block KeyType"},
	{SH_CFGIX_ENABLE_REFNUM_EVENTKEY,   SH_CFG_ENABLE_REFNUM_EVENTKEY, "Create event key based on reference number"},
        {-1}
};


ist_ElfId_t NETWORK_DATA_REQ_id=-1;
ist_ElfId_t EMV_BUF_id=-1;
ist_ElfId_t DN_SEG_id=-1;
ist_ElfId_t NETWORK_SETTLEMENT_DATA_RESP_id = -1;
ist_ElfId_t NETWORK_SETTLEMENT_DATA_id = -1;
ist_ElfId_t ORIG_ENV_id = 0;


ShcAppBase::ShcAppBase(): pcode_req(-1), shcIsSwitch(0)
{
	serverMailboxId = -1;
	shcmsgLogObj = (ShcLog *)shcHelperRegister.getTargetObj(SHC_ShcLog);
	shc600LogObj = (Shc600Log *)shcHelperRegister.getTargetObj(SHC_Shc600Log);
	//memset(&shccard, 0, sizeof(shccard));
	
	shcmsgHelperObj = (ShcmsgHelper *)shcHelperRegister.getTargetObj(SHC_ShcmsgHelper);
	shcSafIOHelperObj = (ShcSafIOHelper *)shcHelperRegister.getTargetObj(SHC_ShcSafIOHelper);
	shcKeyObj  = (ShcKeyHelper *)shcHelperRegister.getTargetObj(SHC_ShcKeyHelper);
	shcMacObj = (ShcMacHelper *)shcHelperRegister.getTargetObj(SHC_ShcMacHelper);
	shcNotifyObj = (ShcNotify *)shcHelperRegister.getTargetObj(SHC_ShcNotify);
	shcTimerObj = (ShcTimerHelper *)shcHelperRegister.getTargetObj(SHC_ShcTimerHelper);
	shcHelperObj = (ShcHelper *)shcHelperRegister.getTargetObj(SHC_ShcHelper);
	issProfileObj = (IssProfile *)shcHelperRegister.getTargetObj(SHC_IssProfile);
	acqProfileObj = (AcqProfile *)shcHelperRegister.getTargetObj(SHC_AcqProfile);
	instProfileObj = (InstProfile *)shcHelperRegister.getTargetObj(SHC_InstProfile);
	shcDKEApiObj = (ShcDKEHelper *)shcHelperRegister.getTargetObj(SHC_ShcDKEHelper);
	if (strcmp("shccmd",argv0)) /* Condtion to check if the function is called from shccmd utility */
	{
		shcGenLogHelperObj = (ShcGenericLogHelper *)shcHelperRegister.getTargetObj(SHC_ShcGenericLogHelper); // R030273
		shcGenericLogObj = (ShcGenericLog *)shcHelperRegister.getTargetObj(SHC_ShcGenericLog);	//	R015826
	}
	shcBinObj = (ShcBin *)shcHelperRegister.getTargetObj(SHC_ShcBin);
	mcastHelperObj = new McastHelper();
	updateMemHelperObj = new UpdateMemHelper();
	entityStatusObj = new EntityStatus();
	shcBalancerObj = (ShcBalancer *)shcHelperRegister.getTargetObj(SHC_ShcBalancer);
	shcSharedMemoryHelperObj = (ShcSharedMemoryHelper *)shcHelperRegister.getTargetObj(SHC_ShcSharedMemoryHelper);
	shcDuplicateChkObj = (ShcDuplicateChk *)shcHelperRegister.getTargetObj(SHC_ShcDuplicateChk);
	shcPinTryCounterObj = (ShcPinTryCounter *)shcHelperRegister.getTargetObj(SHC_ShcPinTryCounter);
	shcCardStatusHelperObj = (ShcCardStatusHelper *)shcHelperRegister.getTargetObj(SHC_ShcCardStatusHelper);
	shcCardStatusChngAlwObj = (ShcCardStatusChngAlw *)shcHelperRegister.getTargetObj(SHC_ShcCardStatusChngAlw);
	shc300ReqDBObj = (Shc300ReqDB *)shcHelperRegister.getTargetObj(SHC_Shc300ReqDB);
	shc300Obj = (SHC300 *)shcHelperRegister.getTargetObj(SHC_Shc300);
	issProfileExtObj = (IssProfileExtended *)shcHelperRegister.getTargetObj(SHC_IssProfileExtended);

	try
	{
		binRouteObj = (BinRoute *)shcHelperRegister.getTargetObj(SHC_BinRoute);
	}
	catch(...)
	{
		binRouteObj = NULL;
	}

	
	shcGenAuthNumFrom = shcGenAuthNumRandom;
	shc_add_auth_saf = 0;
	shcReturnDBError = 0;
	shc_use_sw_des = 0;
	flrfd = 0;
	netid = -1;
	settlementid = -1;
	shckeyParamsList = NULL;

	/*
	 *	Standard message class descriptions
	 */
	shcmsgdesc = NULL;
	DEBUG_ON = 0;


	shclog_specified_msgtype = 0;		/* The message type that should be located. *
												 * 0 means not specified         R008689    */  
	acquirerShcParamsList = NULL;
	issuerShcParamsList = NULL;
	shcNewGentrace = (-1);
	shcExtendedEventLocate = 0;
	saf_interleave = 0;  /* R011925 */

	tmpShcOmsg = NULL;
    int tmpElfId = 0;
    int sleepTime = 0;
    while (sleepTime < 30)
    {
        //This is the first elf id, maybe edict not ready yet, give it some some time
	    NETWORK_DATA_REQ_id = tmpElfId = ElfIdMap::elf_to_id("NETWORK_DATA_REQ");
	    if (tmpElfId <= 0)
	    {
            sleep(1);
        }
        else
            break;
        sleepTime++;
    }
    if (tmpElfId <= 0)
    {
	    OTraceFatal("F-SHC-2101:Can't find elf id for NETWORK_DATA_REQ, quit...\n");
		throw 1;
    }
	EMV_BUF_id = tmpElfId = ElfIdMap::elf_to_id("EMV_BUF");
	if (tmpElfId <= 0)
	{
		OTraceFatal("F-SHC-2102:Can't find elf id for EMV_BUF, quit...\n");
		throw 1;
	}
	
	DN_SEG_id = tmpElfId = ElfIdMap::elf_to_id("DN_SEGMENT");
	if (tmpElfId <= 0)
	{
		OTraceFatal("F-SHC-2103:Can't find elf id for DN_SEG, quit...\n");
		throw 1;
	}
	NETWORK_SETTLEMENT_DATA_id = tmpElfId = ElfIdMap::elf_to_id("NETWORK_SETTLEMENT_DATA");
	if (tmpElfId <= 0)
	{
		OTraceFatal("F-SHC-2104:Can't find elf id for NETWORK_SETTLEMENT_DATA, quit...\n");
		throw 1;
	}
	NETWORK_SETTLEMENT_DATA_RESP_id = tmpElfId = ElfIdMap::elf_to_id("NETWORK_SETTLEMENT_DATA_RESP");
	if (tmpElfId <= 0)
	{
		OTraceFatal("F-SHC-2105:Can't find elf id for NETWORK_SETTLEMENT_DATA_RESP, quit...\n");
		throw 1;
	}
	ORIG_ENV_id = tmpElfId = ElfIdMap::elf_to_id("ORIG_ENV");
	if (tmpElfId <= 0)
	{
		OTraceFatal("F-SHC-2106:Can't find elf id for ORIG_ENV, quit...\n");
		throw 1;
	}

}

/*------------------------------------------------------------------------*
 * End of file shc_mac.c
 *------------------------------------------------------------------------*/
