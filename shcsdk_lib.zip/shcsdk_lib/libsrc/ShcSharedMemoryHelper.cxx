static char _ShcSharedMemoryHelper_cxx_what[] = "@(#) ShcSharedMemoryHelper.cxx 1.3 18/09/28 12:56:41";

/*
 *  Copyright (C) 2004 eFunds Corporation ("eFunds").  All Rights Reserved.
 *  eFunds Canada Corporation is an authorized user.
 *
 *  IST is a registered trademark of eFunds Corporation.  Other brand or
 *  product names are trademarks or registered trademarks of their respective
 *  holders.
 *
 *  The information contained herein is the unpublished proprietary property
 *  of eFunds.  Except as specifically authorized in writing by eFunds, the
 *  holder of this document shall: i) keep all information contained herein
 *  confidential, and ii) protect the information, in whole or in part, from
 *  disclosure and dissemination to all third parties.
 *
 *  This document and the software described in it are furnished under license
 *  and may be used or copied only in accordance with the terms of such license.
 *  This document is supplied for information purposes only, is subject to
 *  change without notice, and should not be construed as a commitment by
 *  either eFunds Corporation or eFunds Canada Corporation.
 *
 *
 *                        MODIFICATION HISTORY                  REVIEW
 *
 *	SPR#	Who	Date	Description			Who	Date
 * ===========================================================================
 *R000000 ztang	21dec91	Creation

 */
/* File Number 174 */

#include <stdio.h>
#include <string.h>
#include <ctype.h>
#include <oasis.h>
#include <oasisenv.h>
#include <rules.h>
#include <dbm.h>
#include <mb.h>
#include <tm.h>
#include <dbm_private.h>
#include <oc/oc_string.h>
#include <ist_otrace.h>
#include <Ccard_scheme.h>
#include <Cinstitution.h>
#include <shc_callback.h>
#include <shcmsgdef.h>
#include <security.h>
#include <shcfmt.h>
#include <shc.h>
#include <shcpreauth.h>
#include <ic/ic_shcmsg.h>
#include <ic/ic_instid.h>
#include <ic/ic_bin.h>
#include <ic/ic_pan.h>
//#include <emvchipcond.h>
#include <ShcSender.h>
#include <istcurrency.h>
#include <shc500std.h>
#include <ShcmsgHelper.h>
#include <ShcKeyHelper.h>
#include <ShcTimerHelper.h>
#include <hotrange.h>
#include <CShcLog.h>
#include <ShcProcessor.h>
#include <ShcDKEHelper.h>
#include <mt_iss_profile.h>
#include <mt_acq_profile.h>
#include <ShcAppBase.h>

#include <ShcMacHelper.h>
#include <CShcNotify.h>
#include <ShcSharedMemoryHelper.h>
#include <IssProfile.h>
#include <AcqProfile.h>
#include <InstProfile.h>
#include <Shc600Log.h>
#include <ShcSafIOHelper.h>
#include <cardprod_access.h>						// R027759 21Apr2010

#include <HaPtmCctHelper.h>
#include <ShcSharedMemoryHelper.h>
#include <UpdateMemHelper.h>

int ShcSharedMemoryHelper::lockRule(const char *ruleName, int *isLocked, int *appid)
{
	if (*appid < 0)
	{
		*appid = rm_getappid(ruleName);
		if (*appid < 0)
			OTraceError("F-SHC-174001:Failed to get %s appid. shared memory update request will not be send.\n", ruleName);
	}

	if ( (*appid >= 0) && (rm_appLockMemory(*appid) < 0 ))
	{
		OTraceError("E-SHC-174002:Can't get lock, just update the shared-cash directly\n");
	}
	else
		*isLocked = 1;
	
	return 0;
}

int ShcSharedMemoryHelper::updateCurrentVersion(const char *ruleName, int isLocked, int appid, char *ruleData, int size)
{
	if ((appid >= 0) && rm_attachedcurrent(appid)) //rm_attachedcurrent, ret 0:is current, otherwise:not current
	{
		if (updateMemHelperObj)
		{
			if ( updateMemHelperObj->sendMemUpdate((char *)ruleName, (char *)ruleData, size)<0)
			{
				OTraceError("E-SHC-174003:Failed to send shared memory update request\n");
			}
			else
				OTraceDebug("D-SHC-174004:Send memory update request successful\n");
		}
		else
			OTraceError("E-SHC-174005:updateMemHelperObj is NULL, no memory update sent\n");
	}
	
	if (isLocked)
		rm_appUnlockMemory(appid);
	
	return 0;
}

int ShcSharedMemoryHelper::attachCurrent(int *appid, struct rules_keytab **pAppHead, const char *ruleName)
{
	if (*appid < 0)
	{
		if (ruleName)
		{
			*appid = rm_getappid(ruleName);
			if (*appid < 0)
			{
				OTraceError("F-SHC-174006:Failed to get %s appid. Can't attach to %s.\n", ruleName);
				return -1;
			}
		}
		else
		{
			OTraceError("E-SHC-174007: rule  can't be found. bin can't be located"
				"Check shared-cash rule is configured and shc_initsys() is called\n");
			return -1;
		}
	}
	
	if (rm_attach(*appid, RULES_VER_CURRENT)<0)
	{
		OTraceError("E-SHC-174008:can't rm_attach() failed.");
		return -1;
	}
	
	if (pAppHead)
		*pAppHead = rm_getapphead(*appid);
	return 0;
}
