//
// Copyright (C) 2009 eFunds Corporation ("eFunds").  All Rights Reserved.
// eFunds Canada Corporation is an authorized user.
//
// IST is a registered trademark of eFunds Corporation.  Other brand or
// product names are trademarks or registered trademarks of their respective
// holders.
//
// The information contained herein is the unpublished proprietary property
// of eFunds.  Except as specifically authorized in writing by eFunds, the
// holder of this document shall: i) keep all information contained herein
// confidential, and ii) protect the information, in whole or in part, from
// disclosure and dissemination to all third parties.
//
// This document and the software described in it are furnished under license
// and may be used or copied only in accordance with the terms of such license.
// This document is supplied for information purposes only, is subject to
// change without notice, and should not be construed as a commitment by
// either eFunds Corporation or eFunds Canada Corporation.
//
/*
 * Description:
 *
 *      MODIFICATION HISTORY
 *
 *  Date         SCR            Who        Description
 *  ===========================================================================
*/
static const char* _ShcCardStatusChngAlw_cxx_what = "@(#) ShcCardStatusChngAlw.cxx p4.1.25 2014/09/08 00:44:40";
#include <auto_ptr.h>
#include <dbm.h>
#include <dbm_private.h>

#include <ShcCardStatusChngAlw.h> 
#include <shc.h>
#include <ExceptionObject.h>
#include <istsafe.h>

ShcCardStatusChngAlw::ShcCardStatusChngAlw()
{
}

int ShcCardStatusChngAlw::checkallowance(ShcmsgHeader * header,char *status,char *new_status)
{
	static ISTCardStatChngShmReader *readerObj=NULL;
	 
	if (!readerObj)
	{
	     readerObj=new ISTCardStatChngShmReader;
	}
	char lstatus[5];
	char lnewstatus[5];
	char userbin_id[10];
	 
	OTraceDebug("D-ALLOW-091001: Status:[%s][%d]new_status:[%s][%d] \n",status,strlen(status),new_status,strlen(new_status));

	memset(instid,0x00,sizeof(instid));
	memset(userbinid,0x00,sizeof(userbinid));

	istsafe_strcpy(instid,sizeof(instid),header->issShcBin->binPkg->bin.institutionid);
	istsafe_strcpy(userbinid,sizeof(userbinid),header->issShcBin->binPkg->bin.userbinid);
	snprintf(lstatus,sizeof(lstatus),"%-4s",status);
	snprintf(lnewstatus,sizeof(lnewstatus),"%-4s",new_status);

	OTraceDebug("D-ALLOW-091002: Status:[%s][%d]new_status:[%s][%d] instid:[%s][%d] userbinid:[%s][%d] \n",lstatus,strlen(lstatus),lnewstatus,strlen(lnewstatus),instid,strlen(instid),userbinid,strlen(userbinid));

	 char result=readerObj->setallowdata(instid,userbinid,lstatus,lnewstatus);

	OTraceDebug("D-ALLOW-091003: Result:	 [%c] \n",result);

	if(result == 'N')
        {
                istsafe_strcpy(userbin_id,sizeof(userbin_id),"*");
                memset(userbinid,0x00,sizeof(userbinid));
                snprintf(userbinid,sizeof(userbinid),"%10s",userbin_id);
                result=readerObj->setallowdata(instid,userbinid,lstatus,lnewstatus);
                OTraceDebug("D-ALLOW-091004:checkallowance with wildcard Result: [%c] \n",result);
        }

	 if(result=='+')
		 return 1;
	 else if (result=='-') 
	 {
		if(strcmp(header->msg.txnSrc,"GUI") == 0)
			return 0;
		else
			return 1;
	 }
	 else 
		return 0;
}
ShcCardStatusChngAlw::~ShcCardStatusChngAlw()
{
}
