//
// Copyright (C) 2009 eFunds Corporation ("eFunds").  All Rights Reserved.
// eFunds Canada Corporation is an authorized user.
//
// IST is a registered trademark of eFunds Corporation.  Other brand or
// product names are trademarks or registered trademarks of their respective
// holders.
//
// The information contained herein is the unpublished proprietary property
// of eFunds.  Except as specifically authorized in writing by eFunds, the
// holder of this document shall: i) keep all information contained herein
// confidential, and ii) protect the information, in whole or in part, from
// disclosure and dissemination to all third parties.
//
// This document and the software described in it are furnished under license
// and may be used or copied only in accordance with the terms of such license.
// This document is supplied for information purposes only, is subject to
// change without notice, and should not be construed as a commitment by
// either eFunds Corporation or eFunds Canada Corporation.
//
/*
 * Description:
 *
 *      MODIFICATION HISTORY
 *
 *  Date         SCR            Who        Description
 *  ===========================================================================
*/

static const char _SHCPINTRYCOUNTER_cxx_what[] = "@(#)SHCPINTRYCOUNTER.cxx 1.4 14/08/19 10:03:42";
#include <auto_ptr.h>
#include <dbm.h>
#include <dbm_private.h>

#include <ShcPinTryCounter.h> 
#include <shc.h>
#include <ExceptionObject.h>
ShcPinTryCounter::ShcPinTryCounter()
{
	_smtSelOne = NULL;
	_smtUpdateInc1 = NULL;
	_smtUpdateIncN = NULL;
	_smtUpdate = NULL;
	_smtInsert = NULL;
	_dbConn = NULL;
	stmt = NULL;
}

void ShcPinTryCounter::dbInit()
{
	if( _dbConn != NULL )
		return;

	_dbConn = new DBMConn(dbm_dbconn);
}


int ShcPinTryCounter::getCnt(ShcmsgHeader *header,int reset_hours)
{
	dbInit();

	long fpin; 
	OTraceDebug("D-PINTRY-04101: Fetching failed pin count \n");

	int rc=selectOne(header->msg.pan);

	if(rc!=0)
	{
		OTraceError("E-PINTRY-04102: Error while Selecting Failedpin count\n");
		return 0;
	}
	else		
	{
		try
		{
			recycle();
			memcpy(pan,header->msg.pan,sizeof(pan));
			shc_normalizepan(pan);
			site_id=header->getMsgSiteId();
			siteid.setValue(site_id);

			_smtSelOne->execute();

			int rc = _smtSelOne->fetch();

			failedCount.getValue(fpin);
			updatedtime.getValue(updated);

			if(rc==DBM_SUCCESS)
			{
				OTraceDebug("D-PINTRY-04103: failedpin :%ld reset_hours:%d updated :%s\n",
				fpin,reset_hours,(char*)(updated).asString());
			}
			_smtSelOne->close();

			if( rc == DBM_NO_DATA )
			{

				OTraceDebug("D-PINTRY-04104: Record not found\n");
				return 0;

			}

		}
		catch (const DBMException& e)
		{
			OTraceError
			(
				"E-PINTRY-04105: Caught exception during Selection,"
				"native error=%d, sqlstate=%.5s, msg=%s\n",
				e.getNativeError(), e.getSQLState().data(), e.getErrMsg().data()
			);
			return ( 0 );
		}
	}
	OCDateTime current;
	current.addHours((-1)*reset_hours);
	if(reset_hours!=0)
	{
		OTraceDebug("D-PINTRY-04106: Updated :%s current:%s \n",(char *)(updated).asString(),(char *)(current).asString());
		if(updated<current)
		{
			int rc=resetCnt(header);	
			if(rc==0)
			return 0;
			
		}
	}
	return fpin;

}
int ShcPinTryCounter::resetCnt(ShcmsgHeader *header)
{
	dbInit();
	try
	{
		int sno=1;
		if ( !_smtUpdate)
		{
			_smtUpdate = _dbConn->getStmt();

			_smtUpdate->prepare( "update shcpintrycounter set "
					     "failedpins = 0 ,"
					     "updated = ? "
					     "where site_id = ? and pan= ?");
		         _smtUpdate->bindParam(  sno++, updatedtime );
			 _smtUpdate->bindParam(  sno++, siteid );
			 _smtUpdate->bindParam(  sno++, DBM_PANTOKENTYPE, pan, sizeof(pan), NULL );			

		}
		
		recycle(); 
                memcpy(pan,header->msg.pan,sizeof(pan));
                shc_normalizepan(pan);
		OCDateTime current;
                updatedtime.setValue(current);

		site_id=header->getMsgSiteId();
		siteid.setValue(site_id);

		int rc=_smtUpdate->execute();

		if ( rc != DBM_SUCCESS )
		{
			OTraceDebug( "D-PINTRY-04108: Cannot reset ShcPinTryCounter");
			return ( -1 );
		}
		_smtUpdate->close();

	}
	catch (const DBMException& e)
	{
		OTraceError
		(
			"E-PINTRY-04109: Caught exception during reseting,"
			"native error=%d, sqlstate=%.5s, msg=%s\n",
			e.getNativeError(), e.getSQLState().data(), e.getErrMsg().data()
		);
		return ( -2 );
	}

	OTraceDebug("D-PINTRY-04110: Reseted ShcPinTryCounter \n");
	return 0;
}


int ShcPinTryCounter::incCnt(ShcmsgHeader *header)
{
	dbInit();
	try
	{
		int rc=getCount(header->msg.pan);
                if(rc<0)
                        return -1;
                if(rc==0)
                        insertInPintry(header,0);
                else
                {
			int sno=1;
			if(!_smtUpdateInc1)
			{

				_smtUpdateInc1 = _dbConn->getStmt();

				_smtUpdateInc1->prepare("update shcpintrycounter set "
							"failedpins = failedpins + 1 ,"
							"updated = ? "
							"where site_id = ? and pan = ?");
				_smtUpdateInc1->bindParam(  sno++, updatedtime );
				_smtUpdateInc1->bindParam(  sno++, siteid );
				_smtUpdateInc1->bindParam(  sno++, DBM_PANTOKENTYPE, pan, sizeof(pan), NULL );
			}


			recycle();
			memcpy(pan,header->msg.pan,sizeof(pan));
			shc_normalizepan(pan);

			OCDateTime current;
			updatedtime.setValue(current);
			site_id=header->getMsgSiteId();
			siteid.setValue(site_id);

			int rc=_smtUpdateInc1->execute();
			_smtUpdateInc1->close();
			if(rc != DBM_SUCCESS)
			{
				OTraceDebug( "D-PINTRY-04112: Cannot update ShcPinTryCounter\n");
				return ( -1 );
			}
			_smtUpdateInc1->close();
		}
					
	}
	catch (const DBMException& e)
	{
		OTraceError
		(
			"E-PINTRY-04113: Caught exception during updation,"
			"native error=%d, sqlstate=%.5s, msg=%s\n",
			e.getNativeError(), e.getSQLState().data(), e.getErrMsg().data()
		);
	return ( -2 );
	}

	OTraceDebug( "D-PINTRY-04114: Incremented failedpin count by 1 for pan<%s>\n",shcApp->shcHelperObj->shc_maskpan(pan));
	return 0;

}
int ShcPinTryCounter::incCnt(ShcmsgHeader *header,int increment)
{
        dbInit();
        try
        {
		int rc=getCount(header->msg.pan);
                if(rc<0)
                        return -1;
                if(rc==0)
                        insertInPintry(header,increment);
		else
		{
			int sno=1;
			if(!_smtUpdateIncN)
			{

				_smtUpdateIncN = _dbConn->getStmt();
				_smtUpdateIncN->prepare("update shcpintrycounter set "
							"failedpins = failedpins + ? ,"
							"updated = ? "
							"where site_id = ? and  pan = ?");
				_smtUpdateIncN->bindParam(  sno++, inc );
				_smtUpdateIncN->bindParam(  sno++, updatedtime );
				_smtUpdateIncN->bindParam(  sno++, siteid );
				_smtUpdateIncN->bindParam(  sno++, DBM_PANTOKENTYPE, pan, sizeof(pan), NULL );
			}
			recycle();
			memcpy(pan,header->msg.pan,sizeof(pan));
			shc_normalizepan(pan);

			if(increment==0)
				inc.setValue(increment+1);
			else
				inc.setValue(increment);

			OCDateTime current;
			updatedtime.setValue(current);

			site_id=header->getMsgSiteId();
			siteid.setValue(site_id);

			int rc= _smtUpdateIncN->execute(); 
			_smtUpdateIncN->close();
			if(rc != DBM_SUCCESS)
			{
				OTraceDebug( "D-PINTRY-04115: Cannot update ShcPinTryCounter\n");
				return ( -1 );
			}

		}

        }
	catch (const DBMException& e)
        {
                OTraceError
                (
                        "E-PINTRY-04116: Caught exception during updation,"
                        "native error=%d, sqlstate=%.5s, msg=%s\n",
                        e.getNativeError(), e.getSQLState().data(), e.getErrMsg().data()
                );
                return ( -2 );
        }

        OTraceDebug( "D-PINTRY-04117: Incremented failedpin count for pan <%s>\n",shcApp->shcHelperObj->shc_maskpan(pan));
	return 0;
}

ShcPinTryCounter::~ShcPinTryCounter()
{
	if(_dbConn)
	delete _dbConn;

	if(_smtSelOne)
	delete 	_smtSelOne;

        if(_smtUpdateInc1)
        delete _smtUpdateInc1;

       if(_smtUpdateIncN)
        delete _smtUpdateIncN;

        if(_smtUpdate)
        delete _smtUpdate;

        if(_smtInsert)
        delete _smtInsert;
}
int ShcPinTryCounter :: selectOne(char *Pan)
{
        if(!_smtSelOne)
        {
                _smtSelOne=_dbConn->getStmt();

                try
                {
                        int sno = 1;
                        int cnt = 2;
                        memset( _ind, 0, sizeof(_ind) );

                                _smtSelOne->prepare
                                (
                                "SELECT "
				"failedpins ,"
				"updated "
				"FROM shcpintrycounter "
				"WHERE pan = ? and site_id =?"
				);
				_smtSelOne->bindCol(  sno++, failedCount );
				_smtSelOne->bindCol(  sno++, updatedtime );
				_smtSelOne->bindParam(  1, DBM_PANTOKENTYPE, pan, sizeof(pan), NULL );
				_smtSelOne->bindParam(  2, siteid );
		}
                catch (const DBMException& e)
                {
                        OTraceError
                        (
                                "E-PINTRY-04119: Caught exception during Selection,"
                                "native error=%d, sqlstate=%.5s, msg=%s\n",
                                e.getNativeError(), e.getSQLState().data(), e.getErrMsg().data()
                        );
                        return ( -2 );
                }
	}

	return 0;
}
int  ShcPinTryCounter::insertInPintry(ShcmsgHeader *header,int increment) //increment represents POSPINCODE 
{
	recycle();
	dbInit();
	memset( _ind, 0, sizeof(_ind) );
	int sno = 1;
	int cnt = 2;

	try
	{
		if(insertOne(header)==1)
		{
			recycle();
			 memcpy(pan,header->msg.pan,sizeof(pan));
			 shc_normalizepan(pan);

			if(increment==0)
				inc.setValue(increment+1);
			else
				inc.setValue(increment);

			site_id=mbGetSiteId();
			//site_id=header->getMsgSiteId();
			siteid.setValue(site_id);
			OCDateTime current; 
			updatedtime.setValue(current);
			
			OTraceDebug("D-PINTRY-04120: Inserting Pan :%s %d Site_is :%d failedpin :%d \n",
			shcApp->shcHelperObj->shc_maskpan(pan),sizeof(pan),header->getMsgSiteId(),increment);
		}
		if(_smtInsert->execute()!=DBM_SUCCESS)
		{
			OTraceError("E-PINTRY-04121: Cannot insert ShcPinTryCounter\n");
			return ( -1 );
		}
		_smtInsert->close();

	}
	catch (const DBMException& e)
	{
		OTraceError
		(
			"E-PINTRY-04120: Caught exception during insert,"
			"native error=%d, sqlstate=%.5s, msg=%s\n",
			e.getNativeError(), e.getSQLState().data(), e.getErrMsg().data()
		);
		return ( -2 );
	}
	
        OTraceDebug("D-PINTRY-04141:Inserted entry into ShcPinTryCounter\n");
        return 1;

}
int ShcPinTryCounter :: insertOne(ShcmsgHeader* header)
{
        if(!_smtInsert)
        {
                _smtInsert=_dbConn->getStmt();
                try
                {
                        int sno = 1;
			_smtInsert->prepare ("insert into shcpintrycounter ("
                                                             "failedpins,"
                                                             "pan,"
                                                             "site_id,"
                                                             "created,"
                                                             "updated"
                                                             ")values"
                                                             "(?,?,?,?,?)");

			_smtInsert->bindParam(  sno++, inc );
			_smtInsert->bindParam(  sno++, DBM_PANTOKENTYPE, pan, sizeof(pan), NULL );
			_smtInsert->bindParam(  sno++, siteid );
			_smtInsert->bindParam(  sno++, updatedtime );
			_smtInsert->bindParam(  sno++, updatedtime );
		}
		catch (const DBMException& e)
		{
			OTraceError
			(
				"E-PINTRY-04121: Caught exception during insert,"
				"native error=%d, sqlstate=%.5s, msg=%s\n",
				e.getNativeError(), e.getSQLState().data(), e.getErrMsg().data()
			);
			return ( -2 );
		}
        }
        return 1;

}
int ShcPinTryCounter :: getCount(char * Pan)
{
        DBMInt recCount;
        long ret;
        try
        {
                memcpy(pan,Pan,sizeof(pan));
                shc_normalizepan(pan);
		site_id=mbGetSiteId();
		siteid.setValue(site_id);
                 if(!stmt)
                 {
                         stmt = _dbConn->getStmt();
                         stmt->prepare( "SELECT count(*) FROM shcpintrycounter where pan= ? and site_id = ?" );
                         stmt->bindCol( 1,recCount );
                         stmt->bindParam( 1,DBM_PANTOKENTYPE,pan,sizeof(pan),NULL );
                         stmt->bindParam( 2,siteid );
                 }
                 stmt->execute();
                 int rc=stmt->fetch();
                 if (rc == DBM_NO_DATA)
                 {
                        OTraceDebug( "D-PINTRY-05037: Recount in SHCNEGATIVEAUTH [%d] \n",rc);
                        return 0;
                 }
                 recCount.getValue(ret);
                 stmt->close();
        }
        catch (const DBMException& e)
        {
                        OTraceError
                        (
                                "E-PINTRY-05036: caught exception during fetching,"
                                "native error=%d, sqlstate=%.5s, msg=%s\n",
                                e.getNativeError(), e.getSQLState().data(), e.getErrMsg().data()
                        );
                        return ( -2 );

	}
        return ret;
}

void ShcPinTryCounter::recycle()
{
	site_id=0;
	memset(pan,0x00,sizeof(pan));
	updatedtime.setValue(0);
	inc.setValue(0);
	siteid.setValue(0);
}
