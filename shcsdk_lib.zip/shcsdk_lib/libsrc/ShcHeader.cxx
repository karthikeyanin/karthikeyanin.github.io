static char _ShcHeader_cxx_what[] = "@(#) ShcHeader.cxx 1.9 05/01/10 14:56:22";

/*
 *  Copyright (C) 2004 eFunds Corporation ("eFunds").  All Rights Reserved.     
 *  eFunds Canada Corporation is an authorized user.                            
 *                                                                              
 *  IST is a registered trademark of eFunds Corporation.  Other brand or        
 *  product names are trademarks or registered trademarks of their respective   
 *  holders.                                                                    
 *                                                                              
 *  The information contained herein is the unpublished proprietary property    
 *  of eFunds.  Except as specifically authorized in writing by eFunds, the     
 *  holder of this document shall: i) keep all information contained herein     
 *  confidential, and ii) protect the information, in whole or in part, from    
 *  disclosure and dissemination to all third parties.                          
 *                                                                          
 *  This document and the software described in it are furnished under license  
 *  and may be used or copied only in accordance with the terms of such license.
 *  This document is supplied for information purposes only, is subject to      
 *  change without notice, and should not be construed as a commitment by       
 *  either eFunds Corporation or eFunds Canada Corporation. 
 *
 *
 *                        MODIFICATION HISTORY                  REVIEW
 *
 * SCR#     Who    Date  Description
 * ===========================================================================
 * R0xxxxx 
 */

//File Number 24

#include <shc.h>
#include <shcdef.h>
#include <shcextbuf.h>

#include <ShcSdkCommon.h>
#include <ShcHeader.h>
#include <ShcAppBase.h>
#include <ShcHelper.h>
#include <ShcBin.h>

ShcHeader::ShcHeader()
{
	flag = 0;	
	repeatFlag = 0;
	denyRespCode = 0;
	returnFlag = 0;
	logFlag = 0;
	shcerr = 0;		
	time_in = 0;		
	time_out = 0;		
	eventId = -1;		
	applMailboxId = 0;	
	shcLogObj = NULL;		
	issShcBin = NULL;
	acqShcBin = NULL;
	procFlag = 0;
	statusFlag = 0;
}

ShcHeader::ShcHeader(ShcHeader &hdr)
{
	flag = hdr.flag;	
	repeatFlag = hdr.repeatFlag;
	denyRespCode = hdr.denyRespCode;
	procFlag = hdr.procFlag;		
	statusFlag = hdr.statusFlag;	
	logFlag = hdr.logFlag;
	shcerr = hdr.shcerr;		
	time_in = hdr.time_in;		
	time_out = hdr.time_out;		
	eventId = hdr.eventId;		
	applMailboxId = hdr.applMailboxId;
	shcLogObj = hdr.shcLogObj;
//	issShcBin = NULL;
//	acqShcBin = NULL;
    issShcBin = (ShcBin *)shcHelperRegister.getTargetObj(SHC_ShcBin);
    *issShcBin= *hdr.issShcBin;
    acqShcBin = (ShcBin *)shcHelperRegister.getTargetObj(SHC_ShcBin);
    *acqShcBin = *hdr.acqShcBin;
}

void ShcHeader::copyFromHeader(ShcHeader *hd)
{
	flag = hd->flag;	
	repeatFlag = hd->repeatFlag;
	denyRespCode = hd->denyRespCode;
	procFlag = hd->procFlag;		
	statusFlag = hd->statusFlag;	
	logFlag = hd->logFlag;
	shcerr = hd->shcerr;		
	time_in = hd->time_in;		
	time_out = hd->time_out;		
	eventId = hd->eventId;		
	applMailboxId = hd->applMailboxId;	
	shcLogObj = hd->shcLogObj;		
//	issShcBin = NULL;
//	acqShcBin = NULL;
    issShcBin = (ShcBin *)shcHelperRegister.getTargetObj(SHC_ShcBin);
    *issShcBin= *hd->issShcBin;
    acqShcBin = (ShcBin *)shcHelperRegister.getTargetObj(SHC_ShcBin);
    *acqShcBin = *hd->acqShcBin;
	
	return;
}


ShcHeader::~ShcHeader()
{
	if ( shcLogObj )
	{
		//delete shcLogObj;
		shcLogObj = NULL;
		OTraceDebug("D-SHC-024001: Return *shcLogObj in ~ShcHeader()\n");
	}
	if (issShcBin)
	{
		delete issShcBin;
		issShcBin = NULL;
	}
	if (acqShcBin)
	{
		delete acqShcBin;
		acqShcBin = NULL;
	}
}

int ShcHeader::createdInternal()
{
	return (flag & MSG_CREATED_INTERNAL);
}

int ShcHeader::setAcqShcBin(char *bin)
{
	if (!acqShcBin)
		acqShcBin = (ShcBin *)shcHelperRegister.getTargetObj(SHC_ShcBin);
	return acqShcBin->setBinPkg(bin);
}

int ShcHeader::setIssShcBin(char *bin)
{
	if (!issShcBin)
		issShcBin = (ShcBin *)shcHelperRegister.getTargetObj(SHC_ShcBin);
	return issShcBin->setBinPkg(bin);
}

void ShcHeader::setReturnFlag(int respcode)
{
	denyRespCode = respcode;
	if ( (respcode == SHC_RC_Approved) || (respcode == SHC_RC_PartialDispense) )
		statusFlag |= TXN_PROC_APPROVED;
	else
	{
		statusFlag |= TXN_PROC_DENIED;
		
		procFlag |= TXN_PROC_SKIP_ENRICH |
			TXN_PROC_SKIP_RESTORE |
			TXN_PROC_SKIP_EDIT | 
			TXN_PROC_SKIP_VERIFY |
			TXN_PROC_SKIP_DOWORK;
	}
}

void ShcHeader::setSkipFlag(unsigned short skipFlag)
{
	procFlag |= skipFlag;
}

void ShcHeader::setIgnoreFlag()
{
	procFlag |= TXN_PROC_SKIP_ENRICH |
				TXN_PROC_SKIP_RESTORE |
				TXN_PROC_SKIP_EDIT | 
				TXN_PROC_SKIP_VERIFY|
				TXN_PROC_SKIP_DOWORK;
	statusFlag |= TXN_PROC_DROPPED;
	shcerr |= SH_IGNORE;
}

int ShcHeader::shouldContinue(unsigned short stepFlag)
{
	//stepFlag indicate which step is asked
	return(!(stepFlag&procFlag));
}

int ShcHeader::issBinValid()
{
	if (issShcBin && issShcBin->binPkg)
		return 1;
	else
		return 0;
}

int ShcHeader::acqBinValid()
{
	if (acqShcBin && acqShcBin->binPkg)
		return 1;
	else
		return 0;
}


