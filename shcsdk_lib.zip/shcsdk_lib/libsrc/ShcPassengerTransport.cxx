/*
 *  Copyright (C) 2004 eFunds Corporation ("eFunds").  All Rights Reserved.
 *  eFunds Canada Corporation is an authorized user.
 *
 *  IST is a registered trademark of eFunds Corporation.  Other brand or
 *  product names are trademarks or registered trademarks of their respective
 *  holders.
 *
 *  The information contained herein is the unpublished proprietary property
 *  of eFunds.  Except as specifically authorized in writing by eFunds, the
 *  holder of this document shall: i) keep all information contained herein
 *  confidential, and ii) protect the information, in whole or in part, from
 *  disclosure and dissemination to all third parties.
 *
 *  This document and the software described in it are furnished under license
 *  and may be used or copied only in accordance with the terms of such license.
 *  This document is supplied for information purposes only, is subject to
 *  change without notice, and should not be construed as a commitment by
 *  either eFunds Corporation or eFunds Canada Corporation.
 */
/*
 *
 *                        MODIFICATION HISTORY                  REVIEW
 *
 *      SPR#    Who     Date    Description                     Who     Date
 * ===========================================================================
 */

//File Number 180

#if defined( WIN32 )
#       define SHCDLLEXPORT __declspec(dllexport)
#else
#       define SHCDLLEXPORT
#endif


#include <stdio.h>
#include <sys/types.h>
#include <time.h>
#include <oasis.h>
#include <ist_otrace.h>
#include <shcfmt.h>
#include <shc.h>
#include <ShcPassengerTransport.h>
#include <string.h>
#include <istsafe.h>
#include <dbm_private.h>

ShcPassengerTransport::ShcPassengerTransport()
{
	memset(buff, 0x00, sizeof(buff));
	len = 0;
}
void ShcPassengerTransport::setTagValue(char *TagName, const char *TagValue)
{
	snprintf(buff+len, sizeof(buff)-len, "%s%03d%s", TagName, strlen(TagValue), TagValue);
	len += strlen(TagName) + 3 + strlen(TagValue);
}


void ShcPassengerTransport::setTagValue(char *TagName, int TagValue)
{
	char tbuf[14]={0};
	snprintf(tbuf, sizeof(tbuf),"%d", TagValue);
	snprintf(buff+len, sizeof(buff)-len, "%s%03d%s", TagName, strlen(tbuf), tbuf);
	len += strlen(TagName) + 3 + strlen(tbuf);
}

void ShcPassengerTransport::setTagValueAsDouble(char *TagName, double TagValue)
{
	char tbuf[14]={0};
	snprintf(tbuf, sizeof(tbuf),"%012.2f", TagValue);
	snprintf(buff+len, sizeof(buff)-len, "%s%03d%s", TagName, strlen(tbuf), tbuf);
	len += strlen(TagName) + 3 + strlen(tbuf);
}

char* ShcPassengerTransport::getBuffer()
{
	return buff;
}

int ShcPassengerTransport::getBufferLength()
{
	return len;
}
