static char _BrandBlocked_cxx_what[] = "@(#) BrandBlocked.cxx 1.4.1.1 11/02/16 12:23:50";

/*
 *  Copyright (C) 2004 eFunds Corporation ("eFunds").  All Rights Reserved.     
 *  eFunds Canada Corporation is an authorized user.                            
 *                                                                              
 *  IST is a registered trademark of eFunds Corporation.  Other brand or        
 *  product names are trademarks or registered trademarks of their respective   
 *  holders.                                                                    
 *                                                                              
 *  The information contained herein is the unpublished proprietary property    
 *  of eFunds.  Except as specifically authorized in writing by eFunds, the     
 *  holder of this document shall: i) keep all information contained herein     
 *  confidential, and ii) protect the information, in whole or in part, from    
 *  disclosure and dissemination to all third parties.                          
 *                                                                          
 *  This document and the software described in it are furnished under license  
 *  and may be used or copied only in accordance with the terms of such license.
 *  This document is supplied for information purposes only, is subject to      
 *  change without notice, and should not be construed as a commitment by       
 *  either eFunds Corporation or eFunds Canada Corporation. 
 *
 *
 *                        MODIFICATION HISTORY                  REVIEW
 *
 *	SPR#	Who	Date	Description			Who	Date   
 * ===========================================================================
 * R027802 jyang 25Jan10 Initial version to support "Block by Brand"
 */

/* File Number 171 */

#include <stdio.h>
#include <string.h>
#include <ist_types.h>
#include <istiso.h>
#include <oasis.h>
#include <oasisenv.h>
#include <ist_otrace.h>
#include <rules.h>
#include <shc.h>
#include <ShcBin.h>
#include <BrandBlocked.h>
#include <istsafe.h>

static int setBinUp = 0;

//static char staticBroadcastStr[16384];


BrandBlocked::BrandBlocked()
{
	rm_init();
	
	int appid = rm_getappid(BRAND_BLOCKED_MESSAGE_NAME);
	
	if (appid < 0)
	{
		OTraceInfo("I-SHC-171.01: 'Block by Brand' not used. rule 'shc-bin-route'\n");
		createPseudoSharedMemory();
	}
	else
	{
		rm_attach( appid, RULES_VER_CURRENT );
		appHead = rm_getapphead(appid);
		appKey = rm_getappkey(appid);
	}
	brandEntries = (BLOCK_BY_BRAND *)appKey;

	// USP-1569 -- not useful here because shared-memory could be updated
	// szBrand      = appHead->keysused;
	
	strcpy( blockedBin, "BLOCKEDBIN" );

	// USP-1319
	blockedTxnDest[0]  = 0;
	blockedCardProd[0] = 0;
	memset(blockedNetworkData, 0, sizeof(blockedNetworkData));		// USP-1678
}


BrandBlocked::~BrandBlocked()
{
	
}


int BrandBlocked::createPseudoSharedMemory()
{
	static struct rules_keytab myKeytab = {0};
	static char myAppKey[sizeof(BLOCK_BY_BRAND)] = {0};
	
	appHead = &myKeytab;
	appKey  = myAppKey;
	
	myKeytab.keysused = 0;
	myKeytab.keysize  = sizeof(BLOCK_BY_BRAND);
	myKeytab.nkeys    = 0;
	
	myKeytab.textused = 0;
	myKeytab.textsize = sizeof(BLOCK_BY_BRAND);
	myKeytab.ntext    = 0;
	
	return 0;
}


int BrandBlocked::lookup( char *src, char *dest,  char *product ) 
{
	static int blockAppid = -1;

	if(blockAppid < 0)
	{
		blockAppid = rm_getappid(BRAND_BLOCKED_MESSAGE_NAME);
		if(blockAppid < 0)
		{
			static int printOne = -1;
			{
				if (printOne == -1)
				{
					OTraceWarning("W-SHC-171.07:Failed to get appid %s.\n", BRAND_BLOCKED_MESSAGE_NAME);

					printOne = 1;
				}
			}
			return 0;
		}
	}
	rm_attach( blockAppid, RULES_VER_CURRENT );
	appHead = rm_getapphead(blockAppid);
	appKey = rm_getappkey(blockAppid);
	brandEntries = (BLOCK_BY_BRAND *)appKey;

	int numItems = appHead->keysused;					// USP-1569
	if ( numItems < 1 )
	{
		OTraceDebug( "D-SHC-171.02: 'Block by Brand' not used.\n");
		return 0;
	}
	OTraceDebug( "D-SHC-171.02: block-by-brand-records in memory(%d)\n", numItems);
	
	int i=0;
	for ( i=0; i < numItems; i++ )
	{
		brandEntries = (BLOCK_BY_BRAND *)(appKey + (appHead->keysize * i));
		OTraceDebug("D-SHC-171.03: Checking Block Brand: [%s/%s] [%s/%s] [%s/%s]\n", 
					 src,brandEntries->institutionid, dest,brandEntries->destination, 
					 product, brandEntries->cardproduct);

		if (    src && *src && brandEntries->institutionid[0] 
			&& strcmp(brandEntries->institutionid, src)!=0 )
			continue;
			
		if (    dest && dest[0] && brandEntries->destination[0] 
			&& !ist_regexpcv((char *)brandEntries->destination, dest, 0) )
			continue;
		
		if (   !product || product[0]=='\0' || product[0]=='*' 
			|| brandEntries->cardproduct[0]=='\0' 
			|| ist_regexpcv((char *)brandEntries->cardproduct, product, 0) )
		{
			OTraceDebug("D-SHC-171.04: Found BRAND blocked: [%s/%s] [%s/%s] [%s/%s]\n", 
						 src,brandEntries->institutionid, 
						 dest,brandEntries->destination, product, brandEntries->cardproduct);
			// USP-1319
			// Need to set some info needed by txn processing and back-office processes
			//strcpy((char*)blockedTxnDest, dest);
			//strcpy((char*)blockedCardProd, product);
			istsafe_strcpy((char*)blockedTxnDest, sizeof(blockedTxnDest), dest);
			istsafe_strcpy((char*)blockedCardProd, sizeof(blockedCardProd), product);
			return 1;
		}
	}
	
	if ( i > 0 )
		OTraceDebug("D-SHC-171.05: Continue BRAND: [%s] [%s] [%s]\n", src, dest, product);
//	else
//		OTraceDebug( "D-SHC-171.06: No data for rule %s, table 'brandblocked'\n", 
//		BRAND_BLOCKED_MESSAGE_NAME );
	
	return 0;
}


void BrandBlocked::setBlockedBin( const bin_t aBin )
{
	strncpy( blockedBin, aBin, sizeof(bin_t)-1 );
}


const char *BrandBlocked::getBlockedBin() const
{
	return blockedBin;
}

const char *BrandBlocked::getBlockedDest() const
{
	return blockedTxnDest;
}
	

const char *BrandBlocked::getBlockedProduct() const
{
	return blockedCardProd;
}


// USP-1678
void BrandBlocked::setBlockedNetworkData( char* netData )
{
	if (netData)
		strncpy(blockedNetworkData, netData, sizeof(blockedNetworkData));
	else
		blockedNetworkData[0] = 0;
}


const char *BrandBlocked::getBlockedNetworkData() const
{
	return blockedNetworkData;
}

