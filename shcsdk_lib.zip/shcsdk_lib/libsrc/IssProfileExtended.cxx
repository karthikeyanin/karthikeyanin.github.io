/*
 *  Copyright (C) 2004 eFunds Corporation ("eFunds").  All Rights Reserved.     
 *  eFunds Canada Corporation is an authorized user.                            
 *                                                                              
 *  IST is a registered trademark of eFunds Corporation.  Other brand or        
 *  product names are trademarks or registered trademarks of their respective   
 *  holders.                                                                    
 *                                                                              
 *  The information contained herein is the unpublished proprietary property    
 *  of eFunds.  Except as specifically authorized in writing by eFunds, the     
 *  holder of this document shall: i) keep all information contained herein     
 *  confidential, and ii) protect the information, in whole or in part, from    
 *  disclosure and dissemination to all third parties.                          
 *                                                                          
 *  This document and the software described in it are furnished under license  
 *  and may be used or copied only in accordance with the terms of such license.
 *  This document is supplied for information purposes only, is subject to      
 *  change without notice, and should not be construed as a commitment by       
 *  either eFunds Corporation or eFunds Canada Corporation. 
 *
 *                        MODIFICATION HISTORY                  REVIEW
 *
 * SCR/JIRA Story   Who    Date    Description
 * ===========================================================================
 * R0xxxxx                                                                    
 * IST_SxxxSPyy-zzz xxx: Switch Version; yy: Service Pack Num; zzz: Story Num
 * IST_S770SP12-154 hsh    28Jun18 Created to extend Issuer Profile
 */
static const char* _IssProfileExtende_cxx_what = "@(#) IssProfileExtended.cxx 1.2 18/11/23 12:25:39";

#include <IssProfileExtended.h>
#include<ist_seg_name.h>
#include<ist_seg_fn_data.h>
#include<ist_seg_elf_id_map.h>
#include <ShcmsgHeader.h>

IssProfileExtended::IssProfileExtended() { _shcmsgHeader=NULL; }

IssProfileExtended::~IssProfileExtended() {}

void IssProfileExtended::setShcmsgHeader(ShcmsgHeader *header )
{
	_shcmsgHeader=header;
	return;
}

int IssProfileExtended::MatchMsgAddCondition(const struct IssuerProfile &issProf)
{
	char *addCond=NULL;
	char *sgmtInit=NULL;
	char *sgmtName=NULL;
	char *sgmtValue=NULL;
	ist_ElfId_t sgmtId=0;
	int retVal=0;

	char sgmtData[1024];
	char addCondData[128];
	int sgmtLen=0;

	memset(addCondData,0,sizeof(addCondData));
	sgmtInit = strstr((char *)issProf.m_addCondition, SHC_IssProfileExtSegTag);
	if (!sgmtInit)
		return 1;	//No segment matching condition, treat as match
	strncpy(addCondData,sgmtInit,sizeof(addCondData));

	addCond=(char *)addCondData;
	sgmtInit = strtok(addCond,":");
	// Expected format: SGMT:<SEGMENT NAME>:<VALUE>
	if(sgmtInit && (strcmp(sgmtInit,SHC_IssProfileExtSegTag)==0))
	{
		sgmtName=strtok(NULL,":");
		if(sgmtName)
		{
			sgmtValue=strtok(NULL,":");
			// SEGMENT NAME has to be defined edict.src
			sgmtId =  ElfIdMap::elf_to_id( sgmtName );
			if(sgmtId>0)
			{
				if(_shcmsgHeader)
				{
					sgmtLen=sizeof(sgmtData);
					memset(sgmtData,0,sgmtLen);
					_shcmsgHeader->getSegmentData((char*)sgmtData, &sgmtLen, sgmtId, 0);
					// Segment exists
					if(sgmtLen>0)
					{
						// Value must match with information in segment
						if(strcmp(sgmtValue,sgmtData)==0)
						{
							OTraceDebug("D-SHC-111000 Segment Data match [%s|%s|%s|%d]\n",sgmtName,sgmtValue,sgmtData,sgmtId);
							retVal=1;
						}
						else
							OTraceError("E-SHC-111001 No Segment Data match [%s|%s|%s]\n",sgmtName,sgmtValue,sgmtData);
						// No longer need the header reference
						_shcmsgHeader=NULL;
					}
					else
						OTraceError("E-SHC-111002 Invalid Segment Length [%s|%s|%d|%d]\n",issProf.m_addCondition,sgmtName,sgmtId,sgmtLen);
				}
				else
					OTraceError("E-SHC-111003 NULL SgmtMsgHeader [%s|%s|%d]\n",issProf.m_addCondition,sgmtName,sgmtId);
			}
			// Segment ID not found
			else
				OTraceError("E-SHC-111004 Undefined Segment Id [%s|%s]\n",issProf.m_addCondition,sgmtName);
		}
		// Segment Name not present
		else
			OTraceError("E-SHC-111005 Undefined Segment Name [%s]\n",issProf.m_addCondition);
	}
	// Additional condition exist but does not have propper format
	else
		OTraceError("E-SHC-111006 Invalid AddCondition format [%s]\n",issProf.m_addCondition);

	return retVal;
}

