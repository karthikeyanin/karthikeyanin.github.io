static char _Shc600Log_cxx_what[] = "@(#) Shc600Log.cxx 1.17.3.2 20/01/30 13:03:06";


/*
 *  Copyright (C) 2004 eFunds Corporation ("eFunds").  All Rights Reserved.     
 *  eFunds Canada Corporation is an authorized user.                            
 *                                                                              
 *  IST is a registered trademark of eFunds Corporation.  Other brand or        
 *  product names are trademarks or registered trademarks of their respective   
 *  holders.                                                                    
 *                                                                              
 *  The information contained herein is the unpublished proprietary property    
 *  of eFunds.  Except as specifically authorized in writing by eFunds, the     
 *  holder of this document shall: i) keep all information contained herein     
 *  confidential, and ii) protect the information, in whole or in part, from    
 *  disclosure and dissemination to all third parties.                          
 *                                                                          
 *  This document and the software described in it are furnished under license  
 *  and may be used or copied only in accordance with the terms of such license.
 *  This document is supplied for information purposes only, is subject to      
 *  change without notice, and should not be construed as a commitment by       
 *  either eFunds Corporation or eFunds Canada Corporation. 
 *
 *
 *                        MODIFICATION HISTORY                  REVIEW
 *
 * SCR#     Who    Date  Description
 * ===========================================================================
 * R0xxxxx 
 * R015223 sdc	09Dec05	Use shc_maskpan function instead of masking here	
 * R023231 Ram  23May08 The SDK header should refer to external header
 * R026116 sks	02Mar09	Populate correct value in shc600log.issuer field
 * R027876 dipa 02Mar10	Remove ADM_BUF segment
 * IST_S_71623-1	dipa	20Mar14		GeoDisp changes: Added log_id
 */
 
//File Number 7

#if defined( WIN32 )
#       define SHCDLLEXPORT __declspec(dllexport)
#else
#       define SHCDLLEXPORT
#endif



#include <shc.h>
#include <ShcSdkCommon.h>
#include <ShcBin.h>
#include <ShcmsgHeader.h>
#include <Shc600Log.h>
#include <ShcAppBase.h>
#include <ShcHelper.h>	//	--- R023231
#include <ShcmsgHelper.h>
#include <mb_umi.h>
#include <istsafe.h>

int Shc600Log::logTxn(ShcHeader *header)
{
	int ret = 0;
	ShcmsgHeader *tmpHeader = (ShcmsgHeader *)header;
    	fill_transaction(header);

    	ret = insert_transaction(shcIsResponse(tmpHeader));

	if(ret < 0)
        	return(-1);
	else if(ret == 2)
		header->shcerr = SH_IGNORE;

    	return(0);

}

int Shc600Log::fill_transaction(ShcHeader *header)
{
	ShcmsgHeader *thisHeader = (ShcmsgHeader *)header;

	OTraceDebug("D-SHC-007001: Copy shcmsg to shc600log for m%04d/p%06d\n",
			 thisHeader->msg.msgtype, thisHeader->msg.pcode);

	memset(&shc600log, 0, sizeof(shc600log));
	shc600log.msgtype 	= thisHeader->msg.msgtype ;
	shc600log.txntype 	= thisHeader->msg.txntype;
	strcpy(shc600log.pan	 	, thisHeader->msg.pan	 );
	memcpy(shc600log.mask_pan, thisHeader->msg.pan, sizeof(shc600log.mask_pan));
	shcApp->shcmsgHelperObj->shc_denormalizepan(shc600log.mask_pan);

	/* R015223 begin */
	char *ptr = shcApp->shcHelperObj->shc_maskpan(shc600log.mask_pan);
	snprintf(shc600log.mask_pan, sizeof(shc600log.mask_pan), "%s", ptr);
	/* R015223 end */
	memset(shc600log.mask_pan, 0, sizeof(shc600log.mask_pan));	//PA-DSS

	shc600log.pcode 	= thisHeader->msg.pcode ;
	dbm_deccopy(&shc600log.amount 	, &thisHeader->msg.amount );
	dbm_deccopy(&shc600log.aval_balance 	, &thisHeader->msg.aval_balance );
	dbm_deccopy(&shc600log.cash_back 	, &thisHeader->msg.cash_back);

	dbm_deccopy(&shc600log.iss_conv_rate 	, &thisHeader->msg.iss_conv_rate );
	shc600log.iss_currency_code 	= thisHeader->msg.iss_currency_code ;
	shc600log.iss_conv_date	= thisHeader->msg.iss_conv_date;

	dbm_deccopy(&shc600log.acq_conv_rate 	, &thisHeader->msg.acq_conv_rate );
	shc600log.acq_currency_code 	= thisHeader->msg.acq_currency_code ;
	shc600log.acq_conv_date	= thisHeader->msg.acq_conv_date;

	dbm_deccopy(&shc600log.tra_amount, &thisHeader->msg.tra_amount);
	dbm_deccopy(&shc600log.tra_conv_rate 	, &thisHeader->msg.tra_conv_rate );
	shc600log.tra_currency_code 	= thisHeader->msg.tra_currency_code ;
	shc600log.tra_conv_date	= thisHeader->msg.tra_conv_date;

	dbm_deccopy(&shc600log.amount_equiv 	, &thisHeader->msg.amount_equiv );
	shc600log.trandate 	= thisHeader->msg.trandate ;
	shc600log.trantime 	= thisHeader->msg.trantime ;
	shc600log.trace 	= shcApp->shcmsgHelperObj->shcMakeKeyLog(thisHeader);
	shc600log.local_time 	= thisHeader->msg.local_time ;
	shc600log.local_date 	= thisHeader->msg.local_date ;
	shc600log.settlement_date 	= thisHeader->msg.settlement_date ;
	shc600log.origmsg		= thisHeader->msg.origmsg;
	shc600log.origtrace	= thisHeader->msg.origtrace;
	shc600log.origdate		= thisHeader->msg.origdate;
	shc600log.origtime		= thisHeader->msg.origtime;
	shc600log.cap_date 	= thisHeader->msg.cap_date ;
	shc600log.pos_entry_code 	= thisHeader->msg.pos_entry_code ;
	shc600log.pos_condition_code = thisHeader->msg.pos_condition_code;
	shc600log.pos_pin_cap_code = thisHeader->msg.pos_pin_cap_code;
	shc600log.pos_cap_code	= thisHeader->msg.pos_cap_code;
	shc600log.life_cycle	= thisHeader->msg.life_cycle;
	shc600log.serial_1		= thisHeader->msg.serial_1;
	shc600log.serial_2		= thisHeader->msg.serial_2;
	strcpy(shc600log.acquirer 	, thisHeader->msg.acquirer );

	//	>>>	R026116
		strcpy(shc600log.issuer 	, thisHeader->msg.issuer );
		strcpy(shc600log.transferee , thisHeader->msg.transferee ); /* qd 23feb96 */
	//	<<<	R026116

	shc600log.respcode 	= thisHeader->msg.respcode ;
	shc600log.reason_code 	= thisHeader->msg.reason_code ; /* qd 23feb96 */
	shc600log.revcode 	= thisHeader->msg.revcode ;
	shc600log.shcerror	= thisHeader->msg.shcerror;
	shc600log.saf		= thisHeader->msg.saf;
	strcpy(shc600log.track2 	, thisHeader->msg.track2 );
	strcpy(shc600log.track3 	, thisHeader->msg.track3 ); /* qd 23feb96 */
	strcpy(shc600log.refnum 	, thisHeader->msg.refnum );
	strcpy(shc600log.authnum 	, thisHeader->msg.authnum );
	strcpy(shc600log.termid 	, thisHeader->msg.termid );
	strcpy(shc600log.acceptorname 	, thisHeader->msg.acceptorname );
	strcpy(shc600log.termloc	 	, thisHeader->msg.termloc	 );
	istsafe_strcpy(shc600log.addresponse,sizeof(shc600log.addresponse),	thisHeader->msg.addresponse);
	//strcpy(shc600log.acctnum, thisHeader->msg.acctnum);
	istsafe_strcpy(shc600log.acctnum, sizeof(shc600log.acctnum), thisHeader->msg.acctnum);
	shc600log.settlement_code = thisHeader->msg.settlement_code;
	dbm_deccopy(&shc600log.settlement_rate, &thisHeader->msg.settlement_rate);
	dbm_deccopy(&shc600log.settlement_amount, &thisHeader->msg.settlement_amount);
	dbm_deccopy(&shc600log.fee, &thisHeader->msg.fee);
	dbm_deccopy(&shc600log.new_fee, &thisHeader->msg.new_fee);
	dbm_deccopy(&shc600log.new_amount, &thisHeader->msg.new_amount);
	dbm_deccopy(&shc600log.new_setl_amount, &thisHeader->msg.new_setl_amount);
	dbm_deccopy(&shc600log.settlement_fee, &thisHeader->msg.settlement_fee);
	shc600log.device_devcap 	= thisHeader->msg.device_devcap ; 
	shc600log.shc_devcap 	    = thisHeader->msg.shc_devcap ; 
	shc600log.formatter_devcap	= thisHeader->msg.formatter_devcap ; 
	shc600log.auth_devcap 	    = thisHeader->msg.auth_devcap ; 

	//R027876 >>>
	//char *adm_buf;
	//int len;
	
	//adm_buf = (char *)get_seg_from_shcmsg(&(thisHeader->msg), (char *)"ADM_BUF", &len);	/* R008717 */

	//if(adm_buf)
	//{
	//	memcpy(shc600log.adm_msg_buf, adm_buf, 
	//		(len>sizeof(shc600log.adm_msg_buf) ? sizeof(shc600log.adm_msg_buf) : len));
	//}
	//<<< R027876	
	
	shc600log.storeid	= thisHeader->msg.storeid;
	shc600log.lane	= thisHeader->msg.lane;
	shc600log.terminal_trace	= thisHeader->msg.terminal_trace;
	shc600log.checker_id	= thisHeader->msg.checker_id;
	shc600log.supervisor	= thisHeader->msg.supervisor;
	shc600log.shift_number	= thisHeader->msg.shift_number;
	shc600log.batch_id	= thisHeader->msg.batch_id;

	shc600log.acq_country	= thisHeader->msg.acq_country;

    memcpy(shc600log.issuer_data,thisHeader->msg.issuer_data,sizeof(shc600log.issuer_data));    
    memcpy(shc600log.acquirer_data,thisHeader->msg.acquirer_data,sizeof(shc600log.acquirer_data));    
    strcpy(shc600log.txnsrc, thisHeader->msg.txnSrc);
    strcpy(shc600log.txndest, thisHeader->msg.txnDest);
    strcpy(shc600log.alternateacquirer, thisHeader->msg.alternateAcquirer);
    strcpy(shc600log.entityid, thisHeader->msg.entityId);
    strcpy(shc600log.iss_entityid, thisHeader->msg.iss_entityId);
    strcpy(shc600log.member_id, thisHeader->msg.member_ID);
    strcpy(shc600log.f_id, thisHeader->msg.F_ID);


    dbm_deccopy(&shc600log.ledger_balance, &thisHeader->msg.ledger_balance);

	//IST_S_71623-1 >>>
	if( thisHeader->msg.shclog_id[0]) 
	{
		OTraceDebug("D-SHC-007001.1: Got chip_index(%s).\n",thisHeader->msg.shclog_id);
	}
	else
	{
		if( mb_getUmi( thisHeader->msg.shclog_id, sizeof(thisHeader->msg.shclog_id) ) < 0 )
		{
			OTraceError("E-SHC-007001.2:SHC-MAKEKEY: Unable to make key.\n");
			return(-1);
		}
		else
			OTraceLog("L-SHC-007001.3: New ID [%s] created for m%04d/t%06d/p%06d\n", 
				thisHeader->msg.shclog_id, thisHeader->msg.msgtype, thisHeader->msg.trace, thisHeader->msg.pcode);
	}
	strcpy(shc600log.log_id, thisHeader->msg.shclog_id);
	//IST_S_71623-1 <<<

	if (thisHeader->msg.site_id == 0)
		thisHeader->msg.site_id = mbGetSiteId();
			shc600log.site_id = thisHeader->msg.site_id;

    shc600log.src_node =  thisHeader->msg.src_node;
    shc600log.dest_node =  thisHeader->msg.dest_node;


	return( 0 );
}

int Shc600Log::insert_transaction(int resp_msg)
{
	int curfd = 0;

    if(shc600logfd < 0 )
	{
        if((shc600logfd = dbm_open("shc600log_1", dbmid)) < 0 )
        {
            OTraceFatal("F-SHC-007002: Unable to open shc600log_1 index: %d\n", dbm_errno);
            return( -1 );
        }
	}

    if(shc600logreqfd < 0 )
	{
        if((shc600logreqfd = dbm_open("shc600log_req_1", dbmid)) < 0 )
        {
            OTraceFatal("F-SHC-007002.1: Unable to open shc600log_req1 index: %d\n", dbm_errno);
            return( -1 );
        }
	}


    if (resp_msg)
	{
		curfd = shc600logfd;
	}
	else
	{
		curfd = shc600logreqfd;
	}
			

    if(dbm_insert(curfd, (char *)&shc600log, 0) < 0)
    {
        OTraceError("E-SHC-007003: Unable to insert record (%d) for m%04d/p%06ld/%s\n",
            dbm_errno, shc600log.msgtype, shc600log.trace, shc600log.log_id);
        return(-1);
    }

    OTraceInfo("I-SHC-007004: New record logged for m%04d/t%06ld/%s\n",
            shc600log.msgtype, shc600log.trace, shc600log.log_id); //IST_S_71623-1

    if (shc600log.respcode == SHC_RC_SwitchNotAvailable || shc600log.respcode == SHC_RC_SystemError)
    {
	if((strcmp(mbMailBoxName(mbLastSenderId()), "p1cvisa") == 0) || (strcmp(mbMailBoxName(mbLastSenderId()), "p1cmc") == 0))
	{
		OTraceError("I-SHC-007013: Response from host is %d. Dropping transaction\n", shc600log.respcode);
		return 2;
	}
    }
    return(0);

}

int Shc600Log::logRepeat(ShcHeader *header)
{
	if(locateTxn(header) < 0)
    {
    	return logTxn(header);
    }
    else
    {
		OTraceInfo("I-SHC-007005: Repeated transaction is get UPDATED only\n");
        fill_transaction(header);
        if(dbm_write(shc600logfd, (char *)&shc600log, 0) < 0)
        {
            OTraceFatal("F-SHC-007006: Error: %d on write\n", dbm_errno);
            return(-1);
        }
		return 0;
    }
}

int Shc600Log::locateTxn( ShcHeader *header,  int flag )
{
	int	ret = -1;
	int fd[2];
	int i;

	ShcmsgHeader *thisHeader = (ShcmsgHeader *)header;

	if(shc600logfd < 0 )
    {
        if((shc600logfd = dbm_open("shc600log_1", dbmid)) < 0 )
        {
            OTraceFatal("P-SHC-007007: Unable to open shc600log_1:%d\n", dbm_errno);
            return( -1 );
        }
    }
	
	if(shc600logreqfd < 0 )
    {
        if((shc600logreqfd = dbm_open("shc600log_req_1", dbmid)) < 0 )
        {
            OTraceFatal("P-SHC-007007.1: Unable to open shc600log_req_1:%d\n", dbm_errno);
            return( -1 );
        }
    }

	/*
	 *	Fill in the index values
	 */
	shc600log.trace	  =  shcApp->shcmsgHelperObj->shcMakeKeyLog(thisHeader);
	shc600log.local_time = thisHeader->msg.local_time;
	shc600log.local_date = thisHeader->msg.local_date;
	shc600log.pcode = thisHeader->msg.pcode;
	memcpy(shc600log.termid, thisHeader->msg.termid, sizeof(shc600log.termid));
	memcpy(shc600log.pan, thisHeader->msg.pan, sizeof(shc600log.pan));


	memcpy(shc600log.acquirer, thisHeader->msg.acquirer, sizeof(shc600log.acquirer));

	OTraceDebug("D-SHC-007008: Search for t(%ld)ld(%ld)lt(%ld)term(%s)p(%s)a(%s)\n",
			shc600log.trace, shc600log.local_date, shc600log.local_time, shc600log.termid,
			shcApp->shcHelperObj->shc_maskpan(shc600log.pan), shc600log.acquirer);

	 if (((flag  & IST_SHCLOG_FLAG_LOCATE_REQ  && flag & IST_SHCLOG_FLAG_LOCATE_RESP)) ||
		 (!(flag & IST_SHCLOG_FLAG_LOCATE_REQ) && !(flag & IST_SHCLOG_FLAG_LOCATE_RESP)) )
	 {
		 fd[0] = shc600logfd;
		 fd[1] = shc600logreqfd;
		 OTraceDebug("D-SHC600-5104:Search RESP/REQ\n");
	 }
	 else if (flag & IST_SHCLOG_FLAG_LOCATE_REQ)
	 {
		 fd[0] = shc600logreqfd;
		 fd[1] = -1;
		 OTraceDebug("D-SHC600-5105:Search REQ\n");
	 }
	 else if (flag & IST_SHCLOG_FLAG_LOCATE_RESP)
	{
	 	fd[0] = shc600logfd;
	 	fd[1] = -1;
	 	OTraceDebug("D-SHCLOG600-5106:Search RESP\n");
	}
	for (i = 0; i < 2 && fd[i] != -1 && ret < 0;  i++)			
	{
		ret = dbm_read(fd[i], (char *)&shc600log, DBM_REQUAL + DBM_RLOCK);
	}

	OTraceDebug("D-SHC-007009: result: %s\n", (ret < 0 ? "not found" : "found"));

	if( ret < 0 )
		return( -1 );
	
	return( 0 );
}


/* Update an existing txn in shclog indicated by shcmsg to the new contents 
 * stored in shcmsg 
 */
int Shc600Log::updateTxn(ShcmsgHeader *header, struct shcmsg *oldmsg, int locateFirst)
{
	struct	ShcmsgWithSegment omsg;
	
	if(oldmsg == NULL)
		oldmsg = &(omsg.msg);
	
	if(locateTxn(header) < 0)
	{
		header->msg.shcerror = SHC_IE_NoMatch;
		OTraceWarning("W-SHC-007010: Unable to locate db txn: Error: %d\n", dbm_errno);
		return(logTxn(header));
	}

	fill_transaction(header);

	OTraceInfo("I-SHC-007011: Update record for m%04d/p%06d/%s\n",
			 shc600log.msgtype, shc600log.pcode, shc600log.log_id); //IST_S_71623-1

	if(dbm_write(shc600logfd, (char *)&shc600log, 0) < 0)
	{
		OTraceFatal("F-SHC-007012: Error: %d on write\n", dbm_errno);
		return(-1);
	}

	return(0);

}






