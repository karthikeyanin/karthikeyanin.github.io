/*
 *  Copyright (C) 2004 eFunds Corporation ("eFunds").  All Rights Reserved.     
 *  eFunds Canada Corporation is an authorized user.                            
 *                                                                              
 *  IST is a registered trademark of eFunds Corporation.  Other brand or        
 *  product names are trademarks or registered trademarks of their respective   
 *  holders.                                                                    
 *                                                                              
 *  The information contained herein is the unpublished proprietary property    
 *  of eFunds.  Except as specifically authorized in writing by eFunds, the     
 *  holder of this document shall: i) keep all information contained herein     
 *  confidential, and ii) protect the information, in whole or in part, from    
 *  disclosure and dissemination to all third parties.                          
 *                                                                          
 *  This document and the software described in it are furnished under license  
 *  and may be used or copied only in accordance with the terms of such license.
 *  This document is supplied for information purposes only, is subject to      
 *  change without notice, and should not be construed as a commitment by       
 *  either eFunds Corporation or eFunds Canada Corporation. 
 *
 *                        MODIFICATION HISTORY                  REVIEW
 *
 *	SPR#	Who	Date	Description
 * ===========================================================================
 *R008717 ztang	13Nov02	Created to support multi-institution 
 *R009030 ztang 03Feb03 The pcode checking should be >= 0
 #R009248 ztang 24Feb03 Remove spaces from instituion id fields
 *R009399 jyang 11Mar03 Added PAN length checking for Visa when searching extbin
 *R012134 emj   04Oct04 Issuer Entity Support
 *R000000 jyang 17Oct06 Locate issuer by iss_entityId
 *R021782 emj   26Oct06 Fixed isRegularExp to handle empty strings
 *R022481 jyang 29Jan08 Supported for locking shared memory of rules
 *R027802 jyang 25Jan10 Added "Block by Brand" Support
 *R027759 EdC	05Feb10	Added LCR Support
 *R027759 EdC	09Feb10	Added TieBreaker Support
 *R029450 las   19May11 make block by brand static
 *R030207 dipa  02Feb12 Clone of R029329
 */
static const char* _IssProfile_cxx_what = "@(#) IssProfile.cxx 1.20.10.5 18/12/30 18:23:29";

#if defined( WIN32 )
#       define SHCDLLEXPORT __declspec(dllexport)
#else
#       define SHCDLLEXPORT
#endif

//File Number 4

#include <stdio.h>
#include <str.h>
#include <oasis.h>
#include <rules.h>
#include <shc.h>
#include <string.h>
#include <ic/ic_bin.h>
#include<ic/ic_instid.h>
#include <ctype.h>
#include <ist_otrace.h>
#include <mt_extbin.h>
#include <IssProfile.h>
#include <mt_acq_profile.h>
#include <mt_iss_profile.h>
#include <mt_inst_profile.h>
#include <BrandBlocked.h>
#include <LCRHelper.h>
#include <TieBreaker.h>
#include <DNSegHelper.h>						// USP-1678
#include <IssProfileExtended.h>

extern  LCRHelper*	LCRHelperObj;
extern  TieBreaker* TieBreakerObj;

#include <ShcBalancer.h>
#include <istsafe.h>

// Moved to the IssProfile.h so functions can access this
#if 0							// R027759
#define MAX_RESULT 100
static struct
{
      struct IssuerProfileShm *p;
      struct shcextbin *e;
      struct shcpkg *pkg;
} profileResult[MAX_RESULT];
#endif

static int resultNum;

static struct shcpkg *(bins[MAX_RESULT]);
struct routingpkg  routingRecord = { 0 };
int onlyUseLocalIssuer = 1;


#define BLACK_HOLE_PRIORITY		50

int IssProfile::initialized = 0;
struct IssuerProfile *IssProfile::issuerProfileData = NULL;
struct shcextbin *IssProfile::shcExtBinData = NULL;
struct shcextbinGroupHeader *IssProfile::shcextbinGroupData = NULL;
struct rules_keytab    	*IssProfile::issuerRuleKeyp = NULL;
struct rules_keytab	   	*IssProfile::shcExtBinRuleKeyp = NULL;
int IssProfile::issuerProfileAppid;
BrandBlocked * IssProfile::brandBlockedObj = NULL;
int IssProfile::shcExtBinAppid;
	
	
int IssProfile::initialize()
{
	int appid;

	if((appid = rm_getappid("iss_profile")) < 0)
	{
		OTraceFatal("F-SHC-0401:unable to locate message name: iss_profile\n");
		return(-1);
	}
	else {

		issuerRuleKeyp = rm_getapphead(appid);

		/*	Find the first entry of my key table */
		issuerProfileData = (struct IssuerProfile *)rm_getappkey(appid);
		issuerProfileAppid   = appid;
	}

	if ((appid = rm_getappid("shared-cash-extbin")) < 0)
	{
		OTraceFatal("F-SHC-0402:unable to locate message name: shared-cash-extbin\n");
		return(-1);
	}
	else {

		shcExtBinRuleKeyp = rm_getapphead(appid);

		/*	Find the first entry of my key table */
		shcExtBinData = (struct shcextbin *)rm_getappkey(appid);
		shcextbinGroupData = (struct shcextbinGroupHeader *)rm_getapptext(appid);
		shcExtBinAppid   = appid;
	}

	// USP-1412
	pHdr = NULL;	
	
	brandBlockedObj = BrandBlocked::getInstance();
	
	initialized = 1;
	return 0;
}


int IssProfile::extbin_compare(const char *pan, const char *low, const char *high, int size)
{
	
    if(memcmp(pan, low, size) >= 0)
    {
        if(memcmp(pan, high, size) > 0)
            return(1);
        else
            return(0);
    }
    else
        return(-1);
}
/*
 *	Input:		pan		
 *	Action:		Search the extended bin records in shared memroy to find
 *				the matching records. Each brand name of the card will be
 *				one record.
 */
ExtBinResultExt gExtBinResultExt;
char _onlyForDestination[10+1] = { 0 }; //use this global to pass additional parameter
void IssProfile::search_extbin(const char *pan, ExtBinResult &searchResult)
{
	char copyOfOnlyForDestination[sizeof(_onlyForDestination)];
	memcpy(copyOfOnlyForDestination, _onlyForDestination, sizeof(copyOfOnlyForDestination));
	_onlyForDestination[0] = 0;

	char bcdPan[10];
	int chari, bcdi;
	int len;
	int size;
	int hasBlocked = 0;											// USP-1590
	gExtBinResultExt.m_numOfResult = 0;
	
	struct shcextbin*	blockedRange = NULL;					// USP-1412
	struct shcextbin*	blkholeRange = NULL;					// USP-1501
	

	if (!initialized)
	{
		if (initialize() < 0)
			return;
	}
	if (setExtRuleParam() < 0)
			return;

	memset(bcdPan, 0, sizeof(bcdPan));
	size= sizeof(shcExtBinData[0].lowbin);

	/* First convert pan from char to bcd */
	for ( chari = bcdi = 0;  bcdi < size ; chari ++, bcdi++)
	{
		if (pan[chari]>='0' && pan[chari] <= '9')
			bcdPan[bcdi]=((pan[chari] - '0')<<4) ;
		else
			break;
		chari++;
		if (pan[chari]>='0' && pan[chari] <= '9')
			bcdPan[bcdi] |= pan[chari] - '0';
		else
			break;
	}

	int x;
	int ret;
	int mid;
	
	if ( rm_waitForLockedShdMem(shcExtBinAppid) )	// R022481
	{
		OTraceWarning("W-SHC-0403.1: rm.appid[%d] was locked. Go ahead\n", shcExtBinAppid);
	}
	
	for (int group=0; group < shcExtBinRuleKeyp->textused; group++)
	{
	    int low = shcextbinGroupData[group].startEntry;
	    int hi  = shcextbinGroupData[group].endEntry;
	
	    while(low <= hi)
	    {
	      	mid = (hi + low) / 2;

			char*		pLow = &(shcExtBinData[mid].lowbin[0]);
			char*		pHig = &(shcExtBinData[mid].highbin[0]);
		
	       	ret = extbin_compare(bcdPan,shcExtBinData[mid].lowbin,shcExtBinData[mid].highbin, size);
	       	if(ret == 0)
			{
	            x = mid;
	            /* the bin number is matching the current entry: Back-up */
	            while(x > shcextbinGroupData[group].startEntry &&
					  memcmp(bcdPan, shcExtBinData[x-1].lowbin, size) >= 0 &&
					  memcmp(bcdPan, shcExtBinData[x-1].highbin, size) <= 0) 
	            {
	                x--;
	            }
	
	            /* Now go forward */
	            while(x <= shcextbinGroupData[group].endEntry &&
				      memcmp(bcdPan, shcExtBinData[x].lowbin, size) >= 0 &&
					  memcmp(bcdPan, shcExtBinData[x].highbin, size) <= 0 )
				{
									/* R009399 >> */
					// PAI-742 -- validate LCRHelperObj and default to 'C' if null (for now)
					OTraceDebug("D-SHC-0410-c: cr/dr(%c) netw_data(%s) dest(%s)\n", 
								(LCRHelperObj ? LCRHelperObj->getProcessOption() : (char)'C'), 
								shcExtBinData[x].network_data, 
								shcExtBinData[x].destination);

					if (strncmp(shcExtBinData[x].destination, (char*)"BLACKHOLE", 9) == 0)
					{
						blkholeRange = &(shcExtBinData[x]);
						x++;
						continue;								// to be added later
					}

	            	if(   strstr(shcExtBinData[x].cardProduct, "VISA") 
					   || strstr(shcExtBinData[x].cardProduct, "PLUS") )
	            	{
	            		long lNetworkData = 0l;
            			char *endptr;
	            		char *ptrNetData = strchr( shcExtBinData[x].network_data, ':' );

						if( ptrNetData )
						{
		            		int  panLen;
							for( panLen=0; isdigit(pan[panLen]); panLen++ );
							if( ! (mGetAcctLenBit(panLen) & strtoul( ptrNetData+1, &endptr, 16 )) )
							{
								x++;
								continue;
							}
						}
					}				/* R009399 << */
					else			// R027759
									// deal specifically with '99' tag ONLY IF a debit route
									// signature debits are credit routes
					// PAI-742 -- if obj is null -- assume credit
					if (   (LCRHelperObj && LCRHelperObj->getProcessOption() == 'D')
						&& (   strncmp(&(shcExtBinData[x].network_data[0]), (char*)"99", 2) == 0
							&& strncmp(&(shcExtBinData[x].network_data[0]), 
										(char*)"990000", 6) != 0)
					   )
					{	// FIS/Advantage/Connex/Debit range
						int				ret = 0;

						if ((ret = validate_PANLen((char*)pan, x)) == 0)
						{
							x++;

							OTraceDebug("D-SHC-1410-e: Failed in PAN Length validation\n");
							continue;
						}

						/*
						// USP-1590 -- removed 
						// relocate -- now that credits and debits are in the list
						if ((ret = filterout_shortBIN(searchResult, x)) == 0 )
						{
							x++;
							OTraceDebug("D-SHC-1410-f: Failed in BIN Length validation\n");
							continue;	
						}
						*/
					}			// R027759  <<<
					// else 	it is credit Routing

					// add to the list of possible destinations
					if (!copyOfOnlyForDestination[0] || (strcmp(copyOfOnlyForDestination, shcExtBinData[x].destination))==0)
					{
						if (searchResult.m_numOfResult >= MAX_EXT_BIN_RESULT_NUM)
                                        {
                                                OTraceError("I-SHC-0411:Too many matching records in extbin. Only add to gExtBinResultExt\n");
                                        }
                                        else
                                        {
						    searchResult.result[searchResult.m_numOfResult] = &(shcExtBinData[x]);
						    searchResult.m_numOfResult++;
					    }
					    gExtBinResultExt.addResult (&(shcExtBinData[x]));
					    OTraceDebug("D-SHC-1410-g: added entry (%s)(%d)\n", 
								 shcExtBinData[x].destination, gExtBinResultExt.m_numOfResult);
					}
	                x++;

	            }					// while loop--group search for extbin entry
	            break;
	        }						// matched range
	        else if(ret < 0)
	        {
	            /* the bin number is smaller than the current entry */
	            hi = mid - 1;
	        }
	        else
	        {
	            /* the bin number is bigger than the current entry */
	            low = mid + 1;
	        }
	    }		// while loop -- to do binary search

	}			// for-loop in search of extbin entry

	// -----------------------------------------------------------------------
	// USP-1501 -- validate list against transaction type (credit/debit)
	// filter out that does not belong
	// Value represents nature of txn which dictates routing
	// Signature debits are debit accounts but treated as credit transactions
	// -----------------------------------------------------------------------
	if (gExtBinResultExt.m_numOfResult > 0)
	{
		char 				txnType 	= (LCRHelperObj ? LCRHelperObj->getProcessOption()
											: 'C');		// PAI-742--assume credit if null object
		struct shcextbin* 	binRange 	= NULL;
		int  				kount 		= gExtBinResultExt.m_numOfResult;
		int  				ix, i, j;

		OTraceDebug("D-SHC-search_extbin:  Processing matching bin ranges...\n");

		// filter out that does not match txnType
		j = kount;
		for ( ix = 0; ix < j; ix++ )
		{
			binRange = gExtBinResultExt.result[ix];
			if (txnType == 'D')		// if debit
			{
				if(   strncmp((char*)"990000", binRange->network_data, 6) == 0
				   || binRange->network_data[0] == ' '			// space
				   || binRange->network_data[0] == '\0' )			// null
				{
					// got a credit route to do -- could be sig debit
					// clear the pointer--will arrange later
					if (ix < MAX_EXT_BIN_RESULT_NUM)
						searchResult.result[ix] = NULL;
					gExtBinResultExt.result[ix] = NULL;
					kount--;		// adjust the new result count
					OTraceDebug("XXXXX: Found a credit destination(%s) for a debit route\n",
								binRange->destination);
				}
			}
			else 					//  it's credit--for now,  we only have 2 -- Credit/Debit
			{
				if(   strncmp(binRange->network_data, (char*)"99", 2)     == 0
				   && strncmp(binRange->network_data, (char*)"990000", 6) >  0 )
				{
					// got a debit route to do
					if (ix < MAX_EXT_BIN_RESULT_NUM)
						searchResult.result[ix] = NULL;
					else
						gExtBinResultExt.result[ix] = NULL;
					kount--;        // adjust the new result count
					OTraceDebug("XXXXX: Found a debit destination(%s)"
								" for a credit route\n", binRange->destination);
				}
			}	
		}		// for loop in the searchResult array
		
		// some entries may have been removed so validate pointer
		OTraceDebug("XXXXXX: remaining in the list after pass 1(kount) = %d\n", kount);
		if (kount > 0)
		{
			for ( ix = 0; ix < j; ix++ )
			{
				binRange = gExtBinResultExt.result[ix];
				if (!binRange)				// removed from earlier pass
					continue;

				// USP-1414/1501--repositioned here
				// USP-1431--some callers will not have the SHC header
				if (   pHdr != NULL  					// USP-1431
					&& isBrandBlocked(pHdr->msg.txnSrc, binRange->destination,
									  binRange->cardProduct, pHdr->msg.msgtype))
				{
					blockedRange = binRange;

					// USP-1599
					// If EBTG, do not drop nor tag as blocked
					if (   strcmp(blockedRange->destination, EBTG_NETWORK) == 0
						&& (pHdr->msg.msgtype%1000)/100 == 4 )
					{
						OTraceDebug("D-SHC-0410-b:  Reversal EBTG detected, retaining...\n");
					}
					else							// end of USP-1599
					if (kount == 1)					// only dest left, excluding blkhole
					{
						// for reversal, drop this--blackhole will be picked-up
						if ( (pHdr->msg.msgtype%1000)/100 == 4 )
						{
							kount--;       			// adjust the new result count
							if (ix < MAX_EXT_BIN_RESULT_NUM)
								searchResult.result[ix] = NULL;
							gExtBinResultExt.result[ix] = NULL;
							OTraceDebug("E-SHC-0410-c: Bin range dropped-it's blocked(%s)\n",
										blockedRange->destination);
							hasBlocked = 0;
						}
						else
						{
							OTraceDebug("E-SHC-0410-c: Blocked(%s) range found--retaining\n",
									 	blockedRange->destination);
							hasBlocked = 1;
						}
					}
					else							// remove it
					if (kount > 1)
					{
						kount--;        			// adjust the new result count
						if (ix < MAX_EXT_BIN_RESULT_NUM)
							searchResult.result[ix] = NULL;
						gExtBinResultExt.result[ix] = NULL;
						OTraceDebug("E-SHC-0410-c: Bin range dropped because it is blocked(%s)\n",
								 	blockedRange->destination);
						hasBlocked = 0;
					}
				}
			}
		}		// if new kount is still with entries

		// kount is the new result -- let's now compress the entries
		// j has the original count
		for(ix = 0; ix < j; ix++)
		{
			if(gExtBinResultExt.result[ix] == NULL)
			{
				// search for non-null entry
				i = ix+1;
				if (i >= j) continue;				// end-of-original-list
				for ( ; i < j; i++)
				{
					if(gExtBinResultExt.result[i] != NULL)
					{
						// don't get confused between ix and i
                                                if (ix < MAX_EXT_BIN_RESULT_NUM)
                                                        searchResult.result[ix] = gExtBinResultExt.result[i];
                                                gExtBinResultExt.result[ix] = gExtBinResultExt.result[i];
                                                if (i < MAX_EXT_BIN_RESULT_NUM)
                                                        searchResult.result[i]  = NULL;
                                                gExtBinResultExt.result[i]  = NULL;
						break;							// for the inner loop
					}
				}										// inner for loop
			}	
		}												// outer for loop

		
		// -------------------------------------------------------------------------------
		// USP-1599--just a comment
		// A blocked destination for EBTG is retained--this is a special case
		// Because it's not tagged, this can be filtered out if other ranges are
		// existing and has longer BIN length
		// -------------------------------------------------------------------------------
		// A blocked-destination should not exist in the list if there are other
		// valid destination/s--although this may be re-inserted if this is the only
		// available destination
		OTraceDebug("XXXXXX: remaining in the list after pass 2(kount) = %d\n", kount);
		if (kount > 1 && hasBlocked == 0 && txnType == 'D')
		{
			kount = filterout_shortBIN(searchResult, kount);
		}												// if new kount is still with entries
		if (kount <= MAX_EXT_BIN_RESULT_NUM)
                        searchResult.m_numOfResult = kount;                             // new set--could be zero
                else
                        searchResult.m_numOfResult = MAX_EXT_BIN_RESULT_NUM;
                gExtBinResultExt.m_numOfResult = kount;                         // new set--could be zero

		if (blkholeRange)								// should never be null
		{
			if (kount < MAX_EXT_BIN_RESULT_NUM )
			{
				searchResult.result[kount] = blkholeRange;	// add the blackhole now
				searchResult.m_numOfResult++;
			}
			gExtBinResultExt.addResult(blkholeRange);       // add the blackhole now
		}

		// Just for debugging
		for(ix = 0; ix < j; ix++)
			OTraceDebug("XXXXX: ranges(%p)\n", gExtBinResultExt.result[ix]);

	}												// if pan ranges were found
	else
	{
		OTraceError("E-SHC-xxxx:  No ranges matched!!!!!\n");
		syslg      ("E-SHC-xxxx:  No ranges matched!!!!!\n");
	}
	
	// USP-1412
	// need to add either blkhole and a blocked range
	// A catch-all -- should not happen because of blackhole being added earlier
	if (gExtBinResultExt.m_numOfResult == 0)
	{
		if (blkholeRange)							// this should always be present
		{
			searchResult.result[searchResult.m_numOfResult] = blkholeRange;
			searchResult.m_numOfResult++;
			gExtBinResultExt.addResult(blkholeRange);
		}

		// USP-1599--another comment only
		// this logic still holds
		if (blockedRange)							// I have a blocked range
		{
			if(pHdr && ((pHdr->msg.msgtype%1000)/100) != 4
			        && ((pHdr->msg.msgtype%1000)/100) != 8)
			{
				if (searchResult.m_numOfResult < MAX_EXT_BIN_RESULT_NUM)
				{
					searchResult.result[searchResult.m_numOfResult] = blockedRange;
					searchResult.m_numOfResult++;
				}
				gExtBinResultExt.addResult(blockedRange);
			}
			// don't add the blocked range if a reversal or network message
		}
	}


	// validate--should not happen because there should be at least the blackhole Range
	if (gExtBinResultExt.m_numOfResult == 0)
	{
		OTraceError("E-SHC-0403:  No ranges left/matching!!!!!\n");
		syslg      ("E-SHC-0403:  No ranges left/matching!!!!!\n");
	}
	else
	{
		OTraceDebug("D-SHC-0403:Found %d(%d) matching records in shcextbindb\n", 
					gExtBinResultExt.m_numOfResult, searchResult.m_numOfResult);
	}
}



int IssProfile::MatchTxnSrc(const struct IssuerProfile &ip, const char *txnSrc)
{
	if (!(ip.m_txnSrc[0]) || (txnSrc && (strcmp((char *)ip.m_txnSrc, (char *)txnSrc)==0)) )
		return 1;
	else
		return 0;
}

int	IssProfile::MatchMsgContents(const struct IssuerProfile &ip, const char *msgType, 
		const char *deviceType, const char *pcode, const char hasPIN)
{
	OTraceDebug("D-SHC-0404:Matching Msg Contents [%s][%s][%s][%c]\n", msgType, deviceType, pcode, hasPIN);
	if ( 	((!ip.m_msgType[0]) || (msgType && ist_regexpcv((char *)ip.m_msgType, (char *)msgType, 0))) &&
			((!ip.m_deviceType[0]) || (deviceType && ist_regexpcv((char *)ip.m_deviceType, (char *)deviceType, 0))) &&
			((!ip.m_pcode[0]) || (pcode && ist_regexpcv((char *)ip.m_pcode, (char *)pcode, 0))) &&
			((!ip.m_hasPIN) || (ip.m_hasPIN == hasPIN))
		)
	{
		// Additional Condition to validate
		if(ip.m_addCondition[0])
			return issProfileExtObj->MatchMsgAddCondition(ip);
		else
			return 1;
	}
	else
	{
		OTraceDebug("D-SHC-0405:MsgContents NOT match: [%s][%s][%s][%c]\n", ip.m_msgType, ip.m_deviceType,
						ip.m_pcode, ip.m_hasPIN?ip.m_hasPIN:'.');
		return 0;
	}
}

int	IssProfile::MatchCardInfo(const struct IssuerProfile &ip, const char *txnDest, 
			                  const char *entityId, const char *cardProduct)
{
	OTraceDebug("D-SHC-0406:Matching Card Info [%s] [%s] [%s]\n", txnDest, entityId, cardProduct);
	if 	(	(!(ip.m_txnDest[0]) || (txnDest && (strcmp((char *)ip.m_txnDest, (char *)txnDest)==0))) &&
			(!(ip.m_entityId[0]) || !entityId || !(entityId[0]) || (entityId && ist_regexpcv((char *)ip.m_entityId, (char *)entityId, 0))) &&
			(!(ip.m_cardProduct[0]) || (cardProduct && ist_regexpcv((char *)ip.m_cardProduct, (char *)cardProduct, 0)))
		)
		return 1;
	else
	{
		OTraceDebug("D-SHC-0407:Card Info NOT match:[%s] [%s] [%s]\n", ip.m_txnDest, ip.m_entityId, ip.m_cardProduct);
		return 0;
	}
}

int IssProfile::locate_extbin(	const char *txnSrc, const char *pan, const int msgType, 
					const int merchantType, const long pcode, const int hasPIN, 
					IssuerInfo &issuerInfo, ShcmsgHeader *header)
{
	char tmpDeviceType[5];
	
	if (merchantType == 6011)
		sprintf(tmpDeviceType, "ATM");
	else
		sprintf(tmpDeviceType, "POS");
	return(locate_extbin(txnSrc, pan, msgType, tmpDeviceType, pcode, hasPIN, issuerInfo,header));
}

char _issProfile_locate_extbin_gatewayId[50+1] = { 0 };
char _issProfile_locate_extbin_gatewayId_used[2+1] = { 0 };
int IssProfile::locate_extbin(	const char *txnSrc, const char *pan, const int msgType, 
					const char *deviceType, const long pcode, const int hasPIN, 
					IssuerInfo &issuerInfo, ShcmsgHeader *header)
{
	char msgTypeBuf[5];
	char pcodeBuf[7];
	bin_t tmpTxnSrc;
	struct shcpkg *binpkg = NULL;
	int tmpHasPIN;
	int  cntBrandBlocked = 0;
	char _tmp_issProfile_locate_extbin_gatewayId[sizeof(_issProfile_locate_extbin_gatewayId)];

	istsafe_strcpy(_tmp_issProfile_locate_extbin_gatewayId, sizeof(_tmp_issProfile_locate_extbin_gatewayId), _issProfile_locate_extbin_gatewayId);
	_issProfile_locate_extbin_gatewayId[0] = 0;
	_issProfile_locate_extbin_gatewayId_used[0] = 0;

	struct IssuerProfile*	downDest   = NULL;			// R027759
	struct shcextbin*		downExtBin = NULL;			// R027759

	// Needs to follow the 'down issuer' logic
	struct IssuerProfile*	blockedDest   = NULL;	// PAI-899
	struct shcextbin*	blockedExtBin = NULL;	// PAI-899
	memset(&routingRecord, 0, sizeof(struct routingpkg));

	resultNum = 0;
	if (!shcBalancerObj)
		OTraceInfo("I-SHC-0410:No Balancer, no balancing\n");
	if (msgType > 0)
		snprintf(msgTypeBuf, sizeof(msgTypeBuf), "%04.4d", msgType);
	else
		msgTypeBuf[0] = '\0';

	if (pcode >= 0)
		snprintf(pcodeBuf, sizeof(pcodeBuf), "%06.6d", pcode);	
	else
		pcodeBuf[0] = '\0';

	ICInstId_pure(tmpTxnSrc, (char *)txnSrc);

	if (hasPIN)
		tmpHasPIN = 'Y';
	else
		tmpHasPIN = 'N';

	ExtBinResult extBinResult;

	issuerInfo.reset();

	if (!initialized)
	{
		if (initialize() < 0)
			return(-1);
	}

	if (setIssRuleParam() < 0)
			return (-1);

	// USP-1412
	// Save the header for use later 
	pHdr = header;

	search_extbin(pan, extBinResult);

	if (	gExtBinResultExt.m_numOfResult <= 0)
	{
		OTraceDebug("W-SHC-0408:Issuer not found\n");
		return (-1);
	}
		
	if ( rm_waitForLockedShdMem(issuerProfileAppid) )	// R022481
	{
		OTraceWarning("W-SHC-0403.2: rm.appid[%d] was locked. Go ahead\n", issuerProfileAppid);
	}
	
	// ----------------------------------------------------------------------------
	// R027759
	// -  Do the LCR here
	// -  If there's only a single entry, no need to call LCR even if active
	// -  The LCR is expected to reduce the list at least into 1 entry
	// -  It is not expected to reduce it to nothing
	// -  Therefore, this will always continue processing
	// ----------------------------------------------------------------------------
	// USP-1501
	// Need to call only if not reversal otherwise, keep the list as is
	// Voice-auth is credit so it's okay not to call LCR (for now)
	if (pHdr && (pHdr->msg.msgtype%1000)/100 != 4
			 && (pHdr->msg.msgtype%1000)/100 != 8)
	{
		if (   haveLCRSupport
			&& LCRHelperObj
			&& extBinResult.m_numOfResult > 1 )
		{
			LCRHelperObj->doLCR(extBinResult);
		}	// R027759
	}
	else
	{
		OTraceDebug("XXXXX: Reversal/Network Msg encountered, no need for LCR\n");
	}

	struct IssuerProfile 	*firstPriorityEntry 		= NULL;
	struct shcextbin 		*firstPriorityExtBinEntry 	= NULL;
	int 					foundFinalRecord 			= 0;
	struct IssuerProfile *pTmp = NULL;
	char *p;

	//Scan issuer profile multiple times based on num of gateways
	int numOfGateway = strlen(_tmp_issProfile_locate_extbin_gatewayId)/2;		//Gateway id is 2-char card_scheme
	int gatewayIndex;
	char *gp;
	if (numOfGateway <= 0)
		numOfGateway = 1;   //Need to loop at least once in case no specific gateway is required
	for (gatewayIndex=0; gatewayIndex < numOfGateway; gatewayIndex++) 
	{
		gp=&_tmp_issProfile_locate_extbin_gatewayId[gatewayIndex*2];
		// Scan the issuer profile memory table
		int i;
		for (i = 0, p = (char *)issuerProfileData; i < issuerRuleKeyp->keysused; i++,p+=issuerRuleKeyp->keysize)
		{
			pTmp = (struct IssuerProfile *)p;
			if (	firstPriorityEntry 
					&&	(pTmp->m_priority >= BLACK_HOLE_PRIORITY) )
				break;
			if (_tmp_issProfile_locate_extbin_gatewayId[0])
			{
				if (pTmp->m_addCondition[0])
				{}
				if ((gp[0] != pTmp->m_addCondition[0]) || (gp[1] != pTmp->m_addCondition[1]))
				{
					OTraceDebug("D-SHC-XXXXX: gateway id(card-scheme) not match. msg(%c%c), profile(%c%c)\n"
							, isprint(gp[0])?gp[0]:' ', isprint(gp[1])?gp[1]:' '
							, isprint(pTmp->m_addCondition[0])?pTmp->m_addCondition[0]:' '
							, isprint(pTmp->m_addCondition[1])?pTmp->m_addCondition[1]:' ');
					continue;
				}
			}

			// R027759
			// ============================================================================================
			// This does not seem to match the required logic of getting all the issuers first
			// - then if a tie-breaker is present, the  tie-breaker chooses from it
			// - if none is present, the highest in the list prevails
			//   > it is not expected to have same priorities among issuers.  The load balancer
			//	   is now done later and using inst_profile--where the multiple sessions are configured
			// ============================================================================================
				// // First iteration resultNum == 0
				// if ( resultNum > 0)
				// {
				// 				if ((pTmp->m_priority != profileResult[resultNum-1].p->m_priority) ||
				// 						(pTmp->m_isLocal != profileResult[resultNum-1].p->m_isLocal))
	
				// 	break;
				// 	}

			if (issProfileExtObj)
				issProfileExtObj->setShcmsgHeader(header);

			// Match the transaction against the issprofile entry in memory
			if (MatchTxnSrc(*pTmp, tmpTxnSrc) &&
				MatchMsgContents(*pTmp, msgTypeBuf, deviceType, pcodeBuf, tmpHasPIN))
			{
				// I got a match--next match against the selected extended BIN list
				for (int j = 0; j < gExtBinResultExt.m_numOfResult; j++)
				{
					if (MatchCardInfo(*pTmp, gExtBinResultExt.result[j]->destination,
								gExtBinResultExt.result[j]->entityId,
								gExtBinResultExt.result[j]->cardProduct))
					{
						// Found a match in extended BIN list
						// validate against shcbin entry
						if(shc_locate_bin(&binpkg, pTmp->m_bin) == -1)
						{
							OTraceFatal("F-SHC-0409:Can't find bin package for internal bin[%s]\n",
									pTmp->m_bin);
							break;
						}

						/* R027802 >>> */
						// Check if this is a blocked destination
						// USP-1599
						// Added filter--check only if not a reversal and not network message
						if (   (msgType%1000)/100 != 4 && (msgType%1000) != 8
							&& isBrandBlocked(tmpTxnSrc, gExtBinResultExt.result[j]->destination, 
										gExtBinResultExt.result[j]->cardProduct, msgType) )
						{
							// cntBrandBlocked is being set to -1 somewhere in this logic
							// it looks like it is useless but there's a reason
							if ( cntBrandBlocked >= 0 )
							{
								cntBrandBlocked++;	// SHC_RC_RestrictedCard;

								// USP-1319  -- 28July2010
								// Set the blocked issuer
								brandBlockedObj->setBlockedBin(pTmp->m_bin);	
								// USP-1678
								brandBlockedObj->setBlockedNetworkData(
										gExtBinResultExt.result[j]->network_data);

								// PAI-899 -- save the required info to continue processing
								// should there be more than one blocked dest, the last prevails
										blockedDest   = pTmp;
								blockedExtBin = gExtBinResultExt.result[j];
							}
							continue;
						}
						/* R027802 <<< */
						
						// Still not clear what this is for--especially that
						// it's possible to have same priorities on different destinations
						if (!firstPriorityEntry)
						{
							firstPriorityEntry = pTmp;
							firstPriorityExtBinEntry = gExtBinResultExt.result[j];
						}

						if (!shc_isdown(binpkg))
						{

		// R027759
							// if (!shcBalancerObj)
							// // ==============================================================
							// // R027759
							// // With LCR/Tie-breaker in effect, finding one matching entry
							// // must not mean it is the final destination
							// // ==============================================================
							// {
							// 	foundFinalRecord = 1;
							// 	issuerInfo.setTxnDest(gExtBinResultExt.result[j]->destination);
							// 	issuerInfo.setCardProduct(gExtBinResultExt.result[j]->cardProduct);
							// 	extBinCountryCode = gExtBinResultExt.result[j]->country_code;
							// 	issuerInfo.setNetworkData(gExtBinResultExt.result[j]->network_data);
							// 	if (!gExtBinResultExt.result[j]->entityId[0])
							// 	{
							// 										if(!isRegularExp(pTmp->m_entityId))
							// 		{
							// 												char tmpentity[sizeof(pTmp->m_entityId)];
							// 												strcpy(tmpentity, pTmp->m_entityId+1);
							// 			tmpentity[strlen(tmpentity)-1] = '\0';
							// 			issuerInfo.setEntityId(tmpentity);
							// 		}
							// 		else 
							// 			issuerInfo.setEntityId((char *)"");
							// 	}
							// 	else
							// 	issuerInfo.setEntityId(gExtBinResultExt.result[j]->entityId);
							// 	}
							// 	// R027759
							// 	// This is what it should be although it needs to discard the
							// 	// lower priority destinations
							// 	else
							//  {
							//  							profileResult[resultNum].p = pTmp;
							//  profileResult[resultNum].e = gExtBinResultExt.result[j];
							//  profileResult[resultNum].pkg = binpkg;
							//  bins[resultNum] = binpkg;
							//  resultNum++;
							//  }
							//  break;
	// end of R027759 -- commented out chunk of code

							// R027759 >>>
							// lower value has higher priority
							if (resultNum > 0 )
							{
								// if existing entry has higher priority
								// ignore issuer profile
								if (   profileResult[resultNum-1].p->m_priority 
										< pTmp->m_priority)
								{
									continue;
								}

								// If existing entry has equal priority, add the
								// issuer profile entry

								if (   profileResult[resultNum-1].p->m_priority 
										== pTmp->m_priority)
								{
									profileResult[resultNum].p = pTmp;
									profileResult[resultNum].e = gExtBinResultExt.result[j];
									profileResult[resultNum].pkg = binpkg;
									bins[resultNum] = binpkg;
									resultNum++;
								}
								else		// the entry/ies in the list are lower priority
								{			// replace all with the higher priority
									profileResult[0].p = pTmp;
									profileResult[0].e = gExtBinResultExt.result[j];
									profileResult[0].pkg = binpkg;
									bins[0] = binpkg;

									// clear next entry--serves as an EOL
									// in case this becomes the last entry
									resultNum = 1;
									profileResult[resultNum].p = NULL;
									profileResult[resultNum].e = NULL;
									profileResult[resultNum].pkg = NULL;
									bins[resultNum] = NULL;
								}
							}
							else	// this is the first entry
							{
                                profileResult[resultNum].p = pTmp;
								profileResult[resultNum].e = gExtBinResultExt.result[j];
								profileResult[resultNum].pkg = binpkg;
								bins[resultNum] = binpkg;
								resultNum++;
							}
								// R027759 <<<
										// if destination is not down
							}
							else
							{
								// Valid dest but down, in this condition,
								// If no issuer was found, it should be:
								// issuer not available, instead of 'destination blocked'
								cntBrandBlocked=(-1);

								// R027759
								// Save this one in case there was no available destination
								// that's not down
								if ( !downDest )
								{
									downDest   = pTmp;
									downExtBin = gExtBinResultExt.result[j];
								}
							}
						}					// for loop in issuer profile memory table
					}			// loop against extended bin list

					// =====================================
					//  R027759
					//  =====================================
					//  if (foundFinalRecord)
					// {
							//      issuerInfo.setIssuerBin(pTmp->m_bin);
					// 	break;
					// 	}
			}				// if transaction matched against issuer profile entry
		}					// for loop in issuer profile memory table
		if (resultNum > 0)
		{
			//Found up destination already, no need to go for next gateway
			break;
		}
	}	//for loop of gateway ids
	
	// ====================================================================================
	// R027759
	// At this point the following are needed:
	// - if there are two (2)-- if one is a blackhole BIN, 
	//   drop the black hole BIN--although not sure why it will be in the list
	// - if there are two (2) or more entries, and if configured, do the tie-breaker
	//   > in theory, issuer priority must be unique if there is no tie-breaker in effect
	//   > and if there is a tie-breaker logic, there's a high chance that there will be
	//     similar priorities with different destinations--common debit world scenario
	// - if there are 'no issuer' found, check if there were blocked destination
	//   > if there was at least one (1) blocked destination that is not blackhole BIN,
	//     make sure that the return code is set properly
	// ====================================================================================
	if (resultNum == 0)
	{
		int ret = -1;
		if (cntBrandBlocked > 0)
		{
			OTraceDebug("D-SHC-%06d: No issuer found but a destination was blocked(%d)\n",
						 __LINE__, cntBrandBlocked);
			
			// PAI-899
			// Need more information to continue processing--copy the 'down issuer' logic
			if(blockedDest && shc_locate_bin(&binpkg, blockedDest->m_bin) == -1)
			{
				OTraceFatal("F-SHC-%06d: Can't find bin package for blocked bin[%s]\n",
											__LINE__, blockedDest->m_bin);
				OTraceDebug("D-SHC-%06d: No issuer found\n", __LINE__);
			}
			else
			{
				profileResult[0].p 		= blockedDest;
				profileResult[0].e 		= blockedExtBin;
				profileResult[0].pkg 	= binpkg;
				bins[0] 				= binpkg;
				return setBlockedBin( issuerInfo );
			}
			// PAI-899

			return setBlockedBin( issuerInfo );
		}
		else
		if ( downDest )					// got a destination that's 'down'
		{
			// This is now issuer-not-available
			if(shc_locate_bin(&binpkg, downDest->m_bin) == -1)
			{
				OTraceFatal("F-SHC-%06d: Can't find bin package for internal bin[%s]\n", 
							 __LINE__, downDest->m_bin);
				OTraceDebug("D-SHC-%06d: No issuer found\n", __LINE__);
			}
			else
			{	
				OTraceDebug("D-SHC-%06d: Avail issuer is down(%s)\n", __LINE__, downDest->m_bin);
				profileResult[0].p 		= downDest;
				profileResult[0].e 		= downExtBin;
				profileResult[0].pkg 	= binpkg;
				bins[0] 				= binpkg;

				ret = 0;				// continue processing;
			}
		}
		else
			OTraceDebug("D-SHC-%06d: No issuer found\n", __LINE__);
	
		// return only if there's no issuer--even down
		if ( ret == -1 )
			return ret;
	}
	else
	if (resultNum == 1)
	{
		if (cntBrandBlocked > 0 && profileResult[0].p->m_priority >= BLACK_HOLE_PRIORITY )
		{
			OTraceDebug("D-SHC-%06d: Only blkhole dest found with %d blocked destination/s\n",
						 __LINE__, cntBrandBlocked);
			// PAI-899
			if(blockedDest && shc_locate_bin(&binpkg, blockedDest->m_bin) == -1)
			{
				OTraceFatal("F-SHC-%06d: Can't find bin package for blocked dest bin[%s]\n",
									__LINE__, blockedDest->m_bin);
				OTraceDebug("D-SHC-%06d: No issuer found\n", __LINE__);
			}
			else
			{
					profileResult[0].p 		= blockedDest;
					profileResult[0].e 		= blockedExtBin;
					profileResult[0].pkg 	= binpkg;
					bins[0] 				= binpkg;
			}
			// PAI-899

			return setBlockedBin( issuerInfo );
		}

		// if there's blocked destination and available is blackhole BIN then it is 
		//    not valid destination
		// if there's no blocked destination, it does not matter if it is blackhole BIN or not
		//    fall down and continue processing
	}
	else
	if (resultNum == 2)
	{
		// Blackhole BIN should have a lower priority than any other BINs
		// nevertheless, let's put this just in case, something went wrong in the settings
		OTraceDebug("D-SHC-%06d: Got 2 entries--checking for blackhole BIN\n", __LINE__);
		if (profileResult[0].p->m_priority >= BLACK_HOLE_PRIORITY)
		{
			OTraceDebug("D-SHC-%06d: Replacing %s with %s\n", __LINE__,
						 profileResult[0].p->m_txnDest, profileResult[1].p->m_txnDest);
			profileResult[0].p = profileResult[1].p;
			profileResult[1].p   = NULL;	
			profileResult[1].e   = NULL;	
			profileResult[1].pkg = NULL;	
			resultNum = 1;
		}
		else
		if (profileResult[1].p->m_priority >= BLACK_HOLE_PRIORITY)
		{
			OTraceDebug("D-SHC-%06d: dropping black hole BIN\n", __LINE__,
						 profileResult[1].p->m_txnDest);
			profileResult[1].p   = NULL;	
			profileResult[1].e   = NULL;	
			profileResult[1].pkg = NULL;	
			resultNum = 1;
		}
		// fall down for further processig
	}
	
	firstPriorityEntry 			= NULL;
	firstPriorityExtBinEntry 	= NULL;
	if ( resultNum > 1 )
	{
		int ret = resultNum;
		// This should not result in discarding all destination
		// ret is expected to be 1 -- but could be more
		if (haveTieBreaker && TieBreakerObj)
			ret = TieBreakerObj->breakIssuerTie(profileResult, resultNum);
			
		if (shcBalancerObj)					// no tie-breaker but with load balancer
		{
			int j = shcBalancerObj->chooseBin(bins, ret);
		
			if (j<0)
			{
				OTraceDebug("D-SHC-%06d: Load balancer did not choose any from %d entries\n",
							__LINE__, ret);
			 	return -1;
			}

			firstPriorityEntry 			= profileResult[j].p;
			firstPriorityExtBinEntry 	= profileResult[j].e;
		}
	}

	// R027759
	// At this stage, if firstPriorityEntry is still null,
	// the first entry in profileResult is the final destination
	// And the BIN could be down 
	if (firstPriorityEntry == NULL)
	{
		firstPriorityEntry 			= profileResult[0].p;
		firstPriorityExtBinEntry 	= profileResult[0].e;
	}

	issuerInfo.setTxnDest(firstPriorityExtBinEntry->destination);
	issuerInfo.setCardProduct(firstPriorityExtBinEntry->cardProduct);
	extBinCountryCode = firstPriorityExtBinEntry->country_code;
	issuerInfo.setNetworkData(firstPriorityExtBinEntry->network_data);
	issuerInfo.setIssuerBin(firstPriorityEntry->m_bin);
    istsafe_strcpy(routingRecord.bin, sizeof(routingRecord.bin),firstPriorityEntry->m_routing_bin);
	istsafe_strcpy(routingRecord.issuer, sizeof(routingRecord.issuer),firstPriorityEntry->m_bin);
	_issProfile_locate_extbin_gatewayId_used[0] = firstPriorityEntry->m_addCondition[0];
	_issProfile_locate_extbin_gatewayId_used[1] = firstPriorityEntry->m_addCondition[1];
	extBinLength = firstPriorityExtBinEntry->bin_length;

	if ( pHdr && _issProfile_locate_extbin_gatewayId_used[0] )
		pHdr->msg.gateway_id = atoi ( _issProfile_locate_extbin_gatewayId_used );

	if (!firstPriorityExtBinEntry->entityId[0])
	{
		if(!isRegularExp(firstPriorityEntry->m_entityId))
		{
			char tmpentity[sizeof(firstPriorityEntry->m_entityId)];
			strcpy(tmpentity, firstPriorityEntry->m_entityId+1);
			tmpentity[strlen(tmpentity)-1] = '\0';
			issuerInfo.setEntityId(tmpentity);
		}
		else 
			issuerInfo.setEntityId((char *)"");
	}
	else
		issuerInfo.setEntityId(firstPriorityExtBinEntry->entityId);

	return 1;
//  End of replacement code for R027759



// R027759
// Replaced by the above code 
#if 0
	if (issuerInfo.getIssuerBin()[0])
		return 1;

	if (resultNum>0)
	{
		int j = shcBalancerObj->chooseBin(bins, resultNum);
		if (j<0)
			return -1;
		firstPriorityEntry = profileResult[j].p;
		firstPriorityExtBinEntry = profileResult[j].e;
	}
	if (firstPriorityEntry)
	{
		if ( cntBrandBlocked>0 && firstPriorityEntry->m_priority >= BLACK_HOLE_PRIORITY )
		{
			return setBlockedBin( issuerInfo );
		}

		/* Found a matching record, but the bin is down, still use this bin */
		issuerInfo.setTxnDest(firstPriorityExtBinEntry->destination);
		issuerInfo.setCardProduct(firstPriorityExtBinEntry->cardProduct);
		extBinCountryCode = firstPriorityExtBinEntry->country_code;
		issuerInfo.setNetworkData(firstPriorityExtBinEntry->network_data);
		issuerInfo.setIssuerBin(firstPriorityEntry->m_bin);
                strcpy(routingRecord.bin, firstPriorityEntry->m_routing_bin);
        istsafe_strcpy(routingRecord.issuer, sizeof(routingRecord.issuer), firstPriorityEntry->m_bin);

		if (!firstPriorityExtBinEntry->entityId[0])
		{
			if(!isRegularExp(firstPriorityEntry->m_entityId))
			{
				char tmpentity[sizeof(firstPriorityEntry->m_entityId)];
				strcpy(tmpentity, firstPriorityEntry->m_entityId+1);
				tmpentity[strlen(tmpentity)-1] = '\0';
				issuerInfo.setEntityId(tmpentity);
			}
			else 
				issuerInfo.setEntityId((char *)"");
		}
		else
			issuerInfo.setEntityId(firstPriorityExtBinEntry->entityId);
		return 1;
	}
	else if ( cntBrandBlocked > 0 )
	{
		return setBlockedBin( issuerInfo );
	}
	else
		return -1;
#endif
}



int IssProfile::locate_issuerByEntityId( const char *txnSrc, const int msgType, 
					int merchantType, const long pcode, const int hasPIN, const char *issBin,
					const char *entityId, const char *destination, const char *cardProduct,
					IssuerInfo &issuerInfo )
{
	char msgTypeBuf[5]={0};
	char pcodeBuf[7]={0};
	bin_t tmpTxnSrc;
	struct shcpkg *binpkg = NULL;
	int tmpHasPIN;
	
	char deviceType[5];
	
	strcpy( deviceType, merchantType==6011 ? "ATM" : "POS" );
	
	if (msgType > 0)
		snprintf(msgTypeBuf, sizeof(msgTypeBuf),"%04.4d", msgType);
	else
		msgTypeBuf[0] = '\0';

	if (pcode >= 0)
		snprintf(pcodeBuf, sizeof(pcodeBuf), "%06.6d", pcode);
	else
		pcodeBuf[0] = '\0';

	ICInstId_pure(tmpTxnSrc, (char *)txnSrc);

	if (hasPIN)
		tmpHasPIN = 'Y';
	else
		tmpHasPIN = 'N';

	issuerInfo.reset();

	if (!initialized)
	{
		if (initialize() < 0)
			return(-1);
	}
	if (setIssRuleParam() < 0)
			return (-1);
	
	bin_t instId    = {0};
	struct shcpkg	*pBinPkg = NULL;
	if ( issBin && issBin[0] )
	{
		if ( shc_locate_bin(&pBinPkg, (char *)issBin) >= 0 )
		{
			strcpy( instId, pBinPkg->bin.institutionid );	// original instId
		}
	}

	if ( rm_waitForLockedShdMem(issuerProfileAppid) )	// R022481
	{
		OTraceWarning("W-SHC-0403.3: rm.appid[%d] was locked. Go ahead\n", issuerProfileAppid);
	}

	struct IssuerProfile *firstPriorityEntry = NULL;
	int foundFinalRecord = 0;
	struct IssuerProfile *pTmp = NULL;
	char *p = (char *)issuerProfileData;

	for (int i = 0; i < issuerRuleKeyp->keysused; i++,p+=issuerRuleKeyp->keysize)
	{
		pTmp = (struct IssuerProfile *)p;
		if (	firstPriorityEntry && (issuerProfileData[i].m_priority >= BLACK_HOLE_PRIORITY) )
			break;

		if (MatchTxnSrc(*pTmp, tmpTxnSrc)	&&
			MatchMsgContents(*pTmp, msgTypeBuf, deviceType, pcodeBuf, tmpHasPIN) &&
			MatchCardInfo(*pTmp, destination, entityId, cardProduct) )
		{
			if(shc_locate_bin(&binpkg, pTmp->m_bin) == -1)
			{
				OTraceFatal("F-SHC-0409:Can't find bin package for internal bin[%s]\n", pTmp->m_bin);
				return (-1);
			}
			if ( instId[0] && strcmp(binpkg->bin.institutionid, instId)!=0 )	// must with under same instId
			{
				OTraceDebug("D-SHC-0409a: InstId get[%s] orig[%s] with entityId[%s], ignored\n", 
						binpkg->bin.institutionid, instId, entityId );
				continue;
			}
			
			if (!firstPriorityEntry)
			{
				firstPriorityEntry = pTmp;
			}
			
			if (!shc_isdown(binpkg))
			{
				issuerInfo.setTxnDest(destination);
				issuerInfo.setCardProduct(cardProduct);
				issuerInfo.setEntityId(entityId);
				issuerInfo.setIssuerBin(pTmp->m_bin);
				istsafe_strcpy(routingRecord.bin, sizeof(routingRecord.bin),pTmp->m_routing_bin);
				istsafe_strcpy(routingRecord.issuer, sizeof(routingRecord.issuer),pTmp->m_bin);
				return 1;	// 1 = match up bin found
			}
		}
	}
	
	if (firstPriorityEntry)
	{
		/* Found a matching record, but the bin is down, still use this bin */
		issuerInfo.setTxnDest(destination);
		issuerInfo.setCardProduct(cardProduct);
		issuerInfo.setEntityId(entityId);
		issuerInfo.setIssuerBin(firstPriorityEntry->m_bin);
		istsafe_strcpy(routingRecord.bin, sizeof(routingRecord.bin),firstPriorityEntry->m_routing_bin);
        istsafe_strcpy(routingRecord.issuer, sizeof(routingRecord.issuer),firstPriorityEntry->m_bin);
		return 0;		// 0 = bin match but is down
	}
	
	return -1;			// -1 = not match bin found
}

int IssProfile::isRegularExp(const char *str)
{
	int ccc;
	int i;

	if (str[0] ==  '\0') 
		return (1);	

	for(i=0;str[i];i++)
	{
		if ((i==0)&&(str[i] == '^'))
			continue;
		if ((str[i] == '$')&& (str[i+1] == '\0'))
			break;
		if (!isalnum(str[i]))
			return 1;
	}
	return 0;
}


	/* R027802 Block by Brand support >>> */
int IssProfile::isBrandBlocked( char *src, char *dest,  char *product, int msgtype ) const
{
	/*
	// caller should be responsible when to call this
	// there are cases where one needs to filter out blocked-dest even if reversals
	// advices should behave the same
	// msgtype must be 010x/020x request (non-advice) txns
	int msgtype23  = msgtype%1000/10;
	if ( msgtype23==10 || msgtype23==20)
	{
		return brandBlockedObj->lookup(src, dest, product);
	}
	*/
	return brandBlockedObj->lookup(src, dest, product);
	
	return 0;
}


int IssProfile::setBlockedBin( IssuerInfo &issuerInfo )
{
        memset(&routingRecord, 0, sizeof(struct routingpkg));
	DNSegHelper	dnSegHelperObj;
	// USP-1319
	// Need some info to be set
	issuerInfo.setTxnDest( brandBlockedObj->getBlockedDest() );
	issuerInfo.setCardProduct(brandBlockedObj->getBlockedProduct());
	issuerInfo.setEntityId("*");
	issuerInfo.setIssuerBin( brandBlockedObj->getBlockedBin() );
	issuerInfo.setNetworkData( brandBlockedObj->getBlockedNetworkData() );	// USP_1678
        strcpy(routingRecord.bin, brandBlockedObj->getBlockedBin());
    istsafe_strcpy(routingRecord.issuer, sizeof(routingRecord.issuer), brandBlockedObj->getBlockedBin());

	// USP-PAI-1678
	if (pHdr)
	{
		OTraceDebug("D-xxxxx: Populating card type\n");
		struct shc_data*	pData = (struct shc_data*)&(pHdr->msg.shc_data_buffer[0]);
		strncpy(pData->network_data, brandBlockedObj->getBlockedNetworkData(),
				sizeof(pData->network_data));
		dnSegHelperObj.re_init();
		dnSegHelperObj.setDNCardCategory(pHdr);
	}
	else
		OTraceWarning("W-xxxxx: Msg not available to populate card type\n");
	
	return (-SHC_RC_RestrictedCard);
}
	
	/* R027802 <<< */
	

// R027759
// =====================================================================
// - filter out if PAN length is not within range
// USP-1345  (10Sep2010)
// - if not valid length ( < 12 and >19) return 0
//   this should result in the blackhole being selected
// =====================================================================
// Returns : 0 -- if not valid length
//           1 -- if valid length
//			-1 -- if error was encountered -- not used
int IssProfile::validate_PANLen(char* pan, int ix)
{
	int				ret     = 0;
	int				len1	= 0;
	int				len2	= 0;
	int  			panLen;
	char 			*endptr;
	char			cLen[3];

	for( panLen=0; isdigit(pan[panLen]); panLen++ );	// count the PAN length

	// check if within known valid range (12-19)
	if ( panLen < 12 || panLen > 19 )
	{
		OTraceWarning("W-SHC-0410: got PAN length %d -- outside of range\n", panLen);
		return 0;
	}

	// length info in network data 
	//   - is offset 2 for 2 bytes
	//   - is stored as ASCII HEX
	cLen[0] = shcExtBinData[ix].network_data[2];
	cLen[1] = shcExtBinData[ix].network_data[3];
	cLen[2] = 0;

	if ( cLen[0] > 0x20 )					// network_data must not contain NULLs
	{
		len1 = strtoul(&(cLen[0]), NULL, 16);
		len2 = 0x80 >> (panLen > 12 ? panLen - 12 : 0);
		if ((len1 & len2))				// valid PAN length
			ret = 1;
	}
	else
	{
		OTraceDebug("D-SHC-0410-a: Empty PAN length encountered\n");
		ret = 1;						// empty PAN length equates to a valid entry
	}

	return ret;
}	// R027759


//	USP-1590 -- new logic--deals with list of matching ranges (search done)
//  Validates BIN length from a set of matching ranges--search already finished and
//  some filtering already done (e.g., txntype grouping, blocked dest, etc.)
//  This is only called if debit txntype, if matching entries are at least 2 and
//	no blocked destination detected.  Assumption here is if there is a blocked destination
//  chances are this is the only destination available--otherwise, the blocked destination
//	would have been dropped
int IssProfile::filterout_shortBIN(ExtBinResult &searchResult, int ix)
{
  	char    lastVal[3], curVal[3];
   	int     lval, cval;
	int		i, j, k, ret;

	struct shcextbin*	(newList[200]);

	// clear the pointers
	for (i = 0; i < ix; i++)
		newList[i] = NULL;

	// get the longest BIN ranges
	OTraceDebug("D-0420-a: Processing %d entries\n", ix);

	newList[0] = gExtBinResultExt.result[0];
	gExtBinResultExt.result[0] = NULL;
	searchResult.result[0] = NULL;
	for ( i = 0, j = 1; j < ix; j++)
	{
		// from the working entry
		lastVal[0] = newList[i]->network_data[4];
		lastVal[1] = newList[i]->network_data[5];
		lastVal[2] = 0;
		lval       = atoi(lastVal);

		curVal[0] = gExtBinResultExt.result[j]->network_data[4];
		curVal[1] = gExtBinResultExt.result[j]->network_data[5];
		curVal[2] = 0;
		cval      = atoi(curVal);

		if (lval == cval)				// add entry into newList
		{
			for(k = 0; k < ix; k++)
			{
				if (newList[k] == NULL)
				{
					newList[k] = gExtBinResultExt.result[j];
					OTraceDebug("D-0420-b: Added (%s)(%s)(%d) into new list\n", 
								 newList[k]->destination, newList[k]->network_data, k);
					i = 0;
					break;
				}
			}
		}
		else
		if (lval > cval)				// ignore entry from searchResult
		{
			OTraceDebug("D-0420-c: Ignoring entry (%s)(%s)\n", gExtBinResultExt.result[j]->destination,
						 gExtBinResultExt.result[j]->network_data);
			i = 0;
		}
		else // cval > lval				// replace entry in newList
		{
			OTraceDebug("D-0420-d: Replacing (%s)(%s)in new list\n", newList[i]->destination,
						 newList[i]->network_data);
			newList[i]   = gExtBinResultExt.result[j];
			OTraceDebug("D-0420-d: With      (%s)(%s)\n", newList[i]->destination,
						 newList[i]->network_data);
			newList[i+1] = NULL;		// mark as end of list
			i = 0;
		}
	}									// for loop

	// now transfer the pointers back and count the end result
	// this should never be a zero--at least one entry should pass as a valid length
	for (i = 0, j = 0; i < ix; i++)
	{
		gExtBinResultExt.result[i] = newList[i];
                if (i < MAX_EXT_BIN_RESULT_NUM)
                {
                        searchResult.result[i] = newList[i];
                }
		if (newList[i] == NULL)
			break;
		else
			j++;
	}

	OTraceDebug("D-0420-e:  Got a new count of %d matches\n", j);

	return j;
}										// filterout_shortBIN


// >>> R029583
int IssProfile::setIssRuleParam()
{
	int appid;
	if(rm_init() < 0)
	{
		OTraceFatal("F-SHC-0421: Unable to connect to Rule manager\n");
		return(-1);
	}
	if((appid = rm_getappid("iss_profile")) == -1)
	{
		OTraceFatal("F-SHC-0422:unable to locate message name: inst-business-day\n");
		return(-1);
	}
	else
	{
		if ( rm_attach( appid, RULES_VER_CURRENT) != 0)
		{
			OTraceError("E-SHC-0423: Unable to attach to CURRENT version \n");
			return(-1);
		}
		issuerRuleKeyp = rm_getapphead(appid);
		/*      Find the first entry of my key table */
		issuerProfileData = (struct IssuerProfile *)rm_getappkey(appid);
		issuerProfileAppid   = appid;
	}
	return 0;
}

int IssProfile::setExtRuleParam()
{
	int appid;
	if(rm_init() < 0)
	{
		OTraceFatal("F-SHC-0424: Unable to connect to Rule manager\n");
		return(-1);
	}

	if((appid = rm_getappid("shared-cash-extbin")) == -1)
	{
		OTraceFatal("F-SHC-0425:unable to locate message name: inst-business-day\n");
		return(-1);
	}
	else
	{
		if ( rm_attach( appid, RULES_VER_CURRENT) != 0)
		{
			OTraceError("E-SHC-0426: Unable to attach to CURRENT version \n");
			return(-1);
		}
		shcExtBinRuleKeyp = rm_getapphead(appid);
		/*      Find the first entry of my key table */
		shcExtBinData = (struct shcextbin *)rm_getappkey(appid);
		shcextbinGroupData = (struct shcextbinGroupHeader *)rm_getapptext(appid);
		shcExtBinAppid   = appid;
	}
	return 0;
}
// <<< R029583

int shc_isdown(struct shcpkg *bp)
{
        if ((bp) && (bp)->bin.flags & SH_DOWN)
                return 1;

        if (!routingRecord.bin[0])
                return 0;
		if (strcmp(routingRecord.issuer, bp->bin.networkid)!=0)
			return 0;	//The connection bin is not for this bin
        struct shcpkg *binpkg = NULL;
        shc_locate_bin(&binpkg, routingRecord.bin);

        if( (binpkg) && (binpkg)->bin.flags & SH_DOWN)
        {
                OTraceDebug("D-SHC-0427: connection bin(%s) is down.\n", routingRecord.bin);
        return 1;
        }

       return 0;
}


