/*
 *  Copyright (C) 2004 eFunds Corporation ("eFunds").  All Rights Reserved.
 *  eFunds Canada Corporation is an authorized user.
 *
 *  IST is a registered trademark of eFunds Corporation.  Other brand or
 *  product names are trademarks or registered trademarks of their respective
 *  holders.
 *
 *  The information contained herein is the unpublished proprietary property
 *  of eFunds.  Except as specifically authorized in writing by eFunds, the
 *  holder of this document shall: i) keep all information contained herein
 *  confidential, and ii) protect the information, in whole or in part, from
 *  disclosure and dissemination to all third parties.
 *
 *  This document and the software described in it are furnished under license
 *  and may be used or copied only in accordance with the terms of such license.
 *  This document is supplied for information purposes only, is subject to
 *  change without notice, and should not be construed as a commitment by
 *  either eFunds Corporation or eFunds Canada Corporation.
 *
 *
 *                        MODIFICATION HISTORY              REVIEW
 *
 *	SPR#	Who	Date		Description					Who			Date
 * =============================================================================
 *  R022759	EdC	09Feb2010	Start
 */

/* File Number 156 */

static char _TieBreaker_cxx_what[] = "@(#) TieBreaker.cxx 1.3 10/04/28 13:43:20";

#include <stdio.h>
#include <string.h>
#include <ctype.h>
#include <oasis.h>
#include <dbm.h>
#include <mb.h>
#include <ist_otrace.h>
#include <ist_otrace.h>
#include <shc.h>
#include <ShcSdkCommon.h>
#include <ShcmsgHelper.h>
#include <ShcBin.h>
#include <FMCMDHeader.h>
#include <shcmerchant.h>
#include <ShcmsgHeader.h>
#include <TieBreaker.h>

TieBreaker*	TieBreakerObj = NULL;

TieBreaker::TieBreaker()
{
	headerP 	= NULL;
	msg			= NULL;
	objStatusOK	= false;
}

TieBreaker::TieBreaker(ShcmsgHeader *header)
{
	headerP 	= header;
	msg     	= &(header->msg);
	objStatusOK	= true;
}



// No core implementation--do nothing
int TieBreaker::initialize(void*)
{
	return 0;	
}



// No core implementation--do nothing
int TieBreaker::breakIssuerTie(profilesList* profileResult, int numEntries)
{
	return 0;
}
