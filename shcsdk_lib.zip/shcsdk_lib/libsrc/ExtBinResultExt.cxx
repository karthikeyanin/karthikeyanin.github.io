static char _ExtBinResultExt_cxx_what[] = "@(#) ShcmsgHelper.cxx 1.73.7.1 16/02/29 09:31:15";


/*
 *  Copyright (C) 2004 eFunds Corporation ("eFunds").  All Rights Reserved.     
 *  eFunds Canada Corporation is an authorized user.                            
 *                                                                              
 *  IST is a registered trademark of eFunds Corporation.  Other brand or        
 *  product names are trademarks or registered trademarks of their respective   
 *  holders.                                                                    
 *                                                                              
 *  The information contained herein is the unpublished proprietary property    
 *  of eFunds.  Except as specifically authorized in writing by eFunds, the     
 *  holder of this document shall: i) keep all information contained herein     
 *  confidential, and ii) protect the information, in whole or in part, from    
 *  disclosure and dissemination to all third parties.                          
 *                                                                          
 *  This document and the software described in it are furnished under license  
 *  and may be used or copied only in accordance with the terms of such license.
 *  This document is supplied for information purposes only, is subject to      
 *  change without notice, and should not be construed as a commitment by       
 *  either eFunds Corporation or eFunds Canada Corporation. 
 *
 *
 *                        MODIFICATION HISTORY                  REVIEW
 *
 *	SPR#	Who	Date	Description			Who	Date   
 * ===========================================================================
*/

/* File Number 179 */

#include <stdio.h>
#include <string.h>
#include <ist_types.h>
#include <istiso.h>
#include <oasis.h>
#include <oasisenv.h>
#include <dbm.h>
#include <tm.h>
#include <dbm_private.h>
#include <oc/oc_string.h>
#include <ist_otrace.h>
#include <Ccard_scheme.h>
#include <Cinstitution.h>
#include <shcmsgdef.h>
#include <shc.h>
#include <mt_extbin.h>


ExtBinResultExt::ExtBinResultExt()
{
	m_numOfResult = 0;
	m_numOfAllocated = 20;
	result = (struct shcextbin * *)calloc(sizeof ( struct shcextbin *), m_numOfAllocated);
	if (!result)
	{
		OTraceFatal("F-SHC-179001:Can't allocate %d entries.\n", m_numOfAllocated);
		throw 1;
	}
}

ExtBinResultExt::~ExtBinResultExt()
{
	free(result);
	result = NULL;
}

int ExtBinResultExt::accomodate(int newSize)
{
	if (m_numOfAllocated >= newSize)
		return m_numOfAllocated;
	newSize = m_numOfAllocated + 20;
	unsigned int old_sz = m_numOfAllocated;
	struct shcextbin * *new_buffer = (struct shcextbin * *)calloc(sizeof(struct shcextbin *), newSize);
	if (!new_buffer)
	{
		OTraceFatal("F-SHC-179003:Can't allocate %d entries.\n", newSize);
		throw 1;
	}
	m_numOfAllocated = newSize;
	if (m_numOfResult > 0)
		memcpy(new_buffer, result, m_numOfResult*(sizeof(struct shcextbin *)));
	free (result);
	result = new_buffer;
	return m_numOfAllocated;
}

int ExtBinResultExt::addResult(struct shcextbin *oneResult)
{
	accomodate(m_numOfResult+1);
	result[m_numOfResult++] = oneResult;
	return 1;
}
