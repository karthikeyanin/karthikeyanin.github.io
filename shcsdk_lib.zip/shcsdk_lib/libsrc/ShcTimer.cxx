/*
 *  Copyright (C) 2004 eFunds Corporation ("eFunds").  All Rights Reserved.
 *  eFunds Canada Corporation is an authorized user.
 *
 *  IST is a registered trademark of eFunds Corporation.  Other brand or
 *  product names are trademarks or registered trademarks of their respective
 *  holders.
 *
 *  The information contained herein is the unpublished proprietary property
 *  of eFunds.  Except as specifically authorized in writing by eFunds, the
 *  holder of this document shall: i) keep all information contained herein
 *  confidential, and ii) protect the information, in whole or in part, from
 *  disclosure and dissemination to all third parties.
 *
 *  This document and the software described in it are furnished under license
 *  and may be used or copied only in accordance with the terms of such license.
 *  This document is supplied for information purposes only, is subject to
 *  change without notice, and should not be construed as a commitment by
 *  either eFunds Corporation or eFunds Canada Corporation.
 */
/*
#pragma ident "@(#) ShcTimer.cxx 1.23.8.5 16/10/21 10:13:29";
 *
 *                        MODIFICATION HISTORY                  REVIEW
 *
 *	SPR#	Who	Date	Description			Who	Date
 * ===========================================================================
 *R00xxxx ztang 05Nov03 Creation
 *R015958 spa	15Mar06 txnDest should be checked while locating the event
 *R021965 emj   16Nov07 Fix shc_locate_event_x to return 1 if event is located
 *R022019 emj   20Nov07 if no pan set mailbos id to -1 in shc_locate_event_x()
 *R027738 dipa  19Jan10 USPS: Issuer Timeout option added
 *R028031 dipa 	08Apr10	Clone of R028011
 *R028031 dipa	29Apr10 implement msgtype check in shc_tm_scan
 *R028365 dipa	28Jul10 Rename shc.issuer_based_timeout parameter to shc.set_lesser_of_iss_or_acq_timeout 
 *R029824 dipa  26Aug11 Remove msgytypeMismatch logic while locating events
 *R151677738 IS 29MAR16 Addition of terminalid during the look up of event in response
 */

//File Number 36

#if defined( WIN32 )
#       define SHCDLLEXPORT __declspec(dllexport)
#else
#       define SHCDLLEXPORT
#endif


#include <stdio.h>
#include <oasis.h>
#include <ist_otrace.h>
#include <mb.h>
#include <tm.h>
#include <shcmsgdef.h>
#include <shc.h>
#include <string.h>
#include <ShcTimerHelper.h>
#include <ShcAppBase.h>

#include <CShcNotify.h>
#include <ShcHelper.h>
#include <IssProfile.h>
#include <AcqProfile.h>
#include <InstProfile.h>
#include <Shc600Log.h>
#include <ShcSafIOHelper.h>
#include <ShcmsgHelper.h>


/* 961115 */
/* static unsigned char timerBuf[ sizeof( struct shcmsg ) + SHC_SEG_MAX ];*/
/* Ssc Integration R004671 */
/* SPR 2007336 Emj - Increase buffer by 16 to hold ARQC & ARPC */
static unsigned char timerBuf[ sizeof( struct shcmsg ) + SHC_SEG_MAX  + CAM_RESULT_LEN];

extern "C" {
	typedef int (*cvrt)();
}


int ShcTimerHelper::shc_set_timers(ShcHeader *header)
{
	/*
	 *	Input:		shcmsg			message to set timers on
	 *	Action:		given an initialised shc message set the value
	 *				of when this message will time out.
	 *
	 *				As a side effect this function sets the global
	 *				shc_current_time to the time of the transaction.
	 *
	 *				The timer is set on the Originator NOT the aquirer.
	 */


	/*	set the time in and the expected time out of the tranasction */
	if (shcEnableSubssecondTimeout)
		header->time_in		= shc_current_time*1000+shc_current_millisecond;
	else
		header->time_in		= shc_current_time;

	// R027738 >>>
	int timeoutUsed = 0;
	long issuerTimeOut = 0;
	long acquirerTimeOut = 0;

	if (header->issBinValid())
	{
		if (shcEnableSubssecondTimeout)
		{
			if (header->issShcBin->binPkg->bin.addflag & SH_ADDFLAG_TIMEOUT_DECISECOND)
				issuerTimeOut = header->issShcBin->binPkg->bin.timeout*100;
			else
				issuerTimeOut = header->issShcBin->binPkg->bin.timeout*1000;
		}
		else
		{
			if (header->issShcBin->binPkg->bin.addflag & SH_ADDFLAG_TIMEOUT_DECISECOND)
				issuerTimeOut = header->issShcBin->binPkg->bin.timeout/10;
			else
				issuerTimeOut = header->issShcBin->binPkg->bin.timeout;
		}
	}
		
	if (header->acqBinValid())
	{
		if (shcEnableSubssecondTimeout)
		{
			if (header->acqShcBin->binPkg->bin.addflag & SH_ADDFLAG_TIMEOUT_DECISECOND)
				acquirerTimeOut = header->acqShcBin->binPkg->bin.timeout*100;
			else
				acquirerTimeOut = header->acqShcBin->binPkg->bin.timeout*1000;
		}
		else
		{
			if (header->acqShcBin->binPkg->bin.addflag & SH_ADDFLAG_TIMEOUT_DECISECOND)
				acquirerTimeOut = header->acqShcBin->binPkg->bin.timeout/10;
			else
				acquirerTimeOut = header->acqShcBin->binPkg->bin.timeout;
		}
	}

	if ( shcApp->acquirerShcParamsList->GetBool((char*)"shc.set_lesser_of_iss_or_acq_timeout")  // Use Issuer timeout configured ?
				&& header->issShcBin && header->issShcBin->binPkg )
	{
		if ( issuerTimeOut <acquirerTimeOut )
		{
			timeoutUsed = issuerTimeOut;   // Issuer timeout < Acquirer's
			OTraceDebug("D-SHC-036010: Use ISSUER[%s] Timeout[%d] \n",
							header->issShcBin->binPkg->bin.networkid, header->issShcBin->binPkg->bin.timeout);
		}
		else
		{
			timeoutUsed = acquirerTimeOut;   // Acquirer timeout < Issuer's
			OTraceDebug( "D-SHC-036011: Use Acquirer[%s] timeout=%d, which is shorter than Issuer[%s] timeout[%d]\n",
								header->acqShcBin->binPkg->bin.networkid,
								header->acqShcBin->binPkg->bin.timeout,
								header->issShcBin->binPkg->bin.networkid,
								header->issShcBin->binPkg->bin.timeout );
		}
	}
	else	// Only use Acquirer timeout as before
	{
		timeoutUsed = acquirerTimeOut;
		OTraceDebug("D-SHC-036001: Acquirer '%s' Timeout = %ld \n",
			header->acqShcBin->binPkg->bin.networkid, acquirerTimeOut);
	}

	if (shcEnableSubssecondTimeout)
		header->time_out = shc_current_time*1000+shc_current_millisecond + timeoutUsed;
	else
		header->time_out = shc_current_time + timeoutUsed;
// R027738 <<<

	return(0);
}


int ShcTimerHelper::shc_time_message(ShcmsgHeader *header)
{
	/* 961115 */
	return( shc_time_message_x( header, NULL ) );
}

int ShcTimerHelper::shc_time_message_x( ShcmsgHeader *header, unsigned char *seg )
{
	/*
	 *	Set the timer for this message to time out
	 */
	int		save_msgno;
	int		ret;

	/* SHC_PREAUTH_REQ is 7100 type message */
	if(header->msg.msgtype == SHC_PREAUTH_REQ)
	{
		save_msgno = header->msg.msgtype;
		header->msg.msgtype = header->msg.origmsg;
	}
	else
		save_msgno = header->msg.msgtype;

	OTraceDebug("D-SHC-036003:  Create event message for m%04d/t%06d\n",
		header->msg.msgtype, header->msg.trace);
	OTraceDebug("D-SHC-036004:   key : %ld\n", shcApp->shcmsgHelperObj->shcMakeKey(header));

	/* 961115 */
	header->truelength();
	if( (!seg) ||
		(!shcmsgHasSegment(&header->msg)) )
	{
		/* Ssc - 28Jun00	 R004671 7.2 integration */
		/* Ssc - 02Mar00     SPR # 2007336 Get ARQC & ARPC from CAM
         *                   and store in buffer
         */
        memcpy( &timerBuf[ 0 ], &header->msg, sizeof( struct shcmsg ) );

		shcApp->shcHelperObj->shc_get_cam_stored_results( &timerBuf[ sizeof( struct shcmsg ) ],
								&timerBuf[ sizeof( struct shcmsg ) + 8 ] );

		if (header->time_out < 10000000000)
		{
        	if((header->eventId = tm_enqueue(shcmid,
                                         header->time_out,
                                         TM_NOTIFY_ONCE,
                                         shcApp->shcmsgHelperObj->shcMakeKey(header),
                                         (char *)&timerBuf[ 0 ],
                                         sizeof( struct shcmsg )+CAM_RESULT_LEN )) < 0)
        	/* Ssc - 02Mar00    SPR # 2007336 End of modification */
			{
				OTraceFatal("F-SHC-036005: Unable to place msg on event queue: Fatal error\n");
				ret = (-1);
			}
			else
				ret = 0;
		}
		else 
		{
			if((header->eventId = tm_hires_enqueue(shcmid, header->time_out/1000, header->time_out%1000*1000000,
					TM_NOTIFY_ONCE,
					shcApp->shcmsgHelperObj->shcMakeKey(header),
					(char *)&timerBuf[ 0 ],
					sizeof( struct shcmsg )+CAM_RESULT_LEN )) < 0)
			{
				OTraceFatal("F-SHC-036015: Unable to place msg on event queue: Fatal error\n");
				ret = (-1);
			}
			else
				ret = 0;
		}
	}
	else
	{
		struct shcseg *segment = (struct shcseg *)seg;
		if (segment->totalsize < 0)
			segment->totalsize = 0;
		memcpy( &timerBuf[ 0 ], &header->msg, sizeof( struct shcmsg ) );
		if (segment->totalsize > 0)
			memcpy( &timerBuf[ sizeof( struct shcmsg ) ], seg, segment->totalsize );

		/* Ssc - 28Jun00	R004671 7.2 integration */
		/* Ssc - 02Mar00    SPR # 2007336 Get ARQC & ARPC from CAM
         *                  and store in buffer
         */
		shcApp->shcHelperObj->shc_get_cam_stored_results( &timerBuf[ sizeof( struct shcmsg ) + segment->totalsize ],
                            &timerBuf[ sizeof( struct shcmsg ) + segment->totalsize + 8 ] );

		if (header->time_out < 10000000000)
		{
			if((header->eventId = tm_enqueue(shcmid, header->time_out,
	   			TM_NOTIFY_ONCE, shcApp->shcmsgHelperObj->shcMakeKey(header), (char *)&timerBuf[ 0 ],
				sizeof( struct shcmsg ) + segment->totalsize + CAM_RESULT_LEN ) ) < 0 )
			{
				OTraceFatal("F-SHC-036006: Unable to place msg on event queue: Fatal error\n");
				ret = (-1);
			}
			else
				ret = 0;
		}
		else 
		{
			if((header->eventId = tm_hires_enqueue(shcmid, header->time_out/1000, header->time_out%1000*1000000,
	   			TM_NOTIFY_ONCE, shcApp->shcmsgHelperObj->shcMakeKey(header), (char *)&timerBuf[ 0 ],
				sizeof( struct shcmsg ) + segment->totalsize + CAM_RESULT_LEN ) ) < 0 )
			{
				OTraceFatal("F-SHC-036016: Unable to place msg on event queue: Fatal error\n");
				ret = (-1);
			}
			else
				ret = 0;
		}

	}

	OTraceDebug("D-SHC-036017: event(%d) created, in(%ld), out(%ld)\n", header->eventId, header->time_in, header->time_out);
	header->msg.msgtype = save_msgno;
	return(ret);
}	/* shc_time_message_x */


int ShcTimerHelper::shc_locate_event(register ShcmsgHeader *header)
{
	struct ShcmsgWithSegment shcmsgSeg = {0} ;
	struct shcmsg *oReqMsg = &(shcmsgSeg.msg);

	int ret = shc_locate_event_x(header, oReqMsg, (unsigned char *)(oReqMsg+1));

	if ( ret >= 0 )
		header->allocateAndCopyReqMsg(oReqMsg);

	return ret;
}


/* 961115 */
int ShcTimerHelper::shc_locate_event(register ShcmsgHeader *header, struct shcmsg *omsg)
{
	return( shc_locate_event_x( header, omsg, NULL ) );
}

static struct shcmsg *currentScanMsg=NULL;
//static int MsgtypeMismatchFound = 0; //R028031
int UseMsgTypeInEventMatching = 1; 		//R028031
int shc_tm_scan(ist_TmNumKey_t NumKey, char* Buf, int Len )
{
	struct shcmsg *eventMsg=(struct shcmsg *)Buf;

	if (!currentScanMsg)
	{
		return 1;
	}

	if(shcmsgIsDeviceAck(currentScanMsg) && eventMsg->unit == currentScanMsg->unit)
	{
		return 1;
	}


	if (currentScanMsg->msgtype==SHC_NETWORK_RESPONSE || !isdigit(currentScanMsg->pan[0]))
	{
		return 1;		//No pan, match
	}

	int len = 0;
	if (( currentScanMsg->msgtype == SHC_NEGATIVEFILE_ADVICE_RESP) || ( currentScanMsg->msgtype == SHC_FILEUPD_ISSREQ_RESPONSE))
	{
		len = (strlen(currentScanMsg->pan) < (strlen(eventMsg->pan))?strlen(currentScanMsg->pan):strlen(eventMsg->pan));
	}
	else
	{
		len = 16;
	}


        if((strncmp(currentScanMsg->pan, eventMsg->pan,len)==0)
		|| (   ((eventMsg->pan[0]         == 0) || (eventMsg->pan[0]         == ' '))
				&& ((currentScanMsg->pan[0] == 0) || (currentScanMsg->pan[0] == ' '))
			)
	  )
	{ 
		//	---	R015958
		//	txnDest should be used while locating the event
		if ((!useTxnDestInEventMatching) || (!currentScanMsg->txnDest[0]) ||
			(strcmp(eventMsg->txnDest, currentScanMsg->txnDest) == 0))
		{
			// R028031 >>>
			if (UseMsgTypeInEventMatching)
			{
				if ((currentScanMsg->msgtype / 10 % 10)&1) // if it is a response msg
				{
					if (currentScanMsg->msgtype == shcApp->shcmsgHelperObj->shc_get_return_msgno(eventMsg->msgtype))
					{
						//  -----R151677738
                                                OTraceDebug("D-SHC-036012: Currentmsg termid [%s] EventMsg termid [%s] \n",currentScanMsg->termid, eventMsg->termid);
                                                if (currentScanMsg->termid[0] && eventMsg->termid[0])
                                                {
														int l1 = strlen(currentScanMsg->termid);
														int l2 = strlen(eventMsg->termid);
														if (l1 > l2)
															l1 = l2;
                                                        if( strnicmp(currentScanMsg->termid, eventMsg->termid, l1) == 0)
                                                                return 1;
                                                }
                                                else 
                                                        return 1;

						//  -----R151677738
                                        }
					else
					{
						OTraceDebug("D-SHC-036009: msgtype does not match.event[%d], msg[%d]\n",
							shcApp->shcmsgHelperObj->shc_get_return_msgno(eventMsg->msgtype),currentScanMsg->msgtype);
		//				MsgtypeMismatchFound = 1;
					}
				}
				else
				{
					if (currentScanMsg->msgtype == eventMsg->msgtype)
						return 1;
					else
					{
						OTraceDebug("D-SHC-036011: msgtype does not match.event[%d], msg[%d]\n",
								eventMsg->msgtype,currentScanMsg->msgtype);
		//				MsgtypeMismatchFound = 1;
					}
				}
			}
			else
				return 1;
			// <<< R028031
		}
		else
			OTraceDebug("D-SHC-036008:txnDest not match.event[%s], msg[%s]\n",
				eventMsg->txnDest,currentScanMsg->txnDest);
	}
	else
		OTraceDebug("D-SHC-036007:Pan not match.event[%s], msg[%s]\n",
			shcApp->shcHelperObj->shc_maskpan(eventMsg->pan),
			shcApp->shcHelperObj->shc_maskpan(currentScanMsg->pan)); 

	return 0;
}


/* 961115 */
int ShcTimerHelper::shc_locate_event_x( register ShcmsgHeader *header, struct shcmsg *omsg, unsigned char *seg )
{
	/* Locate the message in the event queue */
	int		event;
	long	key;
	int		found = 0;
	struct	shcmsg	msg;
	int mailboxid;
	int retVal; //R028031

	header->eventId = -1;

	if(!shcApp->shcExtendedEventLocate && !gShcExtendedEventLocate)
	{
		if((header->eventId = tm_locate(shcApp->shcmsgHelperObj->shcMakeKey(header), -1)) < 0)
			return(-1);
		else if(omsg != NULL)
		{
			if( !seg )
			{
				/* Ssc - 28Jun00	R004671 7.2 integration */
				/* Ssc - 02Mar00    SPR # 2007336 Get ARPC & ARQC from event
                 *                  and store in CAM
                 */
				if( tm_getdata( header->eventId,
                                (char *)&timerBuf[ 0 ],
                                sizeof( timerBuf)) > 0 )
                {
                    memcpy( omsg, &timerBuf[ 0 ], sizeof(struct shcmsg) );
                    shcApp->shcHelperObj->shc_set_cam_stored_results( &timerBuf[ sizeof( struct shcmsg) ],
                                                &timerBuf[ sizeof( struct shcmsg) + 8 ] );
                    return(1);
                }
                else
                {
                    return (-1);
                }
			}
			else
			{
				int	retVal;
				struct shcseg *segment;
				if( ( retVal = tm_getdata( header->eventId,
					(char *)&timerBuf[ 0 ], sizeof( timerBuf ) ) ) >= 0 )
				{
					memcpy( omsg, &timerBuf[ 0 ],
						sizeof( struct shcmsg ) );
					int segsize = retVal - sizeof(struct shcmsg) - CAM_RESULT_LEN;
					if (segsize > 0)
						memcpy( seg, &timerBuf[ sizeof( struct shcmsg ) ], segsize );
					/* Emj - Get ARQC & ARPC from event and store in CAM */

                    shcApp->shcHelperObj->shc_set_cam_stored_results( &timerBuf[sizeof( struct shcmsg) + segsize],
                                                &timerBuf[sizeof( struct shcmsg) + segsize + 8]);
				}
				return retVal;
			}
		}
		else
			return(0);
	}

	key = shcApp->shcmsgHelperObj->shcMakeKey(header);

	if (header->msg.pan[0])
		shcApp->shcmsgHelperObj->shc_normalizepan(header->msg.pan);

	if ((header->msg.msgtype != SHC_NETWORK_RESPONSE) && isdigit(header->msg.pan[0]))
	{
		mailboxid = shcmid;
	}
	else
	{
		mailboxid = -1;
	}



	for(event = -1; !found; )
	{
		currentScanMsg = &header->msg;
		UseMsgTypeInEventMatching = 1; //R028031
		event = tm_locate_event(key, event, mailboxid, (cvrt)&shc_tm_scan);

		currentScanMsg = NULL;
		if(event < 0)
			break;
		else
			found = 1;

		/* Ssc - 28Jun00	R004671 7.2 integration */
		/* Ssc SPR2007336 */
		int retVal = tm_getdata( event, (char *)&timerBuf[ 0 ], sizeof(timerBuf) );
		memcpy(&msg, &timerBuf[ 0 ], sizeof(struct shcmsg) );

		/* 961115 */
		if( !seg )
		{
			/* Ssc - 28Jun00	R004671 7.2 integration */
			/* Ssc - 02Mar00    SPR # 2007336 Get ARQC & ARPC from event and
			*                  store to CAM
			*/
			shcApp->shcHelperObj->shc_set_cam_stored_results( &timerBuf[ sizeof(struct shcmsg)],
											&timerBuf[ sizeof(struct shcmsg) + 8 ] ) ;
		}
		else
		{
			int segsize = retVal - sizeof(struct shcmsg) - CAM_RESULT_LEN;
			if (segsize > 0)
				memcpy( seg, &timerBuf[ sizeof( struct shcmsg ) ], segsize );

			/* Ssc - 28Jun00	R004671 7.2 integration */
			/* Ssc - 02Mar00    SPR # 2007336 Get ARQC & ARPC from event and
			*                  store to CAM
			*/
			shcApp->shcHelperObj->shc_set_cam_stored_results( &timerBuf[ sizeof( msg ) + segsize ],
											&timerBuf[ sizeof( msg ) + segsize + 8 ] );
		}
	}

	if(!found)
	{
		// R028031 >>>
		// check if event is not fetched due to msgtype mismatch.
		//if (MsgtypeMismatchFound)
		//{
		//	OTraceDebug("D-SHC-036010: Restoring the msgtype mismatched event\n");

			// try getting the event id now.
		//	UseMsgTypeInEventMatching = 0;
		//	event = tm_locate_event(key, event, mailboxid, (cvrt)&shc_tm_scan);
		//	if (event < 0)
		//	{
		//		MsgtypeMismatchFound = 0;//R028031
		//		return(-1);
		//	}

		//	int retVal = tm_getdata( event, (char *)&timerBuf[ 0 ], sizeof(timerBuf) );
		//	memcpy(&msg, &timerBuf[ 0 ], sizeof(struct shcmsg) );

		//	if( !seg )
		//		shcApp->shcHelperObj->shc_set_cam_stored_results( &timerBuf[ sizeof(struct shcmsg)],
		//									&timerBuf[ sizeof(struct shcmsg) + 8 ] ) ;
		//	else
		//	{
		//		int segsize = retVal - sizeof(struct shcmsg) - CAM_RESULT_LEN;
		//		if (segsize > 0)
		//			memcpy( seg, &timerBuf[ sizeof( struct shcmsg ) ], segsize );

		//	shcApp->shcHelperObj->shc_set_cam_stored_results( &timerBuf[ sizeof( msg ) + segsize ],
		//									&timerBuf[ sizeof( msg ) + segsize + 8 ] );
		//	}
		//}
		//else
			return(-1);
	}

	header->eventId = event;
//	MsgtypeMismatchFound = 0;//R028031

	if(omsg != NULL)
		memcpy(omsg, &msg, sizeof(struct shcmsg));

	return(1);
}	/* shc_locate_event_x */

