static char _LCRHelper_cxx_what[] = "@(#) LCRHelper.cxx 1.15 19/12/16 15:17:46" ;

/*
 *  Copyright (C) 2010 FIS Corporation ("FIS").  All Rights Reserved.
 *  FIS Canada is an authorized user.
 *
 *  IST is a registered trademark of FIS Corporation.  Other brand or
 *  product names are trademarks or registered trademarks of their respective
 *  holders.
 *
 *  The information contained herein is the unpublished proprietary property
 *  of FIS.  Except as specifically authorized in writing by FIS, the
 *  holder of this document shall: i) keep all information contained herein
 *  confidential, and ii) protect the information, in whole or in part, from
 *  disclosure and dissemination to all third parties.
 *
 *  This document and the software described in it are furnished under license
 *  and may be used or copied only in accordance with the terms of such license.
 *  This document is supplied for information purposes only, is subject to
 *  change without notice, and should not be construed as a commitment by
 *  either FIS Corporation or FIS Canada.
 *
 *
 *                        MODIFICATION HISTORY                  REVIEW
 *
 * SCR#     Who    Date  Description
 * ===========================================================================
 * R0xxxxx
 */
#include <stdlib.h>
#include <ist_text.h>
#include <rules.h>
#include <ist_otrace.h>
#include <shcPosGeoLoc.h>
#include <BusinessDay.h>
#include <LCRHelper.h>
#include <istsafe.h>

#include <HaPtmCctHelper.h>

LCRHelper *LCRHelperObj = NULL;

LCRHelper::LCRHelper() : objStatusOK(false)   //    >>R029856
{
	;	// do nothing
}

LCRHelper::LCRHelper(ShcmsgHeader* hdr): objStatusOK(false) //    >>R029856
{
	initialize(hdr);
}


LCRHelper::~LCRHelper()
{
    ; // do nothing
}


int LCRHelper::initialize(ShcmsgHeader* hdr)
{
	if ( objStatusOK )
	{
		oMsg = &(hdr->msg);
		return 0;
	}

    issuerRuleKeyp      = NULL;
    shcExtBinRuleKeyp   = NULL;
    shcExtBinData       = NULL;
    shcextbinGroupData  = NULL;
    issuerProfileData   = NULL;
    issuerProfileAppid  = -1;

    char    xbuf[128];

    // store the message's address
    oMsg = &(hdr->msg);

    // Issuer Profile shared memory area
    if((appid = rm_getappid("iss_profile")) < 0)
    {
        OTraceFatal("F-LCR-00001: no issuer profile in shared-memory\n");
        objStatusOK = false;
    }

    if (objStatusOK)
    {
        issuerRuleKeyp     = rm_getapphead(appid);

        issuerProfileData  = (struct IssuerProfile *)rm_getappkey(appid);
		issuerProfileAppid = appid;
    }

    // extended BIN table shared memory area
    //if ((appid = rm_getappid("shared-cash-extbin")) < 0)
    //{
    //  OTraceFatal("F-LCR-00002: no extended BIN table in shared-memory\n");
    //  objStatusOK = false;
    //}

    //if ( objStatusOK )
    //{
    //   shcExtBinRuleKeyp = rm_getapphead(appid);

        //  Find the first entry of my key table
    //   shcExtBinData       = (struct shcextbin *)rm_getappkey(appid);
    //   shcextbinGroupData  = (struct shcextbinGroupHeader *)rm_getapptext(appid);
    //   shcExtBinAppid      = appid;
    //   objStatusOK         = true;
    //}

    memset(stateTable, 0, sizeof(stateTable));
    strcpy(stateTable, (char*)"....");
    strcat(stateTable, (char*)"AL  AK      AZ  AR  CA      CO  CT  DE  ");
    strcat(stateTable, (char*)"DC  FL  GA      HI  ID  IL  IN  IA  KS  ");
    strcat(stateTable, (char*)"KY  LA  ME  MD  MA  MI  MN  MS  MO  MT  ");
    strcat(stateTable, (char*)"NE  NV  NH  NJ  NM  NY  NC  ND  OH  OK  ");
    strcat(stateTable, (char*)"OR  PA      RI  SC  SD  TN  TX  UT  VT  ");
    strcat(stateTable, (char*)"VA      WA  WV  WI  WY              AB  ");
    strcat(stateTable, (char*)"BC  MB  NB  NL  NU  NS  ON  PE  QC  SK  ");
    strcat(stateTable, (char*)"    PR                      VI          ");
    strcat(stateTable, (char*)"AS  FM  GU  MH  MP  PW  PR  PR  UM  VI  ");
    strcat(stateTable, (char*)"                                        ");
    strcat(stateTable, (char*)"                                        ");
    OTraceDebug("D-LCR-00002a: Init state table to (%s) with length of (%d)\n", stateTable,
                    strlen(stateTable));

	HaPtmCctHelper::addHandler( "system.dcs.shc_generic" ) ;

    // State code mapping for state-priority routing
	snprintf(fileloc, sizeof(fileloc), "%s/cfg/istparam.cfg", getenv((char*)"OSITE_ROOT"));
    memset(statemap_list, 0, sizeof(statemap_list));
    if (cf_openfile(fileloc) < 0 )
    {
        OTraceWarning("W-LCR: Unable to load state mapping table - open error\n");
        syslg("W-LCR: Unable to load state mapping table - open error\n");
    }
    else
    {
        if(cf_readtable(xbuf, (char*)"shc.lcr_statemap", (char*)"{", (char*)"}", '\n',NULL,1) < 0)
        {
            OTraceError("E-LCR-0140: Unable to locate table '%s'\n", (char*)"shc.lcr_statemap");
            syslg ("E-LCR-0140: Unable to locate table '%s'\n", (char*)"shc.lcr_statemap");
        }
        else
        {
            char    xbuf[256];
            char*   tok = NULL;
			char*	lPtr = NULL;
            char    user[17];
            char    tag[17];
            char    val[33];

            memset(xbuf, 0, sizeof(xbuf));
            while (cf_readtable(xbuf, (char*)"shc.lcr_statemap", (char*)"{", (char*)"}",
                                '\n', NULL, 0) == 0)
            {
                OTraceDebug("D-LCR-%06d: Got %s\n", __LINE__, xbuf);
                tok = strtok(xbuf, " \t");              // space and/or tab chars
                if ( !tok )
                    continue;                           // NULL entry

                // Now let's start processing
                // There will be no validation here -- GIGO!
				// I got the from state
				lPtr = strstr(stateTable, tok);
				if (!lPtr)
				{
                	OTraceWarning("W-LCR-%06d: Invalid entry(%s)--skipping...\n", __LINE__, tok);
                	syslg        ("W-LCR-%06d: Invalid entry(%s)--skipping...\n", __LINE__, tok);
					continue;
				}

                tok = strtok(NULL, " \t");              // get to the TAG token
                if ( tok == NULL )                      // only one value supplied
                {
                    // GIGO -- no validation
                    OTraceWarning("W-LCR-%06d: Not enough data detected\n", __LINE__);
                    syslg		 ("W-LCR-%06d: Not enough data detected\n", __LINE__);
                    continue;
                }
                else                                    // the SHC value
                {
                	OTraceDebug("D-LCR-%06d: Got toMap(%s)\n", __LINE__, tok);
                    memcpy((lPtr+2), tok, 2);
                }

            }   // while loop of suceeding cf_readtable
        }       // else of initial cf_readtable
    }           // after good open

	objStatusOK = true;	
	//    >>R029856
	return 0;      // the objStatusOK should be checked instead of the return value -- USP-1735
	//    <<R029856
}				// initialize()



// -----------------------------------------------------------------
// Test for(in priority order):
// -  state priority
// -  network priority
// -  issuer priority
// Do this only for debits 
// -----------------------------------------------------------------
int	LCRHelper::doLCR(ExtBinResult& extBinList)
{
	int ret = 0;

	if (!objStatusOK)
	{
		OTraceWarning("W-LCR-%06d: Object not properly initialized!\n", __LINE__);
		return -1;
	}

	// 18May2010
	if ( processOption != 'D' )
	{
		OTraceDebug("D-LCR-%06d: Not a debit transaction(%c)--skipping LCR...\n", processOption);
		return 0;
	}

	if ( ret == 0 )
	{
		OTraceDebug("D-LCR-%06d: Checking for EBTG Destination\n", __LINE__);
        ret = 0;
        for (int i = 0; i < gExtBinResultExt.m_numOfResult; i++ )
        {
            // Search entry for EBTG destination
            // This will re-arrange the PAN ranges
            if ( stricmp(gExtBinResultExt.result[i]->destination, EBTG_NETWORK) == 0 )
            {
		gExtBinResultExt.m_numOfResult = extBinList.m_numOfResult = ret = 1;

                if ( i != 0 )
				{
		extBinList.result[0] = gExtBinResultExt.result[0] = gExtBinResultExt.result[i];
		extBinList.result[1] = gExtBinResultExt.result[1] = NULL;
				}
                OTraceDebug("D-LCR-%06d: Found EBTG Network(%d-%d-%s)\n", __LINE__, ret, 
							 gExtBinResultExt.m_numOfResult, gExtBinResultExt.result[0]->destination);
                return 0;
            }
        }

		// No EBTG network in the list
		if ( ret == 0 )
		{
			OTraceDebug("D-LCR-%06d: Checking for State Rule!\n", __LINE__);
            for (int i = 0; i < extBinList.m_numOfResult; i++ )
            {
                if (   gExtBinResultExt.result[i]->network_data[PRIORITY_OFFSET]   != ' '     // SPACE
                    && gExtBinResultExt.result[i]->network_data[PRIORITY_OFFSET+1] != ' '     // SPACE
                   )
                {
                    ret = lcrStateRule(extBinList, i);
                    if (ret == 1)				// means found one state rule
                    {
                        if ( i != 0 )
				gExtBinResultExt.result[0] = extBinList.result[0] = gExtBinResultExt.result[i];

                        // There should be only one state rule possible
			gExtBinResultExt.m_numOfResult = extBinList.m_numOfResult = 1;
                        return 0;
                    }
                }								// checking if state rule is set
            }									// for loop
		}										// if no EBTG destination


		if ( ret == 0 )			// No State rule -- check if network rule is set
		{
            int newLoc = 0;
            int i;

            // Search entry for network rule
            OTraceDebug("D-LCR-%06d: Checking for Network Rule\n", __LINE__);
            for (i = 0; i < gExtBinResultExt.m_numOfResult; i++ )
            {
                // This will re-arrange the PAN ranges
                if (   gExtBinResultExt.result[i]->network_data[PRIORITY_OFFSET] == NETWORK_PRIORITY
					&& gExtBinResultExt.result[i]->network_data[PRIORITY_OFFSET+1] == ' ')
                {
                    OTraceDebug("D-LCR-%06d: Found Network Rule for %s\n",  __LINE__,
                                 gExtBinResultExt.result[i]->destination);

                    if ( i != newLoc )                  // if not the same offset
			{
				gExtBinResultExt.result[newLoc] = gExtBinResultExt.result[i];
				if (newLoc < MAX_EXT_BIN_RESULT_NUM)
					extBinList.result[newLoc] = gExtBinResultExt.result[i];
			}

                    newLoc++;
                }
            }

            if ( newLoc >= 1 )							// more than 1 is ok
            {
                ret = newLoc;
		gExtBinResultExt.m_numOfResult = newLoc;
		if (newLoc <= MAX_EXT_BIN_RESULT_NUM)
			extBinList.m_numOfResult = newLoc;
		else
			extBinList.m_numOfResult = MAX_EXT_BIN_RESULT_NUM;
		return 0;
            }
		}						// if there's a network rule

	
		if ( ret == 0 )			// no network priority -- check Issuer priority rule
		{
            // search entry for issuer priority rule
            // does not matter if this is a black hole BIN -- must still have the appropriate
            // entry for normal flow to succeed
            int newLoc = 0;
            int i;

            OTraceDebug("D-LCR-%06d: Checking for Issuer Priority Rule\n", __LINE__);
            for (i = 0; i < gExtBinResultExt.m_numOfResult; i++ )
            {
                // This will re-arrange the PAN ranges
				// USP-1399 -- why this again?
                if (   gExtBinResultExt.result[i]->network_data[PRIORITY_OFFSET]   == ISSUER_PRIORITY
					&& gExtBinResultExt.result[i]->network_data[PRIORITY_OFFSET+1] == ' ')
                {
                    OTraceDebug("D-LCR-%06d: Found Issuer Priority Rule for %s\n", __LINE__,
                                 gExtBinResultExt.result[i]->destination);

                    if ( i != newLoc )                  // if not the same offset
			{
				gExtBinResultExt.result[newLoc] = gExtBinResultExt.result[i];
				if (newLoc < MAX_EXT_BIN_RESULT_NUM)
					extBinList.result[newLoc] = gExtBinResultExt.result[i];
			}

                    ++newLoc;
                }
            }

            if ( newLoc >= 1 )						// it is possible to have more than 1 entry
            {
                ret = newLoc;
		gExtBinResultExt.m_numOfResult = newLoc;
		if (newLoc <= MAX_EXT_BIN_RESULT_NUM)
			extBinList.m_numOfResult = newLoc;
		else
			extBinList.m_numOfResult = MAX_EXT_BIN_RESULT_NUM;

            }
		}						// if there's an issuer priority rule

	}							// if initialization is good/done

	// no priority rule detected -- continue processing
	return ret;
}


// Default action: do nothing
// This is expected to be overridden by client-specific code
int LCRHelper::clientRoutingRule(struct shcmsg* msg, ExtBinResult& XBinList)
{
   OTraceInfo("I-LCR-%06d: no client implementation\n", __LINE__);
    return 0;
}

int LCRHelper::lcrStateRule(ExtBinResult& extBinList, int ix)
{
    int          ret = 0;
    int          st = 0;
    const char*  state;
    char*        p = NULL;
    char         wrkState[5];
    ShcPosGeoLoc tmpPOSGeoLoc(oMsg->pos_geo_loc);

    state = tmpPOSGeoLoc.getStateProvince();
    st = (IstSafeInt(atoi(state))*4).getInt();
    OTraceDebug("LCR-%06d: oMsg(%p)(%s) state(%s)(%d)\n", __LINE__, oMsg, 
				 oMsg->pos_geo_loc, state, st);

    OTraceDebug("LCR-%06d: POS GeoLoc(%s)\n ix(%d) state(%c%c) mem(%s)\n", __LINE__,
                oMsg->pos_geo_loc, ix, stateTable[st], stateTable[st+1],
                (char*)&(gExtBinResultExt.result[ix]->network_data[STATE_OFFSET]));

	// If there's a mapping, the next code must not be spaces
	if ( stateTable[st+2] > 0 && stateTable[st+2] > ' ')
    	strncpy(wrkState, &(stateTable[st+2]), 2);
	else
    	strncpy(wrkState, &(stateTable[st]), 2);
    wrkState[2] = 0;
    // If none was found in the mapping list, then the original is retained and used
    OTraceDebug("LCR-%06d: Using State %s\n", __LINE__, wrkState);

    if(memcmp((char*)&(gExtBinResultExt.result[ix]->network_data[STATE_OFFSET]),
              (char*)&(wrkState[0]), 2) == 0)
    {
        OTraceDebug("LCR-%06d: Found State Rule for %s\n", __LINE__,
                     gExtBinResultExt.result[ix]->destination);
        ret = 1;
    }

    return ret;
}

void LCRHelper::getOtherData(IssuerInfo&)
{
    OTraceDebug("D-%06d: getOtherData--no action\n", __LINE__);
}

int LCRHelper::binCompare(const char* pan, const char* low, const char* high, int size)
{
    int ret = -1;

    if(memcmp(pan, low, size) >= 0)
    {
        if(memcmp(pan, high, size) > 0)
            ret = 1;
        else
            ret = 0;
    }

    return ret;
}

