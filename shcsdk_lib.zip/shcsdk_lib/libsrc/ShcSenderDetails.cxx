/*
 *  Copyright (C) 2004 eFunds Corporation ("eFunds").  All Rights Reserved.     
 *  eFunds Canada Corporation is an authorized user.                            
 *                                                                              
 *  IST is a registered trademark of eFunds Corporation.  Other brand or        
 *  product names are trademarks or registered trademarks of their respective   
 *  holders.                                                                    
 *                                                                              
 *  The information contained herein is the unpublished proprietary property    
 *  of eFunds.  Except as specifically authorized in writing by eFunds, the     
 *  holder of this document shall: i) keep all information contained herein     
 *  confidential, and ii) protect the information, in whole or in part, from    
 *  disclosure and dissemination to all third parties.                          
 *                                                                          
 *  This document and the software described in it are furnished under license  
 *  and may be used or copied only in accordance with the terms of such license.
 *  This document is supplied for information purposes only, is subject to      
 *  change without notice, and should not be construed as a commitment by       
 *  either eFunds Corporation or eFunds Canada Corporation. 
 */

// "@(#) ShcSenderDetails.cxx 1.0.0.0 02/04/21 21:07:36"

/*----------------------------------------------------------------------------*
 *                                                                            *
 * File:				
 * Description:	
 * Notes:
 *
 * Modification History:
 * YYMMDD SCR#    WHO	Description
 * ------ ------- ---	------------------------------------------------------*
 * 210402 R000000 basker Created.
 *----------------------------------------------------------------------------*/

/* File Number 20 */

#if defined(WIN32)
#	define ShcSenderDetails_h_export_directive	__declspec(dllexport)
#else
#	define ShcSenderDetails_h_export_directive
#endif

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <ctype.h>
#include <errno.h>
#include <oasis.h>
#include <ist_otrace.h>
#include <ShcSenderDetails.h>
#include <ccMapTable.h>
#include <shcseg.h>
#include <shc.h>
#include <ist_seg_name.h>
#include <ist_seg_id.h>
#include <ist_seg_elf_id_map.h>
#include <ShcmsgHeader.h>

#include <HaPtmCctHelper.h>
#include <istsafe.h>

int ShcSenderDetails::nameLen = 30;
int ShcSenderDetails::lastnameLen = 30;
int ShcSenderDetails::cityLen = 20;
int ShcSenderDetails::stateLen = 2;
int ShcSenderDetails::countryLen = 2;
int ShcSenderDetails::address1Len = 30;
int ShcSenderDetails::address2Len = 28;
int ShcSenderDetails::postalLen = 10;
int ShcSenderDetails::initialized = 0;
unsigned short ShcSenderDetails::mySegmentId = 0;

const char *ShcSenderDetails::getName()
{
	return (const char *)SHC_ShcSenderDetails;
}


ShcSenderDetails::ShcSenderDetails()
{
	if (!initialized)
		initialize();
		
	resetData();
	
	memset(name, ' ', nameLen);
	name[nameLen] = '\0';
	memset(lastname, ' ',lastnameLen);
	lastname[lastnameLen] = '\0';
	memset(city, ' ', cityLen);
	city[cityLen] = '\0';
	if (stateLen > 0)
	{
		memset(state, ' ', stateLen);
		state[stateLen] = '\0';
	}
	else
		state[0]='\0';
}

void ShcSenderDetails::loadSenderDetails(char *senderdetails)
{
        char buf[100]={0};
        char *p = buf;
	strncpy( buf, senderdetails, sizeof(buf)-1 );

	if (!initialized)
		initialize();

        resetData();

        p[40] = '\0';
        for (register int i=0; i<40;i++)
                if (!p[i])
                        p[i]= ' ';

        if (nameLen>0)
        {
                memcpy(name, p, nameLen);
                name[nameLen] = '\0';
                p += nameLen;
                setNameSeg( name );
        }

        if (cityLen>0)
        {
                memcpy(city, p, cityLen);
                city[cityLen] = '\0';
                p += cityLen;
                setCitySeg( city );
        }

        if (stateLen>0)
        {
                memcpy(state, p, stateLen);
                state[stateLen] = '\0';
                p += stateLen;
                setStateSeg( state );
        }
        else
                state[0] = '\0';

        if (countryLen==2)
        {
                memcpy(CountryCode, p, 2);
                CountryCode[2] = '\0';
                p += countryLen;
                setCountrySeg( CountryCode );
        }

}

void ShcSenderDetails::initialize(void)
{
	char buf[200];
	int tmpNameLen, tmpCityLen, tmpStateLen, tmpCountryLen, sum; 

	HaPtmCctHelper::addHandler( "system.dcs.shc" ) ;

	if (cf_open(u_constructfile("files/shc.cfg")) >= 0)
	{
		if ( cf_locate("shc.sender_details_name_length",buf) > 0)
			tmpNameLen = atoi(buf);
		else
			tmpNameLen = nameLen;

		if ( cf_locate("shc.sender_details_city_length",buf) > 0)
			tmpCityLen = atoi(buf);
		else
			tmpCityLen = cityLen;

		if ( cf_locate("shc.sender_details_state_length",buf) > 0)
			tmpStateLen = atoi(buf);
		else
			tmpStateLen = stateLen;

		if ( cf_locate("shc.sender_details_country_length",buf) > 0)
			tmpCountryLen = atoi(buf);
		else
			tmpCountryLen = countryLen;

		sum = tmpNameLen+tmpCityLen+tmpStateLen+tmpCountryLen; 

		if ((sum != 54) || (tmpNameLen >30) || (tmpCityLen > 20) || (tmpStateLen > 2) || (tmpCountryLen > 2))
		{
			OTraceError("E-SHC-020001:Lengthes of sender details fields[%d %d %d %d] not valid. Default value [%d %d %d %d] is used.",
				tmpNameLen, tmpCityLen, tmpStateLen, tmpCountryLen, nameLen, cityLen, stateLen, countryLen);
		}
		else
		{
			nameLen = tmpNameLen;
			cityLen = tmpCityLen;
			stateLen = tmpStateLen; 
			countryLen = tmpCountryLen;
		}
			
		cf_close();
	}
	
	setLayoutDef( "SHC", nameLen, cityLen, stateLen, countryLen);
	
	mySegmentId = ElfIdMap::elf_to_id(IST_SEG_NETWORK_SETTLEMENT_DATA);

	OTraceDebug("D-SHC-020002:sender details len:name:(%d),city(%d),state(%d), countrycode(%d).\n",
              nameLen, cityLen, stateLen, countryLen);
	initialized = 1;
}

static int shcfmt_btoaflds[4];

int * ShcSenderDetails::getSenderDetailsFieldsLength()
{
	shcfmt_btoaflds[0] = nameLen;
	shcfmt_btoaflds[1] = cityLen;
	shcfmt_btoaflds[2] = stateLen;
	shcfmt_btoaflds[3] = countryLen;
	
    return shcfmt_btoaflds;
}

void ShcSenderDetails::getSenderDetails(char * senderdetailsBuf)
{
	char tempSenderDetailsBuf[SHC_SENDER_LEN];// length of senderdetails[] defined in shcimf.h
	int len = 0;

	istsafe_strcpy(senderdetailsBuf, sizeof(tempSenderDetailsBuf),name);
	len = istsafe_strlen(senderdetailsBuf, sizeof(tempSenderDetailsBuf));

	istsafe_strcat(senderdetailsBuf,sizeof(tempSenderDetailsBuf), city);
        len = istsafe_strlen(senderdetailsBuf, sizeof(tempSenderDetailsBuf));

	if (stateLen > 0)
	{	
		istsafe_strcat(senderdetailsBuf,sizeof(tempSenderDetailsBuf), state);
	}
	return;
}


void ShcSenderDetails::setLastName(const char *newLastName)
{
	int len;
	
	setLastNameSeg( newLastName );
	
	memset(lastname, ' ', lastnameLen);
	if (strlen(newLastName)>lastnameLen)
		len=lastnameLen;
	else
		len=strlen(newLastName);
	memcpy(lastname, newLastName, len);
	lastname[lastnameLen] = '\0';
	return;
}

void ShcSenderDetails::setPhoneType(const char *phonetypeBuf)
{
	setPhoneTypeSeg( phonetypeBuf );
	return;
}

////////////////////////////////////////////////////////////////////////////////
// Enhance to support segment BILL_TO_ADDRESS
////////////////////////////////////////////////////////////////////////////////


void ShcSenderDetails::resetData()
{
	memset( nameSeg,    0, sizeof(nameSeg) );
	memset( lastnameSeg,    0, sizeof(lastnameSeg) );
	memset( citySeg,    0, sizeof(citySeg) );
	memset( stateSeg,   0, sizeof(stateSeg) );
	memset( countrySeg, 0, sizeof(countrySeg) );
	memset( postalSeg,  0, sizeof(postalSeg) );
	memset( phoneSeg,   0, sizeof(phoneSeg) );
	memset( addressSeg, 0, sizeof(addressSeg) );
	
	memset( segBuffer, 0, sizeof(segBuffer) );
	memset( outputBuffer, 0, sizeof(outputBuffer) );
	memset( (char*)&acceptorLayout, 0, sizeof(ACCEPTORNAME_LAYOUT) );

	return;
}
	
char *ShcSenderDetails::getSenderDetailsFromSegment( const char *segData, int segLen, const char *network )
{
	if ( parseSegSenderDetails(segData, segLen) < 0 )
	{
		strcpy( outputBuffer, "Unable to parse SenderDetails from segmnt" );
		return outputBuffer;
	}
	
	return outputSenderDetails( network );
}
	

int ShcSenderDetails::parseSegSenderDetails( const char *segDataIn, int segLen )
{
	char segData[sizeof(segBuffer)]={0};
	segLen = segLen<sizeof(segBuffer) ? segLen : sizeof(segBuffer);
	memcpy( segData, segDataIn, segLen );
	
	const char *ptr = segData;
	
	resetData();
	
	if ( segLen <= OFST_COUNTRY )
	{
		OTraceError( "E-SHC-020003: Length of segment SenderDetails is too short[%d]<[%d]\n", segLen, OFST_COUNTRY );
		return -1;
	}
	
	if ( segLen > LEN_SEG_MAX )
	{
		OTraceWarning( "W-SHC-020004: Length of segment ACEEPTOR_NAME is too long[%d]>[%d]\n", segLen, LEN_SEG_MAX );
		segLen = LEN_SEG_MAX;
	}
	
	memcpy( segBuffer, segData, segLen );

	if ( segLen > OFST_PHONETYPE )
	{
		memcpy( phonetypeSeg, ptr, LEN_PHONETYPE);
		ptr += LEN_PHONETYPE;
	}

        if ( segLen > OFST_PHONE )
        {
                memcpy( phoneSeg, ptr, LEN_PHONE );
                ptr += LEN_PHONE;
        }
	
	if ( segLen > OFST_NAME )
	{
		memcpy( nameSeg, ptr, LEN_NAME );
		ptr += LEN_NAME;
	}

	if ( segLen > OFST_LASTNAME )
	{
		memcpy( lastnameSeg, ptr, LEN_LASTNAME );
		ptr += LEN_LASTNAME;
	}

        if ( segLen > OFST_ADDRESS1 )
        {
                memcpy( address1Seg, ptr, LEN_ADDRESS1 );
                ptr += LEN_ADDRESS1;
        }

        if ( segLen > OFST_ADDRESS2 )
        {
                memcpy( address2Seg, ptr, LEN_ADDRESS2 );
                ptr += LEN_ADDRESS2;
        }

	if ( segLen > OFST_COUNTRY )
	{
		memcpy( countrySeg, ptr, LEN_COUNTRY );
		ptr += LEN_COUNTRY;
	}

	if ( segLen > OFST_CITY )
	{
		memcpy( citySeg, ptr, LEN_CITY );
		ptr += LEN_CITY;
	}

	if( segLen > OFST_STATE )
	{
		memcpy( stateSeg, ptr, LEN_STATE );
		ptr += LEN_STATE;
	}

	if ( segLen > OFST_POSTAL )
	{
		memcpy( postalSeg, ptr, LEN_POSTAL );
		ptr += LEN_POSTAL;
	}
}


char *ShcSenderDetails::outputSenderDetails( const char *network )
{
	if ( ! isDataReady() )
	{
		OTraceError("E-SHC-020005: data not ready yet in getSenderDetails(%s)\n", network);
		sprintf( outputBuffer, "%.4s data not ready yet                 ", network );
		return outputBuffer;
	}
	
	ACCEPTORNAME_LAYOUT *myLayout = getLayoutDef( network );
	memset( outputBuffer, 0, sizeof(outputBuffer) );
	char *ptr=outputBuffer;
	
	ptr += formatIt( ptr, nameSeg, myLayout->lenName );
	ptr += formatIt( ptr, citySeg, myLayout->lenCity );
	ptr += formatIt( ptr, stateSeg, myLayout->lenState );
	ptr += formatIt( ptr, countrySeg, myLayout->lenCountry%10 );
	
	const char *pCC = NULL;
	if ( myLayout->lenCountry == 2 )
	{
		pCC = getCountryChar2();
	}
	else if ( myLayout->lenCountry == 3 )
	{
		pCC = getCountryChar3();
	}
	else if ( myLayout->lenCountry == 13 )	// 3 char in digits
	{
		pCC = getCountryChar3Digits();
	}
	
	if ( ! pCC )
	{
		
		ptr += formatIt( ptr, (char*)pCC, myLayout->lenCountry%10 );
	}
	
	*ptr = '\0';
	
	OTraceError( "D-SHC-020006: Sender Details for [%s]='%s'\n", network, outputBuffer );
	
	return outputBuffer;
}


char *ShcSenderDetails::generateSegmentData(const char *aName, const char *aCity, const char *aState, const char *aCountry)
{
	setSenderDetails( aName, aCity, aState, aCountry );
//	OTraceDebug( "[%s\\%s\\%s\\%s]\n", nameSeg, citySeg, stateSeg, countrySeg );

	return generateSegmentData();
}


char *ShcSenderDetails::generateSegmentData()
{
	char *ptr = segBuffer;
	memset( segBuffer, 0, sizeof(segBuffer) );
	
	if ( ! isDataReady() )
	{
		return segBuffer;
	}
		
	ptr += snprintf( ptr, sizeof(segBuffer), "%-40s%-20s%-20s%-3s", nameSeg, citySeg, stateSeg, countrySeg );
	
	if ( strlen(addressSeg) > 0 )
	{
		ptr += formatIt( ptr, addressSeg, LEN_ADDRESS );
		OTraceDebug("D-SHC-020008: found address data[%s]\n", (ptr-LEN_ADDRESS) );
	}
	if ( strlen(postalSeg) > 0 )
	{
	ptr += formatIt( ptr, postalSeg,  LEN_POSTAL );
		OTraceDebug("D-SHC-020009: found postal data[%s]\n", (ptr-LEN_POSTAL) );
	}
	if ( strlen(phoneSeg) > 0 )
	{
	ptr += formatIt( ptr, phoneSeg,   LEN_PHONE );
		OTraceDebug("D-SHC-020010: found phone data[%s]\n", (ptr-LEN_PHONE) );
	}

	*ptr = '\0';
	
	OTraceDebug("D-SHC-020011: generateSegmentData()=[%d][%s]\n", strlen(segBuffer), segBuffer );
	
	return segBuffer;
}


void ShcSenderDetails::setSenderDetails(const char *aName, const char *aCity, const char *aState, const char *aCountry)
{
	setName( aName );
	setCityName( aCity );
	setStateName( aState );
	setCountryCode( aCountry );
	return;
}

char *ShcSenderDetails::getAddress1Seg()
{
        strtrim(address1Seg, address1Seg);
        return address1Seg;
}

char *ShcSenderDetails::getAddress2Seg()
{
        strtrim(address2Seg, address2Seg);
        return address2Seg;
}

int ShcSenderDetails::saveSegment( ShcmsgHeader *hdr )
{
	if ( ! isDataReady() )
	{
		OTraceError("E-SHC-: Sender Details segment data not ready\n");
		return -1;
	}
	
	char *segData = generateSegmentData();
	
// append segment here !!!

	hdr->setSegmentData(segData, strlen(segData)+1, mySegmentId, SENDER_DETAILS);

	OTraceDebug( "D-SHC-: saveSegment segid[%d] subid[%d] '%s'\n", mySegmentId, SENDER_DETAILS, segData );

	return 0;
}


int ShcSenderDetails::loadSegment( ShcmsgHeader *hdr )
{
	int  segLen=sizeof(segBuffer);
// get SENDER_DETAILS segment data here !!!
	hdr->getSegmentData(segBuffer, &segLen, mySegmentId, SENDER_DETAILS);
	OTraceDebug( "D-SHC-: loadSegment segid[%d] subid[%d] [%d]'%s'\n", mySegmentId, SENDER_DETAILS, segLen, segBuffer );
	
// found segment 
	if ( segLen > 0 )
	{
		return parseSegSenderDetails( segBuffer, segLen );
	}
	else
		OTraceDebug( "D-SHC-: Sender Details segment data not available \n");	
	
	return 0;
}

