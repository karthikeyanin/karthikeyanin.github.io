static char _ShcBalancer_cxx_what[] = "@(#) ShcBalancer.cxx 1.5 07/05/25 12:22:48";

/*
 *  Copyright (C) 2004 eFunds Corporation ("eFunds").  All Rights Reserved.     
 *  eFunds Canada Corporation is an authorized user.                            
 *                                                                              
 *  IST is a registered trademark of eFunds Corporation.  Other brand or        
 *  product names are trademarks or registered trademarks of their respective   
 *  holders.                                                                    
 *                                                                              
 *  The information contained herein is the unpublished proprietary property    
 *  of eFunds.  Except as specifically authorized in writing by eFunds, the     
 *  holder of this document shall: i) keep all information contained herein     
 *  confidential, and ii) protect the information, in whole or in part, from    
 *  disclosure and dissemination to all third parties.                          
 *                                                                          
 *  This document and the software described in it are furnished under license  
 *  and may be used or copied only in accordance with the terms of such license.
 *  This document is supplied for information purposes only, is subject to      
 *  change without notice, and should not be construed as a commitment by       
 *  either eFunds Corporation or eFunds Canada Corporation. 
 *
 *
 *                        MODIFICATION HISTORY                  REVIEW
 *
 *	SPR#	Who	Date	Description			Who	Date   
 * ===========================================================================
 *R00xxxx 20Oct03 ztang Creation
 *R016305 Emj 20Apr06 Log actual response code in security log
 *R016309 Emj 21Apr06 Updated acquirer counter functions to use acquirer bin
 *R016750 Emj 28Jun06 Fixed syslg message in shc_inc_pinerrcnt_x()
 */
/* File Number 153 */

#include <stdio.h>
#include <string.h>
#include <sys/timeb.h>
#include <ctype.h>
#include <oasis.h>
#include <oasisenv.h>
#include <security.h>
#include <ist_otrace.h>
#include <shc.h>
#include <isttrigger.h>
#include <ic/ic_bin.h>
#include <ShcBalancer.h>
#include <shcfmt.h>
#include <ShcHelperBase.h>
#include <ShcBin.h>
#include <ShcAppBase.h>

static ShcBin *shcBin = NULL;

/*------------------------------------------------------------------------*
 * Utility Function Block  
 *------------------------------------------------------------------------*/
const char *ShcBalancer::getName()
{
    return (const char *)SHC_Balancer;
}

ShcBalancer::ShcBalancer()
{
	pkgs = NULL;
	num = 0;
}

int ShcBalancer::chooseBin(struct shcpkg **bins, int n)
{
	
	
	if (copyPkgs(bins, n)<0)
		return NULL;
	
	return choosePkg();
}
int ShcBalancer::fit(int n)
{
	if (num < n)
	{
		if (num)
			free(pkgs);
		pkgs = (struct shcpkg **)calloc(sizeof(struct shcpkg *), n);
		if (!pkgs)
		{
			OTraceError("E-SHC-15301:Can't allocate in ShcBalancer. Balancing not doen.\n");
			num = 0;
			pkgs = NULL;
			return -1;
		}
		else
			num = n;
	}
	return 0;
}

int ShcBalancer::copyPkgs(struct shcpkg **bins, int n)
{

	if (fit(n)<0)
		return -1;
		
	
	//Find all the bin package
	int bini;
	for (bini=0;bini<n;bini++)
	{
		pkgs[bini] = bins[bini];
	}
	pkgi = n;
	return 0;
}

int ShcBalancer::chooseBin(char **bins, int n)
{
	if (findPkgs(bins, n)<0)
		return NULL;
	
	return choosePkg();
}

int ShcBalancer::findPkgs(char **bins, int n)
{
	if (!shcBin)
		shcBin = (ShcBin *)shcHelperRegister.getTargetObj(SHC_ShcBin);
		
	if (!shcBin)
	{
		OTraceError("E-SHC-15302:Can't create ShcBin object\n");
		return NULL;
	}
	
	if (fit(n)<0)
		return -1;
	
	//Find all the bin package
	int bini;
	for (bini=0, pkgi=0;bini<n;bini++)
	{
		if ( shcBin->shc_locate_bin(&pkgs[pkgi], bins[bini]) < 0)
		{
			OTraceError("E-SHC-15303:Can't find bin:[%s], no balancing for it\n");
			pkgs[pkgi] = NULL;
		}
		pkgi++;
	}
	return 0;
}

int ShcBalancer::choosePkg()
{
	//Check the balance info
	int i;
	struct s_RoundRobinBalInfo *info;
	long oldest = -1;
	long oldestCount = 0;
	int binToUse;
    struct timeb tmpTime;
    ftime(&tmpTime);
	long lastTime = tmpTime.time;
	for (i=0;i<pkgi;i++)
	{
		if (!pkgs[i])
			continue;
			
		info = (struct s_RoundRobinBalInfo *)pkgs[i]->balInfo;
		if (oldest < 0)
		{
			binToUse = i;
			oldest = info->lastTime;
			oldestCount = info->count;
		}
		else if (	(oldest > info->lastTime) ||
					((oldest = info->lastTime) && (oldestCount > info->count))
				)
		{
			binToUse = i;
			oldest = info->lastTime;
			oldestCount = info->count;
		}
		else if (info->lastTime > lastTime)
		{
			//time is in future, this is not correct
			OTraceWarning("W-SHC-15305:bin[%s]has balance time[%ld], current[%ld]\n", pkgs[i]->bin.userbinid, info->lastTime, lastTime);
			info->lastTime = lastTime;
		}
	}
	
	if (oldest < 0)	//Should not happen
		return -1;				
	info = (struct s_RoundRobinBalInfo *)pkgs[binToUse]->balInfo;

	if (info->lastTime != lastTime)
	{
		info->lastTime = lastTime;
		info->count = 1;
	}
	else
	{
		++info->count;
	}

	return binToUse;
}

int ShcBalancer::toString(struct shcpkg *pkg, char *buf, int size)
{
	if (size < 60)
	{
		OTraceError("E-SHC-15304:buf size[%d] too small to hold balance info\n");
		return -1;
	}
	struct s_RoundRobinBalInfo *info;
	info = (struct s_RoundRobinBalInfo *)pkg->balInfo;
	sprintf(buf,"Round Robin Balancer, time last used %ld\n", info->lastTime); 
	return 0;
}



















