//
// Copyright (C) 2009 eFunds Corporation ("eFunds").  All Rights Reserved.
// eFunds Canada Corporation is an authorized user.
//
// IST is a registered trademark of eFunds Corporation.  Other brand or
// product names are trademarks or registered trademarks of their respective
// holders.
//
// The information contained herein is the unpublished proprietary property
// of eFunds.  Except as specifically authorized in writing by eFunds, the
// holder of this document shall: i) keep all information contained herein
// confidential, and ii) protect the information, in whole or in part, from
// disclosure and dissemination to all third parties.
//
// This document and the software described in it are furnished under license
// and may be used or copied only in accordance with the terms of such license.
// This document is supplied for information purposes only, is subject to
// change without notice, and should not be construed as a commitment by
// either eFunds Corporation or eFunds Canada Corporation.
//
/*
 * Description:
 *
 *      MODIFICATION HISTORY
 *
 *  Date         SCR            Who        Description
 *  ===========================================================================
*/
static const char _ShcNegativeAuth_cxx_what[] = "@(#) ShcNegativeAuth.cxx 1.8 17/10/25 04:58:54";
#include <auto_ptr.h>
#include <dbm.h>
#include <dbm_private.h>
#include <ShcNegativeAuth.h>
#include <ExceptionObject.h>
#include <MRApplHelper.h>
#include <MRShcNegAuthTagDefs.h>
//#include <ShcApp.h> 
//#include <ShcFinAuthHelper.h>

int ShcNegativeAuth::getCount(char * pan)
{
	//No one call this yet, so just return 0
	return 0;
}

ShcNegativeAuth *ShcNegativeAuth::getInstance()
{
 	static ShcNegativeAuth *_instance=NULL;
	if ( !_instance )
	{
		_instance = (ShcNegativeAuth *)shcHelperRegister.getTargetObj("ShcNegativeAuth");
		if ( !_instance )
		_instance = new ShcNegativeAuth();
	}
	return _instance;
}

ShcNegativeAuth::ShcNegativeAuth()
{
        _smtSelOne = NULL;
        _updateTbl = NULL;
        _smtInsert = NULL;
        stmt = NULL;
        _dbConn = NULL;
}
void ShcNegativeAuth::recycle()
{
        memset(_pan,0x00,sizeof(_pan));
        memset(&_safamt,0,sizeof(amount_t));
		updateddate.setValue(0);
		d_site_id.setValue(0);
        _safno=0;
        _site_id=0;
        _safdat=0;
}
void ShcNegativeAuth::dbInit()
{
        if( _dbConn != NULL )
			return;
        _dbConn = new DBMConn(dbm_dbconn);
}

int ShcNegativeAuth::resetLimit(ShcmsgHeader *header,long safdate)
{
	/*
	 *	Reset the store and forward limits on a card
	 *	Assume that the card has already been read into memory
	 */
	struct	tm *tm, newtime;
	long    rt, lrt;
	time_t  tmp_safdate;
	int refresh = 0;

	MRApplHelper *mrHelper =  MRApplHelper::getInstance(IST_MR_SERVICE_NAME_NEGAUTH);

	/*
	 *	Get the current time, reset time and last reset time 
	 */
	tm = localtime((time_t *)&shc_current_time);
	memcpy(&newtime, tm, sizeof(newtime));
	newtime.tm_hour = header->issShcBin->binPkg->saf.refreshtime / 100;
	newtime.tm_min  = header->issShcBin->binPkg->saf.refreshtime % 100;
	rt = mktime(&newtime);

	tmp_safdate=safdate;
	
	tm = localtime((time_t *)&tmp_safdate);
	memcpy(&newtime, tm, sizeof(newtime));
	lrt = mktime(&newtime);
	
	OTraceDebug("D-SHCNEGAUTH-05001:Current Time %s\n", ctime((time_t *)&shc_current_time));
	OTraceDebug("D-SHCNEGAUTH-05002:Reset Time   %s\n", ctime((time_t *)&rt));
	OTraceDebug("D-SHCNEGAUTH-05003:Last Reset   %s\n", ctime((time_t *)&lrt));

	/*
	 *	Determine if we have reached the time limit
	 */
	if((shc_current_time / 100 >= rt/100) && (lrt/100 < rt/100))
	{
		/*	
		 * Time to rest limits
		 */
		OTraceDebug("D-SHCNEGAUTH-05004:Reset limits on card [%s]\n", 
		shcApp->shcHelperObj->shc_maskpan(header->msg.pan));		//	---	R021024
		_safno = 0;
		dbm_dbltodec(&_safamt, (double)0);
		refresh = 1;
		_safdat = shc_current_time;
		
	}
	mrHelper->setData(TAG_REFRESH, refresh);
	
	return(0);
}

int ShcNegativeAuth :: reverseLimit(ShcmsgHeader *header)
{
/*
	 *	o	Find original card record
	 */
	int rc =getData(header);
	if(rc < 0)
		return(-1);
        if(rc==0)
		return 0;
	/*
	 *	o	subtract amount from card history
	 */	 

	MRApplHelper *mrHelper =  MRApplHelper::getInstance(IST_MR_SERVICE_NAME_NEGAUTH);

	memset (&negauth, 0, sizeof (struct NegAuth));
	int revflag = 1;

	OTraceDebug("D-SHCNEGAUTH-05005: site_id:%ld _safdate:%ld safnum:%ld \n",_site_id,_safdat,_safno);	
	
	negauth.saf_num=_safno;
	negauth.saf_amount=_safamt;	
	
	memset(buf1,0x00,sizeof(buf1));
	dbm_dectochar(&negauth.saf_amount, buf1);
	OTraceDebug("D-SHCNEGAUTH-05006: Saf_amount:%12s safnum:%ld\n", buf1,negauth.saf_num);

	if(negauth.saf_num > 0)
		negauth.saf_num--;
	else
		negauth.saf_num = 0;

	if(dbm_deccmp(&negauth.saf_amount, &header->msg.amount) < 0)
		dbm_dbltodec(&negauth.saf_amount, (double)0);

			/* R008248 >> check for partial reversals */
	else if( header->msg.respcode == SHC_RC_PartialDispense
			|| header->msg.revcode == SHC_RR_PartialDispense
			|| dbm_decncmp(&header->msg.new_amount, (double)0) != 0
			)
	{
		amount_t amount;
		char     xBuf[50];
		revflag = 2;	
		negauth.saf_num++;
		dbm_decminus(&amount, &header->msg.amount, &header->msg.new_amount);
		dbm_decsub(&negauth.saf_amount, &amount, &negauth.saf_amount);

		if(ist_otrace_get_level() >= OTRACE_DEBUG)
		{
			dbm_dectochar(&amount, xBuf);
			OTraceDebug("D-SHCNEGAUTH-05007:  Update card limits from partial reversal\n");
			OTraceDebug("D-SHCNEGAUTH-05008:  reversal amount: %12s\n", xBuf);
		}
	}
			/* R008248 << */
	else
		dbm_decsub(&negauth.saf_amount, &header->msg.amount, &negauth.saf_amount);

	memset(buf1,0x00,sizeof(buf1));
	dbm_dectochar(&negauth.saf_amount, buf1);
	OTraceDebug("D-SHCNEGAUTH-05009: Saf_amount:%12s Saf_num:%ld\n", buf1,negauth.saf_num);
	/*
	 *	o	write out the card record
	 */
	mrHelper->setData(TAG_REVERSAL, revflag);
	updateLimit(header,&negauth);

	return(0);
}
int ShcNegativeAuth :: insertCardData(ShcmsgHeader *header)
{
	 OTraceDebug("D-SHCNEGAUTH-05010: record not found\n");

	 MRApplHelper *mrHelper =  MRApplHelper::getInstance(IST_MR_SERVICE_NAME_NEGAUTH);

	 try
	 {
		     int rc=prepareInsertOne();
		     if(rc<0)
		     {
			     OTraceDebug( "D-SHCNEGAUTH-05011: Cannot insert ShcNegativeAuth\n" );
			     return ( -1 );
		     }			     
		    
		     recycle();

		     memcpy(_pan,header->msg.pan,sizeof(_pan));
		     shc_normalizepan(_pan);
		     _site_id=header->getMsgSiteId();

		     dbm_deccopy(&(_safamt),&header->msg.amount);
		     updateddate.setValue(current);
		     _safdat=shc_current_time;
		     _safno=1;
		     d_site_id.setValue(_site_id);

			

		     OTraceDebug("D-SHCNEGAUTH-05012: Insert new Record\n");
			 OTraceDebug("D-SHCNEGAUTH-05013: Pan :%s Site_id:%d Safdate:%ld \n",shcApp->shcHelperObj->shc_maskpan(_pan),_site_id,shc_current_time);

			 memset(buf1,0x00,sizeof(buf1));
			 dbm_dectochar(&_safamt,buf1);
			 OTraceDebug("D-SHCNEGAUTH-05014: Saf_amount:%12s current date is %s \n", buf1,(char *)(current).asString());

			 rc=_smtInsert->execute();
		    _smtInsert->close();
		     if(rc!=DBM_SUCCESS)
		     {
				OTraceDebug( "D-SHCNEGAUTH-05015: Cannot insert ShcNegativeAuth\n" );
				return ( -1 );
		     }
		     mrHelper->setReplicateOn(INSERT_SHCNEGATIVEAUTH);
		     mrHelper->setData(TAG_SAF_NUM, 1);
		     mrHelper->setData(TAG_NEGAUTH_PAN, _pan);
		     mrHelper->setData(TAG_SAF_DATE, shc_current_time);
		     mrHelper->setData(TAG_NEGAUTH_SITE_ID, _site_id);
		     mrHelper->setData(TAG_SAF_AMOUNT, &header->msg.amount);
						

		}
	    catch (const DBMException& e)
		{
				OTraceError
				(
						"E-SHCNEGAUTH-05016: Caught exception during Insertion,"
						"native error=%d, sqlstate=%.5s, msg=%s\n",
						e.getNativeError(), e.getSQLState().data(), e.getErrMsg().data()
				);
				_smtInsert->close();
				return ( -2 );
		}
	    return 1;
}
		
int ShcNegativeAuth :: checkLimit(ShcmsgHeader *header,NegAuth *_negauth)
{
	int rc=getData(header);
	if(rc<0)
		return(-1);

		
	OTraceDebug("D-SHCNEGAUTH-05017: Safdate:%ld Safnum:%ld before reset reset call\n",_safdat,_safno);
	/*
	*	o	Reset all limits
	*/
	if(rc!=0)
		resetLimit(header,_safdat);


	_negauth->saf_num=_safno;
	_negauth->saf_amount=_safamt;	
	memset(buf1,0x00,sizeof(buf1));
	dbm_dectochar(&_negauth->saf_amount,buf1);
	OTraceDebug("D-SHCNEGAUTH-05018: Saf_amount:%12s Safnum :%ld SafDate:%ld after reset limit\n", buf1,_negauth->saf_num,_safdat);
		

	/*
	 *	o	Determine if over limits
	 *	26Nov92	ss
	 *		Skip Check if Advice Message.
	 */
	if(_negauth->saf_num + 1 > header->issShcBin->binPkg->saf.num && !shcIsAdvice(header))
	{
		header->msg.respcode = SHC_RC_ExceedsFreqLimit;
		OTraceError("E-SHCNEGAUTH-05020: Denied: SAF Frequence Limits exceeded.\n");
	}

	else if(dbm_decaddcmp(&header->issShcBin->binPkg->saf.amount,
			&header->msg.amount, &_negauth->saf_amount) < 0 &&
			!shcIsAdvice(header))
	{
		header->msg.respcode = SHC_RC_ExceedsLimit;
		OTraceError("E-SHCNEGAUTH-05021: Denied: Negative SAF Limits exceeded.\n");
	}
	else
	{
		/*
		 * Approved
		 */
		OTraceInfo("I-SHCNEGAUTH-05022: Approved by SHC Negative Auth\n");
		header->msg.respcode = SHC_RC_Approved;
	}

	return 0;
}



int ShcNegativeAuth :: prepareSelectOne()
{
	
        try
        {
			int sno = 1;
			int cnt = 0;
			memset( _ind, 0, sizeof(_ind) );

			if(!_smtSelOne)
			{
				_smtSelOne = _dbConn->getStmt();
					
				_smtSelOne->prepare
				( 	
					"select safdate,safnum,safamount,updated "
					"from shcnegativeauth "
					"where pan= ? and site_id =? "
				);

				_smtSelOne->bindCol(  sno++, DBM_LONGTYPE, &_safdat, sizeof(_safdat), &_ind[cnt++] );
				_smtSelOne->bindCol(  sno++, DBM_LONGTYPE, &_safno, sizeof(_safno), &_ind[cnt++] );
				_smtSelOne->bindCol(  sno++, DBM_DECIMALTYPE, &_safamt, sizeof(_safamt), &_ind[cnt++] );
				_smtSelOne->bindCol(  sno++, DBM_DATETIMETYPE, &_updated, sizeof(_updated), &_ind[cnt++] );
				_smtSelOne->bindParam( 1, DBM_PANTOKENTYPE, _pan,sizeof(_pan), NULL );
				_smtSelOne->bindParam( 2, d_site_id );

			}
        }
        catch (const DBMException& e)
        {
                OTraceError
                (
                        "E-SHCNEGAUTH-05023: Caught exception during Selection,"
                        "native error=%d, sqlstate=%.5s, msg=%s\n",
                        e.getNativeError(), e.getSQLState().data(), e.getErrMsg().data()
                );
				_smtSelOne->close();
                return ( -2 );
        }
        return 0;
}

int ShcNegativeAuth :: prepareInsertOne()
{
	if(!_smtInsert)
 	{


		try
		{
			int sno = 1;

			_smtInsert = _dbConn->getStmt();

			 _smtInsert->prepare ("insert into shcnegativeauth ("
                                                             "site_id ,"
                                                             "safdate ,"
                                                             "safnum ,"
                                                             "updated ,"
                                                             "pan ,"
															 "safamount"
                                                             ")values"
                                                             "(?,?,?,?,?,?)");

			_smtInsert->bindParam(  sno++, d_site_id );
		   	_smtInsert->bindParam(  sno++, DBM_LONGTYPE, &(_safdat), sizeof(_safdat), NULL );
			_smtInsert->bindParam(  sno++, DBM_LONGTYPE, &(_safno), sizeof(_safno), NULL );
			_smtInsert->bindParam(  sno++, updateddate );
			_smtInsert->bindParam(  sno++, DBM_PANTOKENTYPE, (_pan), sizeof(_pan), NULL );
			_smtInsert->bindParam(  sno++, DBM_DECIMALTYPE, &(_safamt), sizeof(_safamt), NULL );
		}
				
		catch (const DBMException& e)
		{
			OTraceError
			(
				"E-NEGAUTH-05025: caught exception during insert,"
				"native error=%d, sqlstate=%.5s, msg=%s\n",
				e.getNativeError(), e.getSQLState().data(), e.getErrMsg().data()
			);
			_smtInsert->close();
			return ( -2 );
		}
	}	
	return 0;	
}
int ShcNegativeAuth::updateLimit(ShcmsgHeader *header,NegAuth *neg_auth)
{
	
	recycle();
	int countUpdated = 0;
	
	MRApplHelper *mrHelper = MRApplHelper::getInstance(IST_MR_SERVICE_NAME_NEGAUTH);

	try
	{
		int rc=prepareUpdateOne();
		if(rc!=0)
	    {
		       OTraceError("E-SHCNEGAUTH-05031:Error while updating \n");
		       return -1;
	    }
	    else
	    {

			OTraceDebug("D-SHCNEGAUTH-05026: Update ShcNegativeAuth \n");

			_safno=neg_auth->saf_num;
			dbm_deccopy(&_safamt,&neg_auth->saf_amount);

			memset(buf1,0x00,sizeof(buf1));
			dbm_dectochar(&_safamt, buf1);

			_safdat=shc_current_time;
			memcpy(_pan,header->msg.pan,sizeof(_pan));
			shc_normalizepan(_pan);
			current.now();
			updateddate.setValue(current);
			_site_id=header->getMsgSiteId();
			d_site_id.setValue(_site_id);


			 OTraceDebug( "D-SHCNEGAUTH-05027:pan :%s site_id :%d _safdate:%ld current:%s _safamt :%s saf num %d\n", shcApp->shcHelperObj->shc_maskpan(_pan),_site_id,_safdat,(char *)(current).asString(),buf1,_safno);

			 int rc=_updateTbl->execute();
			 _updateTbl->getRowCount(&countUpdated);
			_updateTbl->close();

			if(rc != DBM_SUCCESS)
			{

				OTraceDebug( "D-SHCNEGAUTH-05027: Cannot update ShcDuplicateChk\n" );
				return ( -1 );
			}
			if(countUpdated==0)
				insertCardData(header);
			else
			{
				mrHelper->setReplicateOn(UPDATE_SHCNEGATIVEAUTH);
				mrHelper->setData(TAG_NEGAUTH_PAN, _pan);
				mrHelper->setData(TAG_SAF_DATE, shc_current_time);
				mrHelper->setData(TAG_NEGAUTH_SITE_ID, _site_id);

				if( header->msg.respcode == SHC_RC_PartialDispense
				|| header->msg.revcode == SHC_RR_PartialDispense
				|| dbm_decncmp(&header->msg.new_amount, (double)0) != 0)
				{
					amount_t amount;
					dbm_decminus(&amount, &header->msg.amount, &header->msg.new_amount);
					mrHelper->setData(TAG_SAF_AMOUNT, &amount);
				}		
				else
				{
					mrHelper->setData(TAG_SAF_AMOUNT, &header->msg.amount);
				}
			}
		}
	 }
	 catch (const DBMException& e)
	 {
			OTraceError
			(
					"E-SHCNEGAUTH-05028: caught exception during update,"
					"native error=%d, sqlstate=%.5s, msg=%s\n",
					e.getNativeError(), e.getSQLState().data(), e.getErrMsg().data()
			);
			_updateTbl->close();
			return ( -2 );
	 }
	 OTraceDebug( "D-SHCNEGAUTH-05029: Done updation\n");
	 return 1;
}
int ShcNegativeAuth :: getData(ShcmsgHeader *header)
{
		dbInit();

        OTraceDebug("D-SHCNEGAUTH-05030: Inside Check Limit\n");

        int rc=prepareSelectOne();

       if(rc!=0)
       {
               OTraceError("E-SHCNEGAUTH-05031:Error while Selecting \n");
               return -1;
       }
       else
       {
			try
            {
					recycle();
					memcpy(_pan,header->msg.pan,sizeof(_pan));
					shc_normalizepan(_pan);

					 _site_id=header->getMsgSiteId();
					 d_site_id.setValue(_site_id);

					_smtSelOne->execute();
					rc = _smtSelOne->fetch();
									
					_smtSelOne->close();

					if( rc == DBM_NO_DATA )
					{
						_safno = 0;
						dbm_dbltodec(&_safamt, (double)0);
						_safdat=0;
						return 0;
					}
					else if(rc!=DBM_SUCCESS)
					{
						 OTraceDebug( "D-SHCNEGAUTH-05034: Cannot Fetch from ShcNegativeauth\n" );
						 return ( -1 );
					}

			 }
			 catch (const DBMException& e)
			 {
					OTraceError
					(
						"E-SHCNEGAUTH-05035: caught exception during fetching,"
						"native error=%d, sqlstate=%.5s, msg=%s\n",
						e.getNativeError(), e.getSQLState().data(), e.getErrMsg().data()
					);
					_smtSelOne->close();
					return ( -2 );
			 }
	  }
	  return 1;
}
int ShcNegativeAuth :: prepareUpdateOne()
{
	int sno=1;
	if(!_updateTbl)
	{
		try
		{
		
			_updateTbl = _dbConn->getStmt();
			_updateTbl->prepare ("update shcnegativeauth set "
					     "safdate = ?,"
					     "safnum = ? ,"
					     "updated= ?, "
					     "safamount = ? "
					     "where pan=? and "
					     "site_id = ?");

			_updateTbl->bindParam(  sno++, DBM_LONGTYPE, &(_safdat), sizeof(_safdat), NULL);
			_updateTbl->bindParam(  sno++, DBM_LONGTYPE, &(_safno), sizeof(_safno), NULL );
			_updateTbl->bindParam(  sno++, updateddate );
			_updateTbl->bindParam(  sno++, DBM_DECIMALTYPE, &(_safamt), sizeof(_safamt), NULL );
			_updateTbl->bindParam(  sno++, DBM_PANTOKENTYPE, (_pan), sizeof(_pan), NULL );
			_updateTbl->bindParam(  sno++, d_site_id );
		
		}
		catch (const DBMException& e)
		{
			OTraceError
			(
				"E-SHCNEGAUTH-05036: caught exception during fetching,"
				"native error=%d, sqlstate=%.5s, msg=%s\n",
				e.getNativeError(), e.getSQLState().data(), e.getErrMsg().data()
			);
			_updateTbl->close();
			return ( -2 );
		}
	}
	return 0;
}

ShcNegativeAuth::~ShcNegativeAuth()
{
        if(_dbConn)
        delete _dbConn;

        if(_smtSelOne)
        delete  _smtSelOne;

        if(_updateTbl)
        delete _updateTbl;

		if(_smtInsert)
		delete _smtInsert;

		if(stmt)
        delete stmt;
}


