//
// Copyright (C) 2009 eFunds Corporation ("eFunds").  All Rights Reserved.
// eFunds Canada Corporation is an authorized user.
//
// IST is a registered trademark of eFunds Corporation.  Other brand or
// product names are trademarks or registered trademarks of their respective
// holders.
//
// The information contained herein is the unpublished proprietary property
// of eFunds.  Except as specifically authorized in writing by eFunds, the
// holder of this document shall: i) keep all information contained herein
// confidential, and ii) protect the information, in whole or in part, from
// disclosure and dissemination to all third parties.
//
// This document and the software described in it are furnished under license
// and may be used or copied only in accordance with the terms of such license.
// This document is supplied for information purposes only, is subject to
// change without notice, and should not be construed as a commitment by
// either eFunds Corporation or eFunds Canada Corporation.
//
/*
 * Description:
 *
 *      MODIFICATION HISTORY
 *
 *  Date         SCR            Who        Description
 *  ===========================================================================
*/

static const char _ShcDuplicateChk_cxx_what[] = "@(#)ShcDuplicateChk.cxx 1.4 14/08/19 10:03:42";
#include <auto_ptr.h>
#include <dbm.h>
#include <dbm_private.h>
#include <istsafe.h>

#include <ShcDuplicateChk.h> 
#include <shc.h>
#include <ExceptionObject.h>
ShcDuplicateChk::ShcDuplicateChk()
{
	_smtSelOne = NULL;
	_updateTbl = NULL;
	_smtUpdate = NULL;
	_smtInsert = NULL;
	_dbConn = NULL;
}
void ShcDuplicateChk::recycle()
{
	memset(lasttxntid,0x00,sizeof(lasttxntid));
	memset(lasttxnacq,0x00,sizeof(lasttxnacq));
	memset(lasttxnanum,0x00,sizeof(lasttxnanum));
	memset(pan,0x00,sizeof(pan));
	memset(&lasttxnamt,0,sizeof(amount_t));
	lasttxntime=0;
	lasttxntrace=0;
	site_id=0;
	siteid.setValue(0);
	lasttxnrespcode=0;
	cur_time.setValue(0);
}
void ShcDuplicateChk::dbInit()
{
	if( _dbConn != NULL )
		return;

	_dbConn = new DBMConn(dbm_dbconn);
}


int ShcDuplicateChk::check(ShcmsgHeader * header)
{
	dbInit();

	OTraceDebug("D-DUPCHECK-04001: Inside Duplicate Checking\n");

       int rc=selectOne(header);

       if(rc!=0)
       {
               OTraceError("E-DUPCHECK-04002: Error while Selecting from shcDuplicatechk \n",rc);
               return -1;
       }
       else
       {
		recycle();
		memcpy(pan,header->msg.pan,sizeof(pan));
		shc_normalizepan(pan);
		site_id=header->getMsgSiteId();
		siteid.setValue(site_id);
		try
		{

			_smtSelOne->execute();

			rc = _smtSelOne->fetch();

			if(rc ==DBM_SUCCESS)
			{
				if(shcApp->issuerShcParamsList->GetBool((char *)"shc.DupCheckExtended"))
				{
					OTraceDebug("D-DUPCHECK-04009: lasttxntime:%ld lasttxntermid:%s lasttxnacquirer:%s lasttxnauthnum:%s "
					"lasttxnrespcode:%ld for pan (%s) with siteid(%d) lasttxntrace:%ld\n",
						lasttxntime,lasttxntid,lasttxnacq,lasttxnanum,lasttxnrespcode,
					shcApp->shcHelperObj->shc_maskpan(header->msg.pan),header->getMsgSiteId(),lasttxntrace);	
				}
				else
				{
					OTraceDebug("D-DUPCHECK-04003: lasttxntime:%ld lasttxntermid:%s lasttxnacquirer:%s lasttxnauthnum:%s "
					"lasttxnrespcode:%ld for pan (%s) with siteid(%d)\n",
					lasttxntime,lasttxntid,lasttxnacq,lasttxnanum,lasttxnrespcode,
					shcApp->shcHelperObj->shc_maskpan(header->msg.pan),header->getMsgSiteId());
				}
			}

			_smtSelOne->close();

			if( rc == DBM_NO_DATA )
			{
				OTraceDebug("D-DUPCHECK-04004: Inserting to DuplicateChk as record not found\n");

				if(insertOne(header)==1)
				{
					recycle();
					memcpy(pan,header->msg.pan,sizeof(pan));
					shc_normalizepan(pan);
					site_id=header->getMsgSiteId();
					siteid.setValue(site_id);
					lasttxntime=shc_current_time;
					strcpy(lasttxntid,header->msg.termid);
					strcpy(lasttxnacq,header->msg.acquirer);
					strcpy(lasttxnanum,header->msg.authnum);
					lasttxnrespcode=header->msg.respcode;
					dbm_deccopy(&lasttxnamt,&header->msg.amount);
					OCDateTime current;
					cur_time.setValue(current);

					if(shcApp->issuerShcParamsList->GetBool((char *)"shc.DupCheckExtended"))
					{
						lasttxntrace=header->msg.trace;
						OTraceDebug("D-DUPCHECK-04011: Inserting an entry into ShcDuplicateChk with Pan :%s %d "
								"Site_is :%d Txntime:%ld Txntermid:%s Txnacquirer:%s "
								"Txnauthnum:%s" "Txnrespcode:%ld Txndatetime <%s> Trace:%ld\n",
								shcApp->shcHelperObj->shc_maskpan(pan),sizeof(pan),
								header->getMsgSiteId(),shc_current_time,header->msg.termid,header->msg.acquirer,
								header->msg.authnum,header->msg.respcode,(char *)(current).asString(), header->msg.trace);	
					}
					else
					{
						OTraceDebug("D-DUPCHECK-04005: Inserting an entry into ShcDuplicateChk with Pan :%s %d "
							    "Site_is :%d Txntime:%ld Txntermid:%s Txnacquirer:%s "
							    "Txnauthnum:%s" "Txnrespcode:%ld Txndatetime <%s>\n",
							    shcApp->shcHelperObj->shc_maskpan(pan),sizeof(pan),
							    header->getMsgSiteId(),shc_current_time,header->msg.termid,header->msg.acquirer,
							    header->msg.authnum,header->msg.respcode,(char *)(current).asString());
					}

					OTraceDumpMoney("D-DUPCHECK-04006: Lasttxnamt:%12s\n", &lasttxnamt);
					OTraceDumpMoney("D-DUPCHECK-04007: Msgamt:%12s\n", &header->msg.amount);

					if(_smtInsert->execute()!=DBM_SUCCESS)
					{
						OTraceError("E-DUPCHECK-04008: Cannot insert ShcDuplicateChk\n");
						return ( -1 );
					}
					_smtInsert->close();
					return 0;
				}
			}
		}
		catch (const DBMException& e)
		{
			OTraceError
			(
				"E-DUPCHECK-04009: caught exception during Selection,"
				"native error=%d, sqlstate=%.5s, msg=%s\n",
				e.getNativeError(), e.getSQLState().data(), e.getErrMsg().data()
			);
			return ( -2 );
		}
	}


	//OTraceDebug("D-DUPCHECK-04024:Current Time %s :: %ld \n", ctime((time_t *)&shc_current_time),shc_current_time);

	if(lasttxnrespcode == SHC_RC_IssuerTimeout || lasttxnrespcode == SHC_RC_IssuerDown)
		return 0;

	char temp_txntermid[24];
	strtrim(lasttxntid,temp_txntermid);

	if(shcApp->issuerShcParamsList->GetBool((char *)"shc.DupCheckExtended"))
	{
		if(stricmp(lasttxnacq, header->msg.acquirer) == 0
		   && stricmp(temp_txntermid, header->msg.termid) == 0		//	---	R022575
		   && dbm_deccmp(&lasttxnamt,&header->msg.amount) == 0
   		   && (lasttxntrace == header->msg.trace)
		   && (shc_current_time - lasttxntime) <= shcApp->issuerShcParamsList->GetNum((char *)"shc.DupTxnLength")
		  )
		{
			OTraceDebug("D-DUPCHECK-04013: Inside Duplicate Detected\n");
			/*      Copy the authnum */
			strcpy(header->msg.authnum, lasttxnanum);

			/*	force the card to be updated with new transaction time */
			lasttxntime = shc_current_time;
			int onlylasttime=1;

			update(header,onlylasttime,lasttxntime);
			
			OTraceWarning("W-SHC-04014: Duplicate detected: a%s/t%06d/c%s/term%s\n",
				header->msg.acquirer, header->msg.trace,		/* R003357 */
				shcApp->shcHelperObj->shc_maskpan(header->msg.pan), header->msg.termid);
			return 1;
		}
		else
			return 0;
	}
	else
	{
		if(stricmp(lasttxnacq, header->msg.acquirer) == 0
		&& stricmp(temp_txntermid, header->msg.termid) == 0		//	---	R022575
		&& dbm_deccmp(&lasttxnamt,&header->msg.amount) == 0
		&& (shc_current_time - lasttxntime) <= shcApp->issuerShcParamsList->GetNum((char *)"shc.DupTxnLength")
		)
		{

		OTraceDebug("D-DUPCHECK-04010: Inside Duplicate Detected\n");
		/*	Copy the authnum */
		//strcpy(header->msg.authnum, lasttxnanum);
		istsafe_strcpy(header->msg.authnum, sizeof(header->msg.authnum), lasttxnanum);

		/*	force the card to be updated with new transaction time */
		lasttxntime = shc_current_time;
		int onlylasttime=1;
		
		update(header,onlylasttime,lasttxntime);

		OTraceWarning("W-SHC-04011: Duplicate detected: a%s/t%06d/c%s/term%s\n",
			header->msg.acquirer, header->msg.trace,		/* R003357 */
			shcApp->shcHelperObj->shc_maskpan(header->msg.pan), header->msg.termid);
		return 1;
		}
		else
			return 0; 
	}
}
int ShcDuplicateChk::update(ShcmsgHeader * header,int onlylasttxntime,long txntime)
{
	dbInit();
	try
	{
		int sno=1;

		if(onlylasttxntime==1)
		{
			if (!_smtUpdate)
			{
				_smtUpdate = _dbConn->getStmt();
				//recycle();
				memset(pan,0x00,sizeof(pan));
				memcpy(pan,header->msg.pan,sizeof(pan));
				shc_normalizepan(pan);
				site_id=header->getMsgSiteId();
				siteid.setValue(site_id);


				OTraceDebug("D-DUPCHECK-04012: Updating Only txntime[%ld] for pan [%s] as its duplicatetxn \n",
					    txntime,shcApp->shcHelperObj->shc_maskpan(pan));

				_smtUpdate->prepare ("update shcduplicatechk set "
                                                             "lasttxntime = ?"
                                                             "where pan= ? and site_id = ?");

				_smtUpdate->bindParam(  sno++, DBM_LONGTYPE, &txntime, sizeof(txntime), NULL);
				_smtUpdate->bindParam(  sno++, DBM_PANTOKENTYPE, pan, sizeof(pan), NULL );
				_smtUpdate->bindParam(  sno++, siteid );
			}	
			if ( _smtUpdate->execute() != DBM_SUCCESS )
			{
				OTraceError("E-DUPCHECK-04013: Cannot update ShcDuplicateChk\n");
				return ( -1 );
			}
			_smtUpdate->close();
			 
		}
		else
		{
			recycle();
			memcpy(pan,header->msg.pan,sizeof(pan));
			shc_normalizepan(pan);
			site_id=header->getMsgSiteId();
			siteid.setValue(site_id);


			lasttxntime=shc_current_time;
			strcpy(lasttxntid,header->msg.termid);
			strcpy(lasttxnacq,header->msg.acquirer);
			strcpy(lasttxnanum,header->msg.authnum);
			lasttxnrespcode=header->msg.respcode;
			dbm_deccopy(&lasttxnamt,&header->msg.amount);
			OCDateTime current;
			cur_time.setValue(current);

			if(shcApp->issuerShcParamsList->GetBool((char *)"shc.DupCheckExtended"))
			{
				lasttxntrace=header->msg.trace;
				OTraceDebug("D-DUPCHECK-04017: Updating shcDuplicatechk table for Pan :%s with Site_id :%d " 
						"Txntime:%ld Txntermid:%s Txnacquirer:%s Txnauthnum:%s Txnrespcode:%ld "
						"Currenttime %s Txntrce:%ld\n" ,shcApp->shcHelperObj->shc_maskpan(pan),site_id,lasttxntime,
						lasttxntid,lasttxnacq,lasttxnanum,lasttxnrespcode,
						(char *)(current).asString(),lasttxntrace);
			}
			else
			{
				OTraceDebug("D-DUPCHECK-04014: Updating shcDuplicatechk table for Pan :%s with Site_id :%d " 
					   "Txntime:%ld Txntermid:%s Txnacquirer:%s Txnauthnum:%s Txnrespcode:%ld "
					   "Currenttime %s \n" ,shcApp->shcHelperObj->shc_maskpan(pan),site_id,lasttxntime,lasttxntid,lasttxnacq,lasttxnanum,lasttxnrespcode,
					    (char *)(current).asString());
			}

			OTraceDumpMoney("D-DUPCHECK-04015: lasttxnamt: %12s\n", &lasttxnamt);
			OTraceDumpMoney("D-DUPCHECK-04016: Msgamt: %12s\n", &header->msg.amount);

			if (!_updateTbl)
                        {
                                _updateTbl = _dbConn->getStmt();
				if(shcApp->issuerShcParamsList->GetBool((char *)"shc.DupCheckExtended"))
				{
                                _updateTbl->prepare ("update shcduplicatechk set "
                                             "updated = ?,"
                                             "lasttxntime = ?,"
                                             "lasttxnrespcode = ? ,"
                                             "lasttxnauthnum = ? ,"
                                             "lasttxntermid = ?,"
                                             "lasttxnacquirer = ?,"
						"lasttxnamt = ?,"
						"lasttxntrace = ? "
						"where pan=? and site_id = ? ");
					_updateTbl->bindParam(  sno++, cur_time );
					_updateTbl->bindParam(  sno++, DBM_LONGTYPE, &lasttxntime, sizeof(lasttxntime), NULL);
					_updateTbl->bindParam(  sno++, DBM_LONGTYPE, &lasttxnrespcode, sizeof(lasttxnrespcode), NULL );
					_updateTbl->bindParam(  sno++, DBM_STRINGTYPE, lasttxnanum, sizeof(lasttxnanum), NULL );
					_updateTbl->bindParam(  sno++, DBM_STRINGTYPE, lasttxntid, sizeof(lasttxntid), NULL );
					_updateTbl->bindParam(  sno++, DBM_STRINGTYPE, lasttxnacq, sizeof(lasttxnacq), NULL );
					_updateTbl->bindParam(  sno++, DBM_DECIMALTYPE, &lasttxnamt, sizeof(lasttxnamt), NULL );
					_updateTbl->bindParam(  sno++, DBM_LONGTYPE, &lasttxntrace, sizeof(lasttxntrace), NULL );
					_updateTbl->bindParam(  sno++, DBM_PANTOKENTYPE, pan, sizeof(pan), NULL );
					_updateTbl->bindParam(  sno++, siteid );	
				}
				else
				{
					_updateTbl->prepare ("update shcduplicatechk set "
						"updated = ?,"
						"lasttxntime = ?,"
						"lasttxnrespcode = ? ,"
						"lasttxnauthnum = ? ,"
						"lasttxntermid = ?,"
						"lasttxnacquirer = ?,"
                                             "lasttxnamt = ? "
                                             "where pan=? and site_id = ? ");
					_updateTbl->bindParam(  sno++, cur_time );
					_updateTbl->bindParam(  sno++, DBM_LONGTYPE, &lasttxntime, sizeof(lasttxntime), NULL);
					_updateTbl->bindParam(  sno++, DBM_LONGTYPE, &lasttxnrespcode, sizeof(lasttxnrespcode), NULL );
					_updateTbl->bindParam(  sno++, DBM_STRINGTYPE, lasttxnanum, sizeof(lasttxnanum), NULL );
					_updateTbl->bindParam(  sno++, DBM_STRINGTYPE, lasttxntid, sizeof(lasttxntid), NULL );
					_updateTbl->bindParam(  sno++, DBM_STRINGTYPE, lasttxnacq, sizeof(lasttxnacq), NULL );
					_updateTbl->bindParam(  sno++, DBM_DECIMALTYPE, &lasttxnamt, sizeof(lasttxnamt), NULL );
					_updateTbl->bindParam(  sno++, DBM_PANTOKENTYPE, pan, sizeof(pan), NULL );
					_updateTbl->bindParam(  sno++, siteid );
				}
			}		
			 if(_updateTbl->execute() != DBM_SUCCESS )
			{
				OTraceError("E-DUPCHECK-04017: Cannot update ShcDuplicateChk\n");
				return ( -1 );
			}
			_updateTbl->close();

			OTraceDebug( "D-DUPCHECK-04018: Updated DuplicateChk table for pan(%s)\n",shcApp->shcHelperObj->shc_maskpan(pan));
		}
			
				
	}
	catch (const DBMException& e)
	{
		OTraceError
		(
			"E-DUPCHECK-04019: Caught exception during update,"
			"native error=%d, sqlstate=%.5s, msg=%s\n",
			e.getNativeError(), e.getSQLState().data(), e.getErrMsg().data()
		);
		return ( -2 );
	}

	return 1;
}

ShcDuplicateChk::~ShcDuplicateChk()
{
	if(_dbConn)
	delete _dbConn;

	if(_smtSelOne)
	delete 	_smtSelOne;

        if(_smtUpdate)
        delete _smtUpdate;

        if(_updateTbl)
        delete _updateTbl;

}
int ShcDuplicateChk :: selectOne(ShcmsgHeader * header)
{
	if(!_smtSelOne)
	{
		_smtSelOne=_dbConn->getStmt();
		
		try
		{
			int sno = 1;
			int cnt = 2;
			memset( _ind, 0, sizeof(_ind) );
			memcpy(pan,header->msg.pan,sizeof(pan));
			shc_normalizepan(pan);

			OTraceDebug("D-DUPCHECK-04020: Selecting data for Pan (%s)\n",shcApp->shcHelperObj->shc_maskpan(pan));
			if(shcApp->issuerShcParamsList->GetBool((char *)"shc.DupCheckExtended"))
			{
				_smtSelOne->prepare
				(
				"SELECT "
				"lasttxntime, "
				"lasttxnamt, "
				"lasttxntermid, "
				"lasttxnacquirer, "
				"lasttxnauthnum, "
				"lasttxnrespcode, "
				"lasttxntrace "
				"FROM shcduplicatechk "
				"WHERE pan = ? and site_id = ?"
				);

				_smtSelOne->bindCol(  sno++, DBM_LONGTYPE, &lasttxntime, sizeof(lasttxntime), &_ind[cnt++] );
				_smtSelOne->bindCol(  sno++, DBM_DECIMALTYPE, &lasttxnamt, sizeof(lasttxnamt), &_ind[cnt++] );
				_smtSelOne->bindCol(  sno++, DBM_STRINGTYPE, lasttxntid, sizeof(lasttxntid), &_ind[cnt++] );
				_smtSelOne->bindCol(  sno++, DBM_STRINGTYPE, lasttxnacq, sizeof(lasttxnacq), &_ind[cnt++] );
				_smtSelOne->bindCol(  sno++, DBM_STRINGTYPE, lasttxnanum, sizeof(lasttxnanum), &_ind[cnt++] );
				_smtSelOne->bindCol(  sno++, DBM_LONGTYPE, &lasttxnrespcode, sizeof(lasttxnrespcode), &_ind[cnt++] );		
				_smtSelOne->bindCol(  sno++, DBM_LONGTYPE, &lasttxntrace, sizeof(lasttxntrace), &_ind[cnt++] );
				_smtSelOne->bindParam(  1, DBM_PANTOKENTYPE, pan, sizeof(pan), NULL );		
				_smtSelOne->bindParam(  2, siteid );		
			}
			else
			{
				_smtSelOne->prepare
				(
				"SELECT "
				"lasttxntime, "
				"lasttxnamt, "
				"lasttxntermid, "
				"lasttxnacquirer, "
				"lasttxnauthnum, "
				"lasttxnrespcode "
				"FROM shcduplicatechk "
				"WHERE pan = ? and site_id = ?"
				);

				_smtSelOne->bindCol(  sno++, DBM_LONGTYPE, &lasttxntime, sizeof(lasttxntime), &_ind[cnt++] );
				_smtSelOne->bindCol(  sno++, DBM_DECIMALTYPE, &lasttxnamt, sizeof(lasttxnamt), &_ind[cnt++] );
				_smtSelOne->bindCol(  sno++, DBM_STRINGTYPE, lasttxntid, sizeof(lasttxntid), &_ind[cnt++] );
				_smtSelOne->bindCol(  sno++, DBM_STRINGTYPE, lasttxnacq, sizeof(lasttxnacq), &_ind[cnt++] );
				_smtSelOne->bindCol(  sno++, DBM_STRINGTYPE, lasttxnanum, sizeof(lasttxnanum), &_ind[cnt++] );
				_smtSelOne->bindCol(  sno++, DBM_LONGTYPE, &lasttxnrespcode, sizeof(lasttxnrespcode), &_ind[cnt++] );		
				_smtSelOne->bindParam(  1, DBM_PANTOKENTYPE, pan, sizeof(pan), NULL );		
				_smtSelOne->bindParam(  2, siteid );		
			}
		}
		catch (const DBMException& e)
		{
			OTraceError
			(
				"E-DUPCHECK-04021: Caught exception during Selection,"
				"native error=%d, sqlstate=%.5s, msg=%s\n",
				e.getNativeError(), e.getSQLState().data(), e.getErrMsg().data()
			);
			return ( -2 );
		}
        }
	return 0;
}

const char *ShcDuplicateChk::getAmtStr( amount_t *amt, int n )
{
	static char xbuf[sizeof(amount_t)+1];
	int old_ndigits = dbm_getndigits();
	
	dbm_setndigits( n );
	dbm_dectochar(amt, xbuf);
	dbm_setndigits(old_ndigits);
	
	return xbuf;
}


int ShcDuplicateChk::dumpMoney(const char *fmt, amount_t *m)
{
	OTraceDebug(fmt, getAmtStr(m));	//	---	R018303
	return 0;
}

int ShcDuplicateChk :: insertOne(ShcmsgHeader* header)
{
	if(!_smtInsert)
	{
		_smtInsert=_dbConn->getStmt();
		try
		{
			recycle();
			int sno = 1;

			if(shcApp->issuerShcParamsList->GetBool((char *)"shc.DupCheckExtended"))
			{

			_smtInsert->prepare ("insert into shcduplicatechk ("
					     "pan,"
					     "site_id,"
					     "created,"
					     "updated,"
					     "lasttxntime,"
					     "lasttxntermid,"
					     "lasttxnacquirer,"
					     "lasttxnauthnum,"
					     "lasttxnrespcode,"
						"lasttxnamt,"
						"lasttxntrace"
						")values"
						"(?,?,?,?,?,?,?,?,?,?,?)");

				_smtInsert->bindParam(  sno++, DBM_PANTOKENTYPE, pan, sizeof(pan), NULL );
				_smtInsert->bindParam(  sno++, siteid );
				_smtInsert->bindParam(  sno++, cur_time );
				_smtInsert->bindParam(  sno++, cur_time );
				_smtInsert->bindParam(  sno++, DBM_LONGTYPE, &lasttxntime, sizeof(lasttxntime), NULL);
				_smtInsert->bindParam(  sno++, DBM_STRINGTYPE, lasttxntid, sizeof(lasttxntid), NULL );
				_smtInsert->bindParam(  sno++, DBM_STRINGTYPE, lasttxnacq, sizeof(lasttxnacq), NULL );
				_smtInsert->bindParam(  sno++, DBM_STRINGTYPE, lasttxnanum, sizeof(lasttxnanum), NULL );
				_smtInsert->bindParam(  sno++, DBM_LONGTYPE, &lasttxnrespcode, sizeof(lasttxnrespcode), NULL );
				_smtInsert->bindParam(  sno++, DBM_DECIMALTYPE, &lasttxnamt, sizeof(lasttxnamt), NULL );
				_smtInsert->bindParam(  sno++, DBM_LONGTYPE, &lasttxntrace, sizeof(lasttxntrace), NULL );
			}
			else
			{
				_smtInsert->prepare ("insert into shcduplicatechk ("
							"pan,"
							"site_id,"
							"created,"
							"updated,"
							"lasttxntime,"
							"lasttxntermid,"
							"lasttxnacquirer,"
							"lasttxnauthnum,"
							"lasttxnrespcode,"
							     "lasttxnamt"
							     ")values"
							     "(?,?,?,?,?,?,?,?,?,?)");

					_smtInsert->bindParam(  sno++, DBM_PANTOKENTYPE, pan, sizeof(pan), NULL );
					_smtInsert->bindParam(  sno++, siteid );
					_smtInsert->bindParam(  sno++, cur_time );
					_smtInsert->bindParam(  sno++, cur_time );
					_smtInsert->bindParam(  sno++, DBM_LONGTYPE, &lasttxntime, sizeof(lasttxntime), NULL);
					_smtInsert->bindParam(  sno++, DBM_STRINGTYPE, lasttxntid, sizeof(lasttxntid), NULL );
					_smtInsert->bindParam(  sno++, DBM_STRINGTYPE, lasttxnacq, sizeof(lasttxnacq), NULL );
					_smtInsert->bindParam(  sno++, DBM_STRINGTYPE, lasttxnanum, sizeof(lasttxnanum), NULL );
					_smtInsert->bindParam(  sno++, DBM_LONGTYPE, &lasttxnrespcode, sizeof(lasttxnrespcode), NULL );
					_smtInsert->bindParam(  sno++, DBM_DECIMALTYPE, &lasttxnamt, sizeof(lasttxnamt), NULL );
			}
		}
		catch (const DBMException& e)
		{
			OTraceError
			(
				"E-DUPCHECK-04022: Caught exception during insert,"
				"native error=%d, sqlstate=%.5s, msg=%s\n",
				e.getNativeError(), e.getSQLState().data(), e.getErrMsg().data()
			);
			return ( -2 );
		}
	}
	OTraceDebug("D-DUPCHECK-04023: Inserted entry into ShcDuplicateChk\n"); 
	return 1;

}
