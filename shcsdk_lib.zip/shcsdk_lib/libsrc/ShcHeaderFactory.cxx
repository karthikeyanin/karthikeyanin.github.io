static char _ShcHeaderFactory_cxx_what[] = "@(#) ShcHeaderFactory.cxx 1.8.2.2 17/08/02 12:57:06";

/*
 *  Copyright (C) 2004 eFunds Corporation ("eFunds").  All Rights Reserved.
 *  eFunds Canada Corporation is an authorized user.
 *
 *  IST is a registered trademark of eFunds Corporation.  Other brand or
 *  product names are trademarks or registered trademarks of their respective
 *  holders.
 *
 *  The information contained herein is the unpublished proprietary property
 *  of eFunds.  Except as specifically authorized in writing by eFunds, the
 *  holder of this document shall: i) keep all information contained herein
 *  confidential, and ii) protect the information, in whole or in part, from
 *  disclosure and dissemination to all third parties.
 *
 *  This document and the software described in it are furnished under license
 *  and may be used or copied only in accordance with the terms of such license.
 *  This document is supplied for information purposes only, is subject to
 *  change without notice, and should not be construed as a commitment by
 *  either eFunds Corporation or eFunds Canada Corporation.
 *
 *
 *                        MODIFICATION HISTORY                  REVIEW
 *
 * SCR#     Who    Date  Description
 * ===========================================================================
 * R020052 spa   21May07 Added cases for ShcmsgFMHeader, FMHeader
 * R020938 spa	 16Aug07 IST LM Bridge support
 */

/* File Number 151 */

#include <ShcSdkCommon.h>
#include <AcqProfile.h>
#include <InstProfile.h>
#include <IssProfile.h>
#include <ShcAcceptorName.h>
#include <ShcAppBase.h>
#include <ShcBin.h>
#include <ShcDKEHelper.h>
#include <ShcHeader.h>
#include <ShcKeyHelper.h>
#include <ShcMacHelper.h>
#include <shcPosGeoLoc.h>
#include <ShcSafIOHelper.h>
#include <ShcSdkLog.h>
#include <CShcLog.h>
#include <Shc600Log.h>
#include <CShcNotify.h>
#include <ShcSender.h>
#include <ShcTimerHelper.h>
#include <ShckeyParamsList.h>
#include <ShcmsgHelper.h>
#include <ShcHeaderFactory.h>
#include <ShcmsgFMHeader.h>	//	---	R020052
#include <ShcmsgODHeader.h>	
#include <FMCMDHeader.h>	//	---	R020052



//entity_type is passed in as a string for now
int ShcHeaderFactory::createCondition(char *condition, const void *msg)
{
	int msgtype;
	memcpy(&msgtype, msg, sizeof(msgtype));
	sprintf(condition, "%04d", msgtype%10000);
	return 0;
}

ShcHeader *ShcHeaderFactory::getTargetObj(char *condition, const void *msg)
{
//	return getObject(condition, helperClassName);
	return createInstance(condition, msg);	// not recycle objects
}


ShcHeader *ShcHeaderFactory::createInstance(const char *condition, const void *msg)
{
	ShcHeader *obj = NULL;
	int mti = atoi(condition);

	if ( mti == SHC_STANDIN_DECISION_BY_ISS_RESP_NOTIFICATION )
	{
		obj = new ShcmsgHeader((struct shcmsg *)msg);
		return obj;
	}

 	switch(condition[1])
 	{
 	case '1':
 	case '2':
 	case '4':
	case '5':
 	case '6':
 	case '8':
		//	>>>	R020052
		if((atoi(condition) == SHC_FM_RESP) || (atoi(condition) == SHC_LM_RESP) ||
			(atoi(condition) == SHC_LM_REVRESP) || (atoi(condition) == SHC_LM_LATERESP))//	---	R020938
			obj = new ShcmsgFMHeader((struct s_FMDecision *)msg);
		else if(atoi(condition) == SHC_FM_CMD_REQ)
			obj = (ShcHeader *)new FMCMDHeader((struct s_BlockCMD *)msg);
		else if(mti == SHC_OD_RESP)
			obj = (ShcHeader *)new ShcmsgODHeader((struct s_ODDecision *)msg);
		else
		//	<<<	R020052
		obj = new ShcmsgHeader((struct shcmsg *)msg);
		break;
	case '3':
		//      >>>     R020052
		if((atoi(condition) == SHC_FM_INST_REQ) || (atoi(condition) == SHC_FM_INST_RESP))
			obj = (ShcHeader *)new FMCMDHeader((struct s_BlockCMD *)msg);
		//	>>>	istauth file update
		else if ( condition[0] == '7' )
			obj = new ShcmsgHeader((struct shcmsg *)msg);
		//	<<<	istauth file update
		else
			obj = new Shc300Header((struct shcmsg *)msg);
		//      <<<     R020052
		break;
	default:
		switch(condition[0])
		{
		case '9':
		case '8':
			obj = new ShcmsgHeader((struct shcmsg *)msg);
			break;

		default:
			obj = NULL;
		}
	}
	if ( obj )
		OTraceDebug("D-SHC-2301:     Create [%s] [%s]\n", obj->getName(), condition);
	else
		OTraceError("I-SHC-2302:     Not ShcHeader Instance[%s]\n", condition);

	return obj;
}


