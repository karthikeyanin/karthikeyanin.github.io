/*
 *  Copyright (C) 2004 eFunds Corporation ("eFunds").  All Rights Reserved.
 *  eFunds Canada Corporation is an authorized user.
 *
 *  IST is a registered trademark of eFunds Corporation.  Other brand or
 *  product names are trademarks or registered trademarks of their respective
 *  holders.
 *
 *  The information contained herein is the unpublished proprietary property
 *  of eFunds.  Except as specifically authorized in writing by eFunds, the
 *  holder of this document shall: i) keep all information contained herein
 *  confidential, and ii) protect the information, in whole or in part, from
 *  disclosure and dissemination to all third parties.
 *
 *  This document and the software described in it are furnished under license
 *  and may be used or copied only in accordance with the terms of such license.
 *  This document is supplied for information purposes only, is subject to
 *  change without notice, and should not be construed as a commitment by
 *  either eFunds Corporation or eFunds Canada Corporation.
 */
/*
#pragma ident "@(#) shc_data.cxx 1.12.7.6 18/02/02 05:50:33";
 *
 *    MODIFICATION HISTORY                  REVIEW
 *
 *	SPR#	Who	Date	Description			Who	Date
 * ===========================================================================
 * 10002122 la  29may96 Added configuration to route 800 messages.
 * 10001935 la  31may96 Renamed struct shckeys to struct shckeysmem.
 * 1002864  jt  13dec96 Added config for shcSendIss_420NoOrig.
 *          yh  26Aug97 Added shcLeadingZeroBin & shcLeadingZeroChar
 * R000588  qd  24nov97 New system level configuration parameters for ACXSYS
 * ACXSYS   yh  25Feb98 Added shcDeviceEncryptBlance dor device balance encryption.
 * R000960  et  23apr98 Added parameter to keep old or reset trantime & trandate
 * R000973  qd 04may98  Leading Zero Bin & Pan
 * R001952  zt 			Added AUTHENTICATE transaction definition for
 *						shc_txn_def
 * 0001303  yh  10Mar99 mailbox id for RECON Server & STD500
 * R001835  qd  20may99 Interac Merge
 * R002251  zt  29Jul99 Added shc_back_office_enabled.
 * R002517  fg  13Aug99 remove mailbox id for STD500 (settlementid), which is
 *						currently defined in shc_settle.c
 * R002521  fg  13Aug99 remove mailbox id for RECON Server (recon_mid), which is *						currently defined in shc_recon.c
 * R003308  fg  28Oct99 Move SHC configuration parameters to bin level
 *                      shc.verify_mac, shc.encrypt_balance, shc.support_NDKE
 *                      shc.restore_trantime, shc.capdate_override
 * R003309  fg  28Oct99 Remove three configuration parameters
 *                      shc.device_encrypt, shc_leading_zero_bin
 *                      shc.leading_zero_char
 * R004671  Dds 26Jun00 Merge vsdc enhancement to 7.2, refer to 2007336
 * 2007336  Mch 26Feb00 Added support for chip data on 7.1.3
 *R007502 ztang 15Feb02 Added support for Account Funding transaction
 * R006940  Emj 02Nov01 EMV STIP Card/Issuer Authentication.
 *R007984 jyang 21Jun02 Added shcApp->omsg_chip_index field
 *R008224 ztang 05Sep02 Added shcSendIss_VoidAdviceNoOrig
 *R008689 ztang 05Dec02 Added shcApp->shclog_specified_msgtype
 *R010134 jyang 22Sep03 Added pcode_req to save request message pcode
 *R015826 pve	03Mar06	Support for Generic Log	
 */

//File Number 8

#if defined( WIN32 )
#       define SHCDLLEXPORT __declspec(dllexport)
#else
#       define SHCDLLEXPORT
#endif


#include <stdio.h>
#include <oasis.h>
#include <shc.h>
#include <ShcAppBase.h>

#include <McastHelper.h>
#include <ShcBalancer.h>

#include <CShcGenericLog.h>		//	R015826
#include <ShcGenericLogHelper.h>	// R030273

#include <ShcDuplicateChk.h>
#include <ShcPinTryCounter.h>
#include <ShcCardStatusHelper.h>
#include <ShcCardStatusChngAlw.h>
#include <Shc300ReqDB.h>
#include <Shc3XX.h>

/*
 *	Global runtime references
 */
struct	shcstats	*shcStats	= NULL;
bin_t   shcDefaultIssuerId = { 0 };
int		shcStatsAppid   = (-1);
int		shcAppid		= (-1);
int		shcPinAppid		= (-1);
int		shcSecurityAppid	= (-1);
int		shcExtBinAppid	= (-1);
struct  rules_keytab    *stats_rulekeyp = NULL;
struct  rules_keytab    *rmtbin_rulekeyp = NULL;
struct  rules_keytab    *shcextbin_rulekeyp = NULL;
struct  pinverparm  *shcPin = NULL;
struct  shcextbin   *shcExtBin = NULL;
struct  shcrmtbin   *shcRmtBin = NULL;
struct  shckeysmem  *shcBinKeys = NULL;
struct  shcsecurity *shcSecurity = NULL;
struct  rules_keytab    *rulekeyp = NULL;
int		shcRmtBinAppid	= (-1);
struct	shcpkg		*shcDefaultIssuer = NULL;
struct	shcpkg		*shcBinPkg	= NULL;

long			shc_current_time = 0;
int				shc_current_millisecond = 0;
int				dbmid		= (-1);
int				shcmid		= (-1);
int				agtmbid		= (-1);
int				tmgrmid	= (-1);
int				DoCurrencyConv = 0;
int				haveDNSupport 	= 0;
int				haveLCRSupport 	= 0;
int				haveTieBreaker	= 0;
int				haveReferCardIssuer = 0;
int				useTxnDestInEventMatching = 1;
int				useTxnDestInShclogLocating = 1;
int				shcDebugFlag = 0;
int				UcafCtrlByte = 0;
int 				netMsginLocalSite = 0;
int				SkipCvvChipOrContactless = 0;
int 			bindRefNumLocate = 0;
int				DateCheckBeforeLogging = 0;
/*
 *	Other misc. values
 */
bin_t			shc_orgid = "1010101010";
ShcAppBase *shcApp = NULL;
struct shcmsg *tmpShcOmsg = NULL;

ShcGenericLog *shcGenericLogObj = NULL;		//	R015826
ShcGenericLogHelper *shcGenLogHelperObj = NULL; // R030273
char	mcInst[MAX_TXN_DESTINATION_LEN+1] = { 0 };
char	mcInstOther[MAX_TXN_DESTINATION_LEN+1] = { 0 };
char	visaInst[MAX_TXN_DESTINATION_LEN+1] = { 0 };
char		noBraodcastFlag = 0;
int                     ofThisSite = 0;
struct	shckeysmem		*newlyFoundShcBinKey;
int gShcExtendedEventLocate = 1;
int visaSkipCvv = 0;
int FullCheckDigit = 0;

McastHelper *mcastHelperObj = NULL;
ShcBalancer *shcBalancerObj = NULL;

UpdateMemHelper *updateMemHelperObj = NULL;
ShcSharedMemoryHelper *shcSharedMemoryHelperObj = NULL;
ShcDuplicateChk *shcDuplicateChkObj = NULL;
ShcPinTryCounter *shcPinTryCounterObj = NULL;
ShcCardStatusHelper *shcCardStatusHelperObj = NULL;
ShcCardStatusChngAlw *shcCardStatusChngAlwObj=NULL;
Shc300ReqDB *shc300ReqDBObj = NULL;
SHC300 *shc300Obj = NULL;

const char sharedCashSecurityRuleName[] = "shared-cash-security";
const char sharedCashRuleName[] = "shared-cash";
short extBinCountryCode = 0;
int  delaySendCachedMsg = 0;
int shcEnableSubssecondTimeout = 0;
int notifyOnIssResponse = 0;
short extBinLength = 0;
int shcSetTxnStartDate = 1;



/*
 * End of File: shc_data.c
 */
