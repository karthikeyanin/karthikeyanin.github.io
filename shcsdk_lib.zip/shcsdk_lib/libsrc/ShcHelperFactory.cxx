static char _ShcHelperFactory_cxx_what[] = "@(#) ShcHelperFactory.cxx 1.9.6.3 20/01/30 13:05:44";

/*
 *  Copyright (C) 2004 eFunds Corporation ("eFunds").  All Rights Reserved.
 *  eFunds Canada Corporation is an authorized user.
 *
 *  IST is a registered trademark of eFunds Corporation.  Other brand or
 *  product names are trademarks or registered trademarks of their respective
 *  holders.
 *
 *  The information contained herein is the unpublished proprietary property
 *  of eFunds.  Except as specifically authorized in writing by eFunds, the
 *  holder of this document shall: i) keep all information contained herein
 *  confidential, and ii) protect the information, in whole or in part, from
 *  disclosure and dissemination to all third parties.
 *
 *  This document and the software described in it are furnished under license
 *  and may be used or copied only in accordance with the terms of such license.
 *  This document is supplied for information purposes only, is subject to
 *  change without notice, and should not be construed as a commitment by
 *  either eFunds Corporation or eFunds Canada Corporation.
 *
 *                        MODIFICATION HISTORY                  REVIEW
 *
 * SCR#     Who    Date  Description
 * ===========================================================================
 * R0xxxxx 
 * R015826 pve	07Mar06	Support for Generic Log
 */

/* File Number 150 */

#include <ShcSdkCommon.h>
#include <AcqProfile.h>
#include <InstProfile.h>     
#include <IssProfile.h>      
#include <ShcAcceptorName.h> 
#include <ShcAppBase.h>      
#include <ShcBin.h>          
#include <ShcDKEHelper.h>    
#include <ShcHelper.h>       
#include <ShcKeyHelper.h>    
#include <ShcMacHelper.h>    
#include <shcPosGeoLoc.h>    
#include <ShcSafIOHelper.h>  
#include <ShcSdkLog.h>   
#include <CShcLog.h> 
#include <Shc600Log.h>
#include <CShcNotify.h>
#include <ShcSender.h>       
#include <ShcTimerHelper.h>  
#include <ShckeyParamsList.h>
#include <ShcmsgHelper.h>    
#include <ShcGenericLogBinary.h>		//	R015826
#include <ShcGenericLogHelper.h>
#include <ShcBalancer.h>    
#include <BinRoute.h>    
#include <ShcSharedMemoryHelper.h>
#include <ShcDuplicateChk.h>
#include <ShcPinTryCounter.h>
#include <ShcCardStatusHelper.h>
#include <ShcCardStatusChngAlw.h>
#include <Shc300ReqDB.h>
#include <Shc3XX.h>
#include <ShcRevMRHelper.h>
#include <ShcKeysMRHelper.h>
#include <IssProfileExtended.h>
#include <istsafe.h>


//entity_type is passed in as a string for now
int ShcHelperFactory::createCondition(char *condition, const void *helperClassName)
{
	//strcpy(condition, (char *)helperClassName);
	istsafe_strcpy(condition, MAX_REGISTRATION_COND_LEN, (char *)helperClassName);
	return 0;
}

ShcHelperBase *ShcHelperFactory::getTargetObj(char *condition, const void *helperClassName)
{
//	return getObject(condition, helperClassName);
	return createInstance(condition, helperClassName);	// not recycle objects
}


ShcHelperBase *ShcHelperFactory::createInstance(const char *condition, const void *msg)
{
	ShcHelperBase *obj = NULL;
	if (strcmp(condition, SHC_ShcBin) == 0)
		obj = new ShcBin();    
	else if (strcmp(condition, SHC_AcqProfile) == 0) 	
		obj = new AcqProfile();
	else if (strcmp(condition, SHC_ShcNotify) == 0)
		obj = new ShcNotify();
	else if (strcmp(condition, SHC_InstProfile) == 0)
		obj = new InstProfile();
	else if (strcmp(condition, SHC_IssProfile) == 0)
		obj = new IssProfile();
	else if (strcmp(condition, SHC_ShcAcceptorName) == 0)
		obj = new ShcAcceptorName();
	else if (strcmp(condition, SHC_ShcAppBase) == 0)
		obj = new ShcAppBase();
	else if (strcmp(condition, SHC_ShcDKEHelper) == 0)
		obj = new ShcDKEHelper();
	else if (strcmp(condition, SHC_ShcHelper) == 0)
		obj = new ShcHelper();
	else if (strcmp(condition, SHC_ShcKeyHelper) == 0)
		obj = new ShcKeyHelper();
	else if (strcmp(condition, SHC_ShcMacHelper) == 0)
		obj = new ShcMacHelper();
	else if (strcmp(condition, SHC_ShcPosGeoLoc) == 0)
		obj = new ShcPosGeoLoc();
	else if (strcmp(condition, SHC_ShcSafIOHelper) == 0)
		obj = new ShcSafIOHelper();
	else if (strcmp(condition, SHC_AccumulationSender) == 0)
		obj = new AccumulationSender();
	else if (strcmp(condition, SHC_AdviceSender) == 0)
		obj = new AdviceSender();
	else if (strcmp(condition, SHC_ShcTimerHelper) == 0)
		obj = new ShcTimerHelper();
	else if (strcmp(condition, SHC_ShckeyParamsList) == 0)
		obj = new ShckeyParamsList();
	else if (strcmp(condition, SHC_ShcmsgHelper) == 0)
		obj = new ShcmsgHelper();
	//	>>>	R015826
	else if (strcmp(condition, SHC_ShcGenericLog) == 0)
		obj = new ShcGenericLogBinary();
	//	<<<	R015826
	else if (strcmp(condition, SHC_ShcGenericLogHelper) == 0)
		obj = new ShcGenericLogHelper();
	else if (strcmp(condition, SHC_ShcBalancer) == 0)
		obj = new ShcBalancer();
	else if (strcmp(condition, SHC_BinRoute) == 0)
		obj = new BinRoute();
	else if (strcmp(condition, SHC_ShcSharedMemoryHelper) == 0)
		obj = new ShcSharedMemoryHelper();
	else if (strcmp(condition, SHC_ShcDuplicateChk) == 0)
		obj = new ShcDuplicateChk();
	else if (strcmp(condition, SHC_ShcPinTryCounter) == 0)
		obj = new ShcPinTryCounter();
	else if (strcmp(condition, SHC_ShcCardStatusHelper) == 0)
		obj = new ShcCardStatusHelper();
	else if (strcmp(condition, SHC_ShcCardStatusChngAlw) == 0)
		obj = new ShcCardStatusChngAlw();
	else if (strcmp(condition, SHC_Shc300ReqDB) == 0)
		obj = new Shc300ReqDB();
	else if (strcmp(condition, SHC_Shc300) == 0)
		obj = new SHC300();
	else if (strcmp(condition, SHC_ShcLog) == 0)
		obj = new ShcLog();
	else if (strcmp(condition, SHCREVMRHELPER_OBJ_NAME) == 0)
		obj = new ShcRevMRHelper();
	else if (strcmp(condition, SHCKEYSMRHELPER_OBJ_NAME) == 0)
		obj = new ShcKeysMRHelper();
	else if (strcmp(condition, SHC_IssProfileExtended) == 0)
		obj = new IssProfileExtended();
	else 
		obj = NULL;
	
	if ( obj )
		OTraceDebug("D-SHC-2301:     Create Instance[%s]\n", condition);
	else
		OTraceError("I-SHC-2302:     No Instance[%s]\n", condition);
		
	return obj;
}


