/*
 *  Copyright (C) 2004 eFunds Corporation ("eFunds").  All Rights Reserved.     
 *  eFunds Canada Corporation is an authorized user.                            
 *                                                                              
 *  IST is a registered trademark of eFunds Corporation.  Other brand or        
 *  product names are trademarks or registered trademarks of their respective   
 *  holders.                                                                    
 *                                                                              
 *  The information contained herein is the unpublished proprietary property    
 *  of eFunds.  Except as specifically authorized in writing by eFunds, the     
 *  holder of this document shall: i) keep all information contained herein     
 *  confidential, and ii) protect the information, in whole or in part, from    
 *  disclosure and dissemination to all third parties.                          
 *                                                                          
 *  This document and the software described in it are furnished under license  
 *  and may be used or copied only in accordance with the terms of such license.
 *  This document is supplied for information purposes only, is subject to      
 *  change without notice, and should not be construed as a commitment by       
 *  either eFunds Corporation or eFunds Canada Corporation. 
 */

// "@(#) shc_sender.cxx 1.5 06/11/23 15:31:51"

/*----------------------------------------------------------------------------*
 *                                                                            *
 * File:				
 * Description:	
 * Notes:
 *
 * Modification History:
 * YYMMDD SCR#    WHO	Description
 * ------ ------- ---	------------------------------------------------------*
 * 020319 R009462 ztang Created.
 * 030516 R009740 ztang Added more condition for accumulation
 *----------------------------------------------------------------------------*/

/* File Number  16 */
#if defined(WIN32)
#	define ShcSender_h_export_directive	__declspec(dllexport)
#else
#	define ShcSender_h_export_directive
#endif

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <errno.h>
#include <mb.h>
#include <shc.h>
#include <shcdef.h>
#include <oasis.h>
#include <ist_otrace.h>
#include <ShcSdkCommon.h>
#include <ShcSender.h>
#include <ShcmsgHeader.h>


#define shcIsPOS(header)	(	(header->msg.pos_condition_code & SH_POS_COND_TERMATOWNER ) && \
        						(header->msg.pos_condition_code & SH_POS_COND_CUSTPRESENT) && \
        						(header->msg.pos_condition_code & SH_POS_COND_CARDPRESENT ) \
        					)



static long shcNotificationCondition = SHC_NOTIFICATION_RESPONSE|SHC_NOTIFICATION_APPROVED|
						SHC_NOTIFICATION_ATM|SHC_NOTIFICATION_POS|SHC_NOTIFICATION_OTHER;

void setShcNotificationCondition(long condition)
{
	shcNotificationCondition = condition;
}

void setShcNotificationCondition(char *strCondition)
{
	long c=0;
	
	for(char *p=strtok(strCondition," \t\n");p!=NULL;p=strtok(NULL, " \t\n"))
	{
		if (strcmp(p, "approved")==0)
			c |= SHC_NOTIFICATION_APPROVED;
		else if (stricmp(p, "denied")==0)
			c |= SHC_NOTIFICATION_DENIED;
		else if (stricmp(p, "atm")==0)
			c |= SHC_NOTIFICATION_ATM;
		else if (stricmp(p, "pos")==0)
			c |= SHC_NOTIFICATION_POS;
		else if (stricmp(p, "other")==0)
			c |= SHC_NOTIFICATION_OTHER;
		else if (stricmp(p, "request")==0)
			c |= SHC_NOTIFICATION_REQUEST;
		else if (stricmp(p, "response")==0)
			c |= SHC_NOTIFICATION_RESPONSE;
	}
	setShcNotificationCondition(c);
}

////////////////////////////////////////////////////////////////////////////////
AdviceSender::AdviceSender():ShcSenderBase(ADVICE_SERVER_MBOX_NAME)
{
}

AccumulationSender::AccumulationSender():ShcSenderBase(ACCUMULATION_SERVER_MBOX_NAME)
{
}

ShcSenderBase::ShcSenderBase(const char *mboxName)
{
	strcpy(m_mboxName, mboxName);
	m_mboxId = -1;
}

int AdviceSender::send(ShcmsgHeader *header, const int senderMboxId, const int msgLen)
{
	long tmpFlag = 0;
	
	
	if (shcmsgIsResponse(&header->msg))
		tmpFlag |= SHC_NOTIFICATION_RESPONSE;
	else
		tmpFlag |= SHC_NOTIFICATION_REQUEST;
		
	if (header->msg.respcode != SHC_RC_Approved)
		tmpFlag |= SHC_NOTIFICATION_DENIED;
	else
		tmpFlag |= SHC_NOTIFICATION_APPROVED;
		
	if (shcIsATM(header))
		tmpFlag |= SHC_NOTIFICATION_ATM;
	else if (shcIsPOS(header))
		tmpFlag |= SHC_NOTIFICATION_POS;
	else
		tmpFlag |= SHC_NOTIFICATION_OTHER;

	if (tmpFlag == (tmpFlag & shcNotificationCondition))
		return(this->ShcSenderBase::send(header, senderMboxId, msgLen));
	else
	{
		OTraceDebug("D-SHC-016001:condition [%lx] not met [%x], notification not sent\n",
				shcNotificationCondition, tmpFlag);
		return 0;
	}
}

int AccumulationSender::send(ShcmsgHeader *header, const int senderMboxId, const int msgLen)
{
	if (!shcIsResponse(header))
	{
		OTraceDebug("D-SHC-016002:Not response message, no need to accumulate\n");
		return 0;
	}
	if( header->msg.respcode != SHC_RC_Approved	&& header->msg.respcode != SHC_RC_PartialDispense )
	{
		OTraceDebug("D-SHC-016003:Not approved message, no need to accumulate\n");
		return 0;
	}
	
	if( header->msg.device_cap & SH_DEVCAP_FROM_REPLAY )
	{
		OTraceDebug("D-SHC-016004:    action : ignored - replay transaction\n");

		return( 0 );
	}

	if ((header->msg.msgtype/100 == 1) || (header->msg.msgtype/100 == 2) || (header->msg.msgtype/100 == 4))
		return(this->ShcSenderBase::send(header, senderMboxId, msgLen));
	else
		OTraceDebug("D-SHC-016005:    action : ignored - message type not used.\n");

	return 0;
}

int ShcSenderBase::send(ShcmsgHeader *header, const int senderMboxId, const int msgLen)
{
	int len;
	
	if ( m_mboxId == -1)
		initialize();
	
	if (m_mboxId < 0)
	{
		OTraceInfo("I-SHC-016006: server mailbox not found, msg not sent\n");
		return(0);
	}
		
	if((len = mb_write(m_mboxId, senderMboxId, (void *)&header->msg, msgLen) ) < 0)
	{
			OTraceLog("L-SHC-16009: Failed to send msg ID[%s] /m%04d/t%d/p%06d to %s\n",
				header->msg.shclog_id, header->msg.msgtype, header->msg.trace, 
				header->msg.pcode, mbMailBoxName(m_mboxId));
		return(-1);
	}
	else
		OTraceLog("L-SHC-16010: Sent msg ID[%s] /m%04d/t%d/p%06d to %s\n",
			header->msg.shclog_id, header->msg.msgtype, header->msg.trace, 
			header->msg.pcode, mbMailBoxName(m_mboxId));
	
	return(0);
}

void ShcSenderBase::initialize()
{
	if ((m_mboxId = mb_locatemailbox(m_mboxName)) < 0)
	{
		OTraceWarning("W-SHC-016008: advice server mailbox not found, advice feature disabled\n");
		m_mboxId = -2;
	}
}



