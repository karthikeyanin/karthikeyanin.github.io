/*
 *  Copyright (C) 2004 eFunds Corporation ("eFunds").  All Rights Reserved.     
 *  eFunds Canada Corporation is an authorized user.                            
 *                                                                              
 *  IST is a registered trademark of eFunds Corporation.  Other brand or        
 *  product names are trademarks or registered trademarks of their respective   
 *  holders.                                                                    
 *                                                                              
 *  The information contained herein is the unpublished proprietary property    
 *  of eFunds.  Except as specifically authorized in writing by eFunds, the     
 *  holder of this document shall: i) keep all information contained herein     
 *  confidential, and ii) protect the information, in whole or in part, from    
 *  disclosure and dissemination to all third parties.                          
 *                                                                          
 *  This document and the software described in it are furnished under license  
 *  and may be used or copied only in accordance with the terms of such license.
 *  This document is supplied for information purposes only, is subject to      
 *  change without notice, and should not be construed as a commitment by       
 *  either eFunds Corporation or eFunds Canada Corporation. 
 */
/*
#pragma ident "@(#) shc_mbcache.cxx 1.12 16/04/07 16:16:08"
 *
 *                        MODIFICATION HISTORY                  REVIEW
 *
 *	SPR#	Who	Date	Description			Who	Date   
 * ===========================================================================
 *R008212 ztang 10Apr03	Created to support fallover in shc
 *R028271 dipa  18Jun10 Txn Statistics
 *R028557 dipa  20Sep10 Txn Statistics - few corrections
 */

/* File Number 13 */

#if defined( WIN32 )
#       define SHCDLLEXPORT __declspec(dllexport)
#else
#       define SHCDLLEXPORT
#endif


#include <stdio.h>
#include <oasis.h>
#include <mb.h>
#include <ist_otrace.h>
#include <shc.h>
#include <oasisenv.h>
#include <stl/vector.h>
#include <ShcHelper.h>
#include <ShcMsgCache.h>
//R028271 >>>
#include <TxnStat.h>
//<<< R028271


static struct ShcMsgCache *(shcMsgCache[MAX_SHC_MSG_QUEUE]);

static int shcMsgCacheCounter = 0;

static int _cacheMsg = 0;

void ShcHelper::beginCacheMsg()
{
	_cacheMsg = 1;
}

void ShcHelper::endCacheMsg()
{
	_cacheMsg = 0;
}


int ShcHelper::cache_mb_write(int dest_id, int src_id, char *msg, int len)
{
	int ret = 0;
	
	if (dest_id < 0)
	{
		OTraceError("E-SHC-013006: Total length: %d bytes messsage from %d can not be sent! [ Destination<%d> is not connected! ] \n", len, src_id, dest_id);
		return (-1);
	}
	
	if (_cacheMsg)
	{
		struct ShcMsgCache *oneCacheEntry;
		
		oneCacheEntry = new (struct ShcMsgCache);
		oneCacheEntry->dest_id = dest_id;
		oneCacheEntry->src_id = src_id;
		oneCacheEntry->amsg = new char[len];
		memcpy(oneCacheEntry->amsg, msg, len);
		oneCacheEntry->len = len;
		
		shcMsgCache[shcMsgCacheCounter++] = oneCacheEntry;
		OTraceDebug("D-SHC-013001: msg from %d to %d len %d cached\n", src_id, dest_id, len);
	}
	else
	{

		if (strlen(((struct  shcmsg *)msg)->shclog_id))
			TxnStatReport(((struct shcmsg *)msg)->shclog_id,TS_SHC,TSR_SEND,((struct  shcmsg *)msg)->msgtype,
									((struct  shcmsg *)msg)->respcode,dest_id); //R028557
		else
			TxnStatReport(((struct shcmsg *)(((struct istadvice*)msg)->buf))->shclog_id,
								TS_SHC,TSR_SEND,
								((struct shcmsg *)(((struct istadvice*)msg)->buf))->msgtype,
								0,dest_id);

		if (mb_write(dest_id, src_id, msg, len) < 0)
		{
			OTraceError("E-SHC-013002:    action : unable to send to %s[%d]\n",
			 	mbMailBoxName(dest_id), dest_id);
			ret = -1;
		}
	}		
	return ret;
}

int ShcHelper::flush_mb_cache()
{
	int ret = 0;
	struct ShcMsgCache *oneCacheEntry;
	
	if (delaySendCachedMsg)
	{
		//Leave the messages to be sent next time when flushing
		delaySendCachedMsg = 0;
		return 0;
	}
	for (int i=0; i<shcMsgCacheCounter; i++)
	{
		oneCacheEntry = shcMsgCache[i];

		if (strlen(((struct  shcmsg *)oneCacheEntry->amsg)->shclog_id))
		{
			TxnStatReport(((struct  shcmsg *)oneCacheEntry->amsg)->shclog_id,
						TS_SHC,TSR_SEND,
						((struct  shcmsg *)oneCacheEntry->amsg)->msgtype, 
						((struct  shcmsg *)oneCacheEntry->amsg)->respcode, //R028557
						oneCacheEntry->dest_id);
			mb_set_tid(((struct  shcmsg *)oneCacheEntry->amsg)->shclog_id, strlen(((struct  shcmsg *)oneCacheEntry->amsg)->shclog_id));
		}
		else
		{
			TxnStatReport(((struct shcmsg *)((struct istadvice *)oneCacheEntry->amsg)->buf)->shclog_id,
						TS_SHC,TSR_SEND,
						((struct shcmsg *)((struct istadvice *)oneCacheEntry->amsg)->buf)->msgtype,
						0,oneCacheEntry->dest_id);
		}

		if (mb_write(oneCacheEntry->dest_id, oneCacheEntry->src_id,
					oneCacheEntry->amsg, oneCacheEntry->len) < 0)
		{
			OTraceError("E-SHC-013003:    action : unable to send to %s[%d]\n",
			 	mbMailBoxName(oneCacheEntry->dest_id), oneCacheEntry->dest_id);
			ret = -1;
		}
		else
		{
			OTraceDebug("D-SHC-013004: msg from %d to %d len %d sent\n", 
				oneCacheEntry->src_id, oneCacheEntry->dest_id, 
				oneCacheEntry->len);
		}
		delete[] oneCacheEntry->amsg;
		delete oneCacheEntry;
	}
	
	shcMsgCacheCounter = 0;
	return ret;
}

void ShcHelper::reset_mb_cache()
{
	struct ShcMsgCache *oneCacheEntry;
	
	for (int i=0; i<shcMsgCacheCounter; i++)
	{
		oneCacheEntry = shcMsgCache[i];
		delete[] oneCacheEntry->amsg;
		delete oneCacheEntry;
	}
	delaySendCachedMsg = 0;
	shcMsgCacheCounter = 0;
}



