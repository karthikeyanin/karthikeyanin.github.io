static char _ShcDkeHelper_cxx_what[] = "@(#) ShcDkeHelper.cxx 1.17.2.3 16/08/02 01:47:08";

/*
 *  Copyright (C) 2004 eFunds Corporation ("eFunds").  All Rights Reserved.     
 *  eFunds Canada Corporation is an authorized user.                            
 *                                                                              
 *  IST is a registered trademark of eFunds Corporation.  Other brand or        
 *  product names are trademarks or registered trademarks of their respective   
 *  holders.                                                                    
 *                                                                              
 *  The information contained herein is the unpublished proprietary property    
 *  of eFunds.  Except as specifically authorized in writing by eFunds, the     
 *  holder of this document shall: i) keep all information contained herein     
 *  confidential, and ii) protect the information, in whole or in part, from    
 *  disclosure and dissemination to all third parties.                          
 *                                                                          
 *  This document and the software described in it are furnished under license  
 *  and may be used or copied only in accordance with the terms of such license.
 *  This document is supplied for information purposes only, is subject to      
 *  change without notice, and should not be construed as a commitment by       
 *  either eFunds Corporation or eFunds Canada Corporation. 
 *
 *
 *                        MODIFICATION HISTORY                  REVIEW
 *
 *	SPR#	Who	Date	Description			Who	Date   
 * ===========================================================================
 *R00xxxx 20Oct03 ztang Creation
 *R016305 Emj 20Apr06 Log actual response code in security log
 *R016309 Emj 21Apr06 Updated acquirer counter functions to use acquirer bin
 *R016750 Emj 28Jun06 Fixed syslg message in shc_inc_pinerrcnt_x()
 *R018532 Emj 30Nov06 DSwitch support for triggers
 *R018276 pve 05Feb07 Dswitch logging changes
 *R021863 sks 30Oct07 interac fix,increase issuer key counter for mac error,dynamic sql pan mask
 *R023231 Ram 23May08 The SDK header should refer to external header
 *R027124 vmp 21Aug09 Added code to reset trigger counter after successful 810 Key exchange response
 */
/* File Number 23 */

#include <stdio.h>
#include <string.h>
#include <ctype.h>
#include <oasis.h>
#include <oasisenv.h>
#include <security.h>
#include <ist_otrace.h>
#include <shc.h>
#include <isttrigger.h>
#include <ic/ic_bin.h>
#include <ShcDKEHelper.h>
#include <shcfmt.h>
#include <ShcBin.h>
#include <ShcHelper.h>	//	---	R023231
#include <ShcKeyHelper.h>
#include <ShcAppBase.h>

/*------------------------------------------------------------------------*
 *      Thresold & Counter(s)
 *========================================================================     
 *
 * ACQUIRER SIDE
 *
 *(1)  KPEa Change Frequency
 *     Number of times KPEa used since last change
 *
 *(2)  Invalid PIN Block Threshold
 *     Number of PIN Block errors since last KPEa change
 *
 *(3)  KMACa Change Frequency
 *     Number of times KMACa used since last change
 *
 *(4)  MAC-Not-Verified Threshold
 *     Number of MAC erros since last KMACa change
 *
 *(5)  KMEa Change Frequency
 *     Number of times KMEa used since last change
 *
 *(6)  CMS Time-out error operator message threshold 
 *     Number of CMS Time-out errors since last message to operator 
 *
 *(7)  Key Change rejected error operator message threshold 
 *     Number of Key change rejections since last message to operator 
 *
 *(8)  MAC error operator message threshold
 *     Number MAC errors since last message to operator 
 *	   
 *(9)  Key conveyance error operator message threshold 
 *     Number of Key conveyance errors since last message to operator 
 *
 *(10)  Key sync error operator message threshold   
 *     Number of KPE sync errors since last message to operator
 *
 *(11) Key sync error operator message threshold   
 *     Number of KMAC sync errors since last message to operator
 *
 *(12) Key sync error operator message threshold   
 *     Number of KME sync errors since last message to operator
 *
 * 
 * ISSUER SIDE
 *
 *(13) MAC error operator message threshold
 *     Number MAC errors since last message to operator 
 *
 *(14) Key conveyance error operator message threshold 
 *     Number of Key conveyance errors since last message to operator 
 *
 *(15) Key sync error operator message threshold   
 *     Number of KPE sync errors since last message to operator
 *
 *(16) Key sync error operator message threshold   
 *     Number of KMAC sync errors since last message to operator
 *
 *(17) Key sync error operator message threshold   
 *     Number of KME sync errors since last message to operator
 *
 *(18) KPEi Change Frequency
 *     Number of times KPEi used since last change
 *------------------------------------------------------------------------*/
/*------------------------------------------------------------------------*
 * Define Block  
 *------------------------------------------------------------------------*/
/*
 * Dynamic Key Exchange Related
 */
#define KPE_COUNTER_INDEX					1	
#define PIN_ERROR_COUNTER_INDEX				2	
#define KMAC_COUNTER_INDEX					3	
#define MAC_ERROR_COUNTER_INDEX				4	
#define KME_COUNTER_INDEX					5	

#define KPE_ISS_COUNTER_INDEX			    18

/*
 * Operator Message Related
 */
#define CMS_TIMEOUT_COUNTER_INDEX			6	
#define KEY_REJECT_COUNTER_INDEX			7	
#define AMAC_ERROR_COUNTER_INDEX			8	
#define AKEY_CONV_ERROR_COUNTER_INDEX		9	
#define AKPE_SYNC_ERROR_COUNTER_INDEX		10	
#define AKMAC_SYNC_ERROR_COUNTER_INDEX		11	
#define AKME_SYNC_ERROR_COUNTER_INDEX		12	
#define IMAC_ERROR_COUNTER_INDEX			13	
#define IKEY_CONV_ERROR_COUNTER_INDEX		14	
#define IKPE_SYNC_ERROR_COUNTER_INDEX		15	
#define IKMAC_SYNC_ERROR_COUNTER_INDEX		16	
#define IKME_SYNC_ERROR_COUNTER_INDEX		17	
#define KPE_TIMER_INDEX				19
#define KMAC_TIMER_INDEX			20

#define INCOMMING_MSG_RESPCODE_ERROR		100

/*------------------------------------------------------------------------*
 * Utility Function Block  
 *------------------------------------------------------------------------*/
int ShcDKEHelper::netid_to_trigid(char *issbin, char *nettrigid, size_t nettrigid_size)
{
    if(issbin)
    {
         ICBin_rjfy( (ICBINp) issbin, (ICBINp) issbin);
		 
         snprintf(nettrigid, nettrigid_size, "%10sNET       ", issbin);
    }
    else
	{
		                   /*01234567890123456789*/
         sprintf(nettrigid, "          NET       ");
	}
return 0 ; /* R005156 */
}

/*------------------------------------------------------------------------*
 * (1) KPE (acquirer) Function Block  
 *------------------------------------------------------------------------*/
int ShcDKEHelper::shc_inc_kpecnt(bin_t issbin)
{
	char nettrigid[21]={0};
	bin_t userBinId;
	char institutionId[11];

	char funcname[]="shc_inc_kepcnt";

	shc_tracein(funcname);

    shc_internalBin2ExternalBin(institutionId, userBinId, issbin);

	netid_to_trigid(userBinId, nettrigid, sizeof(nettrigid));	
	isttrig_inccntval(institutionId, nettrigid, KPE_COUNTER_INDEX);

	shc_traceout(funcname);

	return 0;
}


int ShcDKEHelper::shc_reset_kpecnt(bin_t issbin)
{
	char nettrigid[21]={0};
	char funcname[]="shc_reset_kpecnt";
	bin_t userBinId;
	char institutionId[11];

	shc_tracein(funcname);

    shc_internalBin2ExternalBin(institutionId, userBinId, issbin);

	netid_to_trigid(userBinId, nettrigid, sizeof(nettrigid));	
	isttrig_resetcnt(institutionId, nettrigid, KPE_COUNTER_INDEX);

	shc_traceout(funcname);
	return 0;
}

int ShcDKEHelper::shc_reset_mackey_timer(bin_t issbin)
{
	char nettrigid[21]={0};
	char funcname[]="shc_reset_mac_timer";
	bin_t userBinId;
	char institutionId[11];

	shc_tracein(funcname);

    shc_internalBin2ExternalBin(institutionId, userBinId, issbin);

	netid_to_trigid(userBinId, nettrigid, sizeof(nettrigid));
	isttrig_resetcnt(institutionId, nettrigid, KMAC_TIMER_INDEX);

	shc_traceout(funcname);
	return 0;
}


int ShcDKEHelper::shc_reset_pinkey_timer(bin_t issbin)
{
	char nettrigid[21]={0};
	char funcname[]="shc_reset_pin_timer";
	bin_t userBinId;
	char institutionId[11];

	shc_tracein(funcname);

    shc_internalBin2ExternalBin(institutionId, userBinId, issbin);

	netid_to_trigid(userBinId, nettrigid, sizeof(nettrigid));
	isttrig_resetcnt(institutionId, nettrigid, KPE_TIMER_INDEX);

	shc_traceout(funcname);
	return 0;
}


/* R009862 */

/*------------------------------------------------------------------------*
 * (18) KPE (Issuer) Function Block  
 *------------------------------------------------------------------------*/
int ShcDKEHelper::shc_inc_kpeisscnt(bin_t issbin)
{
	char nettrigid[21]={0};
	bin_t userBinId;
	char institutionId[11];

	char funcname[]="shc_inc_kpeisscnt";

	shc_tracein(funcname);

    shc_internalBin2ExternalBin(institutionId, userBinId, issbin);

	netid_to_trigid(userBinId, nettrigid, sizeof(nettrigid));	
	isttrig_inccntval(institutionId, nettrigid, KPE_ISS_COUNTER_INDEX);

	shc_traceout(funcname);

	return 0;
}


int ShcDKEHelper::shc_reset_kpeisscnt(bin_t issbin)
{
	char nettrigid[21]={0};
	char funcname[]="shc_reset_kpeisscnt";
	bin_t userBinId;
	char institutionId[11];

	shc_tracein(funcname);

    shc_internalBin2ExternalBin(institutionId, userBinId, issbin);

	netid_to_trigid(userBinId, nettrigid, sizeof(nettrigid));	
	isttrig_resetcnt(institutionId, nettrigid, KPE_ISS_COUNTER_INDEX);

	shc_traceout(funcname);
	return 0;
}



/*------------------------------------------------------------------------*
 * (2) PIN Error Function Block  
 *------------------------------------------------------------------------*/
int ShcDKEHelper::shc_inc_pinerrcnt(bin_t issbin)
{
	char nettrigid[21]={0};
	char funcname[]="shc_inc_pinerrcnt";
	bin_t userBinId;
	char institutionId[11];

	shc_tracein(funcname);

    shc_internalBin2ExternalBin(institutionId, userBinId, issbin);

	netid_to_trigid(userBinId, nettrigid, sizeof(nettrigid));	
	isttrig_inccntval(institutionId, nettrigid, PIN_ERROR_COUNTER_INDEX);

	shc_traceout(funcname);
	return 0;
}

int ShcDKEHelper::shc_inc_pinerrcnt_x( ShcmsgHeader *header )
{
	char 	nettrigid[21]={0};
	char 	funcname[]="shc_inc_pinerrcnt_x";
	bin_t	issbin;

	strncpy(issbin, header->issShcBin->binPkg->bin.userbinid, sizeof(bin_t) - 1);
	issbin[sizeof(bin_t) - 1] = '\0';

	shc_tracein(funcname);

	netid_to_trigid(issbin, nettrigid, sizeof(nettrigid));	
	isttrig_inccntval(header->issShcBin->binPkg->bin.institutionid, nettrigid, PIN_ERROR_COUNTER_INDEX);

	syslg("E-SHC-023007: Invalid Pin Block Error. Inst %s Bin %s\n",	//	R018276
						header->issShcBin->binPkg->bin.institutionid, 
						header->issShcBin->binPkg->bin.userbinid);
	shc_hsmerror_log( &header->msg, funcname );

	shc_traceout(funcname);
	return 0;
}


int ShcDKEHelper::shc_reset_pinerrcnt(bin_t issbin)
{
	char nettrigid[21]={0};
	char funcname[]="shc_reset_pinerrcnt";
	bin_t userBinId;
	char institutionId[11];

	shc_tracein(funcname);

    shc_internalBin2ExternalBin(institutionId, userBinId, issbin);

	netid_to_trigid(userBinId, nettrigid, sizeof(nettrigid));	
	isttrig_resetcnt(institutionId, nettrigid, PIN_ERROR_COUNTER_INDEX);

	shc_traceout(funcname);
	return 0;
}
/*------------------------------------------------------------------------*
 * (3) KMAC Function Block  
 *------------------------------------------------------------------------*/
int ShcDKEHelper::shc_inc_kmaccnt(bin_t issbin)
{
	char nettrigid[21]={0};
	char funcname[]="shc_inc_kmaccnt";
	bin_t userBinId;
	char institutionId[11];

	shc_tracein(funcname);

    shc_internalBin2ExternalBin(institutionId, userBinId, issbin);

	netid_to_trigid(userBinId, nettrigid, sizeof(nettrigid));	
	isttrig_inccntval(institutionId, nettrigid, KMAC_COUNTER_INDEX);

	shc_traceout(funcname);
	return 0;
}


int ShcDKEHelper::shc_reset_kmaccnt(bin_t issbin)
{
	char nettrigid[21]={0};
	char funcname[]="shc_reset_kmaccnt";
	bin_t userBinId;
	char institutionId[11];

	shc_tracein(funcname);

    shc_internalBin2ExternalBin(institutionId, userBinId, issbin);

	netid_to_trigid(userBinId, nettrigid, sizeof(nettrigid));	
	isttrig_resetcnt(institutionId, nettrigid, KMAC_COUNTER_INDEX);

	shc_traceout(funcname);
	return 0;
}
/*------------------------------------------------------------------------*
 * (4) MAC Error Function Block  
 *------------------------------------------------------------------------*/
int ShcDKEHelper::shc_inc_macerrcnt(bin_t issbin)
{
	char nettrigid[21]={0};
	char funcname[]="shc_inc_macerrcnt";
	bin_t userBinId;
	char institutionId[11];

	shc_tracein(funcname);

    shc_internalBin2ExternalBin(institutionId, userBinId, issbin);

	netid_to_trigid(userBinId, nettrigid, sizeof(nettrigid));	
	isttrig_inccntval(institutionId, nettrigid, MAC_ERROR_COUNTER_INDEX);

	shc_traceout(funcname);

	shc_inc_amerrcnt(issbin);

	return 0;
}
int ShcDKEHelper::shc_inc_macerrcnt_x( ShcmsgHeader *header )
{
	return (shc_inc_macerrcnt(header, header->msg.respcode));
}

int ShcDKEHelper::shc_inc_macerrcnt( ShcmsgHeader *header, int respcode )
{
	/*
	 *	R004649
	 */

	char 	nettrigid[21]={0};
	char 	funcname[]="shc_inc_macerrcnt";
	bin_t	issbin;

	strncpy(issbin, header->issShcBin->binPkg->bin.userbinid, sizeof(bin_t) - 1);
	issbin[sizeof(bin_t) - 1] = '\0';

	shc_tracein(funcname);

	netid_to_trigid(issbin, nettrigid, sizeof(nettrigid));	
	isttrig_inccntval(header->issShcBin->binPkg->bin.institutionid, nettrigid, MAC_ERROR_COUNTER_INDEX);

	shc_traceout(funcname);

	shc_inc_amerrcnt(header, respcode);

	return 0;
}

int ShcDKEHelper::shc_reset_macerrcnt(bin_t issbin)
{
	char nettrigid[21]={0};
	char funcname[]="shc_reset_macerrcnt";
	bin_t userBinId;
	char institutionId[11];

	shc_tracein(funcname);

    shc_internalBin2ExternalBin(institutionId, userBinId, issbin);

	netid_to_trigid(userBinId, nettrigid, sizeof(nettrigid));	
	isttrig_resetcnt(institutionId, nettrigid, MAC_ERROR_COUNTER_INDEX);

	shc_traceout(funcname);
	return 0;
}
/*------------------------------------------------------------------------*
 * (5) KME Function Block  
 *------------------------------------------------------------------------*/
int ShcDKEHelper::shc_inc_kmecnt(bin_t issbin)
{
	char nettrigid[21]={0};
	char funcname[]="shc_inc_kmecnt";
	bin_t userBinId;
	char institutionId[11];

	shc_tracein(funcname);

    shc_internalBin2ExternalBin(institutionId, userBinId, issbin);

	netid_to_trigid(userBinId, nettrigid, sizeof(nettrigid));	
	isttrig_inccntval(institutionId, nettrigid, KME_COUNTER_INDEX);

	shc_traceout(funcname);
	return 0;
}

int ShcDKEHelper::shc_reset_kmecnt(bin_t issbin)
{
	char nettrigid[21]={0};
	char funcname[]="shc_reset_kmecnt";
	bin_t userBinId;
	char institutionId[11];

	shc_tracein(funcname);

    shc_internalBin2ExternalBin(institutionId, userBinId, issbin);

	netid_to_trigid(userBinId, nettrigid, sizeof(nettrigid));	
	isttrig_resetcnt(institutionId, nettrigid, KME_COUNTER_INDEX);

	shc_traceout(funcname);

	return 0;
}


/*------------------------------------------------------------------------*
 * (6) CMS Timeout Operator Message Threshold  Function Block  
 *------------------------------------------------------------------------*/
int ShcDKEHelper::shc_inc_cmstocnt(bin_t issbin)
{
	char nettrigid[21]={0};
	char funcname[]="shc_inc_cmstocnt";
	bin_t userBinId;
	char institutionId[11];

	shc_tracein(funcname);

    shc_internalBin2ExternalBin(institutionId, userBinId, issbin);

	netid_to_trigid(userBinId, nettrigid, sizeof(nettrigid));	
	isttrig_inccntval(institutionId, nettrigid, CMS_TIMEOUT_COUNTER_INDEX);

	shc_traceout(funcname);
	return 0;
}

int ShcDKEHelper::shc_inc_cmstocnt_x( ShcmsgHeader *header )
{
	/*
	 *	R004649
	 */

	char 	nettrigid[21]={0};
	char 	funcname[]="shc_inc_cmstocnt_x";
	bin_t	issbin;
	char	loginfo[255];
	bin_t userBinId;
	char institutionId[11];
	//	>>>	R021863
	switch (header->msg.msgtype)
	{
		case 110:
		case 120:
		case 210:
		case 230:
		case 422:
		case 610:
		case 630:
				shc_inc_ikmacsyncerrcnt_x(header);
				break;
		default:
				break;
	}
	//	<<<	R021863

	strncpy(issbin, header->issShcBin->binPkg->bin.userbinid, sizeof(bin_t) - 1);
	issbin[sizeof(bin_t) - 1] = '\0';

	shc_tracein(funcname);

	netid_to_trigid(issbin, nettrigid, sizeof(nettrigid));	
	isttrig_inccntval(header->issShcBin->binPkg->bin.institutionid, nettrigid, CMS_TIMEOUT_COUNTER_INDEX);

	strcpy( loginfo, "[Time-Out]: " );
	strcat( loginfo, funcname );
	shc_hsmerror_log( &header->msg, loginfo );

	shc_traceout(funcname);

	return 0;
}


int ShcDKEHelper::shc_reset_cmstocnt(bin_t issbin)
{
	char nettrigid[21]={0};
	char funcname[]="shc_reset_cmstocnt";
	bin_t userBinId;
	char institutionId[11];

	shc_tracein(funcname);

    shc_internalBin2ExternalBin(institutionId, userBinId, issbin);

	netid_to_trigid(userBinId, nettrigid, sizeof(nettrigid));	
	isttrig_resetcnt(institutionId, nettrigid, CMS_TIMEOUT_COUNTER_INDEX);

	shc_traceout(funcname);

	return 0;
}
/*------------------------------------------------------------------------*
 * (7) Key Reject Operator Message Threshold Function Block  
 *------------------------------------------------------------------------*/
int ShcDKEHelper::shc_inc_keyrjtcnt(bin_t issbin)
{
	char nettrigid[21]={0};
	char funcname[]="shc_inc_keyrjtcnt";
	bin_t userBinId;
	char institutionId[11];

	shc_tracein(funcname);

    shc_internalBin2ExternalBin(institutionId, userBinId, issbin);

	netid_to_trigid(userBinId, nettrigid, sizeof(nettrigid));	
	isttrig_inccntval(institutionId, nettrigid, KEY_REJECT_COUNTER_INDEX);

	syslg("E-SHC-023009: Key xchg rejected - Institution %s BIN %s\n", institutionId, userBinId);	/* R004611, R018276 */

	shc_traceout(funcname);

	return 0;
}

int ShcDKEHelper::shc_inc_keyrjtcnt_x( ShcmsgHeader *header )
{
	/*
	 *	R004649
	 */

	char 	nettrigid[21]={0};
	char 	funcname[]="shc_inc_keyrjtcnt_x";
	bin_t	issbin;

	strncpy(issbin, header->issShcBin->binPkg->bin.networkid, sizeof(bin_t) - 1);
	issbin[sizeof(bin_t) - 1] = '\0';

	shc_tracein(funcname);

	netid_to_trigid(header->issShcBin->binPkg->bin.userbinid, nettrigid, sizeof(nettrigid));	
	isttrig_inccntval(header->issShcBin->binPkg->bin.institutionid, nettrigid, KEY_REJECT_COUNTER_INDEX);

	syslg("E-SHC-023011: Key xchg rejected - Institution %s BIN %s\n",	//	R018276
								 header->issShcBin->binPkg->bin.institutionid,
								 header->issShcBin->binPkg->bin.userbinid);

	shc_hsmerror_log( &header->msg, funcname );

	shc_traceout(funcname);


	return 0;
}

int ShcDKEHelper::shc_reset_keyrjtcnt(bin_t issbin)
{
	char nettrigid[21]={0};
	char funcname[]="shc_reset_keyrjtcnt";
	bin_t userBinId;
	char institutionId[11];

	shc_tracein(funcname);

    shc_internalBin2ExternalBin(institutionId, userBinId, issbin);

	netid_to_trigid(userBinId, nettrigid, sizeof(nettrigid));	
	isttrig_resetcnt(institutionId, nettrigid, KEY_REJECT_COUNTER_INDEX);

	shc_traceout(funcname);

	return 0;
}
/*------------------------------------------------------------------------*
 * (8) Acquirer MAC NOT Verified Operator Message Threshold Function Block  
 *------------------------------------------------------------------------*/
int ShcDKEHelper::shc_inc_amerrcnt(bin_t issbin)
{
	char nettrigid[21]={0};
	char funcname[]="shc_inc_amerrcnt";
	bin_t userBinId;
	char institutionId[11];

	shc_tracein(funcname);

    shc_internalBin2ExternalBin(institutionId, userBinId, issbin);

	netid_to_trigid(userBinId, nettrigid, sizeof(nettrigid));	
	isttrig_inccntval(institutionId, nettrigid, AMAC_ERROR_COUNTER_INDEX);

	syslg("W-SHC-023013: Acquirer MAC not verified - Institution %s BIN %s\n", institutionId, userBinId);	//	R018276
					

	shc_traceout(funcname);
	return 0;
}
int ShcDKEHelper::shc_inc_amerrcnt_x( ShcmsgHeader *header )
{
	return (shc_inc_amerrcnt(header, header->msg.respcode)); 
}

int ShcDKEHelper::shc_inc_amerrcnt( ShcmsgHeader *header, int respcode)
{
	/*
	 *	R004649
	 */

	char 	nettrigid[21]={0};
	char 	funcname[]="shc_inc_amerrcnt_x";
	bin_t	issbin;

	strncpy(issbin, header->acqShcBin->binPkg->bin.networkid, sizeof(bin_t) - 1);
	issbin[sizeof(bin_t) - 1] = '\0';

	shc_tracein(funcname);

	netid_to_trigid(header->acqShcBin->binPkg->bin.userbinid, nettrigid, sizeof(nettrigid));	
	isttrig_inccntval(header->acqShcBin->binPkg->bin.institutionid, nettrigid, AMAC_ERROR_COUNTER_INDEX);

	syslg("W-SHC-023015: Acquirer MAC not verified - Institution %s  BIN %s\n",	//	R018276
								header->acqShcBin->binPkg->bin.institutionid,
								header->acqShcBin->binPkg->bin.userbinid);

	shc_hsmerror_log( &header->msg, funcname, respcode );

	shc_traceout(funcname);
	return 0;
}


int ShcDKEHelper::shc_reset_amerrcnt(bin_t issbin)
{
	char nettrigid[21]={0};
	char funcname[]="shc_reset_amerrcnt";
	bin_t userBinId;
	char institutionId[11];

	shc_tracein(funcname);

    shc_internalBin2ExternalBin(institutionId, userBinId, issbin);

	netid_to_trigid(userBinId, nettrigid, sizeof(nettrigid));	
	isttrig_resetcnt(institutionId, nettrigid, AMAC_ERROR_COUNTER_INDEX);

	shc_traceout(funcname);

	return 0;
}
/*--------------------------------------------------------------------------*
 * (9) Acquirer KEY Conveyance Error Operator Message Threshold Function Block  
 *--------------------------------------------------------------------------*/
int ShcDKEHelper::shc_inc_akconverrcnt(bin_t issbin)
{
	char nettrigid[21]={0};
	char funcname[]="shc_inc_akconverrcnt";
	bin_t userBinId;
	char institutionId[11];

	shc_tracein(funcname);

    shc_internalBin2ExternalBin(institutionId, userBinId, issbin);

	netid_to_trigid(userBinId, nettrigid, sizeof(nettrigid));	
	isttrig_inccntval(institutionId, nettrigid, AKEY_CONV_ERROR_COUNTER_INDEX);

	syslg("E-SHC-023017: Acquirer key conveyance err - Institution %s BIN %s\n",	//	R018276
								institutionId, userBinId);/* R004611 */

	shc_traceout(funcname);

	return 0;
}

int ShcDKEHelper::shc_inc_akconverrcnt_x( ShcmsgHeader *header )
{
	char 	nettrigid[21]={0};
	char 	funcname[]="shc_inc_akconverrcnt_x";
	bin_t	issbin;

	strncpy(issbin, header->acqShcBin->binPkg->bin.networkid, sizeof(bin_t) - 1);
	issbin[sizeof(bin_t) - 1] = '\0';

	shc_tracein(funcname);

	netid_to_trigid(header->acqShcBin->binPkg->bin.userbinid, nettrigid, sizeof(nettrigid));	
	isttrig_inccntval(header->acqShcBin->binPkg->bin.institutionid, nettrigid, AKEY_CONV_ERROR_COUNTER_INDEX);

	syslg("E-SHC-023019: Acquirer key conveyance err - Institution %s BIN %s\n",	//	R018276
								header->acqShcBin->binPkg->bin.institutionid,
								header->acqShcBin->binPkg->bin.userbinid);

	shc_hsmerror_log( &header->msg, funcname );

	shc_traceout(funcname);

	return 0;
}

int ShcDKEHelper::shc_reset_akconverrcnt(bin_t issbin)
{
	char nettrigid[21]={0};
	char funcname[]="shc_reset_akconverrcnt";
	bin_t userBinId;
	char institutionId[11];

	shc_tracein(funcname);

    shc_internalBin2ExternalBin(institutionId, userBinId, issbin);

	netid_to_trigid(userBinId, nettrigid, sizeof(nettrigid));	
	isttrig_resetcnt(institutionId, nettrigid, AKEY_CONV_ERROR_COUNTER_INDEX);

	shc_traceout(funcname);

	return 0;
}
/*----------------------------------------------------------------------*
 * (10) Acquirer KPE Sync Error Operator Message Threshold Function Block  
 *----------------------------------------------------------------------*/

int ShcDKEHelper::shc_inc_akpesyncerrcnt(bin_t issbin)
{	
	char nettrigid[21]={0};
	char funcname[]="shc_inc_akpesyncerrcnt";
	bin_t userBinId;
	char institutionId[11];

	shc_tracein(funcname);

    shc_internalBin2ExternalBin(institutionId, userBinId, issbin);

	netid_to_trigid(userBinId, nettrigid, sizeof(nettrigid));	
	isttrig_inccntval(institutionId, nettrigid, AKPE_SYNC_ERROR_COUNTER_INDEX);

	syslg("E-SHC-023021: Acquirer KPE sync. error - Institution %s BIN %s\n",		//	R018276
									institutionId, nettrigid);	/* R004611 */

	shc_traceout(funcname);

	return 0;
}

int ShcDKEHelper::shc_inc_akpesyncerrcnt_x( ShcmsgHeader *header )
{	
	/* 
	 *	R004649 
	 */

	char	nettrigid[21]={0};
	char 	funcname[]="shc_inc_akpesyncerrcnt_x";
	bin_t 	issbin;

	strncpy(issbin, header->acqShcBin->binPkg->bin.networkid, sizeof(bin_t) - 1);
	issbin[sizeof(bin_t) - 1] = '\0';

	shc_tracein(funcname);

	netid_to_trigid(header->acqShcBin->binPkg->bin.userbinid, nettrigid, sizeof(nettrigid));	
	isttrig_inccntval(header->acqShcBin->binPkg->bin.institutionid, nettrigid, AKPE_SYNC_ERROR_COUNTER_INDEX);

	syslg("E-SHC-023023: Acquirer KPE sync. error - Institution %s BIN %s\n",		//	R018276
												header->acqShcBin->binPkg->bin.institutionid,
												header->acqShcBin->binPkg->bin.userbinid);
	shc_hsmerror_log( &header->msg, funcname );

	shc_traceout(funcname);

	return 0;
}


int ShcDKEHelper::shc_reset_akpesyncerrcnt(bin_t issbin)
{
	char nettrigid[21]={0};
	char funcname[]="shc_reset_akpesyncerrcnt";
	bin_t userBinId;
	char institutionId[11];

	shc_tracein(funcname);

    shc_internalBin2ExternalBin(institutionId, userBinId, issbin);

	netid_to_trigid(userBinId, nettrigid, sizeof(nettrigid));	
	isttrig_resetcnt(institutionId, nettrigid, AKPE_SYNC_ERROR_COUNTER_INDEX);

	shc_traceout(funcname);

	return 0;
}
/*----------------------------------------------------------------------*
 * (11) Acquirer KMAC Sync Error Operator Message Threshold Function Block  
 *----------------------------------------------------------------------*/
int ShcDKEHelper::shc_inc_akmacsyncerrcnt(bin_t issbin)
{
	char nettrigid[21]={0};
	char funcname[]="shc_inc_akmacsyncerrcnt";
	bin_t userBinId;
	char institutionId[11];

	shc_tracein(funcname);

    shc_internalBin2ExternalBin(institutionId, userBinId, issbin);

	netid_to_trigid(userBinId, nettrigid, sizeof(nettrigid));	
	isttrig_inccntval(institutionId, nettrigid, AKMAC_SYNC_ERROR_COUNTER_INDEX);

	syslg("E-SHC-023025: Acquirer KMAC sync. error - Institution %s BIN %s\n",	//	R018276
				institutionId, userBinId);	/* R004611 */

	shc_traceout(funcname);

	return 0;
}

int ShcDKEHelper::shc_inc_akmacsyncerrcnt_x( ShcmsgHeader *header )
{
	return (shc_inc_akmacsyncerrcnt_x(header, header->msg.respcode));
}

int ShcDKEHelper::shc_inc_akmacsyncerrcnt_x( ShcmsgHeader *header, int respcode )
{
	/*
	 *	R004649
	 */

	char 	nettrigid[21]={0};
	char 	funcname[]="shc_inc_akmacsyncerrcnt_x";
	bin_t	issbin;
	bin_t userBinId;
	char institutionId[11];

	strncpy(issbin, header->acqShcBin->binPkg->bin.networkid, sizeof(bin_t) - 1);
	issbin[sizeof(bin_t) - 1] = '\0';

	shc_tracein(funcname);

	netid_to_trigid(header->acqShcBin->binPkg->bin.userbinid, nettrigid, sizeof(nettrigid));	
	isttrig_inccntval(header->acqShcBin->binPkg->bin.institutionid, nettrigid, AKMAC_SYNC_ERROR_COUNTER_INDEX);

	syslg("E-SHC-023027: Acquirer KMAC sync. error - Institution %s BIN %s\n",	//	R018276
										header->acqShcBin->binPkg->bin.institutionid,
										header->acqShcBin->binPkg->bin.userbinid);

	shc_hsmerror_log( &header->msg, funcname, respcode );

	shc_traceout(funcname);
	return 0;
}

int ShcDKEHelper::shc_reset_akmacsyncerrcnt(bin_t issbin)
{
	char nettrigid[21]={0};
	char funcname[]="shc_reset_akmacsyncerrcnt";
	bin_t userBinId;
	char institutionId[11];

	shc_tracein(funcname);

    shc_internalBin2ExternalBin(institutionId, userBinId, issbin);

	netid_to_trigid(userBinId, nettrigid, sizeof(nettrigid));	
	isttrig_resetcnt(institutionId, nettrigid, AKMAC_SYNC_ERROR_COUNTER_INDEX);

	shc_traceout(funcname);

	return 0;
}
/*----------------------------------------------------------------------*
 * (12) Acquirer KME Sync Error Operator Message Threshold Function Block  
 *----------------------------------------------------------------------*/
int ShcDKEHelper::shc_inc_akmesyncerrcnt(bin_t issbin)
{
	char nettrigid[21]={0};
	char funcname[]="shc_inc_akmesyncerrcnt";
	bin_t userBinId;
	char institutionId[11];

	shc_tracein(funcname);

    shc_internalBin2ExternalBin(institutionId, userBinId, issbin);

	netid_to_trigid(userBinId, nettrigid, sizeof(nettrigid));	
	isttrig_inccntval(institutionId, nettrigid, AKME_SYNC_ERROR_COUNTER_INDEX);

	syslg("E-SHC-023029: Acquirer KME sync. error - Institution %s BIN %s\n", institutionId, userBinId);	/* R004611, R018276*/

	shc_traceout(funcname);

	return 0;
}

int ShcDKEHelper::shc_inc_akmesyncerrcnt_x( ShcmsgHeader *header )
{
	/*
	 *	R004649
	 */

	char 	nettrigid[21]={0};
	char 	funcname[]="shc_inc_akmesyncerrcnt_x";
	bin_t	issbin;

	strncpy(issbin, header->acqShcBin->binPkg->bin.networkid, sizeof(bin_t) - 1);
	issbin[sizeof(bin_t) - 1] = '\0';

	shc_tracein(funcname);

	netid_to_trigid(header->acqShcBin->binPkg->bin.userbinid, nettrigid, sizeof(nettrigid));	
	isttrig_inccntval(header->acqShcBin->binPkg->bin.institutionid, nettrigid, AKME_SYNC_ERROR_COUNTER_INDEX);

	syslg("E-SHC-023031: Acquirer KME sync. error - Institutionid %s BIN %s\n",	//	R018276
								header->acqShcBin->binPkg->bin.institutionid,
								header->acqShcBin->binPkg->bin.userbinid);
	shc_hsmerror_log( &header->msg, funcname );

	shc_traceout(funcname);


	return 0;
}


int ShcDKEHelper::shc_reset_akmesyncerrcnt(bin_t issbin)
{
	char nettrigid[21]={0};
	char funcname[]="shc_reset_akmesyncerrcnt";
	bin_t userBinId;
	char institutionId[11];

	shc_tracein(funcname);

    shc_internalBin2ExternalBin(institutionId, userBinId, issbin);

	netid_to_trigid(userBinId, nettrigid, sizeof(nettrigid));	
	isttrig_resetcnt(institutionId, nettrigid, AKME_SYNC_ERROR_COUNTER_INDEX);

	shc_traceout(funcname);

	return 0;
}

/*------------------------------------------------------------------------*
 * Tracing Function Block
 *------------------------------------------------------------------------*/
int ShcDKEHelper::shc_tracein(char *funcname)
{
	if( funcname)
		OTraceInfo("I-SHC-023001: Enter Function %s\n", funcname);
 return 0; /* R005156 */
}

int ShcDKEHelper::shc_traceout(char *funcname)
{
	if( funcname)
		OTraceInfo("I-SHC-023002: Leave Function %s\n", funcname);
 return 0; /* R005156 */
}
/*------------------------------------------------------------------------*
 * (13) Issuer MAC NOT Verified Operator Message Threshold Function Block  
 *------------------------------------------------------------------------*/
int ShcDKEHelper::shc_inc_imerrcnt(bin_t acqbin)
{
	char nettrigid[21]={0};
	char funcname[]="shc_inc_imerrcnt";
	bin_t userBinId;
	char institutionId[11];

	shc_tracein(funcname);
    shc_internalBin2ExternalBin(institutionId, userBinId, acqbin);

	netid_to_trigid(userBinId, nettrigid, sizeof(nettrigid));	

	isttrig_inccntval(institutionId, nettrigid, IMAC_ERROR_COUNTER_INDEX);

	syslg("W-SHC-023033: Issuer MAC not verified - Institution %s BIN %s\n", institutionId, userBinId);	/* R004611, R018276 */

	shc_traceout(funcname);
	return 0;
}

int ShcDKEHelper::shc_inc_imerrcnt_x( ShcmsgHeader *header )
{
	/*
	 *	R004649
	 */

	char 	nettrigid[21]={0};
	char 	funcname[]="shc_inc_imerrcnt_x";
	bin_t	acqbin;

	strncpy(acqbin, header->acqShcBin->binPkg->bin.networkid, sizeof(bin_t) - 1);
	acqbin[sizeof(bin_t) - 1] = '\0';

	shc_tracein(funcname);

	netid_to_trigid(header->acqShcBin->binPkg->bin.userbinid, nettrigid, sizeof(nettrigid));	
	isttrig_inccntval(header->acqShcBin->binPkg->bin.institutionid, nettrigid, IMAC_ERROR_COUNTER_INDEX);

	syslg("W-SHC-023035: Issuer MAC not verified - Institution %s BIN %s\n",	//	R018276
										header->acqShcBin->binPkg->bin.institutionid,
										header->acqShcBin->binPkg->bin.userbinid);

	shc_hsmerror_log( &header->msg, funcname );

	shc_traceout(funcname);
	return 0;
}


int ShcDKEHelper::shc_reset_imerrcnt(bin_t acqbin)
{
	char nettrigid[21]={0};
	char funcname[]="shc_reset_imerrcnt";
	bin_t userBinId;
	char institutionId[11];

	shc_tracein(funcname);

    shc_internalBin2ExternalBin(institutionId, userBinId, acqbin);

	netid_to_trigid(userBinId, nettrigid, sizeof(nettrigid));	
	isttrig_resetcnt(institutionId, nettrigid, IMAC_ERROR_COUNTER_INDEX);

	shc_traceout(funcname);

	return 0;
}
/*--------------------------------------------------------------------------*
 * (14) Issuer KEY Conveyance Error Operator Message Threshold Function Block  
 *--------------------------------------------------------------------------*/
int ShcDKEHelper::shc_inc_ikconverrcnt(bin_t acqbin)
{
	char nettrigid[21]={0};
	char funcname[]="shc_inc_ikconverrcnt";
	bin_t userBinId;
	char institutionId[11];

	shc_tracein(funcname);

    shc_internalBin2ExternalBin(institutionId, userBinId, acqbin);

	netid_to_trigid(userBinId, nettrigid, sizeof(nettrigid));	
	isttrig_inccntval(institutionId, nettrigid, IKEY_CONV_ERROR_COUNTER_INDEX);

	syslg("E-SHC-023036: Issuer Key conveyance err - Institution %s BIN %s\n", institutionId, userBinId);	/* R004611, R018276 */

	shc_traceout(funcname);

	return 0;
}

int ShcDKEHelper::shc_inc_ikconverrcnt_x( ShcmsgHeader *header )
{
	char 	nettrigid[21]={0};
	char 	funcname[]="shc_inc_ikconverrcnt_x";
	bin_t	acqbin;
	bin_t userBinId;
	char institutionId[11];

	strncpy(acqbin, header->acqShcBin->binPkg->bin.networkid, sizeof(bin_t) - 1);
	acqbin[sizeof(bin_t) - 1] = '\0';

	shc_tracein(funcname);

	netid_to_trigid(header->acqShcBin->binPkg->bin.userbinid, nettrigid, sizeof(nettrigid));	
	isttrig_inccntval(header->acqShcBin->binPkg->bin.institutionid, nettrigid, IKEY_CONV_ERROR_COUNTER_INDEX);

	syslg("E-SHC-023038: Issuer Key conveyance err - Institution %s Bin %s\n",	//	R018276
								header->acqShcBin->binPkg->bin.institutionid,
								header->acqShcBin->binPkg->bin.userbinid);
	shc_hsmerror_log( &header->msg, funcname );

	shc_traceout(funcname);

	return 0;
}


int ShcDKEHelper::shc_reset_ikconverrcnt(bin_t acqbin)
{
	char nettrigid[21]={0};
	char funcname[]="shc_reset_ikconverrcnt";
	bin_t userBinId;
	char institutionId[11];

	shc_tracein(funcname);

    shc_internalBin2ExternalBin(institutionId, userBinId, acqbin);

	netid_to_trigid(userBinId, nettrigid, sizeof(nettrigid));	
	isttrig_resetcnt(institutionId, nettrigid, IKEY_CONV_ERROR_COUNTER_INDEX);

	shc_traceout(funcname);

	return 0;
}
/*----------------------------------------------------------------------*
 * (15) Issuer KPE Sync Error Operator Message Threshold Function Block  
 *----------------------------------------------------------------------*/
int ShcDKEHelper::shc_inc_ikpesyncerrcnt(bin_t acqbin)
{
	char nettrigid[21]={0};
	char funcname[]="shc_inc_ikpesyncerrcnt";
	bin_t userBinId;
	char institutionId[11];

	shc_tracein(funcname);

    shc_internalBin2ExternalBin(institutionId, userBinId, acqbin);

	netid_to_trigid(userBinId, nettrigid, sizeof(nettrigid));	
	isttrig_inccntval(institutionId, nettrigid, IKPE_SYNC_ERROR_COUNTER_INDEX);

	syslg("E-SHC-023040: Issuer KPE sync. error - Institution %s BIN %s\n", institutionId, userBinId);	/* R004611, R018276 */

	shc_traceout(funcname);
	return 0;
}

int ShcDKEHelper::shc_inc_ikpesyncerrcnt_x( ShcmsgHeader *header )
{
	/*
	 *	R004649
	 */

	char 	nettrigid[21]={0};
	char 	funcname[]="shc_inc_ikpesyncerrcnt_x";
	bin_t	acqbin;

	strncpy(acqbin, header->acqShcBin->binPkg->bin.networkid, sizeof(bin_t) - 1);
	acqbin[sizeof(bin_t) - 1] = '\0';

	shc_tracein(funcname);

	netid_to_trigid(header->acqShcBin->binPkg->bin.userbinid, nettrigid, sizeof(nettrigid));	
	isttrig_inccntval(header->acqShcBin->binPkg->bin.institutionid, nettrigid, IKPE_SYNC_ERROR_COUNTER_INDEX);

	syslg("E-SHC-023042: Issuer KPE sync. error - Institution %s BIN %s\n",		//	R018276
								header->acqShcBin->binPkg->bin.institutionid,
								header->acqShcBin->binPkg->bin.userbinid);

	shc_hsmerror_log( &header->msg, funcname );

	shc_traceout(funcname);
	return 0;
}


int ShcDKEHelper::shc_reset_ikpesyncerrcnt(bin_t acqbin)
{
	char nettrigid[21]={0};
	char funcname[]="shc_reset_ikpesyncerrcnt";
	bin_t userBinId;
	char institutionId[11];

	shc_tracein(funcname);

    shc_internalBin2ExternalBin(institutionId, userBinId, acqbin);

	netid_to_trigid(userBinId, nettrigid, sizeof(nettrigid));	
	isttrig_resetcnt(institutionId, nettrigid, IKPE_SYNC_ERROR_COUNTER_INDEX);

	shc_traceout(funcname);

	return 0;
}
/*----------------------------------------------------------------------*
 * (16) Issuer KMAC Sync Error Operator Message Threshold Function Block  
 *----------------------------------------------------------------------*/
int ShcDKEHelper::shc_inc_ikmacsyncerrcnt(bin_t acqbin)
{
	char nettrigid[21]={0};
	char funcname[]="shc_inc_ikmacsyncerrcnt";
	bin_t userBinId;
	char institutionId[11];

	shc_tracein(funcname);

    shc_internalBin2ExternalBin(institutionId, userBinId, acqbin);

	netid_to_trigid(userBinId, nettrigid, sizeof(nettrigid));	
	isttrig_inccntval(institutionId, nettrigid, IKMAC_SYNC_ERROR_COUNTER_INDEX);

	syslg("E-SHC-023044: Issuer KMAC sync. error - Institution %s BIN %s\n", institutionId, userBinId);	/* R004611, R018276 */

	shc_traceout(funcname);
	return 0;
}

int ShcDKEHelper::shc_inc_ikmacsyncerrcnt_x( ShcmsgHeader *header )
{
	/*
	 * 	R004649
	 */

	char 	nettrigid[21]={0};
	char 	funcname[]="shc_inc_ikmacsyncerrcnt_x";
	bin_t	acqbin;

	strncpy(acqbin, header->acqShcBin->binPkg->bin.networkid, sizeof(bin_t) - 1);
	acqbin[sizeof(bin_t) - 1] = '\0';

	shc_tracein(funcname);

	netid_to_trigid(header->acqShcBin->binPkg->bin.userbinid, nettrigid, sizeof(nettrigid));	
	isttrig_inccntval(header->acqShcBin->binPkg->bin.institutionid, nettrigid, IKMAC_SYNC_ERROR_COUNTER_INDEX);

	syslg("E-SHC-023046: Issuer KMAC sync. error - Institution %s BIN %s\n",	//	R018276
											  header->acqShcBin->binPkg->bin.institutionid,
											  header->acqShcBin->binPkg->bin.userbinid);
	shc_hsmerror_log( &header->msg, funcname );

	shc_traceout(funcname);
	return 0;
}


int ShcDKEHelper::shc_reset_ikmacsyncerrcnt(bin_t acqbin)
{
	char nettrigid[21]={0};
	char funcname[]="shc_reset_ikmacsyncerrcnt";
	bin_t userBinId;
	char institutionId[11];

	shc_tracein(funcname);

    shc_internalBin2ExternalBin(institutionId, userBinId, acqbin);

	netid_to_trigid(userBinId, nettrigid, sizeof(nettrigid));	
	isttrig_resetcnt(institutionId, nettrigid, IKMAC_SYNC_ERROR_COUNTER_INDEX);

	shc_traceout(funcname);

	return 0;
}
/*----------------------------------------------------------------------*
 * (17) Issuer KME Sync Error Operator Message Threshold Function Block  
 *----------------------------------------------------------------------*/
int ShcDKEHelper::shc_inc_ikmesyncerrcnt(bin_t acqbin)
{
	char 	nettrigid[21]={0};
	char 	funcname[]="shc_inc_ikmesyncerrcnt";
	bin_t userBinId;
	char institutionId[11];

	shc_tracein(funcname);

    shc_internalBin2ExternalBin(institutionId, userBinId, acqbin);

	netid_to_trigid(userBinId, nettrigid, sizeof(nettrigid));	
	isttrig_inccntval(institutionId, nettrigid, AKME_SYNC_ERROR_COUNTER_INDEX);

	syslg("E-SHC-023048: Issuer KME sync. error - Institution %s BIN %s\n", institutionId, userBinId);	//	R018276

	shc_traceout(funcname);
	return 0;
}

int ShcDKEHelper::shc_inc_ikmesyncerrcnt_x( ShcmsgHeader *header )
{
	/*
	 *  R004649
	 */

	char 	nettrigid[21]={0};
	char 	funcname[]="shc_inc_ikmesyncerrcnt_x";
	bin_t	acqbin;
	bin_t userBinId;
	char institutionId[11];

	strncpy(acqbin, header->acqShcBin->binPkg->bin.networkid, sizeof(bin_t) - 1);
	acqbin[sizeof(bin_t) - 1] = '\0';

	shc_tracein(funcname);

	netid_to_trigid(header->acqShcBin->binPkg->bin.userbinid, nettrigid, sizeof(nettrigid));	
	isttrig_inccntval(header->acqShcBin->binPkg->bin.institutionid, nettrigid, IKME_SYNC_ERROR_COUNTER_INDEX);

	syslg("E-SHC-023050: Issuer KME sync. error - Institution %s BIN %s\n",	//	R018276
						header->acqShcBin->binPkg->bin.institutionid,
						header->acqShcBin->binPkg->bin.userbinid);
	shc_hsmerror_log( &header->msg, funcname );

	shc_traceout(funcname);
	return 0;
}


int ShcDKEHelper::shc_reset_ikmesyncerrcnt(bin_t acqbin)
{
	char nettrigid[21]={0};
	char funcname[]="shc_reset_ikmesyncerrcnt";
	bin_t userBinId;
	char institutionId[11];

	shc_tracein(funcname);

    shc_internalBin2ExternalBin(institutionId, userBinId, acqbin);

	netid_to_trigid(userBinId, nettrigid, sizeof(nettrigid));	
	isttrig_resetcnt(institutionId, nettrigid, AKME_SYNC_ERROR_COUNTER_INDEX);

	shc_traceout(funcname);

	return 0;
}

int ShcDKEHelper::shc_reset_dynamic_keys( bin_t networkid, char key_type )
{

	bin_t userBinId;
	char institutionId[11];

    shc_internalBin2ExternalBin(institutionId, userBinId, networkid);

	OTraceDebug("D-SHC-023003: Reseting dynamic keys counters\n");
	OTraceDebug("D-SHC-023004:  Institution : %s BIN     : %s\n", institutionId,userBinId);
	OTraceDebug("D-SHC-023005:  Key Type: %c\n", key_type);

	switch ( key_type )
	{
		case SH_KEYTYPE_PIN:
			shc_reset_kpecnt(networkid);
			shc_reset_pinerrcnt(networkid);
			shc_reset_kpeisscnt(networkid);//	---	R027124
			break;

		case SH_KEYTYPE_KME:
			shc_reset_kmecnt(networkid);
			break;

		case SH_KEYTYPE_MAC:
			shc_reset_kmaccnt(networkid);
			shc_reset_macerrcnt(networkid);
			break;
	
		default:
			return( -1 );
	}

	return( 0 );
}

int ShcDKEHelper::shc_hsmerror_log( struct shcmsg *msg, char *loginfo )
{
	return(shc_hsmerror_log(msg, loginfo, msg->respcode));
}

int ShcDKEHelper::shc_hsmerror_log( struct shcmsg *msg, char *loginfo, int respcode)
{
	/*
	 *	This function will be called when specific security
	 * 	errors are detected and will log the value of some
	 * 	of the fields from the shcmsg structure as per
	 * 	Interac requirements
	 */

	char    	cnvrtd_amount[32];
	char    	cnvrtd_newamount[32];
	char    	*strtime;
	char        secLogFile[255];
	time_t  	calendar;
	FILE    	*fp;

	OTraceInfo("I-SHC-023006: shc_hsmerror_log() start logging: "
		       "msgtype [%d], trace [%d], orig respcode [%d] new respcode [%d] loginfo [%s]\n",
		 		msg->msgtype, msg->trace, 
				msg->respcode, respcode, loginfo );
    memset (secLogFile, 0x00, sizeof(secLogFile));
    snprintf (secLogFile,sizeof(secLogFile), "%s", uenv_constructfile("OLOGDIR", "sys/security.err"));

 	fp = fopen( secLogFile, "a" );
    if ( fp == NULL )
    {
        syslg( "\nSystem error occured when trying to open "
            "$OLOGDIR/sys/security.err log file on HSM returned error...\n");
        return( 0 );
    }

 	time( &calendar );
 	strtime = ctime( &calendar );

 	dbm_dectochar( &msg->amount, cnvrtd_amount );
 	dbm_dectochar( &msg->new_amount, cnvrtd_newamount );

 	fprintf( fp, 	"---------------------------"
				" Begin log "
			"---------------------------"
			"\nLog date and time:\t\t\t\t%s"
			"Calling Point/Log Information:\t\t\t%s"
			"\nDetected security exception on pid:\t\t[%d]",
				strtime, 
				loginfo,
				getpid() );

	fprintf( fp,    "\n\nMessage type:\t\t\t\t\t[%d]"
			"\nProcessing code (BM 3):\t\t\t\t[%ld]"
			"\nAmount (BM  4):\t\t\t\t\t[%s]"
			"\nTransaction date (BM 7):\t\t\t[%ld]"
			"\nTransaction time (BM 7):\t\t\t[%ld]"
			"\nSystem trace audit number (BM 11):\t\t[%ld]"
			"\nOriginating member (BM 32):\t\t\t[%s]"
			"\nDestination member (BM 33):\t\t\t[%s]"
			"\nRetrieval reference number (BM 37):\t\t[%s]",
				msg->msgtype,
				msg->pcode,
				cnvrtd_amount,
				msg->trandate,
				msg->trantime,
				msg->trace,
				msg->acquirer,
				msg->forward_inst_id,
				msg->refnum);

	if (msg->respcode == respcode)
	{
		fprintf( fp, "\nResponse code (BM 39):\t\t\t\t[%d]", msg->respcode);
	}
	else
	{
		fprintf( fp, "\nOrig Response code (BM 39):\t\t\t[%d]", msg->respcode);
		fprintf( fp, "\nNew  Response code (BM 39):\t\t\t[%d]", respcode);
	}

	fprintf( fp, "\nTerminal ID. (BM 41):\t\t\t\t[%s]", msg->termid);

	fprintf( fp, 	"\nAdditional data (BM 48):\t\t\t[%s]"
			"\nSecurity related control info (BM 53):\t\t[%s]"
			"\nMessage number (BM 71):\t\t\t\t[%s]"
			"\nMessage number last (BM 72):\t\t\t[%s]"
			"\nReplacement amount (BM 95):\t\t\t[%s]"
			"\nAdditional amounts (BM 120):\t\t\t[%X] [hexa]"
			"\nMAC (BM 64/BM 128):\t\t\t\t[%X] [hexa]"
			"\nKMAC Cryptogram:\t\t\t\t[%X] [hexa]"
			"\nKME Cryptogram:\t\t\t\t\t[%X] [hexa]"
			"\nKPE Cryptogram:\t\t\t\t\t[%X] [hexa]"
			"\n----------------------------"
			" End log "
			"----------------------------\n\n",
				msg->shc_data_buffer,
				msg->sec_fmt_code,
				msg->kpe_kekcnt,
				msg->expected_kekcnt,
				cnvrtd_newamount,
				msg->pin, /* this buf houses adit amount on resp msg */
				msg->mac_value,
				msg->kmac_mfk,
				msg->kme_mfk,
				msg->kpe_mfk );
	fclose( fp );

	return( 0 );
}





