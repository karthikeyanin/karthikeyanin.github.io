/*
 *  Copyright (C) 2004 eFunds Corporation ("eFunds").  All Rights Reserved.     
 *  eFunds Canada Corporation is an authorized user.                            
 *                                                                              
 *  IST is a registered trademark of eFunds Corporation.  Other brand or        
 *  product names are trademarks or registered trademarks of their respective   
 *  holders.                                                                    
 *                                                                              
 *  The information contained herein is the unpublished proprietary property    
 *  of eFunds.  Except as specifically authorized in writing by eFunds, the     
 *  holder of this document shall: i) keep all information contained herein     
 *  confidential, and ii) protect the information, in whole or in part, from    
 *  disclosure and dissemination to all third parties.                          
 *                                                                          
 *  This document and the software described in it are furnished under license  
 *  and may be used or copied only in accordance with the terms of such license.
 *  This document is supplied for information purposes only, is subject to      
 *  change without notice, and should not be construed as a commitment by       
 *  either eFunds Corporation or eFunds Canada Corporation. 
 */
/*
#pragma ident "@(#) shc_date.cxx 1.5 20/03/25 13:13:05";
 *
 *                        MODIFICATION HISTORY                  REVIEW
 *
 *	SPR#	Who	Date	Description			Who	Date   
 * ===========================================================================
 * 2005387 qd  31jul98 Added function shc_adjust_date(), remove compile warnings
 * R001835 qd  08apr98 Use localtime instead of localtime_r
 */

//File Number 9

#if defined( WIN32 )
#       define SHCDLLEXPORT __declspec(dllexport)
#else
#       define SHCDLLEXPORT
#endif


#include <stdio.h>
#include <sys/types.h>
#include <sys/timeb.h>
#include <time.h>
#include <oasis.h>
#include <ist_otrace.h>
#include <shc.h>
#include <string.h> /* R005156 */
#include <istsafe.h>

struct	tm	shc_gmt_date = {0};		/*	global for others to use */
struct	tm	shc_local_date = {0};
struct	tm	shc_work_date = {0};	/*	contains result of last mktime() */
long		shc_current_istdate = 0;	/* ist format gmt date */
long		shc_local_istdate = 0;		/* ist format local date */
long		shc_derived_istdate = 0;
long		shc_gmt_currentdate(void);
long		shc_make_gmt(int y, int m, int d, int H, int M, int S);
long		shc_derive_date(void);
long		shc_local_currentdate();

/*
 *	Functions used during the format phase of the message regarding dates
 *
 *	All functions assume that shc_get_current_date() has been called
 *
 */
int shc_get_current_date()
{
	/*
	 *  Determine the current date in several formats
	 */
	
	struct timeb tmpTime;
	ftime(&tmpTime);
	shc_current_time = tmpTime.time;

	shc_gmt_date = *gmtime((time_t *)&shc_current_time);
	shc_local_date = *localtime((time_t *)&shc_current_time);

	shc_current_istdate = shc_gmt_currentdate();
	shc_local_istdate	= shc_local_currentdate();
	shc_current_millisecond = tmpTime.millitm;
	return(0);
}


long shc_make_gmt(int y, int m, int d, int H, int M, int S)
{
	/*
	 *	Return a gmt UNIX date.
	 *	Assumes that shc_get_current_date() has been called
	 */
	
	long	t;

	memcpy(&shc_work_date, &shc_gmt_date, sizeof(shc_work_date));
	if(y > 0)
		shc_work_date.tm_year = y - 1900;
	if(m > 0)
		shc_work_date.tm_mon = m - 1;
	if(d > 0)
		shc_work_date.tm_mday = d;
	if(H >= 0)
		shc_work_date.tm_hour = H;
	if(M >= 0)
		shc_work_date.tm_min  = M;
	if(S >= 0)
		shc_work_date.tm_sec  = S;
	
	t = mktime(&shc_work_date);
	return(t);
}


long shc_make_istdate(int y, int m, int d)
{
	/*
	 *	Get a derived date based on the year, month, day
	 *	and return as YYYYMMDD
	 *
	 *	All dates in GMT
	 */
	
	if(shc_make_gmt(y, m, d, -1, -1, -1) < 0)
		return(0);
	
	/*	Create derived date */
	shc_derive_date();
	
	return(shc_derived_istdate);
}


long shc_derive_date()
{
	/*
	 *	Take the work date (as used by other internal routines) and
	 *	create an IST date in shc_derived_date (YYYYMMDD format)
	 */
	
	shc_derived_istdate =
		(shc_work_date.tm_year + 1900) * 10000L +
		(shc_work_date.tm_mon + 1) * 100L +
		shc_work_date.tm_mday;
	
	return(shc_derived_istdate);
}


long shc_gmt_adddays(long unix_date, int ndays)
{
	unix_date = (IstSafeLong(unix_date) + (ndays * (60L * 60L * 24L))).getLong();
	shc_work_date = *gmtime((time_t *)&unix_date);
	return(shc_derive_date());
}

long shc_date_unix_to_ist(struct tm *tp, int type)
{
	if(type == 1)
		return(((IstSafeLong(tp->tm_year) + 1900) * 10000L +
		   (tp->tm_mon + 1) * 100L + tp->tm_mday)).getLong();
	else if(type == 2)
		return((IstSafeLong(tp->tm_hour) * 10000L +
		   (tp->tm_min) * 100L + tp->tm_sec)).getLong();
	else
		return(-1);
}

long shc_gmt_currentdate()
{
	return(shc_date_unix_to_ist(&shc_gmt_date, 1));
}

long shc_gmt_currenttime()
{
	return(shc_date_unix_to_ist(&shc_gmt_date, 2));
}

long shc_local_currentdate()
{
	return(shc_date_unix_to_ist(&shc_local_date, 1));
}

long shc_local_currenttime()
{
	return(shc_date_unix_to_ist(&shc_local_date, 2));
}

long shc_date_ist_to_unix(long gmt_date, long gmt_time)
{
	long	t;

	t = shc_make_gmt(gmt_date / 10000,
					 gmt_date / 100 % 100,
					 gmt_date % 100,
					 gmt_time / 10000,
					 gmt_time / 100 % 100,
					 gmt_time % 100);
	return(t);
}


long shc_make_local_date(long gmt_date, long gmt_time)
{
	/*	Given a GMT date and time in IST format return
		a local date in IST format
	*/

	long t;
	struct	tm tm;
	
	t = shc_date_ist_to_unix(gmt_date, gmt_time);
	tm = *localtime((time_t *)&t);	
	return(shc_date_unix_to_ist(&tm, 1));
}


long shc_make_local_time(long gmt_date, long gmt_time)
{
	/*
	 *	Given a GMT date and time in IST format, return the 
	 *	local time in IST format
	 */

	long t;
	struct	tm tm;
	
	t = shc_date_ist_to_unix(gmt_date, gmt_time);
	tm = *localtime((time_t *)&t);	
	return(shc_date_unix_to_ist(&tm, 2));
}

/*
 * qd 15mar96	Expand Date From YYMM Format to YYYYMM Format
 *				Note: This function does not checking the input 
 *                    So it is upto the user to setup input and
 *                    output buffers properly
 */
int shc_expand_date(char *yymm, char *yyyymm)
{
	int yy = atoi(yymm)/100;
	int cc = ((yy <= 70) ? 20 : 19);

	return(sprintf(yyyymm,"%2d%4s", cc, yymm));
}

/*
 *
 * Input:	date_in in YYYYMMDD format and ndays
 * Output:  new date after adjustment in YYYYMMDD format
 * Example: shc_adjust_date(19980731,1) return 19980801
 *
 * Note:    ndays could also be a negative number
 */
time_t shc_adjust_date(long date_in, int ndays)
{
	struct tm tm_adjust={0};
	struct tm tm_out={0};
	time_t tmp_date;
	time_t date_out;

	OTraceInfo("I-SHC-009001: Date In %ld\n", date_in);
	OTraceInfo("I-SHC-009002: Adjust %d day(s)\n", ndays);

	tm_adjust.tm_year = date_in / 10000 - 1900;
	tm_adjust.tm_mon = date_in % 10000 / 100 - 1;
	tm_adjust.tm_mday = date_in % 100 + ndays;

	tmp_date = mktime(&tm_adjust);
	tm_out = *localtime(&tmp_date); /* 27nov98 */  

	date_out = (tm_out.tm_year + 1900) * 10000L + 
			   (tm_out.tm_mon + 1) * 100L + 
			    tm_out.tm_mday;

	OTraceInfo("I-SHC-009003: Date Out %ld\n", date_out);

	return date_out;
}
/*
 * End of file shc_date.c
 */
