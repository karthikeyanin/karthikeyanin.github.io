static char _ShcKeysMRHelper_cxx_what[] = "@(#) ShcKeysMRHelper.cxx 1.7 16/02/01 15:48:47";


/*
 *  Copyright (C) 2004 eFunds Corporation ("eFunds").  All Rights Reserved.     
 *  eFunds Canada Corporation is an authorized user.                            
 *                                                                              
 *  IST is a registered trademark of eFunds Corporation.  Other brand or        
 *  product names are trademarks or registered trademarks of their respective   
 *  holders.                                                                    
 *                                                                              
 *  The information contained herein is the unpublished proprietary property    
 *  of eFunds.  Except as specifically authorized in writing by eFunds, the     
 *  holder of this document shall: i) keep all information contained herein     
 *  confidential, and ii) protect the information, in whole or in part, from    
 *  disclosure and dissemination to all third parties.                          
 *                                                                          
 *  This document and the software described in it are furnished under license  
 *  and may be used or copied only in accordance with the terms of such license.
 *  This document is supplied for information purposes only, is subject to      
 *  change without notice, and should not be construed as a commitment by       
 *  either eFunds Corporation or eFunds Canada Corporation. 
 *
 *
 *                        MODIFICATION HISTORY                  REVIEW
 *
 *	JIRA#	Who	Date	Description			Who	Date   
 * ===========================================================================
*/

/* File Number 30 */

#include <stdio.h>
#include <ShcAppBase.h>
#include <ShcKeysMRHelper.h>
#include <ist_otrace.h>

#include <ist_seg_name.h> 
#include <ist_seg_elf_id_map.h> 
#include <ist_seg_id.h> 
#include <ist_seg_msg_replication_data.h>

#include <MRServiceDefs.h>
#include <MRApplHelper.h>
#include <MRShckeysTagDefs.h>

#include <msg_repl_gd_sender.h>
#include <mb_umi.h>
#include <mb.h>
#include<switch_state_apis.h>


ShcKeysMRHelper::ShcKeysMRHelper()
{
	if (!shcApp)
		shcApp = (ShcAppBase *)shcHelperRegister.getTargetObj(SHC_ShcAppBase);

	_waitTime = 0;
	memset(_workbuf, 0, sizeof(_workbuf));

}

ShcKeysMRHelper::~ShcKeysMRHelper()
{

}


ShcKeysMRHelper *ShcKeysMRHelper::getInstance()
{
	static ShcKeysMRHelper *_instance=NULL;
	if ( !_instance )
	{
		_instance = (ShcKeysMRHelper *)shcHelperRegister.getTargetObj("ShcKeysMRHelper");
		if (!_instance)
	 		_instance = new ShcKeysMRHelper();
	}
	return _instance;
}


int ShcKeysMRHelper::sendKeyWait(struct shckey_buf *bufp, char *newkey, char *newchk, char status)
{

	int ret = -1;

	if (!getDualSite_mb())
		return ret;

	//  Set data    send to other site and wait for reponse message
	setMRDataShared(bufp, newkey, newchk, status);
	ret = sendMRMsgShared(1);
	
	return ret;
}


int ShcKeysMRHelper::sendKey(struct shckey_buf *bufp, char *newkey, char *newchk, char status)
{

	int ret = -1;

	if (!getDualSite_mb())
		return ret;

	setMRDataShared(bufp, newkey, newchk, status);
	ret = sendMRMsgShared(0);

	return ret;

}

int ShcKeysMRHelper::sendMRMsgShared(int waitResp)
{
	if( mbGetSiteId() == 2 )
	{
		if (!IST_MR::check_if_site_is_up(1))
		{
			OTraceDebug("D-SHC-: site 1 is not up key replication skipped.\n");
			return 1;
		}
	}
	else
	{
		if (!IST_MR::check_if_site_is_up(2))
		{
			OTraceDebug("D-SHC-: site 2 is not up key replication skipped.\n");
			return 1;
		}
	}

	MRApplHelper *mrHelper = MRApplHelper::getInstance(IST_MR_SERVICE_NAME_SHCKEYS_SHARED);
	OCString replService;
	OCString replData;

	if ( mrHelper->flattenData(replData) < 0 )
	{
		mrHelper->reset();
		OTraceError("E-SHC-MR0005:unable to prepare data for shared key replication\n" );
		return -1;
	}

	mrHelper->getServiceName(replService);
	int ret = -1;
	char shclog_id[22] = {0};
	if ( mb_get_tid ( shclog_id, sizeof(shclog_id)-1, &ret) <= 0 )
		mb_getUmi( shclog_id, sizeof( shclog_id));
	OCString externalRef = shclog_id;
	if ( waitResp ){
		int responseTime = getWaitTime();
		ret = MRApplHelper::sendToOtherSiteAndWaitForResponse( replService, replData, 
									externalRef, responseTime, 
									_workbuf, sizeof(_workbuf) );
		if ( ret > 0 )
			ret = processRespMRMsg();
		else
		{
			OTraceError("E-SHC-KEYMR-0006: failed to get response for shared key replication\n" );
			ret = -1;
		}
	}else{
		ret = MRApplHelper::sendToOtherSite( replService, replData, externalRef );
	}

	return ret;
}


int ShcKeysMRHelper::processRespMRMsg()
{

	char resultCode;
	char msgid[21];


	// message
	// 1 byte  1  OK  0 Fail
	// 20 bytes Message ID

	resultCode = _workbuf[0];
	memset(msgid, 0, sizeof (msgid));
	strncpy(msgid, &_workbuf[1], 20);

	OTraceDebug("D-SHCKEYMR-0007:RESP [%c] msgig[%s]\n", resultCode, msgid);
	return  1;

}

//use this a argument because can't add argument
char __keycnt_setMRDataShared[20+1] = { 0 };


int ShcKeysMRHelper::setMRDataShared(struct shckey_buf *bufp, char *newkey, char *newchk, char status)
{
	char keycnt[20+1] = { 0 };
	if (__keycnt_setMRDataShared[0])
		strcpy(keycnt, __keycnt_setMRDataShared);
	__keycnt_setMRDataShared[0] = 0;

 	MRApplHelper *mrHelper =  MRApplHelper::getInstance(IST_MR_SERVICE_NAME_SHCKEYS_SHARED);
	mrHelper->reset();
	mrHelper->setReplicateOn(UPDATE_SHCKEYS);
	mrHelper->setData(TAG_SHCKEYS_SITE_ID, bufp->keyp->k.site_id);
	mrHelper->setData(TAG_SHCKEYS_INSTITUTION_ID, bufp->keyp->k.institutionid);
	mrHelper->setData(TAG_SHCKEYS_USERBIN, bufp->keyp->k.userbinid);

	if (keycnt[0])
		mrHelper->setData(TAG_SHCKEYS_KEY_COUNT, keycnt);

	if (bufp->akeyp)
	{	
		mrHelper->setData(TAG_SHCKEYS_OLDKEY, bufp->akeyp);
		mrHelper->setData(TAG_SHCKEYS_OLDCHK_DIGITS,bufp->achkp);
	}
	else if (bufp->ikeyp)
	{
		mrHelper->setData(TAG_SHCKEYS_OLDKEY, bufp->ikeyp);
		mrHelper->setData(TAG_SHCKEYS_OLDCHK_DIGITS,bufp->ichkp);
	}

	mrHelper->setData(TAG_SHCKEYS_STATUS, status);
	mrHelper->setData(TAG_SHCKEYS_CLASS, bufp->key_class);
	mrHelper->setData(TAG_SHCKEYS_TYPE, bufp->type);
	mrHelper->setData(TAG_SHCKEYS_INDEX, bufp->index);


	//   New Key and check digits
	if (newkey)
	    mrHelper->setData(TAG_SHCKEYS_KEY, newkey);
    if (newchk)
	    mrHelper->setData(TAG_SHCKEYS_CHK_DIGITS, newchk);

	mrHelper->setData(TAG_SHCKEYS_SENDER_NODEID, getNodeId_mb());

	//mrHelper->setData(TAG_SHCKEYS_DATE,  );    // Need to  add  date time 

	return 1;
}


int ShcKeysMRHelper::setMRDataUnique(struct shckey_buf *bufp, char status)
{

 	MRApplHelper *mrHelper =  MRApplHelper::getInstance(IST_MR_SERVICE_NAME_SHCKEYS_UNIQUE);
	mrHelper->reset();
	mrHelper->setReplicateOn(UPDATE_SHCKEYS);
	mrHelper->setData(TAG_SHCKEYS_SITE_ID, bufp->keyp->k.site_id);
	mrHelper->setData(TAG_SHCKEYS_INSTITUTION_ID, bufp->keyp->k.institutionid);
	mrHelper->setData(TAG_SHCKEYS_USERBIN, bufp->keyp->k.userbinid);

	if (bufp->akeyp)
	{	
		mrHelper->setData(TAG_SHCKEYS_KEY, bufp->akeyp);
		mrHelper->setData(TAG_SHCKEYS_CHK_DIGITS,bufp->achkp);
	}
	else if (bufp->ikeyp)
	{
		mrHelper->setData(TAG_SHCKEYS_KEY, bufp->ikeyp);
		mrHelper->setData(TAG_SHCKEYS_CHK_DIGITS,bufp->ichkp);
	}

	mrHelper->setData(TAG_SHCKEYS_STATUS, status);
	mrHelper->setData(TAG_SHCKEYS_CLASS, bufp->key_class);
	mrHelper->setData(TAG_SHCKEYS_TYPE, bufp->type);
	mrHelper->setData(TAG_SHCKEYS_INDEX, bufp->index);
	//mrHelper->setData(TAG_SHCKEYS_DATE,  );

	return 1;
}


//TESTED	
int ShcKeysMRHelper::getWaitTime()
{
	getIstparam();
	return _waitTime;
}

//TESTED
int ShcKeysMRHelper::getIstparam()
{

	static int  init = 0;

	const char *const SHCMRKEYWAITTIME = "shc.mrkeywaittime";

	if (init == 0)
	{
		if(cf_open("files/shc.cfg") < 0)
		{
			OTraceWarning("W-SHCKEYS-00:Configuration file not present: Using default values\n");
			_waitTime = 15;
			return(1);
		}

		if (cf_locatenum(SHCMRKEYWAITTIME, &_waitTime) < 0)
		{
			OTraceWarning ("W-SHCKEYS-00??: Parameter '%s' not found\n", SHCMRKEYWAITTIME);
			_waitTime = 15;
		}

		cf_close();

		init = 1;
	}

	return 1;
}

