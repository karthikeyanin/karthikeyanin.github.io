/*
 *  Copyright (C) 2004 eFunds Corporation ("eFunds").  All Rights Reserved.     
 *  eFunds Canada Corporation is an authorized user.                            
 *                                                                              
 *  IST is a registered trademark of eFunds Corporation.  Other brand or        
 *  product names are trademarks or registered trademarks of their respective   
 *  holders.                                                                    
 *                                                                              
 *  The information contained herein is the unpublished proprietary property    
 *  of eFunds.  Except as specifically authorized in writing by eFunds, the     
 *  holder of this document shall: i) keep all information contained herein     
 *  confidential, and ii) protect the information, in whole or in part, from    
 *  disclosure and dissemination to all third parties.                          
 *                                                                          
 *  This document and the software described in it are furnished under license  
 *  and may be used or copied only in accordance with the terms of such license.
 *  This document is supplied for information purposes only, is subject to      
 *  change without notice, and should not be construed as a commitment by       
 *  either eFunds Corporation or eFunds Canada Corporation. 
 */

// "@(#) ShcPosGeoLoc.cxx 1.5.1.1 17/06/01 01:02:55"

/*----------------------------------------------------------------------------*
 *                                                                            *
 * File:				
 * Description:	
 * Notes:
 *
 * Modification History:
 * YYMMDD SCR#    WHO	Description
 * ------ ------- ---	------------------------------------------------------*
 * 030102 R008792 ztang Created.
 * 061102 R018101 spa	Pad zeros at beginning of county, province when numeric
 *----------------------------------------------------------------------------*/

//File Number 34

#if defined(WIN32)
#	define shcfmt_posGeoLoc_h_export_directive	__declspec(dllexport)
#else
#	define shcfmt_posGeoLoc_h_export_directive
#endif

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <errno.h>
#include <oasis.h>
#include <shcfmt.h>
#include <shcPosGeoLoc.h>
#include <istsafe.h>
#include <algorithm>

int ShcPosGeoLoc::countryLen = POS_GEO_LOC_COUNTRY_LEN;
int ShcPosGeoLoc::stateProvinceLen = POS_GEO_LOC_STATE_PROVINCE_LEN;
int ShcPosGeoLoc::countyLen = POS_GEO_LOC_COUNTY_LEN;
int ShcPosGeoLoc::postalCodeLen = POS_GEO_LOC_POSTAL_CODE_LEN;
int ShcPosGeoLoc::sum = 0;
int ShcPosGeoLoc::initialized = 0;

////////////////////////////////////////////////////////////////////////////////
ShcPosGeoLoc::ShcPosGeoLoc(char *posGeoLoc)
{
	char *p, *endP;
	char tmpPosGeoLoc[40];
	
	if (!initialized)
		initialize();
	
	strncpy(tmpPosGeoLoc, posGeoLoc, sum);
	tmpPosGeoLoc[sum] = '\0';
	
	p=tmpPosGeoLoc;
	endP=p+strlen(p);
	
	initFields();
	
	if (countryLen>0)
	{
		memcpy(country, p, std::min<int> (countryLen, sizeof (country)));
		country[countryLen] = '\0';
		p += countryLen;
	}
	
	if (p>=endP)
		return;
		
	if (stateProvinceLen>0)
	{
	       memcpy(stateProvince, p, std::min<int> (stateProvinceLen, sizeof (stateProvince)));
		stateProvince[stateProvinceLen] = '\0';
		p += stateProvinceLen;
	}
	
	if (p>=endP)
		return;

	if (countyLen>0)
	{
		memcpy(county, p, std::min<int> (countyLen, sizeof (county)));
		county[countyLen] = '\0';
		p += countyLen;
	}
	
	if (p>=endP)
		return;

	if (postalCodeLen>0)
	{
		memcpy(postalCode, p, std::min<int> (postalCodeLen, sizeof (postalCode)));
		postalCode[postalCodeLen] = '\0';
		p += postalCodeLen;
	}

}

const char *ShcPosGeoLoc::getNumericCountryCode()
{
	if (country <= 0)
	{
		country[0] = '\0';
	}
		return country;
}

void ShcPosGeoLoc::initialize(void)
{
	initialized = 1;
	sum = countryLen + stateProvinceLen + countyLen + postalCodeLen;
}


void ShcPosGeoLoc::setNumericCountryCode(const char *newCountry)
{
	int len;
	
	if (countryLen <= 0)
		return;
	memset(country, ' ', countryLen);
	if (strlen(newCountry)>countryLen)
		len=countryLen;
	else
		len=strlen(newCountry);
	memcpy(country, newCountry, len);
	country[countryLen] = '\0';
	return;
}

void ShcPosGeoLoc::setStateProvince(const char *newStateProvince)
{
	int len, posn;
	
	if (stateProvinceLen <= 0)
		return;
	//      >>>     R018101
	len = strlen(newStateProvince);
	if(len > stateProvinceLen)
		len = stateProvinceLen;
	if(newStateProvince[0] >= '0' && newStateProvince[0] <= '9')
	{
		memset(stateProvince, '0', stateProvinceLen);
		posn = stateProvinceLen - len;
		memcpy(stateProvince+posn, newStateProvince, len);
	}
	else
	{
		memset(stateProvince, ' ', stateProvinceLen);
		memcpy(stateProvince, newStateProvince, len);
	}
	stateProvince[stateProvinceLen] = '\0';
	//      <<<     R018101
	return;
}

void ShcPosGeoLoc::setCounty(const char *newCounty)
{
	int len, posn;
	
	if (countyLen <= 0)
		return;
	//      >>>     R018101
	len = strlen(newCounty);
	if(len > countyLen)
		len = countyLen;
	if(newCounty[0] >= '0' && newCounty[0] <= '9')
	{
		memset(county, '0', countyLen);
		posn = countyLen - len;
		memcpy(county+posn, newCounty, len);
	}
	else
	{
		memset(county, ' ', countyLen);
		memcpy(county, newCounty, len);
	}
	county[countyLen] = '\0';
	//      <<<     R018101
	return;
}

void ShcPosGeoLoc::setPostalCode(const char *newPostalCode)
{
	int len;
	
	if (postalCodeLen <= 0)
		return;
	memset(postalCode, ' ', postalCodeLen);
	if (strlen(newPostalCode)>postalCodeLen)
		len=postalCodeLen;
	else
		len=strlen(newPostalCode);
	memcpy(postalCode, newPostalCode, len);
	postalCode[postalCodeLen] = '\0';
	return;
}	

void ShcPosGeoLoc::getPosGeoLoc(char * posGeoLocBuf)
{
	char tempPosGeoLocBuf[20]; //sizeof pos_geo_loc defined in shclog_vfrs.h
	int len=0;

	if (countryLen > 0)
	{
		istsafe_strcpy(posGeoLocBuf, sizeof(tempPosGeoLocBuf),country);
		len = istsafe_strlen(posGeoLocBuf,sizeof(tempPosGeoLocBuf));
	}
	if (stateProvinceLen > 0)
	{
		istsafe_strcat(posGeoLocBuf,sizeof(tempPosGeoLocBuf),stateProvince);
                len = istsafe_strlen(posGeoLocBuf,sizeof(tempPosGeoLocBuf));
        }
	if (countyLen > 0)
	{
		istsafe_strcat(posGeoLocBuf,sizeof(tempPosGeoLocBuf),county);
                len = istsafe_strlen(posGeoLocBuf,sizeof(tempPosGeoLocBuf));
        }	
	if (postalCodeLen > 0)
	{
		istsafe_strcat(posGeoLocBuf,sizeof(tempPosGeoLocBuf),postalCode);	
		len = istsafe_strlen(posGeoLocBuf,sizeof(tempPosGeoLocBuf));
        }
	return;
}

ShcPosGeoLoc::ShcPosGeoLoc()
{
	if (!initialized)
		initialize();
		
	initFields();
}

void ShcPosGeoLoc::initFields()
{
	if (countryLen > 0)
	{
		memset(country, ' ', countryLen);
		country[countryLen] = '\0';
	}
	else
		country[0] = '\0';
		
	if (stateProvinceLen > 0)
	{
		memset(stateProvince, ' ', stateProvinceLen);
		stateProvince[stateProvinceLen] = '\0';
	}
	else
		stateProvince[0] = '\0';
	if (countyLen > 0)
	{
		memset(county, ' ', countyLen);
		county[countyLen] = '\0';
	}
	else
		county[0] = '\0';
	if (postalCodeLen > 0)
	{
		memset(postalCode, ' ', postalCodeLen);
		postalCode[postalCodeLen] = '\0';
	}
	else
		postalCode[0] = '\0';
}
