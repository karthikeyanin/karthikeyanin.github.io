static char _Dispatcher_cxx_what[] = "@(#) Dispatcher.cxx 1.3 13/10/09 12:59:14";

/*
 *  Copyright (C) 2004 eFunds Corporation ("eFunds").  All Rights Reserved.     
 *  eFunds Canada Corporation is an authorized user.                            
 *                                                                              
 *  IST is a registered trademark of eFunds Corporation.  Other brand or        
 *  product names are trademarks or registered trademarks of their respective   
 *  holders.                                                                    
 *                                                                              
 *  The information contained herein is the unpublished proprietary property    
 *  of eFunds.  Except as specifically authorized in writing by eFunds, the     
 *  holder of this document shall: i) keep all information contained herein     
 *  confidential, and ii) protect the information, in whole or in part, from    
 *  disclosure and dissemination to all third parties.                          
 *                                                                          
 *  This document and the software described in it are furnished under license  
 *  and may be used or copied only in accordance with the terms of such license.
 *  This document is supplied for information purposes only, is subject to      
 *  change without notice, and should not be construed as a commitment by       
 *  either eFunds Corporation or eFunds Canada Corporation. 
 *
 *
 *                        MODIFICATION HISTORY                  REVIEW
 *
 *	SPR#	Who	Date	Description			Who	Date   
 * ===========================================================================
 *R00xxxx ztang 08Jun13	Creation
 */
/* File Number 148 */


#include <ist_otrace.h>
#include <Dispatcher.h>
#include <istdispatcher_shcdata.h>

int Dispatcher::BusinessMon(struct shcmsg *msg, int len)
{
	int r = 0;
	if (isBusiMonOn())
		r = IstShcDispatcherMsgData::dispatch(DISPATCH_POINT_BUSIMON, msg, len);
	return r;
}

int Dispatcher::BusinessMon(const char *logId, int msgtype, int respcode, char *txnSrc, char *acquirer, char *txnDest, char *issuer)
{
	int r=0;
	if (isBusiMonOn())
		r = IstShcDispatcherMsgData::dispatch(DISPATCH_POINT_BUSIMON, logId, msgtype, respcode, txnSrc, acquirer, txnDest, issuer);
	return r;
}
//this is the original istnotify point developed by Arun
int Dispatcher::AfterShcLog(struct shcmsg *msg, int len)
{
	int r;
	r = IstShcDispatcherMsgData::dispatch("shc_on_response", msg, len);
	return r;
}

int Dispatcher::POS(struct shcmsg *msg, int len)
{
	int r;
	r = IstShcDispatcherMsgData::dispatch("pos_on_capture", msg, len);
	return r;
}
