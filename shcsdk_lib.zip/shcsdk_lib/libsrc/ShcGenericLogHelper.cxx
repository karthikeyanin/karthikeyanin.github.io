static char _ShcGenericLogHelper_cxx_what[] = "@(#) ShcGenericLogHelper.cxx 1.0 11/12/02 18:31:01";

/*
 *  Copyright (C) 2004 eFunds Corporation ("eFunds").  All Rights Reserved.
 *  eFunds Canada Corporation is an authorized user.
 *
 *  IST is a registered trademark of eFunds Corporation.  Other brand or
 *  product names are trademarks or registered trademarks of their respective
 *  holders.
 *
 *  The information contained herein is the unpublished proprietary property
 *  of eFunds.  Except as specifically authorized in writing by eFunds, the
 *  holder of this document shall: i) keep all information contained herein
 *  confidential, and ii) protect the information, in whole or in part, from
 *  disclosure and dissemination to all third parties.
 *
 *  This document and the software described in it are furnished under license
 *  and may be used or copied only in accordance with the terms of such license.
 *  This document is supplied for information purposes only, is subject to
 *  change without notice, and should not be construed as a commitment by
 *  either eFunds Corporation or eFunds Canada Corporation.
 *
 *
 *                        MODIFICATION HISTORY                  REVIEW
 *
 * SCR#     Who    Date  Description
 * ===========================================================================
 * R030464  Dipa  11Apr12  Implement restore()
 * R032449  Dipa  31Dec13  Fix restore issue when map760segments is turned ON
 */

//File Number 172
#include <dbm.h>
#include <shcdef.h>
#include <shc.h>
#include <ist_seg_list.h>
#include <ist_otrace.h>
#include <ist_seg_id.h>
#include <ist_seg_name.h>
#include <ist_seg_elf_id_map.h>
#include <shcfmt.h>
#include <istcurrency.h>
#include <ShcmsgHeader.h>
#include <ShcGenericLogHelper.h>
#include <shclog_add.h>
#include <shc_logadd_def.h>
#include <CShcLog.h>
#include <ShcGenericLogHelper.h>
#include <list>
#include <oc/oc_datetime.h>
#include <istsafe.h>

static	int	shc_logadd_fd = (-1);
SHCLOG_ADD	shclog_add;
static int noOfSegToLog = 0;

extern "C"
int compare_values(const void * a, const void * b)
{
	struct SegmentItemHlpr *ptr1, *ptr2;
	ptr1 = (struct SegmentItemHlpr*)a;
	ptr2 = (struct SegmentItemHlpr*)b;

	if(ptr1->fieldNum == ptr2->fieldNum)
		return (ptr1->sequence - ptr2->sequence);
	else
		return (ptr1->fieldNum - ptr2->fieldNum);
}

ShcGenericLogHelper::ShcGenericLogHelper()
{
	shcchiplogfd = -1;
	shcchiploginsertfd = -1;
	noOfGenLogItem = 0;
	noOfSegMapItem = 0;
	segmentList = NULL;
	bufList = NULL;
	sbufList = NULL;
}

void ShcGenericLogHelper::initialize()
{
	//read the configured parameters from istparam.cfg
	char buf[5];
	if(cf_open(NULL) >= 0)
	{
		//read shc.genericLogFieldSize
		int fieldSize;
		int i;
		cf_rewind();
		if( (cf_locatenum("shc.genericLogFieldSize", &fieldSize)) < 0 )
		{
			OTraceError("E-SHC-172006: Parameter shc.genericLogFieldSize not found \n");
		}
		else if(fieldSize == 0)
		{
			OTraceError("E-SHC-172007: Invalid value for the parameter shc.genericLogFieldSize \n");
		}
		else
		{
			shcGenericLogFieldSize = fieldSize;
		}

		//set shcGenericLogFieldList[] to default values
		for(i=0;i<SHC_GENERIC_LOG_FIELD_NUM;i++)
			shcGenericLogFieldList[i] = i;

		bufList = new dbBufferHlpr[SHC_GENERIC_LOG_FIELD_NUM];
		struct dbBufferHlpr *tmpBufList = bufList;

		//set default values
		memset(bufList, 0, sizeof(struct dbBufferHlpr)*SHC_GENERIC_LOG_FIELD_NUM);

		char temp_config_data[128];
		char sss[sizeof(temp_config_data)];
		int noOfFieldsMerged;
		int smallNum;
		char *ptr;

		//read shc.genericLogMerge
		cf_rewind();
		while( (cf_nextparm("shc.genericLogMerge", temp_config_data) ) > 0 )
		{
			//Find the smallNum as field numbers may not be sorted
			strcpy(sss, temp_config_data);
			ptr = strtok(sss, " \t\n");
			smallNum = atoi(ptr);
			while(ptr != NULL)
			{
				if (atoi(ptr) < smallNum)
					smallNum = atoi(ptr);
				ptr = strtok(NULL, " \t\n");
			}

			ptr = strtok(temp_config_data, " \t\n");
			noOfFieldsMerged = 0;

			while(ptr != NULL)
			{
				shcGenericLogFieldList[atoi(ptr)-1] = smallNum-1;
				noOfFieldsMerged++;
				( bufList + (atoi(ptr)-1))->flag = 2;	//	merged fields
				ptr = strtok(NULL, " \t\n");
			}

			tmpBufList = bufList + smallNum-1;
			tmpBufList->buf = new char[noOfFieldsMerged*shcGenericLogFieldSize+1];
			tmpBufList->bufferSize = noOfFieldsMerged * shcGenericLogFieldSize;
			tmpBufList->flag = 3;		//first field of the merged field set
		}

		//read shc.genericLogItem
		cf_rewind();

		noOfGenLogItem = cf_countparams("shc.genericLogItem");

		if( noOfGenLogItem <= 0 )
		{
			OTraceDebug("W-SHC-172008: Parameter shc.genericLogItem not found \n");
		}
		else
		{
			segmentList = new SegmentItemHlpr[noOfGenLogItem];
			struct SegmentItemHlpr* tmpSegmentList = segmentList;
			int noOfTokens;
			cf_rewind();

			while( (cf_nextparm("shc.genericLogItem", temp_config_data) ) > 0 )
			{
				strcpy(sss, temp_config_data);
				ptr = strtok(temp_config_data, " \t\n");
				noOfTokens = 0;
				while(ptr != NULL)
				{
					switch( noOfTokens )
					{
						case 0:
							snprintf(tmpSegmentList->segmentName,sizeof(tmpSegmentList->segmentName), "%s", ptr);
							tmpSegmentList->segmentHashValue = hashValue(ptr);
							break;
						case 1:
							if( shcGenericLogFieldList[atoi(ptr)-1] != (atoi(ptr)-1) )	//merged field
								tmpSegmentList->fieldNum = shcGenericLogFieldList[atoi(ptr)-1];
							else
								tmpSegmentList->fieldNum = (unsigned char)atoi(ptr);

							//allocate memory for buf of bufList
							tmpBufList = bufList + (atoi(ptr)-1);
							if( tmpBufList->flag == 0 )
								{
								tmpBufList->buf = new char[shcGenericLogFieldSize+1];
								tmpBufList->bufferSize = shcGenericLogFieldSize;
								tmpBufList->flag = 1;
							}
							break;
						case 2:
							tmpSegmentList->sequence = (unsigned char)atoi(ptr);
							break;
						case 3:
							if( !stricmp(ptr, "int") )
								tmpSegmentList->dataType = 'I';
							else if( !stricmp(ptr, "char") )
								tmpSegmentList->dataType = 'C';
							else if( !stricmp(ptr, "binary") )
								tmpSegmentList->dataType = 'B';
							else if( !stricmp(ptr, "money") )
								tmpSegmentList->dataType = 'M';
							else
								tmpSegmentList->dataType = 0;
								break;
						case 4:
							if( !stricmp(ptr, "request") )
								tmpSegmentList->restoreFlag = 'Q';
							else if( !stricmp(ptr, "response") )
								tmpSegmentList->restoreFlag = 'P';
							else if( !stricmp(ptr, "always") )
								tmpSegmentList->restoreFlag = 'B';
							else
								tmpSegmentList->restoreFlag = 0;
							break;
						case 5:
							if( strlen(ptr) == 1 )
								tmpSegmentList->separator = *ptr;
							else if (strlen(ptr) >= 2 ) //ascii value may be 2 or 3 char, I have changed design for it.
								tmpSegmentList->separator = (char)atoi(ptr);
							else
							{
								tmpSegmentList->separator = 0x10;
								OTraceError("E-SHC-172009: No separator specified for the segment: %s, default value is used at line:\n%s\n", tmpSegmentList->segmentName, sss);
							}
							break;
					}
					noOfTokens++;
					ptr = strtok(NULL, " \t\n");
				}
				tmpSegmentList->value = NULL;	//set to NULL initially

				if( (noOfTokens < 5) || (noOfTokens > 6) )
				{
					OTraceError("E-SHC-172010: Error in shc.genericLogItem parameter config. format at line:\n%s\n", sss);
				}
				else if( noOfTokens == 5 )	//No separator, use default separator
				{
					tmpSegmentList->separator = 0x10;
				}

				tmpSegmentList++;
			}
		}

		//sort the segment list using qsort
		qsort(segmentList, noOfGenLogItem, sizeof(struct SegmentItemHlpr), compare_values);

		//read shc.segmap
		cf_rewind();
		noOfSegMapItem = cf_countparams("shc.segmap");
		if (noOfSegMapItem <= 0)
		{
			OTraceDebug("W-SHC-172044: Parameter shc.segmap not found\n");
		}
		else
		{
			segMapList = new segmentMap[noOfSegMapItem];
			struct segmentMap* tmpSegMapList = segMapList;
			int noOfTokens;
			cf_rewind();

			while( (cf_nextparm("shc.segmap", temp_config_data) ) > 0 )
			{
				strcpy(sss, temp_config_data);
				ptr = strtok(temp_config_data, " \t\n");
				noOfTokens = 0;
				while(ptr != NULL)
				{
					switch( noOfTokens )
					{
						case 0:
							snprintf(tmpSegMapList->oldSegName, sizeof(tmpSegMapList->oldSegName),"%s", ptr);
							break;
						case 1:
							snprintf(tmpSegMapList->newSegName, sizeof(tmpSegMapList->newSegName),"%s",ptr);
							break;
						case 2:
							snprintf(tmpSegMapList->newSubSegName, sizeof(tmpSegMapList->newSubSegName), "%s", ptr);
							break;
					}
					noOfTokens++;
					ptr = strtok(NULL, " \t\n");
				}
				if( (noOfTokens < 3) || (noOfTokens > 3) )
					OTraceError("E-SHC-172045: Error in shc.segmap parameter config. format at line:\n%s\n", sss);
				tmpSegMapList++;
			}
		}

		cf_close();

		shcGenericLogBinaryFieldSize = 2000;	//default value
		SHC_GENERIC_LOG_BINARY_FIELD_NUM = 5;
		valueBuf = NULL;
		valueBufLen = 0;

		sbufList = new dbBufferHlpr[SHC_GENERIC_LOG_BINARY_FIELD_NUM];
		valueBuf = (char *)calloc(shcGenericLogBinaryFieldSize,SHC_GENERIC_LOG_BINARY_FIELD_NUM);
		struct dbBufferHlpr *stmpBufList = sbufList;

		//set default values
		memset(sbufList, 0, sizeof(struct dbBufferHlpr)*SHC_GENERIC_LOG_BINARY_FIELD_NUM);

		//compose and bind sql statements

		tmpBufList = bufList;	//point to the start
		char fields[512] = "";
                char valuesInsert[128] = " values(?,?,?,?,?";

		for(i=0;i<SHC_GENERIC_LOG_FIELD_NUM;i++)
		{
			if( (tmpBufList->flag == 1) || (tmpBufList->flag == 2) || (tmpBufList->flag == 3) )
			{
				snprintf(fields+strlen(fields),(sizeof(fields)-strlen(fields)), ",field%d", i+1);
				snprintf(valuesInsert+strlen(valuesInsert),sizeof(valuesInsert)-strlen(valuesInsert), ",?");
			}
			tmpBufList++;
		}
		stmpBufList = sbufList;	//point to the start
		for(i=0;i<SHC_GENERIC_LOG_BINARY_FIELD_NUM;i++)
		{
			sprintf(fields, "%s,binfield%d", fields,i+1);
			strcat(valuesInsert, ",?");
			stmpBufList->buf = &valueBuf[i*shcGenericLogBinaryFieldSize];
			stmpBufList++;
		}

		//insert query
		char sqlStmtDefaultInsert[512] = "insert into shcgenericlog(log_id,msgtype,reqresp, site_id, switch_date";
        char sqlStatementInsert[512] = { 0 }; 


		int bindCount;
                static short int site_id = mbGetSiteId();

		snprintf(sqlStatementInsert, sizeof(sqlStatementInsert), "%s%s)%s)", sqlStmtDefaultInsert, fields, valuesInsert);

	    if (dbm_connect() >=0)
	    {
	        OTraceDebug("D-SHC-172011:Connecting to database successful\n");
	        ch=dbm_dbconn;
	    }
	    else
	    {
	        OTraceError("E-SHC-172012: Connecting to database failed\n");
	        throw 1;
  	  	}

		if( DBMAllocStmt(ch, &shInsert) < 0)
		{
			OTraceError("E-SHC-172013: Insert query allocate error:\n%s\n", sqlStatementInsert);
		}

		if( DBMPrepare(shInsert, sqlStatementInsert) != DBM_SUCCESS )
		{
			OTraceError("E-SHC-172014: Insert query prepare error:\n%s\n", sqlStatementInsert);
		}


		if( (DBMBindParam(shInsert,1,DBM_PARAM_INPUT,DBM_STRINGTYPE,logid,sizeof(logid),&ind[0]) != DBM_SUCCESS) ||
			(DBMBindParam(shInsert,2,DBM_PARAM_INPUT,DBM_LONGTYPE,&msgType,sizeof(msgType),NULL) != DBM_SUCCESS) ||
			(DBMBindParam(shInsert,3,DBM_PARAM_INPUT,DBM_CHARTYPE,&reqresp,sizeof(reqresp),NULL) != DBM_SUCCESS) ||
                        (DBMBindParam(shInsert,4,DBM_PARAM_INPUT,DBM_INTTYPE, &site_id, sizeof(site_id), NULL) != DBM_SUCCESS) ||
                        (DBMBindParam(shInsert,5,DBM_PARAM_INPUT,DBM_DATETYPE,&switch_date,sizeof(switch_date),NULL) != DBM_SUCCESS)  )
		{
			OTraceError("E-SHC-172015: Insert query bind error \n");
		}

		//bind the fields
		tmpBufList = bufList;	//point to the start
		bindCount = 5;
		int mergedFieldsCount = 0;

		for(i=0;i<SHC_GENERIC_LOG_FIELD_NUM;i++)
		{
			if( (tmpBufList->flag == 2) || (tmpBufList->flag == 3) )	//merged fields
			{
				if( tmpBufList->flag == 3 )		//reset mergedFieldsCount when it goes to the next merged fields set
					(bufList+shcGenericLogFieldList[i])->bufferSize = 0;
				bindCount++;
				if( DBMBindParam(shInsert,bindCount,DBM_PARAM_INPUT,DBM_STRINGTYPE,&(bufList+shcGenericLogFieldList[i])->buf[
					(bufList+shcGenericLogFieldList[i])->bufferSize],shcGenericLogFieldSize,&ind[i+3]) != DBM_SUCCESS )// --- R016790
				{
					OTraceError("E-SHC-172016: Insert query bind error for the field: %d \n", i+1);
				}
				(bufList+shcGenericLogFieldList[i])->bufferSize += shcGenericLogFieldSize;
			}
			else if( tmpBufList->flag == 1 )	//used fields
			{
				bindCount++;
				if( DBMBindParam(shInsert,bindCount,DBM_PARAM_INPUT,DBM_STRINGTYPE,tmpBufList->buf,shcGenericLogFieldSize,&ind[i+3])
					!= DBM_SUCCESS )	//	---	R016790
				{
					OTraceError("E-SHC-172017: Insert query bind error for the field: %d \n", i+1);
				}
			}
			tmpBufList++;
		}

		stmpBufList = sbufList;
		for(i=0;i<SHC_GENERIC_LOG_BINARY_FIELD_NUM;i++)
		{
			bindCount++;
			if( DBMBindParam(shInsert,bindCount,DBM_PARAM_INPUT,DBM_BINTYPE,
				stmpBufList[i].buf,shcGenericLogBinaryFieldSize,&indb[i+3]) != DBM_SUCCESS )// --- R016790
				{
					OTraceError("E-SHC-172046: Insert query bind error for the binfield: %d \n", i+1);
				}
		}

		//load entry for both request and response
		char bfields[256] = "";
		for(i=0;i<SHC_GENERIC_LOG_BINARY_FIELD_NUM;i++)
		{
			sprintf(bfields, "%s,binfield%d", bfields,i+1);
			strcat(valuesInsert, ",?");
		}

		char sqlStatementLoadBoth[512] = "select msgtype,reqresp";
		istsafe_strcat(sqlStatementLoadBoth, sizeof(sqlStatementLoadBoth), bfields);
		strcat(sqlStatementLoadBoth, " from shcgenericlog where log_id=?");

		if( DBMAllocStmt(ch, &shLoadBoth) < 0)
		{
			OTraceError("E-SHC-172018: query both statement allocate error:\n%s\n", sqlStatementInsert);
		}

		if( DBMPrepare(shLoadBoth, sqlStatementLoadBoth) != DBM_SUCCESS )
		{
			OTraceError("E-SHC-172019: Load query prepare error:\n%s \n", sqlStatementLoadBoth);
		}

		if( (DBMBindCol(shLoadBoth,1,DBM_LONGTYPE,&msgType,sizeof(msgType),&indb[1]) != DBM_SUCCESS) ||
		    (DBMBindCol(shLoadBoth,2,DBM_CHARTYPE,&reqresp,sizeof(reqresp),&indb[2]) != DBM_SUCCESS)  )
		{
			OTraceError("E-SHC-172020: Load query bind error \n");
		}

		bindCount = 2;
		mergedFieldsCount = 0;
		stmpBufList = sbufList;	//point to the start
		for(i=0;i<SHC_GENERIC_LOG_BINARY_FIELD_NUM;i++)
		{
			bindCount++;
			if( DBMBindCol(shLoadBoth,bindCount,DBM_BINTYPE,stmpBufList[i].buf,(shcGenericLogBinaryFieldSize+1),&indb[i+3]) != DBM_SUCCESS )//---R016790
			{
				OTraceError("E-SHC-172021: Insert query bind error for the binfield: %d \n", i+1);
			}
//			stmpBufList++;
		}

		// bindCount for BindCol and BindParam are not related, so use 1 here
		if( DBMBindParam(shLoadBoth,1,DBM_PARAM_INPUT,DBM_STRINGTYPE,logid,sizeof(logid),&indb[0]) != DBM_SUCCESS )
		{
			OTraceError("E-SHC-172023: Load query bind error \n");
		}


		//load entry for either request or response

		char sqlStatementLoad1[512] = "";
		strcat(sqlStatementLoad1, sqlStatementLoadBoth);
		strcat(sqlStatementLoad1, " and reqresp=?");

		if( DBMAllocStmt(ch, &shLoad1) < 0)
		{
			OTraceError("E-SHC-172024: query 1 statement allocate error:\n%s\n", sqlStatementInsert);
		}
		if( DBMPrepare(shLoad1, sqlStatementLoad1) != DBM_SUCCESS )
		{
			OTraceError("E-SHC-172025: Load query prepare error:\n%s \n", sqlStatementLoad1);
		}

		if( (DBMBindCol(shLoad1,1,DBM_LONGTYPE,&msgType,sizeof(msgType),&indb[1]) != DBM_SUCCESS) ||
		    (DBMBindCol(shLoad1,2,DBM_CHARTYPE,&reqresp,sizeof(reqresp),&indb[2]) != DBM_SUCCESS) )
		{
			OTraceError("E-SHC-172026: Load query bind error \n");
		}

		bindCount = 2;
		mergedFieldsCount = 0;
		stmpBufList = sbufList;	//point to the start
		for(i=0;i<SHC_GENERIC_LOG_BINARY_FIELD_NUM;i++)
		{
			bindCount++;
			if( DBMBindCol(shLoad1,bindCount,DBM_BINTYPE,stmpBufList[i].buf,(shcGenericLogBinaryFieldSize+1),&indb[i+3]) != DBM_SUCCESS )
			{
				OTraceError("E-SHC-172027: Insert query bind error for the field: %d \n", i+1);
			}
			//stmpBufList++;
		}

		if( (DBMBindParam(shLoad1,1,DBM_PARAM_INPUT,DBM_STRINGTYPE,logid,sizeof(logid),&indb[0]) != DBM_SUCCESS) ||
			(DBMBindParam(shLoad1,2,DBM_PARAM_INPUT_OUTPUT,DBM_CHARTYPE,&reqresp,sizeof(reqresp),NULL) != DBM_SUCCESS) )
		{
			OTraceError("E-SHC-172029: Load query bind error \n");
		}

		cf_close();
	}// cf_open END
}

void ShcGenericLogHelper::fillSegment(ShcmsgHeader *header, char *logHeader, int *logHeaderLen)
{
	int i,j,k;
	noOfSegToLog = 0;

	struct dbBufferHlpr *tmpBufList = bufList;
	struct dbBufferHlpr *stmpBufList = sbufList;

	strcpy(logid, header->msg.shclog_id);
	msgType = header->msg.msgtype;
	switch_date = header->msg.settlement_date;
	OCDateTime settleDate(switch_date/10000, switch_date/100 % 100, switch_date % 100, 0, 0, 0, 0 );

        if ( !settleDate.isValid() )
                switch_date = 0;
        if (!switch_date)
        {
                switch_date = header->msg.processor_busday;
                OCDateTime procDate(switch_date/10000, switch_date/100 % 100, switch_date % 100, 0, 0, 0, 0 );
                if( !procDate.isValid() )
                        switch_date =  header->msg.local_date;
        }

	//if (!switch_date)
		//switch_date = header->msg.processor_busday;

	if(shcIsResponse(header))	//response messages like 110,210,430,432
		reqresp = 'P';
	else
		reqresp = 'Q';

	//reset segmentList and bufList
	for(i=0;i<noOfGenLogItem;i++)
		(segmentList+i)->value = NULL;

	for(i=0;i<SHC_GENERIC_LOG_FIELD_NUM;i++)
	{
		if( (bufList+i)->buf != NULL )
			(bufList+i)->buf[0] = '\0';

	}
	for(i=0;i<(SHC_GENERIC_LOG_FIELD_NUM+3);i++)
		ind[i] = 0;

        if ( header->truelength() >  sizeof(struct shcmsg) ) {
                OTraceDebug("D-SHC-172031: segments found, flatten before processing \n");
        }

	if (!(header->msg.device_cap & SH_DEVCAP_USER_SEGMENT)) //No segment
		return ;

	struct shcseg *seg = (struct shcseg *)header->segment;
	int noOfSegments = shc_segnsegments(seg);

	OTraceDebug("D-SHC-172032: No. of segments found in the message: %d\n", noOfSegments);

	struct shcsegstart * segStart = shc_segfirst(seg);
	char *ptr;

	for(i=0;i<noOfSegments;i++)
	{
		ptr = shc_segname(seg, segStart);

		for(j=0;j<noOfGenLogItem;j++)
		{
			int tmpHashValue = hashValue(ptr);
			if( (tmpHashValue == (segmentList+j)->segmentHashValue)
				&& ( stricmp(ptr, (segmentList+j)->segmentName) == 0 ) )
			{
				(segmentList+j)->value = shc_seggetdata_pointer(seg, segStart);
					(segmentList+j)->segmentDataLen = shc_seggetdata_len(seg, segStart);

			}

		}
		segStart = shc_segnext(seg, segStart);
		if( segStart == NULL)
			break;
	}

	static char sbuf[SHC_SEG_MAX + 1];
	int seglen = 0;
	char *sptr;
	list<char *> tptr;

	for(j=0;j<noOfGenLogItem;j++)
	{
		sptr = (segmentList+j)->segmentName;
		for(k=0;k<noOfSegMapItem;k++)
		{
			if( stricmp(sptr, (segMapList+k)->oldSegName) == 0 )
			{
				memset(sbuf, 0x00, sizeof(sbuf));
				header->getSegmentData(sbuf,&seglen,ElfIdMap::elf_to_id((segMapList+k)->newSegName),
							IstSegSubElementMap::Subelement_name_to_Id((segMapList+k)->newSubSegName));
				if(seglen>0)
				{
					char *lptr = (char *)malloc((IstSafeInt(strlen(sbuf))+1).getInt());
					tptr.push_back(lptr);
					(segmentList+j)->value = lptr;
					if((segmentList+j)->value)
					{
						strcpy((segmentList+j)->value, sbuf);
						(segmentList+j)->segmentDataLen = seglen;
					}
				}
			}
		}
	}

	//fill the bufList from segmentList

	int *dataLen;
	amount_t *amt;

	for(i=0;i<noOfGenLogItem;i++)
	{
		tmpBufList = bufList + ( (segmentList+i)->fieldNum - 1);
			dataLen = &ind[(segmentList+i)->fieldNum + 2];

		if( (segmentList+i)->value != NULL )
		{

			switch( (segmentList+i)->dataType )
			{
				case 'C':
					if (segmentList[i].segmentDataLen > strlen(segmentList[i].value))
					segmentList[i].segmentDataLen = strlen(segmentList[i].value);
					if( ((*dataLen) +(segmentList+i)->segmentDataLen)  >  tmpBufList->bufferSize )
					{
						OTraceError("E-SHC-172033: Buffer overflow, unable to write the segment %s\n", (segmentList+i)->segmentName );
					}
					else
					{
						*dataLen += format_out((unsigned char*)(&tmpBufList->buf[*dataLen]),
								(segmentList+i)->value,FMT_CHAR, (segmentList+i)->segmentDataLen );
					}
					if( (*dataLen) < tmpBufList->bufferSize)	//to separate the segments/to indicate no data
						tmpBufList->buf[(*dataLen)++] = (segmentList+i)->separator;

					tmpBufList->buf[*dataLen] = 0;
					break;
				case 'I':
					(segmentList+i)->segmentDataLen = sprintf(&tmpBufList->buf[*dataLen],"%d",*(int*)(segmentList+i)->value);
					if( ((*dataLen) +(segmentList+i)->segmentDataLen)  >  tmpBufList->bufferSize )
					{
						OTraceError("E-SHC-172034: Buffer overflow, unable to write the segment %s\n", (segmentList+i)->segmentName );
					}
					else
					{
						*dataLen += format_out((unsigned char*)(&tmpBufList->buf[*dataLen]),
								(segmentList+i)->value,FMT_ITOA,(segmentList+i)->segmentDataLen );
					}
					if( (*dataLen) < tmpBufList->bufferSize)	//to separate the segments/to indicate no data
						tmpBufList->buf[(*dataLen)++] = (segmentList+i)->separator;

					tmpBufList->buf[*dataLen] = 0;
					break;
				case 'B':
					if( ((*dataLen) +(segmentList+i)->segmentDataLen*2)  >  tmpBufList->bufferSize )
					{
						OTraceError("E-SHC-172035: Buffer overflow, unable to write the segment %s\n", (segmentList+i)->segmentName );
					}
					else
					{
						*dataLen += format_out((unsigned char*)(&tmpBufList->buf[*dataLen]),
								(segmentList+i)->value,FMT_HTOA, (segmentList+i)->segmentDataLen*2 );
					}
					if( (*dataLen) < tmpBufList->bufferSize)	//to separate the segments/to indicate no data
						tmpBufList->buf[(*dataLen)++] = (segmentList+i)->separator;

					tmpBufList->buf[*dataLen] = 0;
					break;
				case 'M':
					amt = (amount_t*)(segmentList+i)->value;
					(segmentList+i)->segmentDataLen = strlen(amt->v.esql_decimal.digits);	//it may require correction
					if( ((*dataLen) +(segmentList+i)->segmentDataLen)  >  tmpBufList->bufferSize )
					{
						OTraceError("E-SHC-172036: Buffer overflow, unable to write the segment %s\n", (segmentList+i)->segmentName );
					}
					else
					{
						*dataLen += ccy_format_out((unsigned char*)(&tmpBufList->buf[*dataLen]),
								amt,FMT_CTOM, (segmentList+i)->segmentDataLen, header->msg.acq_currency_code );
					}
					if( (*dataLen) < tmpBufList->bufferSize)	//to separate the segments/to indicate no data
						tmpBufList->buf[(*dataLen)++] = (segmentList+i)->separator;

					tmpBufList->buf[*dataLen] = 0;
					break;
				default:
					OTraceError("E-SHC-172037: Unknown data type\n");
					break;

			}
			noOfSegToLog ++;
		}
		else	// segment doesn't have any data
		{
			tmpBufList->buf[(*dataLen)++] = (segmentList+i)->separator;
			tmpBufList->buf[*dataLen] = 0;
		}

	}

	list<char *>::iterator it;
	for(it=tptr.begin(); it!=tptr.end(); it++) //free the list
	{
		free(*it);
	}

	// log required segments in respective tables
	insertSegments(header);

	//Clear buffer
	for(i=0;i<SHC_GENERIC_LOG_BINARY_FIELD_NUM;i++)
	{
		sbufList[i].buf[0] = '\0';

	}
	for(i=0;i<(SHC_GENERIC_LOG_BINARY_FIELD_NUM+3);i++)
		indb[i] = 0;

	//fill segmentList from message segments
	int len = shcGenericLogBinaryFieldSize*SHC_GENERIC_LOG_BINARY_FIELD_NUM;
	IstSegList *segList = header->getSegList();
	if (!segList)
	{
		OTraceDebug("D-SHC-172052: No SegList. Nothing to Log\n");
		return ;
	}

	logHeader[0] = '\0';valueBufLen= sizeof(valueBuf);

	segList->compose(header->msg.msgtype, valueBuf, &valueBufLen, logHeader, logHeaderLen);
	if ((*logHeaderLen)<=0)	//No segment
	{
		OTraceDebug("D-SHC-172053: No 7.6.1 specific segment to log, check for 7.6 segments\n"); 
		if (noOfGenLogItem <= 0 || noOfSegToLog <= 0)
		{
			OTraceDebug("D-SHC-172053a: No 7.6 specific segments to log\n");
			return;
		}
	}

	//Fill in ind.
	len = valueBufLen;
	for(i=0;i<SHC_GENERIC_LOG_BINARY_FIELD_NUM;i++)
	{
		if (len > shcGenericLogBinaryFieldSize)
		{
			indb[i+3] = shcGenericLogBinaryFieldSize;
			len -= shcGenericLogBinaryFieldSize;
		}
		else if (len > 0)
		{
			indb[i+3] = len;
			len = 0;
		}
		else
		{
			indb[i+3] = DBM_NULL_DATA;
		}
	}
	//Fill in ind.
	//set the length
	ind[0] = strlen(logid);		//no need for ind[1] & ind[2]

	for(i=0;i<SHC_GENERIC_LOG_FIELD_NUM;i++)
	{
		if (bufList[i].flag == 2)
		{
			//This field is merged to a smaller number field
			int actualField = shcGenericLogFieldList[i];
			struct dbBufferHlpr *actualBuf = &bufList[actualField];

			if (ind[actualField+3] <= shcGenericLogFieldSize )
			{
				ind[i+3] = 0; //No data spilled into this field
			}
			else
			{
				//Data from smaller number field extends to this field
				int spill = ind[actualField+3] - shcGenericLogFieldSize;

				if (spill > shcGenericLogFieldSize)
					//This field can only hold this much
					ind[i+3] = shcGenericLogFieldSize;
				else
					//This is the last field needed to hold the spill
					ind[i+3] = spill;

				ind[actualField+3] -= ind[i+3];
			}
		}
		else if( bufList[i].flag == 3 )		//merged fields
		{
			//Nothing to do, ind for this field will be reduced by other merged fields
		}
		//for all other fields, the ind already has the length of data
	}
}

void ShcGenericLogHelper::insert()
{
	int dataInMergedField;
	int i;

	if(valueBufLen <= 0) // do insert only in response for 7.6.1 segments
	{
		OTraceDebug("D-SHC-172038: No 7.6.1 segments configured to log\n");
		if (noOfGenLogItem <= 0 || noOfSegToLog <= 0)
		{	
			OTraceDebug("D-SHC-172038a: No 7.6 segments configured to log\n");
			return;
		}
	}

	//set the length
	ind[0] = strlen(logid);		//no need for ind[1] & ind[2]

	OTraceDebug("D-SHC-172043:ShcGenericLogHelper::insert ID=%s\n",logid);

	//	>>>	R024803
	int ret;
	ret = DBMExecute(shInsert);
	if( ret != DBM_SUCCESS )
	{
		OTraceError("E-SHC-172040: Error when executing insert query.\n");
		processError(ret,shInsert);
	//	<<<	R024803
	}
	DBMFreeStmt(shInsert, DBM_CLOSE);
}

int ShcGenericLogHelper::insertSegments(ShcmsgHeader *header)
{
	map_Shcchiplog(header);
	map_Shclogadd(header);

	return 0;
}

int ShcGenericLogHelper::map_Shcchiplog(ShcmsgHeader *header)
{
	int len = 0;
	emv* emvbuf = NULL;
	int seglen;
	emv tmpEmvBuf;
        emvbuf=&tmpEmvBuf;
        seglen = sizeof(tmpEmvBuf);

        strcpy(shcchiplog.chip_index, header->msg.shclog_id);

        header->getSegmentData((char *)&tmpEmvBuf,&seglen,ElfIdMap::elf_to_id(IST_SEG_EMV_BUF),0);
        if (seglen <=0)
               emvbuf = NULL;

	if (emvbuf)
	{
		if(shcIsRequest(header))
		{
			map_ShcchiplogIns(header, emvbuf);
		}
		else
		{
			if (header->msg.device_devcap & SH_DEVICE_LOG_SHCCHIPLOG)
			{
				if(shcchiplogfd == -1)
				{
					if((shcchiplogfd = dbm_open("shcchiplog_1", dbmid)) < 0)
					{
						OTraceError("E-SHCLOG-172057: Unable to open shcchiplog_1 index : %d\n",
											dbm_errno);
						return -1;
					}
				}
				strcpy(shcchiplog.chip_index, header->msg.shclog_id);
				shcchiplog.site_id = mbGetSiteId();
				if (dbm_read(shcchiplogfd,
					     (char *)&shcchiplog,
					     DBM_REQUAL | DBM_RLOCK) < 0)
				{
					map_ShcchiplogIns(header, emvbuf);
					return (0);
					//OTraceError("E-SHC-172059: dbm_read problem with shcchiplogfd.\n");
				}	
			       	OTraceDebug("D-SHCLOG-172001a: Copy shcmsg to shcchiplog for update.\n");
				shcchiplog.term_txn_date      = emvbuf->term_txn_date;
				shcchiplog.cvv_res_code       = (char)emvbuf->cvv_res_code;
				shcchiplog.card_auth_res_code = (char)emvbuf->card_auth_res_code;
				shcchiplog.tvr_cvr_status     = (char)emvbuf->tvr_cvr_status;
				shcchiplog.term_type          = emvbuf->term_type;
				shcchiplog.term_entry_cap     = emvbuf->term_entry_cap;
				shcchiplog.chip_cond_code     = emvbuf->chip_cond_code;
				shcchiplog.ccps_txn_ind       = emvbuf->ccps_txn_ind;
				shcchiplog.card_auth_rel_ind  = emvbuf->card_auth_rel_ind;
				shcchiplog.msg_reason_code    = emvbuf->msg_reason_code;
				shcchiplog.deri_key_idx       = emvbuf->deri_key_idx;
				shcchiplog.crypto_version     = emvbuf->crypto_version;
				shcchiplog.crypto_txn_type    = emvbuf->crypto_txn_type;
				shcchiplog.term_country_code  = emvbuf->term_country_code;
				shcchiplog.crypto_curr_code   = emvbuf->crypto_curr_code;
				shcchiplog.neg_file_version   = emvbuf->neg_file_version;
				shcchiplog.ccard_pa_trace     = emvbuf->ccard_pa_trace;
				shcchiplog.ccard_purch_trace  = emvbuf->ccard_purch_trace;
				shcchiplog.ccard_crypto_trace = emvbuf->ccard_crypto_trace;
				shcchiplog.mcard_batch_trace  = emvbuf->mcard_batch_trace;
				shcchiplog.mcard_txn_trace    = emvbuf->mcard_txn_trace;
				shcchiplog.bitmap             = emvbuf->bitmap;
				dbm_deccopy(&shcchiplog.crypto_amount, &emvbuf->crypto_amount);
				dbm_deccopy(&shcchiplog.crypto_cb_amount, &emvbuf->crypto_cb_amount);
				strcpy(shcchiplog.srv_restrict_code, emvbuf->srv_restrict_code);
				strcpy(shcchiplog.term_cap_profile, emvbuf->term_cap_profile);
				strcpy(shcchiplog.tvr, emvbuf->tvr);
				strcpy(shcchiplog.unpredictable_num, emvbuf->unpredictable_num);
				strcpy(shcchiplog.term_ser_num, emvbuf->term_ser_num);
				strcpy(shcchiplog.cvr, emvbuf->cvr);
				strcpy(shcchiplog.issuer_discre_data, emvbuf->issuer_discre_data);
				strcpy(shcchiplog.cryptogram, emvbuf->cryptogram);
				strcpy(shcchiplog.app_txn_counter, emvbuf->app_txn_counter);
				strcpy(shcchiplog.app_ichg_profile, emvbuf->app_ichg_profile);
				strcpy(shcchiplog.arpc_cryptogram, emvbuf->arpc_cryptogram);
				strcpy(shcchiplog.arpc_respcode, emvbuf->arpc_respcode);
				strcpy(shcchiplog.issuer_script_res, emvbuf->issuer_script_res);
				strcpy(shcchiplog.ccard_sch_crypto, emvbuf->ccard_sch_crypto);
				strcpy(shcchiplog.issuer_app_data, emvbuf->issuer_app_data);
				strcpy(shcchiplog.issuer_auth_data, emvbuf->issuer_auth_data);	
				if( dbm_write(shcchiplogfd, (char *)&shcchiplog, 0) < 0 )
				{
					OTraceError("E-SHCLOG-172055: Error while updating shcchiplog: %d on write\n", dbm_errno);
				}
				else
					OTraceDebug("D-SHCLOG-172058:   Updated record in shcchiplog for m%04d/p%06d\n",
						header->msg.msgtype, header->msg.pcode);	
			}
			else
			{
				OTraceDebug("D-SHCLOG-172056:Request did not have emvbuf but response has\n");
			}	
		}
	}
	if ( shcchiplogfd >= 0)
	dbm_rewind(shcchiplogfd);
}

int ShcGenericLogHelper::map_ShcchiplogIns(ShcmsgHeader *header, emv* emvbuf)
{
	OTraceDebug("D-SHC-172001: Copy shcmsg to shcchiplog.\n");
	shcchiplog.term_txn_date      = emvbuf->term_txn_date;
	shcchiplog.cvv_res_code       = (char)emvbuf->cvv_res_code;
	shcchiplog.card_auth_res_code = (char)emvbuf->card_auth_res_code;
	shcchiplog.tvr_cvr_status     = (char)emvbuf->tvr_cvr_status;
	shcchiplog.term_type          = emvbuf->term_type;
	shcchiplog.term_entry_cap     = emvbuf->term_entry_cap;
	shcchiplog.chip_cond_code     = emvbuf->chip_cond_code;
	shcchiplog.ccps_txn_ind       = emvbuf->ccps_txn_ind;
	shcchiplog.card_auth_rel_ind  = emvbuf->card_auth_rel_ind;
	shcchiplog.msg_reason_code    = emvbuf->msg_reason_code;
	shcchiplog.deri_key_idx       = emvbuf->deri_key_idx;
	shcchiplog.crypto_version     = emvbuf->crypto_version;
	shcchiplog.crypto_txn_type    = emvbuf->crypto_txn_type;
	shcchiplog.term_country_code  = emvbuf->term_country_code;
	shcchiplog.crypto_curr_code   = emvbuf->crypto_curr_code;
	shcchiplog.neg_file_version   = emvbuf->neg_file_version;
	shcchiplog.ccard_pa_trace     = emvbuf->ccard_pa_trace;
	shcchiplog.ccard_purch_trace  = emvbuf->ccard_purch_trace;
	shcchiplog.ccard_crypto_trace = emvbuf->ccard_crypto_trace;
	shcchiplog.mcard_batch_trace  = emvbuf->mcard_batch_trace;
	shcchiplog.mcard_txn_trace    = emvbuf->mcard_txn_trace;
	shcchiplog.bitmap             = emvbuf->bitmap;
	dbm_deccopy(&shcchiplog.crypto_amount, &emvbuf->crypto_amount);
	dbm_deccopy(&shcchiplog.crypto_cb_amount, &emvbuf->crypto_cb_amount);
	strcpy(shcchiplog.srv_restrict_code, emvbuf->srv_restrict_code);
	strcpy(shcchiplog.term_cap_profile, emvbuf->term_cap_profile);
	strcpy(shcchiplog.tvr, emvbuf->tvr);
	strcpy(shcchiplog.unpredictable_num, emvbuf->unpredictable_num);
	strcpy(shcchiplog.term_ser_num, emvbuf->term_ser_num);
	strcpy(shcchiplog.cvr, emvbuf->cvr);
	strcpy(shcchiplog.issuer_discre_data, emvbuf->issuer_discre_data);
	strcpy(shcchiplog.cryptogram, emvbuf->cryptogram);
	strcpy(shcchiplog.app_txn_counter, emvbuf->app_txn_counter);
	strcpy(shcchiplog.app_ichg_profile, emvbuf->app_ichg_profile);
	strcpy(shcchiplog.arpc_cryptogram, emvbuf->arpc_cryptogram);
	strcpy(shcchiplog.arpc_respcode, emvbuf->arpc_respcode);
	strcpy(shcchiplog.issuer_script_res, emvbuf->issuer_script_res);
	strcpy(shcchiplog.ccard_sch_crypto, emvbuf->ccard_sch_crypto);
	strcpy(shcchiplog.issuer_app_data, emvbuf->issuer_app_data);
	strcpy(shcchiplog.issuer_auth_data, emvbuf->issuer_auth_data);
	shcchiplog.site_id = mbGetSiteId();
	/* Insert into database */
	if( shcchiploginsertfd < 0 )
	if( (shcchiploginsertfd = dbm_open("shcchiplog_1", dbmid)) < 0 )
	{
		OTraceFatal("F-SHC-172002: Unable to open shcchiplog_1 index:  %d\n", dbm_errno);
		return( -1 );
	}

	if(dbm_insert(shcchiploginsertfd, (char *)&shcchiplog, 0) < 0)
	{
		OTraceFatal("F-SHC-172003: Unable to insert chip record: %d\n", dbm_errno);
		if(dbm_errno == EBADF)
		{
			OTraceFatal("F-SHC-172003.1:  Shc needs to kill itself for the above DBM error.. curfd [%d]\n", shcchiploginsertfd);
			kill(getpid(),1);
		}
		else
			OTraceFatal("F-SHC-172003.2:  shc DOES NOT need to kill itself for this DBM error.. curfd [%d]\n", shcchiploginsertfd);
		return( -1 );
	}
	header->msg.device_devcap |= SH_DEVICE_LOG_SHCCHIPLOG;
	OTraceDebug("D-SHC-172004: New record logged for shcchiplog \n");
	return ( 0 );
}

/*
 *	Function:		shc_logadd_open
 *	Description:	Opens the shc_logadd index to handled the table
 *	Returns:		0: On success
 */
int ShcGenericLogHelper::shc_logadd_open()
{
	if(shc_logadd_fd == -1)
	{
		if((shc_logadd_fd = dbm_open( "pkshclog_add", dbmid )) < 0)
		{
			OTraceFatal("F-SHC-172051:LOGADD: Unable to open pkshclog_add index, errno=%d\n", dbm_errno);
			return(-1);
		}
	}
	return(0);

}	/*	shc_logadd_open	*/

int ShcGenericLogHelper::map_Shclogadd( ShcmsgHeader *header )
{
	SHCLOG_ADD			*p_shclog_add = NULL;
	struct shcsegstart	*pSegStart    = NULL;
	struct shcseg		*pSeg      = shcmsgLocateSegmentStart( &(header->msg) );
	int                  optAction = 0;

	if( shc_logadd_open() < 0 )
		return( -1 );

	if( (pSegStart=shc_segfind( pSeg, SHC_INDSPE_SEG ) ) == NULL )
	{
		OTraceWarning("W-SHC-172047:SEG-ADD: Segment[%s] not found\n", SHC_INDSPE_SEG );
		return( -1 );
	}

	if((p_shclog_add=(SHCLOG_ADD *)shc_seggetdata_pointer(pSeg,pSegStart))==NULL)
	{
		OTraceWarning("W-SHC-172048:SEG-ADD: Segment [%s] has no SHCLOG_ADD data\n",	SHC_INDSPE_SEG );
		return( -1 );
	}

	memcpy( &shclog_add, p_shclog_add, sizeof(SHCLOG_ADD) );

	if( isxdigit( shclog_add.shclog_idx[0] ) )	/* shclog_idx is existed */
	{
		strcpy( ((ShcLog *)(header->shcLogObj))->shclog.chip_index, shclog_add.shclog_idx );
	}
	else
	{
		strcpy( shclog_add.shclog_idx, header->msg.shclog_id );
	}

	shclog_add.site_id = mbGetSiteId();
	shclog_add.msgtype =  header->msg.msgtype;

	if( dbm_insert( shc_logadd_fd, (char *)&shclog_add, 0 ) < 0 )
	{
		OTraceError("E-SHC-172049:SEG-ADD: Failed to insert SHCLOG_ADD[%d] m%04d/t%06ld\n",
			dbm_errno, header->msg.msgtype, header->msg.trace );
		if(dbm_errno == EBADF)
		{
			OTraceFatal("F-SHC-172049.1:  Shc needs to kill itself for the above DBM error.. curfd [%d]\n", shc_logadd_fd);
			kill(getpid(),1);
		}
		else
			OTraceFatal("F-SHC-172049.2:  shc DOES NOT need to kill itself for this DBM error.. curfd [%d]\n", shc_logadd_fd);
		return( -1 );
	}
	OTraceDebug("D-SHC-172050:SEG-ADD: Inserted SHCLOG_ADD[%s] m%04d/t%06ld\n",
			shclog_add.shclog_idx, header->msg.msgtype, header->msg.trace );

	return( 0 );
}

int ShcGenericLogHelper::hashValue(const char* ptr)
{
	if( (ptr == NULL) || (noOfGenLogItem == 0) )
		return 0;

	int sum = 0;
	for(;*ptr;ptr++)
		sum += *ptr;
	return sum;
}

ShcGenericLogHelper::~ShcGenericLogHelper()
{

	DBMFreeStmt(shUpdate, DBM_DROP);

	if( sbufList )
	{
		//first free the memory allocated for buf
		for(int i=0;i<SHC_GENERIC_LOG_BINARY_FIELD_NUM;i++)
		{
			if( (sbufList+i)->buf != NULL )
				delete (sbufList+i)->buf;
		}
		delete []sbufList;
		sbufList = NULL;
	}
	if (valueBuf)
		free(valueBuf);

	if (segMapList)
		delete []segMapList;
}

IstSegList *ShcGenericLogHelper:: restore(ShcmsgHeader *header, char _reqresp, char *reqBufHeader, int reqBufHeaderLen, char *respBufHeader, int respBufHeaderLen)
{
	int i;
//	if (noOfGenLogItem <= 0)
//	{
//		OTraceDebug("D-SHC-131041:No segments configured to log\n");
//		return;
//	}

	DBMHSTMT currentHdl;

	struct dbBufferHlpr *tmpBufList = bufList;
	if (header->origMsg)
		strcpy(logid, header->origMsg->shclog_id);
	else
		strcpy(logid, header->msg.shclog_id);

	indb[0] = strlen(logid);

	if( (_reqresp == 'B') || (_reqresp == 'A') )		//	R018777
	{
		currentHdl = shLoadBoth;
	}
	else	//either request or response
	{
		reqresp = _reqresp;
		currentHdl = shLoad1;
	}

	//	>>>	R024803
	//if( DBMExecute(currentHdl) != DBM_SUCCESS )
	int ret;
	ret = DBMExecute(currentHdl);
	if ( ret != DBM_SUCCESS )
	{
		OTraceError("E-SHC-131042: Error when executing load query [%c].\n", _reqresp);
		processError(ret,currentHdl);
		return NULL;
	//	<<<	R024803
	}

	IstSegList *segList = new IstSegList;
	
	try
	{
		indb[3] = indb[4] =indb[5] =indb[6] =indb[7] = 0 ;
		while((ret = DBMFetch(currentHdl)) == DBM_SUCCESS)
		{
			valueBufLen = (indb[3]>0?indb[3]:0) + (indb[4]>0?indb[4]:0) + (indb[5]>0?indb[5]:0) + (indb[6]>0?indb[6]:0) + (indb[7]>0?indb[7]:0);
			if ((reqresp == 'Q') && reqBufHeader)
				segList->parse(valueBuf, valueBufLen, reqBufHeader, reqBufHeaderLen);
			else if (respBufHeader)
				segList->parse(valueBuf, valueBufLen,respBufHeader, respBufHeaderLen);
			
		}
	
		processError(ret, currentHdl);
	
		DBMFreeStmt(currentHdl, DBM_CLOSE);
	}
	catch(...)
	{
		delete segList;
		return NULL;
	}
	return segList;
}


