/*
 *  Copyright (C) 2004 eFunds Corporation ("eFunds").  All Rights Reserved.     
 *  eFunds Canada Corporation is an authorized user.                            
 *                                                                              
 *  IST is a registered trademark of eFunds Corporation.  Other brand or        
 *  product names are trademarks or registered trademarks of their respective   
 *  holders.                                                                    
 *                                                                              
 *  The information contained herein is the unpublished proprietary property    
 *  of eFunds.  Except as specifically authorized in writing by eFunds, the     
 *  holder of this document shall: i) keep all information contained herein     
 *  confidential, and ii) protect the information, in whole or in part, from    
 *  disclosure and dissemination to all third parties.                          
 *                                                                          
 *  This document and the software described in it are furnished under license  
 *  and may be used or copied only in accordance with the terms of such license.
 *  This document is supplied for information purposes only, is subject to      
 *  change without notice, and should not be construed as a commitment by       
 *  either eFunds Corporation or eFunds Canada Corporation. 
 */
/*
#pragma ident "@(#) shc_seg.cxx 1.5.1.4 20/03/15 19:56:40"
 *
 *                        MODIFICATION HISTORY                  REVIEW
 *
 *	SPR#	Who	Date	Description			Who	Date   
 * ===========================================================================
 *  bsa 	26Oct93		Created for use with the terminal manager
 *	ad		13jan94		Added a series of 'one step' conveneince functions.
 *R006893 ztang 14Jan02 Fixed byte alignment bug
 *R007796 ztang 16May02 Fixed byte alignment bug for option
 *R008019 ztang 03Jul02 Fixed byte alignment again
 * R008117 jyang 06Aug02 Support to append segment fields
 *R008387 ztang 10Oct02 Support adding data more than once to segment
 *R008717 ztang 11Dec02	Add get_seg_from_shcmsg()
 *R008785 jyang 20Dec02 Support restoring segment fields from event
 *R00
 *R020235 vmp	06Jun07	restored emv segment for turnaround 420
 */
/* File Number 15 */

#if defined( WIN32 )
#       define SHCDLLEXPORT __declspec(dllexport)
#else
#       define SHCDLLEXPORT
#endif


#include <stdio.h>
#include <oasis.h>
#include <mb.h>
#include <dbm.h>
#include <ist_otrace.h>
#include <shc.h>
#include <shcmsgdef.h>
#include <shcseg.h>
#include <string.h>
#include <istsafe.h>
#include <algorithm>

/*************************************************************************
 *	Manupilating segments
 *
 *	to locate a segment
 *			shc_segfind()
 *			shc_segfindnext()
 *
 *	to get first segment
 *			shc_segfirst()
 *
 *	to get next segment
 *			shc_segnext()
 *
 *	
 *************************************************************************/

struct shcseg *shcmsgLocateSegmentStart(struct shcmsg *msg)
{
	struct shcseg *segP =reinterpret_cast<struct shcseg *>( (msg) + 1);
	if (	segP->nsegments > 200 || 
			segP->nsegments <= 0 ||
			segP->totalsize > SHC_SEG_MAX ||
			segP->totalsize <=0
		)
	{
		segP->totalsize = 0;
		segP->nsegments = 0;
	}
	
	return segP;
		
}


int shc_segnsegments(struct shcseg *seg)
{
	return(seg->nsegments);
}

int shc_seglength(struct shcseg *seg)
{
	return(seg->totalsize);
}


char *shc_segname(struct shcseg *seg, struct shcsegstart *sp)
{
	return(sp->type);
}


struct shcsegstart *shc_segfind(struct shcseg *seg, const char *type)
{
	return(shc_segfindnext(seg, NULL, type));
}


struct shcsegstart
	*shc_segfindnext(struct shcseg *seg, struct shcsegstart *sp, const char *type)
{
	if(seg->nsegments <= 0)
		return(NULL);

	sp = shc_segnext(seg, sp);

	if(sp == NULL)
		return(NULL);

	while(sp != NULL)
	{
		if(type == NULL)
			return(sp);

		if(stricmp(sp->type, type) == 0)
			return(sp);
		
		sp = shc_segnext(seg, sp);
	}

	return(NULL);
	
}


struct shcsegstart *shc_segfirst(struct shcseg *seg)
{
	struct	shcsegstart	*sp;

	if (!seg->nsegments)
		return NULL;
		
	seg->current = 1;
	sp = (struct shcsegstart *)(seg + 1);

	if (((char *)sp) + sp->segsize > ((char *)seg)+seg->totalsize )
	{
		/* Out of segment already */
		OTraceWarning("I-SHC-015001: Segment out of boundary\n");
		return (NULL);
	}
	return(sp);
}


struct shcsegstart *shc_segnext(struct shcseg *seg, struct shcsegstart *sp)
{
	if(sp == NULL)
		return(shc_segfirst(seg));

	if(sp == NULL)
		return(NULL);
		
	if (seg->current >= seg->nsegments)
		return (NULL);
		
	sp = (struct shcsegstart *)( (char *)sp + sp->segsize);
	seg->current++;

	if (((char *)sp) + sp->segsize > ((char *)seg)+seg->totalsize )
	{
		/* Out of segment already */
		OTraceWarning("I-SHC-015002: Segment out of boundary\n");
		return (NULL);
	}
	return(sp);
}



int shc_segnopt(struct shcseg *seg, struct shcsegstart *sp)
{
	
	return(sp->nopt);
}


struct	shcsegopt 
	*shc_segfindopt(struct shcseg *seg, struct shcsegstart *sp, int type)
{
	struct	shcsegopt	*sopt;

	for(sopt = NULL; ; )
	{
		sopt = shc_segnextopt(seg, sp, sopt);
		if(sopt == NULL)
			return(NULL);
		
		if(sopt->opt == type)
			return(sopt);
	}
}




struct	shcsegopt *shc_segfirstopt(struct shcseg *seg, struct shcsegstart *sp)
{
	return(shc_segnextopt(seg, sp, NULL));
}


struct	shcsegopt
	*shc_segnextopt(struct shcseg *seg,
	struct shcsegstart *sp, struct shcsegopt *sopt)
{

	if(sopt == NULL)
		sp->current = 0;
	
	if(sp->current >= sp->nopt)
		return(NULL);
	
	if(sp->current == 0)
		sp->sopt = (struct shcsegopt *)(sp + 1);
	else
	{
		sp->sopt = (struct shcsegopt *)( (char *)sopt + sopt->optlen );
	}

	
	++(sp->current);
	return(sp->sopt);
}


char *shc_seggetoptdata(struct shcseg *seg,
	struct shcsegstart *sp, struct shcsegopt *sopt)
{
	if(sopt->datalen <= 0)
		return(NULL);
	else
		return(sopt->optdata);
}


char *shc_seggetdata_pointer(struct shcseg *seg, struct shcsegstart *sp)
{

	return(
		(char *)( (char *)sp + sp->optlen + sizeof(struct shcsegstart) )
		);
}


int shc_seggetdata_len(struct shcseg *seg, struct shcsegstart *sp)
{
	return(sp->datalen);
}

/*************************************************************************
 *
 *	Conveneince functions.
 *	These functions do not extend the functionality. They simply
 *	provide simplified access to the segments.
 *
 *	The functions assume as a first parameter 'shcmsg'
 *
 *************************************************************************/
char *shc_segcf_getdata(struct shc *shcmsg, char *segname)
{
	/*
	 *	Given a segment name, return the data pointer to that segment
	 */
	struct	shcseg			*segp;
	struct	shcsegstart		*sp;
	
	if(!shcHasSegment(shcmsg))
		return(NULL);
	
	segp	= shcmsgLocateSegmentStart(&shcmsg->msg);
	sp		= shc_segfind(segp, segname);

	if(sp == NULL)
		return(NULL);
	
	return(shc_seggetdata_pointer(segp, sp));
}

	
/*************************************************************************
 *	Creating segments
 *
 *	Segments should be created as follows
 *
 *		shc_segbegin()
 *			for(each segment)
 *				shc_segaddsegment()
 *					for(each option)
 *						shc_segaddoption()
 *					shc_segadddata()
 *
 *		shc_segend()
 *
 *************************************************************************/
struct shcseg *shc_segallocate(long size)
{
	struct	shcseg *seg;

	long tmpvar = (IstSafeLong(sizeof(struct shcseg)) * 2).getLong();
	size = (IstSafeLong(size) + tmpvar).getLong();
	seg = (struct shcseg *)calloc(size, 1);
	if(seg == NULL)
		return(NULL);
	
	shc_segbegin(seg);
	return(seg);
}

int shc_segbegin(struct shcseg *seg)
{
	seg->totalsize	= 0;
	seg->nsegments	= 0;
	seg->p			= (char *)(seg + 1);
	seg->sp			= NULL;

	return(0);
}


int shc_segaddsegment(struct shcseg *seg, const char *type)
{
	/*	Calculate current segment size */
	if(seg->sp)
	{
		seg->sp->segsize = seg->p - (char *)seg->sp;
	}


	/*	next available address in segment buffer */
	seg->sp = (struct shcsegstart *)seg->p;
	seg->p  = seg->p + sizeof(struct shcsegstart);

	memset(seg->sp, 0, sizeof(struct shcsegstart));
	//strcpy(seg->sp->type, type);
	istsafe_strcpy(seg->sp->type, sizeof(seg->sp->type), type);
	++seg->nsegments;
	return(0);
}


int shc_segaddoption(
	struct shcseg *seg, shcsegopt_t opt, long action, const char *data, long datalen)
{
	struct	shcsegopt	*sopt;
	int					dlen;
	
	/*	next available address */
	sopt = (struct shcsegopt *)seg->p;

	/*	option length */
	/* Although we give optdata 1 char, the compiler can autually give 4, so let's see
	 * what's the real size of optdata
	 */
	int realoptdatalen = sizeof(struct shcsegopt) - (&sopt->optdata[0] - (char *)sopt);
	if(datalen > realoptdatalen)
		dlen = datalen - realoptdatalen;	/* adjust for databuffer of one byte */
	else
		dlen = 0;

	/* Make sure the extra data is aligned properly */
	if (dlen > 0)
		dlen = ((IstSafeInt(dlen)+7).getInt())/8*8;

	sopt->optlen  = (IstSafeLong(sizeof(struct shcsegopt)) + dlen).getLong();
	sopt->opt = opt;
	sopt->datalen = datalen;
	sopt->action = action;

	if(datalen > 0 && data != NULL)
		memcpy(sopt->optdata, data, min<long>(datalen, sizeof(sopt->optdata)));

	seg->p = seg->p + sopt->optlen;

	seg->sp->optlen = seg->sp->optlen + sopt->optlen;
	++seg->sp->nopt;
	return(0);
}


int shc_segadddata(struct shcseg *seg, const char *bp, int len)
{
	if (seg->sp->datalen > 0)
	{/* Already have data, need to reverse the memory alignment so the new data can be right after the old data */
		int adjustLen;
		adjustLen = 8 -seg->sp->datalen%8;
		seg->sp->segsize -= adjustLen;
		seg->p -= adjustLen;
	}
	memcpy(seg->p, bp, len);
	
	seg->sp->datalen += len;
	
	int additionalAlignmentByte = 8 - seg->sp->datalen%8;
	
	len = len+additionalAlignmentByte;
	seg->sp->segsize += len;

	/* Make sure the pointer is aligned properly */
	seg->p = seg->p + len;
	return(0);
}



int shc_segend(struct shcseg *seg)
{
	/*	calculate actual size */
	if(seg->sp)
	{
		/*	calculate last segment size */
		seg->sp->segsize = seg->p - (char *)seg->sp;
	}
	
	seg->totalsize = seg->p - (char *)seg;
	return(0);
}


/* R008117 >> */
int shc_segAppendBegin(struct shcseg *pSeg)
{
	struct shcsegstart *sp;

	if( (sp=shc_segfirst(pSeg)) && pSeg->nsegments>0 )
	{
		for( int i=0; sp && i<pSeg->nsegments; i++ )
		{
			pSeg->sp = sp;
			pSeg->p = (char*)sp + sp->segsize;
			sp = shc_segnext(pSeg, sp);
		}
	}
	else
		shc_segbegin(pSeg);

	return( 0 );
}

/* R008117 >> */
int shc_segAppendNoOpt( struct shcmsg *msg, char *segName, char *segData, int segLen )
{
	if( msg && segName && *segName && segData )
	{
		struct shcseg *pSeg = (struct shcseg*)(msg+1);
		
		if (msg->device_cap & SH_DEVCAP_USER_SEGMENT)
			shc_segAppendBegin( pSeg );
		else
			shc_segbegin(pSeg);
		msg->device_cap |= SH_DEVCAP_USER_SEGMENT;
		shc_segaddsegment( pSeg, segName );
		shc_segadddata( pSeg, (char*)segData, segLen );
		shc_segend( pSeg );
		return( shc_seglength(pSeg) );
	}

	return( 0 );
}
/* R008117 << */

/* R008717 BEGIN*/
void *get_seg_from_shcmsg(struct shcmsg *shcmsg, char *segName, int *segLen)
{
	struct shcseg   *shcsegP;
	struct shcsegstart      *sp;

	if (!(shcmsg->device_cap & SH_DEVCAP_USER_SEGMENT))
		return NULL;
	shcsegP = (struct shcseg *)&shcmsg[1];
	if((sp=shc_segfind(shcsegP, segName)))
	{
		*segLen = shc_seggetdata_len(shcsegP, sp);
		return (void *)shc_seggetdata_pointer(shcsegP, sp);
	}
	else
		return NULL;
	
}
/* R008717 END */

int shc_segAppend4Restore( struct shcmsg *msg, char *segName, char *segData, int segLen )
{
	if( msg && segName && *segName && segData )
	{
		struct shcseg *pSeg = (struct shcseg*)(msg+1);
		if (msg->device_cap & SH_DEVCAP_USER_SEGMENT)
			shc_segAppendBegin( pSeg );
		else
			shc_segbegin(pSeg);
		msg->device_cap |= SH_DEVCAP_USER_SEGMENT;
		shc_segaddsegment( pSeg, segName );
		shc_segaddoption( pSeg, SHC_SEG_RESTORE, SHC_SEG_RESTORE, NULL, 0 );
		shc_segadddata( pSeg, (char*)segData, segLen );
		shc_segend( pSeg );
		return( shc_seglength(pSeg) );
	}

	return( 0 );
}

int shc_restoreSegField( struct shcmsg *msg, struct shcmsg *omsg )
{
	struct shcseg      *pSeg = (struct shcseg*)(omsg+1);
	struct shcsegstart *sp   = NULL;
	struct shcsegopt   *pSegOpt  = NULL;
	int i = 0;
	
	if (!shcmsgHasSegment(omsg))
		return NULL;
		
	if ( (sp=shc_segfirst(pSeg)) && pSeg->nsegments>0 )
	{
		for ( i=0; sp && i<pSeg->nsegments; i++ )
		{
			int restored = 0;		//		R020235
			pSeg->sp = sp;
			pSeg->p = (char*)sp + sp->segsize;
			
			if ( (pSegOpt = shc_segfindopt(pSeg, sp, SHC_SEG_RESTORE)) != NULL )
			{
				if ( pSegOpt->action==SHC_SEG_RESTORE && pSegOpt->opt==SHC_SEG_RESTORE )
				{
					shc_segAppendNoOpt( msg, shc_segname(pSeg,sp)
						, shc_seggetdata_pointer(pSeg,sp), shc_seggetdata_len(pSeg,sp) );
						restored = 1;		//		R020235
				}
			}
			//		>>>		R020235 
			if(!restored)
			{
				/*check for some special cases, for emv segment but
				we should restore all the cases */
				if(strcmp(shc_segname(pSeg,sp), "EMV_BUF")==0)
				{
					int len;
					void *e=get_seg_from_shcmsg(msg, "EMV_BUF",&len);
					if(!e)
					{
						shc_segAppendNoOpt(msg,shc_segname(pSeg,sp)
								, shc_seggetdata_pointer(pSeg,sp), shc_seggetdata_len(pSeg,sp) );

						restored = 1;
					}

				}
			}
			//		<<<		R020235
			sp = shc_segnext(pSeg, sp);
		}
		if ( i == pSeg->nsegments )
			return( 0 );
	}
	return( -1 );
}		

