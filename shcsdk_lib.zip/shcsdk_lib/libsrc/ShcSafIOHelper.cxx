/*
 *  Copyright (C) 2004 eFunds Corporation ("eFunds").  All Rights Reserved.     
 *  eFunds Canada Corporation is an authorized user.                            
 *                                                                              
 *  IST is a registered trademark of eFunds Corporation.  Other brand or        
 *  product names are trademarks or registered trademarks of their respective   
 *  holders.                                                                    
 *                                                                              
 *  The information contained herein is the unpublished proprietary property    
 *  of eFunds.  Except as specifically authorized in writing by eFunds, the     
 *  holder of this document shall: i) keep all information contained herein     
 *  confidential, and ii) protect the information, in whole or in part, from    
 *  disclosure and dissemination to all third parties.                          
 *                                                                          
 *  This document and the software described in it are furnished under license  
 *  and may be used or copied only in accordance with the terms of such license.
 *  This document is supplied for information purposes only, is subject to      
 *  change without notice, and should not be construed as a commitment by       
 *  either eFunds Corporation or eFunds Canada Corporation. 
 */
/*
#pragma ident "@(#) ShcSafIOHelper.cxx 1.24.2.7 20/03/25 13:13:31";
 *
 *                        MODIFICATION HISTORY                  REVIEW
 *
 *	SPR#	Who	Date	Description			Who	Date   
 * ===========================================================================
 * 10001959 la	10may96 Added function to SAF with a specific route.
 * 10002361 la  01jul96 Save and restore message type.
 * XXXXXXXX la  05jul96 Prevent saf messages from being saf'ed again.
 * XXXXXXXX la  07jul96 Determine whether to send SAF now or later based on
 * 10002358 la  24jul96 Test if response is < 0 instead of = -1
 * 10002676 jsg 961108  Check for IBFT on advice coerce 
 *                       the current bin status.
 *	ss		27Mar92		In locate_transaction route: 1) need to seek
 *						to start of file. 2) Don't need to call shc_makekey.
 *						3) Check Msgtype, 4) Correct a bug in stricmp
 *	
 *	aes		22Jul93		The amounts in the SAF file will be
 *						stored in the switch's currency.
 *	jt		22feb96		No longer write to saf file but msg is sent to istadvice
 *						instead, then let istadvice/istreplay handle or saf msg.
 *	wc		16dec97		Added more message types in shc_saf_determine_file
 *						(ACXSYS)
 *	R000818 wc	980224	Added header time.h.
 *  R000973 et  02may98 Changed stricmp to ICBin_cmp
 *  R001041 et  01jun98 Changed logic for safcutoffdate and cap_date   
 *  2005371 qd  31jul98 Reset SH_DEVCAP_FROM_NETWORK flag before store msg   
 *  R001794 qd  03feb99 Update saf status if posauth did not appove the transaction
 *  R001835 qd  18may99 Interac Merge
 * R003368	jsun	23Nov99	Fix core dump caused by ODebug
 *	R003631	HJ	02Dec99	Delete unnessary code which can create error message
 *	R004439	HJ	19Apr00	Fix bug in shc_saf_open_file
 *	R003895	rlo	20Apr00	Match the internal reversal flag when saf.
 *  R004761 fg  14Jun00 Change debug info    
 * R004938 jsun 21Jul00 Assign origdate/time with trandate/time for Interac
 * R005129 jsun 30Oct00 Undo the change of R004938 for Interac bm90
 * R005896 jy	07May01	Added a funtcion to convert response msg to advice msg 
 *						for SAF and changed function shc_saf_writefile()
 * R006621	hsh	05Sep01	Verify if the msg has a segment. If so, the size of the
 *						segment has to be included in the mb_write
 *R007617 jyang 19Mar02 Support to SAF approved advice message 
 *R008779 jyang 02Jan03 Multi-institution support
 *R011307 Emj   18Oct04 Retreve Safcutoffdate from business day profile
 *R011943 jyang 17Sep04 Calculate segmant length correctly
 *R016871 spa   06Jul06 Added definition for ShcSafIOHelper::net_saf_exists(struct shcpkg *pkg)
 *R000000 jyang 17Oct06 Safdb support in dswitch
 *R000000 jyang 11Mar08 Bin Route support
 *R023231 Ram   23May08 The SDK header should refer to external header
 *R026229 Ash   27Mar09 Remove sensitive data from SAF File
 *R027876 Dipa  02Mar10 Segment changes
 *R027876 Dipa  22Apr10 Segment changes - fix
 *R028104 Dipa  29Apr10 routingInfo fix
 *R028271 Dipa  18Jun10 Txn Statistics 
 *R030381 Dipa  10Mar12 Txn Statistics - more changes
 */

//File Number 35

#if defined( WIN32 )
#       define SHCDLLEXPORT __declspec(dllexport)
#else
#       define SHCDLLEXPORT
#endif


#include <stdio.h>
/* ACXSYS: wc R000818 */
#include <time.h>
#include <string.h>
#include <oasis.h>
#include <oasisenv.h>
#include <ist_otrace.h>
#include <fcntl.h>
#include <unistd.h>
#include <ShcMsgCache.h>
#include <shcmsgdef.h>
#include <shc.h>
#include <dirent.h> /* R001794 */
#include <ic/ic_bin.h>

#include <ShcHelper.h> //	--- R023231
#include <ShcmsgHelper.h>
#include <ShcSafIOHelper.h>
#include <ShcTimerHelper.h>
#include <ShcAppBase.h>
#include <ShcBin.h>
#include <BinRoute.h>
#include <ist_seg_name.h> //R027876
#include <ist_seg_elf_id_map.h> //R027876
#include <ist_seg_id.h> //R027876
#include <istsafe.h>
#include <algorithm>
//R028271 >>>
#include <TxnStat.h>
#include <mb_umi.h>
//<<< R028271

/*
 *	File I/O routines for SAF module
 */

extern int errno;

ShcBin *ShcSafIOHelper::shc_saf_determine_file(ShcmsgHeader *header)
{
	/*
	 *	Determine which file to use
	 *	Open the file
	 *	Return the institution paramaters we are using
	 */

	ShcBin *shcBin;

	if(header->msg.msgtype == SHC_STLMTREQ 
	   	|| header->msg.msgtype == SHC_STLMTREQ_ADVICE
		/* wc	16dec97		R000586 ACXSYS -->start	*/
	   	|| header->msg.msgtype == SHC_CHARGE_BACK_ADVICE              
	   	|| header->msg.msgtype == SHC_ISS_ADMIN   
	   	|| header->msg.msgtype == SHC_ISS_ADMIN_ADVICE )	 
		/* wc	16dec97		R000586 ACXSYS -->end	*/
			shcBin = header->acqShcBin;
	else
			shcBin = header->issShcBin;
	/*
	 *	o	Determine output file
	 */
	char fName[80] = {0};
	snprintf( fName, sizeof(fName), "%s.%s", shcBin->binPkg->bin.institutionid, shcBin->binPkg->bin.userbinid );
	shc_saf_routename_pure( fName );
	
	return(shcBin);
}




int ShcSafIOHelper::shc_saf_write_transaction(ShcmsgHeader *header)
{
	/*
	 *	Write a transaction to the Saf file for this inistution
	 */
	ShcBin *shcBin;

	shcBin = shc_saf_determine_file(header);
	shc_saf_writefile(shcBin, header);

	return(0);
}




int ShcSafIOHelper::shc_saf_open_file(char *netid)
{
	/*
	 *	Given a network id return a file descriptor for
	 *	that institution
	 */
	
	int	fd;
	/* R003631 *//* R004439 */
	char	buf[128], name[128], *ptr;	/* R001794 */

	ptr = netid;
	while (*ptr == ' ') 
		ptr++;
	//strcpy(name, ptr);
	istsafe_strcpy(name, sizeof(name), ptr);
	if (shc_saf_get_name(name, sizeof(name)) < 0)
		return -1;
	snprintf(buf, sizeof(buf), "%s/%s%s",
				 uenv_constructfile(OLOGDIR_ENV, SAFDIR), name, DEFEXT);

	fd = open(buf, O_RDWR, 0666);

    if(fd < 0)
        { OTraceError("E-SHC-0828 get_saf: Error: %d: Open(%s)\n", errno, buf);}
    else
        OTraceInfo("I-SHC-035001: Open(%s) with fd %d\n", buf, fd );

	/*	Assume that the netid has been normalized */

	/*	jt	22feb96		not creating/writing to saf, to istadvice instead	*/
	/*
	char	buf[128];	
	sprintf(buf, "%s/%s.saf", uenv_constructfile(OLOGDIR_ENV, "saf"), netid);
	fd = open(buf, O_RDWR | O_CREAT, 0666);

	if(fd < 0)
		OTraceFatal("F-SHC-035002: get_saf: Error: %d: Open(%s)\n", errno, buf);
	*/
	/* fd = -1; R001794 */

	return(fd);
}


int ShcSafIOHelper::shc_saf_close_file(ShcBin *shcBin)
{
	/*	jt	22feb96		not creating/writing to saf, to istadvice instead	*/
	if( shcBin->binPkg->saf.fd == (-1) )
		return (0);

	close(shcBin->binPkg->saf.fd);
	shcBin->binPkg->saf.fd = -1;
	
	return 0;
}


int ShcSafIOHelper::shc_saf_writefile(ShcBin *shcBin, ShcmsgHeader *header)
{
	//  >>> R026229
	//Used to restore sensitive data
	char       rst_cvv2[sizeof(header->msg.cvv2)];
	char    rst_pin[sizeof(header->msg.pin)];
	char    rst_track2[sizeof(header->msg.track2)];
	char    rst_track3[sizeof(header->msg.track3)];

	//store return value in tmp variable
	int tmp_ret;

	//store Sensitive data in tmp variables

	memcpy(rst_cvv2,header->msg.cvv2,sizeof(header->msg.cvv2));
	memcpy(rst_pin,header->msg.pin,sizeof(header->msg.pin));
	memcpy(rst_track2,header->msg.track2,sizeof(header->msg.track2));
	memcpy(rst_track3,header->msg.track3,sizeof(header->msg.track3));
	//  <<< R026229
	/*
	 *	Write to the output file
	 */
	header->msg.shc_devcap &= ~SH_DEVCAP_SHC_STDIN;	/* R005896 */

	if(shcBin->binPkg->saf.type & SH_SAF_NOFILE)
		return(0);
	
	if( header->msg.device_cap & SH_DEVCAP_FROM_REPLAY )
	{
		OTraceInfo("I-SHC-035003:  saf ignored: device_cap indicates from replay\n");
		return( 0 );
	}

	//  >>> R026229
	if(shcApp->issuerShcParamsList->GetBool((char *)"shc.saf_remove_sensitive_data"))
	{
		memset(header->msg.pin, 0, sizeof(header->msg.pin));
		memset(header->msg.track2 , 0, sizeof(header->msg.track2));
		memset(header->msg.track3, 0, sizeof(header->msg.track3));
		memset(header->msg.cvv2,0, sizeof(header->msg.cvv2));
		OTraceDebug("D-SHC-035020:shc.saf_remove_sensitive_data is ON .Sensitive Data Removed Before SAF \n");
	}
	else
	{
		OTraceDebug("D-SHC-035021:shc.saf_remove_sensitive_data is OFF.Sensitive Data Not Removed Before SAF \n");
	}
	//  <<< R026229

	/*	jt	22feb96		not creating/writing to saf, to istadvice instead	*/
	OTraceDebug("D-SHC-035004: ShcSafIOHelper::shc_saf_writefile(),write to istadvice[%04d]\n",header->msg.msgtype);

	//  >>> R026229

	tmp_ret = shc_saf_toistadvice(shcBin, header);

	/* Restore Sensitive Data to shcmsg fields */
	memcpy(header->msg.cvv2,rst_cvv2,sizeof(rst_cvv2));
	memcpy(header->msg.pin,rst_pin,sizeof(rst_pin));
	memcpy(header->msg.track2,rst_track2,sizeof(rst_track2));
	memcpy(header->msg.track3,rst_track3,sizeof(rst_track3));
	return(tmp_ret);
	//  <<< R026229

}


int ShcSafIOHelper::shc_saf_checkduplicate_write(ShcmsgHeader *header, ShcBin *shcBin)
{
	/*
	 *	Check the saf file.
	 *	If the current transaction is found then
	 *		return 0
	 *	else
	 *		write the current transaction to the saf file
	 */
	/*struct	shc omsg;*/
	struct	istadvice advicemsg; /* R001794 */
	int		ret;

	/* R001794 */
	/*ret = shc_saf_locate_transaction(header, shcBin->binPkg->saf.fd, &omsg);*/
	ret = shc_saf_locate_transaction(header, shcBin->binPkg->saf.fd, &advicemsg);

	if(ret < 0)
	{
		/*	Update the transaction to disk */
		header->msg.saf = SH_SAF_PENDING;

		/*	ad:	30Nov91		forgot to actualy write transaction. */
		shc_saf_writefile(shcBin, header);
		return(1);
	}
	else
		return(0);
}


int ShcSafIOHelper::shc_saf_find_txn(ShcmsgHeader *header, int code)
{
	/*
	 *	Locate the message in the output file
	 *	and set the saf flag to code
	 */
	
	ShcBin *shcBin;
	struct	istadvice advicemsg; /* R001794 */
	int		ret = (-1);

	shcBin = shc_saf_determine_file(header);
	ret = shc_saf_locate_transaction(header, shcBin->binPkg->saf.fd, &advicemsg);

	if(ret == 0)
	{
		advicemsg.status = code;
		lseek(shcBin->binPkg->saf.fd, -sizeof(advicemsg), 1);
		write(shcBin->binPkg->saf.fd, &advicemsg, sizeof(advicemsg));
	}

	shc_saf_close_file(shcBin);
	return(ret);
}


/* R001794 now the file contains istadvice structure */
/*shc_saf_locate_transaction(ShcmsgHeader *header, int fd, struct shc *omsg)*/
int ShcSafIOHelper::shc_saf_locate_transaction(ShcmsgHeader *header, int fd, struct istadvice *advicemsg)
{
	/*
	 *	Locate an saf transaction in the open saf file
	 *
	 *	if found
	 *		return	0
	 *		leave file positioned just after the message
	 *
	 *	else
	 *		return -1
	 */
	/* long		trace;	NOT NECESSARY 27Mar92 */

	int			mtype, omtype;								/* 27Mar92. Sunny */
	struct shcmsg  *omsg; /* R001794 */
	
	omsg=(struct shcmsg *)advicemsg->buf; /* R001794 */

	/*	jt	22feb96		not creating/writing to saf, to istadvice instead	*/
	if (fd < 0)
		return(-1);

	mtype = (header->msg.msgtype % 10000) / 100;			/* 27Mar92 */
	lseek(fd, 0, SEEK_SET);									/* 27Mar92 */

	for(;;)
	{
		/* R001794 */
		/*if(read(fd, &omsg->msg, sizeof(omsg->msg)) < sizeof(omsg->msg))*/
		if(read(fd, advicemsg, sizeof(struct istadvice)) 
               < sizeof(struct istadvice))
			break;
		
		/*
		 *	Attempt to match
		 */
		omtype = (omsg->msgtype % 10000) / 100;			/* 27Mar92 */

		if(header->msg.trace == omsg->trace &&
		   mtype == omtype &&								/* 27Mar92 */
		   header->msg.local_time == omsg->local_time	&&
		   header->msg.local_date == omsg->local_date	&&
		   stricmp(header->msg.termid, omsg->termid) == 0	&&
		   stricmp(header->msg.pan, omsg->pan) == 0			&&
/* R000973 et */
// R005156		   ICBin_cmp(header->msg.acquirer, omsg->acquirer) == 0 /* 27mar92*/
		   ICBin_cmp((ICBINp)header->msg.acquirer, (ICBINp)omsg->acquirer) == 0 	// R005156
		  )
		{
			/* R003895 Match the internal reversal flag if it is a 400 */
			if((header->msg.msgtype / 100) == 4)
			{
				OTraceDebug("D-SHC-035005:  Verify the internal reversal flag.\n");
				OTraceDebug("D-SHC-035006:  The message that SHC wants to locate has the internal reversal flag %s.\n", shc_internalrev(header)? "ON" : "OFF");
				OTraceDebug("D-SHC-035007:  The message that SHC got has the internal reversal flag %s.\n", (omsg->device_cap & SH_DEVCAP_INTERNALREV)? "ON" : "OFF");
				if(shc_internalrev(header) != (omsg->device_cap & SH_DEVCAP_INTERNALREV))
				{
					OTraceInfo("I-SHC-035008:	Internal reversal flag does not match. Fetch the next record.\n");
					continue;
				}
				else
				{
					OTraceInfo("I-SHC-035009:  Internal reversal flag matches.\n");
				}
			}
			OTraceInfo("I-SHC-035010: Found message in file\n");
			return(0);
			/* End R003895 */
		}
	}

	return(-1);
}


/* 10001959 */
/* wc 22dec97	R000586 ACXSYS--> add pkg to prototype */
int ShcSafIOHelper::shc_saf_byname(ShcBin *shcBin, ShcmsgHeader *header, char *name, int send )
{
	/*
	 *	Note : In the cfg files, the entries for "advice.route" have to add the
	 *			the following lines, 1 line for 1 route/mailbo.
	 *
	 *	advice.route	networkid	mbname
	 *	advice.route	networkid	mbname
	 *
	 *	for example
	 *	advice.route	0000645601	OasisFormatter
	 *
	 */
	struct	istadvice	advice = {0};
	static	int			advicemb = -1;
	int			xmsgtype = 0;									/* 10002361 */
	long	tmpdate, tmptime;

	struct	shcseg	*t_seg;	/*	R006621	*/

	if( advicemb < 0 )											/* 10002358 */
	{
		if((advicemb=mb_locatemailbox_local(AUTH_ADVICE_NAME)) < 0)
		{
			OTraceWarning("W-SHC-035011: Unable to locate mailbox '%s'\n", AUTH_ADVICE_NAME);
			return( -1 );
		}
	}

	/*
	 *	create advice msg from shcmsg
	 */
	//strcpy(advice.route, name);
	istsafe_strcpy(advice.route, sizeof(advice.route), name);
	advice.status = (send ? SH_SAF_PENDING : SH_SAF_SKIPPED);
	xmsgtype = header->msg.msgtype;								/* 10002361 */
	//R028271 >>>
	if(!strlen(header->msg.shclog_id))
	{
		mb_getUmi(header->msg.shclog_id, sizeof(header->msg.shclog_id));
		mb_set_tid(header->msg.shclog_id, strlen(header->msg.shclog_id));
	}
	//<<< R028271

	shc_saf_convertmsg(header);

	if(((header->msg.msgtype == SHC_FINREQ_ADVICE) || 
		(header->msg.msgtype == SHC_AUTHREQ_ADVICE)) && 
		(header->msg.shc_devcap & SH_DEVCAP_SHC_EVENT))
	{
		/*	set advice repeat to indicate already advice sent to issuer.
			let istadvice check and reset the first replay flag.
		*/
		header->msg.flipped_msgtype = header->msg.msgtype+1;
		OTraceDebug("D-SHC-035022: Timeout advice message, added flipped msgtype:%d\n",
					 header->msg.flipped_msgtype);
	}
				/* R011943 >> */
	advice.datalen = std::min<int>(header->truelength(), sizeof advice.buf);
	memcpy(advice.buf, (char *)&header->msg, advice.datalen );
				/* R011943 << */


	/* wc	22dec97		R000586 ACXSYS	*/
	shc_saf_calculate_capdate(&advice, header); 

	OTraceDebug("D-SHC-035012:shc_saf_toistadvice(),route='%s',msgtype='%d',pan='%s',chipindex='%s'\n",
				advice.route, header->msg.msgtype, shcApp->shcHelperObj->shc_maskpan(header->msg.pan),
				header->msg.shclog_id);

	if( cache_mb_write(advicemb, shcmid, (char *)&advice, ADVICE_LENGTH) < 0 )
	{
		OTraceWarning("W-SHC-035013: Unable to write to advice server.\n");
		header->msg.msgtype = xmsgtype;							/* 10002361 */
		return( -1 );
	}

	header->msg.msgtype = xmsgtype;								/* 10002361 */
	return(0);
}

int ShcSafIOHelper::shc_saf_convertmsg(ShcmsgHeader *header)
{
	OTraceDebug("D-SHC-035014:shc_saf_convertmsg(),incoming msgtype='%d'\n",header->msg.msgtype);

	/*
	 * 	change msgtype to advice msg. 
	 */
	switch(header->msg.msgtype){
	case    SHC_FINREQ:     header->msg.msgtype = SHC_FINREQ_ADVICE;    break;
	case    SHC_REVREQ:
	{
		/* 961108 */
		if( !shcIsIBFTD( header ) )
			header->msg.msgtype = SHC_REVREQ_ADVICE;
		break;
	}	
	case    SHC_STLMTREQ:   header->msg.msgtype = SHC_STLMTREQ_ADVICE;  break;
	case    SHC_AUTHREQ:    header->msg.msgtype = SHC_AUTHREQ_ADVICE;   break;
	case    SHC_POSAUTH_REQ:header->msg.msgtype = SHC_FINREQ_ADVICE;    break;
	}
	return ( 0 );
}

/*  R005896 - Convert response message to advice message --> */
int ShcSafIOHelper::shc_saf_resp_convertmsg(ShcmsgHeader *header)
{
    OTraceDebug("D-SHC-035015:shc_saf_resp_convertmsg(),incoming msgtype='%d'\n",
 					        header->msg.msgtype);

    /* change msgtype (response) to advice msg. */
	switch( header->msg.msgtype )
	{
	case    SHC_FINREQ_RESPONSE:
			header->msg.msgtype = SHC_FINREQ_ADVICE;
			break;
			
	case    SHC_REVREQ_RESPONSE:
			if( !shcIsIBFTD( header ) )
			header->msg.msgtype = SHC_REVREQ_ADVICE;
			break;
			
	case	SHC_STLMTREQ_RESPONSE:
			header->msg.msgtype = SHC_STLMTREQ_ADVICE;
			break;
			
	case	SHC_AUTHREQ_RESPONSE:
			header->msg.msgtype = SHC_AUTHREQ_ADVICE;
			break;
			
	case	SHC_POSAUTH_RESPONSE:
			header->msg.msgtype = SHC_FINREQ_ADVICE;
			break;

					// R007617 >>
	case	SHC_AUTHREQ_ADVICE_RESPONSE:
			header->msg.msgtype = SHC_AUTHREQ_ADVICE;
			break;

	case    SHC_FINREQ_ADVICE_RESPONSE:
			header->msg.msgtype = SHC_FINREQ_ADVICE;
			break;

	case    SHC_REVREQ_ADVICE_RESPONSE:
			header->msg.msgtype = SHC_REVREQ_ADVICE;
			break;
					// R007617 <<
			


	}
	return( 0 );
}
/* <-- R005896 */


/*	wc 31dec97	R000586 ACXSYS-->start	*/	
//int ShcSafIOHelper::shc_saf_calculate_cutoff(ShcBin *shcBin)
//{
//		
//	int		cutoff;
//	int		t_hr = 0, t_min = 0;
//
//	cutoff = shcBin->binPkg->bin.cutoff;
//
//	t_hr = shcBin->binPkg->bin.cutoff / 100;
//	t_min = shcBin->binPkg->bin.cutoff % 100;
//
//	/*
//	 * R001835
//	 */
//	if(shcBin->isInterac())
//	{
//		if( t_min < 30 )
//			t_min += 30;
//		else
//		{
//			t_min = t_min + 30 - 60;
//			t_hr  += 1;
//			t_hr  = ( t_hr > 23 ) ? 0 : t_hr;  
//		}
//	}
//
//	return( t_hr * 100 + t_min );
//}

int ShcSafIOHelper::shc_saf_calculate_capdate(struct istadvice *advicep, ShcmsgHeader *header) 
{

	advicep->safcutoffdate = shcApp->shcmsgHelperObj->getSettlementDate(header);

	/* what about saf cutoff different for Interac */

    if ( advicep->safcutoffdate < header->msg.settlement_date )
         advicep->safcutoffdate =  header->msg.settlement_date ;

	return ( 0 );
}
/*	wc 31dec97	R000586 ACXSYS-->end	*/	


/*
 * R001794 This function will use the filename to search the full name
 *         example: input filename = "445566.778899";
 *                  SAF file name = "445566.778899.20030207.SAF";
 *                  output filename = "445566.778899.20030207";
 */
int ShcSafIOHelper::shc_saf_get_name(char *filename, size_t filenmeSze)
{
	char	buf[500];
	int		i, count=0;
	char	*dot, *p;
	int		ret=-1;		/* R004439 */

#ifdef WIN32


		WIN32_FIND_DATA findFileData;
        HANDLE                  hFindFile = NULL;
        char                    szFindPath[MAX_PATH+1];

        sprintf(szFindPath, "%s\\*.SAF", uenv_constructfile(OLOGDIR_ENV, SAFDIR));
        /* R001273 */
        hFindFile = FindFirstFile(szFindPath, &findFileData);
        if (hFindFile == INVALID_HANDLE_VALUE) { /* R001273 */

                /* The message below is invalid when there is no such files
                   with extension ".SAF" */

			/* R004761 */
        OTraceInfo("I-SHC-035016: No SAF file exists in dir %s\n",
					uenv_constructfile(OLOGDIR_ENV, SAFDIR));
            return ret;		/* R004439 */
        }
        do {
                printf("\n File: %s\n", findFileData.cFileName);

                /* count_file (1, 0, findFileData.cFileName); */
				if ((i = strlen(findFileData.cFileName)) > sizeof(DEFEXT))
				{
					if((dot = strrchr(findFileData.cFileName, '.')) == NULL|| 
						( i = strcmp(dot, DEFEXT)) != 0 ) 
					{
						continue;
					}
					else
					{
						if( strncmp(filename, findFileData.cFileName, strlen(filename) ) == 0 )
						{	
							//strcpy(filename,findFileData.cFileName);
							istsafe_strcpy(filename,filenmeSze, findFileData.cFileName);
							p = (char *) strrchr(filename, '.');
							*p = '\0';
							OTraceInfo("I-SHC-035017: SAF file name %s\n", findFileData.cFileName);
							ret = 0;		/* R004439 */
							break;
						}
					}
				}

        } while (FindNextFile(hFindFile, &findFileData));


        FindClose(hFindFile);
        return ret;		/* R004439 */


#else /* non-WIN32 */

	DIR 	*dirp;
	struct dirent *dp;

	if( filename && strlen(filename)>0 )	/* R009023 */
	{
		if ((dirp = opendir(uenv_constructfile(OLOGDIR_ENV, SAFDIR))) == NULL)
		{
			OTraceInfo("I-SHC-035018:Unable to open dir %s\n",
				  uenv_constructfile(OLOGDIR_ENV, SAFDIR));
			return ret;		/* R004439 */
		}
		while ((dp = readdir(dirp)) != NULL)
		{
			if ((i = strlen(dp->d_name)) > sizeof(DEFEXT))
			{
				if(((dot = strrchr(dp->d_name, '.')) == NULL) || 
				   (( i = strcmp(dot, DEFEXT)) != 0 )) 
				{
					continue;
				}
				else
				{
					if( strncmp(filename, dp->d_name, strlen(filename) ) == 0 )
					{	
						istsafe_strcpy(filename, filenmeSze,dp->d_name);
						p = (char *) strrchr(filename, '.');
						*p = '\0';
						OTraceInfo("I-SHC-035019: SAF file name %s\n", dp->d_name);
						ret = 0;		/* R004439 */
						break;
					}
				}
			}
		}
		closedir(dirp);
	}
	return ret;		/* R004439 */
#endif /* non WIN32 */
}


char *ShcSafIOHelper::shc_saf_routename_pure(char *fName)
{
	char *p1, *p2;
	for( p1=fName, p2=fName; *p2; p2++ )
	{
		if( *p2!=' ' )
			*p1++ = *p2;
	}
	*p1 = '\0';
	return fName;	
}

/*	jt	22feb96		not creating/writing to saf, to istadvice instead	*/
/* 10001959 */
int ShcSafIOHelper::shc_saf_toistadvice(ShcBin *shcBin, ShcmsgHeader *header)
{
	char	name[128];
	
	struct RoutingInfo routingInfo = {0};
	// R027876, R028104 >>>
	int len = sizeof(struct RoutingInfo);
	header->getSegmentData((char *)&routingInfo, &len, NETWORK_DATA_REQ_id,ROUTING_INFO);
	
	if ( len )
	{
		routingInfo.flag &= ~(ROUTE_INFO_FLAG_USE_FOR_REQ | ROUTE_INFO_FLAG_USE_BINROUTE);
		header->setSegmentData((char*)&routingInfo, sizeof(routingInfo),
								NETWORK_DATA_REQ_id,ROUTING_INFO); //R027876
	}
	// <<< R027876, R028104

	
	//sprintf( name, "!%s.", shcBin->binPkg->bin.institutionid );
	snprintf( name, sizeof(name), "!%s.", shcBin->binPkg->bin.institutionid );
	istsafe_strcat( name, sizeof(name), shcBin->binPkg->bin.userbinid );
	

	shc_saf_routename_pure( name );

	header->msg.device_cap &= ~(SH_DEVCAP_FROM_NETWORK); /* 2005371 */

	/* wc 22dec97	R000586 ACXSYS--> add pkg to prototype */
	return( shc_saf_byname(shcBin, header, name, True) );	/* R003632 */
}

//      >>>     R016871
// Checks for existence of saf file
int ShcSafIOHelper::net_saf_exists(struct shcpkg *pkg)
{
	char *p1, *p2;
	char    buf[252];

	//sprintf( buf, "%s.%s", pkg->bin.institutionid, pkg->bin.userbinid);
	snprintf( buf, sizeof(buf), "%s.%s", pkg->bin.institutionid, pkg->bin.userbinid);
	for(p1=buf, p2=buf; *p1; p1++ )
	{
		if( *p1 != ' ' )
			*p2++ = *p1;
	}
	*p2 = '\0';

	if( shc_saf_get_name(buf, sizeof(buf)) < 0 )
		return( 0 );
	OTraceDebug("D-SHC-03520: SAF file '%s.SAF' existed.\n", buf );
	return( 1 );
}
//      <<<     R016871
