/*
 *  Copyright (C) 2004 eFunds Corporation ("eFunds").  All Rights Reserved.     
 *  eFunds Canada Corporation is an authorized user.                            
 *                                                                              
 *  IST is a registered trademark of eFunds Corporation.  Other brand or        
 *  product names are trademarks or registered trademarks of their respective   
 *  holders.                                                                    
 *                                                                              
 *  The information contained herein is the unpublished proprietary property    
 *  of eFunds.  Except as specifically authorized in writing by eFunds, the     
 *  holder of this document shall: i) keep all information contained herein     
 *  confidential, and ii) protect the information, in whole or in part, from    
 *  disclosure and dissemination to all third parties.                          
 *                                                                          
 *  This document and the software described in it are furnished under license  
 *  and may be used or copied only in accordance with the terms of such license.
 *  This document is supplied for information purposes only, is subject to      
 *  change without notice, and should not be construed as a commitment by       
 *  either eFunds Corporation or eFunds Canada Corporation. 
 */
/*
static char SCCSid[] = "@(#) ShcMacHelper.cxx 1.13 07/11/30 08:52:28";
 *
 *  MODIFICATION HISTORY                              REVIEW
 *
 *	SPR#	Who	Date	Description	                  Who	Date   
 * ===========================================================================
 *R00xxxx ztang 05Nov03 Creation
 *R016347 Emj   01May06 Updated shc_getissnetmac to use shcBIN 
 *R021471 Emj   25Sep07 Removed EMV buf for internal generate 420 for interac
 *R022100 sks   30Nov07 Use func issBinValid & acqBinValid to check validity of bin
 *
 */

//File Number 28

#if defined( WIN32 )
#       define SHCDLLEXPORT __declspec(dllexport)
#else
#       define SHCDLLEXPORT
#endif


#include <stdio.h>
#include <oasis.h>
#include <mb_umi.h>
#include <ist_otrace.h>
#include <shc.h>
#include <string.h>
#include <security.h>	/* R005156 */
#include <CShcLog.h>
#include <ShcSdkCommon.h>
#include <ShcMacHelper.h>
//#include <ShcSaf.h>
#include <ShcDKEHelper.h>
#include <ShcmsgHelper.h>
#include <ShcKeyHelper.h>
#include <ShcAppBase.h>

#include <CShcNotify.h>
#include <ShcTimerHelper.h>
#include <ShcHelper.h>
#include <IssProfile.h>
#include <AcqProfile.h>
#include <InstProfile.h>
#include <Shc600Log.h>
#include <ShcSafIOHelper.h>

/*------------------------------------------------------------------------*/

int ShcMacHelper::shcRespNotVerifyMac(register ShcmsgHeader *header)
{
    /*
     *  This function verifies the response code in shcmsg to see if MAC 
     *  verification is required.
     *  
	 *  return: 1 ---> No need to verify MAC
	 *          0 ---> Need to verify MAC
     */

	int		respcode;

	if (shcIsRequest(header))  // R010480
		return 0;              // R010480

	respcode = header->msg.respcode;

    if ( respcode == SHC_RC_MACKeyError || respcode == SHC_RC_NoKeysToUse || 
         respcode == SHC_RC_PINKeyError || respcode == SHC_RC_MACSyncError ||
         respcode == SHC_RC_SwitchNotAvailable ||
	 respcode == SHC_RC_SystemError || respcode == SHC_RC_InvalidIssuer )
		return(1);

	return(0);
}

int	ShcMacHelper::shc_saf_reversal(register ShcmsgHeader *header)
{
    /*
     *  This function writes one reversal advice (SHC_REVREQ_ADVICE) to SAF file and   
	 *  setup appropriate reason for reversal code for financial response
     *  (0110/0210) security failure. Setup MAC information before writting
	 *  the transaciton to the SAF file.
     *
	 *  Reason for Reversal Code:
     *      1.  SHC_RR_MACKeyError:  MAC Value is wrong.
     *      2.  SHC_RR_MACSyncError: MAC Key counter is wrong - sync error.
	 *      3.  SHC_RR_KMESyncError: Message Encryption Key sync error.
     */
     int save_msgtype;

	char saveid[sizeof(header->msg.shclog_id)];
	strcpy(saveid, header->msg.shclog_id);
	mb_getUmi( header->msg.shclog_id, sizeof( header->msg.shclog_id));

    save_msgtype = header->msg.msgtype;
    header->msg.msgtype = SHC_REVREQ_ADVICE;
   	OTraceLog("L-SHC-028015: Created msg ID[%s] /m%04d\n",
		header->msg.shclog_id, header->msg.msgtype);

	switch (header->msg.respcode)
	{
		case SHC_RC_MACKeyError:
			header->msg.revcode = SHC_RR_MACKeyError;
			break;

		case SHC_RC_MACSyncError:
			header->msg.revcode = SHC_RR_MACSyncError;
			break;

		case SHC_RC_KMESyncError:
			header->msg.revcode = SHC_RR_KMESyncError;
			break;

		case SHC_RC_InvalidTransactionTerm:
			header->msg.revcode = SHC_RR_EditError;
			break;
	}

	/*
	 * Setup MAC information before writing to the SAF.
	 */

	 if(header->issShcBin->isInterac())
	 {
		/* R021471 remove emvbuffer for internal generated reversal
			   for interac */
	 	if (header->msg.device_cap & SH_DEVCAP_USER_SEGMENT)
		{
			struct  shcseg          *segp;
		   	struct  shcsegstart     *sp;
		  	segp    = shcmsgLocateSegmentStart(&(header->msg));
			sp      = shc_segfind(segp, "EMV_BUF");
			if (sp != NULL)
		    {
			   strcpy(sp->type, "OLD_EMV_BUF");
			}
		}
	}

    shcApp->shcSafIOHelperObj->shc_saf_writefile(header->issShcBin, header);

	header->shcLogObj->logTxn(header); /* 2005285 */

    header->msg.msgtype = save_msgtype;
    
	strcpy(header->msg.shclog_id, saveid);
	
	return(0);
}



/* R004723 - Check bin before verify mac */
int ShcMacHelper::shcmac_addfields( ShcmsgHeader *header )
{
	if( shcIsNetwork(header) )
	{ 
		if( header->msg.netcode == SHC_NET_ECHO_START 
			|| header->msg.netcode == SHC_NET_ECHO
			|| header->msg.netcode == SHC_NET_SIGNON_START 
			|| header->msg.netcode == SHC_NET_SIGNON
			|| header->msg.netcode == SHC_NET_SIGNOFF_START 
			|| header->msg.netcode == SHC_NET_SIGNOFF )
				return( 0 );
	}

	OTraceDebug("D-SHC-028001: Adding MAC fields.\n");
	OTraceDebug("D-SHC-028002:  Msgtype: %04d\n", header->msg.msgtype);
	OTraceDebug("D-SHC-028003:  flags  : [x%X]\n", header->shcerr);

	if( header->shcerr & (SH_RETURN) )
	{
		if( shcIsAdmIssResp(header) )
		{
			if (!header->issBinValid())			/* R004723 */
			{
				OTraceError("E-SHC-028004: Invalid issuer - No Adding MAC fields.\n");
				return -1;
			}

			if( shcIsVerifyMac(header->issShcBin->binPkg) && header->issShcBin->shckeys_FillMsg(header,
					SH_KEYTYPE_PIN_ISS, SH_KEYTYPE_MAC) < 0 )
			{
       			OTraceError("E-SHC-028005: Failed - No KMAC keys for %s\n",
						header->issShcBin->binPkg->bin.networkid);
				header->msg.respcode = SHC_RC_NoKeysToUse;
				return( -1 );
			}
		}
		else if( shcIsRevIssResp(header) )
		{
			if (!header->issBinValid())			/* R004723 */
			{
				OTraceError("E-SHC-028006: Invalid issuer - No Adding MAC fields.\n");
				return -1;
			}

			if( shcIsVerifyMac(header->issShcBin->binPkg) && header->issShcBin->shckeys_FillMsg(header,
					SH_KEYTYPE_PIN_ACQ, SH_KEYTYPE_MAC) < 0 )
			{
				OTraceError("E-SHC-028007: Failed - No KMAC keys for %s\n",
						header->issShcBin->binPkg->bin.networkid);
				header->msg.respcode = SHC_RC_NoKeysToUse;
				return( -1 );
			}
		}
		else
		{
			if (!header->acqBinValid())			/* R004723 */
			{
				OTraceError("E-SHC-028008: Invalid acquirer - No Adding MAC fields.\n");
				return -1;
			}
/* R004923
			if( shcIsVerifyMac(header->acqShcBin->binPkg) && header->acqShcBin->shckeys_FillMsg(header,
					SH_KEYTYPE_PIN_ISS, SH_KEYTYPE_MAC) < 0 )
*/
			if( shcIsVerifyMac(header->acqShcBin->binPkg) )
			{
				if( ! header->msg.mac_index)
					header->msg.mac_index = '0';

				if(header->acqShcBin->shckeys_FillMsg(header, 
						SH_KEYTYPE_PIN_ISS, SH_KEYTYPE_MAC) < 0)
				{
				OTraceError("E-SHC-028009: Failed - No KMAC keys for %s\n",
						header->acqShcBin->binPkg->bin.networkid);
				header->msg.respcode = SHC_RC_NoKeysToUse;
				return( -1 );
				}
			}
		}
	}
	else if( header->shcerr & (SH_SENDACQ) )
	{
		if( !(header->issBinValid()) || !shcIsVerifyMac(header->issShcBin->binPkg) ) //	R022100	/* R004723 */
			header->msg.mac_index = '0';

		if (!header->acqBinValid())		/* R004723 */
		{
			OTraceError("E-SHC-028010: Invalid acquirer - No Adding MAC fields.\n");
			return -1;
		}

		if( shcIsAdmIssReq(header) )
		{
			if( shcIsVerifyMac(header->acqShcBin->binPkg) && header->acqShcBin->shckeys_FillMsg(header,
					SH_KEYTYPE_PIN_ACQ, SH_KEYTYPE_MAC) < 0 )
			{
				OTraceError("E-SHC-028011: Failed - No KMAC keys for %s\n",
						header->acqShcBin->binPkg->bin.networkid);
				header->msg.respcode = SHC_RC_NoKeysToUse;
	    		shcApp->shcmsgHelperObj->shc_set_return_msgno(&header->msg);
				header->shcerr &= ~SH_SENDACQ;
				header->shcerr |= SH_RETURN;
				return( -1 );
			}
		}
		else if( shcIsRevIssReq(header) )
		{
			if( shcIsVerifyMac(header->acqShcBin->binPkg) && header->acqShcBin->shckeys_FillMsg(header,
					SH_KEYTYPE_PIN_ISS, SH_KEYTYPE_MAC) < 0 )
			{
   				OTraceError("E-SHC-028012: Failed - No KMAC keys for %s\n",
						header->acqShcBin->binPkg->bin.networkid);
				header->msg.respcode = SHC_RC_NoKeysToUse;
	    		shcApp->shcmsgHelperObj->shc_set_return_msgno(&header->msg);
				header->shcerr &= ~SH_SENDACQ;
				header->shcerr |= SH_RETURN;
				return( -1 );
			}
		}
	}
	else if( header->shcerr & (SH_SENDISS) )
	{
		if (!header->issBinValid())		/* R004723 */
		{
			OTraceError("E-SHC-028013: Invalid issuer - No Adding MAC fields.\n");
			return -1;
		}

		if( shcIsVerifyMac(header->issShcBin->binPkg) )
		{
			if( shcIsNetwork(header) )
			{
				if( ! (header->msg.netcode == SHC_NET_KEYS 
					&& header->msg.format_code[1] == SH_KEYTYPE_MAC) )
					header->msg.mac_index = '0';
			}
			else if( !(header->acqBinValid()) || !shcIsVerifyMac(header->acqShcBin->binPkg) ) //	R022100	/* R04723 */
				header->msg.mac_index = '0';

			if( header->issShcBin->shckeys_FillMsg(header, SH_KEYTYPE_PIN_ACQ,
					SH_KEYTYPE_MAC) < 0 )
			{
   				OTraceError("E-SHC-028014: Failed - No MAC keys for %s\n", 
						header->issShcBin->binPkg->bin.networkid);
   				OTraceError("E-SHC-028015:  action : Return message to acquirer\n");
				header->msg.respcode = SHC_RC_NoKeysToUse;
	    		shcApp->shcmsgHelperObj->shc_set_return_msgno(&header->msg);
				header->shcerr &= ~SH_SENDISS;
				header->shcerr |= SH_RETURN;
				return( -1 );
			}
		}
	}

	return( 0 );
}
/* R001072 < */


/*	12jan96		jt
 *	Added for MAC verification by formatter
 */
int ShcMacHelper::shc_getissnetmac(ShcmsgHeader *header, ShcBin *shcBin, char *mackey)
{
	struct shckey_buf keybuf = {0}; /* R001835 */

	/*
	 * R001835
	 */
	if(!shcBin->isInterac())
	{
		/*
         * Non-Interac Version
         */
		if(shcBin->key == NULL)
			return(-1);
		
		if(shcBin->key->k.issmacidx == 1)
			memcpy(header->msg.mac.key, shcBin->key->k.issmac1, shcBin->key->k.issmac_len);
		else
			memcpy(header->msg.mac.key, shcBin->key->k.issmac2, shcBin->key->k.issmac_len);
        
		header->msg.keylen = shcBin->key->k.issmac_len;
	}
	else
	{
		/*
         * Interac Version
         */
		if( shcBin->shckeys_GetKey(&keybuf, SH_KEYTYPE_PIN_ISS, SH_KEYTYPE_MAC,
       		 SH_KEYIDX_CURRENT) != 0 )
        	return( -1 );

   		 memcpy(mackey, keybuf.akeyp, IST_SECURITY_KEY_SZ);
	}	
	return(0);
}

/*------------------------------------------------------------------------*
 * End of file shc_mac.c
 *------------------------------------------------------------------------*/
