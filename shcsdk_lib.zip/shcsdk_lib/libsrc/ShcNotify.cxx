/*
 *  Copyright (C) 2004 eFunds Corporation ("eFunds").  All Rights Reserved.     
 *  eFunds Canada Corporation is an authorized user.                            
 *                                                                              
 *  IST is a registered trademark of eFunds Corporation.  Other brand or        
 *  product names are trademarks or registered trademarks of their respective   
 *  holders.                                                                    
 *                                                                              
 *  The information contained herein is the unpublished proprietary property    
 *  of eFunds.  Except as specifically authorized in writing by eFunds, the     
 *  holder of this document shall: i) keep all information contained herein     
 *  confidential, and ii) protect the information, in whole or in part, from    
 *  disclosure and dissemination to all third parties.                          
 *                                                                          
 *  This document and the software described in it are furnished under license  
 *  and may be used or copied only in accordance with the terms of such license.
 *  This document is supplied for information purposes only, is subject to      
 *  change without notice, and should not be construed as a commitment by       
 *  either eFunds Corporation or eFunds Canada Corporation. 
 *
 *
 *
 *                        MODIFICATION HISTORY                  REVIEW
 *
 *	SPR#	Who	Date	Description			Who	Date   
 * ===========================================================================
 * 1634		zm	28Mar96	Do not send reversal to istadvice if original is 
 *							required and not found
 * 10002011 la  14may96 Make advice route after message is adjusted.
 * 10001986 la  23may96 Resulting from 10002011 fix. Must fill advice structure
 *                       message first before adjusting it.
 *	jsn		13jan94		Created to echo shcmsg's to the advice server
 *						for notification to other nodes.
 *	ad		05mar94		Changed construction of routining entry to use
 *						'owner' field instead of 'stlmtagent' field.
 *						NOTE: This should parameterised.
 *	ad		07mar94		Do not attempt routing if either acqbin or 
 *							issbin is NULL
 *	wc		18dec97		Change ADVICE_LENGTH
 *  R001835 qd 07apr99  Interac Merge
 *R008779 jyang 02Jan03 Multi-institution support
 *R027271 dipa  18Jun10 Txn Statistics 
 *R030381 dipa  10Mar12 Txn Statistics  - more changes
 */

//File Number 33

#if defined( WIN32 )
#       define SHCDLLEXPORT __declspec(dllexport)
#else
#       define SHCDLLEXPORT
#endif

static const char* _ShcNotify_cxx_what = "@(#) ShcNotify.cxx 1.15 20/03/25 13:13:15";


#include <stdio.h>
#include <string.h>
#include <oasis.h>
#include <ist_otrace.h>
#include <mb.h>
#include <ShcMsgCache.h>
#include <shcmsgdef.h>
#include <shc.h>
#include <ShcmsgHelper.h>
#include <shcnotify.h>
#include <CShcNotify.h>
#include <ShcAppBase.h>
#include<ic/ic_instid.h>
#include<ic/ic_bin.h>
#include <ShcBin.h>

static		int			notify_mbid		=	-1;
static		char		CurrentNode[MB_MAX_NAME+1] = "";


/* -=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
 *
 *		Takes the shcmsg, constructs an advice message and sends the
 *	advice message to the advice server for processing.
 *
 */
int	ShcNotify::shc_notify_echo( ShcmsgHeader *header )
{
	struct		istadvice		amsg = {0};
	int							truelength;
	

	if( !shcIsNotifyOn(header) ) /* R011815 */

		return(0);

	OTraceDebug("D-SHC-033001:  shc_notify_echo()\n");
	OTraceDebug("D-SHC-033002:   message: m%04d/t%06ld/r%03d\n", header->msg.msgtype,
			header->msg.trace, header->msg.respcode);

	/*
	 *	Verify that both the acqbin and issbin pointers are valid
	 */
	if(!header->acqBinValid() || !header->issBinValid())
		return(0);

	if ((header->msg.msgtype == SHC_FINREQ_ADVICE_RESPONSE) &&
		(strcmp(header->msg.authnum, "AAAAAA") == 0))
	{
		OTraceDebug("D-SHC-033003:  Found Adjustment - trace: %d\n", header->msg.trace);
		/* ---	--- */
		header->msg.msgtype = SHC_FINREQ_RESPONSE;
	
	}

	/* pk - added on 02.17.94 */
	if ( (header->msg.msgtype == SHC_REVREQ) &&
		 (
		   (header->msg.respcode == SHC_RC_DeviceTimeOut)
								||
		   (header->msg.respcode == SHC_RC_IssuerTimeout)
		 )
	   )
		header->msg.msgtype = SHC_REVREQ_RESPONSE;

	if( !shcmsgIsResponse(&header->msg))
	{
		OTraceDebug("D-SHC-033004:   action : not response msg, advice NOT sent\n");
		return(0);
	}

	if( shcIsNetwork(header))
		if( !shc_notify_netcode_allowed(header) )
		{
			OTraceDebug("D-SHC-033005:   action : network msg, advice NOT sent\n");
			return(0);
		}

	if( header->msg.device_cap & SH_DEVCAP_UPDATE_LOGS)
	{
		OTraceDebug("D-SHC-033006:   action : log flag set, advice NOT sent\n");
		return(0);
	}

	/* zm 28Mar96 spr 1634 */
	/* Do not send to istadvice if the original was not found */
	if (shcIsReversal(header) && header->msg.respcode == SHC_RC_NoOriginal &&
		(header->msg.device_cap & SH_DEVCAP_REV_REQUIREORIG))
	{
		OTraceDebug("D-SHC-033007:   action : original not found, advice NOT sent\n");
		return(0);
	}

	truelength = header->truelength();

	if( shc_notify_build(header, &amsg, truelength) < 0 || // R010754
		shc_notify_send( &amsg, truelength) < 0 )        // R010754
			return(-1);

	return(0);
}


/* -=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
 *
 *		Builds an advice message from the shcmsg.
 *
 */
int ShcNotify::shc_notify_build( ShcmsgHeader *header, struct istadvice *amsg, int len)
{

	memset( (char *)amsg, 0, sizeof( struct istadvice));

	amsg->datalen = len;
	amsg->sender = shcmid;					
	amsg->replay = False;					/*don't want respnse to return*/

	memcpy((char *)amsg->buf, (char *)&header->msg, std::min<int>(len, sizeof amsg->buf));

	if( shc_notify_adjust_msg(amsg) < 0 )						/* 10001986 */
		return( -1 );											/* 10001986 */

	shc_notify_construct_tag( header, amsg );

	return(0);
}



/* -=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
 *		Constructs the tag which the advice server will use to
 *	determine routing of the message.
 *
 */
int ShcNotify::shc_notify_construct_tag( ShcmsgHeader *header, struct istadvice *amsg)
{

	int			i;
	struct		shcmsg		*msg;

	msg = (struct shcmsg *)amsg->buf;

	amsg->route[0] = '\0';

	if( !strlen( CurrentNode ) )
		mb_getcurrentnode( CurrentNode, &i);

	/*
	 *	Format:
	 *	'nodenamesource-acquirerbin-messagetype'
	 *
	 *	ie. Toronto-0000645032-0210
	 *
	 */

				/* R010604 >> */
	bin_t instIss, binIss, instAcq, binAcq;
	
	ICInstId_pure( instIss, header->issShcBin->binPkg->bin.institutionid );
	ICBin_pure( binIss, header->issShcBin->binPkg->bin.userbinid );
	ICInstId_pure( instAcq, header->acqShcBin->binPkg->bin.institutionid );
	ICBin_pure( binAcq, header->acqShcBin->binPkg->bin.userbinid );
	
	snprintf(amsg->route, sizeof(amsg->route),"%s.%s-%s.%s-%04d-%06d-%03d", instIss, binIss, instAcq, binAcq,
		header->msg.msgtype, header->msg.pcode, header->msg.respcode);
				/* R010604 << */

	OTraceDebug("D-SHC-033008: key: %s\n", amsg->route);

	return(0);
}



/* -=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
 *		Adjusts the message before sending
 *
 *		1.	adjust messge number
 *		2.	set the UPDATE LOG flag on
 *		3.	Turn off device flags
 *
 */
int ShcNotify::shc_notify_adjust_msg( struct istadvice *amsg )
{
	int		i;
	struct	shcmsg *shcmsg;
    bin_t tmpInstitutionId;
    bin_t tmpUserBinId;
	ShcInstParamsList *shcParamsList;
	struct a_msgmap *tmpMsgMap;

	shcmsg = (struct shcmsg *)amsg->buf;

    if (shc_internalBin2ExternalBin(tmpInstitutionId, tmpUserBinId, shcmsg->issuer) < 0)
    {
        OTraceError("E-SHC-033009: Invalid internal bin [%s]\n", shcmsg->issuer);
        return( -1 );
    }

    shcParamsList = (ShcInstParamsList *)shcApp->shcParams.getInst(tmpInstitutionId);
	tmpMsgMap = shcParamsList->getA_msgmap();

	if(shcParamsList->getNumAdviceRoute() <= 0 || tmpMsgMap == NULL) // R010604
		return(-1);
	
	for(i = 0; i < shcParamsList->getNumAdviceRoute(); ++i) 		// R010604
		if(tmpMsgMap[i].srcmsg == shcmsg->msgtype)
		{
			shcmsg->msgtype = tmpMsgMap[i].dstmsg;
			shcmsg->device_cap |= SH_DEVCAP_UPDATE_LOGS;
			shcmsg->device_cap &= ~(SH_DEVCAP_FROMDEVICE | SH_DEVCAP_WILLACK);

			OTraceDebug("D-SHC-033010:   new msg : '%d'\n", shcmsg->msgtype);

			return(0);
		}
	
	return(-1);
}


	

/* -=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
 *		Sends the constructed advice message to the advice server
 *	for processing.
 *
 */
int	ShcNotify::shc_notify_send( struct istadvice *amsg , int len)
{
	if( notify_mbid < 0)
	{
		if( (notify_mbid = mb_locatemailbox_local( AUTH_ADVICE_NAME )) < 0)
		{
			OTraceWarning("W-SHC-033011:   action : unable to locate advice server, advice NOT sent\n");
			return(-1);
		}
	}
	
	/* wc	18dec97	Change from ADVICE_LENGTH() to ADVICE_LENGTH */
	if( cache_mb_write( notify_mbid, shcmid, (char *)amsg, ADVICE_LENGTH) < 0)
	{
		OTraceLog("L-SHC-033015: Failed to send msg ID[%s] /m%04d/t%d/p%06d to %s\n",
			((struct shcmsg *)amsg->buf)->shclog_id, ((struct shcmsg *)amsg->buf)->msgtype, 
			((struct shcmsg *)amsg->buf)->trace, ((struct shcmsg *)amsg->buf)->pcode, 
			mbMailBoxName(notify_mbid));

		return(-1);
	}
	else
		OTraceLog("L-SHC-033016: Sent msg ID[%s] /m%04d/t%d/p%06d to %s\n",
			((struct shcmsg *)amsg->buf)->shclog_id, ((struct shcmsg *)amsg->buf)->msgtype, 
			((struct shcmsg *)amsg->buf)->trace, ((struct shcmsg *)amsg->buf)->pcode, 
			mbMailBoxName(notify_mbid));
	
	OTraceDebug("D-SHC-033013:   action : sending advice message\n");
	OTraceDebug("D-SHC-033014:   mailbox: %s[%d]\n",mbMailBoxName(notify_mbid), notify_mbid);

	return( 0 );
}


int ShcNotify::shc_notify_netcode_allowed(ShcmsgHeader *header)
{
	if(header->msg.netcode == SHC_NET_TERM_KEY ||
	   header->msg.netcode == SHC_NET_TERM_KEY_START)
		return( True );

	return( False );
}

int ShcNotify::shcIsNotifyOn(ShcmsgHeader *header)
{
	int ret = 0;

	if (shcApp->acquirerShcParamsList->getNotify_on() || shcApp->issuerShcParamsList->getNotify_on())
	{
		ret = 1;
	}
	return (ret);
}
