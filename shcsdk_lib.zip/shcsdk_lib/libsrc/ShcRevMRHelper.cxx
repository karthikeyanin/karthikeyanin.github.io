static char _ShcRevMRHelper_cxx_what[] = "@(#) ShcRevMRHelper.cxx 1.3.1.3 20/04/14 21:07:37"; 


/*
 *  Copyright (C) 2004 eFunds Corporation ("eFunds").  All Rights Reserved.     
 *  eFunds Canada Corporation is an authorized user.                            
 *                                                                              
 *  IST is a registered trademark of eFunds Corporation.  Other brand or        
 *  product names are trademarks or registered trademarks of their respective   
 *  holders.                                                                    
 *                                                                              
 *  The information contained herein is the unpublished proprietary property    
 *  of eFunds.  Except as specifically authorized in writing by eFunds, the     
 *  holder of this document shall: i) keep all information contained herein     
 *  confidential, and ii) protect the information, in whole or in part, from    
 *  disclosure and dissemination to all third parties.                          
 *                                                                          
 *  This document and the software described in it are furnished under license  
 *  and may be used or copied only in accordance with the terms of such license.
 *  This document is supplied for information purposes only, is subject to      
 *  change without notice, and should not be construed as a commitment by       
 *  either eFunds Corporation or eFunds Canada Corporation. 
 *
 *
 *                        MODIFICATION HISTORY                  REVIEW
 *
 *	JIRA#	Who	Date	Description			Who	Date   
 * ===========================================================================
*/

/* File Number 30 */

#include <stdio.h>
#include <string.h>
#include <ShcAppBase.h>
#include <ShcRevMRHelper.h>
#include <ist_otrace.h>
#include <HaPtmCctHelper.h>
#include <dbm.h>
#include <algorithm>
#include <ist_seg_name.h> 
#include <ist_seg_elf_id_map.h> 
#include <ist_seg_id.h> 
#include <ist_seg_msg_replication_data.h>
#include <istsafe.h>

struct ShcRevMRmsgOrig {
	char    	shclog_id[21];
	int 		revcode;
	int 		respcode;
	amount_t	aval_balance;
	amount_t 	new_setl_amount;
	amount_t 	new_amount;
	amount_t 	new_fee;
	amount_t 	ch_new_amount;   
	amount_t 	new_setl_fee; 
};

struct ShcRevMRmsgNoOrig {
    char		pan[SHC_PAN_LEN + 1];
	int 		msgtype;
	int         origmsg;
	int 		trace;
	int			local_time;
  	date_t		local_date;
 	char		termid[SHC_TERMID_LEN+1];
    bin_t		acquirer;
    char		authnum[SHC_AUTHNUM_LEN+1];
 	char		entityId[MAX_ENTITY_ID_LEN+1];
    int			device_cap;
	char		refnum[SHC_REFNUM_LEN+1];
	int 	    pcode;
    short		merchant_type;
    int			origtrace;
	int 		revcode;
	int 		respcode;
	amount_t	aval_balance;
	amount_t 	new_setl_amount;
	amount_t 	new_amount;
	amount_t 	new_fee;
	amount_t 	ch_new_amount;   
	amount_t 	new_setl_fee; 

};



ShcRevMRHelper::ShcRevMRHelper()
{
	if (!shcApp)
		shcApp = (ShcAppBase *)shcHelperRegister.getTargetObj(SHC_ShcAppBase);

}

ShcRevMRHelper::~ShcRevMRHelper()
{

}


ShcRevMRHelper *ShcRevMRHelper::getInstance()
{
	static ShcRevMRHelper *_instance=NULL;
	if ( !_instance )
	{
		_instance = (ShcRevMRHelper *)shcHelperRegister.getTargetObj("ShcRevMRHelper");
		if (!_instance)
	 		_instance = new ShcRevMRHelper();
	}
	return _instance;
}




int ShcRevMRHelper::revOrigMRMessage(OCString& msg)
{
	//This function should locate the original message 
	//then update it has not already been reversed 
	OTraceDebug("D-SHCRMR-0001:ShcRevMRHelper::revOrigMRMessag\n");

    ShcRevMRmsgOrig 	shcRevMRmsgOrig;

	// Should check the size of the segment 
	memset (&shcRevMRmsgOrig, 0, sizeof (struct ShcRevMRmsgOrig));
	memcpy (&shcRevMRmsgOrig, msg.data(), sizeof (struct ShcRevMRmsgOrig));

	//First locate the original message using logid
	ShcmsgHeader header;


	header.msg.site_id = mbGetSiteId();;  // Should always be the site which is running on
	strcpy(header.msg.shclog_id, shcRevMRmsgOrig.shclog_id);

	if (shcApp->shcmsgLogObj->locateTxn(&header, IST_SHCLOG_FLAG_USE_CHIP_INDEX) < 0)
	{
		OTraceDebug("D-SHCRMR:0001: original transaction not found\n");
		return (1);

	}

	//  Need to  check if already  reversed



	//  Set to reverse
	header.reqMsg->shcerror = SHC_IE_Reversed;
	header.reqMsg->revcode  = shcRevMRmsgOrig.revcode;
	header.reqMsg->respcode = shcRevMRmsgOrig.respcode;

	dbm_deccopy(&header.reqMsg->aval_balance, &shcRevMRmsgOrig.aval_balance);
	dbm_deccopy(&header.reqMsg->new_setl_amount, &shcRevMRmsgOrig.new_setl_amount);
	dbm_deccopy(&header.reqMsg->new_amount, &shcRevMRmsgOrig.new_amount);
	dbm_deccopy(&header.reqMsg->new_fee, &shcRevMRmsgOrig.new_fee);
	dbm_deccopy(&header.reqMsg->ch_new_amount, &shcRevMRmsgOrig.ch_new_amount);   
	dbm_deccopy(&header.reqMsg->new_setl_fee, &shcRevMRmsgOrig.new_setl_fee); 


	memcpy(&header.msg, header.reqMsg, sizeof(struct ShcmsgWithSegment));
	
	if (shcApp->shcmsgLogObj->doUpdateReversal(&header) < 0)
	{
		OTraceError("E-SHCRMR-0002:Update origmsg of (%s) failed\n", header.msg.shclog_id);
	}
		
	OTraceDebug("D-SHCRMR-0003:Update origmsg of (%s) successfull\n", header.msg.shclog_id);


	return (1);
}



int ShcRevMRHelper::revNoOrigMRMessage(OCString& msg)
{

	//This funcation should attemp to loacte the original
	//The update if it has not already been reversed
	OTraceDebug("D-SHCRMR-0004:ShcRevMRHelper::revNoOrigMRMessag\n");
    ShcRevMRmsgNoOrig 	shcRevMRmsgNoOrig;

	// Should check the size of the segment 
	memset (&shcRevMRmsgNoOrig, 0, sizeof (struct ShcRevMRmsgNoOrig));
	memcpy (&shcRevMRmsgNoOrig, msg.data(), sizeof (struct ShcRevMRmsgNoOrig));


	ShcmsgHeader tmpheader;
	ShcmsgHeader *header;
	int useSpecialPOSLookup = 0;
	struct ShcmsgWithSegment tmpMsg ;
	struct shcmsg *omsg = &(tmpMsg.msg);

	header = &tmpheader;

    strcpy(header->msg.pan, shcRevMRmsgNoOrig.pan);
	header->msg.msgtype = shcRevMRmsgNoOrig.msgtype;
	header->msg.origmsg = shcRevMRmsgNoOrig.origmsg; 
	header->msg.trace = shcRevMRmsgNoOrig.trace;
	header->msg.local_time = shcRevMRmsgNoOrig.local_time;
  	header->msg.local_date = shcRevMRmsgNoOrig.local_date;
 	strcpy(header->msg.termid, shcRevMRmsgNoOrig.termid);
    strcpy(header->msg.acquirer, shcRevMRmsgNoOrig.acquirer);
    strcpy(header->msg.authnum, shcRevMRmsgNoOrig.authnum);
 	strcpy(header->msg.entityId, shcRevMRmsgNoOrig.entityId);
    header->msg.device_cap = shcRevMRmsgNoOrig.device_cap;
	strcpy(header->msg.refnum, shcRevMRmsgNoOrig.refnum);
	header->msg.pcode = shcRevMRmsgNoOrig.pcode = header->msg.pcode;
    header->msg.merchant_type = shcRevMRmsgNoOrig.merchant_type;
    header->msg.origtrace =  shcRevMRmsgNoOrig.origtrace;



	if ((!header->msg.refnum[0]) &&
		(!shcIsATM(header)) &&
		(header->msg.local_date <= 0))
	{
	 	//Special lookup for POS
		useSpecialPOSLookup = 1;
	}

	if(header->msg.origtrace != 0)
	{
	 	header->msg.trace = header->msg.origtrace;
	}

	if(header->msg.origmsg == 0)
	{
		header->msg.msgtype = SHC_FINREQ;
		if (useSpecialPOSLookup)
		{
			if(shcApp->shcmsgLogObj->locateTxnSeq(header, omsg,NULL) < 0)
			{
				header->msg.msgtype = SHC_AUTHREQ;
				if(shcApp->shcmsgLogObj->locateTxnSeq(header, omsg, NULL) < 0)
				{
					OTraceDebug("D-SHCRMR-0005:Original not found\n");
					return 1;
				}
			}
		}
		else if(shcApp->shcmsgLogObj->locateTxn(header, omsg,NULL) < 0)
		{
			header->msg.msgtype = SHC_AUTHREQ;
			if(shcApp->shcmsgLogObj->locateTxn(header, omsg, NULL) < 0)
			{
				OTraceDebug("D-SHCRMR-0006:Original not found\n");
				return 1;
			}
		}
	}
	else
	{
		header->msg.msgtype = header->msg.origmsg;
		if (useSpecialPOSLookup)
		{
			if(shcApp->shcmsgLogObj->locateTxnSeq(header, omsg, NULL) < 0)
			{	
				OTraceDebug("D-SHCRMR-0007:Original not found\n");
				return 1; 
			}
		}
		else if(shcApp->shcmsgLogObj->locateTxn(header, omsg, NULL) < 0)
		{
			OTraceDebug("D-SHCRMR-0008:Original not found\n");
			return 1;
		}
	}

	header->allocateAndCopyOrigMsg(omsg);

	// NEED TO CHECK IF ALREADY REVERSED


	//  Set to reverse  by other site
	header->origMsg->shcerror = SHC_IE_Reversed_Other_Site;
	header->origMsg->revcode  = shcRevMRmsgNoOrig.revcode;
	header->origMsg->respcode = shcRevMRmsgNoOrig.respcode;

	dbm_deccopy(&header->origMsg->aval_balance, &shcRevMRmsgNoOrig.aval_balance);
	dbm_deccopy(&header->origMsg->new_setl_amount, &shcRevMRmsgNoOrig.new_setl_amount);
	dbm_deccopy(&header->origMsg->new_amount, &shcRevMRmsgNoOrig.new_amount);
	dbm_deccopy(&header->origMsg->new_fee, &shcRevMRmsgNoOrig.new_fee);
	dbm_deccopy(&header->origMsg->ch_new_amount, &shcRevMRmsgNoOrig.ch_new_amount);   
	dbm_deccopy(&header->origMsg->new_setl_fee, &shcRevMRmsgNoOrig.new_setl_fee); 


	memcpy(&header->msg, header->origMsg, sizeof(struct ShcmsgWithSegment));


	if (shcApp->shcmsgLogObj->doUpdateReversal(header) < 0)
	{
		OTraceError("E-SHCRMR-0009:Update origmsg of (%s) failed\n", header->msg.shclog_id);
	}
		
	OTraceDebug("D-SHCRMR-0010:Update origmsg of (%s) successfull\n", header->msg.shclog_id);


	return (1);
}


int ShcRevMRHelper::setSegmentRevOrig(ShcmsgHeader  *header)
{

	static int lSegMRId = ElfIdMap::elf_to_id(IST_SEG_MSG_REPLICATION_DATA);

	if ( !mbIsDualSite() )
		return 1;

	OTraceDebug("D-SHCRMR-0011:ShcRevMRHelper::setSegmentRevOrig\n");

	if (header->origMsg->site_id ==  mbGetSiteId())
	{
		
		OTraceDebug("D-SHCRMR-0012:Original process on this site no need to MR\n");
		return 1;
	}
	


	ShcRevMRmsgOrig shcRevMRmsgOrig;

	memset (&shcRevMRmsgOrig, 0, sizeof (struct ShcRevMRmsgOrig));


	istsafe_strcpy(shcRevMRmsgOrig.shclog_id, sizeof (shcRevMRmsgOrig.shclog_id), header->origMsg->shclog_id);
	shcRevMRmsgOrig.respcode = header->origMsg->respcode;
	shcRevMRmsgOrig.revcode = header->origMsg->revcode;

	dbm_deccopy(&shcRevMRmsgOrig.aval_balance, &header->origMsg->aval_balance);
	dbm_deccopy(&shcRevMRmsgOrig.new_setl_amount, &header->origMsg->new_setl_amount);
	dbm_deccopy(&shcRevMRmsgOrig.new_amount, &header->origMsg->new_amount);
	dbm_deccopy(&shcRevMRmsgOrig.new_fee, &header->origMsg->new_fee);
	dbm_deccopy(&shcRevMRmsgOrig.ch_new_amount, &header->origMsg->ch_new_amount);   
	dbm_deccopy(&shcRevMRmsgOrig.new_setl_fee, &header->origMsg->new_setl_fee); 


	// Need to add the segment here  

	IstSegMsgReplicationData* msgReplSegObj = (IstSegMsgReplicationData*) header->getSegmentObj( lSegMRId, IST_SEG_CREATE );

	if ( msgReplSegObj )
	{
		msgReplSegObj->appendData(IST_MR_SERVICE_NAME_SHCREVORIG, &shcRevMRmsgOrig, sizeof (struct ShcRevMRmsgOrig));
	}



	return (1);
}



int ShcRevMRHelper::setSegmentRevNoOrig(ShcmsgHeader  *header)
{
	if ( !mbIsDualSite() )
			return 0;

	static int lSegMRId = ElfIdMap::elf_to_id(IST_SEG_MSG_REPLICATION_DATA);
	ShcRevMRmsgNoOrig shcRevMRmsgNoOrig;

	//  This function builds the segment for reversal Original not found
	OTraceDebug("D-SHCRMR-0013:ShcRevMRHelper::setSegmentRevNoOrig\n");


	memset (&shcRevMRmsgNoOrig, 0 , sizeof (struct ShcRevMRmsgNoOrig));

    istsafe_strcpy(shcRevMRmsgNoOrig.pan,sizeof (shcRevMRmsgNoOrig.pan),header->msg.pan);
	shcRevMRmsgNoOrig.msgtype = header->msg.msgtype;
	shcRevMRmsgNoOrig.origmsg = header->msg.origmsg; 
	shcRevMRmsgNoOrig.trace = header->msg.trace;
	shcRevMRmsgNoOrig.local_time = header->msg.local_time;
  	shcRevMRmsgNoOrig.local_date = header->msg.local_date;
 	istsafe_strcpy(shcRevMRmsgNoOrig.termid,sizeof (shcRevMRmsgNoOrig.termid),header->msg.termid);
    istsafe_strcpy(shcRevMRmsgNoOrig.acquirer,sizeof (shcRevMRmsgNoOrig.acquirer),header->msg.acquirer);
    istsafe_strcpy(shcRevMRmsgNoOrig.authnum,sizeof (shcRevMRmsgNoOrig.authnum), header->msg.authnum);
 	istsafe_strcpy(shcRevMRmsgNoOrig.entityId, sizeof (shcRevMRmsgNoOrig.entityId),header->msg.entityId);
    shcRevMRmsgNoOrig.device_cap = header->msg.device_cap;
	istsafe_strcpy(shcRevMRmsgNoOrig.refnum, sizeof (shcRevMRmsgNoOrig.refnum),header->msg.refnum);
	shcRevMRmsgNoOrig.pcode = header->msg.pcode;
    shcRevMRmsgNoOrig.merchant_type = header->msg.merchant_type;
    shcRevMRmsgNoOrig.origtrace = header->msg.origtrace;

	shcRevMRmsgNoOrig.respcode = header->msg.respcode;
	shcRevMRmsgNoOrig.revcode = header->msg.revcode;

	dbm_deccopy(&shcRevMRmsgNoOrig.aval_balance, &header->msg.aval_balance);
	dbm_deccopy(&shcRevMRmsgNoOrig.new_setl_amount, &header->msg.new_setl_amount);
	dbm_deccopy(&shcRevMRmsgNoOrig.new_amount, &header->msg.new_amount);
	dbm_deccopy(&shcRevMRmsgNoOrig.new_fee, &header->msg.new_fee);
	dbm_deccopy(&shcRevMRmsgNoOrig.ch_new_amount, &header->msg.ch_new_amount);   
	dbm_deccopy(&shcRevMRmsgNoOrig.new_setl_fee, &header->msg.new_setl_fee); 


	IstSegMsgReplicationData* msgReplSegObj = (IstSegMsgReplicationData*) header->getSegmentObj( lSegMRId, IST_SEG_CREATE );

	if ( msgReplSegObj )
	{
		msgReplSegObj->appendData(IST_MR_SERVICE_NAME_SHCREVNOORIG, &shcRevMRmsgNoOrig, sizeof (struct ShcRevMRmsgNoOrig));

	}

	return (1);
}


