/*
 *  Copyright (C) 2004 eFunds Corporation ("eFunds").  All Rights Reserved.
 *  eFunds Canada Corporation is an authorized user.
 *
 *  IST is a registered trademark of eFunds Corporation.  Other brand or
 *  product names are trademarks or registered trademarks of their respective
 *  holders.
 *
 *  The information contained herein is the unpublished proprietary property
 *  of eFunds.  Except as specifically authorized in writing by eFunds, the
 *  holder of this document shall: i) keep all information contained herein
 *  confidential, and ii) protect the information, in whole or in part, from
 *  disclosure and dissemination to all third parties.
 *
 *  This document and the software described in it are furnished under license
 *  and may be used or copied only in accordance with the terms of such license.
 *  This document is supplied for information purposes only, is subject to
 *  change without notice, and should not be construed as a commitment by
 *  either eFunds Corporation or eFunds Canada Corporation.
 */
/*
#pragma ident "@(#) shc_recon.cxx 1.8 12/05/29 06:42:51"
 *
 *                        MODIFICATION HISTORY                  REVIEW
 *
 *	SPR#	Who	Date	Description			Who	Date
 * ===========================================================================
 *	la		31May94		Created
 *	la		27Jul94		Switch code check not needed.
 *	ad		03Jun95		shc_recon_send() - return without reading response
 *						from recon server.
 * 10001856 la  12may96 Reconcille 410 and 420 messages.
 * 10002113 la  01jun96 Corrected fix for SPR# 10001856.
 *                      Do not reconcile replayed transactions.
 * 10002364 la  02jul96 Route message to shc500std process for reconcillation.
 * 10002376 qd  18oct96 Ignore mis-matched 04xx settlement message
 * 0001303  yh  10Mar99 Do not locate mailbox for RECON SERVER for each txn.
 * R002521  fg  13Aug99 Only locate mailbox SERVER_RECON_PROCESS for once no
 *                      matter succeed or fail in recon_api_getserver().
 *R008404 jyang 21Oct02 bypass the internal inquiry result in settlement server
 *R028271 dipa  18Jun10 Txn Statistics
 *R030381 dipa  10Mar12 Txn Statistics - more changes
 */

//File Number 14

#if defined( WIN32 )
#       define SHCDLLEXPORT __declspec(dllexport)
#else
#       define SHCDLLEXPORT
#endif


#include <stdio.h>
#include <string.h>
#include <ctype.h>
#include <oasis.h>
#include <ist_otrace.h>
#include <shc.h>
/* #include <shcfmt.h> */
#include <ShcMsgCache.h>
#include <shc500std.h>
#include <ShcmsgHelper.h>
#include <ShcmsgHeader.h>
#include <ShcBin.h>

#define SERVER_RECON_PROCESS		"istReconProcessServer"


int ShcmsgHelper::shc_recon_send( ShcmsgHeader *header, int private_mid )
{
	int		server_mid;

	OTraceDebug("D-SHC-014001:  Reconcillation for m%04d/t%06ld/r%03d\n",
			header->msg.msgtype, header->msg.trace, header->msg.respcode);

	/* 10002113 */
	if( header->msg.device_cap & SH_DEVCAP_FROM_REPLAY )
	{
		OTraceDebug("D-SHC-014002:    action : ignored - replay transaction\n");

		return( 0 );
	}
			/* R008404 >> */
	if( !header->issBinValid() || !header->acqBinValid())
	{
		OTraceDebug("D-SHC-014003:    action : ignored - internal inquiry result\n");
		return( 0 );
	}		/* R008404 << */

	switch( header->msg.msgtype )
	{
		case SHC_REVREQ_RESPONSE:
		case SHC_REVREQ_ADVICE_RESPONSE:
		  /*
		   * SPR10002376
		   */
		   if(header->msg.shcerror == SHC_IE_NoMatch)
		   {
		    	OTraceInfo("I-SHC-014004: Mis-matched %d,ignore settlement\n",
		     			header->msg.msgtype);
				return(0);
		   }

		case SHC_AUTHREQ_RESPONSE:
		case SHC_AUTHREQ_ADVICE_RESPONSE:
		case SHC_FINREQ_RESPONSE:
		case SHC_FINREQ_ADVICE_RESPONSE: /* 10002113 */
			if( header->msg.respcode != SHC_RC_Approved
				&& header->msg.respcode != SHC_RC_PartialDispense )
			{
				OTraceDebug("D-SHC-014005:    action : ignored - not approved.\n");
				return( 0 );
			}
			break;

		default:
			OTraceDebug("D-SHC-014006:    action : ignored - message type not used.\n");
			return( 0 );
	}

	if ( (server_mid = recon_api_getserver()) < 0 )
		return( shc_send_recon_500(header) ); 						/* 10002364 */

	if ( private_mid <= 0 )
		if ( (private_mid = recon_api_getprivate()) < 0 )
			return( -1 );


	/* 03Jun95 */
	if( cache_mb_write(server_mid, 0 , (char *)&header->msg, sizeof(struct shcmsg)) < 0 )
	{
		OTraceLog("L-SHC-014015: Failed to send msg ID[%s] /m%04d/t%d/p%06d to %s\n",
			header->msg.shclog_id, header->msg.msgtype, header->msg.trace,
			header->msg.pcode, mbMailBoxName(server_mid));
		return( -1 );
	}
	else
		OTraceLog("L-SHC-014016: Sent msg ID[%s] /m%04d/t%d/p%06d to %s\n",
			header->msg.shclog_id, header->msg.msgtype, header->msg.trace,
			header->msg.pcode, mbMailBoxName(server_mid));


	OTraceDebug("D-SHC-014008:    action : send to %s[%d]\n", mbMailBoxName(server_mid),
			server_mid);

	return( 0 );
}

int ShcmsgHelper::recon_api_getserver()
{
	/* R002521 */
	static int		recon_mid = (-1);
	static int		first_try = True;

	if ( (recon_mid < 0) && (first_try == True) )
	{
		if ( (recon_mid = mb_locatemailbox(SERVER_RECON_PROCESS)) < 0 )
		{
			OTraceWarning("W-SHC-014009: Unable to locate server mailbox. '%s'\n",
				SERVER_RECON_PROCESS);
		}
		first_try = False;
	}

	return( recon_mid );
}

int ShcmsgHelper::recon_api_getprivate()
{
	static int		mid = (-1);

	if ( mid < 0 )
		if ( (mid = mb_createmailbox_private()) < 0 )
			OTraceFatal("F-SHC-014010:RECON_API: Unable to create private mailbox.\n");

	return( mid );
}

/* 10002364 */
int ShcmsgHelper::shc_send_recon_500( ShcmsgHeader *header )
{
	/*
	 *	Route the settlement transaction to the proper settlement
	 *	task
	 */
	struct	shc500std	std500;
	int					mbid;

	if( (mbid = shc_settlement_findroute(header)) < 0 )
		 return( -1 );

	if( shc_settlement_format_message(header, &std500) < 0 )
		return( -1 );

	if( cache_mb_write(mbid, shcmid, (char *)&std500, sizeof(struct shc500std)) < 0 )
	{
		OTraceLog("L-SHC-014013: Failed to send msg ID[%s] /m%04d to %s\n",
			std500.shclog_id, std500.msgtype, mbMailBoxName(mbid));
		return( -1 );
	}
	else
		OTraceLog("L-SHC-014014: Sent msg ID[%s] /m%04d to %s\n",
			std500.shclog_id, std500.msgtype, mbMailBoxName(mbid));
	OTraceDebug("D-SHC-014012:    action : send to %s[%d]\n", mbMailBoxName(mbid), mbid);

	return( 0 );
}
