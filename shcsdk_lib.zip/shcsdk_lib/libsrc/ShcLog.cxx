static char _ShcLog_cxx_what[] = "@(#) ShcLog.cxx 1.84.31.2 20/05/15 14:27:42";



/*
 *  Copyright (C) 2004 eFunds Corporation ("eFunds").  All Rights Reserved.     
 *  eFunds Canada Corporation is an authorized user.                            
 *                                                                              
 *  IST is a registered trademark of eFunds Corporation.  Other brand or        
 *  product names are trademarks or registered trademarks of their respective   
 *  holders.                                                                    
 *                                                                              
 *  The information contained herein is the unpublished proprietary property    
 *  of eFunds.  Except as specifically authorized in writing by eFunds, the     
 *  holder of this document shall: i) keep all information contained herein     
 *  confidential, and ii) protect the information, in whole or in part, from    
 *  disclosure and dissemination to all third parties.                          
 *                                                                          
 *  This document and the software described in it are furnished under license  
 *  and may be used or copied only in accordance with the terms of such license.
 *  This document is supplied for information purposes only, is subject to      
 *  change without notice, and should not be construed as a commitment by       
 *  either eFunds Corporation or eFunds Canada Corporation. 
 *
 *
 *
 *                        MODIFICATION HISTORY                  REVIEW
 *
 *	SPR#	Who	Date	Description			Who	Date   
 * ===========================================================================
 * R0xxxxx 
 * R010373 lsun 07May04 support Visa FRS message
 * R012134 Emj  01Oct04 Support for Issuer Entity
 * R012160 Emj  10Oct04 Processor business Day
 * R012339 Emj  08Nov04 Emv Buffer Bitmap
 * R011925 jyang 16Sep04 Saf interleave support
 * R011824 rzhou 04Oct04 Log MasterCard specific data
 * R012381 Emj   12Nov04 New field tvr_cvr_statuc in emvbuf
 * R014452 Emj   28Jul05 New field issuer_auth_data in emvbuf
 * R015140 sdc   26Nov05 Check termid field when locating txn using refnum
 * R015154 sdc	 29Nov05 Log additional balance fields
 * R015223 sdc	 09Dec05 Use shc_maskpan function instead of masking here	
 * R015471 sdc	 13Jan06 Initialize pid to zero in the constructor
 * R015826 pve	 03Mar06 Support for Generic Log
 * R015909 spa	 14Mar06 Fix shcchiplog error;clone from R015772
 * R015958 spa	 15Mar06 txnDest should be used while locating original Txn
 * R016806 spa	 30Jun06 Fix format String mismatch in OTraceInfo call
 * R017867 spa	 28Sep06 txnDest comparison should be done for all records
 * R000000 jyang 17Oct06 Safdb support in dswitch
 * R018579 pve	 29Dec06 Approve repeat msg if the original msg is approved
 * R018754 Emj   23Jan07 Log shcchiglog if configured and txn has EMV_BUF
 *                       segment
 * R019573 Emj   11Apr07 Check device_devcap SH_DEVICE_LOG_SHCCHIPLOG when
 *                       updating shcchiplog
 * R021024 bby   27Aug07 PAN/CVV/CVV2/Track2 Masking 
 * R023231 Ram	 23May08 The SDK header should refer to external header
 * R025729 sks	 05Feb09 Populate correct value in shclog.issuer field
 * R026977 Dipa  21Jul09 While processing repeat txn, loop for approved txn ignoring duplicate txn response
 * R027170 Dipa  01Sep09 PA-DSS changes - tokenization of PAN in where clause done
 * R027202 sel   04Sep09 Truncate trailing spaces in alpha response code
 * R027559 Ash	 05Feb09 Clone of R027320 and R027562 
 * R028745 Dipa  16Nov10 Clone of R028676
 * R028821 Dipa  28Dec10 WR33700 - Interface to Data query tool
 * R028847 Dipa  28Dec10 USP-1481 - Confusing debug line
 * R028821 Dipa  06Jan11 WR33700 - Send header->msg to istnotify module
 * R028821 Dipa  12Jan11 WR33700 - Comment out the changes - to be release after integ. testing is done
 * R028821 Dipa  14Feb11 WR33700 - Changes in API implementation
 * R028821 Dipa  16Feb11 WR33700 - Change commenting style
 * R030004 Dipa  10Oct11 Initialize seg_req_len and seg_resp_len before calling restore()
 * R031154 Dipa  21Dec12 Clone of R031038, R031083
 */
 
/* File Number 32 */
/************************************************************************ 
 * These functions are dynamically link to at runtime from shc_lib.     *
 * The functionality of the logging may be customized by replacing each *
 * function with a custom version of the function.                      *
 * If a custom logging library is generated it must export each of the  *
 * functions.                                                           *
 ************************************************************************/




#if defined( WIN32 )
#       define SHCDLLEXPORT __declspec(dllexport)
#else
#       define SHCDLLEXPORT
#endif


#include <stdio.h>
#include <ctype.h>
#include <sys/types.h>
#include <sys/timeb.h>
#include <dbm.h>
#include <mb_umi.h>
#include <ist_otrace.h>
#include <shc.h>
#include <string.h>
#include <ic/ic_shcmsg.h>	/*	R005156	*/
#include <ic/ic_instid.h>
#include <CShcLog.h>
#include <ShcAppBase.h>
#include <ShcmsgHeader.h>
#include <ShcBin.h>
#include <ShcHelper.h>	//	---	R023231
#include <ShcmsgHelper.h>
#include <ShcGenericLogBinary.h>		//	R015826
#include <Dispatcher.h>
#include <HaPtmCctHelper.h>
#include <dbm_private.h>
#include <tokenizer.h>
#include <MRServiceDefs.h>
#include <ist_seg_name.h>
#include <ist_seg_elf_id_map.h>

//Added for BBL POS_BATCH_IDX Fix
#include <ist_seg_name.h> 
#include <ist_seg_elf_id_map.h> 
#include <ist_seg_id.h> 
//Added for BBL POS_BATCH_IDX Fix
#include <istsafe.h>
#include <BinRoute.h>
#include <msg_repl_util.h>

#include <ist_seg_shc300_req.h>
#include <DBMWrap/DBMException.hxx>


#define		SQLTBL_SZ		50
#define		SQLKEY_SZ		1024
#define		SQLEXP_CFG		"shc.sql_exp"
#define		SQLELM_CFG		"shc.sql_tbl"
#define		SQLCHAR_SEP		'|'


void handleDBMException(DBMConn* conObj, DBMStmt* stmt, const DBMException& e );
int generatePanCondTokens(char *pan, char *tok1, char *tok2);

struct SQLELM
{
	char	*key;
	char	*stmt;
};

static char				SqlKey[SQLKEY_SZ] = {0};
static struct SQLELM 	SqlTbl[SQLTBL_SZ] = {0};
static int				SqlTbl_n = 0;

int _shclog_isupdateReq = 0;
int shclogSkipGenlog = 0;

// 2024022
static int useRefnumToLocate = 0;
static int excludeTraceInRefnum = 0;
int locate_for_repeat = 0;

int generatePanCond(char *bp, char *pan, char **bpp)
{
        static Tokenizer *tkn_ptr = NULL;
        if (!tkn_ptr)
                tkn_ptr = Tokenizer::create();

        char pan_token[(Tokenizer::MAX_PAN_SIZE > Tokenizer::MAX_TOKEN_SIZE ?
                        Tokenizer::MAX_PAN_SIZE : Tokenizer::MAX_TOKEN_SIZE)+1];
        char pan_token2[(Tokenizer::MAX_PAN_SIZE > Tokenizer::MAX_TOKEN_SIZE ?
                        Tokenizer::MAX_PAN_SIZE : Tokenizer::MAX_TOKEN_SIZE)+1];
        int tkn_ret = tkn_ptr->getTokens(pan,pan_token, pan_token2,false);
        if(tkn_ret != 0)
        {
                if (tkn_ret == Tokenizer::PAN_NOT_FOUND)
                {
                        OTraceDebug("D-SHCLOG-5004.1: PAN not found \n");
                        //return Tokenizer::PAN_NOT_FOUND;
                }
                else
                {
                        OTraceError("E-SHCLOG-5004.1: Unable to tokenize Pan [%d]\n", tkn_ret);
                        //return -1;
                }
				return -1;
        }
        OTraceDebug("D-SHCLOG-5004.1: Tokenized PAN [%s]\n",
                        strcmp(pan,pan_token)? pan_token:shc_maskpan(pan_token));

        if ( pan_token[0] == '\0' )
        bp += sprintf(bp, "pan = '%s' ", pan_token2);
    else if (pan_token2[0] == '\0' )
        bp += sprintf(bp, "pan = '%s' ", pan_token);
    else
        bp += sprintf(bp, "pan in ('%s','%s') ", pan_token, pan_token2);

        *bpp = bp;
        return 0;
}

int ShcLog::logTxn(ShcHeader *logHeader)
{
	ShcmsgHeader *header = (ShcmsgHeader *)logHeader;
	char *ptr = NULL;
	int len;


	/*
	 *	Log the transaction to the database
	 */

	OTraceDebug("D-SHCLOG-5001:Log txn [%04d][%d][%s]\n",header->msg.msgtype, header->msg.site_id, header->msg.shclog_id );


	/* R002017 */
	if ( !use_log(header) )
		return 0;

	if (header->msg.local_date == 0)
		header->msg.local_date = shc_local_currentdate();

	/*	fill in the database fields */
	fill_transaction(header);

        memset(shclog.seg_req, 0, sizeof(shclog.seg_req));
        memset(shclog.seg_resp, 0, sizeof(shclog.seg_resp));

	if (shcIsResponse(header))
	{
		seg_resp_len = sizeof(shclog.seg_resp);
		shcGenericLogObj->fillSegment(header, (char *)shclog.seg_resp, &seg_resp_len);		//	R015826
	}
	else
	{
		seg_req_len = sizeof(shclog.seg_req);
		shcGenericLogObj->fillSegment(header, (char *)shclog.seg_req, &seg_req_len);		//	R015826
	}
	
									/* R008003,R008041 >> */
	
	/* Ssc - 28Jun00	R004671 integration 7.2 */
	/* Ssc - 21Feb00    SPR # 2007336
     *                  1. Pass new parameter to determine
     *                     if chip data should be logged
     *                  2. Advice chip txn is always logged
     */

 	if(insert_transaction(shcIsResponse(header)) < 0 ) /* R011925 */
		return(-1);

	if( (header->msg.msgtype == SHC_FILEUPD_ISSREQ ) || (header->msg.msgtype == SHC_LOCAL_FILEUPD_ISSREQ) )
        {
                int len=25;
                char updcode[2]="";
                IstSegShc300Req *shc300req = NULL;
                shc300req = (IstSegShc300Req *)header->getSegmentObj(ElfIdMap::elf_to_id(IST_SEG_SHC300_REQ), 0);
                if(shc300req)
                {
                        shc300req->getFileupdatecode(updcode, &len);
                        if(  (atoi(updcode)!= SHC300_QUERY ) )
                                shcApp->shcmsgHelperObj->replicateMessageToOtherSite(header);
                }
        }
	else if( (header->msg.msgtype == 800) ||
          ((strcmp(header->msg.txnSrc,"FN") == 0) && (header->msg.respcode == SHC_RC_Approved) && (header->msg.msgtype == SHC_FILEUPD_ISSREQ_RESPONSE) ))
        {
                shcApp->shcmsgHelperObj->replicateMessageToOtherSite(header);
        }
        else if ((shcIsResponse(header)) && (header->msg.msgtype/100 != 3)){
                shcApp->shcmsgHelperObj->replicateMessageToOtherSite(header);
        }

   	//	>>	 R028821 - commented out to implement after int.testing
	if (shcIsResponse(header))
	{
		Dispatcher::AfterShcLog(&header->msg,header->truelength());
	}
	//	<<	R028821 

	/*	That's all folks */
	return(0);
}

int ShcLog::logRepeat(ShcHeader *logHeader)
{
	ShcmsgHeader *header = (ShcmsgHeader *)logHeader;

	/*
	 *	Check if a transaction exists and if so do not log it
	 *	otherwise log the new transaction
	 */
	struct	ShcmsgWithSegment omsg;
	int ret;

	/* R002017 */
    if ( !use_log(header) )
        return 0;

	memset(&omsg, 0, sizeof(omsg));
	if(locateTxn(header, &(omsg.msg), NULL) < 0)
	{
		OTraceDebug("D-SHCLOG-5002: Creating transaction.\n");
		return(logTxn(header));
	}
									/* R007672 >> */
	if( shcIsAdvice(header) && (omsg.msg).shcerror==SHC_IE_Reversed )
	{
		return( 3 );
	}								/* R007672 << */

							/* R007211 BEGIN*/
	if (!shcmsgIsResponse(&(omsg.msg)))
		return 2;
	if (header->msg.msgtype % 10 == 1)
	{
		//header->msg.respcode=(omsg.msg).respcode;
		//header->msg.msgtype=(omsg.msg).msgtype;
	}
	else
	//shcApp->shccard.lasttxnrespcode=(omsg.msg).respcode;
							/* R007211 END */
	
	return(1);
}

int ShcLog::updateTxn(ShcmsgHeader *header, struct shcmsg *oldmsg, int flag)
{
	/*
	 *	Locate an original transaction and update it with the current
	 *	transaction
	 */
	struct	ShcmsgWithSegment omsg;
	int len;
	int		pcode_saved = -1;	// R010134
	// - commented out to implement after int. testing
	//	>> R028821
	int sendToNotify=0;
	//	<<	R028821 

	char saved_chip_index[sizeof(shclog.chip_index)] = {0};
	int  saved_site_id = 0;
	int  saved_located_is_req = 0;

	
	/* R002017 */
    if ( !use_log(header) )
        return 0;


	if (flag& IST_SHCLOG_FLAG_LOCATE_FIRST)
	{
		if(oldmsg == NULL)
		{
			oldmsg = &(omsg.msg);
			memset(&omsg, 0, sizeof(omsg));
		}
					/* R010134 >> */
		if( shcIsResponse(header) && (shcIsAuthorizationRequest(header)
			|| shcIsFinancialRequest(header)) 
			&& (!(shcIsIBFTW(header)||shcIsIBFTD(header))) )	// R011136
		{
			if( header->reqMsg && (header->reqMsg->pcode != header->msg.pcode ))
			{
				pcode_saved = header->msg.pcode;
				header->msg.pcode = header->reqMsg->pcode;
				OTraceDebug("D-SHCLOG-5065: locate with req pcode(%06d), then update resp pcode with (%06d)\n", 
						header->reqMsg->pcode, pcode_saved );
			}
		}
					/* R010134 << */
		
		if(locateTxn(header, oldmsg, NULL, flag) < 0)
		{
			switch(dbm_errno)
			{
			case DBME_EOF:
			case DBME_NOTFOUND:
				break;
			default:
				//Something wrong with database
				OTraceWarning("W-SHCLOG-5078: Unable to locate db txn: Error: %d. Abort update\n", dbm_errno);
				return -1;
			}
			/*	Insert with a special error code */
			header->msg.shcerror = SHC_IE_NoMatch;
			if( pcode_saved >= 0 )
			{
				header->msg.pcode = pcode_saved;
			}
			OTraceWarning("W-SHCLOG-5003: Unable to locate db txn: Error: %d\n", dbm_errno);
			return(logTxn(header));
		}

		istsafe_strcpy(saved_chip_index, sizeof(saved_chip_index), shclog.chip_index);
		saved_site_id = shclog.site_id;
		saved_located_is_req = (shclogLocateFd == shclogreqfd || 
                                shclogLocateFd == shclogreqfd_logID ||
                                shclogLocateFd == shclogreqfd_refnum) ? 1 : 0;

		OTraceDebug("D-SHCLOG-5200: updateTxn_After: located key chip_index[%s] site_id[%d] located_is_req[%d]\n",
			    saved_chip_index, saved_site_id, saved_located_is_req);
		
		if (shcmsgIsRequest(&shclog))
		{
			//The original is request msg, still need to log shcgenericlog
			_shclog_isupdateReq = 1;
		}
		else
			_shclog_isupdateReq = 0;

					/* R010134 >> */
		if( pcode_saved >= 0 )
		{
			header->msg.pcode = pcode_saved;
		}
					/* R010134 << */
	}
	if (shcmsgIsRequest(&shclog) && shcIsResponse(header))
	{
		seg_resp_len = sizeof(shclog.seg_resp);
		shcGenericLogObj->fillSegment(header, (char *)shclog.seg_resp, &seg_resp_len);		//	R015826
		sendToNotify = 1; 	//  >>   R028821
	}
	fill_transaction(header);

	if ((flag & IST_SHCLOG_FLAG_LOCATE_FIRST) && saved_chip_index[0] != '\0')
	{
		OTraceDebug("D-SHCLOG-5201: updateTxn: Before: chip_index[%s] site_id[%d], Restoring to: chip_index[%s] site_id[%d]\n",
                    shclog.chip_index, shclog.site_id, saved_chip_index, saved_site_id);

		memset(shclog.chip_index, 0, sizeof(shclog.chip_index));
		istsafe_strcpy(shclog.chip_index, sizeof(shclog.chip_index), saved_chip_index);
		shclog.site_id = saved_site_id;

		// Rewind to clear any stale cursor position
		rewind();

		if (saved_located_is_req)
		{
		    OTraceDebug("D-SHCLOG-5202: updateTxn: Relocking on REQ table (shclogreqfd_logID)\n");
		    if (dbm_read(shclogreqfd_logID, (char *)&shclog, DBM_REQUAL | DBM_RLOCK) >= 0)
		    {
			shclogLocateFd = shclogreqfd;
			OTraceDebug("D-SHCLOG-5203: updateTxn: Relock succeeded, shclogLocateFd now [%d]\n", shclogLocateFd);
		    }
		    else
		    {
			OTraceWarning("W-SHCLOG-5201: updateTxn: relock failed on shclogreqfd_logID for chip_index[%s] site_id[%d], dbm_errno[%d]\n",
			      saved_chip_index, saved_site_id, dbm_errno);
		    }
		}
		else
		{
		    OTraceDebug("D-SHCLOG-5205: updateTxn: Relocking on RESP table (shclogfd_logID)\n");
		    if (dbm_read(shclogfd_logID, (char *)&shclog, DBM_REQUAL | DBM_RLOCK) >= 0)
		    {
			shclogLocateFd = shclogfd;
			OTraceDebug("D-SHCLOG-5206: updateTxn: Relock succeeded, shclogLocateFd now [%d]\n", shclogLocateFd);
		    }
		    else
		    {
			OTraceWarning("W-SHCLOG-5202: updateTxn: relock failed on shclog_5 for chip_index[%s] site_id[%d], dbm_errno[%d]\n",
				      saved_chip_index, saved_site_id, dbm_errno);
		    }
		}
	}
	else
	{
		OTraceDebug("D-SHCLOG-5208: updateTxn: failed flag[0x%X] LOCATE_FIRST[%d] saved_chip_index[%s]\n",
                    flag, ((flag & IST_SHCLOG_FLAG_LOCATE_FIRST) ? 1 : 0), saved_chip_index);
	}

	if (update_transaction(1) < 0 ) /* R011925 */
		return -1;

	//	>>	R028821 - commented out to implement after int.testing
	if (sendToNotify)
	{
		Dispatcher::AfterShcLog(&header->msg,header->truelength());
	}
	//	<<	R028821 

	return(0);
}



/*
*	19Mar92 Sunny
*
*	Description:
*		This fuction try to read the shclog record sequentially and 
*		attempt to locate the transaction matching the field defined in
*		struct shclogmatch.
*	
*		Must at least give me the trace number and the Pan when calling 
*		this function.
*
*	Return 
*		0 if found and oldmsg will contains the shclog record.
*		-1 if unable to located or failed.
*/
int ShcLog::locateTxnSeq(ShcmsgHeader *header, struct shcmsg *oldmsg,
	struct shclogmatch *shclogmatch, int flag)
{

	int	ret;
	long	save_date;
	int		save_msgtype;
	int		cmp_trace;
	char	xbuf[256],*bp,*ptr1,*ptr,xbuf1[256];		//	---	R021024
	int fd[2];
	int i;

	/* R002017 */
    if ( !use_log(header) )
        return -1;

	if (shclogfd < 0)
		open_index();

	
	save_msgtype = header->msg.msgtype;
	header->msg.msgtype = header->msg.origmsg;
	cmp_trace = shclog.trace	  =  shcApp->shcmsgHelperObj->shcMakeKeyLog(header);
	header->msg.msgtype = save_msgtype;

	if(header->msg.trace < 0)
		cmp_trace = 0;

	shclog.local_time = header->msg.local_time;
	save_date = shclog.local_date = header->msg.local_date;

	memcpy(shclog.termid, header->msg.termid, sizeof(shclog.termid));
	memcpy(shclog.pan, header->msg.pan, sizeof(shclog.pan));


	memcpy(shclog.acquirer, header->msg.acquirer, sizeof(shclog.acquirer));
	memcpy(shclog.authnum, header->msg.authnum, sizeof(shclog.authnum));

	int firstMatchedEntry = 1;
	
		if( shclogfd >= 0 )	
		dbm_rewind(shclogfd);
		if( shclogreqfd >= 0 )
		dbm_rewind(shclogreqfd);
	
		OTraceDebug("D-SHCLOG-5004:T(%ld) ldate(%ld) ltime(%ld) term(%s) p(%s) a(%s)\n",
			shclog.trace, shclog.local_date, shclog.local_time,
			shclog.termid, shcApp->shcHelperObj->shc_maskpan(shclog.pan),shclog.acquirer);		//	---	R021024
		
		bp = xbuf;
		if (header->msg.local_date > 0)
			bp += sprintf(bp, "local_date = '%02d/%02d/%04d' ", 
							header->msg.local_date / 100 % 100,
							header->msg.local_date % 100,
							header->msg.local_date / 10000 );
			
		if (header->msg.pan[0])
		{
			if (bp != xbuf)
			{
				istsafe_strcat (bp, (sizeof(xbuf)-(bp-xbuf)), "and ");
				bp += 4;
			}

			// R027170 >>>>
                        int tkn_ret = generatePanCond(bp, header->msg.pan, &bp);
                        if(tkn_ret != 0)
                        {
                                        //if (tkn_ret == Tokenizer::PAN_NOT_FOUND)
                                                //return 0;
                                        //else
                                                return -1;
                        }

                                // <<<< R027170

			}
			
			if (header->msg.acquirer[0])
			{
				if (bp != xbuf)
				{
					istsafe_strcat (bp, (sizeof(xbuf)-(bp-xbuf)), "and ");
					bp += 4;
				}
				bp += sprintf(bp, "acquirer = '%10s' ", header->msg.acquirer);
			}
			
			if (header->msg.termid[0])
			{
				if (bp != xbuf)
				{
					istsafe_strcat (bp, (sizeof(xbuf)-(bp-xbuf)), "and ");
					bp += 4;
				}
				bp += sprintf(bp, "termid = '%s' ",	header->msg.termid);
			}
			
			if(cmp_trace)
			{
				if (bp != xbuf)
				{
					istsafe_strcat (bp, (sizeof(xbuf)-(bp-xbuf)), "and ");
					bp += 4;
				}
				bp += sprintf(bp, "trace = %ld ", header->msg.trace);
			}
			
			if(header->msg.authnum[0] != '\0')
			{
				if (bp != xbuf)
				{
					istsafe_strcat (bp, (sizeof(xbuf)-(bp-xbuf)), "and ");
					bp += 4;
				}
				bp += snprintf(bp, (sizeof(xbuf)-(bp-xbuf)), "authnum = '%s' ", header->msg.authnum);
			}

			if(header->msg.entityId[0] != '\0')
			{
				if (bp != xbuf)
				{
					istsafe_strcat (bp, (sizeof(xbuf)-(bp-xbuf)), "and ");
					bp += 4;
				}
				bp += sprintf(bp, "entityid = '%s' ", header->msg.entityId);
			}

			// EwenJ Start loop here 
			if (((flag  & IST_SHCLOG_FLAG_LOCATE_REQ  && flag & IST_SHCLOG_FLAG_LOCATE_RESP)) ||
				(!(flag & IST_SHCLOG_FLAG_LOCATE_REQ) && !(flag & IST_SHCLOG_FLAG_LOCATE_RESP)) )
			{
				fd[0] = shclogfd;
				fd[1] = shclogreqfd;
				OTraceDebug("D-SHCLOG-5101:Search RESP/REQ\n");
			}
			else if (flag & IST_SHCLOG_FLAG_LOCATE_REQ)
			{
				fd[0] = shclogreqfd;
				fd[1] = -1;
				OTraceDebug("D-SHCLOG-5102:Search REQ\n");
			}
			else if (flag & IST_SHCLOG_FLAG_LOCATE_RESP)
			{
				fd[0] = shclogfd;
				fd[1] = -1;
				OTraceDebug("D-SHCLOG-5103:Search RESP\n");
			}

		OTraceDebug("D-SHCLOG-5069:sql[%s]\n", xbuf); //R027170

		for (i = 0; i < 2 && fd[i] != -1; i++)

		{	
			if(dbm_selectfd(fd[i], xbuf) < 0)
			{
				OTraceError("E-SHCLOG-5005:Select failed in shc_log.c\n");
				return(-1);
			}

			while(dbm_fetchfd(fd[i], (char *)&shclog) >= 0)
			{
				if (firstMatchedEntry)
				{
					fill_message(oldmsg);
					shclogLocateFd = fd[i];
					firstMatchedEntry = 0;
					continue;
				}
				
				if (shclog.local_date < oldmsg->local_date)
					continue;
				else if (	(shclog.local_date > oldmsg->local_date) ||
							(shclog.local_time > oldmsg->local_time) )
				{
					fill_message(oldmsg);
					shclogLocateFd = fd[i];
				}
			
				continue;
			}				

			//rewind(); //IST_S770SP5-146 
			return(0);	
	
		
		}
	
	//rewind(); //IST_S770SP5-146 

	if (!firstMatchedEntry)
		return 0;
		
	OTraceError("E-SHCLOG-5006: Fetch failed in shc_log.c\n");
	return(-1);

}

/* Ssc - 28Jun00	R004671 integration 7.2 */
/* Ssc - 23Feb00    SPR 2007336 Update for support chip Txn */

int ShcLog::fill_transaction(ShcmsgHeader *header)
{
	int i, len; /* R003928 rlo For-loop index */
	char buf[2] = {0};
	static int logPosBatchIdx = -1;
	int seg_len = 0;
	int src_node = 0;
	int dest_node = 0;	

	struct RoutingInfo routingInfo = {0};

						/* R008003 >> */
	if( header->msg.shclog_id[0]) 
	{
        OTraceDebug("D-SHCLOG-5010: Got chip_index(%s).\n",header->msg.shclog_id);
	}
	else
	{
        if( mb_getUmi( header->msg.shclog_id, sizeof(header->msg.shclog_id) ) < 0 )
        {
            OTraceError("E-SHCLOG-5011:SHC-MAKEKEY: Unable to make key.\n");
            return(-1);
        }
        else
        	OTraceLog("L-SHCLOG-5017: New ID [%s] created for m%04d/t%06d/p%06d\n", 
        			header->msg.shclog_id, header->msg.msgtype, header->msg.trace, header->msg.pcode);
    }
	strcpy(shclog.chip_index, header->msg.shclog_id);

	// Set Site_id and Version ID
	if (header->msg.site_id == 0)
    	header->msg.site_id = mbGetSiteId();
	shclog.site_id = header->msg.site_id;

	if (header->msg.version == 0)
		header->msg.version = 770;
	shclog.version =  header->msg.version;

	// Set src_node and dest_node 

	seg_len = sizeof(struct RoutingInfo);
	header->getSegmentData((char *)&routingInfo, &seg_len, NETWORK_DATA_REQ_id,ROUTING_INFO);
	if ( seg_len > 0 )
	{
		OTraceDebug("D-SHCLOG-5135: routingInfo->SrcNode[%s] and routingInfo->DestNode[%s] \n", routingInfo.srcNode,routingInfo.destNode);
		if (IST_MR::cluster_info_loaded() == true)
		{
			int ret_src = IST_MR::map_node_name_to_node_id(routingInfo.srcNode, src_node);
			if ( ret_src == 0 )
			{
				header->msg.src_node = src_node;
				OTraceDebug("D-SHCLOG-5136: Source Node [%d] \n", header->msg.src_node);
			}
			else
			{
				OTraceDebug("D-SHCLOG-5137: Source node not found set src_node as Current node \n");
				header->msg.src_node = getNodeId_mb();
			}
			int ret_dest = IST_MR::map_node_name_to_node_id(routingInfo.destNode, dest_node);
			if ( ret_dest == 0 )
			{
				header->msg.dest_node = dest_node;
				OTraceDebug("D-SHCLOG-5138: Destination Node [%d] \n", header->msg.dest_node);
			}
			else
			{
				OTraceDebug("D-SHCLOG-5139: Destination node not found set dest_node as 0 \n");
				header->msg.dest_node = 0;
			}
		}
		else
		{
			OTraceDebug("D-SHCLOG-5140: cluster-info rule not found \n");
			if(strcmp(routingInfo.srcNode,routingInfo.destNode)==0)
			{
				header->msg.src_node = getNodeId_mb();
				header->msg.dest_node = header->msg.src_node;
			}
			else
			{
				header->msg.src_node = getNodeId_mb();
				header->msg.dest_node = 0;
			}
		}
	}
	else
	{
		OTraceDebug("D-SHCLOG-5141: RoutingInfo Segment not found setting setting src_node as currentnode and dest_node to 0\n");
		header->msg.src_node = getNodeId_mb();
		header->msg.dest_node = 0;
	}					
			
	shclog.src_node  = header->msg.src_node;
	shclog.dest_node = header->msg.dest_node;

	OTraceDebug("D-SHCLOG-5142: shclog.src_node[%d] and shclog.dest_node[%d] \n", shclog.src_node, shclog.dest_node);

	//Loading logPosBatchIdx Configuration
	if ( logPosBatchIdx < 0 )
	{
        logPosBatchIdx = 0;	
		if ( cf_open(NULL) >= 0 )
		{
			if( (cf_locate("shc.logPosBatchIdx", buf)) >= 0 )
    		{
        		if ( toupper(buf[0]) == 'Y' || buf[0] == '1' )
        		{
            		OTraceDebug("D-SHC-032035: Parameter shc.logPosBatchIdx is set on\n");
            		logPosBatchIdx = 1;
        		}
    		}
		cf_close();
		}
	}


						/* R008003 << */
	OTraceDebug("D-SHCLOG-5012:   Copy shcmsg to shclog for m%04d/p%06d\n",
			 header->msg.msgtype, header->msg.pcode);

	shclog.device_cap = header->msg.device_cap & ~SH_DEVCAP_USER_SEGMENT;
	shclog.msgtype 	= header->msg.msgtype ;
	shclog.flipped_msgtype 	= header->msg.flipped_msgtype ;
	shclog.txntype 	= header->msg.txntype;
	strcpy(shclog.pan	 	, header->msg.pan	 );
	strcpy(shclog.mask_pan	 	, header->msg.pan	 );
    shcApp->shcmsgHelperObj->shc_denormalizepan(shclog.mask_pan);

	/* R015223 begin */
	char *ptr = shcApp->shcHelperObj->shc_maskpan(shclog.mask_pan);
	snprintf(shclog.mask_pan,sizeof(shclog.mask_pan),"%s",ptr); //IST_S_0157721-34
	/* R015223 end */

	//Added For Populating POS_BATCH_IDX in SHCLOG.MASK_PAN
	memset(shclog.mask_pan, 0, sizeof(shclog.mask_pan));    //PA-DSS
	if ( logPosBatchIdx )
	{
		char posBatchIdx[2048] = {0};
		int lenPosBatchId = sizeof(posBatchIdx);	
		header->getSegmentData ( posBatchIdx, &lenPosBatchId, ElfIdMap::elf_to_id(IST_SEG_NETWORK_DATA_REQ), POS_TMPFLD);

		if ( lenPosBatchId > 0 )
			istsafe_strcpy(shclog.mask_pan,sizeof(shclog.mask_pan),posBatchIdx+972);
			//strncpy ( shclog.mask_pan, posBatchIdx+972, 16);
			shclog.mask_pan[16] = '\0';
	}


	shclog.pcode 	= header->msg.pcode ;
	dbm_deccopy(&shclog.amount 	, &header->msg.amount );
	dbm_deccopy(&shclog.aval_balance 	, &header->msg.aval_balance );
	dbm_deccopy(&shclog.cash_back 	, &header->msg.cash_back);

	dbm_deccopy(&shclog.iss_conv_rate 	, &header->msg.iss_conv_rate );
	shclog.iss_currency_code 	= header->msg.iss_currency_code ;
	shclog.iss_conv_date	= header->msg.iss_conv_date;

	dbm_deccopy(&shclog.acq_conv_rate 	, &header->msg.acq_conv_rate );
	shclog.acq_currency_code 	= header->msg.acq_currency_code ;
	shclog.txn_currency_code 	= header->msg.txn_currency_code ;
	shclog.acq_conv_date	= header->msg.acq_conv_date;

	/* qd 23feb96	add four new fields */
	dbm_deccopy(&shclog.tra_amount, &header->msg.tra_amount);
	dbm_deccopy(&shclog.tra_conv_rate 	, &header->msg.tra_conv_rate );
	shclog.tra_currency_code 	= header->msg.tra_currency_code ;
	shclog.tra_conv_date	= header->msg.tra_conv_date;

	dbm_deccopy(&shclog.amount_equiv 	, &header->msg.amount_equiv );
	shclog.trandate 	= header->msg.trandate ;
	shclog.trantime 	= header->msg.trantime ;
	shclog.trace 	=  shcApp->shcmsgHelperObj->shcMakeKeyLog(header);
	shclog.local_time 	= header->msg.local_time ;

	if(DateCheckBeforeLogging)
	{
		OTraceDebug("D-SHC-032049: Parameter shc.date_check_before_logging is set on\n");
		if(header->msg.local_date/10000 < 1999)
        	{
               		header->msg.local_date = 19990000 + (header->msg.local_date) % 10000;
        	}
	}

	shclog.local_date	= header->msg.local_date;
	shclog.settlement_date 	= header->msg.settlement_date ;
	shclog.origmsg		= header->msg.origmsg;
	shclog.origflippedmsg		= header->msg.origFlippedMsg;
	shclog.origtrace	= header->msg.origtrace;
	shclog.origdate		= header->msg.origdate;
	shclog.origtime		= header->msg.origtime;
	shclog.cap_date 	= header->msg.cap_date ;
	shclog.processor_busday 	= header->msg.processor_busday;
	shclog.pos_entry_code 	= header->msg.pos_entry_code ;
	shclog.pos_condition_code = header->msg.pos_condition_code;
	shclog.pos_pin_cap_code = header->msg.pos_pin_cap_code;
	shclog.pos_cap_code	= header->msg.pos_cap_code;
	shclog.life_cycle	= header->msg.life_cycle;
	shclog.serial_1		= header->msg.serial_1;
	shclog.serial_2		= header->msg.serial_2;
	strcpy(shclog.acquirer 	, header->msg.acquirer );

	//	>>>	R025729
	strcpy(shclog.issuer 	, header->msg.issuer );
	strcpy(shclog.transferee , header->msg.transferee ); /* qd 23feb96 */
	//	<<<	R025729

	strcpy(shclog.originator 	, header->msg.originator );
	shclog.respcode 	= header->msg.respcode ;
	shclog.reason_code 	= header->msg.reason_code ; /* qd 23feb96 */
	shclog.revcode 	= header->msg.revcode ;
	shclog.shcerror	= header->msg.shcerror;
	shclog.saf		= header->msg.saf;
	strcpy(shclog.refnum 	, header->msg.refnum );
	strcpy(shclog.authnum 	, header->msg.authnum );
	strcpy(shclog.termid 	, header->msg.termid );
	strcpy(shclog.acceptorname 	, header->msg.acceptorname );
	strcpy(shclog.termloc	 	, header->msg.termloc	 );
	istsafe_strcpy(shclog.addresponse,sizeof(shclog.addresponse),	header->msg.addresponse);
	strcpy(shclog.acctnum, header->msg.acctnum);
	/* The additional response field was set in eds_toist.c bit 38
	   to be able to capture the network over which the transaction
	   was sent out. This is filled into shclog - It is the responsibility
	   of Evan's team to be able to charge the merchant for "SUSPENSE"
	   items - i.e without receiving the PDF from EDS they charge the
	   merchant for the network to which the txn was routed */

	shclog.settlement_code = header->msg.settlement_code;
	dbm_deccopy(&shclog.settlement_rate, &header->msg.settlement_rate);
	dbm_deccopy(&shclog.settlement_amount, &header->msg.settlement_amount);
	dbm_deccopy(&shclog.fee, &header->msg.fee);

	/* qd 23feb96	add 12 new fields */
	dbm_deccopy(&shclog.new_fee, &header->msg.new_fee);
	dbm_deccopy(&shclog.new_amount, &header->msg.new_amount);
	dbm_deccopy(&shclog.new_setl_amount, &header->msg.new_setl_amount);
	dbm_deccopy(&shclog.settlement_fee, &header->msg.settlement_fee);

	/* R007894 */
	header->msg.device_devcap |= ( atoi(header->msg.sec_fmt_code) 
									& SH_DEVICE_SECFMTCODE_MASK );

	shclog.device_devcap 	= header->msg.device_devcap ; 
	shclog.shc_devcap 	    = header->msg.shc_devcap ; 
	shclog.formatter_devcap	= header->msg.formatter_devcap ; 
	shclog.auth_devcap 	    = header->msg.auth_devcap ; 

	memcpy(shclog.filler1, header->msg.filler1, sizeof(shclog.filler1) );
	memcpy(shclog.filler2, header->msg.filler2, sizeof(shclog.filler2) );
	memcpy(shclog.filler3, header->msg.filler3, sizeof(shclog.filler3) );
	memcpy(shclog.filler4, header->msg.filler4, sizeof(shclog.filler4) );

	shclog.storeid	= header->msg.storeid;
	shclog.lane	= header->msg.lane;
	shclog.terminal_trace	= header->msg.terminal_trace;
	shclog.checker_id	= header->msg.checker_id;
	shclog.supervisor	= header->msg.supervisor;
	shclog.shift_number	= header->msg.shift_number;
	shclog.slot_num	= header->msg.slot_num; /* 2005204 */
	shclog.batch_id	= header->msg.batch_id;

	shclog.merchant_type= header->msg.merchant_type;		/* Essa. 18Dec92. HP code*/
	shclog.acq_country	= header->msg.acq_country;	/* ss:10mar95 */

	/*R003928*/
	/*Currently this field may not be logged in to database as our database
	  layer seems to be terminating the field when it sees first null
	  character SG*/
	/* Replacing null characters with 0x10 */
	for(i = 0; i < SHC_DATA_LEN; i++)
		if(header->msg.shc_data_buffer[i])
			shclog.shc_data_buffer[i] = header->msg.shc_data_buffer[i];
		else
			shclog.shc_data_buffer[i] = 0x10;

    /* R004685 - log some fields for Europay --> */
    shclog.ch_currency_code    = header->msg.ch_currency_code ;
    shclog.ch_conv_date    = header->msg.ch_conv_date;

    dbm_deccopy(&shclog.ch_amount  , &header->msg.ch_amount );
    dbm_deccopy(&shclog.ch_conv_rate, &header->msg.ch_conv_rate );

    dbm_deccopy(&shclog.new_amount_equiv  , &header->msg.new_amount_equiv );
    dbm_deccopy(&shclog.txn_amount  , &header->msg.txn_amount );
    /* <-- R004685 for Europay */

			/* R007208 >> */
	dbm_deccopy(&shclog.new_setl_fee, &header->msg.new_setl_fee);
	dbm_deccopy(&shclog.txn_conv_rate, &header->msg.txn_conv_rate);
	dbm_deccopy(&shclog.ch_new_amount , &header->msg.ch_new_amount );
			/* << R007208 */
	
    /*
     * yh: 1997/09/22. Fill in issuer_data/acquirer_data for SMS
     */
    memcpy(shclog.issuer_data,header->msg.issuer_data,sizeof(shclog.issuer_data));    
	
	char 	segbuf[64] = {0},
            acq_dataBuf[129]={0};
    int seglen = -1;
    header->getSegmentData( segbuf, &seglen,
        ElfIdMap::elf_to_id(IST_SEG_NETWORK_SETTLEMENT_DATA), MERCHANT_TRANS_ID);
    if(seglen){
        if(strlen(shclog.acquirer_data)+seglen > 128){
            OTraceDebug("D-SHCLOG-5020: MERCHANT_TRANS_ID trimmed in acquirer_data\n");
        }
        sprintf(acq_dataBuf,"%s|%s",header->msg.acquirer_data,segbuf);
        memcpy(shclog.acquirer_data,acq_dataBuf,sizeof(shclog.acquirer_data));
    }else
     memcpy(shclog.acquirer_data,header->msg.acquirer_data,sizeof(shclog.acquirer_data));    

	/* R008717 BEGIN */
	strcpy(shclog.txnsrc, header->msg.txnSrc);
	strcpy(shclog.txndest, header->msg.txnDest);
	strcpy(shclog.alternateacquirer, header->msg.alternateAcquirer);
	strcpy(shclog.entityid, header->msg.entityId);
	strcpy(shclog.iss_entityid, header->msg.iss_entityId);
	strcpy(shclog.cardproduct, header->msg.cardProduct);
	strcpy(shclog.member_id, header->msg.member_ID);
	strcpy(shclog.f_id, header->msg.F_ID);
	strcpy(shclog.mvv, header->msg.MVV);
	strcpy(shclog.invoice_number, header->msg.invoice_number);
	strcpy(shclog.trans_id, header->msg.trans_id);
	strcpy(shclog.fpi, header->msg.FPI);
	/* R008717 END */

	/*
	 * yh: 1997/10/2. Log the ledger_balance into the database table shclog.
	 *
	 */
    dbm_deccopy(&shclog.ledger_balance, &header->msg.ledger_balance);

	/* R015154 Log additional balance fields */
	dbm_deccopy(&shclog.setl_ledger_balance, &header->msg.setl_ledger_balance);
	dbm_deccopy(&shclog.setl_aval_balance, &header->msg.setl_aval_balance);
	dbm_deccopy(&shclog.acq_ledger_balance, &header->msg.acq_ledger_balance);
	dbm_deccopy(&shclog.acq_aval_balance, &header->msg.acq_aval_balance);
	/* R015154 end */

	shclog.aval_balance_type = header->msg.aval_balance_type; //R028676
	shclog.ledger_balance_type = header->msg.ledger_balance_type; //R028676


	dbm_deccopy(&shclog.device_fee, &header->msg.device_fee);	/* R002421 */
	
	/* Ssc - 28Jun00	R004671 integration 7.2 */
	/* Ssc - 17Feb00    SPR # 2007336 New chip fields in shclog */

	memset(shclog.alpharesponsecode, 0x00, sizeof(shclog.alpharesponsecode));
	istsafe_strcpy(shclog.alpharesponsecode, sizeof(shclog.alpharesponsecode), header->msg.alpha_response_code);
    /* Ssc - 17Mar00    SPR # 2007336 Match chip_type between shclog
     *                  and shcmsg
     */
    shclog.card_seqno      = header->msg.card_seqno;

	shclog.branch	= header->msg.branch;	/* R007204 */
	shclog.txn_start_time = header->msg.txn_start_time;
	if (shcIsResponse(header))
	{
		if (header->msg.txn_end_time <= 0)
		{
			struct timeb tmpTime;
			ftime(&tmpTime);
			struct tm *tmpGmtime = gmtime(&tmpTime.time);
			header->msg.txn_end_time = 	tmpGmtime->tm_hour * 	10000000 +
											tmpGmtime->tm_min*		100000 +
											tmpGmtime->tm_sec*		1000 +
											tmpTime.millitm;
		}
		shclog.txn_end_time = header->msg.txn_end_time;
	}
	// >>> R026128 - Initializing txn_end_time to 0 for request messages
	else
			shclog.txn_end_time = 0;
    // <<< R026128

	shclog.gateway_id = header->msg.gateway_id;

	//char segbuf[20];
	//int seglen = 0;
	memset(segbuf,0,sizeof(segbuf));
	header->getSegmentData ( segbuf, &seglen, ElfIdMap::elf_to_id(IST_SEG_NETWORK_SETTLEMENT_DATA), SHCIMF_SUBMERCHANT_ID);
	if(seglen > 0)
		istsafe_strcpy(shclog.submerchant_id, sizeof(shclog.submerchant_id), segbuf);

	seglen = 0;
	memset(segbuf,0,sizeof(segbuf));
	header->getSegmentData ( segbuf, &seglen, ElfIdMap::elf_to_id(IST_SEG_NETWORK_SETTLEMENT_DATA), MERCH_DESTBASED_ID);
	if(seglen > 0)
		istsafe_strcpy(shclog.dest_id, sizeof(shclog.dest_id), segbuf);

	seglen = 0;
	memset(segbuf,0,sizeof(segbuf));
	header->getSegmentData ( segbuf, &seglen, ElfIdMap::elf_to_id(IST_SEG_NETWORK_SETTLEMENT_DATA), SHCIMF_PAYMENT_FACILITATOR_ID);
	if(seglen > 0)
		istsafe_strcpy(shclog.payfacid, sizeof(shclog.payfacid), segbuf);

	return( 0 );
}

int ShcLog::fill_message(struct shcmsg *msg)
{
	int	i;	/* R003928 rlo For-loop index */
	struct shc_data	*shc_data_ptr;	/* R001319 For filling device_cap */
	/* Ssc - 28Jun00	R004671 integration 7.2 */
	/* Ssc - 17Feb00    SPR # 2007336 Update fill_message()
	 *                  to support chip data Txn
 	 */
	int 	 len;
	int 	 hasError = 0;

	
	if (shclogfd < 0)
		open_index();

	msg->pos_entry_code 	= shclog.pos_entry_code ;			/* R008003 */
	msg->device_cap = shclog.device_cap &  ~SH_DEVCAP_USER_SEGMENT;
	
	strncpy(msg->shclog_id, shclog.chip_index, 20 );	//	R015826


	OTraceDebug("D-SHCLOG-5016:  Copy shclog to shcmsg for m%04d/p%06d\n",
			 shclog.msgtype, shclog.pcode);

	if (shclog.site_id == 0)
		shclog.site_id = mbGetSiteId(); 
	msg->site_id =  shclog.site_id;

	if (shclog.version == 0)
		shclog.version = 770;
	msg->version =  shclog.version;

	msg->src_node = shclog.src_node;
	msg->dest_node = shclog.dest_node;


	msg->msgtype 	= shclog.msgtype ;
	msg->flipped_msgtype 	= shclog.flipped_msgtype ;
	msg->txntype		= shclog.txntype ;
	strcpy(msg->pan	 	, shclog.pan	 );
	msg->pcode 	= shclog.pcode ;
	dbm_deccopy(&msg->amount 	, &shclog.amount );
	dbm_deccopy(&msg->aval_balance 	, &shclog.aval_balance );
	dbm_deccopy(&msg->cash_back 	, &shclog.cash_back);

	dbm_deccopy(&msg->iss_conv_rate 	, &shclog.iss_conv_rate );
	msg->iss_currency_code 	= shclog.iss_currency_code ;
	msg->iss_conv_date	= shclog.iss_conv_date;

	dbm_deccopy(&msg->acq_conv_rate 	, &shclog.acq_conv_rate );
	msg->acq_currency_code 	= shclog.acq_currency_code ;
	msg->txn_currency_code 	= shclog.txn_currency_code ;
	msg->acq_conv_date	= shclog.acq_conv_date;

	/* qd 23feb96	add four new fields */
	dbm_deccopy(&msg->tra_amount, &shclog.tra_amount);
	dbm_deccopy(&msg->tra_conv_rate 	, &shclog.tra_conv_rate );
	msg->tra_currency_code 	= shclog.tra_currency_code ;
	msg->tra_conv_date	= shclog.tra_conv_date;

	dbm_deccopy(&msg->amount_equiv 	, &shclog.amount_equiv );
	msg->trandate 	= shclog.trandate ;
	msg->trantime 	= shclog.trantime ;
	msg->trace 	= shc_gettrace(shclog.trace);
	msg->local_time 	= shclog.local_time ;
	msg->local_date 	= shclog.local_date ;
	msg->settlement_date 	= shclog.settlement_date ;
	msg->origmsg		= shclog.origmsg;
	msg->origFlippedMsg		= shclog.origflippedmsg;
	msg->origtrace	= shclog.origtrace;
	msg->origdate		= shclog.origdate;
	msg->origtime		= shclog.origtime;
	msg->cap_date 	= shclog.cap_date ;
	msg->processor_busday 	= shclog.processor_busday;
	msg->pos_entry_code 	= shclog.pos_entry_code ;
	msg->pos_condition_code = shclog.pos_condition_code;
	msg->pos_pin_cap_code = shclog.pos_pin_cap_code;
	msg->pos_cap_code	= shclog.pos_cap_code;
	msg->life_cycle	= shclog.life_cycle;
	msg->serial_1	= shclog.serial_1;
	msg->serial_2	= shclog.serial_2;
	strcpy(msg->acquirer 	, shclog.acquirer );
	strcpy(msg->issuer 	, shclog.issuer );
	strcpy(msg->transferee 	, shclog.transferee ); /* qd 23feb96 */
	strcpy(msg->originator 	, shclog.originator );
	msg->respcode 	= shclog.respcode ;
	msg->reason_code 	= shclog.reason_code ; /* qd 23feb96 */
	msg->revcode 	= shclog.revcode ;
	msg->shcerror	= shclog.shcerror;
	msg->saf			= shclog.saf;
	strcpy(msg->refnum 	, shclog.refnum );
	strcpy(msg->authnum 	, shclog.authnum );
	strcpy(msg->termid 	, shclog.termid );
	strcpy(msg->acceptorname 	, shclog.acceptorname );
	strcpy(msg->termloc	 	, shclog.termloc	 );
	//strtrim(msg->termloc, msg->termloc);
	strcpy(msg->addresponse,	shclog.addresponse);
	strcpy(msg->acctnum, shclog.acctnum);
	strtrim(msg->acctnum, msg->acctnum);

	msg->settlement_code = shclog.settlement_code;
	dbm_deccopy(&msg->settlement_rate, &shclog.settlement_rate);
	dbm_deccopy(&msg->settlement_amount, &shclog.settlement_amount);
	dbm_deccopy(&msg->fee, &shclog.fee);

	/* qd 23feb96	add 12 new fields */
	dbm_deccopy(&msg->new_fee, &shclog.new_fee);
	dbm_deccopy(&msg->new_amount, &shclog.new_amount);
	dbm_deccopy(&msg->new_setl_amount, &shclog.new_setl_amount);
	dbm_deccopy(&msg->settlement_fee, &shclog.settlement_fee);

	msg->device_devcap 	 = shclog.device_devcap ; 
	
	/* R007894 */
	snprintf( msg->sec_fmt_code, sizeof(msg->sec_fmt_code), "%02d"
			, msg->device_devcap & SH_DEVICE_SECFMTCODE_MASK) ;

	msg->shc_devcap 	     = shclog.shc_devcap ; 
	msg->formatter_devcap = shclog.formatter_devcap ; 
	msg->auth_devcap 	 = shclog.auth_devcap ; 

	memcpy(msg->filler1, shclog.filler1, sizeof(shclog.filler1) );
	memcpy(msg->filler2, shclog.filler2, sizeof(shclog.filler2) );
	memcpy(msg->filler3, shclog.filler3, sizeof(shclog.filler3) );
	memcpy(msg->filler4, shclog.filler4, sizeof(shclog.filler4) );

	msg->storeid	= shclog.storeid;
	msg->lane	= shclog.lane;
	msg->terminal_trace	= shclog.terminal_trace;
	msg->checker_id	= shclog.checker_id;
	msg->supervisor	= shclog.supervisor;
	msg->shift_number	= shclog.shift_number;
	msg->slot_num	= shclog.slot_num; /* 2005204  */
	msg->batch_id	= shclog.batch_id;

	msg->merchant_type = shclog.merchant_type; /* 18Dec92. HP Code */
	msg->acq_country	= shclog.acq_country;	/* ss:10mar95 */
   
    /* R001934. */
    dbm_deccopy(&msg->ledger_balance, &shclog.ledger_balance );

	/* R015154 Log additional balance fields */
	dbm_deccopy(&msg->acq_aval_balance, &shclog.acq_aval_balance);
	dbm_deccopy(&msg->acq_ledger_balance, &shclog.acq_ledger_balance);
	dbm_deccopy(&msg->setl_aval_balance, &shclog.setl_aval_balance);
	dbm_deccopy(&msg->setl_ledger_balance, &shclog.setl_ledger_balance);
	/* R015154 end */

	msg->aval_balance_type = shclog.aval_balance_type; //R028676
	msg->ledger_balance_type = shclog.ledger_balance_type; //R028676

	dbm_deccopy(&msg->device_fee, &shclog.device_fee);	/* R002421 */

    /*
     * yh: 1997/10/14. Fill the message with the original data for
     *                 issuer_data & acquirer_data
     */
    memcpy(msg->issuer_data, shclog.issuer_data, sizeof(shclog.issuer_data));
    memcpy(msg->acquirer_data, shclog.acquirer_data, sizeof(shclog.acquirer_data));

	/* R008717 BEGIN */
	ICInstId_pure(msg->txnSrc, shclog.txnsrc);
	ICInstId_pure(msg->txnDest, shclog.txndest);
	strcpy(msg->alternateAcquirer, shclog.alternateacquirer);
	strcpy(msg->entityId, shclog.entityid);
	strcpy(msg->iss_entityId, shclog.iss_entityid);
	strcpy(msg->cardProduct, shclog.cardproduct);
	strcpy(msg->member_ID, shclog.member_id);
	strcpy(msg->F_ID, shclog.f_id);
	strcpy(msg->MVV, shclog.mvv);
	strcpy(msg->invoice_number, shclog.invoice_number);
	strcpy(msg->trans_id, shclog.trans_id);
	strcpy(msg->FPI, shclog.fpi);
	/* R008717 END */


	/*R003928*/
	for(i = 0; i < SHC_DATA_LEN; i++)
		if(shclog.shc_data_buffer[i] == 0x10)
			msg->shc_data_buffer[i] = '\0';
		else
			msg->shc_data_buffer[i] = shclog.shc_data_buffer[i];

	/* R001319 Filling device_cap in shcmsg */
	shc_data_ptr = (struct shc_data *)msg->shc_data_buffer;
	/* End R001319 */

    /* R004685 - restore some fields for Europay --> */
    msg->ch_currency_code =shclog.ch_currency_code;
    msg->ch_conv_date = shclog.ch_conv_date;

    dbm_deccopy( &msg->ch_conv_rate, &shclog.ch_conv_rate );
    dbm_deccopy( &msg->ch_amount, &shclog.ch_amount );

    dbm_deccopy( &msg->new_amount_equiv, &shclog.new_amount_equiv );
    dbm_deccopy( &msg->txn_amount, &shclog.txn_amount );
    /* <-- R004685 for Europay */

			/* R007208 >> */
	dbm_deccopy( &msg->new_setl_fee, &shclog.new_setl_fee );
	dbm_deccopy( &msg->txn_conv_rate, &shclog.txn_conv_rate );
	dbm_deccopy( &msg->ch_new_amount, &shclog.ch_new_amount );
			/* << R007208  */

	/* Ssc - 28Jun00	R004671 integration 7.2 */
	/* Ssc - 17Feb00    SPR # 2007336 */
    strcpy( msg->alpha_response_code, shclog.alpharesponsecode );

	// >>> R027202
	for (i=strlen(msg->alpha_response_code)-1;
			i>=0 && msg->alpha_response_code[i] && msg->alpha_response_code[i] == ' '; i--);
		msg->alpha_response_code[i+1] = '\0';
	// <<< R027202

    msg->card_seqno = shclog.card_seqno;

	msg->branch	= shclog.branch;	/* R007204 */

	msg->txn_start_time = shclog.txn_start_time;
	msg->txn_end_time = shclog.txn_end_time;
	msg->gateway_id = shclog.gateway_id;

	return( hasError );
}

int ShcLog::open_index()
{
	int i;


	if (shclogfd >= 0 )
		return 1;
		

	if((shclogfd = dbm_open("shclog_1", dbmid)) < 0)
	{
		OTraceFatal("F-SHCLOG-5018: Insert: Unable to open shclog_1 index: %d\n", 
						dbm_errno);
		return(-1);
	}
	if(shclogfd_refnum == -1)
		if((shclogfd_refnum = dbm_open("shclog_4", dbmid)) < 0)
		{
			OTraceFatal("F-SHCLOG-5074: Insert: Unable to open shclog_4 index: %d\n", 
							dbm_errno);
			return(-1);
		}
	if(shclogfd_logID == -1)
		if((shclogfd_logID = dbm_open("shclog_5", dbmid)) < 0)
		{
			OTraceFatal("F-SHCLOG-5075: Insert: Unable to open shclog_5 index: %d\n", 
							dbm_errno);
			return(-1);
		}
	if( shcloginsertfd < 0 )
	{
		if( (shcloginsertfd = dbm_open("shclog_1", dbmid)) < 0 )
		{
			OTraceFatal("F-SHC-032001:   Unable to open shclog_1 index: %d\n", dbm_errno);
			return( -1 );
		}
	}

	if( shclogreqinsertfd < 0 )
	{
		if( (shclogreqinsertfd = dbm_open("shclog_req_1", dbmid)) < 0 )
		{
			OTraceFatal("F-SHC-032001:   Unable to open shclog_1 index: %d\n", dbm_errno);
			return( -1 );
		}
	}
	if( shclogreqfd < 0 )
	{
		if( (shclogreqfd = dbm_open("shclog_req_1", dbmid)) < 0 )
		{
			OTraceFatal("F-SHC-032001:   Unable to open shclog_1 index: %d\n", dbm_errno);
			return( -1 );
		}
	}

	if(shclogreqfd_logID == -1)
		if((shclogreqfd_logID = dbm_open("shclog_req_3", dbmid)) < 0)
		{
			OTraceFatal("F-SHCLOG-5075: Insert: Unable to open shclog_5 index: %d\n", 
							dbm_errno);
			return(-1);
		}
	
	if(shclogreqfd_refnum == -1)
		if((shclogreqfd_refnum = dbm_open("shclog_req_2", dbmid)) < 0)
		{
			OTraceFatal("F-SHCLOG-5074: Insert: Unable to open shclog_4 index: %d\n", 
							dbm_errno);
			return(-1);
		}

	return(0);
}

int ShcLog::insert_transaction(int resp_msg) /* 2007336 new parameter for chip txn */
{
	/*
	 *	Insert whatever is in the shclog structure into the database
	 */

	int curfd = 0;

	if (shclogfd < 0)
		open_index();

    struct timeb tmpTime;
    ftime(&tmpTime);

	if (resp_msg)
	{
		curfd = shcloginsertfd;
	}
	else
	{
		curfd = shclogreqinsertfd;
	}

	if(dbm_suppress_dupkey_errmsg(curfd, true) < 0)
		OTraceInfo("I-SHC-032010: Failed in suppressing dupkey error msg");

	if(dbm_insert(curfd, (char *)&shclog, 0) < 0)
	{
		if(dbm_errno == DBME_DUPLICATE_KEY)
			OTraceInfo("I-SHC-032011: Duplicate key, unable to insert record for m%04d/t%06ld\n",
				shclog.msgtype, shclog.trace);
		else
		{
			OTraceFatal("F-SHC-032002:   Unable to insert record (%d) for m%04d/t%06ld\n",
				dbm_errno, shclog.msgtype, shclog.trace);

			//The response time of operators for this kind of error is long,shc to kill itself when faced with such errors

			if(dbm_errno == EBADF)
			{
				OTraceFatal("F-SHC-032003:  Shc needs to kill itself for the above DBM error.. curfd [%d]\n", curfd);
				kill(getpid(),1);
			}
			else
				OTraceFatal("F-SHC-032004:  shc DOES NOT need to kill itself for this DBM error.. curfd [%d]\n", curfd);	
		}	

		if(dbm_suppress_dupkey_errmsg(curfd, false) < 0)
			OTraceInfo("I-SHC-032012: Failed in removing dupkey error msg suppress");

		return(-1);
	}

	if(dbm_suppress_dupkey_errmsg(curfd, false) < 0)
		OTraceInfo("I-SHC-032013: Failed in removing dupkey error msg suppress");
	
	if (!shclogSkipGenlog)
		shcGenericLogObj->insert();		//	R015826
	
	struct timeb afterTime;
    ftime(&afterTime);

	OTraceInfo("I-SHC-5072:insert cost[%ld]\n", 
		(afterTime.time-tmpTime.time)*1000+afterTime.millitm-tmpTime.millitm);

	OTraceDebug("D-SHCLOG-5026:New record logged for m%04d/t%06ld/id[%s]\n",
			shclog.msgtype, shclog.trace, shclog.chip_index);	

	return(0);
}

int ShcLog::locateTxn( ShcHeader *logHeader, int flag )
{
	ShcmsgHeader *header = (ShcmsgHeader *)logHeader;

	struct ShcmsgWithSegment	oReqMsg;
	int ret = locateTxn( header, &(oReqMsg.msg), NULL, flag);
	
	if( ret >= 0 )
		header->allocateAndCopyReqMsg( &(oReqMsg.msg) );
	
	return ret;
}


int ShcLog::locateTxn( ShcmsgHeader *header, struct shcmsg *oldmsg, char *prefix, int flag)
{
	/*
	 *	Locate the transaction as named by the key fields in 'msg'
	 */
	struct ShcmsgWithSegment	omsg;
	char	xbuf[16385] = {0};
	int		ret;
	int		tmpret = -1;	//	R018579
	int		fd[2];
	struct shc_data	*shc_data_ptr;	/* R001319 For looking up device_cap */
	int	internalrev;	/* R001319 internal reversal indicator */
	int	device_cap;	/* R001319 Device_cap from shclog */
	long	lSaveTrace; /* R006247 */
	int i;

	//	>>>	R027559
	struct shclog tmpShclog; 
	bool TimeoutFlag, DeclineFlag;
	//	<<<	R027559

	dbm_errno = 0;
	/* R002017 */
    if ( !use_log(header) )
        return -1;

	if (shclogfd < 0)
		open_index();

	if( oldmsg == NULL )
	{
		oldmsg = &(omsg.msg);
		memset(&omsg, 0, sizeof(omsg));
	}

	if (locate_for_repeat && shcApp->acquirerShcParamsList && shcApp->acquirerShcParamsList->GetBool((char *)"shc.repeatLookUpSkipReq"))
	{
		flag &= ~IST_SHCLOG_FLAG_LOCATE_REQ;	//Don't locate request
		flag |= IST_SHCLOG_FLAG_LOCATE_RESP;
	}

	memset(shclog.seg_req,0, sizeof(shclog.seg_req));
	memset(shclog.seg_resp,0, sizeof(shclog.seg_resp));
	/*	14Apr93....
	*	Check if any one of the index value is null or not
	*	If true, read transaction base on the refnum.
	*/

	OTraceDebug("D-SHCLOG-5027:  Locate transaction\n");
	OTraceDebug("D-SHCLOG-5027: %04d\n", header->msg.msgtype);

	/* R001319 Identify whether the message is an internal reversal */
	internalrev = header->msg.device_cap & SH_DEVCAP_INTERNALREV;
	/* End R001319 */

	if (((flag  & IST_SHCLOG_FLAG_LOCATE_REQ  && flag & IST_SHCLOG_FLAG_LOCATE_RESP)) ||
		(!(flag & IST_SHCLOG_FLAG_LOCATE_REQ) && !(flag & IST_SHCLOG_FLAG_LOCATE_RESP)) )
	{
		fd[0] = shclogfd;
		fd[1] = shclogreqfd;
		OTraceDebug("D-SHCLOG-5104:Search RESP/REQ\n");
	}
	else if (flag & IST_SHCLOG_FLAG_LOCATE_REQ)
	{
		fd[0] = shclogreqfd;
		fd[1] = -1;
		OTraceDebug("D-SHCLOG-5105:Search REQ\n");
	}
	else if (flag & IST_SHCLOG_FLAG_LOCATE_RESP)
	{
		fd[0] = shclogfd;
		fd[1] = -1;
		OTraceDebug("D-SHCLOG-5106:Search RESP\n");
	}

	for (i = 0; i < 2 && fd[i] != -1; i++)
	//for( i=firstIndex(); isValidIndex(i); i = nextIndex(i))
	{
	    /*
	     * R001835
	     */
	    if(header->issShcBin && header->issShcBin->isDynamicSQL())	
		{
																/* R006247 - begin */
			/*--- save original trace ---*/
			lSaveTrace = header->msg.trace;
	
			/*--- change trace, with shc_makekey, to get original trx in shclog ---*/
			header->msg.trace =  shcApp->shcmsgHelperObj->shcMakeKeyLog(header);
																/* R006247 - end */
			
	
			/* R001074 > */
	
																/* R006247 - begin */
			ret = shcsql_find(header, xbuf, prefix);
	
			/*--- recover the original trace of the msg, saved before ---*/
			header->msg.trace = lSaveTrace;
	
			if( ret >= 0 )										/* R006247 - end */
			{
				// R027170 >>>>
				char *pan_ptr = strstr(xbuf,header->msg.pan);
				char xbuf1[256], *ptr1;
				if (pan_ptr)
				{
					//mask the clear pan
					if ((pan_ptr-xbuf) <= sizeof(xbuf1))
						memcpy(xbuf1,xbuf,(pan_ptr-xbuf));
					ptr1 = xbuf1 + (pan_ptr-xbuf);	
					snprintf(ptr1,(sizeof(xbuf1)-(pan_ptr-xbuf)),"%s",shc_maskpan(header->msg.pan));
					pan_ptr += strlen(header->msg.pan);
					snprintf(xbuf1+strlen(xbuf1),sizeof(xbuf1)-strlen(xbuf1), "%s",pan_ptr);
					OTraceDebug("D-SHCLOG-5028:   Sql. stmt: '%s'\n",xbuf1);
				}
				else
					OTraceDebug("D-SHCLOG-5028:   Sql. stmt: '%s'\n", xbuf);
				// <<<< R027170
	
				if( dbm_selectfd(fd[i], xbuf) >= 0 )
				{
	
					/* R004165 Change the code for R001319 so that the internal */
					/*         reversal flag is only used for 400 messages. */
	
					/* R001319 Change this to find a match in device_cap */
					shc_data_ptr = (struct shc_data *)shclog.shc_data_buffer;
					while(dbm_fetchfd(fd[i], (char *)&shclog) >= 0)
					{
	
						/* R004207 Clean up the following if statement. */
						if(header->msg.msgtype / 100 != 4)
						/* End R004207 */
						{
							fill_message(oldmsg);
							shclogLocateFd = fd[i];
							//	>>>	R018579
							if( header->isrepeat() && (shclog.respcode != SHC_RC_Approved))
							{
								tmpret = ret;
								continue;
							}
							//	<<<	R018579
							//rewind(); //IST_S770SP5-146 
							return( 0 );
						}
						/* End R004165 */
	
						device_cap = shclog.device_cap;
	
						/* R004207 Clean up debug messages. */
						OTraceDebug("D-SHCLOG-5029:  Verify the internal reversal flag.\n");
						OTraceDebug("D-SHCLOG-5029: that SHC wants to locate has the internal reversal flag %s.\n", internalrev? "ON" : "OFF");
						OTraceDebug("D-SHCLOG-5029: that SHC got has the internal reversal flag %s.\n", (device_cap & SH_DEVCAP_INTERNALREV)? "ON" : "OFF");
						/* End R004207 */
	
						if(internalrev == (device_cap & SH_DEVCAP_INTERNALREV))
						{
	
							/* R004207 Clean up debug messages. */
							OTraceInfo("I-SHCLOG-5030:  Internal reversal flag matches.\n");
							/* End R004207 */
	
							fill_message(oldmsg);
							shclogLocateFd = fd[i];
							//	>>>	R018579
							if( header->isrepeat() && (shclog.respcode != SHC_RC_Approved))
							{
								tmpret = ret;
								continue;
							}
							//	<<<	R018579

							//rewind(); //IST_S770SP5-146 
							return( 0 );
						}
	
						/* R004207 Clean up debug messages. */
						OTraceInfo("I-SHCLOG-5031: Internal reversal flag does not match. Fetch the next record.\n");
						/* End R004207 */
	
					}
					//	>>>	R018579
					if(tmpret >= 0)		//	for repeat msg
					{

						//rewind(); //IST_S770SP5-146 
						return( 0 );
					}
					//	<<<	R018579
					ret = -1;
					/* End R001319 */
				}
	
				OTraceError("E-SHC-032003:   locate_transaction() Unable to select using Dynamic SQL \n");
				OTraceError("E-SHC-032004:    Using default select statement \n");
			}
			/* R001074 < */
		} /* R001835 */
	}/* End of for loop */
	
	if (flag & IST_SHCLOG_FLAG_USE_CHIP_INDEX)
	{
		return locateTxnChipIndex(header, oldmsg, flag);
	}

	int locate_orig_using_ref_pan = 0;
	if(shcApp && shcApp->acquirerShcParamsList && shcApp->acquirerShcParamsList->GetBool((char *)"shc.locate_orig_using_ref_pan"))
	{
		locate_orig_using_ref_pan = 1;
	}

	if( (header->msg.local_time <= 0 && header->msg.local_date <= 0 )|| useRefnumToLocate || locate_orig_using_ref_pan && (!header->isrepeat()))
	{
		if(strlen(header->msg.refnum) > 0)
		{
			OTraceDebug("D-SHCLOG-5034:shc_log.c(%d)locate tx by refnum\n",__LINE__);
			if( bindRefNumLocate)
			{
				if( locateTxnRefnum_xt(header, oldmsg) >= 0 )
					return( 0 );
			}
			else
			{
				if( locateTxnRefnum(header, oldmsg) >= 0 )
					return( 0 );
			}
		}
	}

	int recFound = 0;
	int tmpfd = 0;

	for (i = 0; i < 2 && fd[i] != -1 && !recFound; i++)
	{	
		/*
		 *	Fill in the index values
		 */
		TimeoutFlag = DeclineFlag = false;	//	---	R027559

		OTraceInfo("I-SHCLOG-5064:i:%d fd:%d\n", i, fd[i]);	
		shclog.trace	  =  shcApp->shcmsgHelperObj->shcMakeKeyLog(header);

		if(((header->msg.formatter_devcap & SH_FORMATDEVCAP_ADVICE_TIMEOUT) || (header->msg.device_cap & SH_DEVCAP_SET_CAPDATE)) &&
                        (header->msg.trantime!=0) && (shcIsAdvice(header)) )
                {
                        shclog.local_time = header->msg.trantime;
                }
                else
                {
                        shclog.local_time = header->msg.local_time;
                }

		shclog.local_date = header->msg.local_date;
		shclog.pcode = header->msg.pcode;
	
		memcpy(shclog.termid, header->msg.termid, sizeof(shclog.termid));
		memcpy(shclog.pan, header->msg.pan, sizeof(shclog.pan));
		memcpy(shclog.acquirer, header->msg.acquirer, sizeof(shclog.acquirer));
	
		OTraceDebug("D-SHCLOG-5035:   Search for t(%ld)ld(%ld)lt(%ld)term(%s)p(%s)a(%s)pc(%06d)\n",
				shclog.trace, shclog.local_date, shclog.local_time, shclog.termid,
				shcApp->shcHelperObj->shc_maskpan(shclog.pan),shclog.acquirer, shclog.pcode);		//	---	R021024
	
		/* R004207 Remove the dbm_rewind because we are not using dbm_read with RSEQ now. */
		/* End R004207 */
	
		/* R004165 Change the code for R001319 so that the internal reversal flag */
		/*         is only used for 400 messages. */
			
		/* R001319 Change this to find a match in device_cap */
		shc_data_ptr = (struct shc_data *)shclog.shc_data_buffer;
	
		/* R004207 "dbm_read" with DBM_RSEQ does not work as specified in the */
		/*			document. Use the method suggested by Alex instead. */
            struct timeb tmpTime;
            ftime(&tmpTime);
            long before_time =  tmpTime.time%1000*1000+tmpTime.millitm;

		for(ret = dbm_read(fd[i], (char *)&shclog, DBM_REQUAL | DBM_RLOCK);
			ret >= 0;
			ret = dbm_fetchfd(fd[i], (char *)&shclog))
		/* End R004207 */
		{
			/* Check if the message type matches */	/* R008689 */
			if (shcApp->shclog_specified_msgtype && (shclog.msgtype/10 != shcApp->shclog_specified_msgtype/10))
				continue;

			//	>>>	R017867
			ICInstId_pure(shclog.txndest, shclog.txndest);

			if (useTxnDestInShclogLocating && header->msg.txnDest[0] && (strcmp(shclog.txndest, header->msg.txnDest) != 0))
			{
				OTraceDebug("D-SHCLOG-5070:txnDest[%s] does not match with original[%s]\n",header->msg.txnDest, shclog.txndest);
				continue;
			}
			//	<<<	R017867

			// >>> R026977
			OTraceDebug("D-SHCLOG-5071: msg->msgtype=[%d] for repeat[%d]\n",
								header->msg.msgtype, locate_for_repeat);
			if( locate_for_repeat && shclog.respcode == SHC_RC_DuplicateTransaction )
				continue;
			//	>>>	R027559
			if(shclog.shcerror == SHC_IE_SafReply || shclog.shcerror == SHC_IE_Duplicate)
				continue;
			//	<<<	R027559
			OTraceDebug("D-SHCLOG-5071: Final Found: log->msgtype[%d],log->respcode[%d]\n",shclog.msgtype,shclog.respcode);
			// <<< R026977

			if(shcIsAdviceResp(header) && (header->msg.auth_devcap & SH_DEVCAP_AUTH_ADVICE_INCREMENT) &&
				(shclog.auth_devcap & SH_DEVCAP_AUTH_ADVICE_INCREMENT) && (header->msg.filler2[0] != '\0') && (shclog.filler2[0] != '\0')
				&& (strncmp(header->msg.filler2,"MULCL",5)==0)&& (strncmp(shclog.filler2,"MULCL",5)==0)){
				//both multi clearing advices
				if(strcmp(header->msg.filler2,shclog.filler2)!=0){
					OTraceInfo("I-SHCLOG-5076: Diff multi-clr msg t%d f2=%s, log f2=%s ID[%s]\n",header->msg.trace,header->msg.filler2,shclog.filler2,shclog.chip_index);
					continue;
				}
			}
			/* R004207 Clean up the if statement a little bit */
			if(header->msg.msgtype / 100 != 4)
			//	>>>	R018579
			{
				//	>>>	R027559
				if( header->isrepeat() )
				{
					if(shclog.shcerror == SHC_IE_Reversed || shclog.shcerror == SHC_IE_Voided ||
																	shclog.shcerror == SHC_IE_Duplicate)
						continue;

					if(shclog.respcode == SHC_RC_IssuerTimeout)
					{
						OTraceDebug("D-SHCLOG-5071.1: Timed-out Txn found...continue searching\n");
						TimeoutFlag=true;
						continue;
					}
					else if (shclog.respcode != SHC_RC_Approved )
					{
						OTraceDebug("D-SHCLOG-5071.2: Declined Txn found...continue searching\n");
						DeclineFlag=true;
						memset(&tmpShclog,0,sizeof(shclog));
						memcpy(&tmpShclog, &shclog, sizeof(tmpShclog));
						tmpfd = fd[i];
						recFound = 1; // Avoid searching in SHCLOG_REQ
						continue;
					}
					recFound = 1;
					shclogLocateFd = fd[i];
					break;
				}
				recFound = 1;
				shclogLocateFd = fd[i];
				break;
				//	<<<	R027559
			}
			//	<<<	R018579
			/* End R004207 */
	
			/* End R004165 */
			device_cap = shclog.device_cap;
	
			/* R004207 Clean up debug messages. */
			OTraceDebug("D-SHCLOG-5036:  Verify the internal reversal flag.\n");
			OTraceDebug("D-SHCLOG-5036:	The message that SHC wants to locate has the internal reversal flag %s.\n", internalrev? "ON" : "OFF");
			OTraceDebug("D-SHCLOG-5036:	The message that SHC got has the internal reversal flag %s.\n", (device_cap & SH_DEVCAP_INTERNALREV)? "ON" : "OFF");
			/* End R004207 */
	
			/* R004207 Remove the useless "else" case */
			if(internalrev == (device_cap & SH_DEVCAP_INTERNALREV))
			{
				OTraceInfo("I-SHCLOG-5037:  Internal reversal flag matches.\n");
				//	>>>	R018579
				//	>>>	R027559
				if( header->isrepeat() )
				{
					if(shclog.shcerror == SHC_IE_Reversed || shclog.shcerror == SHC_IE_Voided ||
																	shclog.shcerror == SHC_IE_Duplicate)
						continue;

					if(shclog.respcode == SHC_RC_IssuerTimeout)
					{
						if (!DeclineFlag)
							TimeoutFlag=true;
						continue;
					}
					else if (shclog.respcode != SHC_RC_Approved)
					{
						DeclineFlag=true;
						memset(&tmpShclog,0,sizeof(shclog));
						memcpy(&tmpShclog, &shclog, sizeof(tmpShclog));
						tmpfd = fd[i];
						continue;
					}
					recFound = 1;
					shclogLocateFd = fd[i];
					break;
				}
				recFound = 1;
				shclogLocateFd = fd[i];
				break;
				//	<<<	R027559
				//	<<<	R018579
			}
			OTraceInfo("I-SHCLOG-5038: Internal reversal flag does not match. Fetch the next record.\n");
			/* End R004207 */
		}
		if (TimeoutFlag || DeclineFlag)
			break;
	}
	/* End R001319 */
	
	//	>>>	R027559
	if (ret < 0) // no approved txn matched so far
	{
		if( shcApp->issuerShcParamsList && shcApp->issuerShcParamsList->GetBool((char *)"shc.ExtPreAuthLookup") )
                {
                        if( locateTxnByExtLookup(header, oldmsg, IST_SHCLOG_FLAG_LOCATE_RESP) >= 0 )
                                return 0;
                }

				if(header->msg.origmsg == SHC_FINREQ)
				{
					char mcCardScheme[4] = {0};
					int locRet = 0;
					if(bindRefNumLocate)
						locRet = locateTxnRefnum_xt(header, oldmsg);
					else
						locRet = locateTxnRefnum(header, oldmsg);

 					if( locRet >= 0 )
					{
						shcApp->shcHelperObj->shc_getCardSchemeFromCardProduct(&mcCardScheme[0], &oldmsg->cardProduct[0], sizeof(mcCardScheme));

						if(((oldmsg->pcode/10000) == SH_ISO_PREAUTHREQ) && (oldmsg->pos_condition_code & SH_POS_COND_REQ_PREAUTH)
			 				&& (strncmp (mcCardScheme, MASTERCARD_CARD_SCHEME, sizeof(MASTERCARD_CARD_SCHEME)) == 0))
						{
							OTraceInfo("I-SHC-032205:  Located Mastercard Orignal Preauth Request with Refnum\n");
 							return( 0 );
						}
					}
				}

		if (DeclineFlag) // matched declined txn found
		{
			OTraceInfo("I-SHC-032005:    result: declined original txn found\n");
			memcpy(&shclog,&tmpShclog,sizeof(shclog));
			shclogLocateFd = tmpfd;
		}
		else if (TimeoutFlag) // timed-out org txn found
		{
			OTraceInfo("I-SHC-032005:    result: timed-out original txn found..send this txn to issuer\n");

			//rewind(); //IST_S770SP5-146 
			return -1;
		}
		else
		{
			// No original txn found
			OTraceInfo("I-SHC-032005:    result: not found\n");

			//rewind(); //IST_S770SP5-146 
			return -1;
		}
	}

	OTraceInfo("I-SHC-032005:    result: found\n");
	//	<<<	R027559
	ICInstId_pure(shclog.txnsrc, shclog.txnsrc);
	ICInstId_pure(shclog.txndest, shclog.txndest);
	fill_message(oldmsg);
	//shclogLocateFd = fd[i];

	//rewind(); //IST_S770SP5-146 
	return( 0 );
}


/*
 * qd 31mar97 Search transaction record by reference number and pan   
 *            
 * Note: This function is used as a backup to search for the record when either
 * 		 local_date or local_time is zero
 */
int ShcLog::locateTxnRefnum(ShcmsgHeader *header, struct shcmsg *oldmsg, int flag)
{
	/*
	 *	Locate the transaction as named by the key fields in 'msg'
	 */
	struct	ShcmsgWithSegment omsg;
	char where[256];
    char where_debug[256];		//	---	R021024
	int	internalrev;	/* R001319 internal reversal indicator */
	int	device_cap;	/* R001319 Device_cap from shclog */
	struct shc_data	*shc_data_ptr;	/* R001319 For looking up device_cap */
	int id_len=0;
	int   fd[2];
	int i;
	int len = 0;
	memset(shclog.seg_req,0, sizeof(shclog.seg_req));
	memset(shclog.seg_resp,0, sizeof(shclog.seg_resp));
	// R027170 >>>>

        char *bp = where;
        snprintf(where,sizeof(where), "refnum = '%12s' and ", header->msg.refnum);
	len = istsafe_strlen(where, sizeof(where));
	bp += len;
        int tkn_ret = generatePanCond(bp, header->msg.pan, &bp);
	if(tkn_ret != 0)
	{
                //if (tkn_ret == Tokenizer::PAN_NOT_FOUND)
                        //return 0;
                //else
                        return -1;
	}

        snprintf(where_debug,sizeof(where_debug), "refnum = '%12s' and pan = <tokenized pan>", header->msg.refnum);

	// <<<< R027170

	/* R002017 */
    if ( !use_log(header) )
        return -1;

	if (shclogfd < 0)
		open_index();

	if(oldmsg == NULL)
	{
		oldmsg = &(omsg.msg);
		memset(&omsg, 0, sizeof(omsg));
	}

									/* R002251 BEGIN */
	if ( shcApp->acquirerShcParamsList && shcApp->acquirerShcParamsList->GetBool((char *)"shc.enable_back_office") ||
		shcApp->issuerShcParamsList && shcApp->issuerShcParamsList->GetBool((char *)"shc.enable_back_office")) 
	{
		long back_office_flags;
		char where2[128];

		back_office_flags = header->msg.shc_devcap & SH_DEVCAP_SHC_BO_MASK;
		if (back_office_flags)
			sprintf(where2," and shc_devcap >= %ld and shc_devcap <= %ld ",
				back_office_flags, back_office_flags+0xffffffL);
		else
			sprintf(where2," and shc_devcap <= %ld ",0xffffffL);
		istsafe_strcat(where, sizeof(where), where2);
	    
	    //	>>>	R021024 
		strcat(where_debug,where2);
		OTraceDebug("D-SHCLOG-5045:where clause after backoffice:%s\n",where_debug);
		//	<<<	R021024	
	}
									/* R002251 END */
	if(header->msg.trace > 0 && !excludeTraceInRefnum)
	{
		char tbuf[50];

   		sprintf(tbuf, " and trace = %d",  shcApp->shcmsgHelperObj->shcMakeKeyLog(header));
		istsafe_strcat(where, sizeof(where), tbuf);
        strcat(where_debug, tbuf);		//	---	R021024
	
	}
    OTraceDebug("D-SHCLOG-5046: Search (refnum) WHERE <%s>\n", where_debug);		//	---	R021024

    // ADD  SHould this be by refnum /// 
	if (((flag  & IST_SHCLOG_FLAG_LOCATE_REQ  && flag & IST_SHCLOG_FLAG_LOCATE_RESP)) ||
		(!(flag & IST_SHCLOG_FLAG_LOCATE_REQ) && !(flag & IST_SHCLOG_FLAG_LOCATE_RESP)) )
	{
		fd[0] = shclogfd;
		fd[1] = shclogreqfd; 
		OTraceDebug("D-SHCLOG-5108:Search RESP/REQ\n");
	}
	else if (flag & IST_SHCLOG_FLAG_LOCATE_REQ)
	{
		fd[0] = shclogreqfd;
		fd[1] = -1; 
		OTraceDebug("D-SHCLOG-5108:Search REQ\n");
	}
	else if (flag & IST_SHCLOG_FLAG_LOCATE_RESP)
	{
		fd[0] = shclogfd;
		fd[1] = -1; 
		OTraceDebug("D-SHCLOG-5109:Search RESP\n");
	}

	for (i = 0; i < 2 && fd[i] != -1; i++)
	{
	    if (dbm_selectfd(fd[i], where) < 0)
	    {
	   		OTraceWarning("W-SHC-032006: refnum: dbm_selectfd fails\n");

			//rewind(); //IST_S770SP5-146 
			return(-1);
	    }	
	
		/* R004165 Change the code for R001319 so that the internal reversal flag */
		/*         is only used for 400 messages. */
	
		/* R001319 Change this to find a match in device_cap */
		internalrev = header->msg.device_cap & SH_DEVCAP_INTERNALREV;
		while(dbm_fetchfd(fd[i], (char *) &shclog) >= 0)
		{
	
			/* Check if the message type matches */	/* R008689 */
			if (shcApp->shclog_specified_msgtype && (shclog.msgtype/10 != shcApp->shclog_specified_msgtype/10))
				continue;

                        /* Check first digit of header and shclog msg type */
                        if ((header->msg.msgtype/100) != (shclog.msgtype/100))
                                continue;

			ICInstId_pure(shclog.txndest, shclog.txndest);

			if (useTxnDestInShclogLocating && header->msg.txnDest[0] && (strcmp(shclog.txndest, header->msg.txnDest) != 0))
			{
				OTraceDebug("D-SHCLOG-5047.2:txnDest[%s] does not match with original[%s]\n",header->msg.txnDest, shclog.txndest);
				continue;
			}

			/* R015140 Check termid field when locating txn using refnum */
			if (header->msg.termid[0] && shclog.termid[0])
			{
				//R031084 Triming Trailing Spaces for Terminal Id
				id_len = strlen(shclog.termid)-1;
				for (; id_len>=0 && shclog.termid[id_len] && shclog.termid[id_len] == ' '; id_len--);
				shclog.termid[id_len+1]='\0';
				id_len = 0;

				char tmp_termid[9];
				strcpy(tmp_termid, header->msg.termid);
				strtrim(tmp_termid, tmp_termid);

				if (strcmp(tmp_termid, shclog.termid)!=0)
				{
					OTraceInfo("I-SHCLOG-5066:termid don't match, in msg[%s], in table[%s]\n", header->msg.termid, shclog.termid);
					continue;
				}
			}
			/* R015140 end */

			// >>> R026977
            OTraceDebug("D-SHCLOG-5047: msg->msgtype=[%d] for repeat[%d]\n",
								header->msg.msgtype, locate_for_repeat);
			if( locate_for_repeat && shclog.respcode == SHC_RC_DuplicateTransaction )
					continue;

			//R028676 >>>
			if(shclog.shcerror == SHC_IE_SafReply || shclog.shcerror == SHC_IE_Duplicate)
			{
				OTraceDebug("D-SHCLOG-5047.1: Ignoring txn with shclog.shcerror[%d]\n",shclog.shcerror);
				continue;
			}
			//<<< R028676

			OTraceDebug("D-SHCLOG-5047: Final Found: log->msgtype[%d],log->respcode[%d]\n",shclog.msgtype,shclog.respcode);
			// <<< R026977

			/* R004207 Clean up the if statement a little bit */
			if(header->msg.msgtype / 100 != 4)
			/* End R004207 */
			{
				OTraceDebug("D-SHCLOG-5048: Found: header->msg.msgtype:%d log->msgtype:%d\n",
						header->msg.msgtype, shclog.msgtype );
				fill_message(oldmsg);
				shclogLocateFd = fd[i];

				//rewind(); //IST_S770SP5-146 
				return 0;
			}
			/* End R004165 */
			shc_data_ptr = (struct shc_data *)shclog.shc_data_buffer;
			device_cap = shclog.device_cap;
	
			/* R004207 Clean up debug messages. */
			OTraceDebug("D-SHCLOG-5049:  Verify the internal reversal flag.\n");
			OTraceDebug("D-SHCLOG-5049:	The message that SHC wants to locate has the internal reversal flag %s.\n", internalrev? "ON" : "OFF");
			OTraceDebug("D-SHCLOG-5049:	The message that SHC got has the internal reversal flag %s.\n", (device_cap & SH_DEVCAP_INTERNALREV)? "ON" : "OFF");
			/* End R004207 */
	
			if(internalrev == (device_cap & SH_DEVCAP_INTERNALREV))
			{
				/* R004207 Clean up debug messages. */
				OTraceDebug("D-SHCLOG-5050:  Internal reversal flag matches.\n");
				OTraceDebug("D-SHCLOG-5050: Found: header->msg.msgtype:%d log->msgtype:%d\n",
							 header->msg.msgtype, shclog.msgtype );
				/* End R004207 */
				
				fill_message(oldmsg);
				shclogLocateFd = fd[i];

				//rewind(); //IST_S770SP5-146 
				return 0;
			}
	
			/* R004207 Clean up debug messages. */
			OTraceDebug("D-SHCLOG-5051: Internal reversal flag does not match. Fetch the next record.\n");
			/* End R004207 */
	
		}
	}
	OTraceWarning("W-SHC-032007: refnum: not found\n");

	//rewind(); //IST_S770SP5-146 
	return(-1);
	/* End R001319 */
}


int ShcLog::locateTxnChipIndex(ShcmsgHeader *header, struct shcmsg *oldmsg, int flag)
{
	/*
	 *	Locate the transaction as named by the key fields in 'msg'
	 */
	struct	ShcmsgWithSegment omsg;
	int ret = 0;
	int i;
	int fd[2];


	/* R002017 */
    if ( !use_log(header) )
        return -1;

	memset(shclog.seg_req,0, sizeof(shclog.seg_req));
	memset(shclog.seg_resp,0, sizeof(shclog.seg_resp));

	if (shclogfd < 0)
		open_index();

	if(oldmsg == NULL)
	{
		oldmsg = &(omsg.msg);
		memset(&omsg, 0, sizeof(omsg));
	}

	if (((flag  & IST_SHCLOG_FLAG_LOCATE_REQ  && flag & IST_SHCLOG_FLAG_LOCATE_RESP)) ||
		(!(flag & IST_SHCLOG_FLAG_LOCATE_REQ) && !(flag & IST_SHCLOG_FLAG_LOCATE_RESP)) )
	{
		fd[0] = shclogfd_logID;
		fd[1] = shclogreqfd_logID; 
		OTraceDebug("D-SHCLOG-5110:Search RESP/REQ\n");
	}
	else if (flag & IST_SHCLOG_FLAG_LOCATE_REQ)
	{
		fd[0] = shclogreqfd_logID;
		fd[1] = -1; 
		OTraceDebug("D-SHCLOG-5111:Search REQ\n");
	}
	else if (flag & IST_SHCLOG_FLAG_LOCATE_RESP)
	{
		fd[0] = shclogfd_logID;
		fd[1] = -1; 
		OTraceDebug("D-SHCLOG-5112:Search RESP\n");
	}

	try
	{
	
		for (i = 0; i < 2 && fd[i] != -1; i++)
		{
			strcpy(shclog.chip_index, header->msg.shclog_id);
			OTraceDebug("D-SHCLOG-5075: Search for chip_index(%s)\n", header->msg.shclog_id);
			int rc = 0, rec =0, skipShcLogReqFd = 0;

			if(!_dbConn1)
				_dbConn1= new DBMConn(dbm_dbconn);

			if(fd[i] == shclogfd_logID)	
			{
				if(!_smtShcLogAllCI)
				{
					_smtShcLogAllCI = _dbConn1->getStmt();
					rc = prepareShcLogAll(_smtShcLogAllCI, 5 );
					if ( rc != 0 )
					{
						return -1;
					}

				}
				_smtShcLogAllCI->execute();
				rec = _smtShcLogAllCI->fetch();
				_smtShcLogAllCI->close();

				OTraceDebug("D-SHCLOG-5076: Found SHCLOG: header->msg.msgtype:%d shclog->msgtype:%d rc[%d]\n",
						header->msg.msgtype, shclog.msgtype , rec );
				skipShcLogReqFd = 1;

			}
			if(fd[i] ==shclogreqfd_logID && !skipShcLogReqFd)
			{
				if(!_smtShcLogReqAllCI)
				{
					_smtShcLogReqAllCI = _dbConn1->getStmt();
					rc = prepareShcLogAll(_smtShcLogReqAllCI, 6 );
					if ( rc != 0 )
					{
						return -1;
					}
				}
				_smtShcLogReqAllCI->execute();
				rec = _smtShcLogReqAllCI->fetch();
				_smtShcLogReqAllCI->close();
				OTraceDebug("D-SHCLOG-5076: Found REQ : header->msg.msgtype:%d shclog->msgtype:%d rec[%d]\n",
						header->msg.msgtype, shclog.msgtype,rec );
			}
			if (rec == DBM_SUCCESS)
			{
				OTraceDebug("D-SHCLOG-5076: Found: header->msg.msgtype:%d log->msgtype:%d\n",
						header->msg.msgtype, shclog.msgtype );
				fill_message(oldmsg);
			        shclogLocateFd = fd[i];
				return 0;
			}
		}
	}
	catch(DBMException e)
	{
		OTraceError("E-SHC-5079:DB ERR:%s, sql state:%s\n", e.getErrMsg().data(), e.getSQLState().data());
	}

	OTraceInfo("I-SHC-5077: chip_index(%s) not found\n", shclog.chip_index);

	//rewind(); //IST_S770SP5-146 
	return(-1);
	/* End R001319 */
}

int ShcLog::update_transaction (int log_chip)/* 2007336 new parameter for chip txn */
{
	/*
	 *	Write the current transaction to the database
	 */
	/* 2007336 VSDC enhancement */
	if (shclogfd < 0)
		open_index();



	OTraceDebug("D-SHCLOG-5055:   Update record logged for m%04d/p%06d\n",
			 shclog.msgtype, shclog.pcode);

    struct timeb tmpTime;
    ftime(&tmpTime);

	if(dbm_write(shclogLocateFd, (char *)&shclog, 0) < 0)
	{
		OTraceFatal("F-SHC-032008: Error: %d on write\n", dbm_errno);
		return(-1);
	}
	struct timeb afterTime;
    ftime(&afterTime);

	OTraceInfo("I-SHC-5073:update cost[%ld]\n",
		(afterTime.time-tmpTime.time)*1000+afterTime.millitm-tmpTime.millitm);

	if( _shclog_isupdateReq &&  (!shclogSkipGenlog))
			shcGenericLogObj->insert();
	//	<<<	R015826

	return(0);
}

/*
 * R002017.
 * Invalid transferee bank causes the core dump.
 */
int ShcLog::use_log(ShcmsgHeader *header)
{
int		use_log;

	use_log = 1;
	if ( !shcIsIBFT(header) )
	{
		if ( header->acqBinValid() && header->issBinValid() )
			use_log = _shcHeaderNoIBFTUseLog(header);
	}
	else if ( header->transfereeBinValid())
	{
		use_log = _shcHeaderIBFTUseLog(header);
	}
	return(use_log);
}

int ShcLog::generate_shclog_id(struct shcmsg *msg)
{ 

	mb_getUmi(msg->shclog_id, sizeof(msg->shclog_id));
	strcpy( shclog.chip_index,  msg->shclog_id); //R028105
	return 0;
}

int ShcLog::locateEuropayTxn( ShcmsgHeader *header, struct shcmsg *omsg, int flagCheckDup, int flag )
{
	struct ShcmsgWithSegment	oldmsg;
	char 	strBuf[200] = { 0 };
	char    *ptrBuf = strBuf;
	int i;
	int fd[2];
	
	if( omsg == NULL )
	{
		omsg = &(oldmsg.msg);
		memset(&oldmsg, 0, sizeof(oldmsg));
	}


	memset(shclog.seg_req,0, sizeof(shclog.seg_req));
	memset(shclog.seg_resp,0, sizeof(shclog.seg_resp));
	if (shclogfd < 0)
		open_index();

    ptrBuf += sprintf(strBuf,"local_date='%02d/%02d/%04d' and trace=%d"
    	, header->msg.local_date / 100 % 100, header->msg.local_date % 100
    	, header->msg.local_date / 10000,  shcApp->shcmsgHelperObj->shcMakeKeyLog(header));
    
	if( header->msg.F_ID[0] )
		ptrBuf += sprintf( ptrBuf, " and f_id='%s'", header->msg.F_ID );

	if( header->msg.member_ID[0] )
		ptrBuf += sprintf( ptrBuf, " and member_id='%s'", header->msg.member_ID );

	OTraceDebug("D-SHCLOG-5057: acq:[%s], iss:[%s]; Where clause = [%s]\n" \
				, header->msg.acquirer, header->msg.issuer, strBuf);

	if (((flag  & IST_SHCLOG_FLAG_LOCATE_REQ  && flag & IST_SHCLOG_FLAG_LOCATE_RESP)) ||
		(!(flag & IST_SHCLOG_FLAG_LOCATE_REQ) && !(flag & IST_SHCLOG_FLAG_LOCATE_RESP)) )
	{
		fd[0] = shclogfd;
		fd[1] = shclogreqfd;
		OTraceDebug("D-SHCLOG-5113:Search RESP/REQ\n");
	}
	else if (flag & IST_SHCLOG_FLAG_LOCATE_REQ)
	{
		fd[0] = shclogreqfd;
		fd[1] = -1;
		OTraceDebug("D-SHCLOG-5114:Search REQ\n");
	}
	else if (flag & IST_SHCLOG_FLAG_LOCATE_RESP)
	{
		fd[0] = shclogfd;
		fd[1] = -1;
		OTraceDebug("D-SHCLOG-5115:Search RESP\n");
	}

	
	for (i = 0; i < 2 && fd[i] != -1; i++)
	{
		if ( dbm_selectfd( fd[i], strBuf ) < 0 )
		{
			OTraceError("E-SHCLOG-5058: Select failed...[%s]\n", strBuf);
	
			return (False);
		}
	
		if ( dbm_fetchfd( fd[i], ( char * )&shclog ) < 0 )
		{
		  OTraceDebug("D-SHCLOG-5061: No original 100/110 msg being found!\n"); 
		  return( False );
		}
		
		if( flagCheckDup==True )	/* Just check if txn is duplicated for 100 msg */
			return( True );
			
		do
		{
			int tmpMsgType = shclog.msgtype/100;

			if( (tmpMsgType ==1) || (tmpMsgType==2) )
			{
				OTraceDebug("D-SHCLOG-5060: Found original message[%04d].\n", shclog.msgtype );
					
				fill_message(omsg);
				shclogLocateFd = fd[i];
				return( True );
			}
			
		}while( dbm_fetchfd( fd[i], (char *)&shclog ) == 0 );
	}
	OTraceDebug("D-SHCLOG-5061: No original 100/110 msg being found!\n");
		
	return( False );
}

/* <-- R005338	(18Dec00)	*/
int ShcLog::rewind()
{
	if (shclogfd < 0)
		open_index();

	
	if (shclogfd >= 0)
		dbm_rewind(shclogfd);
	if (shclogfd_refnum >=  0)
		dbm_rewind(shclogfd_refnum);
	if (shclogfd_logID >= 0) //R031038
		dbm_rewind(shclogfd_logID);
	if (shcloginsertfd >= 0)
		dbm_rewind(shcloginsertfd);

	if (shclogreqfd >= 0)
		dbm_rewind(shclogreqfd);
	if (shclogreqfd_refnum >=  0)
		dbm_rewind(shclogreqfd_refnum);
	if (shclogreqfd_logID >= 0) //R031038
		dbm_rewind(shclogreqfd_logID);
	if (shclogreqinsertfd >= 0)
		dbm_rewind(shclogreqinsertfd);

	return 0;
}

ShcLog::ShcLog()
{
	
	shclogfd = -1;
	shclogfd_refnum = -1;
	shclogfd_logID = -1;
	shcloginsertfd = -1;

	shclogreqfd = -1;
	shclogreqfd_refnum = -1;
	shclogreqfd_logID = -1;
	shclogreqinsertfd = -1;

	_dbConn = NULL;
	_updateVoid = NULL;;
	_updateReversal = NULL;
	_updateFinCapture = NULL;
	_updateRespcode = NULL;

	_dbConn1 = NULL;
	_smtShcLogAll = NULL;
	_smtShcLogTrace = NULL;
	_smtShcLogBkOff = NULL;
	_smtShcLog = NULL;
	_smtShcLogReqAll = NULL;
	_smtShcLogReqTrace = NULL;
	_smtShcLogReqBkOff = NULL;
	_smtShcLogReq = NULL;
	_smtShcLogReqAllCI = NULL;
	_smtShcLogAllCI = NULL;

    _smtShcLogAllP = NULL;
    _smtShcLogTraceP = NULL;
    _smtShcLogBkOffP = NULL;
    _smtShcLogP = NULL;
    _smtShcLogReqAllP = NULL;
    _smtShcLogReqTraceP = NULL;
    _smtShcLogReqBkOffP = NULL;
    _smtShcLogReqP = NULL;

	memset(&shclog, 0, sizeof(shclog));
	return;
}

int ShcLog::updateRespcode( ShcmsgHeader *header )
{
	int len;

	OTraceDebug("D-SHC-032009: Updating respcode for trace %ld, termid %s to %d\n",
		header->msg.trace, header->msg.termid, header->msg.respcode);
	
	if(locateTxn(header, NULL, NULL) < 0 )
		return( -1 );

	shclog.respcode = header->msg.respcode;

	initDB();
	if (prepareUpdateRespcode() < 0)
	{
		return -1;
	}

	shclog.respcode = header->msg.respcode;

	struct timeb tmpTime;
    ftime(&tmpTime);

	try
	{
		_updateRespcode->execute();
		_updateRespcode->close();
	}
	catch( const DBMException& e )
	{
	 	handleDBMException( _dbConn, _updateRespcode, e );
		OTraceError
		(
		   	"E-SHCLOG-5116:caught exception in update respcode "
		   	"native error=%d, sqlstate=%.5s, msg=%s\n",
			e.getNativeError(), e.getSQLState().data(), e.getErrMsg().data()
		);
		return -1;
	}		

	struct timeb afterTime;
    ftime(&afterTime);

	OTraceInfo("I-SHC-5117:update respcode cost[%ld]\n",
		(afterTime.time-tmpTime.time)*1000+afterTime.millitm-tmpTime.millitm);
	return 1;
}


ShcLog::~ShcLog()
{
}

int ShcLog::initDB()
{
 	if(!_dbConn)
		_dbConn= new DBMConn(dbm_dbconn);

	 return 1;
}


int ShcLog::doUpdateVoid(ShcmsgHeader *header)
{
	OTraceDebug("D-SHCLOG-5119:doUpdateVoid [%s]\n", header->msg.shclog_id); 

	initDB();
	if (prepareUpdateVoid() < 0)
	{
		return -1;
	}

	// Set Fileds to update
	shclog.shcerror	= header->msg.shcerror;
	shclog.site_id =  header->msg.site_id;
	strcpy(shclog.chip_index, header->msg.shclog_id);

	struct timeb tmpTime;
    ftime(&tmpTime);

	try
	{
		_updateVoid->execute();
		_updateVoid->close();
	}
	catch( const DBMException& e )
	{
	 	handleDBMException( _dbConn, _updateVoid, e );
		OTraceError
		(
		   	"E-SHCLOG-5120:caught exception in update void "
		   	"native error=%d, sqlstate=%.5s, msg=%s\n",
			e.getNativeError(), e.getSQLState().data(), e.getErrMsg().data()
		);
		return -1;
	}		
	
	struct timeb afterTime;
    ftime(&afterTime);

	OTraceInfo("I-SHC-5121:update void cost[%ld]\n",
		(afterTime.time-tmpTime.time)*1000+afterTime.millitm-tmpTime.millitm);

	if( _shclog_isupdateReq &&  (!shclogSkipGenlog))
			shcGenericLogObj->insert();
	//	<<<	R015826

	return(0);
}

int ShcLog::doUpdateReversal(ShcmsgHeader *header)
{

	OTraceDebug("D-SHCLOG-5122:doUpdateReversal [%s]\n", header->msg.shclog_id); 

	initDB();
	if (prepareUpdateReversal() < 0)
	{
		return -1;
	}

	// Update the following Fields
	//	revcode
	//	respcode
	//	aval_balance
	//  new_setl_amount	
	//	new_amount
	//	new_fee
	//	ch_new_amount
	//	new_setl_fee

	shclog.revcode 	= header->msg.revcode ;
	shclog.respcode 	= header->msg.respcode ;
	dbm_dbltodec( &shclog.aval_balance, 	dbm_dectodbl(&header->msg.aval_balance) );
	dbm_dbltodec( &shclog.new_setl_amount, 	dbm_dectodbl(&header->msg.new_setl_amount) );
	dbm_dbltodec( &shclog.new_amount, 	dbm_dectodbl(&header->msg.new_amount) );
	dbm_dbltodec( &shclog.new_fee,          dbm_dectodbl(&header->msg.new_fee) );
	dbm_dbltodec( &shclog.ch_new_amount, 	dbm_dectodbl(&header->msg.ch_new_amount) );
	dbm_dbltodec( &shclog.new_setl_fee,     dbm_dectodbl(&header->msg.new_setl_fee) );
	shclog.shcerror	= header->msg.shcerror;

	shclog.site_id =  header->msg.site_id;
	strcpy(shclog.chip_index, header->msg.shclog_id);

	struct timeb tmpTime;
    ftime(&tmpTime);

	try
	{
		_updateReversal->execute();
		_updateReversal->close();
	}
	catch( const DBMException& e )
	{
	 	handleDBMException( _dbConn, _updateReversal, e );
		OTraceError
		(
		   	"E-SHCLOG-5123:caught exception in update reversal "
		   	"native error=%d, sqlstate=%.5s, msg=%s\n",
			e.getNativeError(), e.getSQLState().data(), e.getErrMsg().data()
		);
		return -1;
	}		
	
	struct timeb afterTime;
    ftime(&afterTime);

	OTraceInfo("I-SHC-5124:update reversal cost[%ld]\n",
		(afterTime.time-tmpTime.time)*1000+afterTime.millitm-tmpTime.millitm);

	return 1;
}

int ShcLog::doUpdateFinCapture(ShcmsgHeader *header)
{

	OTraceDebug("D-SHCLOG-5125:doUpdateFinCapture [%s]\n", header->msg.shclog_id); 
	initDB();

	if (prepareUpdateFinCapture() < 0)
	{
		return -1;
	}

	// For Fin Capture Update  batch_id  and formatter_devcap
	shclog.batch_id	= header->msg.batch_id;
	shclog.formatter_devcap	= header->msg.formatter_devcap ; 

	shclog.site_id =  header->msg.site_id;
	strcpy(shclog.chip_index, header->msg.shclog_id);

	struct timeb tmpTime;
    ftime(&tmpTime);

	try
	{
		_updateFinCapture->execute();
		_updateFinCapture->close();
	}
	catch( const DBMException& e )
	{
	 	handleDBMException( _dbConn, _updateFinCapture, e );
		OTraceError
		(
		   	"E-SHCLOG-5126:caught exception in update fincapture "
		   	"native error=%d, sqlstate=%.5s, msg=%s\n",
			e.getNativeError(), e.getSQLState().data(), e.getErrMsg().data()
		);
		return -1;
	}		
	
	struct timeb afterTime;
    ftime(&afterTime);

	OTraceInfo("I-SHC-5127:update fincapture  cost[%ld]\n",
		(afterTime.time-tmpTime.time)*1000+afterTime.millitm-tmpTime.millitm);

	return 1;
}

int ShcLog::prepareUpdateRespcode()
{

	 if (!_updateRespcode)
	 {
	    int i = 1;;	
		 _updateRespcode = _dbConn->getStmt();

		try
		{
			//  For Void Update shcerror 
			_updateRespcode->prepare ("update shclog  set respcode = ? where site_id = ? AND chip_index = ?");

		    _updateRespcode->bindParam(i++, DBM_LONGTYPE, &shclog.respcode, sizeof(shclog.respcode), NULL);

			_updateRespcode->bindParam(i++, DBM_INTTYPE, &shclog.site_id, sizeof(shclog.site_id), NULL);
			_updateRespcode->bindParam(i++, DBM_STRINGTYPE, shclog.chip_index, sizeof(shclog.chip_index), NULL);

		 }
		 catch( const DBMException& e )
		 {
		 	handleDBMException( _dbConn, _updateRespcode, e );
			OTraceError
			(
			   	"E-SHCLOG-5128:caught exception in prepare update response code "
			   	"native error=%d, sqlstate=%.5s, msg=%s\n",
				e.getNativeError(), e.getSQLState().data(), e.getErrMsg().data()
			);
			return -1;
		}		
	}

	return 1;
}

int ShcLog::prepareUpdateVoid()
{

	 if (!_updateVoid)
	 {
	    int i = 1;;	
		 _updateVoid = _dbConn->getStmt();

		try
		{
			//  For Void Update shcerror 
			_updateVoid->prepare ("update shclog  set shcerror = ? where site_id = ? AND chip_index = ?");

		    _updateVoid->bindParam(i++, DBM_LONGTYPE, &shclog.shcerror, sizeof(shclog.shcerror), NULL);

			_updateVoid->bindParam(i++, DBM_INTTYPE, &shclog.site_id, sizeof(shclog.site_id), NULL);
			_updateVoid->bindParam(i++, DBM_STRINGTYPE, shclog.chip_index, sizeof(shclog.chip_index), NULL);

		 }
		 catch( const DBMException& e )
		 {
		 	handleDBMException( _dbConn, _updateVoid, e );
			OTraceError
			(
			   	"E-SHCLOG-5129:caught exception in prepare update void "
			   	"native error=%d, sqlstate=%.5s, msg=%s\n",
				e.getNativeError(), e.getSQLState().data(), e.getErrMsg().data()
			);
			return -1;
		}		
	}

	return 1;
}


int ShcLog::prepareUpdateReversal()
{

	if (!_updateReversal)
	{
	    int i = 1;;	
		_updateReversal = _dbConn->getStmt();

		try
		{
			// Update the following Fields
			//	revcode
			//	respcode
			//	aval_balance
			//  new_setl_amount	
			//	new_amount
			//	new_fee
			//	ch_new_amount
			//	new_setl_fee

			_updateReversal->prepare ("update shclog set "
									  "revcode =  ?, "
									  "respcode = ?, "
									  "aval_balance = ?, "
									  "new_setl_amount = ?, "
									  "new_amount = ?, "
									  "new_fee = ?, "
									  "ch_new_amount = ?, "
									  "new_setl_fee = ?, "
									  "shcerror = ? "
									  "where site_id = ? AND chip_index  = ?");
		    
			_updateReversal->bindParam(i++, DBM_LONGTYPE, &shclog.revcode, sizeof(shclog.revcode), NULL);
			_updateReversal->bindParam(i++, DBM_LONGTYPE, &shclog.respcode, sizeof(shclog.respcode), NULL);
			_updateReversal->bindParam(i++, DBM_DECIMALTYPE, &shclog.aval_balance, sizeof(shclog.aval_balance), NULL); 
			_updateReversal->bindParam(i++, DBM_DECIMALTYPE, &shclog.new_setl_amount, sizeof(shclog.new_setl_amount), NULL);
			_updateReversal->bindParam(i++, DBM_DECIMALTYPE, &shclog.new_amount, sizeof(shclog.new_amount), NULL);
			_updateReversal->bindParam(i++, DBM_DECIMALTYPE, &shclog.new_fee, sizeof(shclog.new_fee), NULL);
			_updateReversal->bindParam(i++, DBM_DECIMALTYPE, &shclog.ch_new_amount, sizeof(shclog.ch_new_amount), NULL);
			_updateReversal->bindParam(i++, DBM_DECIMALTYPE, &shclog.new_setl_fee, sizeof(shclog.new_setl_fee), NULL);
		    _updateReversal->bindParam(i++, DBM_LONGTYPE, &shclog.shcerror, sizeof(shclog.shcerror), NULL);

			_updateReversal->bindParam(i++, DBM_INTTYPE, &shclog.site_id, sizeof(shclog.site_id), NULL);
			_updateReversal->bindParam(i++, DBM_STRINGTYPE, shclog.chip_index, sizeof(shclog.chip_index), NULL);


		 }
		 catch( const DBMException& e )
		 {
		 	handleDBMException( _dbConn, _updateReversal, e );
			
			OTraceError
			(
			   	"E-SHCLOG-5130:caught exception in prepare update reversal "
			   	"native error=%d, sqlstate=%.5s, msg=%s\n",
				e.getNativeError(), e.getSQLState().data(), e.getErrMsg().data()
			);
			return -1;
		}		
	}

	return 1;
}

int ShcLog::prepareUpdateFinCapture()
{
	if (!_updateFinCapture)
	{
	    int i = 1;;	
		_updateFinCapture = _dbConn->getStmt();

		try
		{ 	
			// For Fin Capture Update  batch_id  and formatter_devcap
			_updateFinCapture->prepare ("update shclog  set batch_id = ?, formatter_devcap  = ? where site_id = ? AND chip_index = ?");
		    
			_updateFinCapture->bindParam(i++, DBM_LONGTYPE, &shclog.batch_id, sizeof(shclog.batch_id), NULL);
		    _updateFinCapture->bindParam(i++, DBM_LONGTYPE, &shclog.formatter_devcap, sizeof(shclog.formatter_devcap), NULL);
 
			_updateFinCapture->bindParam(i++, DBM_INTTYPE, &shclog.site_id, sizeof(shclog.site_id), NULL);
			_updateFinCapture->bindParam(i++, DBM_STRINGTYPE, shclog.chip_index, sizeof(shclog.chip_index), NULL);

		 }
		 catch( const DBMException& e )
		 {
		 	handleDBMException( _dbConn, _updateFinCapture, e );
			
			OTraceError
			(
			   	"E-SHCLOG-5131:caught exception in prepare update fin capture "
			   	"native error=%d, sqlstate=%.5s, msg=%s\n",
				e.getNativeError(), e.getSQLState().data(), e.getErrMsg().data()
			);
			return -1;
		}		
	}

	return 1;
}

int ShcLog::shcsql_init()
{
	static int	init = 0; 
	char		xbuf[16385] = {0};
	char		*bp = NULL;

	if( init )
		return( init );

	HaPtmCctHelper::addHandler( "system.dcs.shc" ) ;

	init = -1;

	if( cf_open(NULL) < 0 )
		return( -1 );

	if( cf_locate(SQLEXP_CFG, SqlKey) <= 0 )
		return( -1 );

	OTraceDebug("D-SHC-032036: Loading SQL table\n");

	for( cf_rewind(); SqlTbl_n < SQLTBL_SZ; SqlTbl_n++ )
	{
		if( cf_nextparm(SQLELM_CFG, xbuf) <= 0 )
			break;

		/* 
		 * Get key
		 */
		if( (bp = strtok(xbuf, " \t\n")) )
		{
/* R005156	if( ! (SqlTbl[SqlTbl_n].key = malloc(strlen(bp) + 1)) )	*/
			if( ! (SqlTbl[SqlTbl_n].key = ( char * )malloc(strlen(bp) + 1)) ) /* R005156 */
			{
				OTraceError("E-SHC-032037: Unable to allocate %d bytes for SQL key.\n",
					strlen(bp));

				continue;
			}
			strcpy(SqlTbl[SqlTbl_n].key, bp);
		}

		/*
	 	 *	Get statement
	 	 */
		if( (bp = strtok(NULL, "\n")) )
		{
/* R005156	if( ! (SqlTbl[SqlTbl_n].stmt = malloc(strlen(bp) + 1)) )	*/
			if( ! (SqlTbl[SqlTbl_n].stmt = (char *)malloc(strlen(bp) + 1)) )	/* R005156 */
			{
				OTraceError("E-SHC-032038: Unable to allocate %d bytes for SQL statement.\n",
					strlen(bp));

				continue;
			}
			strcpy(SqlTbl[SqlTbl_n].stmt, bp);
		}

		OTraceDebug("D-SHC-032039:  key   = '%s'\n", SqlTbl[SqlTbl_n].key);
		OTraceDebug("D-SHC-032040:   stmt = '%s'\n", SqlTbl[SqlTbl_n].stmt);
	}

	cf_close();

	init = 1;

	return( init );
}


int ShcLog::shcsql_getfield( char *src, char *dst )
{
	int		l = 0;

	if( *src == SQLCHAR_SEP )
		src++;

	for( ; *src && *src != SQLCHAR_SEP; src++ )
	{
		*dst++ = *src;
		l++;
	}

	return( l );
}

int ShcLog::shcsql_cmp( char *expp, char *keyp )
{
	return( stricmp(expp, keyp) );
}

int ShcLog::shcsql_find( ShcmsgHeader *header, char *dstp, char *prefix )
{
	char	ekey[SQLKEY_SZ] = {0};
	char	xbuf[1024] = {0};
	int		i = 0;

	if ( shcsql_init() < 0 )
		return( -1 );

	OTraceDebug("D-SHC-032041: Search for SQL statement\n");
	OTraceDebug("D-SHC-032042:  SQL Key: '%s'\n", SqlKey);

	if( ICShcmsg_expand(&header->msg, SqlKey, xbuf) < 0 )
	{
		OTraceError("E-SHC-032043:  Result : Unable to expand SQL key\n");
		return( -1 );
	}

	if( prefix )
		snprintf(ekey,sizeof(ekey),"%s",prefix);
	snprintf(ekey+strlen(ekey),sizeof(ekey)-strlen(ekey),"%s",xbuf); //IST_S_0157721-34

	OTraceDebug("D-SHC-032044:  Exp.   : '%s'\n", ekey);

	for( i = 0; i < SqlTbl_n; i++ )
	{
		if( ! SqlTbl[i].key )
			continue;
	
		if( shcsql_cmp(SqlTbl[i].key, ekey) == 0 )
		{
			OTraceDebug("D-SHC-032045:  Result : found\n");
			OTraceDebug("D-SHC-032046:  Key    : '%s'\n", SqlTbl[i].key);
			OTraceDebug("D-SHC-032047:  Stmt   : '%s'\n", SqlTbl[i].stmt);

			if (ICShcmsg_expand(&header->msg, SqlTbl[i].stmt, dstp) < 0)
			{
				OTraceError("E-SHC-032047.1:  Result : Unable to expand SQL Stmt\n");
				return( -1 );
			}
			return( 1 );
		}
	}

	OTraceDebug("D-SHC-032048:  Result : none found\n");

	return( -1 );
}


// SPR 2024022 >>>>>
int ShcLog::setLocateByRefnum(int true_or_false)
{
	return (useRefnumToLocate = true_or_false);
}

int ShcLog::setExcludeTraceInRefnum(int true_or_false)
{
	return (excludeTraceInRefnum = true_or_false);
}

int ShcLog::isLocateByRefnum()
{
	return useRefnumToLocate;	
}

int ShcLog::isExcludeTraceInRefnum()
{
	return excludeTraceInRefnum;	
}

IstSegList *ShcLog::restoreGenericLog(ShcGenericLog *genericLog, ShcmsgHeader *header, char reqresp)
{
	seg_req_len = sizeof(shclog.seg_req);	//R030004
	seg_resp_len = sizeof(shclog.seg_resp);	//R030004

	IstSegList *segList = genericLog->restore(header, reqresp, (char *)shclog.seg_req, seg_req_len, (char *)shclog.seg_resp, seg_resp_len);
	
	return segList;	
}

// SPR 2024022 <<<<<


void handleDBMException(DBMConn* conObj, DBMStmt* stmt, const DBMException& e )
{
	OTraceError
	(
		"E-SHCLOG-0001 Caught DBM Exception"
		"native error=%d, sqlstate=%.5s, msg=%s\n",
		e.getNativeError(), e.getSQLState().data(), e.getErrMsg().data()
	);

	try
	{
		if( stmt )
			stmt->close();
	}
	catch(const DBMException& se )
	{
	}


}

/*
 * Search original transaction record by pan, pcode, amount, pos condition code, authnum and termloc
 *
 * Note: This function is used to search for the record when all lookup failed and shc.ExtPreAuthLookup enabled
 * in istparam.cfg
 * (This method especially return for BBL)
 */

int ShcLog::locateTxnByExtLookup(ShcmsgHeader *header, struct shcmsg *oldmsg, int flag)
{
        if( (header->msg.msgtype != SHC_AUTHREQ) ||
            (!shcIsPreAuthCancelReq(header)) ||
            !(header->msg.pos_condition_code & SH_POS_COND_REQ_PREAUTH)) {
                OTraceDebug("D-SHCLOG-5107:locateTxnByExtLookup not a PreAuth Cancel txn\n");
                return -1;
        }

        struct ShcmsgWithSegment omsg;
        struct shc_data *shc_data_ptr;  /* R001319 For looking up device_cap */

        char where[256];
        char where_debug[256];

        int     internalrev;    /* R001319 internal reversal indicator */
        int     device_cap;     /* R001319 Device_cap from shclog */
        int     id_len=0;
        int     fd[2];
        int     i;

        memset(shclog.seg_req,0, sizeof(shclog.seg_req));
        memset(shclog.seg_resp,0, sizeof(shclog.seg_resp));

        char pan_token[(Tokenizer::MAX_PAN_SIZE > Tokenizer::MAX_TOKEN_SIZE ?
                                        Tokenizer::MAX_PAN_SIZE : Tokenizer::MAX_TOKEN_SIZE) + 1];
        Tokenizer *tkn_ptr = Tokenizer::create();
        int tkn_ret = tkn_ptr->getToken(header->msg.pan,pan_token,true);
        delete tkn_ptr;
        if(tkn_ret != 0)
        {
                OTraceError("E-SHCLOG-5043: Unable to tokenize Pan [%d]\n", tkn_ret);
                return -1;
        }
        OTraceDebug("D-SHCLOG-5044: Tokenized PAN [%s]\n",
                                strcmp(header->msg.pan,pan_token)? pan_token:shc_maskpan(pan_token));
        char    amount[50];
        dbm_dectochar(&header->msg.amount, amount);

        snprintf(where, sizeof(where), " pan = '%s' and amount = %12s and authnum = '%s' and termloc = '%s' ",
                pan_token, amount,
                header->msg.authnum, header->msg.termloc);

        snprintf(where_debug, sizeof(where_debug), " pan = '%s' and amount = %12s and authnum = '%s' and termloc = '%s'",
                strcmp(header->msg.pan,pan_token)? pan_token:shc_maskpan(pan_token), amount,
                header->msg.authnum, header->msg.termloc);

        if ( !use_log(header) )
                return -1;

        if (shclogfd < 0)
                open_index();

        if(oldmsg == NULL)
        {
                oldmsg = &(omsg.msg);
                memset(&omsg, 0, sizeof(omsg));
        }

        OTraceDebug("D-SHCLOG-5046: Search (extended lookup) WHERE <%s>\n", where_debug);

        if (((flag  & IST_SHCLOG_FLAG_LOCATE_REQ  && flag & IST_SHCLOG_FLAG_LOCATE_RESP)) ||
                (!(flag & IST_SHCLOG_FLAG_LOCATE_REQ) && !(flag & IST_SHCLOG_FLAG_LOCATE_RESP)) )
        {
                fd[0] = shclogfd;
                fd[1] = shclogreqfd;
                OTraceDebug("D-SHCLOG-5108:Search RESP/REQ\n");
        }
        else if (flag & IST_SHCLOG_FLAG_LOCATE_REQ)
        {
                fd[0] = shclogreqfd;
                fd[1] = -1;
                OTraceDebug("D-SHCLOG-5108:Search REQ\n");
        }
        else if (flag & IST_SHCLOG_FLAG_LOCATE_RESP)
        {
                fd[0] = shclogfd;
                fd[1] = -1;
                OTraceDebug("D-SHCLOG-5109:Search RESP\n");
        }

        for (i = 0; i < 2 && fd[i] != -1; i++)
        {
                if (dbm_selectfd(fd[i], where) < 0)
                {
                        OTraceWarning("W-SHC-032006: extended lookup: dbm_selectfd fails\n");
                        return(-1);
                }

                while(dbm_fetchfd(fd[i], (char *) &shclog) >= 0)
                {
                        if( shclog.msgtype == 110  &&
                            shclog.respcode == SHC_RC_Approved &&
                            (shclog.pos_condition_code & SH_POS_COND_REQ_PREAUTH) &&
                            shcGetProcessCode(shclog.pcode) == SH_ISO_PREAUTHREQ )
                        {
                                OTraceDebug("D-SHCLOG-5048: Found: header->msg.msgtype:%d log->msgtype:%d\n",
                                                header->msg.msgtype, shclog.msgtype );
                                fill_message(oldmsg);
                                shclogLocateFd = fd[i];
                                return 0;
                        }
                }
        }
        OTraceWarning("W-SHC-032007: extended lookup: not found\n");
        return(-1);
}

int ShcLog::locateTxnRefnumInit()
{
        int rc;

        if(!_dbConn1)
                _dbConn1= new DBMConn(dbm_dbconn);

        if(!_smtShcLogAll)
                {
                        _smtShcLogAll = _dbConn1->getStmt();
                        rc = prepareShcLogAll( _smtShcLogAll, 1 );
                        if ( rc != 0 )
                        {
                                return -1;
                        }
                }
        if(!_smtShcLogTrace)
                {
                        _smtShcLogTrace = _dbConn1->getStmt();
                     rc = prepareShcLogTrace( _smtShcLogTrace , 1);
                        if ( rc != 0 )
                        {
                                return -1;
                        }
                }
        if(!_smtShcLogBkOff)
                {
                        _smtShcLogBkOff = _dbConn1->getStmt();
                                rc = prepareShcLogBkOff( _smtShcLogBkOff , 1);
                        if ( rc != 0 )
                        {
                                                        return -1;
                        }
                }
        if(!_smtShcLog)
                {
                        _smtShcLog = _dbConn1->getStmt();
                                rc = prepareShcLog( _smtShcLog , 1);
                        if ( rc != 0 )
                        {
                                                        return -1;
                        }
                }
                if(!_smtShcLogReqAll)
                {
                        _smtShcLogReqAll = _dbConn1->getStmt();
                        rc = prepareShcLogAll(_smtShcLogReqAll, 2 );
                        if ( rc != 0 )
                        {
                                return -1;
                        }
                }
        if(!_smtShcLogReqTrace)
                {
                        _smtShcLogReqTrace = _dbConn1->getStmt();
                     rc = prepareShcLogTrace( _smtShcLogReqTrace , 2);
                        if ( rc != 0 )
                        {
                                return -1;
                        }
                }
        if(!_smtShcLogReqBkOff)
                {
                        _smtShcLogReqBkOff = _dbConn1->getStmt();
                                rc = prepareShcLogBkOff( _smtShcLogReqBkOff , 2);
                        if ( rc != 0 )
                        {
                                                        return -1;
                        }
                }
        if(!_smtShcLogReq)
                {
                        _smtShcLogReq = _dbConn1->getStmt();
                                rc = prepareShcLog( _smtShcLogReq , 2);
                        if ( rc != 0 )
                        {
                                                        return -1;
                        }
                }
        if(!_smtShcLogAllP)
                {
                        _smtShcLogAllP = _dbConn1->getStmt();
                        rc = prepareShcLogAll( _smtShcLogAllP, 3 );
                        if ( rc != 0 )
                        {
                                return -1;
                        }
                }
        if(!_smtShcLogTraceP)
                {
                        _smtShcLogTraceP = _dbConn1->getStmt();
                     rc = prepareShcLogTrace( _smtShcLogTraceP , 3);
                        if ( rc != 0 )
                        {
                                return -1;
                        }
                }
        if(!_smtShcLogBkOffP)
                {
                        _smtShcLogBkOffP = _dbConn1->getStmt();
                                rc = prepareShcLogBkOff( _smtShcLogBkOffP , 3);
                        if ( rc != 0 )
                        {
                                                        return -1;
                        }
                }
        if(!_smtShcLogP)
                {
                        _smtShcLogP = _dbConn1->getStmt();
                                rc = prepareShcLog( _smtShcLogP , 3);
                        if ( rc != 0 )
                        {
                                                        return -1;
                        }
                }
                if(!_smtShcLogReqAllP)
                {
                        _smtShcLogReqAllP = _dbConn1->getStmt();
                        rc = prepareShcLogAll(_smtShcLogReqAllP, 4 );
                        if ( rc != 0 )
                        {
                                return -1;
                        }
                }
        if(!_smtShcLogReqTraceP)
                {
                        _smtShcLogReqTraceP = _dbConn1->getStmt();
                     rc = prepareShcLogTrace( _smtShcLogReqTraceP , 4);
                        if ( rc != 0 )
                        {
                                return -1;
                        }
                }
        if(!_smtShcLogReqBkOffP)
                {
                        _smtShcLogReqBkOffP = _dbConn1->getStmt();
                                rc = prepareShcLogBkOff( _smtShcLogReqBkOffP , 4);
                        if ( rc != 0 )
                        {
                                                        return -1;
                        }
                }
        if(!_smtShcLogReqP)
                {
                        _smtShcLogReqP = _dbConn1->getStmt();
                                rc = prepareShcLog( _smtShcLogReqP , 4);
                        if ( rc != 0 )
                        {
                                                        return -1;
                        }
                }
        _initFlag = true;
        return 0;
}

int ShcLog::prepareShcLogAll(DBMStmt* stmt,int tbl)
{
        int sno = 1;
        int cnt = 0;
    char fullStmt[4096];
    char query[2048];

        memset(query,0x00,sizeof(query));
    memset(fullStmt,0x00,sizeof(fullStmt));
        istsafe_strcpy(query,sizeof(query),     "SELECT msgtype, flipped_msgtype,pan,mask_pan, pcode ,txntype  , amount, aval_balance ,amount_equiv,cash_back ,iss_conv_rate ,iss_currency_code,iss_conv_date,acq_conv_rate,acq_currency_code,acq_conv_date,tra_amount,tra_conv_rate,tra_currency_code,tra_conv_date, fee,new_fee,new_amount,new_setl_amount,settlement_fee,settlement_rate,settlement_code,settlement_amount,trandate,trantime ,trace,local_time,local_date,settlement_date,cap_date,pos_entry_code,pos_condition_code,pos_pin_cap_code  ,pos_cap_code,life_cycle,acquirer  ,issuer ,transferee,originator,member_id ,f_id,txnsrc ,txndest ,alternateacquirer ,entityid  ,iss_entityid  ,cardproduct ,mvv,invoice_number,trans_id ,fpi  ,txn_start_time,txn_end_time ,device_cap,respcode,reason_code,revcode ,shcerror,saf,origmsg ,origflippedmsg,origtrace,origdate,origtime,merchant_type ,acq_country,refnum,authnum ,termid,acceptorname  ,termloc ,addresponse,acctnum ,branch,serial_1,serial_2,storeid ,lane  ,terminal_trace,checker_id ,supervisor ,shift_number  ,batch_id,device_devcap ,shc_devcap ,formatter_devcap,auth_devcap,filler1 ,filler2 ,filler3 ,filler4 ,issuer_data,acquirer_data,new_amount_equiv , acq_aval_balance, acq_ledger_balance , setl_aval_balance  , setl_ledger_balance, aval_balance_type  , ledger_balance_type, new_setl_fee , txn_amount , txn_new_amount, txn_currency_code  , txn_conv_rate, txn_conv_date, ch_amount  , ch_new_amount, ch_currency_code, ch_conv_rate, ch_conv_date,ledger_balance , slot_num, device_fee , shc_data_buffer, card_seqno, alpharesponsecode , chip_type  , chip_index, processor_busday,seq_trace_no ,seg_req, seg_resp,site_id,version,src_node, dest_node, gateway_id, submerchant_id, dest_id, payfacid ");
        try
        {
                istsafe_strcat(fullStmt, sizeof(fullStmt), query);
                if(tbl == 1)
                        istsafe_strcat(fullStmt,sizeof(fullStmt)," from shclog where refnum = ? AND pan = ? and shc_devcap >= ? and shc_devcap <= ?  and trace = ? for update");
                else if (tbl == 2)
                        istsafe_strcat(fullStmt,sizeof(fullStmt)," from shclog_req where refnum = ? AND pan = ? and shc_devcap >= ? and shc_devcap <= ?  and trace = ? for update");
                else if (tbl == 3)
                        istsafe_strcat(fullStmt,sizeof(fullStmt)," from shclog where refnum = ? AND pan in(?,?) and shc_devcap >= ? and shc_devcap <= ?  and trace = ? for update");
                else if (tbl == 4)
                        istsafe_strcat(fullStmt,sizeof(fullStmt),"  from shclog_req where refnum = ? AND pan in(?,?)  and shc_devcap >= ? and shc_devcap <= ?  and trace = ? for update");
		else if (tbl == 5)
			istsafe_strcat(fullStmt,sizeof(fullStmt)," from shclog where chip_index = ? for update");
		else if (tbl == 6)
			istsafe_strcat(fullStmt,sizeof(fullStmt),"  from shclog_req where chip_index = ? for update");

		stmt->prepare(fullStmt);
		doBindCol(stmt);

                if((tbl == 1) || (tbl == 2))
                {
                stmt->bindParam(1, DBM_STRINGTYPE, refnum, sizeof(refnum), NULL);
                stmt->bindParam(2, DBM_PANTOKENTYPE, Pan, sizeof(Pan),NULL );
                stmt->bindParam(3, DBM_LONGTYPE, &devcap1,sizeof(devcap1),NULL );
                stmt->bindParam(4, DBM_LONGTYPE, &devcap,sizeof(devcap),NULL );
                stmt->bindParam(5, DBM_LONGTYPE, &trace,sizeof(trace),NULL );
                }
		if((tbl == 5) || (tbl == 6))
		{
			stmt->bindParam(1, DBM_STRINGTYPE, shclog.chip_index, sizeof(shclog.chip_index), NULL);
		}
		else
                {
                        stmt->bindParam(1, DBM_STRINGTYPE, refnum, sizeof(refnum), NULL);
                        stmt->bindParam(2, DBM_PANTOKENTYPE, Pan, sizeof(Pan),NULL );
                        stmt->bindParam(3, DBM_PANTOKENTYPE, Pan1, sizeof(Pan1),NULL );
                        stmt->bindParam(4, DBM_LONGTYPE, &devcap1,sizeof(devcap1),NULL );
                        stmt->bindParam(5, DBM_LONGTYPE, &devcap,sizeof(devcap),NULL );
                        stmt->bindParam(6, DBM_LONGTYPE, &trace,sizeof(trace),NULL );
                }
        }
        catch( const DBMException& e )
        {
                handleDBMException( _dbConn, stmt, e );
                        OTraceError
                        (
                                        "E-ATM-18024 caught exception in prepareShcLogAll,"
                                        "native error=%d, sqlstate=%.5s, msg=%s\n",
                                        e.getNativeError(), e.getSQLState().data(), e.getErrMsg().data()
                        );
                        return -1;
        }
        return 0;

}

int ShcLog::prepareShcLogTrace(DBMStmt* stmt,int tbl)
{
        int sno = 1;
        int cnt = 0;
        char fullStmt[4096];
   char query[2048];

        memset(query,0x00,sizeof(query));
    memset(fullStmt,0x00,sizeof(fullStmt));
        istsafe_strcpy(query,sizeof(query),     "SELECT msgtype, flipped_msgtype,pan,mask_pan, pcode ,txntype  , amount, aval_balance ,amount_equiv,cash_back ,iss_conv_rate ,iss_currency_code,iss_conv_date,acq_conv_rate,acq_currency_code,acq_conv_date,tra_amount,tra_conv_rate,tra_currency_code,tra_conv_date, fee,new_fee,new_amount,new_setl_amount,settlement_fee,settlement_rate,settlement_code,settlement_amount,trandate,trantime ,trace,local_time,local_date,settlement_date,cap_date,pos_entry_code,pos_condition_code,pos_pin_cap_code  ,pos_cap_code,life_cycle,acquirer  ,issuer ,transferee,originator,member_id ,f_id,txnsrc ,txndest ,alternateacquirer ,entityid  ,iss_entityid  ,cardproduct ,mvv,invoice_number,trans_id ,fpi  ,txn_start_time,txn_end_time ,device_cap,respcode,reason_code,revcode ,shcerror,saf,origmsg ,origflippedmsg,origtrace,origdate,origtime,merchant_type ,acq_country,refnum,authnum ,termid,acceptorname  ,termloc ,addresponse,acctnum ,branch,serial_1,serial_2,storeid ,lane  ,terminal_trace,checker_id ,supervisor ,shift_number  ,batch_id,device_devcap ,shc_devcap ,formatter_devcap,auth_devcap,filler1 ,filler2 ,filler3 ,filler4 ,issuer_data,acquirer_data,new_amount_equiv , acq_aval_balance, acq_ledger_balance , setl_aval_balance  , setl_ledger_balance, aval_balance_type  , ledger_balance_type, new_setl_fee , txn_amount , txn_new_amount, txn_currency_code  , txn_conv_rate, txn_conv_date, ch_amount  , ch_new_amount, ch_currency_code, ch_conv_rate, ch_conv_date,ledger_balance , slot_num, device_fee , shc_data_buffer, card_seqno, alpharesponsecode , chip_type  , chip_index, processor_busday,seq_trace_no ,seg_req, seg_resp,site_id,version,src_node, dest_node, gateway_id, submerchant_id, dest_id, payfacid ");

        try
        {
                istsafe_strcat(fullStmt, sizeof(fullStmt), query);
                if(tbl == 1)
                {
                        istsafe_strcat(fullStmt, sizeof(fullStmt),"  from shclog where refnum = ? AND pan = ? and shc_devcap <= ? and trace = ?  for update");
                }
                else if(tbl == 2)
                {
                        istsafe_strcat(fullStmt, sizeof(fullStmt)," from shclog_req where refnum = ? AND pan = ? and shc_devcap <= ? and trace = ?  for update");
                }
                else if(tbl == 3)
                {
            istsafe_strcat(fullStmt, sizeof(fullStmt)," from shclog where refnum = ? AND pan in(?,?) and shc_devcap <= ? and trace = ?  for update");
        }
                else if(tbl == 4)
                {
            istsafe_strcat(fullStmt, sizeof(fullStmt),"  from shclog_req where refnum = ? AND pan in(?,?) and shc_devcap <= ? and trace = ?  for update");
                }
                stmt->prepare(fullStmt);

                doBindCol(stmt);

                if((tbl == 1) || (tbl == 2))
                {
                stmt->bindParam(1, DBM_STRINGTYPE, refnum, sizeof(refnum), NULL);
                stmt->bindParam(2, DBM_PANTOKENTYPE, Pan, sizeof(Pan),NULL );
                stmt->bindParam(3, DBM_LONGTYPE, &devcap,sizeof(devcap),NULL );
                stmt->bindParam(4, DBM_LONGTYPE, &trace,sizeof(trace),NULL );
                }
                else
                {
                        stmt->bindParam(1, DBM_STRINGTYPE, refnum, sizeof(refnum), NULL);
                        stmt->bindParam(2, DBM_PANTOKENTYPE, Pan, sizeof(Pan),NULL );
                        stmt->bindParam(3, DBM_PANTOKENTYPE, Pan1, sizeof(Pan1),NULL );
                        stmt->bindParam(4, DBM_LONGTYPE, &devcap,sizeof(devcap),NULL );
                        stmt->bindParam(5, DBM_LONGTYPE, &trace,sizeof(trace),NULL );
                }
        }
        catch( const DBMException& e )
        {
                        handleDBMException( _dbConn1, stmt, e );
                        OTraceError
                        (
                                        "E-ATM-18024 caught exception in prepareShcLogTrace,"
                                        "native error=%d, sqlstate=%.5s, msg=%s\n",
                                        e.getNativeError(), e.getSQLState().data(), e.getErrMsg().data()
                        );
                        return -1;
        }
        return 0;

}

int ShcLog::prepareShcLogBkOff(DBMStmt* stmt,int tbl)
{
        int sno = 1;
        int cnt = 0;
    char fullStmt[4096];
   char query[2048];

        memset(query,0x00,sizeof(query));
    memset(fullStmt,0x00,sizeof(fullStmt));
        istsafe_strcpy(query,sizeof(query),     "SELECT msgtype, flipped_msgtype,pan,mask_pan, pcode ,txntype  , amount, aval_balance ,amount_equiv,cash_back ,iss_conv_rate ,iss_currency_code,iss_conv_date,acq_conv_rate,acq_currency_code,acq_conv_date,tra_amount,tra_conv_rate,tra_currency_code,tra_conv_date, fee,new_fee,new_amount,new_setl_amount,settlement_fee,settlement_rate,settlement_code,settlement_amount,trandate,trantime ,trace,local_time,local_date,settlement_date,cap_date,pos_entry_code,pos_condition_code,pos_pin_cap_code  ,pos_cap_code,life_cycle,acquirer  ,issuer ,transferee,originator,member_id ,f_id,txnsrc ,txndest ,alternateacquirer ,entityid  ,iss_entityid  ,cardproduct ,mvv,invoice_number,trans_id ,fpi  ,txn_start_time,txn_end_time ,device_cap,respcode,reason_code,revcode ,shcerror,saf,origmsg ,origflippedmsg,origtrace,origdate,origtime,merchant_type ,acq_country,refnum,authnum ,termid,acceptorname  ,termloc ,addresponse,acctnum ,branch,serial_1,serial_2,storeid ,lane  ,terminal_trace,checker_id ,supervisor ,shift_number  ,batch_id,device_devcap ,shc_devcap ,formatter_devcap,auth_devcap,filler1 ,filler2 ,filler3 ,filler4 ,issuer_data,acquirer_data,new_amount_equiv , acq_aval_balance, acq_ledger_balance , setl_aval_balance  , setl_ledger_balance, aval_balance_type  , ledger_balance_type, new_setl_fee , txn_amount , txn_new_amount, txn_currency_code  , txn_conv_rate, txn_conv_date, ch_amount  , ch_new_amount, ch_currency_code, ch_conv_rate, ch_conv_date,ledger_balance , slot_num, device_fee , shc_data_buffer, card_seqno, alpharesponsecode , chip_type  , chip_index, processor_busday,seq_trace_no ,seg_req, seg_resp,site_id,version,src_node, dest_node, gateway_id ");


        try
        {
                istsafe_strcat(fullStmt, sizeof(fullStmt), query);
                if(tbl == 1)
                        istsafe_strcat(fullStmt, sizeof(fullStmt)," from shclog where refnum = ? AND pan = ? and shc_devcap >= ? and shc_devcap <= ?  for update");
                else if(tbl == 2)
                        istsafe_strcat(fullStmt, sizeof(fullStmt)," from shclog_req where refnum = ? AND pan = ? and shc_devcap >= ? and shc_devcap <= ?  for update");
                else if(tbl == 3)
                        istsafe_strcat(fullStmt, sizeof(fullStmt)," from shclog where refnum = ? AND pan in(?,?) and shc_devcap >= ? and shc_devcap <= ?  for update");
                else if(tbl == 4)
                        istsafe_strcat(fullStmt, sizeof(fullStmt)," from shclog_req where refnum = ? AND pan in(?,?) and shc_devcap >= ? and shc_devcap <= ?  for update");

        stmt->prepare(fullStmt);

        doBindCol(stmt);

                if((tbl == 1) || (tbl ==2))
                {
                stmt->bindParam(1, DBM_STRINGTYPE, refnum, sizeof(refnum), NULL);
                stmt->bindParam(2, DBM_PANTOKENTYPE, Pan, sizeof(Pan),NULL );
                stmt->bindParam(3, DBM_LONGTYPE, &devcap1,sizeof(devcap1),NULL );
                stmt->bindParam(4, DBM_LONGTYPE, &devcap,sizeof(devcap),NULL );
                }
                else
                {
                        stmt->bindParam(1, DBM_STRINGTYPE, refnum, sizeof(refnum), NULL);
                        stmt->bindParam(2, DBM_PANTOKENTYPE, Pan, sizeof(Pan),NULL );
                        stmt->bindParam(3, DBM_PANTOKENTYPE, Pan1, sizeof(Pan1),NULL );
                        stmt->bindParam(4, DBM_LONGTYPE, &devcap1,sizeof(devcap1),NULL );
                        stmt->bindParam(5, DBM_LONGTYPE, &devcap,sizeof(devcap),NULL );
                }
        }

        catch( const DBMException& e )
        {
                        handleDBMException( _dbConn1, stmt, e );
                        OTraceError
                        (
                                        "E-ATM-18024 caught exception in prepareShcLogBkOff,"
                                        "native error=%d, sqlstate=%.5s, msg=%s\n",
                                        e.getNativeError(), e.getSQLState().data(), e.getErrMsg().data()
                        );
                        return -1;
        }
        return 0;

}

int ShcLog::prepareShcLog(DBMStmt* stmt,int tbl)
{
    int sno = 1;
    int cnt = 0;
    char fullStmt[4096];
   char query[2048];

        memset(query,0x00,sizeof(query));
    memset(fullStmt,0x00,sizeof(fullStmt));
        istsafe_strcpy(query,sizeof(query),     "SELECT msgtype, flipped_msgtype,pan,mask_pan, pcode ,txntype  , amount, aval_balance ,amount_equiv,cash_back ,iss_conv_rate ,iss_currency_code,iss_conv_date,acq_conv_rate,acq_currency_code,acq_conv_date,tra_amount,tra_conv_rate,tra_currency_code,tra_conv_date, fee,new_fee,new_amount,new_setl_amount,settlement_fee,settlement_rate,settlement_code,settlement_amount,trandate,trantime ,trace,local_time,local_date,settlement_date,cap_date,pos_entry_code,pos_condition_code,pos_pin_cap_code  ,pos_cap_code,life_cycle,acquirer  ,issuer ,transferee,originator,member_id ,f_id,txnsrc ,txndest ,alternateacquirer ,entityid  ,iss_entityid  ,cardproduct ,mvv,invoice_number,trans_id ,fpi  ,txn_start_time,txn_end_time ,device_cap,respcode,reason_code,revcode ,shcerror,saf,origmsg ,origflippedmsg,origtrace,origdate,origtime,merchant_type ,acq_country,refnum,authnum ,termid,acceptorname  ,termloc ,addresponse,acctnum ,branch,serial_1,serial_2,storeid ,lane  ,terminal_trace,checker_id ,supervisor ,shift_number  ,batch_id,device_devcap ,shc_devcap ,formatter_devcap,auth_devcap,filler1 ,filler2 ,filler3 ,filler4 ,issuer_data,acquirer_data,new_amount_equiv , acq_aval_balance, acq_ledger_balance , setl_aval_balance  , setl_ledger_balance, aval_balance_type  , ledger_balance_type, new_setl_fee , txn_amount , txn_new_amount, txn_currency_code  , txn_conv_rate, txn_conv_date, ch_amount  , ch_new_amount, ch_currency_code, ch_conv_rate, ch_conv_date,ledger_balance , slot_num, device_fee , shc_data_buffer, card_seqno, alpharesponsecode , chip_type  , chip_index, processor_busday,seq_trace_no ,seg_req, seg_resp,site_id,version,src_node, dest_node, gateway_id, submerchant_id, dest_id, payfacid ");


        try
        {
                istsafe_strcat(fullStmt, sizeof(fullStmt), query);
                if(tbl == 1)
                        istsafe_strcat(fullStmt, sizeof(fullStmt)," from shclog where refnum = ? AND pan = ? and shc_devcap <= ? for update");
                else if(tbl == 2)
                        istsafe_strcat(fullStmt, sizeof(fullStmt)," from shclog_req where refnum = ? AND pan = ? and shc_devcap <= ? for update");
                else if(tbl == 3)
                        istsafe_strcat(fullStmt, sizeof(fullStmt)," from shclog where refnum = ? AND pan in (?,?) and shc_devcap <= ? for update");
                else if(tbl == 4)
                        istsafe_strcat(fullStmt, sizeof(fullStmt)," from shclog_req where refnum = ? AND pan in(?,?) and shc_devcap <= ? for update");

        stmt->prepare(fullStmt);

        doBindCol(stmt);

                if((tbl == 1) || (tbl == 2))
                {
                stmt->bindParam(1, DBM_STRINGTYPE, refnum, sizeof(refnum), NULL);
                stmt->bindParam(2, DBM_PANTOKENTYPE, Pan, sizeof(Pan),NULL );
                stmt->bindParam(3, DBM_LONGTYPE, &devcap,sizeof(devcap),NULL );
                }
                else
                {
                        stmt->bindParam(1, DBM_STRINGTYPE, refnum, sizeof(refnum), NULL);
                        stmt->bindParam(2, DBM_PANTOKENTYPE, Pan, sizeof(Pan),NULL );
                        stmt->bindParam(3, DBM_PANTOKENTYPE, Pan1, sizeof(Pan1),NULL );
                        stmt->bindParam(4, DBM_LONGTYPE, &devcap,sizeof(devcap),NULL );
                }
        }
        catch( const DBMException& e )
        {
                        handleDBMException( _dbConn1, stmt, e );
                        OTraceError
                        (
                                        "E-ATM-18024 caught exception in prepareShcLog,"
                                        "native error=%d, sqlstate=%.5s, msg=%s\n",
                                        e.getNativeError(), e.getSQLState().data(), e.getErrMsg().data()
                        );
                        return -1;
        }
        return 0;

}

int ShcLog::locateTxnRefnum_xt(ShcmsgHeader *header, struct shcmsg *oldmsg, int flag)
{

    struct  ShcmsgWithSegment omsg;
    int internalrev;    /* R001319 internal reversal indicator */
    int device_cap_chk; /* R001319 Device_cap from shclog */
    struct shc_data *shc_data_ptr;  /* R001319 For looking up device_cap */
    int id_len=0;
    int   fd[2];
        int tmpfd[2];
    int i;
    int len = 0;
    memset(shclog.seg_req,0, sizeof(shclog.seg_req));
    memset(shclog.seg_resp,0, sizeof(shclog.seg_resp));
        long back_office_flags=0;
        int rc;
        int shclogAvlb=1;
        int shclogreqAvlb = 2;
        int  searchForTrace = 0;
        int searchForPanRange = 0;
    DBMStmt *updateVoidFd = _updateVoid;
    DBMStmt *updateReversalFd = _updateReversal;
    DBMStmt *updateFinCaptureFd = _updateFinCapture;
    DBMStmt *updateRespcode = _updateRespcode;
        DBMConn *dbConnPtr = _dbConn;
        char pan_tok1[(Tokenizer::MAX_PAN_SIZE > Tokenizer::MAX_TOKEN_SIZE ?
                                        Tokenizer::MAX_PAN_SIZE : Tokenizer::MAX_TOKEN_SIZE)+1];
        char pan_tok2[(Tokenizer::MAX_PAN_SIZE > Tokenizer::MAX_TOKEN_SIZE ?
                                        Tokenizer::MAX_PAN_SIZE : Tokenizer::MAX_TOKEN_SIZE)+1];

        if ( !use_log(header) )
        return -1;

        locateTxnRefnumInit();

        if (shclogfd < 0)
                open_index();

    if(oldmsg == NULL)
    {
        oldmsg = &(omsg.msg);
        memset(&omsg, 0, sizeof(omsg));
    }

     if (shcApp->acquirerShcParamsList && shcApp->acquirerShcParamsList->GetBool((char *)"shc.enable_back_office") ||
	shcApp->issuerShcParamsList && shcApp->issuerShcParamsList->GetBool((char *)"shc.enable_back_office"))
                back_office_flags = header->msg.shc_devcap & SH_DEVCAP_SHC_BO_MASK;

        if (back_office_flags)
        {
                devcap1 = back_office_flags;
                devcap = 0xffffffL;
        }
        else
                devcap = 0xffffffL;

        if(header->msg.trace > 0 && !excludeTraceInRefnum)
        {
                searchForTrace = 1;
                trace = shcApp->shcmsgHelperObj->shcMakeKeyLog(header);
        }

        memset(refnum,0x00,sizeof(refnum));
        snprintf(refnum,sizeof(refnum), "%12s", header->msg.refnum);

        memset(Pan,0x00,sizeof(Pan));
    memset(Pan1,0x00,sizeof(Pan1));
        memset(pan_tok1,0x00,sizeof(pan_tok1));
        memset(pan_tok2,0x00,sizeof(pan_tok2));

        int tkn_ret = generatePanCondTokens(header->msg.pan, pan_tok1, pan_tok2);
        if(tkn_ret != 0)
                 return -1;

        memcpy(Pan,pan_tok1,sizeof(Pan));
        memcpy(Pan1,pan_tok2,sizeof(Pan1));

        if(strlen(Pan1) > 0)
                searchForPanRange = 1;

        memset(fd,0,sizeof(fd));
        memset(tmpfd,0,sizeof(tmpfd));
    if (((flag  & IST_SHCLOG_FLAG_LOCATE_REQ  && flag & IST_SHCLOG_FLAG_LOCATE_RESP)) ||
        (!(flag & IST_SHCLOG_FLAG_LOCATE_REQ) && !(flag & IST_SHCLOG_FLAG_LOCATE_RESP)) )
    {
        tmpfd[0] = shclogAvlb;
        tmpfd[1] = shclogreqAvlb;
                fd[0] = shclogfd;
                fd[1] = shclogreqfd;

        OTraceDebug("D-SHCLOG-5108:Search RESP/REQ\n");
    }
    else if (flag & IST_SHCLOG_FLAG_LOCATE_REQ)
    {
        tmpfd[0] = shclogreqAvlb;
        tmpfd[1] = -1;
                fd[0] = shclogreqfd;
                fd[1] = -1;
        OTraceDebug("D-SHCLOG-5108:Search REQ\n");
    }
    else if (flag & IST_SHCLOG_FLAG_LOCATE_RESP)
    {
        tmpfd[0] = shclogAvlb;
        tmpfd[1] = -1;
                fd[0] = shclogfd;
                fd[1] = -1;
        OTraceDebug("D-SHCLOG-5109:Search RESP\n");
    }

    for (i = 0; i < 2 && tmpfd[i] != -1; i++)
    {
        /* R001319 Change this to find a match in device_cap */
        internalrev = header->msg.device_cap & SH_DEVCAP_INTERNALREV;

                if(     tmpfd[i] == shclogAvlb)
                {
                        if ((searchForTrace) && (back_office_flags))
                        {
                                if(searchForPanRange)
                                {
                    _smtShcLogAllP->execute();
                    rc = _smtShcLogAllP->fetch();
                    _smtShcLogAllP->close();
                                }
                                else
                                {
                                        _smtShcLogAll->execute();
                                        rc = _smtShcLogAll->fetch();
                                        _smtShcLogAll->close();
                                }
                        }
                        else if(searchForTrace)
                        {
                                if(searchForPanRange)
                                {
                    _smtShcLogTraceP->execute();
                    rc = _smtShcLogTraceP->fetch();
                    _smtShcLogTraceP->close();
                                }
                                else
                                {
                                        _smtShcLogTrace->execute();
                                        rc = _smtShcLogTrace->fetch();
                                        _smtShcLogTrace->close();
                                }
                        }
                        else if (back_office_flags)
                        {
                if(searchForPanRange)
                {
                    _smtShcLogBkOffP->execute();
                    rc = _smtShcLogBkOffP->fetch();
                    _smtShcLogBkOffP->close();
                                }
                                else
                                {
                                        _smtShcLogBkOff->execute();
                                        rc = _smtShcLogBkOff->fetch();
                                        _smtShcLogBkOff->close();
                                }
                        }
                        else
                        {
                if(searchForPanRange)
                {
                    _smtShcLogP->execute();
                    rc = _smtShcLogP->fetch();
                    _smtShcLogP->close();
                }
                else
                {
                                        _smtShcLog->execute();
                                        rc = _smtShcLog->fetch();
                                        _smtShcLog->close();
                                }
                        }

                }
                else if( tmpfd[i] == shclogreqAvlb)
                {
                        if ((searchForTrace) && (back_office_flags))
                        {
                if(searchForPanRange)
                {
                    _smtShcLogReqAllP->execute();
                    rc = _smtShcLogReqAllP->fetch();
                    _smtShcLogReqAllP->close();
                }
                else
                {
                                        _smtShcLogReqAll->execute();
                                        rc = _smtShcLogReqAll->fetch();
                                        _smtShcLogReqAll->close();
                                }
                        }
                        else if (searchForTrace)
                        {
                if(searchForPanRange)
                {
                        _smtShcLogReqTraceP->execute();
                        rc = _smtShcLogReqTraceP->fetch();
                        _smtShcLogReqTraceP->close();
                                }
                                else
                                {
                                        _smtShcLogReqTrace->execute();
                                        rc = _smtShcLogReqTrace->fetch();
                                        _smtShcLogReqTrace->close();
                                }
                        }
                        else if (back_office_flags)
                        {
                if(searchForPanRange)
                {
                    _smtShcLogReqBkOffP->execute();
                    rc = _smtShcLogReqBkOffP->fetch();
                    _smtShcLogReqBkOffP->close();
                }
                else
                {
                                        _smtShcLogReqBkOff->execute();
                                        rc = _smtShcLogReqBkOff->fetch();
                                        _smtShcLogReqBkOff->close();
                                }
                        }
                        else
                        {
                if(searchForPanRange)
                {
                    _smtShcLogReqP->execute();
                    rc = _smtShcLogReqP->fetch();
                    _smtShcLogReqP->close();
                }
                else
                {
                                        _smtShcLogReq->execute();
                                        rc = _smtShcLogReq->fetch();
                                        _smtShcLogReq->close();
                                }
                        }

                }
			 OTraceDebug(
            "D-SHCLOG-62000: globals(before): shclogfd[%d] shclogfd_refnum[%d] shclogfd_logID[%d] shcloginsertfd[%d] "
            "shclogreqfd[%d] shclogreqfd_refnum[%d] shclogreqfd_logID[%d] shclogreqinsertfd[%d]\n",
            shclogfd, shclogfd_refnum, shclogfd_logID, shcloginsertfd,
            shclogreqfd, shclogreqfd_refnum, shclogreqfd_logID, shclogreqinsertfd
        );
                                shclogfd = fd[0];
                                shclogfd_refnum = fd[0];
                                shclogfd_logID = fd[0];
                                shcloginsertfd = fd[0];
				if (fd[1] != -1) 
				{
					shclogreqfd = fd[1];
					shclogreqfd_refnum = fd[1];
					shclogreqfd_logID = fd[1];
					shclogreqinsertfd = fd[1];
				}
			 OTraceDebug(
            "D-SHCLOG-62000: globals(after): shclogfd[%d] shclogfd_refnum[%d] shclogfd_logID[%d] shcloginsertfd[%d] "
            "shclogreqfd[%d] shclogreqfd_refnum[%d] shclogreqfd_logID[%d] shclogreqinsertfd[%d]\n",
            shclogfd, shclogfd_refnum, shclogfd_logID, shcloginsertfd,
            shclogreqfd, shclogreqfd_refnum, shclogreqfd_logID, shclogreqinsertfd
        );
                        _updateVoid = updateVoidFd;
                        _updateReversal = updateReversalFd;
                        _updateFinCapture = updateFinCaptureFd;
                        _updateRespcode = updateRespcode;
                        _dbConn = dbConnPtr;

        if (rc == DBM_NO_DATA)
        {
            OTraceDebug("D-SHCLOG-61001: No Record in shclog/shclogreq\n");
            continue;
        }
        else if( rc != DBM_SUCCESS )
        {
                        OTraceError("E-SHCLOG-61001:Cannot fetch from shclog/shclogreq\n");
            continue;
                }
                /* Check if the message type matches */ /* R008689 */
                if (shcApp->shclog_specified_msgtype && (shclog.msgtype/10 != shcApp->shclog_specified_msgtype/10))
                        continue;

                /* Check first digit of header and shclog msg type */
                if ((header->msg.msgtype/100) != (shclog.msgtype/100))
                                continue;

                ICInstId_pure(shclog.txndest, shclog.txndest);

                if (useTxnDestInShclogLocating && header->msg.txnDest[0] && (strcmp(shclog.txndest, header->msg.txnDest) != 0))
                {
                        OTraceDebug("D-SHCLOG-5047.2:txnDest[%s] does not match with original[%s]\n",header->msg.txnDest, shclog.txndest);
                        continue;
                }

                /* R015140 Check termid field when locating txn using refnum */
                if (header->msg.termid[0] && shclog.termid[0])
                {
                        //R031084 Triming Trailing Spaces for Terminal Id
                        id_len = strlen(shclog.termid)-1;
                        for (; id_len>=0 && shclog.termid[id_len] && shclog.termid[id_len] == ' '; id_len--);
                        shclog.termid[id_len+1]='\0';
                        id_len = 0;

                        char tmp_termid[9];
                        strcpy(tmp_termid, header->msg.termid);
                        strtrim(tmp_termid, tmp_termid);

                        if (strcmp(tmp_termid, shclog.termid)!=0)
                        {
                                OTraceInfo("I-SHCLOG-5066:termid don't match, in msg[%s], in table[%s]\n", header->msg.termid, shclog.termid);
                                continue;
                        }
                }
                /* R015140 end */

                // >>> R026977
                OTraceDebug("D-SHCLOG-5047: msg->msgtype=[%d] for repeat[%d]\n",
                                                        header->msg.msgtype, locate_for_repeat);
                if( locate_for_repeat && shclog.respcode == SHC_RC_DuplicateTransaction )
                                continue;

                //R028676 >>>
                if(shclog.shcerror == SHC_IE_SafReply || shclog.shcerror == SHC_IE_Duplicate)
                {
                        OTraceDebug("D-SHCLOG-5047.1: Ignoring txn with shclog.shcerror[%d]\n",shclog.shcerror);
                        continue;
                }
                //<<< R028676

                OTraceDebug("D-SHCLOG-5047: Final Found: log->msgtype[%d],log->respcode[%d]\n",shclog.msgtype,shclog.respcode);
                // <<< R026977

                /* R004207 Clean up the if statement a little bit */
                if(header->msg.msgtype / 100 != 4)
                /* End R004207 */
                {
                        OTraceDebug("D-SHCLOG-5048: Found: header->msg.msgtype:%d log->msgtype:%d\n",
                                        header->msg.msgtype, shclog.msgtype );
                        fill_message(oldmsg);
                        shclogLocateFd = fd[i];


                        //rewind(); //IST_S770SP5-146
                        return 0;
                }
                /* End R004165 */
                shc_data_ptr = (struct shc_data *)shclog.shc_data_buffer;
                device_cap_chk = shclog.device_cap;

                /* R004207 Clean up debug messages. */
                OTraceDebug("D-SHCLOG-5049:  Verify the internal reversal flag.\n");
                OTraceDebug("D-SHCLOG-5049: The message that SHC wants to locate has the internal reversal flag %s.\n", internalrev? "ON" : "OFF");
                OTraceDebug("D-SHCLOG-5049: The message that SHC got has the internal reversal flag %s.\n", (device_cap_chk & SH_DEVCAP_INTERNALREV)? "ON" : "OFF");
                /* End R004207 */

                if(internalrev == (device_cap_chk & SH_DEVCAP_INTERNALREV))
                {
                        /* R004207 Clean up debug messages. */
                        OTraceDebug("D-SHCLOG-5050:  Internal reversal flag matches.\n");
                        OTraceDebug("D-SHCLOG-5050: Found: header->msg.msgtype:%d log->msgtype:%d\n",
                                                 header->msg.msgtype, shclog.msgtype );
                        /* End R004207 */

                        fill_message(oldmsg);
                        shclogLocateFd = fd[i];
                        //rewind(); //IST_S770SP5-146
                        return 0;
                }

                /* R004207 Clean up debug messages. */
                OTraceDebug("D-SHCLOG-5051: Internal reversal flag does not match. Fetch the next record.\n");
                /* End R004207 */


    }
    OTraceWarning("W-SHC-032007: refnum: not found\n");

    //rewind(); //IST_S770SP5-146
    return(-1);
    /* End R001319 */
}

int generatePanCondTokens(char *pan, char *tok1, char *tok2)
{
        static Tokenizer *tkn_ptr = NULL;
        if (!tkn_ptr)
                        tkn_ptr = Tokenizer::create();

        int tkn_ret = tkn_ptr->getTokens(pan,tok1, tok2,false);
        if(tkn_ret != 0)
        {
                if (tkn_ret == Tokenizer::PAN_NOT_FOUND)
                {
                                OTraceDebug("D-SHCLOG-5005.1: PAN not found \n");
                }
                else
                {
                                OTraceError("E-SHCLOG-5005.1: Unable to tokenize Pan [%d]\n", tkn_ret);
                }
                return -1;
        }
        OTraceDebug("D-SHCLOG-5005.1: Tokenized PAN [%s]\n",strcmp(pan,tok1)? tok1:shc_maskpan(tok1));

        return 0;
}

int ShcLog::doBindCol(DBMStmt* stmt)
{
    int sno = 1;
    int cnt = 0;

        memset(_ind,0,sizeof(_ind));
        stmt->bindCol(  sno++, DBM_LONGTYPE, &shclog.msgtype, sizeof(shclog.msgtype), &_ind[cnt++] );
        stmt->bindCol(  sno++, DBM_LONGTYPE, &shclog.flipped_msgtype, sizeof(shclog.flipped_msgtype), &_ind[cnt++] );
        stmt->bindCol(  sno++, DBM_PANTOKENTYPE, shclog.pan, sizeof(shclog.pan), NULL );
        stmt->bindCol(  sno++, DBM_STRINGTYPE, shclog.mask_pan, sizeof(shclog.mask_pan), &_ind[cnt++] );
        stmt->bindCol(  sno++, DBM_LONGTYPE, &shclog.pcode, sizeof(shclog.pcode), &_ind[cnt++] );
        stmt->bindCol(  sno++, DBM_LONGTYPE, &shclog.txntype, sizeof(shclog.txntype), &_ind[cnt++] );
        stmt->bindCol(  sno++, DBM_MONEYTYPE,&shclog.amount, sizeof(shclog.amount), &_ind[cnt++] );
        stmt->bindCol(  sno++, DBM_MONEYTYPE,&shclog.aval_balance, sizeof(shclog.aval_balance), &_ind[cnt++] );
        stmt->bindCol(  sno++, DBM_MONEYTYPE,&shclog.amount_equiv, sizeof(shclog.amount_equiv), &_ind[cnt++] );
        stmt->bindCol(  sno++, DBM_MONEYTYPE,&shclog.cash_back, sizeof(shclog.cash_back), &_ind[cnt++] );
        stmt->bindCol(  sno++, DBM_MONEYTYPE,&shclog.iss_conv_rate, sizeof(shclog.iss_conv_rate), &_ind[cnt++] );
        stmt->bindCol(  sno++, DBM_INTTYPE, &shclog.iss_currency_code, sizeof(shclog.iss_currency_code), &_ind[cnt++] );
        stmt->bindCol(  sno++, DBM_DATETYPE, &shclog.iss_conv_date,sizeof(shclog.iss_conv_date), &_ind[cnt++] );
        stmt->bindCol(  sno++, DBM_MONEYTYPE,&shclog.acq_conv_rate, sizeof(shclog.acq_conv_rate), &_ind[cnt++] );
        stmt->bindCol(  sno++, DBM_INTTYPE, &shclog.acq_currency_code, sizeof(shclog.acq_currency_code), &_ind[cnt++] );
        stmt->bindCol(  sno++, DBM_DATETYPE, &shclog.acq_conv_date, sizeof(shclog.acq_conv_date), &_ind[cnt++] );
        stmt->bindCol(  sno++, DBM_MONEYTYPE,&shclog.tra_amount, sizeof(shclog.tra_amount), &_ind[cnt++] );
        stmt->bindCol(  sno++, DBM_MONEYTYPE,&shclog.tra_conv_rate, sizeof(shclog.tra_conv_rate), &_ind[cnt++] );
        stmt->bindCol(  sno++, DBM_INTTYPE, &shclog.tra_currency_code, sizeof(shclog.tra_currency_code), &_ind[cnt++] );
        stmt->bindCol(  sno++, DBM_DATETYPE, &shclog.tra_conv_date, sizeof(shclog.tra_conv_date), &_ind[cnt++] );
        stmt->bindCol(  sno++, DBM_MONEYTYPE,&shclog.fee, sizeof(shclog.fee), &_ind[cnt++] );
        stmt->bindCol(  sno++, DBM_MONEYTYPE,&shclog.new_fee, sizeof(shclog.new_fee), &_ind[cnt++] );
        stmt->bindCol(  sno++, DBM_MONEYTYPE,&shclog.new_amount, sizeof(shclog.new_amount), &_ind[cnt++] );
        stmt->bindCol(  sno++, DBM_MONEYTYPE,&shclog.new_setl_amount, sizeof(shclog.new_setl_amount), &_ind[cnt++] );
        stmt->bindCol(  sno++, DBM_MONEYTYPE,&shclog.settlement_fee, sizeof(shclog.settlement_fee), &_ind[cnt++] );
        stmt->bindCol(  sno++, DBM_MONEYTYPE,&shclog.settlement_rate, sizeof(shclog.settlement_rate), &_ind[cnt++] );
        stmt->bindCol(  sno++, DBM_INTTYPE, &shclog.settlement_code, sizeof(shclog.settlement_code), &_ind[cnt++] );
        stmt->bindCol(  sno++, DBM_MONEYTYPE,&shclog.settlement_amount, sizeof(shclog.settlement_amount), &_ind[cnt++] );
        stmt->bindCol(  sno++, DBM_DATETYPE, &shclog.trandate, sizeof(shclog.trandate), &_ind[cnt++] );
        stmt->bindCol(  sno++, DBM_LONGTYPE, &shclog.trantime, sizeof(shclog.trantime), &_ind[cnt++] );
        stmt->bindCol(  sno++, DBM_LONGTYPE, &shclog.trace, sizeof(shclog.trace), &_ind[cnt++] );
        stmt->bindCol(  sno++, DBM_LONGTYPE, &shclog.local_time, sizeof(shclog.local_time), &_ind[cnt++] );
        stmt->bindCol(  sno++, DBM_DATETYPE, &shclog.local_date, sizeof(shclog.local_date), &_ind[cnt++] );
        stmt->bindCol(  sno++, DBM_DATETYPE, &shclog.settlement_date, sizeof(shclog.settlement_date), &_ind[cnt++] );
        stmt->bindCol(  sno++, DBM_DATETYPE, &shclog.cap_date, sizeof(shclog.cap_date), &_ind[cnt++] );
        stmt->bindCol(  sno++, DBM_INTTYPE, &shclog.pos_entry_code, sizeof(shclog.pos_entry_code), &_ind[cnt++] );
        stmt->bindCol(  sno++, DBM_INTTYPE, &shclog.pos_condition_code, sizeof(shclog.pos_condition_code), &_ind[cnt++] );
        stmt->bindCol(  sno++, DBM_CHARTYPE,&shclog.pos_pin_cap_code, sizeof(shclog.pos_pin_cap_code), &_ind[cnt++] );
        stmt->bindCol(  sno++, DBM_INTTYPE, &shclog.pos_cap_code, sizeof(shclog.pos_cap_code), &_ind[cnt++] );
        stmt->bindCol(  sno++, DBM_LONGTYPE, &shclog.life_cycle, sizeof(shclog.life_cycle), &_ind[cnt++] );
        stmt->bindCol(  sno++, DBM_STRINGTYPE, shclog.acquirer, sizeof(shclog.acquirer), &_ind[cnt++] );
        stmt->bindCol(  sno++, DBM_STRINGTYPE, shclog.issuer, sizeof(shclog.issuer), &_ind[cnt++] );
        stmt->bindCol(  sno++, DBM_STRINGTYPE, shclog.transferee, sizeof(shclog.transferee), &_ind[cnt++] );
        stmt->bindCol(  sno++, DBM_STRINGTYPE, shclog.originator, sizeof(shclog.originator), &_ind[cnt++] );
        stmt->bindCol(  sno++, DBM_STRINGTYPE, shclog.member_id, sizeof(shclog.member_id), &_ind[cnt++] );
        stmt->bindCol(  sno++, DBM_STRINGTYPE, shclog.f_id, sizeof(shclog.f_id), &_ind[cnt++] );
        stmt->bindCol(  sno++, DBM_STRINGTYPE, shclog.txnsrc, sizeof(shclog.txnsrc), &_ind[cnt++] );
        stmt->bindCol(  sno++, DBM_STRINGTYPE, shclog.txndest, sizeof(shclog.txndest), &_ind[cnt++] );
        stmt->bindCol(  sno++, DBM_STRINGTYPE, shclog.alternateacquirer, sizeof(shclog.alternateacquirer), &_ind[cnt++] );
        stmt->bindCol(  sno++, DBM_STRINGTYPE, shclog.entityid, sizeof(shclog.entityid), &_ind[cnt++] );
        stmt->bindCol(  sno++, DBM_STRINGTYPE, shclog.iss_entityid, sizeof(shclog.iss_entityid), &_ind[cnt++] );
        stmt->bindCol(  sno++, DBM_STRINGTYPE, shclog.cardproduct, sizeof(shclog.cardproduct), &_ind[cnt++] );
        stmt->bindCol(  sno++, DBM_STRINGTYPE, shclog.mvv, sizeof(shclog.mvv), &_ind[cnt++] );
        stmt->bindCol(  sno++, DBM_STRINGTYPE, shclog.invoice_number, sizeof(shclog.invoice_number), &_ind[cnt++] );
        stmt->bindCol(  sno++, DBM_STRINGTYPE, shclog.trans_id, sizeof(shclog.trans_id), &_ind[cnt++] );
        stmt->bindCol(  sno++, DBM_STRINGTYPE, shclog.fpi, sizeof(shclog.fpi), &_ind[cnt++] );
        stmt->bindCol(  sno++, DBM_LONGTYPE, &shclog.txn_start_time, sizeof(shclog.txn_start_time), &_ind[cnt++] );
        stmt->bindCol(  sno++, DBM_LONGTYPE, &shclog.txn_end_time, sizeof(shclog.txn_end_time), &_ind[cnt++] );
        stmt->bindCol(  sno++, DBM_LONGTYPE, &shclog.device_cap, sizeof(shclog.device_cap), &_ind[cnt++] );
        stmt->bindCol(  sno++, DBM_LONGTYPE, &shclog.respcode, sizeof(shclog.respcode), &_ind[cnt++] );
        stmt->bindCol(  sno++, DBM_LONGTYPE, &shclog.reason_code, sizeof(shclog.reason_code), &_ind[cnt++] );
        stmt->bindCol(  sno++, DBM_LONGTYPE, &shclog.revcode, sizeof(shclog.revcode), &_ind[cnt++] );
        stmt->bindCol(  sno++, DBM_LONGTYPE, &shclog.shcerror, sizeof(shclog.shcerror), &_ind[cnt++] );
        stmt->bindCol(  sno++, DBM_INTTYPE, &shclog.saf, sizeof(shclog.saf), &_ind[cnt++] );
        stmt->bindCol(  sno++, DBM_INTTYPE, &shclog.origmsg, sizeof(shclog.origmsg), &_ind[cnt++] );
        stmt->bindCol(  sno++, DBM_INTTYPE, &shclog.origflippedmsg, sizeof(shclog.origflippedmsg), &_ind[cnt++] );
        stmt->bindCol(  sno++, DBM_LONGTYPE, &shclog.origtrace, sizeof(shclog.origtrace), &_ind[cnt++] );
        stmt->bindCol(  sno++, DBM_DATETYPE, &shclog.origdate, sizeof(shclog.origdate), &_ind[cnt++] );
        stmt->bindCol(  sno++, DBM_LONGTYPE, &shclog.origtime, sizeof(shclog.origtime), &_ind[cnt++] );
        stmt->bindCol(  sno++, DBM_INTTYPE, &shclog.merchant_type, sizeof(shclog.merchant_type), &_ind[cnt++] );
        stmt->bindCol(  sno++, DBM_INTTYPE, &shclog.acq_country, sizeof(shclog.acq_country), &_ind[cnt++] );
        stmt->bindCol(  sno++, DBM_STRINGTYPE, shclog.refnum, sizeof(shclog.refnum), &_ind[cnt++] );
        stmt->bindCol(  sno++, DBM_STRINGTYPE, shclog.authnum, sizeof(shclog.authnum), &_ind[cnt++] );
        stmt->bindCol(  sno++, DBM_STRINGTYPE, shclog.termid, sizeof(shclog.termid), &_ind[cnt++] );
        stmt->bindCol(  sno++, DBM_STRINGTYPE, shclog.acceptorname, sizeof(shclog.acceptorname), &_ind[cnt++] );
        stmt->bindCol(  sno++, DBM_STRINGTYPE, shclog.termloc, sizeof(shclog.termloc), &_ind[cnt++] );
        stmt->bindCol(  sno++, DBM_STRINGTYPE, shclog.addresponse, sizeof(shclog.addresponse), &_ind[cnt++] );
        stmt->bindCol(  sno++, DBM_STRINGTYPE, shclog.acctnum, sizeof(shclog.acctnum), &_ind[cnt++] );
        stmt->bindCol(  sno++, DBM_INTTYPE, &shclog.branch, sizeof(shclog.branch), &_ind[cnt++] );
        stmt->bindCol(  sno++, DBM_LONGTYPE, &shclog.serial_1, sizeof(shclog.serial_1), &_ind[cnt++] );
        stmt->bindCol(  sno++, DBM_LONGTYPE, &shclog.serial_2, sizeof(shclog.serial_2), &_ind[cnt++] );
        stmt->bindCol(  sno++, DBM_LONGTYPE, &shclog.storeid, sizeof(shclog.storeid), &_ind[cnt++] );
        stmt->bindCol(  sno++, DBM_LONGTYPE, &shclog.lane, sizeof(shclog.lane), &_ind[cnt++] );
        stmt->bindCol(  sno++, DBM_LONGTYPE, &shclog.terminal_trace, sizeof(shclog.terminal_trace), &_ind[cnt++] );
        stmt->bindCol(  sno++, DBM_LONGTYPE, &shclog.checker_id, sizeof(shclog.checker_id), &_ind[cnt++] );
        stmt->bindCol(  sno++, DBM_LONGTYPE, &shclog.supervisor, sizeof(shclog.supervisor), &_ind[cnt++] );
        stmt->bindCol(  sno++, DBM_LONGTYPE, &shclog.shift_number, sizeof(shclog.shift_number), &_ind[cnt++] );
        stmt->bindCol(  sno++, DBM_LONGTYPE, &shclog.batch_id, sizeof(shclog.batch_id), &_ind[cnt++] );
        stmt->bindCol(  sno++, DBM_LONGTYPE, &shclog.device_devcap, sizeof(shclog.device_devcap), &_ind[cnt++] );
        stmt->bindCol(  sno++, DBM_LONGTYPE, &shclog.shc_devcap, sizeof(shclog.shc_devcap), &_ind[cnt++] );
        stmt->bindCol(  sno++, DBM_LONGTYPE, &shclog.formatter_devcap, sizeof(shclog.formatter_devcap), &_ind[cnt++] );
        stmt->bindCol(  sno++, DBM_LONGTYPE, &shclog.auth_devcap, sizeof(shclog.auth_devcap), &_ind[cnt++] );
        stmt->bindCol(  sno++, DBM_STRINGTYPE, shclog.filler1, sizeof(shclog.filler1), &_ind[cnt++] );
        stmt->bindCol(  sno++, DBM_STRINGTYPE, shclog.filler2, sizeof(shclog.filler2), &_ind[cnt++] );
        stmt->bindCol(  sno++, DBM_STRINGTYPE, shclog.filler3, sizeof(shclog.filler3), &_ind[cnt++] );
        stmt->bindCol(  sno++, DBM_STRINGTYPE, shclog.filler4, sizeof(shclog.filler4), &_ind[cnt++] );
        stmt->bindCol(  sno++, DBM_STRINGTYPE, shclog.issuer_data, sizeof(shclog.issuer_data), &_ind[cnt++] );
        stmt->bindCol(  sno++, DBM_STRINGTYPE, shclog.acquirer_data, sizeof(shclog.acquirer_data), &_ind[cnt++] );
        stmt->bindCol(  sno++, DBM_MONEYTYPE,&shclog.new_amount_equiv, sizeof(shclog.new_amount_equiv), &_ind[cnt++] );
        stmt->bindCol(  sno++, DBM_MONEYTYPE,&shclog.acq_aval_balance, sizeof(shclog.acq_aval_balance), &_ind[cnt++] );
        stmt->bindCol(  sno++, DBM_MONEYTYPE,&shclog.acq_ledger_balance, sizeof(shclog.acq_ledger_balance), &_ind[cnt++] );
        stmt->bindCol(  sno++, DBM_MONEYTYPE,&shclog.setl_aval_balance, sizeof(shclog.setl_aval_balance), &_ind[cnt++] );
        stmt->bindCol(  sno++, DBM_MONEYTYPE,&shclog.setl_ledger_balance, sizeof(shclog.setl_ledger_balance), &_ind[cnt++] );
        stmt->bindCol(  sno++, DBM_INTTYPE, &shclog.aval_balance_type, sizeof(shclog.aval_balance_type), &_ind[cnt++] );
        stmt->bindCol(  sno++, DBM_INTTYPE, &shclog.ledger_balance_type, sizeof(shclog.ledger_balance_type), &_ind[cnt++] );
        stmt->bindCol(  sno++, DBM_MONEYTYPE,&shclog.new_setl_fee, sizeof(shclog.new_setl_fee), &_ind[cnt++] );
        stmt->bindCol(  sno++, DBM_MONEYTYPE,&shclog.txn_amount, sizeof(shclog.txn_amount), &_ind[cnt++] );
        stmt->bindCol(  sno++, DBM_MONEYTYPE,&shclog.txn_new_amount, sizeof(shclog.txn_new_amount), &_ind[cnt++] );
        stmt->bindCol(  sno++, DBM_INTTYPE, &shclog.txn_currency_code, sizeof(shclog.txn_currency_code), &_ind[cnt++] );
        stmt->bindCol(  sno++, DBM_MONEYTYPE,&shclog.txn_conv_rate, sizeof(shclog.txn_conv_rate), &_ind[cnt++] );
        stmt->bindCol(  sno++, DBM_DATETYPE, &shclog.txn_conv_date, sizeof(shclog.txn_conv_date), &_ind[cnt++] );
        stmt->bindCol(  sno++, DBM_MONEYTYPE,&shclog.ch_amount, sizeof(shclog.ch_amount), &_ind[cnt++] );
        stmt->bindCol(  sno++, DBM_MONEYTYPE,&shclog.ch_new_amount, sizeof(shclog.ch_new_amount), &_ind[cnt++] );
        stmt->bindCol(  sno++, DBM_INTTYPE, &shclog.ch_currency_code, sizeof(shclog.ch_currency_code), &_ind[cnt++] );
        stmt->bindCol(  sno++, DBM_MONEYTYPE,&shclog.ch_conv_rate, sizeof(shclog.ch_conv_rate), &_ind[cnt++] );
        stmt->bindCol(  sno++, DBM_DATETYPE, &shclog.ch_conv_date, sizeof(shclog.ch_conv_date), &_ind[cnt++] );
        stmt->bindCol(  sno++, DBM_MONEYTYPE,&shclog.ledger_balance, sizeof(shclog.ledger_balance), &_ind[cnt++] );
        stmt->bindCol(  sno++, DBM_INTTYPE, &shclog.slot_num, sizeof(shclog.slot_num), &_ind[cnt++] );
        stmt->bindCol(  sno++, DBM_MONEYTYPE,&shclog.device_fee, sizeof(shclog.device_fee), &_ind[cnt++] );
		stmt->bindCol(  sno++, DBM_BINTYPE, shclog.shc_data_buffer, sizeof(shclog.shc_data_buffer),&_ind[cnt++] );
        stmt->bindCol(  sno++, DBM_INTTYPE, &shclog.card_seqno, sizeof(shclog.card_seqno), &_ind[cnt++] );
        stmt->bindCol(  sno++, DBM_STRINGTYPE, shclog.alpharesponsecode, sizeof(shclog.alpharesponsecode), &_ind[cnt++] );
        stmt->bindCol(  sno++, DBM_CHARTYPE, &shclog.chip_type, sizeof(shclog.chip_type), &_ind[cnt++] );
        stmt->bindCol(  sno++, DBM_STRINGTYPE, shclog.chip_index, sizeof(shclog.chip_index), &_ind[cnt++] );
        stmt->bindCol(  sno++, DBM_DATETYPE, &shclog.processor_busday, sizeof(shclog.processor_busday), &_ind[cnt++] );
        stmt->bindCol(  sno++, DBM_LONGTYPE, &shclog.seq_trace_no, sizeof(shclog.seq_trace_no), &_ind[cnt++] );
        stmt->bindCol(  sno++, DBM_BINTYPE, shclog.seg_req, sizeof(shclog.seg_req),&_ind[cnt++] );
        stmt->bindCol(  sno++, DBM_BINTYPE, shclog.seg_resp, sizeof(shclog.seg_resp),&_ind[cnt++] );
        stmt->bindCol(  sno++, DBM_INTTYPE, &shclog.site_id, sizeof(shclog.site_id), &_ind[cnt++] );
        stmt->bindCol(  sno++, DBM_INTTYPE, &shclog.version, sizeof(shclog.version), &_ind[cnt++] );
        stmt->bindCol(  sno++, DBM_INTTYPE, &shclog.src_node, sizeof(shclog.src_node), &_ind[cnt++] );
        stmt->bindCol(  sno++, DBM_INTTYPE, &shclog.dest_node, sizeof(shclog.dest_node), &_ind[cnt++] );
	stmt->bindCol(  sno++, DBM_INTTYPE, &shclog.gateway_id, sizeof(shclog.gateway_id), &_ind[cnt++] );
	stmt->bindCol(  sno++, DBM_STRINGTYPE, shclog.submerchant_id, sizeof(shclog.submerchant_id), &_ind[cnt++] );
	stmt->bindCol(  sno++, DBM_STRINGTYPE, shclog.dest_id, sizeof(shclog.dest_id), &_ind[cnt++] );
	stmt->bindCol(  sno++, DBM_STRINGTYPE, shclog.payfacid, sizeof(shclog.payfacid), &_ind[cnt++] );
        return 0;
}

