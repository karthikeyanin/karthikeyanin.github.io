/*
 *  Copyright (C) 2004 eFunds Corporation ("eFunds").  All Rights Reserved.
 *  eFunds Canada Corporation is an authorized user.
 *
 *  IST is a registered trademark of eFunds Corporation.  Other brand or
 *  product names are trademarks or registered trademarks of their respective
 *  holders.
 *
 *  The information contained herein is the unpublished proprietary property
 *  of eFunds.  Except as specifically authorized in writing by eFunds, the
 *  holder of this document shall: i) keep all information contained herein
 *  confidential, and ii) protect the information, in whole or in part, from
 *  disclosure and dissemination to all third parties.
 *
 *  This document and the software described in it are furnished under license
 *  and may be used or copied only in accordance with the terms of such license.
 *  This document is supplied for information purposes only, is subject to
 *  change without notice, and should not be construed as a commitment by
 *  either eFunds Corporation or eFunds Canada Corporation.
 *                        MODIFICATION HISTORY                  REVIEW
 *
 *	SPR#	Who	Date	Description			Who	Date
 * ===========================================================================
 * R0xxxxx
 * R014503     rzhou   08Aug05  Restored settlement fields
 * R015306     sdc     19Dec05  Don't send recon message to shc500std if recon flag is not set
 * R015807  Emj 08Mar06 Check if original was partial approval
 * R016378 jyang 08May06 Send notification message once only
 * R000000 jyang 17Oct06 Safdb support in dswitch
 * R018687 Emj   22Jan07 Dump chip data if EMV_BUF segment present
 * R018832 spa	 06Feb07 Restore issuer field from original message
 * R020162 Emj   01Jun07 DCVV/ICVV/CVC3/SCVC3 validation
 * R020295 spa   14Jun07 Restore issuer field from original only if shc.restoreIssuerForReversal is set
 * R020452 pve	 28Jun07 Deny txn when the cvv_resultcode is 'E'
 * R020622 spa	 13Jul07 Restore SH_DEVCAP_SHC_PIN_BASED flag from original shc_devcap
 * R021024 bby   27Aug07 PAN/CVV/CVV2/Track2 Masking
 * R022575 Sel   11Feb08 Check Duplicate Transaction control is working for all the cases in IST/Switch
 * R023231 Ram 	 23May08 The SDK header should refer to external header
 * R025885 las   05Feb08 Visa Spring Compliance - Changes to ATM Processing and International ATM Cash
 * R026116 sks   02Mar09 Restore cap_date field from original
 * R026151 sks	 05Mar09 Changes in shc_restoreOriginal() for cap_date field
 * R026255 vmp	 23Mar09 restore card_seqno from Origianl msg if it is card_seqno < 0 in reversal 
 * R027263 dipa  22Sep09 restore pos_cap_code from Origianl msg in reversal 
 * R027876 dipa  02Mar10 Segment changes
 * R027905 dipa  25Mar10 Reversal-Void Enhancement
 * R028271 dipa  18Jun10 Txn Statistics
 * R029153 sks	 22Mar11 Restore trans_id from org txn response
 * R030207 dipa  01Feb12 Clone of USP-1609
 * R030381 dipa  10Mar12 Txn statistics - changes
 * R031154 dipa  21Dec12 Clone of R031066
 * IST_S770SP4-53 dipa 05Oct15 shc_checkCsc() API fixed so that it doesnt overwrite cvv_resultcode 
 */

//"@(#) ShcmsgHelper1.cxx 1.53.28.1 20/05/15 14:30:31";
//File Number 31

#include <stdio.h>
#include <oasis.h>
#include <mb.h>
#include <oasisenv.h>
#include <ic/ic_types.h>  /* R001835 */
#include <tm.h>
#include <ShcSender.h>
#include <ShcMsgCache.h>

#include <rules.h>
#include <ist_otrace.h>
#include <ctype.h>
#include <multi_institution.h>
#include <security.h>
#include <ist_modulus.h>

#include <CShcLog.h>
#include <ShcDKEHelper.h>
#include <ShcKeyHelper.h>

#include <ShcSdkCommon.h>
#include <ShcTimerHelper.h>
#include <ShcSafIOHelper.h>
#include <ShcMacHelper.h>
#include <CShcNotify.h>
#include <shc_callback.h>
#include <ShcAppBase.h>
#include <InstProfile.h>
#include <ShcBin.h>


#include <ShcHelper.h>	//	---	R023231
#include <ShcmsgHelper.h>
#include <CShcGenericLog.h>	//	R015826
#include <ist_seg_name.h> //R027876
#include <ist_seg_elf_id_map.h> //R027876
#include <ist_seg_id.h> //R027876
#include <istsafe.h>

//R028271 >>>
#include <TxnStat.h>
//<<< R028271
#include<ShcDuplicateChk.h>

/*****************************************************************************/

int ShcmsgHelper::shc_checkscode(ShcmsgHeader *header)
{
	/*
	 *	Check the service code on the card
	 */
	int 	scode, pcode;
	char	strscode[5];
	int		posEntryMode = (header->msg.pos_entry_code & SH_POS_PINPANENTRY_MASK)/10;

	/*
	 *	If the serivce code is to be checked then a Card record
	 *	must have been created. Otherwise a denial is returned
	 */

	if(header->issShcBin->pin == NULL)
	{
		OTraceError("E-SHC-031001:Attempt to check scode but no track data. Trace %ld issuer %s\n",
			header->msg.trace, header->msg.issuer);

		header->msg.respcode = SHC_RC_UnableToProcess;
		return(-1);
	}

	memcpy(strscode, header->pindata + header->issShcBin->pin->scodeoffset, 3);
	strscode[3] = '\0';
	scode = atoi(strscode);
	pcode = header->msg.pcode / 10000;

	// >>> IST_S761SP19-42 >>>
	if(shcApp->issuerShcParamsList->GetBool((char *)"shc.checkServiceCode"))
	{
		OTraceDebug("D-SHC-031026:Service code check param enabled, service code [%d], posEntryMode [%d]\n", scode, posEntryMode);
		switch(scode)
		{
			case 000:
			case 999:
				if((posEntryMode == SH_POS_PANENTRY_TRK1OR2) || (posEntryMode == SH_POS_PANENTRY_MAGSTRIP) || (posEntryMode == SH_POS_PANENTRY_CONTACTLESS_MAGSTRIP))
				{
					header->msg.respcode = SHC_RC_TransactionNotAllowed;
					return(-1);
				}
				else 
				{
					return 0;
				}
			case	120:
			case	520:
				if(!shc_txn_has_pin(header))
				{
					header->msg.respcode = SHC_RC_TransactionNotAllowed;
					return(-1);
				}
				else
				{
					return 0;
				}
		}
	}
	// <<< IST_S761SP19-42 <<<

	switch(scode){
	case	101:
	case	501:
		/*	Visa standard: Unrestricted card */
		return(0);

	case	102:
	case	502:
		/*	Visa standard: International: Goods and Services Only */
		if(pcode == SH_ISO_G_AND_S || pcode == SH_ISO_G_AND_S_CASH ||
		   pcode == SH_ISO_PURCH_RETURN)
			return(0);
		else
		{
			header->msg.respcode = SHC_RC_TransactionNotAllowed;
			return(-1);
		}

	case	120:
	case	520:
		/*	Visa standard: International: Must have a PIN */
		/*	22dec93 ****	removed
		if(!shc_txn_has_pin(header))
		{
			header->msg.respcode = SHC_RC_TransactionNotAllowed;
			return(-1);
		}
		else
		*/

		return(0);

	case	799:
		return(0);

	}

	return(0);
}

/*****************************************************************************/

int ShcmsgHelper::shc_verify_check_digit(ShcmsgHeader *header)
{
	/*
	 *	Verify the check digit on this account
	 */
	char	acct[30] = {0};
	char	*p = NULL;

	strcpy(acct, header->msg.pan);

    /* R005871 >> truncate trail spaces */
    for( p = acct+strlen(acct)-1; *p==' ' && p>=acct; p--);
    *(p+1) = '\0';
    /* R005871 << */

	for( p = acct; *p && *p == '0'; p++);		/* skip lead 0's */

	if(verify_mod10(p))
		return(1);
	else
	{
		OTraceError("E-SHC-031002:Check digit failed for '%s'\n", shcApp->shcHelperObj->shc_maskpan(p));
		return(0);
	}
}

/*****************************************************************************/

int ShcmsgHelper::shc_checkduptxn(ShcmsgHeader *header)
{
	/* R004832, R004686 >> */ /* (check duplication for Europay 100 txn ) */
	if( header->msg.msgtype==SHC_AUTHREQ && shc_isEuroAcquirer(header) )
		return ( shc_chkEuropayDupTxn(header) ? True : False);

	/* R004832, R004686 << */
        int result=shcDuplicateChkObj->check(header);
        if(result==1)
        return 1;
        else
        return 0;
}


/*****************************************************************************/

		/* R005887 >> */
int ShcmsgHelper::shc_setCvvResultCode( ShcmsgHeader *header, char val )
{
	struct shc_data *ptr_shc_data;

	if( header == NULL )
		return ( -1 );

	ptr_shc_data = (struct shc_data *)header->msg.shc_data_buffer;
	ptr_shc_data->cvv2_resultcode = val;

	return ( 0 );
}

/*****************************************************************************/

/* This function actually return cvv2 result code */
char ShcmsgHelper::shc_getCvvResultCode(ShcmsgHeader *header )
{
	struct shc_data *ptr_shc_data;

	ptr_shc_data = (struct shc_data *)header->msg.shc_data_buffer;
	return( ptr_shc_data->cvv2_resultcode );
}
/*****************************************************************************/

int ShcmsgHelper::shc_checkCvvCvv2( ShcmsgHeader *header )
{
	struct shc_data *ptr_shc_data_buffer;
	int iRes=0;
	char buf[2];

	//	>>>	R021024
	char localbuf[SHC_TRACK2_LEN+1];
	memset(localbuf, '*', strlen(header->msg.track2));
	localbuf[strlen(header->msg.track2)] = '\0';
	memcpy(localbuf,header->msg.track2, 4);
	//	<<<	R021024


	ptr_shc_data_buffer = (struct shc_data *)header->msg.shc_data_buffer;

	char cvv_resultcode = ptr_shc_data_buffer->cvv_resultcode;
	char cvv2_resultcode = ptr_shc_data_buffer->cvv2_resultcode;

	shc_setCvvResultCode( header, '\0' );

	/* R006141 --> cvv_resultcode = '\0':NotVerified, 'M':Match, 'N':NotMatch */
	ptr_shc_data_buffer->cvv_resultcode = '\0';

	if (shcmsgIsContactless(&header->msg) || shcmsgHeaderIsChipTxn(header)) // R030244
	{
		if ( isDCVVVerifyNeeded(header, header->issShcBin->binPkg) )
		{
			OTraceDebug( "D-SHC-031038: perform DCVV verify\n");
			if(header->issShcBin->binPkg->bin.bin_cfg & SH_CFG_DCVV)
			{
				shc_verify_dcvv(header);
			}
			else if ((header->issShcBin->binPkg->bin.bin_cfg & SH_CFG_CVC3)||(header->issShcBin->binPkg->bin.bin_cfg & SH_CFG_ICVV))
			{
				//IST_S761SP9-75 - Changes done to iCVV and CVC3 check
				//	Contactless Chip txn - perform iCVV check
				//	Contactless Magstrip txn - perform CVC3 check

				if (shcmsgHeaderIsChipTxn(header))
					shc_verify_icvv(header);
				else
					shc_verify_cvc3(header);
			}
			else if (header->issShcBin->binPkg->bin.bin_cfg & SH_CFG_SCVC3)
			{
				shc_verify_scvc3(header);
			}
			//else if (header->issShcBin->binPkg->bin.bin_cfg & SH_CFG_ICVV)
			//{
			//	shc_verify_icvv(header);
			//}

			cvv_resultcode = ptr_shc_data_buffer->cvv_resultcode;

			if( cvv_resultcode == '\0' )
				OTraceDebug( "D-SHC-031038: DCVV verify: cvv_resultcode is [null]\n");
			else
				OTraceDebug( "D-SHC-031038: DCVV verify: cvv_resultcode is [%c]\n", cvv_resultcode);

		}

		if ( isDCVVCheckNeeded(header, header->issShcBin->binPkg) )
		{
			OTraceDebug( "D-SHC-031038: perform DCVV check\n" );
			switch(cvv_resultcode)
			{
			case 'P':
				if ( isDCVVVerifyNeeded(header, header->issShcBin->binPkg) )
				{
					OTraceError("E-SHC-031039: Denied because switch could not perform cvv validation %c\n", cvv_resultcode);
					header->msg.respcode = SHC_RC_SystemError;
					shc_setCvvResultCode( header, 'Y' ); 
				}
			   break;
			case 'N':
			case 'I':
			case 'E':	//	R020452
				OTraceError("E-SHC-031038: Denied because cvvresult code is [%c]\n", cvv_resultcode);
				header->msg.respcode = SHC_RC_InvalidCVV;
				shc_setCvvResultCode( header, 'Y' ); 
				break;
			case 'M':
				OTraceDebug( "D-SHC-031038: DCVV check: pass\n" );
				break;
			default:
				OTraceDebug( "D-SHC-031038: DCVV check: not verified\n" );
				break;
			}
		}

	}
	
	memset(buf,0x00,sizeof(buf));	
	if( isCVVVerifyNeeded(header, header->issShcBin->binPkg) && !shcmsgHeaderIsChipTxn(header))
	{
		OTraceDebug( "D-SHC-031038: perform CVV verify\n");
		if((header->msg.device_cap & SH_DEVCAP_NOTRACK_DATA) || header->msg.track2[0] == '=')
		{
	   		OTraceInfo("I-SHC-031006:shc_cvv(): No track data for (pan=%s, track=%s)\n",
			shcApp->shcHelperObj->shc_maskpan(header->msg.pan),localbuf);		//	---	R021024
		}
		else if(((shc_getInstitutionIdFromCardScheme(visaInst, "04")) == 1) && ((header->msg.pcode/10000) == 20) && (header->msg.msgtype == SHC_AUTHREQ) && visaSkipCvv)
		{
			OTraceDebug( "D-SHC-031038: Skipping CVV check for Credit voucher and merchandise return authorization message for Visa\n");
		}	
		else if(((iRes=shc_cvv(header)) !=0) && (iRes != SEC_ASYNCH_WAIT))
		{
			if(iRes != 2)
			{
				shc_setCvvResultCode( header, 'Y' ); /* Not match, Want to be compatible with europay and MasterCard */
				ptr_shc_data_buffer->cvv_resultcode = 'N';
			}
		}
		else if(iRes==SEC_ASYNCH_WAIT)
		{
			// Asynch mode, waiting for response
			shc_setCvvResultCode( header, 'W' );
			ptr_shc_data_buffer->cvv_resultcode = 'W';
			return(iRes);
		}
		else
		{
			iRes=0;
			ptr_shc_data_buffer->cvv_resultcode = 'M'; 	/* Match - R006141 */
		}

		if( ptr_shc_data_buffer->cvv_resultcode == '\0' )
			OTraceDebug( "D-SHC-031038: perform CVV verify: result_code = [not verified]\n" );
		else
			OTraceDebug( "D-SHC-031038: perform CVV verify: result_code = [%c]\n", ptr_shc_data_buffer->cvv_resultcode);
	}

    if( isCVV2VerifyNeeded(header, header->issShcBin->binPkg) )
    {
	    OTraceDebug( "D-SHC-031038: perform CVV2 verify\n" );
	    if( shc_getCvvResultCode( header ) != 'Y' )
	    {
	        if( header->msg.cvv2[0] != '\0' )
	        {
	            //shc_setCvvResultCode( header, 'P' );
                /* Invalid CVV2 set to 'N', valid set 'M' */
                if( shc_verify_cvv2(header) )
                {
                    if( header->msg.respcode == SHC_RC_InvalidCVV2 )
                        shc_setCvvResultCode( header, 'N' );
                }
                else
                    shc_setCvvResultCode( header, 'M' );
	        	header->msg.respcode = 0;   /* Don't reject on verifying CVV2 for any reason */
	        }
	    }
	    char cvv2_result_code = shc_getCvvResultCode( header );
	    if( cvv2_result_code == '\0' )
	    {
		OTraceDebug( "D-SHC-031007: perform CVV2 verify: cvv2_resultcode= [not verified]\n" );
	    }else
	    {
		OTraceDebug( "D-SHC-031007: perform CVV2 verify: cvv2_resultcode= [%c]\n", cvv2_result_code );
	    }
	}

	if(ptr_shc_data_buffer->cvv2_resultcode == '\0')
		ptr_shc_data_buffer->cvv2_resultcode = cvv2_resultcode;

	if(ptr_shc_data_buffer->cvv_resultcode == '\0')
		ptr_shc_data_buffer->cvv_resultcode = cvv_resultcode;

	OTraceDebug("D-SHC-1105 SHC_CVV RespCode[%d]\n",header->msg.respcode);
	return(header->msg.respcode); /* Only reject on invalid CVV */
}

		/* R005887 << */


/*****************************************************************************/
/* Check if msg comes from Europay Agent for R004832, R004684, R004685, R004686 */
	/* R007206 & R007237 >> */
int ShcmsgHelper::shc_isEuroAcquirer( ShcmsgHeader *header )   // Europay Network is Acquirer
{
	return( shc_isEuroTxn(header, 'A') );
}

/*****************************************************************************/
int ShcmsgHelper::shc_isEuroIssuer( ShcmsgHeader *header )    // Europay Network is Issuer
{
	return( shc_isEuroTxn(header, 'I') );
}

/*****************************************************************************/
int ShcmsgHelper::shc_isEuroNet( ShcmsgHeader *header )
{
	return( shc_isEuroTxn(header, 'A')||shc_isEuroTxn(header, 'I') );
}

/*****************************************************************************/
int ShcmsgHelper::shc_isEuroTxn(ShcmsgHeader *header, char which )	/* A: asEuroAcquirer, I: asEuroIssuer */
{
	static int firstTime = 0;
	static bin_t euInstitution = {0};
	bin_t	inst = { 0 };
	char	strBuf[64];
	int 	ret = 0;

	if( which == 'A' )
		memcpy(inst, header->msg.txnSrc, sizeof(inst)-1);
	else
		memcpy( inst, header->msg.txnDest, sizeof(bin_t)-1 );

	if( firstTime > 0 )		/* europayBin has been got from istparam.cfg */
	{
		ret = ( strcmp( euInstitution, inst ) == 0 ? 1 : 0 );
	}
	else if( firstTime < 0 )	/* EUROPAY institution not found */
	{}
	else if( firstTime ==0 )	/* first extracting the europayBin param from istparam.cfg */
	{
		firstTime = 1;
		strBuf[ sizeof(bin_t)-1 ] = '\0';	/* preventing BIN from length>sizeof(bin_t) */

		ret = shc_getInstitutionIdFromCardScheme(euInstitution, EUROPAY_CARD_SCHEME);
		if (ret < 0)
		{
			OTraceWarning( "W-SHC-031008: EUROPAY institutiton not found in database. No Europay specific checking.\n" );
			strcpy(euInstitution, "##########");
			firstTime = -1;
		}

		ret = ( strcmp( euInstitution, inst ) == 0 ? 1 : 0 );
    }

	if( ret )
		OTraceDebug( "D-SHC-031009: %s=='%s'(EPS-Net).\n"
					, which=='A' ? "acqbin" : "issbin", inst );

	return ( ret );
}
	/* << R007206 & R007237 */

/*****************************************************************************/
/* R004832 and R004686 --> */
int ShcmsgHelper::shc_chkEuropayDupTxn(ShcmsgHeader *header)
{
	struct 	ShcmsgWithSegment oldmsg = {0};

	if( ((ShcLog *)(header->shcLogObj))->locateEuropayTxn( header, &(oldmsg.msg), True ) )
	{
		OTraceInfo("I-SHC-031010: Found duplicate: Record is pan = [%s]\n", shcApp->shcHelperObj->shc_maskpan(header->msg.pan));
		return( True );
	}
	else
	{
		OTraceInfo("I-SHC-031011: No duplicate record being found.\n");
		return( False );
	}
}
/* <-- R004832 and R004686 */


/*****************************************************************************/
int ShcmsgHelper::checkEuAcquirerProfile( ShcmsgHeader *header, unsigned long lNetworkData )
{
	int  ret = -1;
	int  pCode = header->msg.pcode/10000;
	int  merchCode = header->msg.merchant_type;
	int  posEntryMode = (header->msg.pos_entry_code & SH_POS_PINPANENTRY_MASK)/10;
	int  pinEntryCap  = (header->msg.pos_entry_code & SH_POS_PINPANENTRY_MASK)%10;
	int  pinBaseTxn = strlen(header->msg.pin)>0 ? 1 : 0;

	int  is_Eurocard_Mastercard = lNetworkData & (EU_BIN_MAST | EU_BIN_ECMC);
	int  is_Cirrus_Eurocheque = lNetworkData & (EU_BIN_ECHA | EU_BIN_CRUS | EU_BIN_ECCR);
	int  is_Maestro = lNetworkData & EU_BIN_MAES;

	if( posEntryMode == SH_POS_PANENTRY_MAGSTRIP )	// R007612
		posEntryMode = SH_POS_PANENTRY_TRK1OR2;		// R007612

	OTraceDebug( "D-SHC-031012: Merch(%d),PosEntryMode(%02d:%d),CVM(%c)\n"
				, merchCode, posEntryMode, pinEntryCap, (pinBaseTxn ? 'P' : 'S') );

	if( pinBaseTxn && posEntryMode==SH_POS_PANENTRY_TRK1OR2 && pinEntryCap==SH_POS_PINENTRY_HASCAP )
	{
			/* A.10 - ATM PBT */
		if( pCode==1 && merchCode==6011 )
			ret = 0;

			/* A.20 - POS PBT Retail */
		else if( (pCode==0 && merchCode!=6011) && !is_Cirrus_Eurocheque )
			ret = 0;

			/* A.30 - POS PBT Cash */
		else if( (pCode==1 && merchCode==6010) && !is_Eurocard_Mastercard )
			ret = 0;
	}

	if( ret<0 && !pinBaseTxn && merchCode!=6011 )
	{
			/* A.40 POS SBT Retail + electronic commerce retail */
		if( pCode==0 && !is_Cirrus_Eurocheque
			&& ( (posEntryMode==SH_POS_PANENTRY_ECOMMERCE && is_Eurocard_Mastercard)
				|| posEntryMode==SH_POS_PANENTRY_TRK1OR2 ) )
			ret = 0;

		else if( is_Eurocard_Mastercard )	/* Eurocard-MasterCard */
		{
				/* A.50 - POS SBT Cash */
			if( (pCode==17 || pCode==1) && posEntryMode==SH_POS_PANENTRY_TRK1OR2 )	// R007612
				ret = 0;

				/* A.60 - Manual SBT Retail + Manual electronic commerce retail */
			else if( pCode==0 && pinEntryCap==SH_POS_PINENTRY_NOCAP
			 && (posEntryMode==SH_POS_PANENTRY_ECOMMERCE ||posEntryMode==SH_POS_PANENTRY_MANUAL) )
				ret = 0;

				/* A.70 - Manual SBT Cash */
			else if( pCode==17 && posEntryMode==SH_POS_PANENTRY_MANUAL && pinEntryCap==SH_POS_PINENTRY_NOCAP )
				ret = 0;
		}
	}

	return( ret );
}
	/* << R007206 & R007237 */


/*****************************************************************************/

int ShcmsgHelper::shc_updateduptxn_info(ShcmsgHeader *header)
{
	/*	1.	Should we maintain dup txn. info */
	if( !(header->issShcBin->binPkg->bin.flags & SH_CHECKDUP) )
		return(0);

        /*      2. Update the record */
        int result=shcDuplicateChkObj->update(header);
        if(result==1)
        return 1;
        else
        return result;
}


/*****************************************************************************/

int ShcmsgHelper::shc_openfloorlim()
{
	if(shcApp->flrfd < 0)
		shcApp->flrfd = dbm_open("floorlim_1", getpid());

	if(shcApp->flrfd < 0)
	{
		OTraceError("E-SHC-031014: Unable to open floor limit table: Error:%d\n",
				dbm_errno);

		return(-1);
	}
	else
		return(0);
}


/*****************************************************************************/

int ShcmsgHelper::shc_balance_encryption(ShcmsgHeader *header, char *kme, char procmode)
{
	/*
	 *  This function encrypt/decrypt the shcmsg->msg.pin field:
	 *  by using the Key shcmsg->msg.kme_mfk according to the
	 *  procmode ('E' for encryption; 'D' for decryption).
	 *  The encrypted/decrypted result is still in
	 *  shcmsg->msg.pin.
	 *
	 *  return: SHC_RC_Approved for successful operation
	 *          -1              for failure
	 */

	int	data_len;
	int	kmeret;

	if( ! kme )
		kme = header->msg.kme_mfk;

	data_len = sizeof(header->msg.pin);
	kmeret = data_cryption(kme,
					  NULL,
					  header->msg.pin,
				      &data_len,
					  header->msg.pin,
					  procmode);
    if(kmeret)
        return(SHC_RC_Approved);

	return( -1 ); /* sec_error()); */
}

/*****************************************************************************/

int ShcmsgHelper::shc_build_balance_data(char * data_buf, amount_t *src)
{
    /*
     *  This function builds the binary format of a given amount_t data.
	 *
     *  The total length of this binary data is SHC_PIN_LEN (16) bytes,
     *  with the first byte credit/debit indicator ('C'/'D') followed
     *  by the right justified amount_t data with leading zeros.
     *
     */

	int		sign;
	char	buf[50];
	amount_t	data;

	dbm_deccopy(&data, src);

	if (dbm_cmpzero(&data) <= 0 )
	{
		sign = 1;
		dbm_decnmul(&data, -1);
	}
	dbm_decnmul(&data, 100);		/* two decimal points */
	dbm_dectochar(&data, buf);

	shc_normalize_amount(data_buf, buf, SHC_PIN_LEN);

	if ( sign == 1 )
		data_buf[0] = 'D';	/* debit */
	else
		data_buf[0] = 'C';	/* credit */

	return( 0 );
}


/*****************************************************************************/

int ShcmsgHelper::shc_normalize_amount(register char *nbp, register char *obp, int len)
{
    /*
     *  This function normalizes the given obp to the end of '.' or the end
	 *  of the string by adding the leading zeros to a total length (len)
	 *  and put it in *nbp.
     *
     *  The given *obp contains only digits and '.'.
     */

    int i;
    register char   *save_obp;

    for(i = 0; i < len; ++i)
        /*  scan inital white space */
        if(isspace(*obp) || *obp == '0')
            ++obp;
        else
            break;

    save_obp = obp;
    memset(nbp, '0', len);
    nbp[len] = '\0';

    nbp += len - 1;

    if(!*obp)
        return(0);

    for(i = 0; i < len; ++i)
        /*  scan to end of num */
        if ( *obp == '.' || *obp == '\0' )     /* the end of the string */
            break;
        else
            ++obp;

    --obp;

    /*  Working backwards normalize the num */
    for(;;)
    {
        if(obp < save_obp)
            break;

        *nbp-- = *obp--;
    }
    return(0);
}


/*****************************************************************************/

int ShcmsgHelper::data_edit_error(char * data)
{
	/*
	 * This function checks if there is an edit error in balance data which
	 * can only contain digits and 'C' or 'D'.
	 *
	 * return: 0  --> successful
	 *         -1 --> failure
	 */

	int	length, i;

	length = strlen(data);
	for (i=0; i<length; i++, *data++)
	{
		if ( !isdigit(*data) && *data != 'C' && *data != 'D' )
		{
            OTraceDebug("D-SHC-031015:  Status  : failed - Invalid balance\n");
			return(-1);
		}
	}
	return(0);
}

int ShcmsgHelper::shc_restoreOriginal(ShcmsgHeader *header)
{

	if (!header->origMsg)
	{
		OTraceDebug("D-SHC-031016: No original message, nothing restored\n");
		return 0;
	}
	if (header->msg.formatter_devcap & SH_FORMATDEVCAP_ORIG_MSG_RESTORED )
	{
		OTraceDebug("D-SHC-0300109:  Original message restored already, skip restore\n");
		return 0;
	}


	::tmpShcOmsg = header->origMsg;
	OTraceInfo("I-SHC-030093: Restoring fields from original txn\n");

	// rely on the flag alone

	if (!header->issBinValid())
	{
		//issuer bin not set, not called from shc, just restore fields only, do not lookup
		OTraceDebug("D-SHC-031027: Original issuer/txndest to be restored if empty\n");
		if (!header->msg.txnDest[0])
			istsafe_strcpy(header->msg.txnDest, sizeof(header->msg.txnDest), header->origMsg->txnDest);

		if (!header->origMsg->member_ID[0])
			strtrim(header->origMsg->member_ID, header->msg.member_ID); // arg1 -> arg2 - R030207,USP-1609

		if (!header->msg.issuer[0])
			istsafe_strcpy(header->msg.issuer, sizeof(header->msg.issuer), header->origMsg->issuer);
		if (!header->msg.acquirer[0])
			istsafe_strcpy(header->msg.acquirer, sizeof(header->msg.acquirer), header->origMsg->acquirer);
		if (!header->msg.iss_entityId[0])
			istsafe_strcpy(header->msg.iss_entityId, sizeof(header->msg.iss_entityId), header->origMsg->iss_entityId);

	}
	else if(   shcApp->shcParams.getInst(header->issShcBin->binPkg->bin.institutionid)->GetBool
			((char *)"shc.restoreIssuerForReversal") 
	  )
	{
		// 05Oct2010
		// need the txndest too
		OTraceDebug("D-SHC-031017: Original issuer/txndest to be restored\n");
		strcpy(header->msg.txnDest, header->origMsg->txnDest);

		// USP-1556 -- member ID too
		//strcpy(header->msg.member_ID, header->origMsg->member_ID);
		strtrim(header->origMsg->member_ID, header->msg.member_ID); // arg1 -> arg2 - R030207,USP-1609

		strcpy(header->msg.issuer, header->origMsg->issuer);
		strcpy(header->msg.iss_entityId, header->origMsg->iss_entityId);
		header->issShcBin->setBinPkg(header->msg.issuer);
		shcApp->issuerShcParamsList = (ShcInstParamsList *)shcApp->shcParams.getInst(header->issShcBin->binPkg->bin.institutionid);
        //lookup inst_profile
		struct shcsecurity *keyparam;
		int ikeyparam;
        InstitutionProfile instProfile = { 0 };
        int len = sizeof(struct InstitutionProfile);

        NetworkInfo networkInfo;
        shcApp->instProfileObj->locateNetworkInfo(header->msg.txnSrc, header->msg.txnDest,
            header->msg.iss_entityId, header->msg.msgtype, header->msg.issuer, networkInfo);
        if (networkInfo.foundNetworkInfo())
            header->setSegmentData((char *)networkInfo.getInstProfileEntry(),
                sizeof(struct InstitutionProfile), NETWORK_DATA_REQ_id, ISS_INST_PROFILE_ENTRY);

		if(rm_isMultiVerSupported(0))
		{
			keyparam = networkInfo.getKey();
				
			if (header->issBinValid() && (keyparam))
			{
				header->issShcBin->setKey(keyparam);
			}
		}
		else
		{
			ikeyparam = networkInfo.getKeyparam();
					
			if (header->issBinValid() && (ikeyparam >= 0))
			{
				header->issShcBin->setKey(&shcSecurity[ikeyparam]);
			}
		}
	}
	//	<<<	R018832

				/* R006645 >> */
									/* R009092 BEGIN */
		OTraceInfo("I-SHC-030094.1: Trace(%d), Restore Message origTrace(%d)\n",header->msg.origtrace,header->origMsg->trace);
		if (header->msg.origmsg <= 0)
			header->msg.origmsg     = header->origMsg->origmsg;	//origmsg contains request message type
		if ( (header->msg.origtrace <= 0) || (header->msg.origtrace == header->msg.trace) )
			header->msg.origtrace   = header->origMsg->trace;

		OTraceInfo("I-SHC-030094.2: Trace(%d), origTrace(%d)\n",header->msg.trace,header->msg.origtrace);
		OTraceInfo("I-SHC-030094: Restore gateway_id (%d), orig(%d)\n",header->msg.gateway_id,header->origMsg->gateway_id);
		if (header->msg.gateway_id <= 0)
                        header->msg.gateway_id = header->origMsg->gateway_id;
									/* R009092 END */

	header->msg.serial_1    = header->origMsg->serial_1;
	strcpy(header->msg.originator, header->origMsg->originator);

	if(*(header->msg.authnum) == '\0')
	{
		OTraceInfo("I-SHC-030094: Restore authnum from orig txn 2\n");
		strcpy(header->msg.authnum, header->origMsg->authnum);
	}
			/* R007209 >> */
	if( header->msg.acctnum[0] == '\0')
		strcpy( header->msg.acctnum, header->origMsg->acctnum );
	if( header->msg.iss_currency_code <= 0 )
		header->msg.iss_currency_code = header->origMsg->iss_currency_code;
	if ( dbm_decncmp(&header->msg.iss_conv_rate, (double)0) == 0 )
		dbm_deccopy( &header->msg.iss_conv_rate, &header->origMsg->iss_conv_rate );

//	if( header->origMsg->device_devcap & SH_DEVICE_LOG_SHCLOG_ADD )
//	{
//		if( ! has_shclog_add(header) )			/* R008041 */
//		{
//			if( ((ShcLog *)(header->shcLogObj))->shc_logadd_restoreSegment( &header->msg ) == 0 )
//			{
//				header->msg.device_cap |= SH_DEVCAP_USER_SEGMENT;
//				header->msg.device_devcap |= SH_DEVICE_LOG_SHCLOG_ADD;
//
//				OTraceDebug("D-SHC-031017: Original shclog_add segment being restored\n");
//			}
//			else
//			{
//				OTraceWarning("W-SHC-031018: Failed to restore original shclog_add\n");
//			}
//		}
//	}
	/* R007984 << */

	OTraceDebug("D-SHC-031019:restore original message number\n");
	if (!header->msg.pan[0])
		istsafe_strcpy(header->msg.pan, sizeof(header->msg.pan), header->origMsg->pan);
		
	header->msg.origFlippedMsg = header->origMsg->flipped_msgtype;
	header->msg.flipped_msgtype=0;

	/* 10002243 */
	if( header->msg.local_date <= 0 || header->msg.local_time <= 0 )
	{
		header->msg.local_date = header->origMsg->local_date;
		header->msg.local_time = header->origMsg->local_time;
	}



	header->msg.origpcode = header->origMsg->pcode;

	if (!header->msg.authnum[0])
		memcpy(header->msg.authnum, header->origMsg->authnum, sizeof(header->msg.authnum));
	if (header->msg.origtrace <= 0)
		header->msg.origtrace = header->origMsg->trace;

	/* 10002243 */
	if( header->msg.settlement_date <= 0 )
		header->msg.settlement_date = header->origMsg->settlement_date;

    /*
     * yh: 1997/09/22. restore issuer_data from the original transaction.
     */
    memcpy(header->msg.issuer_data, header->origMsg->issuer_data,
           sizeof(header->msg.issuer_data));
	header->msg.merchant_type = header->origMsg->merchant_type;		/* R004340 */
												/* R007781 BEGIN */
	if (shc_is_empty_buf(header->msg.filler1, sizeof(header->msg.filler1)))
		memcpy( header->msg.filler1, header->origMsg->filler1, sizeof(header->msg.filler1) );
	if (shc_is_empty_buf(header->msg.filler2, sizeof(header->msg.filler2)))
		memcpy( header->msg.filler2, header->origMsg->filler2, sizeof(header->msg.filler2) );
	if (shc_is_empty_buf(header->msg.filler3, sizeof(header->msg.filler3)))
		memcpy( header->msg.filler3, header->origMsg->filler3, sizeof(header->msg.filler3) );
	if (shc_is_empty_buf(header->msg.filler4, sizeof(header->msg.filler4)))
		memcpy( header->msg.filler4, header->origMsg->filler4, sizeof(header->msg.filler4) );
												/* R007781 END */
	//	>>>	R029153
	if (shc_is_empty_buf(header->msg.trans_id, sizeof(header->msg.trans_id)))
		memcpy( header->msg.trans_id, header->origMsg->trans_id, sizeof(header->msg.trans_id) );
	//	<<<	R029153

/* R004938 >> */
	if(header->issShcBin->isInterac())
	{
		//Maybe we should always restore the trandate & trantime, but dare not to change
		OTraceDebug("D-SHC-031020:Replace origdate/time for Interac\n");

		header->msg.origdate = header->origMsg->origdate;
		header->msg.origtime = header->origMsg->origtime;
	} /* R004938 << */

	header->msg.origrespcode = header->origMsg->respcode;
	header->msg.origcapdate = header->origMsg->cap_date;

	//	>>>	R026116
	if( header->msg.cap_date <= 0)	//	---	R026151
		header->msg.cap_date = header->origMsg->cap_date;
	//	<<<	R026116

	if( header->msg.auth_devcap <= 0)	
		header->msg.auth_devcap = header->origMsg->auth_devcap;
	if( header->msg.pos_pin_cap_code <= 0)
		header->msg.pos_pin_cap_code = header->origMsg->pos_pin_cap_code;

	//	>>>	R026255
	if( header->msg.card_seqno < 0 )
		header->msg.card_seqno = header->origMsg->card_seqno;
	//	<<<	R026255
	if( header->msg.pos_cap_code < 0)
		header->msg.pos_cap_code =  header->origMsg->pos_cap_code;  //R027263

	dbm_deccopy( &header->msg.fee, &header->origMsg->fee );		/* R007230 */
	dbm_deccopy( &header->msg.device_fee, &header->origMsg->device_fee );	//	--- R025885

	int savedOrigMsg = header->msg.origmsg;
	if (header->origMsg->saf)
	{
		/* Original message is approved by standin, should be advice when sent to issuer */
		switch (header->msg.origmsg/10)
		{
		case 10: /*10x message */
			header->msg.origmsg = 120;
			break;
		case 20: /*20x message */
			header->msg.origmsg = 220;
			break;
		}
	}

	// R027876 >>>
	if (savedOrigMsg != header->msg.origmsg)
	{
		char buf[5];
		memset(buf, 0x00, sizeof(buf));
		sprintf(buf,"%d",savedOrigMsg);
		header->setSegmentData(buf,strlen(buf), ElfIdMap::elf_to_id(IST_SEG_NETWORK_SETTLEMENT_DATA), ORIG_MSG_TYPE);
	}
	// <<< R027876

	header->msg.device_cap &= ~SH_DEVCAP_NOPIN;                           /* R009100 */
	header->msg.device_cap |= ( header->origMsg->device_cap & SH_DEVCAP_NOPIN ); /* R009100 */

	/* R015807 */
	//	---	R020622
	header->msg.shc_devcap |= header->origMsg->shc_devcap & 
		(SH_DEVCAP_SHC_PIN_BASED | SH_DEVCAP_SHC_PARTIAL_AUTH | SH_DEVCAP_SHC_REQ_REPEAT | SH_DEVCAP_SHC_DCC_IND);

	strcpy( header->msg.FPI, header->origMsg->FPI );		/* R009356 */

	/* R014503 >> */
	dbm_deccopy( &header->msg.settlement_amount, &header->origMsg->settlement_amount );
	if (!header->msg.amount.v.compat[0]) 
	{
		//msg.amount doesn't have value, restore from original
		//Add decimal point at the end because pos may do ccy format in
		dbm_deccopy( &header->msg.amount, &header->origMsg->amount );
		if (!strchr(header->msg.amount.v.esql_decimal.digits, '.'))
			istsafe_strcat(header->msg.amount.v.esql_decimal.digits, sizeof(header->msg.amount.v.esql_decimal.digits), ".");
	}
	dbm_deccopy( &header->msg.settlement_rate, &header->origMsg->settlement_rate );
	header->msg.iss_conv_date = header->origMsg->iss_conv_date;
	header->msg.settlement_code = header->origMsg->settlement_code;
	if (shcIsReversal(header)) OTraceDebug("D-SHC-031037: Restored settlement info: Amt.<%.29s> Ccy. cd<%03d>\n", &header->msg.settlement_amount, header->msg.settlement_code);
	/* << R014503 */

	if ((!header->msg.acceptorname[0]) && (header->origMsg->acceptorname[0]))
		istsafe_strcpy(header->msg.acceptorname, sizeof(header->msg.acceptorname), header->origMsg->acceptorname);

    /*struct shc_data *ptr_shc_data = (shc_data *)header->msg.shc_data_buffer;
    struct shc_data *ptr_orig_shc_data = (shc_data *)header->origMsg->shc_data_buffer;
    //Restore pos_condition_code_x
    ptr_shc_data->pos_condition_code_x = ptr_orig_shc_data->pos_condition_code_x;
	if ((!ptr_shc_data->avs_data[0]) && (ptr_orig_shc_data->avs_data[0]))
		istsafe_strcpy(ptr_shc_data->avs_data, sizeof(ptr_shc_data->avs_data), ptr_orig_shc_data->avs_data);
	if ((!ptr_shc_data->expiry_date[0]) && (ptr_orig_shc_data->expiry_date[0]))
		istsafe_strcpy(ptr_shc_data->expiry_date, sizeof(ptr_shc_data->expiry_date), ptr_orig_shc_data->expiry_date);*/

	int cnti;
    char tmp_shc_data_buffer[SHC_DATA_LEN*2] = {0};
    for(cnti = 0; cnti < SHC_DATA_LEN*2; cnti++)
    {
        if(header->origMsg->shc_data_buffer[cnti] == 0x10)
            tmp_shc_data_buffer[cnti] = '\0';
        else
            tmp_shc_data_buffer[cnti] = header->origMsg->shc_data_buffer[cnti];
    }

    struct shc_data *ptr_shc_data = (shc_data *)header->msg.shc_data_buffer;
    struct shc_data *ptr_shc_data2 = (shc_data *)tmp_shc_data_buffer;

	ptr_shc_data->pos_condition_code_x = ptr_shc_data2->pos_condition_code_x;
    if ((!ptr_shc_data->avs_data[0]) && (ptr_shc_data2->avs_data[0]))
        istsafe_strcpy(ptr_shc_data->avs_data, sizeof(ptr_shc_data->avs_data), ptr_shc_data2->avs_data);
    if ((!ptr_shc_data->expiry_date[0]) && (ptr_shc_data2->expiry_date[0]))
        istsafe_strcpy(ptr_shc_data->expiry_date, sizeof(ptr_shc_data->expiry_date), ptr_shc_data2->expiry_date);

	OTraceDebug("D-SHC-03102 avs_data<%s>\n",ptr_shc_data->avs_data);

	// R027905 >>>
	dbm_deccopy(&header->msg.cash_back, &header->origMsg->cash_back);
	if (header->origMsg->termloc[0])
		strcpy(header->msg.termloc, header->origMsg->termloc);
	if (header->origMsg->refnum[0])
		strcpy(header->msg.refnum, header->origMsg->refnum);
	//header->msg.pos_condition_code |= header->origMsg->pos_condition_code & SH_POS_COND_CREDIT_TXN;
	header->msg.pos_condition_code = header->origMsg->pos_condition_code;	//original pos_condition_code restored into 400 msg
	// <<< R027905

	if (!header->issBinValid())
		header->msg.pos_entry_code = header->origMsg->pos_entry_code;	//original pos_entry_code restored into 400 msg
	else if(shcApp->shcParams.getInst(header->issShcBin->binPkg->bin.institutionid)->GetBool((char *)"shc.restorePosEntryCode"))
		header->msg.pos_entry_code = header->origMsg->pos_entry_code;	//original pos_entry_code restored into 400 msg

	if (header->msg.batch_id == 0)
		header->msg.batch_id = header->origMsg->batch_id;
	int callbackRet = shc_callback(header, "post_restore_original_request");
	switch(callbackRet)
	{
	case SHCCALLBACKNONE:
	case SHCCALLBACKCONTINUE:
	case SHCCALLBACKOVERRIDE:
		break;
	default:
		return (callbackRet);
	break;
	}

	//	>>>	R015826
	char tmplogid[sizeof(header->msg.shclog_id)];
	strcpy (tmplogid, header->msg.shclog_id);
	strcpy(header->msg.shclog_id, header->origMsg->shclog_id);

	strcpy(header->msg.shclog_id, tmplogid);

	IstSegList *origSegList = ((ShcLog *)header->shcLogObj)->restoreGenericLog(shcGenericLogObj, header, 'B');

	if (origSegList)
	{
		header->setOrigSegList(origSegList);
		IstSegList *currentSegList = header->getSegList();
		currentSegList->restore(header->getOrigSegList());
	}
	//	<<<	R015826
	
	if(!header->issShcBin->isInterac())
	{
		OTraceDebug("D-SHC-031020i-0:Inside Replace origdate/time \n");
		char origLocalTime[6+1];

		memset(origLocalTime, 0x00, sizeof(origLocalTime));
		snprintf(origLocalTime, sizeof(origLocalTime),"%06d",header->origMsg->local_time);
		header->setSegmentData(origLocalTime,strlen(origLocalTime), ElfIdMap::elf_to_id(IST_SEG_NETWORK_SETTLEMENT_DATA), ORIGINAL_LOCAL_TIME);

		char origLocalDate[8+1];

		memset(origLocalDate, 0x00, sizeof(origLocalDate));
		snprintf(origLocalDate, sizeof(origLocalDate),"%06d",header->origMsg->local_date);
		header->setSegmentData(origLocalDate,strlen(origLocalDate), ElfIdMap::elf_to_id(IST_SEG_NETWORK_SETTLEMENT_DATA), ORIGINAL_LOCAL_DATE);

		OTraceDebug("D-SHC-031020.1 : origdate = [%ld] origtime = [%ld] origLocalTime = [%s] origLocalDate = [%s] \n", header->msg.origdate,header->msg.origtime, origLocalTime, origLocalDate);

		char SegOrgIdSHCID[24];
		int segleg =0;
		memset(SegOrgIdSHCID , 0x00, sizeof(SegOrgIdSHCID));
		header->getSegmentData(SegOrgIdSHCID, &segleg, ElfIdMap::elf_to_id(IST_SEG_NETWORK_SETTLEMENT_DATA), REV_ORIG_SHCLOG_ID);
		OTraceDebug("D-SHC-031020-2: Segment OrgId from IST_SEG_NETWORK_SETTLEMENT_DATA[%s] Len[%d]\n",SegOrgIdSHCID, segleg);
		if (segleg>0)
		{
			OTraceDebug("D-SHC-031020-3: Get the Segment OrgId from IST_SEG_NETWORK_SETTLEMENT_DATA\n");
			header->msg.origdate = header->origMsg->trandate;
			header->msg.origtime = header->origMsg->trantime;
			OTraceDebug("D-SHC-031020-5: origdate[%d]trandate[%d] - origtime[%d]trantime[%d]\n",
					header->msg.origdate, header->origMsg->trandate, header->msg.origtime, header->origMsg->trantime);
		}
		else
		{
			if ((header->msg.origdate <= 0)||(header->msg.shc_devcap & SH_DEVCAP_SHC_VOID))
				header->msg.origdate = header->origMsg->trandate;
			if ((header->msg.origtime <= 0)||(header->msg.shc_devcap & SH_DEVCAP_SHC_VOID))
				header->msg.origtime = header->origMsg->trantime;
		}
	}

	return 0;
}





/*****************************************************************************/

int ShcmsgHelper::shc_set_return_msgno(ShcmsgHeader *header)
{
	header->msg.msgtype = shc_get_return_msgno(header->msg.msgtype);
	return(header->msg.msgtype);
}

/*****************************************************************************/

int ShcmsgHelper::shc_locate_device_message(ShcmsgHeader *header)
{
	/*
	 *	Locate a event message for an ACK/NAK transaction
	 */
	header->shcerr = SH_IGNORE;

	/*	Try POS transaction */
	header->msg.msgtype = SHC_DEVICE_ACK + SHC_AUTHREQ_RESPONSE;

	/* 961204 */
	if(shcApp->shcTimerObj->shc_locate_event_x(header, &(header->msg), (unsigned char *)header->segment) >= 0)
	{
		header->msg.msgtype = SHC_AUTHREQ_RESPONSE;
//		if(shc_initialise_transaction(header) < 0)
//			return(-1);
//		else
			return(0);
	}

	/*	Try finacial ATM transaction */
	header->msg.msgtype = SHC_DEVICE_ACK + SHC_FINREQ_RESPONSE;

	/* 961204 */
	if(shcApp->shcTimerObj->shc_locate_event_x(header, &(header->msg), (unsigned char *)header->segment) >= 0)
	{
		header->msg.msgtype = SHC_FINREQ_RESPONSE;
//		if(shc_initialise_transaction(header) < 0)
//			return(-1);
//		else
			return(0);
	}

	/*	No luck.	Transaction not in event queue */
	OTraceWarning("W-SHC-031021:Unmatched %d from device: Trace: %d\n",
								header->msg.msgtype, header->msg.trace);

	//R028271 >>>
	TxnStatReport(header->msg.shclog_id,TS_SHC,TSR_DROP,DROP_DEVACK_NOT_FOUND,0,0);
	//<<< R028271

	/*	ad: 05mar94: If no ack pending found then just throw it away: */
	return(-1);

}


/*****************************************************************************/
int ShcmsgHelper::dumpShcmsg( struct shcmsg *msg, int mbOutbound )
{
	ShcmsgHeader *h = NULL;
	/*
	 * R001835 Dump shcmsg into shcdump.debug
	 */
	if( ist_otrace_get_level2() & OTRACE_HEXDUMP )
	{
		if ( mbOutbound > 0 )
		{
			OTraceTitleDump( "--- SEND message to mbox[%s][%d] ---\n"
				, mbMailBoxName(mbOutbound), mbOutbound );
		}
		else
		{
			OTraceTitleDump( "--- RECEIVE message from mbox[%s][%d] ---\n"
				, mbMailBoxName(msg->senderid), msg->senderid );
		}
		OTraceHexDump( (unsigned char *)msg,  h->truelength( msg ));
	}
	if( ist_otrace_get_level2() & OTRACE_FIELDDUMP )
	{
		if ( mbOutbound > 0 )
		{
			OTraceTitleDump( "--- SEND message to mbox[%s][%d] ---\n"
				, mbMailBoxName(mbOutbound), mbOutbound );
		}
		else
		{
			OTraceTitleDump( "--- RECEIVE message from mbox[%s][%d] ---\n"
				, mbMailBoxName(msg->senderid), msg->senderid );
		}
		ICShcmsg_printMsg(msg, NULL, NULL, NULL);

		dump_emv( msg, NULL );
	}

	return 0;
}

/*****************************************************************************/

int ShcmsgHelper::dumpHexShcmsg( struct shcmsg *msg, FILE *fd )
{
	const int HEX_COL = 16;
	ShcmsgHeader *h = NULL;
	int len = h->truelength( msg );
	unsigned char *pData = (unsigned char *)msg;

	char hexBuf[256] = {0};
	char ascBuf[256] = {0};
	char *pHexBuf;

	int i=0;
	while( i < len )
	{
		pHexBuf = hexBuf;

		int j, k;
		for ( j=0; j<HEX_COL && i+j<len; j++ )
		{
			pHexBuf += sprintf( pHexBuf, "%02x ", *(pData+i+j) );
			ascBuf[j] = isprint(*(pData+i+j)) ? *(pData+i+j) : '.' ;
		}
		for ( k=j; k<HEX_COL; k++ )
		{
			pHexBuf += sprintf( pHexBuf, "   " );
			ascBuf[k] = ' ';
		}
		ascBuf[k] = '\0';

		fprintf( fd, "[ %04d | %s | %s ]\n", i/HEX_COL*HEX_COL, hexBuf, ascBuf );
		i += j;
	}

	return len;
}

/*****************************************************************************/
int ShcmsgHelper::getAlterIssuerByEntityId( struct shcmsg *msg, char *alterIssuer, struct shcpkg **pkg, size_t alterIssrSize )
{
	if ( ! msg )
	{
		OTraceError("E-SHC-031022: getAlterIssuerByEntityId() - shcmsg is NULL\n");
		return (-1);
	}

	// try the issuer bin located before first
	if ( msg->issuer[0] )
	{
		if ( shcApp->shcBinObj->shc_locate_bin(pkg, msg->issuer) >= 0 )
		{
			if ( ! shc_isdown(*pkg) )	// bin is up
			{
				return 1;				// use it
			}
		}
	}

	IssuerInfo issuerInfo;
	*pkg = NULL;
	bin_t issBin = {0};

	if ( ! alterIssuer )
	{
		alterIssuer = issBin;
	}

	int ret = shcApp->issProfileObj->locate_issuerByEntityId( msg->txnSrc, msg->msgtype,
							msg->merchant_type, msg->pcode, msg->pin[0], msg->issuer,
							msg->iss_entityId, msg->txnDest, msg->cardProduct,
							issuerInfo );

	if ( ret < 0 )		// not found
	{
		OTraceError("E-SHC-031023: Not match alternate issuer bin found!\n");
	}
	else
	{
		if ( issuerInfo.foundIssuer() )
		{
			if ( ret > 0 )		// found but is up
			{
				//strcpy( alterIssuer, issuerInfo.getIssuerBin() );
				istsafe_strcpy( alterIssuer, alterIssrSize, issuerInfo.getIssuerBin() );
				if ( strcmp(alterIssuer, msg->issuer) != 0 )
				{
					OTraceInfo("I-SHC-031024: Found 'UP' alternate routing issuer[%s]\n", alterIssuer);
				}
			}
			else				// found and is down
			{
				//strcpy( alterIssuer, msg->issuer );
				istsafe_strcpy( alterIssuer, alterIssrSize, msg->issuer );
				OTraceDebug("D-SHC-031025: Use original down issuer[%s]\n", alterIssuer);
			}

			shcApp->shcBinObj->shc_locate_bin(pkg, alterIssuer);
		}
	}

	return ret;
}

int ShcmsgHelper::shc_checkCavvCaav( ShcmsgHeader *header )
{

	if( isCAVVEnabledForStandInOnly(header->issShcBin->binPkg) && !shcIsStandIn(header) )
	{
		OTraceDebug( "D-SHC-031026: BIN configured for CAVV check only when in stand-in\n" );
		return 0;  
	}

	int retVal = 0, decl_on_fail = 0, segLen = 0;
	char ucafBase64[29];	

	memset(ucafBase64, 0x00, sizeof(ucafBase64));
        header->getSegmentData(ucafBase64, &segLen, ElfIdMap::elf_to_id(IST_SEG_NETWORK_DATA_REQ), MC_UCAF_AAV);
	if(segLen > 0)
	{
		if((ucafBase64[0] == 'j' || ucafBase64[0] == 'h') && (((header->issShcBin->binPkg->bin.addflag & SH_ADDFLAG_HMAC_MAS_DECL) == SH_ADDFLAG_HMAC_MAS_DECL) || ((header->issShcBin->binPkg->bin.addflag & SH_ADDFLAG_CVC2_MAS_DECL) == SH_ADDFLAG_CVC2_MAS_DECL)))
        	{
      	        	decl_on_fail = 1;
        	}
		else if((UcafCtrlByte) && (ucafBase64[0] == 'k') && ((header->issShcBin->binPkg->bin.addflag & SH_ADDFLAG_CAVV_SPA2_DECLINE) == SH_ADDFLAG_CAVV_SPA2_DECLINE))
		{
			decl_on_fail = 1;
		}
	}
	
	shc_setissuerCAVVResultCode( header, '\0' );

	/* issuerCAVVResultCode = '\0':NotVerified, 'M':Match, 'N':NotMatch */

	retVal = shc_verify_cavv_caav (header); 
	OTraceDebug( "D-SHC-031201: retvalue from function is <%d>\n", retVal);

	if((header->msg.respcode == SHC_RC_InvalidVisCvc2CAAV) || (header->msg.respcode == SHC_RC_InvalidVis3DSCvc2CAAV))
	{
		decl_on_fail = 1;
	}

	if( retVal == -1)
		shc_setissuerCAVVResultCode( header, '1' );
	else if( retVal == 1)
		shc_setissuerCAVVResultCode( header, '2' );
	else if( retVal == -2)
		shc_setissuerCAVVResultCode( header, '0' );

	OTraceDebug( "D-SHC-031202: cavv_caav_resultcode=%c\n"
				, shc_getissuerCAVVResultCode( header ) ? shc_getissuerCAVVResultCode( header ) : ' ' );

	if(decl_on_fail != 1 && !shcIsStandIn(header))
	{
		header->msg.respcode = 0; 	// need not reject the transaction  if cavv/caav dont match
	}
	return ( header->msg.respcode );
}


int ShcmsgHelper::shc_checkCsc( ShcmsgHeader *header )
{
	int retVal = 0;

	retVal = shc_verify_csc(header);
	OTraceDebug( "D-SHC-031230: csc resultcode=<%d>\n", retVal);
	if ( retVal == 0 )
	{
		OTraceDebug( "D-SHC-031230.2: csc verify skipped\n");
	}else if( retVal == 1 )
	{
		OTraceDebug( "D-SHC-031230.3: csc verify passed\n");
	}else if ( retVal < 0 )
	{
		OTraceDebug( "D-SHC-031230.4: csc verify failed\n");
	}
	return ( header->msg.respcode );
}
#define isCVVResultIgnored(header)   ( (shc_getCvvResultCode(header) == '\0') )
#define isCVVResultMatched(header)   ( (shc_getCvvResultCode(header) == 'M') )
#define isCVVResultFailed(header)	( !isCVVResultIgnored(header) && !isCVVResultMatched(header) )

#define isCAVVResultIgnored(header)  (shc_getissuerCAVVResultCode(header) == '\0')
#define isCAVVResultMatched(header)  (shc_getissuerCAVVResultCode(header) == '2')
#define isCAVVResultFailed(header)  ( !isCAVVResultIgnored(header) && !isCAVVResultMatched(header) )

int ShcmsgHelper::performStandInOnlyChecks( ShcmsgHeader* header )
{
	char xbuf[512] = {0};
        int seglen = 0;
	bool skip_auth_check=false;

        memset(xbuf, 0, sizeof(xbuf));
	if(shcApp->issuerShcParamsList->GetBool((char *)"shc.standin_timeout_skip_auth_check"))
		skip_auth_check=true;

	//only called from pos_auth and shc_saf_fin
	if ( (header->msg.shc_devcap & SH_DEVCAP_SHC_EVENT ) && (skip_auth_check))
	{
		OTraceDebug( "D-SHC-031238: timed out message skip checks. decline with response code [%02d]\n", SHC_RC_UnableToProcess );
		header->msg.respcode = SHC_RC_UnableToProcess;
		return -1;
	}

        header->getSegmentData(xbuf, &seglen, ElfIdMap::elf_to_id(IST_SEG_NETWORK_SETTLEMENT_DATA), TOKEN_REQUESTER_ID);
		
	if((seglen > 0) && header->issShcBin->isTokenTxnChkSkip() && shc_isdown(header->issShcBin->binPkg))
        {
                OTraceDebug("D-SHC-31239: Token transaction - BIN configured to skip performStandInOnlyChecks during stand-in\n");
                return 0;
        }

	if((shcIsAuthorizationRequest(header)) || (shcIsFinancialRequest(header)))
	{
		shc_get_pin_data(header);
		int ret = 0;
		int save_response_code = -1;
		//if from istauth preauth, then save and restore
		if( header->msg.respcode == SHC_RC_Continue )
		{
			save_response_code = header->msg.respcode;
			header->msg.respcode = SHC_RC_Approved;
		}

		if( isCVVEnabledForStandInOnly( header->issShcBin->binPkg) || 
			isDCVVEnabledForStandInOnly(header->issShcBin->binPkg) )
		{
			OTraceDebug( "D-SHC-031238: perform stand-in check for CVV/CVV2/DCVV\n" );
			char ignore_cvv[2];
			int cvv_len = 0;
			memset(ignore_cvv , 0x00, sizeof(ignore_cvv));
			header->getSegmentData(ignore_cvv, &cvv_len, NETWORK_DATA_REQ_id, IGNORE_CVV_CHECK);
			if(!cvv_len)
			{
				shc_checkCvvCvv2(header);
				if( isCVVResultFailed(header) )
				{
					OTraceError("E-SHC-031231: Denied: CVV not valid\n");
					ret = -1;
					goto ret_to_caller;
				}else if( isCVVResultMatched(header) )
				{
					OTraceDebug("D-SHC-031231: check for CVV/CVV2/DCVV Passed\n");
				}else if ( isCVVResultIgnored(header)  ) {
					OTraceDebug("D-SHC-031231: check for CVV/CVV2/DCVV skipped\n");
				}
			}
		}

		if( isCAVVEnabledForStandInOnly( header->issShcBin->binPkg) )
		{
			OTraceDebug( "D-SHC-031238: perform stand-in check for CAVV/3DS\n" );
			shc_checkCavvCaav(header);
			if( isCAVVResultFailed(header) )
			{
				OTraceError("E-SHC-031232: Denied: CAVV/CAAV not valid or cannot be verified\n");
				ret = -1;
				goto ret_to_caller;
			}else if ( isCAVVResultMatched(header) )
			{
				OTraceDebug("D-SHC-031232: check for CAVV/3DS - Passed\n");
			}else if ( isCAVVResultIgnored(header) )
			{
				OTraceDebug("D-SHC-031232: check for CAVV/3DS - skipped\n");
			}
		}

		if( isCSCEnabledOnlyForStandIn( header->issShcBin->binPkg) )
		{
			OTraceDebug( "D-SHC-031238: perform stand-in check for CSC\n" );
			if( shc_checkCsc(header) )
			{
				OTraceError("E-SHC-031233: Denied: CSC not valid or cannot be verified\n");
				ret = -1;
				goto ret_to_caller;
			}
		}

		ret_to_caller:
			if( (ret == -1) && (header->msg.respcode == SHC_RC_Approved) )
			{
				header->msg.respcode = SHC_RC_DoNotHonor;
			}else if ( (ret == 0) && (header->msg.respcode ==  SHC_RC_Approved) && (save_response_code == SHC_RC_Continue) )
			{
				header->msg.respcode = save_response_code;
			}
			return ret;
	}else
	{
		OTraceDebug( "D-SHC-031238: msgtype[%d], not eligible for stand-in check\n", header->msg.msgtype );
	}

	return 0;	
}
