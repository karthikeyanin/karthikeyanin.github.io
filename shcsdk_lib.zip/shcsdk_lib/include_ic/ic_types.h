/*
 * Copyright (C) 2004 eFunds Corporation ("eFunds").  All Rights Reserved.  
 * eFunds Canada Corporation is an authorized user. 
 * 
 * IST is a registered trademark of eFunds Corporation.  Other brand or
 * product names are trademarks or registered trademarks of their respective
 * holders. 
 * 
 * The information contained herein is the unpublished proprietary property
 * of eFunds.  Except as specifically authorized in writing by eFunds, the
 * holder of this document shall: i) keep all information contained herein
 * confidential, and ii) protect the information, in whole or in part, from
 * disclosure and dissemination to all third parties. 
 * 
 * This document and the software described in it are furnished under license
 * and may be used or copied only in accordance with the terms of such license.
 * This document is supplied for information purposes only, is subject to
 * change without notice, and should not be construed as a commitment by
 * either eFunds Corporation or eFunds Canada Corporation. 
 */
#if !defined( _ic_types_h )
#define _ic_types_h
static char _ic_types_h_what[] = "@(#) ic_types.h 1.4 04/07/23 10:56:06";

/*
 *	IST and IST/Share are registered trademarks of Oasis Technology Ltd.
 *
 *	Copyright (C) 1990 - 1998 Oasis Technology Ltd.
 *	All Rights Reserved
 *	This Module contains Proprietary Information of
 *	Oasis Technology Ltd., and should be treated as Confidential.
 *
 *	THIS IS UNPUBLISHED PROPRIETARY SOURCE CODE OF OASIS TECHNOLOGY LTD.
 *	The copyright notice above does not evidence any  
 *	actual or intended publication of such source code.
 *
 *                        MODIFICATION HISTORY                  REVIEW
 *
 *	SPR#	Who	Date	Description			Who	Date   
 * ===========================================================================
 *
 */

#include <ic/ic.h>

#include <ic/ic_exp.h>

#include <ic/ic_pan.h>

#include <ic/ic_bin.h>

#include <ic/ic_shcmsg.h>

#include <ic/ic_trig.h>

#endif
