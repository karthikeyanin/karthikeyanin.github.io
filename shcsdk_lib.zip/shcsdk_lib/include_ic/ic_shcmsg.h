/*
 * Copyright (C) 2004 eFunds Corporation ("eFunds").  All Rights Reserved.  
 * eFunds Canada Corporation is an authorized user. 
 * 
 * IST is a registered trademark of eFunds Corporation.  Other brand or
 * product names are trademarks or registered trademarks of their respective
 * holders. 
 * 
 * The information contained herein is the unpublished proprietary property
 * of eFunds.  Except as specifically authorized in writing by eFunds, the
 * holder of this document shall: i) keep all information contained herein
 * confidential, and ii) protect the information, in whole or in part, from
 * disclosure and dissemination to all third parties. 
 * 
 * This document and the software described in it are furnished under license
 * and may be used or copied only in accordance with the terms of such license.
 * This document is supplied for information purposes only, is subject to
 * change without notice, and should not be construed as a commitment by
 * either eFunds Corporation or eFunds Canada Corporation. 
 */
#ifndef ICSHCMSG_H
#define ICSHCMSG_H
static char _ic_shcmsg_h_what[] = "@(#) ic_shcmsg.h 1.8 07/05/04 14:13:25";

/*
 *	IST and IST/Share are registered trademarks of Oasis Technology Ltd.
 *
 *	Copyright (C) 1990 - 1998 Oasis Technology Ltd.
 *	All Rights Reserved
 *	This Module contains Proprietary Information of
 *	Oasis Technology Ltd., and should be treated as Confidential.
 *
 *	THIS IS UNPUBLISHED PROPRIETARY SOURCE CODE OF OASIS TECHNOLOGY LTD.
 *	The copyright notice above does not evidence any  
 *	actual or intended publication of such source code.
 *
 *                        MODIFICATION HISTORY                  REVIEW
 *
 *	SPR#	Who	Date	Description			Who	Date   
 * ===========================================================================
 *	R002169	wc	10Apr99	Fix for NT porting
 * R019859 jyang 04May07 add a new function 
 *
 */

#if !defined( SHCDLLEXPORT )
#   if defined( WIN32 )
#       define SHCDLLEXPORT __declspec(dllimport)
#   else
#       define SHCDLLEXPORT
#   endif
#endif

#include <ic/ic.h>
#include <shc.h>

/*
 *	IMF C Class for SHCMSG
 */

#define	ICSHCMSG_NFLDS	1024

typedef	struct shcmsg 	ICSHCMSG;
typedef	struct shcmsg *	ICSHCMSGp;
typedef char 			ICSHCMSGBIT[ICSHCMSG_NFLDS];

#define	ICSHCMSG_SZ			sizeof(ICSHCMSG)
#define	ICSHCMSG_TOKEN_L	'<'
#define	ICSHCMSG_TOKEN_R	'>'



	/* Constructor */
SHCDLLEXPORT extern ICReturn	ICShcmsg_shcmsg( void );

SHCDLLEXPORT extern ICReturn	ICShcmsg_putFld( ICSHCMSG *, char *, char * );
SHCDLLEXPORT extern ICReturn	ICShcmsg_getFld( ICSHCMSG *, char *, char *, int * );
SHCDLLEXPORT extern ICReturn 	ICShcmsg_getFld( ICSHCMSG *, char *, char *, int *, int needMask ); // R019859

	/* Operators */
SHCDLLEXPORT extern ICReturn	ICShcmsg_isDataNull( ICSHCMSG *, char * );

	/* Functions */
SHCDLLEXPORT extern ICReturn	ICShcmsg_expand( ICSHCMSG *, char *, char * );

SHCDLLEXPORT extern ICReturn	ICShcmsg_clrBit( ICSHCMSGBIT * );
SHCDLLEXPORT extern ICReturn	ICShcmsg_setBit( ICSHCMSGBIT *, char * );
SHCDLLEXPORT extern ICReturn	ICShcmsg_rstBit( ICSHCMSGBIT *, char * );

SHCDLLEXPORT extern ICReturn	ICShcmsg_cmpFld( ICSHCMSG *, ICSHCMSG *, char * );
SHCDLLEXPORT extern ICReturn	ICShcmsg_cmpFld( ICSHCMSG *, ICSHCMSG *, char * );
SHCDLLEXPORT extern ICReturn	ICShcmsg_cmpMsg( ICSHCMSG *, ICSHCMSG *, ICSHCMSGBIT * );
SHCDLLEXPORT extern ICReturn	ICShcmsg_cpyMsg( ICSHCMSG *, ICSHCMSG *, ICSHCMSGBIT * );
SHCDLLEXPORT extern ICReturn  ICShcmsg_cpyFld( ICSHCMSG *srcp, ICSHCMSG *dstp, char *name );

SHCDLLEXPORT extern ICReturn	ICShcmsg_printMsg( ICSHCMSG *, ICSHCMSGBIT *, FILE *, char * );

#endif	/* #ifndef ICSHCMSG_H */

