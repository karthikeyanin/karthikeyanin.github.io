//
// Copyright (C) 2004 eFunds Corporation ("eFunds").  All Rights Reserved.  
// eFunds Canada Corporation is an authorized user. 
// 
// IST is a registered trademark of eFunds Corporation.  Other brand or
// product names are trademarks or registered trademarks of their respective
// holders. 
// 
// The information contained herein is the unpublished proprietary property
// of eFunds.  Except as specifically authorized in writing by eFunds, the
// holder of this document shall: i) keep all information contained herein
// confidential, and ii) protect the information, in whole or in part, from
// disclosure and dissemination to all third parties. 
// 
// This document and the software described in it are furnished under license
// and may be used or copied only in accordance with the terms of such license.
// This document is supplied for information purposes only, is subject to
// change without notice, and should not be construed as a commitment by
// either eFunds Corporation or eFunds Canada Corporation. 
//
static	char ver[100]="IST/Segtest: Version ";
static	char _shc_cxx_what[] = "@(#) shcsegtest.cxx 1.3 04/07/23 10:55:39";

/*
 *	IST and IST/Share are registered trademarks of Oasis Technology Ltd.
 *
 *	Copyright (C) 1990 - 1999 Oasis Technology Ltd.
 *	All Rights Reserved
 *	This Module contains Proprietary Information of
 *	Oasis Technology Ltd., and should be treated as Confidential.
 *
 *	THIS IS UNPUBLISHED PROPRIETARY SOURCE CODE OF OASIS TECHNOLOGY LTD.
 *	The copyright notice above does not evidence any  
 *	actual or intended publication of such source code.
 */
/*
 *
 *                        MODIFICATION HISTORY                  REVIEW
 *
 *	SPR#	Who	Date		Description			Who	Date   
 * ===========================================================================
 * R007796 ztang 15May02	Creation
 * R008387 ztang 10Oct02	Added more tests
 */

#include <stdio.h>
#include <signal.h>
#include <stdlib.h>
#include <errno.h>
#include <oasis.h>
#include <mb.h>
#include <tsk.h>
#include <rules.h>
#include <config.h>
#include <string.h>
#include <shc.h>



extern "C" 
{
	void 	shcsegtestexit(int n);
}

int main(int argc, char **argv)
{
	argv0 = *argv;
	char buf[200];
	char samplebuf[] = "01234567890123456789";
	catch_all_signals( shcsegtestexit );
	struct shcseg *p=NULL;

		
	strcat(ver, VERSION);
	ODebugOn("shcsegtest.debug");
	debug("%s\n", ver);
	p = (struct shcseg *)calloc(1, SHC_SEG_MAX + sizeof(struct shc));
	shc_segbegin((struct shcseg *)p);
	for (int i=0; i<25; i++)
	{
		char segtype[100];
		strncpy(segtype, samplebuf, i%20+1);
		segtype[i%20+1] = '\0';
		shc_segaddsegment(p, segtype);
		debug("Added segment [%s]\n", segtype);
		for (int j=0;j<i%10; j++)
		{
			shcsegopt_t opt;
			long action;
			char data[100];
			opt = j;
			action=10-j;
			strncpy(data, samplebuf, j+1);
			data[j+1] = '\0';
			
			shc_segaddoption(p, opt, action, data, j+1);
			debug("	Option [%s]\n", data);
		}
		
		if (i%10 != 0)
		{
			char segdata[100];
			strncpy(segdata, samplebuf, i%10);
			segdata[i%10+1] = '\0';
			shc_segadddata(p, segdata, i%10);
			debug("	Segment Data [%s] added\n", segdata);
			if (i%5 != 0)
			{
				segdata[0] = '|';
				strncpy(&segdata[1], samplebuf, i%5);
				segdata[i%5+1] = '\0';
				shc_segadddata(p, segdata, i%5+1);
				debug("	Segment Data [%s] added\n", segdata);
			}
		}
	}
	shc_segend(p);
	
	
	/* Read the segment data back */
	debug("Result: %d segments, total size %d\n", shc_segnsegments(p), shc_seglength(p));
	struct shcsegstart *sp;
	sp = shc_segfirst(p);
	struct	shcsegopt * sopt;
	
	while(sp != NULL)
	{
		debug("Segment Type [%s]\n", shc_segname(p, sp));
		debug("	Data [%s]\n", shc_seggetdata_pointer(p, sp));
		debug("	Number of options [%d]\n", shc_segnopt(p, sp));
		sopt = shc_segfirstopt(p, sp);
		while(sopt != NULL)
		{
			struct shcsegopt tmpOpt[4];
			memcpy(tmpOpt, sopt, sizeof(tmpOpt));
			memcpy(tmpOpt, sopt, tmpOpt[0].optlen);
			debug("		Option opt[%ld] len[%ld] datalen[%d] action[%d] data[%.*s]\n", 
				tmpOpt[0].opt, tmpOpt[0].optlen, tmpOpt[0].datalen, tmpOpt[0].action, tmpOpt[0].datalen, tmpOpt[0].optdata);
			sopt = shc_segnextopt(p, sp, sopt);
		}
		sp = shc_segnext(p, sp);
	}
	
	sp = shc_segfind(p, "0123");
	if (sp != NULL)
	{
		debug("Segment Type [%s]\n", shc_segname(p, sp));
		debug("	Data [%s]\n", shc_seggetdata_pointer(p, sp));
		debug("	Number of options [%d]\n", shc_segnopt(p, sp));
		sopt = shc_segfindopt(p, sp, 1);
		if (sopt != NULL)
		{
			struct shcsegopt tmpOpt[4];
			memcpy(tmpOpt, sopt, sizeof(tmpOpt));
			memcpy(tmpOpt, sopt, tmpOpt[0].optlen);
			debug("		Option opt[%ld] len[%ld] datalen[%d] action[%d] data[%.*s]\n", 
				tmpOpt[0].opt, tmpOpt[0].optlen, tmpOpt[0].datalen, tmpOpt[0].action, tmpOpt[0].datalen, tmpOpt[0].optdata);
		}
		else
			debug("	No Option\n");
	}
	else
		debug("Can't find Segment [%s]\n", "0123");
	
	return(0);
}

void shcsegtestexit(int n)
{
	static int	count = 0;

		
	ODebugOff();

	if(n > 1)
		kill(getpid(), n);

	exit(n);
}

