//
// Copyright (C) 2004 eFunds Corporation ("eFunds").  All Rights Reserved.  
// eFunds Canada Corporation is an authorized user. 
// 
// IST is a registered trademark of eFunds Corporation.  Other brand or
// product names are trademarks or registered trademarks of their respective
// holders. 
// 
// The information contained herein is the unpublished proprietary property
// of eFunds.  Except as specifically authorized in writing by eFunds, the
// holder of this document shall: i) keep all information contained herein
// confidential, and ii) protect the information, in whole or in part, from
// disclosure and dissemination to all third parties. 
// 
// This document and the software described in it are furnished under license
// and may be used or copied only in accordance with the terms of such license.
// This document is supplied for information purposes only, is subject to
// change without notice, and should not be construed as a commitment by
// either eFunds Corporation or eFunds Canada Corporation. 
//
static	char ver[100]="IST/Acceptor Name test: Version ";
static  char _acceptorname_cxx_what[] = "@(#) acceptorname.cxx 1.3 10/05/27 14:08:07";

/*
 *	IST and IST/Share are registered trademarks of Oasis Technology Ltd.
 *
 *	Copyright (C) 1990 - 1999 Oasis Technology Ltd.
 *	All Rights Reserved
 *	This Module contains Proprietary Information of
 *	Oasis Technology Ltd., and should be treated as Confidential.
 *
 *	THIS IS UNPUBLISHED PROPRIETARY SOURCE CODE OF OASIS TECHNOLOGY LTD.
 *	The copyright notice above does not evidence any  
 *	actual or intended publication of such source code.
 */
/*
 *
 *                        MODIFICATION HISTORY                  REVIEW
 *
 *	SPR#	Who	 Date		Description			Who	Date   
 * ===========================================================================
 * R027879 jyang 15Feb10	Creation
 * R028078 dipa  20Apr10    Added store number and mall name
 */

#include <stdio.h>
#include <signal.h>
#include <stdlib.h>
#include <errno.h>
#include <oasis.h>
#include <mb.h>
#include <tsk.h>
#include <rules.h>
#include <config.h>
#include <string.h>
#include <shc.h>
#include <ist_otrace.h>
#include <ShcAcceptorName.h>
#include <ShcmsgHeader.h>


int test_acceptorname()
{
	char xbuf[200]={0};
	// test #1 - Backward compatible
	//ShcAcceptorName testOut1((char*)"\\23456789 123456789 123\\23456789 123ONCA");	// MasterCard
	ShcAcceptorName testOut1((char*)"\\23456789 123456789 12345\\23456789 123CA"); // Visa
	
	testOut1.getName(xbuf);
	printf("name[%s] ", xbuf );
	testOut1.getCityName(xbuf);
	printf("city[%s] ", xbuf );
	testOut1.getStateName(xbuf);
	printf("state[%s] ", xbuf );
	testOut1.getTwoCharCountryCode(xbuf);
	printf("country[%s]\n", xbuf );

	printf("MC  :[%s]\n\n", testOut1.outputAcceptorName( "MC" ) );
	printf("VISA:[%s]\n\n", testOut1.outputAcceptorName( "VISA" ) );
	
	
	// test #2 - Create segment data
	ShcAcceptorName testIn;
	
	testIn.setAddressSeg((char *)"\\ADDRESS 0123456789 123456789 123456789012");
	testIn.setPostalSeg("\\POSTAL89012");
	testIn.setPhoneSeg("\\PHONE78901234567");
	testIn.setStoreSeg("\\6676"); //R028078
	testIn.setMallSeg("\\DEBENHAMS"); //R028078
	testIn.setAdditionalData("\\Whatever data you want to store!");
	
	testIn.setName("\\NAME6789 123456789 123456789 1234567890");
	testIn.setCityName("\\CITY6789 1234567890");
	testIn.setStateName("ON");
//	testIn.setCountryCode("CA");
	testIn.setNumericCountryCode(840);
	
	const char *segData;
	//segData = testIn.generateSegmentData("\\NAME6789 123456789 123456789 1234567890", "\\CITY6789 1234567890", "ON", "CA");
	segData = testIn.generateSegmentData();
	
	printf("segData:[%d][%s]\n\n", strlen(segData), segData );
	
	// test #3 - parse info from segment data
	ShcAcceptorName testOut;
	
	// #3.1 - Visa
	testOut.parseSegAcceptorName( segData, strlen(segData) );
	printf("VISA:[%s]\n", testOut.outputAcceptorName( "VISA" ) );
	
	// #3.2
	printf("VISA:[%s]\n\n", testOut.getAcceptorNameFromSegment(segData, strlen(segData), "VISA") );

	// test #4 - MasterCard
	printf("MC:  [%s]\n\n", testOut.outputAcceptorName( "MC" ) );
	
	// test #4 - Discover
	printf("DISC:[%s%s%s%s%s]\n\n", testOut.outputAcceptorName( "DISC" ), testOut.getAddressSeg(), 
				testOut.getPostalSeg(),testOut.getPhoneSeg(), testOut.getAdditionalData() );
	
	
	// test #5 - FISB
	char *ptr=xbuf;
    /// Use address first if provided
    if ( strlen(testOut.getAddressSeg()) > 0 )
    {
        // put address
        ptr += testOut.getAddressSeg( ptr, 23 );
    }
    else        /// then Name field
    {
        // Name - 23 characters to FISB
        ptr += testOut.getNameSeg( ptr, 23 );
    }

    // City - 13 characters to FISB
    ptr += testOut.getCitySeg( ptr, 13 );

    // State - 2 characters to FISB
    ptr += testOut.getStateSeg( ptr, 2 );

    // Country - 2 characters to FISB
    strcat( ptr, testOut.getCountryChar2() );

///         sprintf(shcmsg->msg.acceptorname, "%-23s%-13s%-2s%-2s", wName, wCity, wState, wCCode);
	
	printf( "FISB:[%s]\n\n", xbuf );
	
	// test #6 - old way
	ptr=xbuf;
	testOut.getName(xbuf);
	printf("name:[%s] ", xbuf );
	testOut.getCityName(xbuf);
	printf("city[%s] ", xbuf );
	testOut.getStateName(xbuf);
	printf("state[%s] ", xbuf );
	testOut.getTwoCharCountryCode(xbuf);
	printf("country[%s]\n\n", xbuf );
	
	ptr += testOut.getNameSeg(xbuf,25);
	printf("name:[%s] ", xbuf );
	ptr += testOut.getCitySeg(xbuf, 13);
	printf("city[%s] ", xbuf );
	ptr += testOut.getStateSeg(xbuf, 2);
	printf("state[%s] ", xbuf );
	ptr += testOut.getCountrySeg(xbuf, 2);
	printf("country[%s]\n", xbuf );
	
//	printf("name:[%s] city[%s] state[%s] country[%s]\n\taddress[%s] postal[%s] phone[%s] additional[%s]\n\n"
	printf("\taddress[%s] postal[%s] phone[%s] store[%s] mall[%s] additional[%s]\n\n"
				, testOut.getAddressSeg(), testOut.getPostalSeg(), testOut.getPhoneSeg(), 
				testOut.getStoreSeg(), testOut.getMallSeg(), testOut.getAdditionalData());
	
	printf("name:[%s] city[%s] state[%s] country[%s] address[%s] postal[%s] phone[%s] store[%s] mall[%s] additional[%s]\n\n"
				, testOut.getNameSeg(), testOut.getCitySeg(), testOut.getStateSeg(), testOut.getCountrySeg()
				, testOut.getAddressSeg(), testOut.getPostalSeg(), testOut.getPhoneSeg(),
				testOut.getStoreSeg(), testOut.getMallSeg(),testOut.getAdditionalData());

	// test #7 - API for ShcmsgHeader
	ShcmsgHeader hdr;
	// store acceptor name into segment of ShcmsgHeader
	testIn.saveSegment( &hdr );
	
	// clear local segBuffer
	testIn.clearSegBuffer();
	
	// load acceptor name into local segBuffer from segment of ShcmsgHeader
	testIn.loadSegment( &hdr );
	
	// print out data in segment of ShcmsgHeader
	segData = testIn.getSegBuffer();
	printf("ShcmsgHeader - segData:[%d][%s]\n\n", strlen(segData), segData );

	return 0;
}


int main(int argc, char **argv)
{
	argv0 = *argv;
	char buf[200];
	char choice[10];

	ODebugOn(argv0);
	ist_otrace_set_level(OTRACE_DEBUG);
	
	test_acceptorname();

	ODebugOff();

	return 0;
}

