//
// Copyright (C) 2004 eFunds Corporation ("eFunds").  All Rights Reserved.  
// eFunds Canada Corporation is an authorized user. 
// 
// IST is a registered trademark of eFunds Corporation.  Other brand or
// product names are trademarks or registered trademarks of their respective
// holders. 
// 
// The information contained herein is the unpublished proprietary property
// of eFunds.  Except as specifically authorized in writing by eFunds, the
// holder of this document shall: i) keep all information contained herein
// confidential, and ii) protect the information, in whole or in part, from
// disclosure and dissemination to all third parties. 
// 
// This document and the software described in it are furnished under license
// and may be used or copied only in accordance with the terms of such license.
// This document is supplied for information purposes only, is subject to
// change without notice, and should not be construed as a commitment by
// either eFunds Corporation or eFunds Canada Corporation. 
//
static	char ver[100]="IST/Segtest: Version ";
static  char _shc_cxx_what[] = "@(#) shcshmtest.cxx 1.8 08/02/12 17:28:31";

/*
 *	IST and IST/Share are registered trademarks of Oasis Technology Ltd.
 *
 *	Copyright (C) 1990 - 1999 Oasis Technology Ltd.
 *	All Rights Reserved
 *	This Module contains Proprietary Information of
 *	Oasis Technology Ltd., and should be treated as Confidential.
 *
 *	THIS IS UNPUBLISHED PROPRIETARY SOURCE CODE OF OASIS TECHNOLOGY LTD.
 *	The copyright notice above does not evidence any  
 *	actual or intended publication of such source code.
 */
/*
 *
 *                        MODIFICATION HISTORY                  REVIEW
 *
 *	SPR#	Who	Date		Description			Who	Date   
 * ===========================================================================
 * R030556 dipa  14Jun12	Creation
 */

#include <stdio.h>
#include <signal.h>
#include <stdlib.h>
#include <errno.h>
#include <oasis.h>
#include <mb.h>
#include <tsk.h>
#include <rules.h>
#include <config.h>
#include <string.h>
#include <shc.h>
#include <multi_institution.h>
#include <ist_otrace.h>
#include <ShcAppBase.h>
#include <InstProfile.h>
#include <ShcKeyHelper.h>
#include <ShcHelper.h>
#include <ic/ic_bin.h>
#include <ic/ic_instid.h>

extern int acqProfileFindUpBin;
void test_shcSecurity();
void test_shcPin();
void test_shcExtBin();
void test_shcBinKeys();
void print_shckeys(struct shcsecurity *);
void print_shcpkg(struct shcpkg *pkg, struct shckeysmem *shcbinkey);

void print_shckeys(struct shcsecurity *key)
{
		printf("i[%s] u[%s] b[%s] keytypes[%c] kek[%s] kekchk[%s]\n",
						key->k.institutionid, 
						key->k.userbinid, 
						key->k.bin,
						key->k.keytypes, 
						key->k.kek, 
						key->k.kekchk);
		printf("acqpinidx[%d] acqpin1[%s] acqpin1chk[%s] acqpin2[%s] acqpin2chk[%s]\n",
					key->k.acqpinidx,
					key->k.acqpin1,
					key->k.acqpin1chk,
					key->k.acqpin2,
					key->k.acqpin2chk);
		printf("isspinidx[%d] isspin1[%s] isspin1chk[%s] isspin2[%s] isspin2chk[%s]\n",
					key->k.isspinidx,
					key->k.isspin1,
					key->k.isspin1chk,
					key->k.isspin2,
					key->k.isspin2chk);
		printf("acqmacidx[%d] acqmac1[%s] acqmac1chk[%s] acqmac2[%s] acqmac2chk[%s]\n",
					key->k.acqmacidx,
					key->k.acqmac1,
					key->k.acqmac1chk,
					key->k.acqmac2,
					key->k.acqmac2chk);
		printf("issmacidx[%d] issmac1[%s] issmac1chk[%s] issmac2[%s] issmac2chk[%s]\n",
					key->k.issmacidx,
					key->k.issmac1,
					key->k.issmac1chk,
					key->k.issmac2,
					key->k.issmac2chk);
		printf("flags[%s] o_rowid[%ld] acqbin[%s] issbin[%s] acqkek[%s] acqkekchk[%s]\n",
					key->k.flags,
					key->k.o_rowid,
					key->k.acqbin,
					key->k.issbin,
					key->k.acqkek,
					key->k.acqkekchk);
		printf("acqpin3[%s] acqpin3chk[%s] acqmac3[%s] acqmac3chk[%s] isspin3[%s] isspin3chk[%s] issmac3[%s] issmac3chk[%s]\n",
					key->k.acqpin3,
					key->k.acqpin3chk,
					key->k.acqmac3,
					key->k.acqmac3chk,
					key->k.isspin3,
					key->k.isspin3chk,
					key->k.issmac3,
					key->k.issmac3chk);
		printf("acqkmeidx[%d] acqkme1[%s] acqkme1chk[%s] acqkme2[%s] acqkme2chk[%s] acqkme3[%s] acqkme3chk[%s]\n",
					key->k.acqkmeidx,
					key->k.acqkme1,
					key->k.acqkme1chk,
					key->k.acqkme2,
					key->k.acqkme2chk,
					key->k.acqkme3,
					key->k.acqkme3chk);
		printf("isskmeidx[%d] isskme1[%s] isskme1chk[%s] isskme2[%s] isskme2chk[%s] isskme3[%s] isskme3chk[%s]\n",
					key->k.isskmeidx,
					key->k.isskme1,
					key->k.isskme1chk,
					key->k.isskme2,
					key->k.isskme2chk,
					key->k.isskme3,
					key->k.isskme3chk);
		printf("%c:%c:%c:%c:%c:%c:%c:%c:%c:%c\n",
					key->k.acqkekstat, key->k.acqpin1stat, key->k.acqmac1stat,
					key->k.acqkme1stat, key->k.acqpin2stat, key->k.acqmac2stat,
					key->k.acqkme2stat, key->k.acqpin3stat, key->k.acqmac3stat,
					key->k.acqkme3stat);
		printf("%c:%c:%c:%c:%c:%c:%c:%c:%c:%c\n",
					key->k.isskekstat, key->k.isspin1stat, key->k.issmac1stat,
					key->k.isskme1stat, key->k.isspin2stat, key->k.issmac2stat,
					key->k.isskme2stat, key->k.isspin3stat, key->k.issmac3stat,
					key->k.isskme3stat);
		printf("acqkekcnt[%s]\n", key->k.acqkekcnt);
		printf("acqpin1cnt[%s] acqpin2cnt[%s] acqpin3cnt[%s] \n",
					key->k.acqpin1cnt, key->k.acqpin2cnt, key->k.acqpin3cnt); 
		printf("acqmac1cnt[%s] acqmac2cnt[%s] acqmac3cnt[%s]\n",
					key->k.acqmac1cnt, key->k.acqmac2cnt, key->k.acqmac3cnt);
		printf("acqkme1cnt[%s] acqkme2cnt[%s] acqkme3cnt[%s]\n",
					key->k.acqkme1cnt, key->k.acqkme2cnt, key->k.acqkme3cnt);
		printf("isskekcnt[%s] \n", key->k.isskekcnt);
		printf("isspin1cnt[%s] isspin2cnt[%s] isspin3cnt[%s]\n",
					key->k.isspin1cnt, key->k.isspin2cnt, key->k.isspin3cnt);
		printf("issmac1cnt[%s] issmac2cnt[%s] issmac3cnt[%s] \n",
					key->k.issmac1cnt, key->k.issmac2cnt, key->k.issmac3cnt);
		printf("isskme1cnt[%s] isskme2cnt[%s] isskme3cnt[%s]\n",
					key->k.isskme1cnt, key->k.isskme2cnt, key->k.isskme3cnt);
		printf("def_class[%c] def_index[%c] val_new[%c] val_seq[%c] val_chk[%c] upd_tbl[%c]\n",
					key->k.def_class, key->k.def_index, key->k.val_new,
					key->k.val_seq, key->k.val_chk,key->k.upd_tbl);
		printf("kek_len[%d] isskpe_len[%d] isskme_len[%d] issmac_len[%d] acqkpe_len[%d] acqkme_len[%d] acqmac_len[%d]\n",
					key->k.kek_len, key->k.isskpe_len, key->k.isskme_len,
					key->k.issmac_len, key->k.acqkpe_len, key->k.acqkme_len, key->k.acqmac_len);
		printf("macusage[%d] pinusage[%d] pinchange[%d] macchange[%d] hash[%ld]\n",
				key->macusage, key->pinusage, key->pinchange, key->macchange, key->hash);
	return;
}

void test_shcSecurity()
{
	bin_t issuer;
	char txnSrc[20], txnDest[20], iss_entityId[100];
	int msgtype;
	NetworkInfo n;
	struct shcsecurity *key = NULL;

	printf("Testing shcSecurity Global Pointer\n");
	printf("----------------------------------\n");

	printf("Retrieving SHCKEYS record using NetworkInfo...\n");
	printf("\nPlease input information in following order:\n");
	printf("txnSrc txnDest iss_entityid msgtype issuer\n");
	scanf("%s %s %s %d %s", txnSrc, txnDest, iss_entityId, &msgtype, issuer);
	printf("\ntxnSrc[%s] txnDest[%s] iss_entityid[%s] msgtype[%d] issuer[%s]\n",txnSrc, txnDest, iss_entityId, msgtype, issuer);

	shcApp->instProfileObj->locateNetworkInfo(txnSrc, txnDest,iss_entityId,msgtype,issuer, n);
	if (n.foundNetworkInfo())
	{
		printf("\nINST profile entry found.\n");
		if(rm_isMultiVerSupported(0))
		{
			struct InstitutionProfile *ip;
			memcpy(ip,n.getInstProfileEntry(),sizeof(struct InstitutionProfile));
			printf("INST_PROFILE: i[%s] txnsrc[%s] txndest[%s] keyparamstr[%s] keyparm[%d]\n",
				ip->instId, ip->m_txnSrc, ip->m_txnDest, ip->keyparamStr,ip->keyparm);
			printf("INST_PROFILE: status[%c] id[%d] priority[%d]\n",
				ip->status, ip->id, ip->m_priority);
			key = shcApp->shcKeyObj->getKey(ip->instId, ip->keyparamStr);
		}
		else
			key = &shcSecurity[n.getKeyparam()];
		
		if(key)
			print_shckeys(key);
		else
			printf("SHCKEYS not configured for the instprofile entry.\n");
	}
	else
		printf("ERROR: INST profile entry not found\n");

	return;
}

void print_shcpkg(struct shcpkg *pkg, struct shckeysmem *shcbinkey)
{
	int i,j;
	printf("\nBIN information\n");
	printf("instid[%s] userbinid[%s] networkid[%s] owner[%s]\n",
			pkg->bin.institutionid,pkg->bin.userbinid,pkg->bin.networkid,pkg->bin.owner);
	printf("mb[%s] port[%s] netmgrid[%s] bintype[%d] timeout[%d] flags[%ld]\n",
			mbtab[pkg->bin.mailbox].name,mbtab[pkg->bin.port].name,mbtab[pkg->bin.netmgrid].name,pkg->bin.bintype,pkg->bin.timeout,pkg->bin.flags);
	printf("pinparm[%d] country_code[%d] currcode[%d] cvvdate[%d] cardid[%d] statid[%d]\n",
			pkg->bin.pinparm,pkg->bin.country_code,pkg->bin.currency_code,pkg->bin.cvvdate,
			pkg->bin.cardid,pkg->bin.statid);
	printf("last_online_activity[%ld] bankname[%s] cammailboxid[%d] bin_cfg[%ld] node[%s]\n",
			pkg->bin.last_online_activity,pkg->bin.bankname,pkg->bin.cammailboxid,
			pkg->bin.bin_cfg,pkg->bin.node);

	printf("\nSAF information\n");
	printf("type[%d] num[%d] refreshtime[%ld] fd[%d] posmailbox[%d] replayid[%d]\n",
		pkg->saf.type, pkg->saf.num,pkg->saf.refreshtime,pkg->saf.fd,pkg->saf.posmailbox,pkg->saf.replayid);

	printf("\nSHCTXN Information\n");
	printf("npintry[%d] txnset[%ld]\n",pkg->txn.npintry, pkg->txn.txnset);

	printf("\nSHCAUTH Information\n");
	printf("type[%d] authserver[%d] def_from_acct[%d] def_to_acct[%d]\n",
		pkg->auth.type, pkg->auth.authserver,pkg->auth.def_from_acct,pkg->auth.def_to_acct);

	printf("\nbalInfo[%ld]\n\n",pkg->balInfo);
	return;
}

void print_shcPin(struct pinverparm *pin, struct shcpkg *pkg)
{
	printf("Pin index: %d   Institution %s BIN: %s\n", pkg->bin.pinparm, pin->institutionid, pin->bin);
	printf("bin offset: %d  pan len: %d panvaloffset: %d  panvallen: %d\n",
					pin->binoffset, pin->panlen, pin->panvaloffset, pin->panvallen);
	printf("Pan Pad: %c  Pin Pad: %c  Pin len: %d  Pin offset: %d\n",
					pin->panpad, pin->pinpad, pin->pinlen, pin->pinoffset);
	printf("Decimalization: %s  ekpv: %s\nekpv_comkey: %s\n",
					pin->dec_table, pin->ekpv, pin->ekpv_comkey);
	printf("Pin Method: %s  Pin Blk: %s\n", pin->pinmethod, pin->pinblk);
	printf("Expiry offset: %d  Branch Offset: %d  Verify Flag: %c\n",
	pin->expiryoffset, pin->branchoffset, pin->verify_pin_local);
	printf("Service code offset: %d\n", pin->scodeoffset);
	printf("CVV Offset: %d\n", pin->cvvoffset);
	printf("CVV A-KEY: %s\n", pin->cvv_a_key);
	printf("CVV B-KEY: %s\n", pin->cvv_b_key);
	printf("pin->visa_pvk1_key_0 = %s\n", pin->visa_pvk1_key_0);
	printf("pin->visa_pvk2_key_0 = %s\n", pin->visa_pvk2_key_0);
	printf("pin->visa_pvk1_key_1 = %s\n", pin->visa_pvk1_key_1);
	printf("pin->visa_pvk2_key_1 = %s\n", pin->visa_pvk2_key_1);
	printf("pin->visa_pvk1_key_2 = %s\n", pin->visa_pvk1_key_2);
	printf("pin->visa_pvk2_key_2 = %s\n", pin->visa_pvk2_key_2);
	printf("pin->visa_pvk1_key_3 = %s\n", pin->visa_pvk1_key_3);
	printf("pin->visa_pvk2_key_3 = %s\n", pin->visa_pvk2_key_3);
	printf("pin->visa_pvk1_key_4 = %s\n", pin->visa_pvk1_key_4);
	printf("pin->visa_pvk2_key_4 = %s\n", pin->visa_pvk2_key_4);
	printf("pin->visa_pvk1_key_5 = %s\n", pin->visa_pvk1_key_5);
	printf("pin->visa_pvk2_key_5 = %s\n", pin->visa_pvk2_key_5);
	printf("pin->visa_pvk1_key_6 = %s\n", pin->visa_pvk1_key_6);
	printf("pin->visa_pvk2_key_6 = %s\n", pin->visa_pvk2_key_6);
	printf("visa pvk 1: %s\n", pin->visa_pvk1_key);
	printf("visa pvk 2: %s\n", pin->visa_pvk2_key);
	printf("visa pvki offset: %d\n", pin->pvkioffset);
	printf("visa pvv  offset: %d\n", pin->pvvoffset);
	
	return;
}
void test_shcPin()
{
	char instid[20], userbinid[20];
	struct shcpkg *pkg;
	struct	pinverparm	*pin;


	printf("Testing shcPin Global Pointer\n");
	printf("----------------------------------\n");

	printf("\nPlease input information in following order:\n");
	printf("instid userbinid\n");
	scanf("%s %s",instid, userbinid);
	shc_normalizebin(userbinid);
	printf("instid[%s] userbinid[%s]\n",instid,userbinid);

	if(shc_locate_bin(&pkg,instid,userbinid) < 0)
	{
		printf("InstitutionId[%s] and UserbinId[%s] is not valid\n",instid,userbinid);
		return;
	}

	
	pin = &shcPin[pkg->bin.pinparm];
	printf("Fetch PIN using shcPin Global Pointer\n");
	printf("-------------------------------------\n");
	print_shcPin(pin,pkg);

	pin = NULL;
	pin = shcApp->shcHelperObj->shc_getpinparm(pkg->bin.pinparm);
	printf("\n\nFetch PIN using shc_getpinparm() API\n");
	printf("------------------------------------\n");
	print_shcPin(pin,pkg);

	return;
}
	

void test_shcBinKeys()
{
	struct shcpkg *pkg;
	struct	shckeysmem	*shcbinkey;
	char instid[20], userbinid[20];

	printf("Testing shcBinKeys Global Pointer\n");
	printf("----------------------------------\n");

	printf("\nPlease input information in following order:\n");
	printf("instid userbinid\n");
	scanf("%s %s",instid, userbinid);
	shc_normalizebin(userbinid);
	printf("instid[%s] userbinid[%s]\n",instid,userbinid);

	if(rm_isMultiVerSupported(0))
	{
		if(shc_locate_bin(&pkg,instid,userbinid) < 0)
		{
			printf("BIN not located for instid[%s] and userbinid[%s]\n",instid,userbinid);
			return;
		}
		shcbinkey = newlyFoundShcBinKey;
	}
	else
	{
	
		//Old way of shc_locate_bin() implementation
		bin_t	tmpInstitutionId;
		bin_t	tmpUserBinId;
		int		i;
		int		n;

		ICInstId_pure( (ICBINp) tmpInstitutionId, (ICBINp ) instid);
		ICBin_rjfy( (ICBINp) tmpUserBinId, (ICBINp ) userbinid);
		printf("shcNumberOfKeys[%d]\n",shcNumberOfKeys);

		for(i = 0; i < shcNumberOfKeys; ++i)
		{
			if(	(stricmp(tmpInstitutionId, shcBinKeys[i].institutionid) == 0) &&
				(stricmp(tmpUserBinId, shcBinKeys[i].userbinid) == 0) )
					break;
		}
		if(i < shcNumberOfKeys)
		{
			shcbinkey = &shcBinKeys[i];
			pkg = &shcBinPkg[shcBinKeys[i].textid];
		}
		else
		{
			printf("BIN not located for instid[%s] and userbinid[%s]\n",instid,userbinid);	
			return;
		}
		

		//if(shc_locate_bin(&pkg,instid,userbinid) < 0)
		//{
		//	printf("Unable to locate shcbin\n");
		//	return;
		//}

	}
	if(pkg)
		print_shcpkg(pkg, shcbinkey);
	else
		printf("Shcpkg not found\n");

	return;
}

int main(int argc, char **argv)
{
	argv0 = *argv;
	char buf[200];
	char choice[10];

	ODebugOn(argv0);
	ist_otrace_set_level(OTRACE_DEBUG);
	

	mb_init();
	shc_init();
	while (choice[0] != '0')
	{
		printf("*****************************************************\n");
		printf("0:	Exit\n");
		printf("1:  shcSecurity Global Pointer testing\n");
		printf("2:  shcPin Global Pointer testing\n");
		printf("3:  shcBinKeys Global Pointer testing\n");
		printf("Your Choice:\n");
		scanf("%s", choice);	
		
		switch(choice[0])
		{
		case '1':
			test_shcSecurity();
			break;
		case '2':
			test_shcPin();
			break;
		case '3':
			test_shcBinKeys();
			break;
		}
	}
	
	return 0;
}

