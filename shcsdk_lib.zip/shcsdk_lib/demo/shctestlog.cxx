//
// Copyright (C) 2004 eFunds Corporation ("eFunds").  All Rights Reserved.  
// eFunds Canada Corporation is an authorized user. 
// 
// IST is a registered trademark of eFunds Corporation.  Other brand or
// product names are trademarks or registered trademarks of their respective
// holders. 
// 
// The information contained herein is the unpublished proprietary property
// of eFunds.  Except as specifically authorized in writing by eFunds, the
// holder of this document shall: i) keep all information contained herein
// confidential, and ii) protect the information, in whole or in part, from
// disclosure and dissemination to all third parties. 
// 
// This document and the software described in it are furnished under license
// and may be used or copied only in accordance with the terms of such license.
// This document is supplied for information purposes only, is subject to
// change without notice, and should not be construed as a commitment by
// either eFunds Corporation or eFunds Canada Corporation. 
//
static	char ver[100]="IST/Segtest: Version ";
static  char _shc_trest_cxx_what[] = "@(#) shcroute.cxx 1.2 12/07/02 03:11:51";

/*
 *	IST and IST/Share are registered trademarks of Oasis Technology Ltd.
 *
 *	Copyright (C) 1990 - 1999 Oasis Technology Ltd.
 *	All Rights Reserved
 *	This Module contains Proprietary Information of
 *	Oasis Technology Ltd., and should be treated as Confidential.
 *
 *	THIS IS UNPUBLISHED PROPRIETARY SOURCE CODE OF OASIS TECHNOLOGY LTD.
 *	The copyright notice above does not evidence any  
 *	actual or intended publication of such source code.
 */
/*
 *
 *                        MODIFICATION HISTORY                  REVIEW
 *
 *	SPR#	Who	Date		Description			Who	Date   
 * ===========================================================================
 * R008717 ztang 15May02	Creation
 */

#include <stdio.h>
#include <signal.h>
#include <stdlib.h>
#include <errno.h>
#include <oasis.h>
#include <mb.h>
#include <mb_umi.h>
#include <tsk.h>
#include <rules.h>
#include <config.h>
#include <string.h>
#include <shc.h>
#include <multi_institution.h>
#include <ist_otrace.h>
#include <InstProfile.h>
#include <BinRoute.h>
#include <CShcLog.h>
#include <iostream>
#include <vector>
#include <ShcmsgHeader.h>
#include<ist_seg_name.h>
#include<ist_seg_fn_data.h>
#include<ist_seg_elf_id_map.h>



using namespace std;

ShcLog *shcmsgLogObj = NULL;

//initDB();
//int prepareUpdateVoid();
//virtual int prepareUpdateReversal();
//virtual int prepareUpdateFinCapture();
//virtual int doUpdateVoid();
//virtual int doUpdateReversal();
//virtual int doUpdateFinCapture();

int testUpdates()
{
	struct shcmsg oldmsg;

	ShcmsgHeader *header = new ShcmsgHeader();


	if (shcmsgLogObj == NULL)
	{
		cout <<  "Unable to create shclog Object" << endl;
		exit(0);
	}

    header->msg.msgtype = 110;
	if( mb_getUmi( header->msg.shclog_id, sizeof(header->msg.shclog_id) ) < 0 )
	{
			OTraceError("E-SHCLOG-5011:SHC-MAKEKEY: Unable to make key.\n");
			exit(-1);
	}
	else
		OTraceLog("L-SHCLOG-5017: New ID [%s] created for m%04d/t%06d/p%06d\n",
			header->msg.shclog_id, header->msg.msgtype, header->msg.trace, header->msg.pcode);
 	IstSegFNData *fnData = (IstSegFNData*)header->getSegmentObj(ElfIdMap::elf_to_id(IST_SEG_FN_DATA), IST_SEG_CREATE);	
	fnData->setNetworkTerminalId("TEST1234");

	shcmsgLogObj->logTxn((ShcHeader *)header);

	header->msg.shcerror = 99;

	shcmsgLogObj->doUpdateVoid(header);

	//shcmsgLogObj->logTxn((ShcHeader *)header);
	dbm_commit(getpid());

	
    //header->msg.msgtype = 110;
	//shcmsgLogObj->logTxn((ShcHeader *)header);

	//shcmsgLogObj->locateTxnChipIndex(header, &oldmsg, 0);
	//dbm_commit(getpid());
	//

	delete header;

	return 1;
}

	
int testLogTxn()
{
	struct shcmsg oldmsg;

	ShcmsgHeader *header = new ShcmsgHeader();


	if (shcmsgLogObj == NULL)
	{
		cout <<  "Unable to create shclog Object" << endl;
		exit(0);
	}

    header->msg.msgtype = 100;
	if( mb_getUmi( header->msg.shclog_id, sizeof(header->msg.shclog_id) ) < 0 )
	{
			OTraceError("E-SHCLOG-5011:SHC-MAKEKEY: Unable to make key.\n");
			exit(-1);
	}
	else
		OTraceLog("L-SHCLOG-5017: New ID [%s] created for m%04d/t%06d/p%06d\n",
			header->msg.shclog_id, header->msg.msgtype, header->msg.trace, header->msg.pcode);

 	IstSegFNData *fnData = (IstSegFNData*)header->getSegmentObj(ElfIdMap::elf_to_id(IST_SEG_FN_DATA), IST_SEG_CREATE);	
	fnData->setNetworkTerminalId("TEST1234");


	shcmsgLogObj->logTxn((ShcHeader *)header);
	dbm_commit(getpid());

	
    header->msg.msgtype = 110;
	shcmsgLogObj->logTxn((ShcHeader *)header);

	//shcmsgLogObj->locateTxnChipIndex(header, &oldmsg, 0);
	dbm_commit(getpid());
	//

	delete header;

	return 1;
}

int testChipLocate()
{
	struct shcmsg oldmsg;

	ShcmsgHeader *header = new ShcmsgHeader();


	if (shcmsgLogObj == NULL)
	{
		cout <<  "Unable to create shclog Object" << endl;
		exit(0);
	}

    header->msg.msgtype = 100;
	if( mb_getUmi( header->msg.shclog_id, sizeof(header->msg.shclog_id) ) < 0 )
	{
			OTraceError("E-SHCLOG-5011:SHC-MAKEKEY: Unable to make key.\n");
			exit(-1);
	}
	else
		OTraceLog("L-SHCLOG-5017: New ID [%s] created for m%04d/t%06d/p%06d\n",
			header->msg.shclog_id, header->msg.msgtype, header->msg.trace, header->msg.pcode);


	shcmsgLogObj->logTxn((ShcHeader *)header);
	dbm_commit(getpid());

	
	shcmsgLogObj->locateTxnChipIndex(header, &oldmsg, IST_SHCLOG_FLAG_LOCATE_RESP);
	shcmsgLogObj->locateTxnChipIndex(header, &oldmsg, IST_SHCLOG_FLAG_LOCATE_REQ);
	shcmsgLogObj->locateTxnChipIndex(header, &oldmsg, IST_SHCLOG_FLAG_LOCATE_RESP | IST_SHCLOG_FLAG_LOCATE_REQ);

    header->msg.msgtype = 110;
	shcmsgLogObj->logTxn((ShcHeader *)header);

	shcmsgLogObj->locateTxnChipIndex(header, &oldmsg, 0);
	dbm_commit(getpid());

	delete header;

	return 1;
}

int testRefnumLocate()
{
	struct shcmsg oldmsg;

	ShcmsgHeader *header = new ShcmsgHeader();


	if (shcmsgLogObj == NULL)
	{
		cout <<  "Unable to create shclog Object" << endl;
		exit(0);
	}

	header->reset();

    header->msg.msgtype = 100;
	if( mb_getUmi( header->msg.shclog_id, sizeof(header->msg.shclog_id) ) < 0 )
	{
			OTraceError("E-SHCLOG-5011:SHC-MAKEKEY: Unable to make key.\n");
			exit(-1);
	}
	else
		OTraceLog("L-SHCLOG-5017: New ID [%s] created for m%04d/t%06d/p%06d\n",
			header->msg.shclog_id, header->msg.msgtype, header->msg.trace, header->msg.pcode);

	strcpy(header->msg.pan, "123412341234");
	strcpy(header->msg.refnum, "923456789012");


	shcmsgLogObj->logTxn((ShcHeader *)header);
	dbm_commit(getpid());

	shcmsgLogObj->locateTxnRefnum(header, &oldmsg, IST_SHCLOG_FLAG_LOCATE_RESP);
	shcmsgLogObj->locateTxnRefnum(header, &oldmsg, IST_SHCLOG_FLAG_LOCATE_REQ);
	shcmsgLogObj->locateTxnRefnum(header, &oldmsg,  IST_SHCLOG_FLAG_LOCATE_RESP | IST_SHCLOG_FLAG_LOCATE_REQ);

	
    header->msg.msgtype = 110;

	shcmsgLogObj->locateTxnRefnum(header, &oldmsg, IST_SHCLOG_FLAG_LOCATE_RESP);
	shcmsgLogObj->locateTxnRefnum(header, &oldmsg, IST_SHCLOG_FLAG_LOCATE_REQ);
	shcmsgLogObj->locateTxnRefnum(header, &oldmsg,  IST_SHCLOG_FLAG_LOCATE_RESP | IST_SHCLOG_FLAG_LOCATE_REQ);

	dbm_commit(getpid());

	delete header;

	return 1;
}

int testTxnSeqLocate()
{
	struct shcmsg oldmsg;

	ShcmsgHeader *header = new ShcmsgHeader();


	if (shcmsgLogObj == NULL)
	{
		cout <<  "Unable to create shclog Object" << endl;
		exit(0);
	}

	header->reset();

    header->msg.msgtype = 100;
	if( mb_getUmi( header->msg.shclog_id, sizeof(header->msg.shclog_id) ) < 0 )
	{
			OTraceError("E-SHCLOG-5011:SHC-MAKEKEY: Unable to make key.\n");
			exit(-1);
	}
	else
		OTraceLog("L-SHCLOG-5017: New ID [%s] created for m%04d/t%06d/p%06d\n",
			header->msg.shclog_id, header->msg.msgtype, header->msg.trace, header->msg.pcode);

	strcpy(header->msg.pan, "123412341234");
	strcpy(header->msg.refnum, "923456789012");


	shcmsgLogObj->logTxn((ShcHeader *)header);
	dbm_commit(getpid());

	shcmsgLogObj->locateTxnSeq(header, &oldmsg, NULL, IST_SHCLOG_FLAG_LOCATE_RESP);
	shcmsgLogObj->locateTxnSeq(header, &oldmsg, NULL, IST_SHCLOG_FLAG_LOCATE_REQ);
	shcmsgLogObj->locateTxnSeq(header, &oldmsg, NULL, IST_SHCLOG_FLAG_LOCATE_RESP | IST_SHCLOG_FLAG_LOCATE_REQ);

	
    header->msg.msgtype = 110;

	//shcmsgLogObj->locateTxnRefnum(header, &oldmsg, IST_SHCLOG_FLAG_LOCATE_RESP);
	//shcmsgLogObj->locateTxnRefnum(header, &oldmsg, IST_SHCLOG_FLAG_LOCATE_REQ);
	//shcmsgLogObj->locateTxnRefnum(header, &oldmsg,  IST_SHCLOG_FLAG_LOCATE_RESP | IST_SHCLOG_FLAG_LOCATE_REQ);

	dbm_commit(getpid());

	delete header;

	return 1;
}

int testLocate()
{
	struct shcmsg oldmsg;

	ShcmsgHeader *header = new ShcmsgHeader();


	if (shcmsgLogObj == NULL)
	{
		cout <<  "Unable to create shclog Object" << endl;
		exit(0);
	}

	header->reset();

    header->msg.msgtype = 100;
	if( mb_getUmi( header->msg.shclog_id, sizeof(header->msg.shclog_id) ) < 0 )
	{
			OTraceError("E-SHCLOG-5011:SHC-MAKEKEY: Unable to make key.\n");
			exit(-1);
	}
	else
		OTraceLog("L-SHCLOG-5017: New ID [%s] created for m%04d/t%06d/p%06d\n",
			header->msg.shclog_id, header->msg.msgtype, header->msg.trace, header->msg.pcode);

	strcpy(header->msg.pan, "4321123412341234");
	//strcpy(header->msg.refnum, "923456789012");


	shcmsgLogObj->logTxn((ShcHeader *)header);
	dbm_commit(getpid());

	shcmsgLogObj->locateTxn(header, &oldmsg, NULL, IST_SHCLOG_FLAG_LOCATE_RESP);
	shcmsgLogObj->locateTxn(header, &oldmsg, NULL, IST_SHCLOG_FLAG_LOCATE_REQ);
	shcmsgLogObj->locateTxn(header, &oldmsg, NULL, IST_SHCLOG_FLAG_LOCATE_RESP | IST_SHCLOG_FLAG_LOCATE_REQ);

	
    header->msg.msgtype = 110;

	//shcmsgLogObj->locateTxnRefnum(header, &oldmsg, IST_SHCLOG_FLAG_LOCATE_RESP);
	//shcmsgLogObj->locateTxnRefnum(header, &oldmsg, IST_SHCLOG_FLAG_LOCATE_REQ);
	//shcmsgLogObj->locateTxnRefnum(header, &oldmsg,  IST_SHCLOG_FLAG_LOCATE_RESP | IST_SHCLOG_FLAG_LOCATE_REQ);

	dbm_commit(getpid());

	delete header;

	return 1;
}

int main(int argc, char **argv)
{
	argv0 = *argv;
	char buf[200];
	char choice[10];

	OTraceOn(argv0);
	ist_otrace_set_level(OTRACE_DEBUG);

	mb_init();
	shc_init();
	dbm_init();

	shcmsgLogObj = new ShcLog();

	//testUpdates();
	testLogTxn();
	//testChipLocate();
	//testRefnumLocate();
	//testTxnSeqLocate();
	//testLocate();


	while (choice[0] != '0')
	{
		("0:	Exit\n");
		cout << "0: Exit" << endl;
		cout << "1: run testLog txn" << endl;
		cout << "2: run roundrobin Tests" << endl;
		cin >> choice[0];
		
		switch(choice[0])
		{
			case '1':
				testLogTxn();
				break;
			case '2':
				//runRoundRobin();
				break;
		}
	}

	dbm_commit(getpid());

	OTraceOff();
	
	return 0;
}

