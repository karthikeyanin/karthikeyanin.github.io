//
// Copyright (C) 2004 eFunds Corporation ("eFunds").  All Rights Reserved.  
// eFunds Canada Corporation is an authorized user. 
// 
// IST is a registered trademark of eFunds Corporation.  Other brand or
// product names are trademarks or registered trademarks of their respective
// holders. 
// 
// The information contained herein is the unpublished proprietary property
// of eFunds.  Except as specifically authorized in writing by eFunds, the
// holder of this document shall: i) keep all information contained herein
// confidential, and ii) protect the information, in whole or in part, from
// disclosure and dissemination to all third parties. 
// 
// This document and the software described in it are furnished under license
// and may be used or copied only in accordance with the terms of such license.
// This document is supplied for information purposes only, is subject to
// change without notice, and should not be construed as a commitment by
// either eFunds Corporation or eFunds Canada Corporation. 
//
static	char ver[100]="IST/Segtest: Version ";
static  char _shc_cxx_what[] = "@(#) shctest.cxx 1.2.2.1 16/10/21 10:04:55";

/*
 *	IST and IST/Share are registered trademarks of Oasis Technology Ltd.
 *
 *	Copyright (C) 1990 - 1999 Oasis Technology Ltd.
 *	All Rights Reserved
 *	This Module contains Proprietary Information of
 *	Oasis Technology Ltd., and should be treated as Confidential.
 *
 *	THIS IS UNPUBLISHED PROPRIETARY SOURCE CODE OF OASIS TECHNOLOGY LTD.
 *	The copyright notice above does not evidence any  
 *	actual or intended publication of such source code.
 */
/*
 *
 *                        MODIFICATION HISTORY                  REVIEW
 *
 *	SPR#	Who	Date		Description			Who	Date   
 * ===========================================================================
 * xxxxxxxx ztang 15May02	Creation
 */

#include <stdio.h>
#include <signal.h>
#include <stdlib.h>
#include <errno.h>
#include <oasis.h>
#include <mb.h>
#include <tsk.h>
#include <rules.h>
#include <config.h>
#include <string.h>
#include <shc.h>
#include <shcprototype.h>
#include <multi_institution.h>
#include <ist_otrace.h>
#include <ShcAppBase.h>
#include <ShcBin.h>
#include <IssProfile.h>

void test_shcmsg_locate_track_data()
{
	struct shcmsg tmpMsg;
	strcpy(tmpMsg.track2, "4501000600070008=0604101");
	char *p=shcmsg_locate_track_data(&tmpMsg);
	if (strncmp(p, "0604", 4)!=0)
		printf("test_shc_locate_track_data failed:%s\n", p);
	else
		printf("test_shc_locate_track_data succeeded\n");
	return;
}

void test_shc_get_iss_acq_xt()
{
	struct ShcWithSegment buf = { 0 };
	struct shc *shcp = &buf.shc;
	strcpy(shcp->msg.pan, "4502612000123456");
	strcpy(shcp->msg.track2, "4501000600070008=0604101");
	strcpy(shcp->msg.txnSrc, "04");
	extBinCountryCode = 0;
	shc_get_iss_acq_xt(shcp, 1);
	if (shcp->issbin && shcp->acqbin && (extBinCountryCode > 0))
		printf("shc_get_iss_acq_xt Succeed.\n");
	return;
}

void test_shc_isdown()
{
        ShcBin shcBinObj;
        shcBinObj.setBinPkg("ztang_r1l0");
        shcBinObj.setInstDown();
        if (shc_isdown(shcBinObj.binPkg))
                printf("1 passed.\n");
        else
                printf("1 failed.\n");
        ShcBin tmpbin;
        tmpbin.setBinPkg("ztang_r1l1");
        tmpbin.setInstDown();
        shcBinObj.setInstUp();
        strcpy(routingRecord.bin, "ztang_r1l1");
        if (shc_isdown(shcBinObj.binPkg))
                printf("2 passed.\n");
        else
                printf("2 failed.\n");
        tmpbin.setInstUp();
        if (!shc_isdown(shcBinObj.binPkg))
                printf("3 passed.\n");
        else
                printf("3 failed.\n");
        return;
}

int main(int argc, char **argv)
{
	argv0 = *argv;
	char buf[200];
	char choice[10];

	ODebugOn(argv0);
	ist_otrace_set_level(OTRACE_DEBUG);
	

	shc_init();
	
        test_shc_isdown();
	//test_shcmsg_locate_track_data();
	//test_shc_get_iss_acq_xt();
	return 0;
}

