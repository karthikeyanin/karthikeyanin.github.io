//
// Copyright (C) 2004 eFunds Corporation ("eFunds").  All Rights Reserved.  
// eFunds Canada Corporation is an authorized user. 
// 
// IST is a registered trademark of eFunds Corporation.  Other brand or
// product names are trademarks or registered trademarks of their respective
// holders. 
// 
// The information contained herein is the unpublished proprietary property
// of eFunds.  Except as specifically authorized in writing by eFunds, the
// holder of this document shall: i) keep all information contained herein
// confidential, and ii) protect the information, in whole or in part, from
// disclosure and dissemination to all third parties. 
// 
// This document and the software described in it are furnished under license
// and may be used or copied only in accordance with the terms of such license.
// This document is supplied for information purposes only, is subject to
// change without notice, and should not be construed as a commitment by
// either eFunds Corporation or eFunds Canada Corporation. 
//
static	char ver[100]="IST/Segtest: Version ";
static  char _shc_route_cxx_what[] = "@(#) shcroute.cxx 1.2 12/07/02 03:11:51";

/*
 *	IST and IST/Share are registered trademarks of Oasis Technology Ltd.
 *
 *	Copyright (C) 1990 - 1999 Oasis Technology Ltd.
 *	All Rights Reserved
 *	This Module contains Proprietary Information of
 *	Oasis Technology Ltd., and should be treated as Confidential.
 *
 *	THIS IS UNPUBLISHED PROPRIETARY SOURCE CODE OF OASIS TECHNOLOGY LTD.
 *	The copyright notice above does not evidence any  
 *	actual or intended publication of such source code.
 */
/*
 *
 *                        MODIFICATION HISTORY                  REVIEW
 *
 *	SPR#	Who	Date		Description			Who	Date   
 * ===========================================================================
 * R008717 ztang 15May02	Creation
 */

#include <stdio.h>
#include <signal.h>
#include <stdlib.h>
#include <errno.h>
#include <oasis.h>
#include <mb.h>
#include <tsk.h>
#include <rules.h>
#include <config.h>
#include <string.h>
#include <shc.h>
#include <multi_institution.h>
#include <ist_otrace.h>
#include <InstProfile.h>
#include <BinRoute.h>
#include <iostream>
#include <vector>
using namespace std;


int getBin(struct shc& shc)
{
	if (shc.msg.pin[0] == '-')
		shc.msg.pin[0] = '\0';
	
	shc_normalizepan(shc.msg.pan);
	shc.msg.respcode = 0;
	shc_get_iss_acq_xt(&shc, 1 );

	return 0;
}

void checkRouting(struct shc& shc, int caseno )
{
	IssuerInfo issuerInfo;
	AcquirerInfo acquirerInfo;
	NetworkInfo networkInfo;

	int ret=0;
	
	if (shc.msg.respcode == 0)
	{
		cout << "issuer =" << shc.msg.issuer << endl;
		cout << "acquirer =" << shc.msg.acquirer << endl;
		shc_locate_network_info(shc.msg.txnSrc, shc.msg.msgtype, shc.msg.issuer, networkInfo);
		if (networkInfo.foundNetworkInfo())
			cout << "outbound inst profile result:" << networkInfo.getExternalId() << ":" << networkInfo.getExternalIdDesc() <<
				":" << networkInfo.getMember_ID() << ":" << networkInfo.getF_ID() << endl;
		else
			cout << "outbound inst profile error" << endl;
		if ( networkInfo.isRouteSet() )
		{
			struct RoutingInfo route;	
			memcpy( &route, networkInfo.getRoutingInfo(), sizeof(struct RoutingInfo));
			cout << "route: mailbox=" << route.mailbox << "," << "port=" << route.port << endl;
		}
		else
		{
			cout << "route not set\n";
		}
		cout << endl;

	}			
	return;
}
	
int getBinRoutes( char* issuer, vector<struct s_binroute>& routes )
{
	struct rules_keytab *appHead;
	char *appKey;

	int appidBinRoute = rm_getappid((char*)"shc-bin-route");
	if (appidBinRoute == -1)
	{
		cout << "error accessing binroute shared memory\n";
		exit(0);
	}
	else
	{
		appHead = rm_getapphead(appidBinRoute);
		appKey = rm_getappkey(appidBinRoute);
	}
	
	int i;
	routes.clear();
	char* p;
	s_binroute * tmpRoute;
	for (i=0, p=appKey ;i<appHead->keysused;i++, p+= appHead->keysize)
	{
		tmpRoute = (s_binroute *)p;
		if (strcmp(tmpRoute->internalid, issuer))
			continue;

		routes.push_back(*tmpRoute);
	}

	return 0;
}

void fillRoutingInfo (struct RoutingInfo& ri, struct s_binroute& route )
{
        strcpy(ri.destNode, route.node);
        strcpy(ri.mailbox, route.mailbox);
        strcpy(ri.port, route.port);
}

void displayCase(int caseno)
{
	cout << "Case [" << caseno << "]-----------------------------------" << endl;
}

void displayStatus( char* issuer )
{
	vector<struct s_binroute> routes;
	routes.clear();
	getBinRoutes( issuer, routes );
	vector<struct s_binroute>::iterator itr;
	for ( itr = routes.begin(); itr != routes.end(); itr++ )
	{
		cout << "route: " << itr->node << " " << itr->port << " " 
		<< itr->mailbox << " Priority[" << itr->priority << "] status["  << itr->status << "]" << endl;
	}
	cout << endl;
}

void runCases ( int* caseno,  vector<struct s_binroute>& routes, struct shc& shc )
{
	if ( routes.size() == 0 )
		return;

	struct s_binroute route = routes[0];
	routes.erase(routes.begin());
	vector<struct s_binroute> save_routes = routes;
	struct RoutingInfo routingInfo = { 0 };
	fillRoutingInfo( routingInfo, route );
	binRouteObj->markRouteDown( shc.msg.issuer, &routingInfo, 0 );
	runCases ( caseno, save_routes, shc );
	(*caseno)++;
	displayCase(*caseno);
	displayStatus( shc.msg.issuer );
	checkRouting( shc, *caseno );

	save_routes = routes;
	binRouteObj->markRouteUp( shc.msg.issuer, &routingInfo, 0 );
	runCases ( caseno, save_routes, shc );
	(*caseno)++;
	displayCase(*caseno);
	displayStatus( shc.msg.issuer );
	checkRouting( shc, *caseno );
}

void runTests()
{
	char txnsrc[11] = {0};
	char pan[20] = {0};
	char pin[17] = {0};
	char entityId[32] = {0};
	int msgtype = 0;
	int merchType = 0;
	int pcode;
	int currency;
	struct shc shc = {0};

	cout << "Please input information in following order:\n";
	cout << "txnSrc PAN msgType deviceType(merchant type) pcode PIN_block(-) entityId currency\n";
	scanf("%s %s %d %hd %ld %d %s %hd", shc.msg.txnSrc, shc.msg.pan, &shc.msg.msgtype, &shc.msg.merchant_type,
                        &shc.msg.pcode, shc.msg.pin, shc.msg.entityId, &shc.msg.acq_currency_code);

	getBin( shc );
	if ( shc.msg.respcode != 0 )
	{
		cout << "error [%d] locating bin " << shc.msg.respcode;
		exit(0);
	}

	vector<struct s_binroute> routes;
	getBinRoutes( shc.msg.issuer, routes );

	if ( routes.size() == 0 )
	{
		cout << "no routes identified" << endl;
		exit(0);
	}
	cout << routes.size() << " routes identified" << endl;

	vector<struct s_binroute>::iterator itr;
	for ( itr = routes.begin(); itr != routes.end(); itr++ )
	{
		struct RoutingInfo routingInfo = { 0 };
		fillRoutingInfo( routingInfo, *itr );
		binRouteObj->markRouteUp( shc.msg.issuer, &routingInfo, 0 );
	}
	int caseno = 0;
	runCases ( &caseno, routes, shc );
}

void runRoundRobin()
{
	char txnsrc[11] = {0};
	char pan[20] = {0};
	char pin[17] = {0};
	char entityId[32] = {0};
	int msgtype = 0;
	int merchType = 0;
	int pcode;
	int currency;
	struct shc shc = {0};

	cout << "Please input information in following order:\n";
	cout << "txnSrc PAN msgType deviceType(merchant type) pcode PIN_block(-) entityId currency\n";
	scanf("%s %s %d %hd %ld %d %s %hd", shc.msg.txnSrc, shc.msg.pan, &shc.msg.msgtype, &shc.msg.merchant_type,
                        &shc.msg.pcode, shc.msg.pin, shc.msg.entityId, &shc.msg.acq_currency_code);

	getBin( shc );
	if ( shc.msg.respcode != 0 )
	{
		cout << "error [%d] locating bin " << shc.msg.respcode;
		exit(0);
	}

	vector<struct s_binroute> routes;
	getBinRoutes( shc.msg.issuer, routes );

	if ( routes.size() == 0 )
	{
		cout << "no routes identified" << endl;
		exit(0);
	}
	cout << routes.size() << " routes identified" << endl;

	vector<struct s_binroute>::iterator itr;
	for ( itr = routes.begin(); itr != routes.end(); itr++ )
	{
		struct RoutingInfo routingInfo = { 0 };
		fillRoutingInfo( routingInfo, *itr );
		binRouteObj->markRouteUp( shc.msg.issuer, &routingInfo, 0 );
	}
	int caseno = 1;
	displayStatus( shc.msg.issuer );
	for ( int idx = 0 ; idx < 50; idx++ )
		checkRouting( shc, caseno++ );
	
}
int main(int argc, char **argv)
{
	argv0 = *argv;
	char buf[200];
	char choice[10];

	ODebugOn(argv0);
	ist_otrace_set_level(OTRACE_DEBUG);
	

	mb_init();
	shc_init();
	while (choice[0] != '0')
	{
		("0:	Exit\n");
		cout << "0: Exit" << endl;
		cout << "1: run all combination Tests" << endl;
		cout << "2: run roundrobin Tests" << endl;
		cin >> choice[0];
		
		switch(choice[0])
		{
			case '1':
				runTests();
				break;
			case '2':
				runRoundRobin();
				break;
		}
	}
	
	return 0;
}

