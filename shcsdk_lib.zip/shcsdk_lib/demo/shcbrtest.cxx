//
// Copyright (C) 2004 eFunds Corporation ("eFunds").  All Rights Reserved.  
// eFunds Canada Corporation is an authorized user. 
// 
// IST is a registered trademark of eFunds Corporation.  Other brand or
// product names are trademarks or registered trademarks of their respective
// holders. 
// 
// The information contained herein is the unpublished proprietary property
// of eFunds.  Except as specifically authorized in writing by eFunds, the
// holder of this document shall: i) keep all information contained herein
// confidential, and ii) protect the information, in whole or in part, from
// disclosure and dissemination to all third parties. 
// 
// This document and the software described in it are furnished under license
// and may be used or copied only in accordance with the terms of such license.
// This document is supplied for information purposes only, is subject to
// change without notice, and should not be construed as a commitment by
// either eFunds Corporation or eFunds Canada Corporation. 
//
static	char ver[100]="IST/Segtest: Version ";
static  char _shc_cxx_what[] = "@(#) shcbrtest.cxx 1.3 12/10/29 13:54:54";

/*
 *	IST and IST/Share are registered trademarks of Oasis Technology Ltd.
 *
 *	Copyright (C) 1990 - 1999 Oasis Technology Ltd.
 *	All Rights Reserved
 *	This Module contains Proprietary Information of
 *	Oasis Technology Ltd., and should be treated as Confidential.
 *
 *	THIS IS UNPUBLISHED PROPRIETARY SOURCE CODE OF OASIS TECHNOLOGY LTD.
 *	The copyright notice above does not evidence any  
 *	actual or intended publication of such source code.
 */
/*
 *
 *                        MODIFICATION HISTORY                  REVIEW
 *
 *	SPR#	Who	Date		Description			Who	Date   
 * ===========================================================================
 * R008717 ztang 15May02	Creation
 */

#include <stdio.h>
#include <signal.h>
#include <stdlib.h>
#include <errno.h>
#include <oasis.h>
#include <mb.h>
#include <tsk.h>
#include <rules.h>
#include <config.h>
#include <string.h>
#include <shc.h>
#include <multi_institution.h>
#include <BinRoute.h>
#include <InstProfile.h>
#include <ist_otrace.h>
#include <ShcAppBase.h>

void markBinAndRouteUpTest()
{
	struct RoutingInfo r = { 0 };
	bin_t  bin = { 0 };
	printf("Please input information in following order, use - to skip a data:\n");
	printf("internal_bin node mailbox port \n");
	scanf("%s %s %s %s", bin, r.destNode, r.mailbox, r.port);
	if (r.destNode[0] == '-')
		r.destNode[0] = '\0';
	if (r.mailbox[0] == '-')
		r.mailbox[0] = '\0';
	if (r.port[0] == '-')
		r.port[0] = '\0';
	if (bin[0] == '-')
		bin[0] = '\0';
	else
		shc_normalizebin(bin);
	binRouteObj->markRouteAndBinUp(bin, &r);
	return;
}

void locateNetworkInfoTest()
{
	bin_t  bin = { 0 };
	printf("Please input information in following order, use - to skip a data:\n");
	printf("txnSrc, txnDest, iss_entityId, msgtype, internal_bin, Routing?(Y/N).\n");
	char routingOrNot[10];
	char txnSrc[20];
	char txnDest[20];
	char iss_entityId[20];
	char msgTypeStr[20];
	scanf("%s %s %s %s %s %s", txnSrc, txnDest, iss_entityId, msgTypeStr, bin, routingOrNot);
	if (txnSrc[0] == '-')
		txnSrc[0] = '\0';
	if (txnDest[0] == '-')
		txnDest[0] = '\0';
	if (iss_entityId[0] == '-')
		iss_entityId[0] = '\0';
	int msgType = atoi(msgTypeStr);
	if (bin[0] == '-')
		bin[0] = '\0';
	else
		shc_normalizebin(bin);
	NetworkInfo networkInfo;
	setRoutingWithInstProfile = ((routingOrNot[0] == 'Y')||(routingOrNot[0] == 'y'))?1:0;
	shcApp->instProfileObj->locateNetworkInfo(txnSrc, txnDest, iss_entityId, msgType, bin, networkInfo);
	return;
}

//void retractTest()
//{
//	struct RoutingInfo r = { 0 };
//	int  profileId;
//	char profileIdStr[80];
//	printf("Please input information in following order, use - to skip a data:\n");
//	printf("profileId node mailbox port \n");
//	scanf("%d %s %s %s", profileIdStr, r.destNode, r.mailbox, r.port);
//	if (r.destNode[0] == '-')
//		r.destNode[0] = '\0';
//	if (r.mailbox[0] == '-')
//		r.mailbox[0] = '\0';
//	if (r.port[0] == '-')
//		r.port[0] = '\0';
//	if (profileIdStr[0] == '-')
//		profileId = 0;
//	else
//		profileId = atoi(profileIdStr);
//	binRouteObj->retractCounter(NULL, &r, profileId);
//	return;
//}


int main(int argc, char **argv)
{
	argv0 = *argv;
	char buf[200];
	char choice[10];

	ODebugOn(argv0);
	ist_otrace_set_level(OTRACE_DEBUG);
	

	mb_init();
	shc_init();
	while (choice[0] != '0')
	{
		printf("*****************************************************\n");
		printf("0:	Exit\n");
		printf("1:  Mark route and bin up\n");
		printf("2:  (disabled)retract counter\n");
		printf("3:  locateNetworkInfo\n");
		printf("Your Choice:\n");
		scanf("%s", choice);	
		
		switch(choice[0])
		{
		case '1':
			markBinAndRouteUpTest();
			break;
//		case '2':
//			retractTest();
//			break;
		case '3':
			locateNetworkInfoTest();
			break;
		}
	}
	
	return 0;
}

