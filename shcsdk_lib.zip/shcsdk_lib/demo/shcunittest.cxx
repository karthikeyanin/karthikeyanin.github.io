//
// Copyright (C) 2004 eFunds Corporation ("eFunds").  All Rights Reserved.  
// eFunds Canada Corporation is an authorized user. 
// 
// IST is a registered trademark of eFunds Corporation.  Other brand or
// product names are trademarks or registered trademarks of their respective
// holders. 
// 
// The information contained herein is the unpublished proprietary property
// of eFunds.  Except as specifically authorized in writing by eFunds, the
// holder of this document shall: i) keep all information contained herein
// confidential, and ii) protect the information, in whole or in part, from
// disclosure and dissemination to all third parties. 
// 
// This document and the software described in it are furnished under license
// and may be used or copied only in accordance with the terms of such license.
// This document is supplied for information purposes only, is subject to
// change without notice, and should not be construed as a commitment by
// either eFunds Corporation or eFunds Canada Corporation. 
//
static  char _shcunittest_cxx_what[] = "@(#) shcunittest.cxx 1.2 16/07/07 14:53:02";

/*
 *	IST and IST/Share are registered trademarks of Oasis Technology Ltd.
 *
 *	Copyright (C) 1990 - 1999 Oasis Technology Ltd.
 *	All Rights Reserved
 *	This Module contains Proprietary Information of
 *	Oasis Technology Ltd., and should be treated as Confidential.
 *
 *	THIS IS UNPUBLISHED PROPRIETARY SOURCE CODE OF OASIS TECHNOLOGY LTD.
 *	The copyright notice above does not evidence any  
 *	actual or intended publication of such source code.
 */
/*
 *
 *                        MODIFICATION HISTORY                  REVIEW
 *
 *	SPR#	Who	Date		Description			Who	Date   
 * ===========================================================================
 * R008717 ztang 15May02	Creation
 */

#include <stdio.h>
#include <signal.h>
#include <stdlib.h>
#include <errno.h>
#include <oasis.h>
#include <mb.h>
#include <tsk.h>
#include <rules.h>
#include <config.h>
#include <string.h>
#include <shc.h>
#include <multi_institution.h>
#include <ist_otrace.h>
#include <ShcmsgHeader.h>
#include <ShcAppBase.h>
#include <ShcTimerHelper.h>


void eventTest()
{
	printf("2 event test in total\n");
	struct shcmsg msg = {0};
	msg.msgtype = 200;
	msg.trace = 123456;
	strcpy(msg.pan,"1234123412341234   ");
	strcpy(msg.termid,"123456");
	
	ShcmsgHeader header(&msg);
	shc_get_current_date();
	header.time_in = shc_current_time;
	header.time_out = header.time_in+20;

	shcmid = mb_locatemailbox("SharedCash");


	if(shcApp->shcTimerObj->shc_time_message(&header) < 0)
	{
		printf("Failed to enqueue message\n");
		return;
	}
	struct ShcWithSegment tmpshc = { 0 };
	memcpy(&tmpshc.shc.msg, &msg, sizeof(msg));
	tmpshc.shc.msg.msgtype = 210;
	strcpy(tmpshc.shc.msg.termid, "123456  ");
	
	
	if (shcmid < 0)
	{
		printf("Can't find SharedCash mailbox\n");
		return;
	}
	
	if (shc_locate_event(&tmpshc.shc, NULL) >= 0)
	{
		printf("Success shc_locate_event\n");
	}
	else
		printf("Fail shc_locate_event\n");
	
	if (shc_locate_event_x(&tmpshc.shc, NULL, NULL) >= 0)
	{
		printf("Success shc_locate_event_x\n");
	}
	else
		printf("Fail shc_locate_event\n");
	
	tm_dequeue(header.eventId);
	
	
	return;
}


int main(int argc, char **argv)
{
	argv0 = *argv;
	char buf[200];
	char choice[10];

	OTraceOn(argv0);
	
	mb_init();
	shc_init();

	eventTest();
		
	return 0;
}

