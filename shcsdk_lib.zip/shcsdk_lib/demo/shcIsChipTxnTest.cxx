//
// Copyright (C) 2004 eFunds Corporation ("eFunds").  All Rights Reserved.  
// eFunds Canada Corporation is an authorized user. 
// 
// IST is a registered trademark of eFunds Corporation.  Other brand or
// product names are trademarks or registered trademarks of their respective
// holders. 
// 
// The information contained herein is the unpublished proprietary property
// of eFunds.  Except as specifically authorized in writing by eFunds, the
// holder of this document shall: i) keep all information contained herein
// confidential, and ii) protect the information, in whole or in part, from
// disclosure and dissemination to all third parties. 
// 
// This document and the software described in it are furnished under license
// and may be used or copied only in accordance with the terms of such license.
// This document is supplied for information purposes only, is subject to
// change without notice, and should not be construed as a commitment by
// either eFunds Corporation or eFunds Canada Corporation. 
//
static	char ver[100]="IST/Segtest: Version ";
static  char _shc_cxx_what[] = "@(#) shcIsChipTxnTest.cxx 1.1 09/05/20 17:04:41";

/*
 *	IST and IST/Share are registered trademarks of Oasis Technology Ltd.
 *
 *	Copyright (C) 1990 - 1999 Oasis Technology Ltd.
 *	All Rights Reserved
 *	This Module contains Proprietary Information of
 *	Oasis Technology Ltd., and should be treated as Confidential.
 *
 *	THIS IS UNPUBLISHED PROPRIETARY SOURCE CODE OF OASIS TECHNOLOGY LTD.
 *	The copyright notice above does not evidence any  
 *	actual or intended publication of such source code.
 */
/*
 *
 *                        MODIFICATION HISTORY                  REVIEW
 *
 *	SPR#	Who	Date		Description			Who	Date   
 * ===========================================================================
 * xxxxxxxx ztang 19may09	Creation
 */

#include <stdio.h>
#include <signal.h>
#include <stdlib.h>
#include <errno.h>
#include <oasis.h>
#include <mb.h>
#include <tsk.h>
#include <rules.h>
#include <config.h>
#include <string.h>
#include <shcmsgdef.h>
#include <shc.h>
#include <shcseg.h>
#include <shcprototype.h>
#include <multi_institution.h>
#include <ist_otrace.h>


int main(int argc, char **argv)
{
	struct ShcmsgWithSegment msgbuf = { 0 };
	struct shcmsg *msg = &msgbuf.msg;
	struct ShcmsgWithSegment *msgbuf_p = &msgbuf;
	int testnum = 1;

	try
	{
		msg->pos_entry_code = 50 | 0x7f000;
		if (shcIsChipTxn(msgbuf_p))
			printf("Test %d passed\n", testnum++);
		else
			throw 1;

		if (shcmsgIsChipTxn(msg))
			printf("Test %d passed\n", testnum++);
		else
			throw 1;

		memset(msg, 0, sizeof(msgbuf));

		msg->pos_entry_code = 70 | 0x7f000;
		if (shcIsChipTxn(msgbuf_p))
			printf("Test %d passed\n", testnum++);
		else
			throw 1;
		if (shcmsgIsChipTxn(msg))
			printf("Test %d passed\n", testnum++);
		else
			throw 1;

		memset(msg, 0, sizeof(msgbuf));

		msg->pos_entry_code = 950 | 0x7f000;
		if (shcIsChipTxn(msgbuf_p))
			printf("Test %d passed\n", testnum++);
		else
			throw 1;
		if (shcmsgIsChipTxn(msg))
			printf("Test %d passed\n", testnum++);
		else
			throw 1;

		memset(msg, 0, sizeof(msgbuf));

		msg->pos_entry_code = 901 | 0x7f000;
		if (!shcIsChipTxn(msgbuf_p))
			printf("Test %d passed\n", testnum++);
		else
			throw 1;
		if (!shcmsgIsChipTxn(msg))
			printf("Test %d passed\n", testnum++);
		else
			throw 1;

		memset(msg, 0, sizeof(msgbuf));
		shc_segAppendNoOpt( msg, "EMV_BUF", "1234", 5 );
		if (shcIsChipTxn(msgbuf_p))
			printf("Test %d passed\n", testnum++);
		else
			throw 1;
		if (shcmsgIsChipTxn(msg))
			printf("Test %d passed\n", testnum++);
		else
			throw 1;
	}
	catch(...)
	{
		printf("Failed at %d test\n", testnum);
	}
	return 0;
}

