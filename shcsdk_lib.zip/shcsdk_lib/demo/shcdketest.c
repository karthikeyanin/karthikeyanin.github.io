/*
 * Copyright (C) 2004 eFunds Corporation ("eFunds").  All Rights Reserved.  
 * eFunds Canada Corporation is an authorized user. 
 * 
 * IST is a registered trademark of eFunds Corporation.  Other brand or
 * product names are trademarks or registered trademarks of their respective
 * holders. 
 * 
 * The information contained herein is the unpublished proprietary property
 * of eFunds.  Except as specifically authorized in writing by eFunds, the
 * holder of this document shall: i) keep all information contained herein
 * confidential, and ii) protect the information, in whole or in part, from
 * disclosure and dissemination to all third parties. 
 * 
 * This document and the software described in it are furnished under license
 * and may be used or copied only in accordance with the terms of such license.
 * This document is supplied for information purposes only, is subject to
 * change without notice, and should not be construed as a commitment by
 * either eFunds Corporation or eFunds Canada Corporation. 
 */
static char ver[]="isttriginit r1.0 01Nov97";
/*
 *	IST and IST/Share are registered trademarks of Oasis Technology Ltd.
 *
 *	Copyright (C) 1990 - 1997 Oasis Technology Ltd.
 *	All Rights Reserved
 *	This Module contains Proprietary Information of
 *	Oasis Technology Ltd., and should be treated as Confidential.
 *
 *	THIS IS UNPUBLISHED PROPRIETARY SOURCE CODE OF OASIS TECHNOLOGY LTD.
 *	The copyright notice above does not evidence any  
 *	actual or intended publication of such source code.
 */
/*
#pragma ident "@(#)shcdketest.c 1.3 20/07/08 00:37:09"
 *
 *    MODIFICATION HISTORY                  REVIEW
 *
 *	SPR#	Who	Date	Description			Who	Date   
 * ===========================================================================
 *          qd 24sep97  Created
 */
/*------------------------------------------------------------------------*
 * Include Block
 *------------------------------------------------------------------------*/
#include <stdio.h>
#include <string.h>
#include <signal.h>
#include <fcntl.h>
#include <oasis.h>
#include <mb.h>
#include <rules.h>
#include <isttrigger.h>
#include <math.h>

/*------------------------------------------------------------------------*
 * Function Prototype Block
 *------------------------------------------------------------------------*/
void shcdke_exit(int n);

/*------------------------------------------------------------------------*
 * Main Function Block
 *------------------------------------------------------------------------*/
void main(int argc, char **argv)
{
	int  ret = 0;

	/*
	 * HouseKeeping
	 */

	argv0 = *argv;
	catch_all_signals(shcdke_exit);
	ODebugOn("shcdketest.debug");

	shc_inc_kpecnt("0000008");

	if(	shc_kpe_overthreshold("000008"))
	{
		printf("Reset\n");
		shc_reset_kpecnt("000008");
	}

	pow(2,56);	

	/*
	 * Clean up the battle fields and die in peace
	 */
	shcdke_exit(0);
}

/*------------------------------------------------------------------------*
 * shcdke_exit() Function Block 
 *------------------------------------------------------------------------*/
void shcdke_exit(int n)
{
	if(n == 0 || n == SIGTERM)
		ODebug("I-3000: Normal Exit %d\n", n);
	else	
		ODebug("W-3000: Exit due to signal %d\n", n);
			
	ODebugOff();

	if(n > 1)
		kill(getpid(), n);

	exit(n);
}
/*------------------------------------------------------------------------*
 * End of file
 *------------------------------------------------------------------------*/
