/*
 * Copyright (C) 2004 eFunds Corporation ("eFunds").  All Rights Reserved.  
 * eFunds Canada Corporation is an authorized user. 
 * 
 * IST is a registered trademark of eFunds Corporation.  Other brand or
 * product names are trademarks or registered trademarks of their respective
 * holders. 
 * 
 * The information contained herein is the unpublished proprietary property
 * of eFunds.  Except as specifically authorized in writing by eFunds, the
 * holder of this document shall: i) keep all information contained herein
 * confidential, and ii) protect the information, in whole or in part, from
 * disclosure and dissemination to all third parties. 
 * 
 * This document and the software described in it are furnished under license
 * and may be used or copied only in accordance with the terms of such license.
 * This document is supplied for information purposes only, is subject to
 * change without notice, and should not be construed as a commitment by
 * either eFunds Corporation or eFunds Canada Corporation. 
 */
/*
 *  IST and IST/Share are registered trademarks of Oasis Technology Ltd.
 *
 *  Copyright (C) 1990 - 1999 Oasis Technology Ltd.
 *  All Rights Reserved
 *  This Module contains Proprietary Information of
 *  Oasis Technology Ltd., and should be treated as Confidential.
 *
 *  THIS IS UNPUBLISHED PROPRIETARY SOURCE CODE OF OASIS TECHNOLOGY LTD.
 *  The copyright notice above does not evidence any
 *  actual or intended publication of such source code.
 */
/*
#pragma ident "@(#) demo_shclog.h 1.3 04/12/30 13:38:05"
 *
 *                        MODIFICATION HISTORY                  REVIEW
 *
 *  SPR#    Who Date    Description         Who Date
 * ===========================================================================
 *R009866 ztang 25Jun03 Creation
*/

#ifndef _SC_DEMO_SHCLOG_H_
#define _SC_DEMO_SHCLOG_H_

#include <ShcmsgHeader.h>
#include "shc_callback.h"

class DemoShclog: public ShcLog
{
public:
	DemoShclog() : ShcLog(4, 2) {  }
	int logTxn(ShcmsgHeader *header);
	int open_index();
};


extern "C" SHCDLLEXPORT int register_all(shcCallBackFactory* cbFactory);

#endif
		

