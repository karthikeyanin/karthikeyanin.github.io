//
// Copyright (C) 2004 eFunds Corporation ("eFunds").  All Rights Reserved.  
// eFunds Canada Corporation is an authorized user. 
// 
// IST is a registered trademark of eFunds Corporation.  Other brand or
// product names are trademarks or registered trademarks of their respective
// holders. 
// 
// The information contained herein is the unpublished proprietary property
// of eFunds.  Except as specifically authorized in writing by eFunds, the
// holder of this document shall: i) keep all information contained herein
// confidential, and ii) protect the information, in whole or in part, from
// disclosure and dissemination to all third parties. 
// 
// This document and the software described in it are furnished under license
// and may be used or copied only in accordance with the terms of such license.
// This document is supplied for information purposes only, is subject to
// change without notice, and should not be construed as a commitment by
// either eFunds Corporation or eFunds Canada Corporation. 
//
static	char ver[100]="IST/Segtest: Version ";
static  char _shc_cxx_what[] = "@(#) shcmttest.cxx 1.9 12/06/04 06:53:49";

/*
 *	IST and IST/Share are registered trademarks of Oasis Technology Ltd.
 *
 *	Copyright (C) 1990 - 1999 Oasis Technology Ltd.
 *	All Rights Reserved
 *	This Module contains Proprietary Information of
 *	Oasis Technology Ltd., and should be treated as Confidential.
 *
 *	THIS IS UNPUBLISHED PROPRIETARY SOURCE CODE OF OASIS TECHNOLOGY LTD.
 *	The copyright notice above does not evidence any  
 *	actual or intended publication of such source code.
 */
/*
 *
 *                        MODIFICATION HISTORY                  REVIEW
 *
 *	SPR#	Who	Date		Description			Who	Date   
 * ===========================================================================
 * R008717 ztang 15May02	Creation
 */

#include <stdio.h>
#include <signal.h>
#include <stdlib.h>
#include <errno.h>
#include <oasis.h>
#include <mb.h>
#include <tsk.h>
#include <rules.h>
#include <config.h>
#include <string.h>
#include <shc.h>
#include <multi_institution.h>
#include <ist_otrace.h>
#include <InstProfile.h>

extern int acqProfileFindUpBin;
void manualIssuerAcquirerProfileTest()
{
	IssuerInfo issuerInfo;
	AcquirerInfo acquirerInfo;
	int ret=0;
	
	char txnSrc[20], txnDest[20], pan[40], entityId[100];
	int msgType, pcode, hasPIN, currency;
	char merchantType[20]; 
	char upBinFirst[20];
	
	printf("Please input information in following order:\n");
	printf("txnSrc PAN msgType deviceType(merchant type) pcode hasPIN(0/1) useUpPin(Y/N) \n");
	scanf("%s %s %d %s %d %d %s", txnSrc, pan, &msgType, merchantType, &pcode, &hasPIN, upBinFirst);
	if ((upBinFirst[0] == 'Y') || (upBinFirst[0] == 'y'))
		acqProfileFindUpBin = 1;
	ret=shc_locate_extbin(txnSrc, pan, msgType,	merchantType, (long)pcode, hasPIN, issuerInfo);
	printf("#Issuer profile for:%s:%s:%d:%s:%d:%d\n", txnSrc, pan, msgType,	merchantType, pcode, hasPIN);
	if (ret < 0)
		printf("#Issuer profile error:%d\n", ret);
	else
		printf("#Issuer profile result:%s:%s:%s\n", issuerInfo.getIssuerBin(), issuerInfo.getTxnDest(), 
													issuerInfo.getCardProduct());
	
	printf("Please input in this order:txnSrc, txnDest, entityId, currency\n");
	scanf("%s %s %s %d", txnSrc, txnDest, entityId, &currency);
	shc_locate_acquirer(txnSrc, txnDest, entityId, currency, merchantType, acquirerInfo);
	printf("#Acquirer profile for:%s:%s:%s:%d\n", txnSrc, txnDest, entityId, currency);
	if (acquirerInfo.foundAcquirer())
		printf("#Acquirer profile result:%s:%s\n", acquirerInfo.getAcqBin(), acquirerInfo.getAlternateAcqBin());
	else
		printf("#Acquirer profile error\n");

	printf("******Again Using all-in-one function\n");
	shc_getIssuerAcquirerInfo(txnSrc, pan, msgType, merchantType, pcode, hasPIN, entityId, currency, 
								issuerInfo, acquirerInfo);
	if (issuerInfo.foundIssuer())
		printf("#Issuer profile result:%s:%s:%s\n", issuerInfo.getIssuerBin(), issuerInfo.getTxnDest(), 
													issuerInfo.getCardProduct());
	else
		printf("#Issuer profile error:%d\n", ret);

	if (acquirerInfo.foundAcquirer())
		printf("#Acquirer profile result:%s:%s\n", acquirerInfo.getAcqBin(), acquirerInfo.getAlternateAcqBin());
	else
		printf("#Acquirer profile error\n");
	return;
}

void shcmsgTest()
{
	IssuerInfo issuerInfo;
	AcquirerInfo acquirerInfo;
	NetworkInfo networkInfo;

	int ret=0;
	struct shc shc;
	
	
	memset (&shc, 0, sizeof(shc));
	printf("Please input information in following order:\n");
	printf("txnSrc PAN msgType deviceType(merchant type) pcode PIN_block(-) entityId currency\n");
	scanf("%s %s %d %hd %ld %d %s %hd", shc.msg.txnSrc, shc.msg.pan, &shc.msg.msgtype, &shc.msg.merchant_type, 
			&shc.msg.pcode, shc.msg.pin, shc.msg.entityId, &shc.msg.acq_currency_code);
	if (shc.msg.pin[0] == '-')
		shc.msg.pin[0] = '\0';
	
	shc_normalizepan(shc.msg.pan);
	shc.msg.respcode = 0;
	shc_get_iss_acq_xt(&shc, 1 );
	printf("#shcmsg response code:%d\n", shc.msg.respcode);
	if (shc.msg.respcode == 0)
	{
		//printf("#shcmsg acquirer bin:%s:%s\n", shc.acqbin->bin.institutionid, shc.acqbin->bin.userbinid);
		//printf("#shcmsg issuer bin:%s:%s\n", shc.issbin->bin.institutionid, shc.issbin->bin.userbinid);
		printf( "header->msg.issuer= %s\n", shc.msg.issuer);
		printf( "header->msg.acquirer= %s\n", shc.msg.acquirer);
		//if (shc.alternateAcqBin != NULL)
		//	printf("#shcmsg alternate acquirer bin:%s:%s\n", shc.alternateAcqBin->bin.institutionid, shc.alternateAcqBin->bin.userbinid);
		//else
		//	printf("#shcmsg no alternate acquirer bin\n");
		RoutingInfoResult::getInstance()->reset();
		shc_locate_network_info(shc.msg.txnSrc, shc.msg.msgtype, shc.msg.issuer, networkInfo);
		if (networkInfo.foundNetworkInfo())
		printf("Outbound Inst profile result:%s:%s:%s:%s\n", networkInfo.getExternalId(), 
			networkInfo.getExternalIdDesc(), networkInfo.getMember_ID(), networkInfo.getF_ID());
		else
			printf("Outbound Inst profile error\n");
		if ( RoutingInfoResult::getInstance()->isRouteSet() )
		{
			struct RoutingInfo route;	
			memcpy( &route, RoutingInfoResult::getInstance()->get(), sizeof(struct RoutingInfo));
			printf( "route: mailbox=%s, port=%s\n", route.mailbox, route.port );
		}
		else
		{
			printf( "route not set\n" );
		}

		exit(0);
	}			
	return;
}
	
void manualBin2NetworkTest()
{
	NetworkInfo networkInfo;
	char txnSrc[20], bin[20];
	int msgType;

	printf("Please input in this order: txnSrc, msgType, bin\n");
	scanf("%s %d %s", txnSrc, &msgType, bin);
	shc_locate_network_info(txnSrc, msgType, bin, networkInfo);
	printf("#Outbound Inst profile for:%s:%d:%s\n", txnSrc, msgType, bin);
	if (networkInfo.foundNetworkInfo())
		printf("#Outbound Inst profile result:%s:%s:%s:%s\n", networkInfo.getExternalId(), 
				networkInfo.getExternalIdDesc(), networkInfo.getMember_ID(), networkInfo.getF_ID());
	else
		printf("#Outbound Inst profile error\n");

	return;
}
	
extern int instProfileFindUpBin;
void manualNetwork2BinTest()
{
	IssuerInfo issuerInfo;
	char txnSrc[20], externalId[20], externalIdDesc[100], member_ID[12], F_ID[12];
	int msgType;
	char upBinFirst[20];

	printf("Please input in following order, if NULL use -\n");
	printf("txnSrc, msgType, externalId, externalIdDesc, member_ID, F_ID, up bin first(Y/N)\n");
	scanf("%s %d %s %s %s %s %s", txnSrc, &msgType, externalId, externalIdDesc, member_ID, F_ID, upBinFirst);
	if (externalId[0] == '-')
		externalId[0] = '\0';
	if (externalIdDesc[0] == '-')
		externalIdDesc[0] = '\0';
	if (member_ID[0] == '-')
		member_ID[0] = '\0';
	if (F_ID[0] == '-')
		F_ID[0] = '\0';
	if ((upBinFirst[0] == 'Y') || (upBinFirst[0] == 'y'))
		instProfileFindUpBin = 1;
	shc_locate_issuer_from_network(txnSrc, msgType, externalId, member_ID, F_ID, issuerInfo);
	printf("#Inbound Inst profile for:%s:%d:%s:%s:%s:%s\n", txnSrc, msgType, externalId, externalIdDesc, member_ID, F_ID);
	if (issuerInfo.foundIssuer())
		printf("#Inbound Inst profile result:%s:%s\n", issuerInfo.getIssuerBin(), issuerInfo.getTxnDest()); 
	else
		printf("#Inbound Inst profile error\n");

	return;
}
void manualInst2BinTest()
{
	IssuerInfo issuerInfo;
	char txnSrc[20], entityId[100];
	char upBinFirst[20];
	int msgType;

	printf("Please input in following order, if NULL use -\n");
	printf("txnSrc, entityId, msgType, up bin first(Y/N)\n");
	scanf("%s %s %d %s", txnSrc, entityId, &msgType, upBinFirst);
	if (entityId[0] == '-')
		entityId[0] = '\0';
	if (txnSrc[0] == '-')
		txnSrc[0] = '\0';
	if ((upBinFirst[0] == 'Y') || (upBinFirst[0] == 'y'))
		instProfileFindUpBin = 1;
	shc_locate_issuer_from_institution(txnSrc, entityId, msgType, issuerInfo);
	printf("#Inbound Inst profile for:%s:%d:%s\n", txnSrc, msgType, entityId);
	if (issuerInfo.foundIssuer())
		printf("#Inbound Inst profile result:%s:%s\n", issuerInfo.getIssuerBin(), issuerInfo.getTxnDest()); 
	else
		printf("#Inbound Inst profile error\n");

	return;
}

int testInternal2External()
{

	bin_t bin, institutionId, userBinId;

	printf("Please input an internal bin id:\n");
	scanf("%s", bin);
	if (shc_internalBin2ExternalBin(institutionId, userBinId, bin) >= 0)
		printf("External ID:%s:%s\n", institutionId, userBinId);
	else
		printf("External ID not found\n");

	return 0;
}

int testExternal2Internal()
{

	bin_t bin, institutionId, userBinId;

	printf("Please input institution id and user bin id:\n");
	scanf("%s%s", institutionId, userBinId);

	if (shc_externalBin2InternalBin(bin, institutionId, userBinId) >= 0)
		printf("Internal ID:%s\n", bin);
	else
		printf("Internal ID not found\n");

	return 0;
}

int main(int argc, char **argv)
{
	argv0 = *argv;
	char buf[200];
	char choice[10];

	ODebugOn(argv0);
	ist_otrace_set_level(OTRACE_DEBUG);
	

	mb_init();
	shc_init();
	while (choice[0] != '0')
	{
		printf("*****************************************************\n");
		printf("0:	Exit\n");
		printf("1:  Internal Bin Id to External Bin Id\n");
		printf("2:  External Bin Id to Internal Bin Id\n");
		printf("i:	Manual Issuer Profile + Acquirer Profile Test\n");
		printf("n:	Network to Bin Test\n");
		printf("b:	Bin to Network Test\n");
		printf("I:	Institution to Bin Test\n");
		printf("s:	shcmsg testing\n");
		printf("Your Choice:\n");
		scanf("%s", choice);	
		
		switch(choice[0])
		{
		case '1':
			testInternal2External();
			break;
		case '2':
			testExternal2Internal();
			break;
		case 'i':
			manualIssuerAcquirerProfileTest();
			break;
		case 'n':
			manualNetwork2BinTest();
			break;
		case 'I':
			manualInst2BinTest();
			break;
		case 'b':
			manualBin2NetworkTest();
			break;
		case 's':
			shcmsgTest();
			break;
		}
	}
	
	return 0;
}

