//
// Copyright (C) 2004 eFunds Corporation ("eFunds").  All Rights Reserved.  
// eFunds Canada Corporation is an authorized user. 
// 
// IST is a registered trademark of eFunds Corporation.  Other brand or
// product names are trademarks or registered trademarks of their respective
// holders. 
// 
// The information contained herein is the unpublished proprietary property
// of eFunds.  Except as specifically authorized in writing by eFunds, the
// holder of this document shall: i) keep all information contained herein
// confidential, and ii) protect the information, in whole or in part, from
// disclosure and dissemination to all third parties. 
// 
// This document and the software described in it are furnished under license
// and may be used or copied only in accordance with the terms of such license.
// This document is supplied for information purposes only, is subject to
// change without notice, and should not be construed as a commitment by
// either eFunds Corporation or eFunds Canada Corporation. 
//
static char ver[]="IST:shc_callback.cxx: r1.00.00 29Dec99";
static char _shc_callback_cxx_what[] = "@(#) shc_callback.cxx 1.11 12/05/29 06:42:24";
/*
 *	IST and IST/Share are registered trademarks of Oasis Technology Ltd.
 *
 *	Copyright (C) 1990 - 1997 Oasis Technology Ltd.
 *	All Rights Reserved
 *	This Module contains Proprietary Information of
 *	Oasis Technology Ltd., and should be treated as Confidential.
 *
 *	THIS IS UNPUBLISHED PROPRIETARY SOURCE CODE OF OASIS TECHNOLOGY LTD.
 *	The copyright notice above does not evidence any  
 *	actual or intended publication of such source code.
 *
 *                        MODIFICATION HISTORY                       REVIEW
 *
 *	SPR#	Who	Date	Description								Who	Date   
 * =============================================================================
 *  R002797 fguo 29Dec99 SHC Callback 
 *  R004774  fg  08Jun00 Display debug info only when it is turned on 
 *  R006874 ccy  31Oct01 Change char* to const char*
 *  R007909 Emj  13Jum02  Added return value from Callback 
 *  R018276 pve	 27Nov06  Remove excessive syslg messages
 *  R023659 ram  19Jun08 Callback prototype changed to improve performance
 *  R023762 ram  28Jun08 Callback changes enclosed inside DSWITCH macro
 */

/* File Number 133 */

#if defined( WIN32 )
#       define CALLBACKDLLEXPORT __declspec(dllexport)
#else
#       define CALLBACKDLLEXPORT
#endif


#define  __DECLARE_GLOBALS_HERE

#include "shc_internal_cb.h" 
#include "ist_otrace.h"

shcCallBackFactory* shcCallBackFactory::_instance = 0;
shcCallBackLookupTable* shcCallBackLookupTable::_instance = 0;
PredicateMaker::MakerMap* PredicateMaker::Registry = 0;  

int shcCallBackFactory::register_callback( shcCallBack* cb, 
										   const OCString& name)
{
	if (factoryMap.insert(name, cb) != 1)
	{
		//R018276
		OTraceError("E-SHC-CB-133001: %s failed to be registered.\n", name.data()); 
		return 1;
	}

	return 0;
}

shcCallBack* shcCallBackFactory::lookup(const OCString& name) const
{
	try {
		return factoryMap[name];
	}
	catch (...)
	{
		return NULL;
	}		
}

shcCallBackFactory*  shcCallBackFactory::getFactory()
{
	if (_instance == 0)
		_instance = new shcCallBackFactory;

	return _instance;
}
//	>>>	R023762
const OCString cbTblEntry::Match (const ShcHeader *shcmsg, const OCString& ProcessingPoint)	//	---	R023659
//	<<<	R023762
{
	bool	stillEqual = true;
	
	for (int i = 0; i < predicateVec.size(); i ++)
	{
		cbPredicateBase* anIssuer = predicateVec[i];

		if (anIssuer->query(shcmsg) != true)
		{	
			stillEqual = false;
			return OCString("");	
		}
	}

	OCString aProcPoint = getProcPoint();

	if (aProcPoint != ProcessingPoint)
	{
		stillEqual = false;
		return OCString("");	
	}

	if (stillEqual)
		return getName();
	
	return OCString("");
}

int shcCallBackLookupTable::insert(cbTblEntry& anEntry)
{
	cbVec.push_back(anEntry);
	return 0;
}
//  >>> R023762
shcCallBack* shcCallBackLookupTable::search (const ShcHeader *shcmsg,const OCString& ProcessingPoint) 	//	---	R023659
//  <<< R023762
{
	for (int i = 0; i < cbVec.size(); i ++)
	{
		cbTblEntry anEntry;

		anEntry = cbVec[i];

		OCString rightName(anEntry.Match(shcmsg, ProcessingPoint));

		if (rightName != OCString(""))
		{
			return (shcCallBackFactory::getFactory())->lookup(rightName);
		}
	} 

	return NULL;
}

shcCallBackLookupTable*  shcCallBackLookupTable::getTable()
{
	if (_instance == 0)
		_instance = new shcCallBackLookupTable;

	return _instance;
}

cbPredicateBase* PredicateMaker::newPredicate(OCString& className, 
											OCString& val)
{
	PredicateMaker* maker;
	
	try {
     	maker = (*(getRegistryInstance()))[className];
	}
	catch (...)
	{
		maker = NULL;
	}

	if (maker == NULL)
	{
		return NULL;
	}
	else
		  return maker->makePredicate(val);
}

PredicateMaker::MakerMap* PredicateMaker::getRegistryInstance()
{
	if ( !Registry )
		Registry = new MakerMap;

	return Registry;
}	

//  >>> R023762
int shc_callback ( ShcHeader *shcmsg, const char* processingPoint)	//	---	R023659
//  <<< R023762
{
    shcCallBack*    cbPtr;
	OCString	procPoint(processingPoint);

	if ( (cbPtr= (shcCallBackLookupTable::getTable())->search(shcmsg, procPoint)) != NULL)
	{
		return(cbPtr->execute(shcmsg, procPoint));
	}
	else
	{
		return (SHCCALLBACKNONE);
	}

	return (SHCCALLBACKNONE);
}

