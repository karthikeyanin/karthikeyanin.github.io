//
// Copyright (C) 2004 eFunds Corporation ("eFunds").  All Rights Reserved.  
// eFunds Canada Corporation is an authorized user. 
// 
// IST is a registered trademark of eFunds Corporation.  Other brand or
// product names are trademarks or registered trademarks of their respective
// holders. 
// 
// The information contained herein is the unpublished proprietary property
// of eFunds.  Except as specifically authorized in writing by eFunds, the
// holder of this document shall: i) keep all information contained herein
// confidential, and ii) protect the information, in whole or in part, from
// disclosure and dissemination to all third parties. 
// 
// This document and the software described in it are furnished under license
// and may be used or copied only in accordance with the terms of such license.
// This document is supplied for information purposes only, is subject to
// change without notice, and should not be construed as a commitment by
// either eFunds Corporation or eFunds Canada Corporation. 
//
static char ver[]="IST:init_callback.cxx: r1.00.00 29Dec99";
static char _init_callback_cxx_what[] = "@(#) init_callback.cxx 1.8 16/08/18 07:20:10";
/*
 *	IST and IST/Share are registered trademarks of Oasis Technology Ltd.
 *
 *	Copyright (C) 1990 - 1997 Oasis Technology Ltd.
 *	All Rights Reserved
 *	This Module contains Proprietary Information of
 *	Oasis Technology Ltd., and should be treated as Confidential.
 *
 *	THIS IS UNPUBLISHED PROPRIETARY SOURCE CODE OF OASIS TECHNOLOGY LTD.
 *	The copyright notice above does not evidence any  
 *	actual or intended publication of such source code.
 *
 *                        MODIFICATION HISTORY                       REVIEW
 *
 *	SPR#	Who	Date	Description								Who	Date   
 * =============================================================================
 *  R002797 fguo 29Dec99 SHC Callback initialization 
 *  R018276 pve	 27Nov06 Remove excessive syslg messages
 *
 */

/* File Number 132 */

#if defined( WIN32 )
#       define CALLBACKDLLEXPORT __declspec(dllexport)
#else
#       define CALLBACKDLLEXPORT
#endif

#include <oasis.h>

#ifndef WIN32
#include <strings.h>
#endif

#include <ist_types.h>
#include <ist_dll.h>
#include <ist_otrace.h>		//	R018276
#include "iostream.h"
#include "shc_internal_cb.h"

#include <stl/vector.h>

#include <HaPtmCctHelper.h>

#define cfgFileName	"cfg/callback.cfg"

vector<OCString
#if ! defined(OC_USE_NEW_STL)
		, __STL_DEFAULT_ALLOCATOR(OCString)
#endif
	>orderVec;

int fillClassNames(char** ptoPbegin)
{
	char *pend, *pbegin; 
	int len;
	char p2[50];

	pbegin = *ptoPbegin;
	pend = strchr(pbegin+1, '"');
	if (pend == NULL)
	{
		//R018276
		OTraceError("E-SHC-CB-132001: Error in shc.cbString: No closing quotes.\n"); 
		return -1;
	}
	else
	{
		len = pend - pbegin - 1;

		if (len != 0 && len < sizeof(p2))   // With predicates
		{
			strncpy(p2, pbegin+1, len);
			p2[len] = '\0';

			orderVec.push_back(p2);
		}

		*ptoPbegin = strchr(pend+1, '"');
		return 0;
	}

}

int fillKeyFields (cbTblEntry& anEntry, int i, char** ptoPbegin)
{
	// pbegin is the beginning of the quotes
	char *pend, *pbegin; 
	int len;
	char p2[50];

	pbegin = *ptoPbegin;
	pend = strchr(pbegin+1, '"');
	if (pend == NULL)
	{
		//R018276
		OTraceError("E-SHC-CB-132002: Error in shc.cbTbl: No closing quotes.\n"); 
		return -1;
	}
	else
	{
		len = pend - pbegin - 1;
		if (len != 0 && len < sizeof(p2))
		{
			strncpy(p2, pbegin+1, len);
			p2[len] = '\0';
		}
		if (i < orderVec.size())
		{
			OCString  predName(orderVec[i]);
			OCString  predValue(p2);
			cbPredicateBase* anPred = PredicateMaker::newPredicate(
										predName, predValue);
			if (anPred != NULL)
			{
				// cout << anPred << endl;
				anEntry.addPredicate(anPred);
			}
			else
			{
				//R018276
				OTraceError("E-SHC-CB-132003: Adding predicate failed.\n"); 
				return -1;
			}
		}
		else if (i == orderVec.size())
		{
			// fill in the processing point
			anEntry.setProcPoint(p2);
		}
		else
		{
			// fill in the name
			anEntry.setName(p2);
		}

		// return the beginning of next pair of quotes
		*ptoPbegin = strchr(pend+1, '"'); 
		return 1;
	}
}

int readCallBackConfig(void)
{
	char tmp[1024];
	ist_Return_t	Result = IST_RET_FAIL;
	ist_DllHdl_t	LibHdl1 = NULL;
	ist_DllHdl_t	LibHdl2 = NULL;
    int     (*registerFacPtr)(shcCallBackFactory*);
    int     (*registerPredPtr)(PredicateMaker::MakerMap*);

	char qualifiedDLL[1024] = "";

	HaPtmCctHelper::addHandler( "system.dcs.shc" ) ;

	cf_open(NULL);  // use istparam.cfg

	// read shc.cbString entry
	cf_rewind();
	if (cf_locate ("shc.cbString", tmp) <= 0)
	{
		//R018276
		OTraceWarning("W-SHC-CB-132004: Cannot find entry shc.cbString in configuration file.\n"); 

		// If this entry doesn't exist, no need to read shc.cbDll and 
		// shc.cbTbl entries; Missing of this entry means that user 
		// doesn't really need callback.  
		return 0;
	}
	else
	{
		char* pbegin = strchr(tmp, '"');
		char** ptoPbegin = &pbegin;

		while ((*ptoPbegin) != NULL)
		{	
			if (fillClassNames(ptoPbegin) < 0)
				return -1;
		}
	}

	// build the PredicateMaker::registry 
	if (orderVec.size() != 0)   // Predicate Exist
	{
		strcpy(qualifiedDLL, "libopredicateCB.DLL");

		if ((Result = ist_dll_open(qualifiedDLL, &LibHdl1)) != IST_RET_OK)
		{
			//R018276
			OTraceFatal("F-SHC-CB-132005: Opening library %s failed.\n", qualifiedDLL); 
			return -1;	
		}	

		if ((Result = ist_dll_fn_adr(&LibHdl1, "register_predicates", 
								(void **) &registerPredPtr)) != IST_RET_OK) 
		{
			//R018276
			OTraceFatal("F-SHC-CB-132006: Retrieving function \"register_predicates\" failed.\n");
			return -1;
		}
		else
			(*registerPredPtr)(PredicateMaker::getRegistryInstance());
	}

	// read shc.cbDll entry
	cf_rewind();
	while (cf_nextparm("shc.cbDll", tmp) > 0)
	{
		if (strchr(tmp, '.') == NULL)
		{
			//R018276
			OTraceError("E-SHC-CB-132007: Proper extension for library name %s is needed.\n",tmp); 
			return -1;	
		}

		strcpy(qualifiedDLL, tmp);

		if ((Result = ist_dll_open(qualifiedDLL, &LibHdl2)) != IST_RET_OK)
		{
			//R018276
			OTraceFatal("F-SHC-CB-132008: Opening library %s failed.\n", qualifiedDLL); 
			return -1;	
		}	
		
		if ((Result = ist_dll_fn_adr(&LibHdl2, "register_all", 
									(void **) &registerFacPtr)) != IST_RET_OK) 
		{
			//R018276
			OTraceFatal("F-SHC-CB-132009: Retrieving function \"register_all\" failed.\n");
			return -1;
		}
		else
			(*registerFacPtr)(shcCallBackFactory::getFactory());
	}

	// read shc.cbTbl entry
	cf_rewind();
	while (cf_nextparm("shc.cbTbl", tmp) > 0)
	{
		cbTblEntry anEntry;
		int i = 0; 

		char* pbegin = strchr(tmp, '"');
		char** ptoPbegin = &pbegin;

		while ((*ptoPbegin) != NULL)
		{
			if (fillKeyFields(anEntry, i, ptoPbegin) < 0)
				return -1;
			i ++;
		}

		if ((i - orderVec.size()) != 2)
		{
			//R018276
			OTraceWarning("W-SHC-CB-132010: Number of fields in shc.cbTbl doesn't match that in shc.cbString.\n");
			return -1;
		}

		(shcCallBackLookupTable::getTable())->insert(anEntry);

	}

	return 1;
}

