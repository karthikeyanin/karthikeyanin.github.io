dnl This is a machine generated file
dnl Do not modify this file
dnl @(#) %M% %I% %E% %U%
dnl aclocal.m4 generated automatically by aclocal 1.4

dnl Copyright (C) 1994, 1995-8, 1999 Free Software Foundation, Inc.
dnl This file is free software; the Free Software Foundation
dnl gives unlimited permission to copy and/or distribute it,
dnl with or without modifications, as long as this notice is preserved.

dnl This program is distributed in the hope that it will be useful,
dnl but WITHOUT ANY WARRANTY, to the extent permitted by law; without
dnl even the implied warranty of MERCHANTABILITY or FITNESS FOR A
dnl PARTICULAR PURPOSE.

# serial 25 AM_PROG_LIBTOOL
AC_DEFUN(AM_PROG_LIBTOOL,
[AC_REQUIRE([AM_ENABLE_SHARED])dnl
AC_REQUIRE([AM_ENABLE_STATIC])dnl
AC_REQUIRE([AC_CANONICAL_HOST])dnl
AC_REQUIRE([AC_PROG_RANLIB])dnl
AC_REQUIRE([AC_PROG_CC])dnl
AC_REQUIRE([AM_PROG_LD])dnl
AC_REQUIRE([AM_PROG_NM])dnl
AC_REQUIRE([AC_PROG_LN_S])dnl
dnl
# Always use our own libtool.
LIBTOOL='$(SHELL) $(top_builddir)/libtool'
AC_SUBST(LIBTOOL)dnl

# Check for any special flags to pass to ltconfig.
libtool_flags=
test "$enable_shared" = no && libtool_flags="$libtool_flags --disable-shared"
test "$enable_static" = no && libtool_flags="$libtool_flags --disable-static"
test "$silent" = yes && libtool_flags="$libtool_flags --silent"
test "$ac_cv_prog_gcc" = yes && libtool_flags="$libtool_flags --with-gcc"
test "$ac_cv_prog_gnu_ld" = yes && libtool_flags="$libtool_flags --with-gnu-ld"

# Some flags need to be propagated to the compiler or linker for good
# libtool support.
case "$host" in
*-*-irix6*)
  # Find out which ABI we are using.
  echo '[#]line __oline__ "configure"' > conftest.$ac_ext
  if AC_TRY_EVAL(ac_compile); then
    case "`/usr/bin/file conftest.o`" in
    *32-bit*)
      LD="${LD-ld} -32"
      ;;
    *N32*)
      LD="${LD-ld} -n32"
      ;;
    *64-bit*)
      LD="${LD-ld} -64"
      ;;
    esac
  fi
  rm -rf conftest*
  ;;

*-*-sco3.2v5*)
  # On SCO OpenServer 5, we need -belf to get full-featured binaries.
  CFLAGS="$CFLAGS -belf"
  ;;
esac

# Actually configure libtool.  ac_aux_dir is where install-sh is found.
CC="$CC" CFLAGS="$CFLAGS" CPPFLAGS="$CPPFLAGS" \
LD="$LD" NM="$NM" RANLIB="$RANLIB" LN_S="$LN_S" \
AR="ar $AR_option" \
${CONFIG_SHELL-/bin/sh} $ac_aux_dir/ltconfig --no-reexec \
$libtool_flags --no-verify $ac_aux_dir/ltmain.sh $host \
|| AC_MSG_ERROR([libtool configure failed])

# Redirect the config.log output again, so that the ltconfig log is not
# clobbered by the next message.
exec 5>>./config.log
])

# AM_ENABLE_SHARED - implement the --enable-shared flag
# Usage: AM_ENABLE_SHARED[(DEFAULT)]
#   Where DEFAULT is either `yes' or `no'.  If omitted, it defaults to
#   `yes'.
AC_DEFUN(AM_ENABLE_SHARED,
[define([AM_ENABLE_SHARED_DEFAULT], ifelse($1, no, no, yes))dnl
AC_ARG_ENABLE(shared,
changequote(<<, >>)dnl
<<  --enable-shared[=PKGS]  build shared libraries [default=>>AM_ENABLE_SHARED_DEFAULT],
changequote([, ])dnl
[p=${PACKAGE-default}
case "$enableval" in
yes) enable_shared=yes ;;
no) enable_shared=no ;;
*)
  enable_shared=no
  # Look at the argument we got.  We use all the common list separators.
  IFS="${IFS= 	}"; ac_save_ifs="$IFS"; IFS="${IFS}:,"
  for pkg in $enableval; do
    if test "X$pkg" = "X$p"; then
      enable_shared=yes
    fi
  done
  IFS="$ac_save_ifs"
  ;;
esac],
enable_shared=AM_ENABLE_SHARED_DEFAULT)dnl
])

# AM_DISABLE_SHARED - set the default shared flag to --disable-shared
AC_DEFUN(AM_DISABLE_SHARED,
[AM_ENABLE_SHARED(no)])

# AM_DISABLE_STATIC - set the default static flag to --disable-static
AC_DEFUN(AM_DISABLE_STATIC,
[AM_ENABLE_STATIC(no)])

# AM_ENABLE_STATIC - implement the --enable-static flag
# Usage: AM_ENABLE_STATIC[(DEFAULT)]
#   Where DEFAULT is either `yes' or `no'.  If omitted, it defaults to
#   `yes'.
AC_DEFUN(AM_ENABLE_STATIC,
[define([AM_ENABLE_STATIC_DEFAULT], ifelse($1, no, no, yes))dnl
AC_ARG_ENABLE(static,
changequote(<<, >>)dnl
<<  --enable-static[=PKGS]  build static libraries [default=>>AM_ENABLE_STATIC_DEFAULT],
changequote([, ])dnl
[p=${PACKAGE-default}
case "$enableval" in
yes) enable_static=yes ;;
no) enable_static=no ;;
*)
  enable_static=no
  # Look at the argument we got.  We use all the common list separators.
  IFS="${IFS= 	}"; ac_save_ifs="$IFS"; IFS="${IFS}:,"
  for pkg in $enableval; do
    if test "X$pkg" = "X$p"; then
      enable_static=yes
    fi
  done
  IFS="$ac_save_ifs"
  ;;
esac],
enable_static=AM_ENABLE_STATIC_DEFAULT)dnl
])


# AM_PROG_LD - find the path to the GNU or non-GNU linker
AC_DEFUN(AM_PROG_LD,
[AC_ARG_WITH(gnu-ld,
[  --with-gnu-ld           assume the C compiler uses GNU ld [default=no]],
test "$withval" = no || with_gnu_ld=yes, with_gnu_ld=no)
AC_REQUIRE([AC_PROG_CC])
ac_prog=ld
if test "$ac_cv_prog_gcc" = yes; then
  # Check if gcc -print-prog-name=ld gives a path.
  AC_MSG_CHECKING([for ld used by GCC])
  ac_prog=`($CC -print-prog-name=ld) 2>&5`
  case "$ac_prog" in
  # Accept absolute paths.
changequote(,)dnl
  /* | [A-Za-z]:\\*)
changequote([,])dnl
    test -z "$LD" && LD="$ac_prog"
    ;;
  "")
    # If it fails, then pretend we aren't using GCC.
    ac_prog=ld
    ;;
  *)
    # If it is relative, then search for the first ld in PATH.
    with_gnu_ld=unknown
    ;;
  esac
elif test "$with_gnu_ld" = yes; then
  AC_MSG_CHECKING([for GNU ld])
else
  AC_MSG_CHECKING([for non-GNU ld])
fi
AC_CACHE_VAL(ac_cv_path_LD,
[if test -z "$LD"; then
  IFS="${IFS= 	}"; ac_save_ifs="$IFS"; IFS="${IFS}:"
  for ac_dir in $PATH; do
    test -z "$ac_dir" && ac_dir=.
    if test -f "$ac_dir/$ac_prog"; then
      ac_cv_path_LD="$ac_dir/$ac_prog"
      # Check to see if the program is GNU ld.  I'd rather use --version,
      # but apparently some GNU ld's only accept -v.
      # Break only if it was the GNU/non-GNU ld that we prefer.
      if "$ac_cv_path_LD" -v 2>&1 < /dev/null | egrep '(GNU|with BFD)' > /dev/null; then
	test "$with_gnu_ld" != no && break
      else
        test "$with_gnu_ld" != yes && break
      fi
    fi
  done
  IFS="$ac_save_ifs"
else
  ac_cv_path_LD="$LD" # Let the user override the test with a path.
fi])
LD="$ac_cv_path_LD"
if test -n "$LD"; then
  AC_MSG_RESULT($LD)
else
  AC_MSG_RESULT(no)
fi
test -z "$LD" && AC_MSG_ERROR([no acceptable ld found in \$PATH])
AC_SUBST(LD)
AM_PROG_LD_GNU
])

AC_DEFUN(AM_PROG_LD_GNU,
[AC_CACHE_CHECK([if the linker ($LD) is GNU ld], ac_cv_prog_gnu_ld,
[# I'd rather use --version here, but apparently some GNU ld's only accept -v.
###--- On AIX, xlC -q64 -v return GNU and cause confusion in detection of GNU linker
###--- Fix by making grep work more precise.
if $LD -v 2>&1 </dev/null | fgrep 'GNU ld version' 1>&5; then
  ac_cv_prog_gnu_ld=yes
else
  ac_cv_prog_gnu_ld=no
fi])
])

# AM_PROG_NM - find the path to a BSD-compatible name lister
AC_DEFUN(AM_PROG_NM,
[AC_MSG_CHECKING([for BSD-compatible nm])
AC_CACHE_VAL(ac_cv_path_NM,
[if test -n "$NM"; then
  # Let the user override the test.
  ac_cv_path_NM="$NM"
else
  IFS="${IFS= 	}"; ac_save_ifs="$IFS"; IFS="${IFS}:"
  for ac_dir in /usr/ucb /usr/ccs/bin $PATH /bin; do
    test -z "$ac_dir" && ac_dir=.
    if test -f $ac_dir/nm; then
      # Check to see if the nm accepts a BSD-compat flag.
      # Adding the `sed 1q' prevents false positives on HP-UX, which says:
      #   nm: unknown option "B" ignored
      if ($ac_dir/nm -B /dev/null 2>&1 | sed '1q'; exit 0) | egrep /dev/null >/dev/null; then
        ac_cv_path_NM="$ac_dir/nm -B"
      elif ($ac_dir/nm -p /dev/null 2>&1 | sed '1q'; exit 0) | egrep /dev/null >/dev/null; then
        ac_cv_path_NM="$ac_dir/nm -p"
      else
        ac_cv_path_NM="$ac_dir/nm"
      fi
      break
    fi
  done

  ac_cv_path_NM="$ac_cv_path_NM $NM_option"

  IFS="$ac_save_ifs"
  test -z "$ac_cv_path_NM" && ac_cv_path_NM=nm
fi])
NM="$ac_cv_path_NM"
AC_MSG_RESULT([$NM])
AC_SUBST(NM)
])


# Like AC_CONFIG_HEADER, but automatically create stamp file.

AC_DEFUN(AM_CONFIG_HEADER,
[AC_PREREQ([2.12])
AC_CONFIG_HEADER([$1])
dnl When config.status generates a header, we must update the stamp-h file.
dnl This file resides in the same directory as the config header
dnl that is generated.  We must strip everything past the first ":",
dnl and everything past the last "/".
AC_OUTPUT_COMMANDS(changequote(<<,>>)dnl
ifelse(patsubst(<<$1>>, <<[^ ]>>, <<>>), <<>>,
<<test -z "<<$>>CONFIG_HEADERS" || echo timestamp > patsubst(<<$1>>, <<^\([^:]*/\)?.*>>, <<\1>>)stamp-h<<>>dnl>>,
<<am_indx=1
for am_file in <<$1>>; do
  case " <<$>>CONFIG_HEADERS " in
  *" <<$>>am_file "*<<)>>
    echo timestamp > `echo <<$>>am_file | sed -e 's%:.*%%' -e 's%[^/]*$%%'`stamp-h$am_indx
    ;;
  esac
  am_indx=`expr "<<$>>am_indx" + 1`
done<<>>dnl>>)
changequote([,]))])

# Do all the work for Automake.  This macro actually does too much --
# some checks are only needed if your package does certain things.
# But this isn't really a big deal.

# serial 1

dnl Usage:
dnl AM_INIT_AUTOMAKE(package,version, [no-define])

AC_DEFUN(AM_INIT_AUTOMAKE,
[AC_REQUIRE([AC_PROG_INSTALL])
PACKAGE=[$1]
AC_SUBST(PACKAGE)
VERSION=[$2]
AC_SUBST(VERSION)
dnl test to see if srcdir already configured
if test "`cd $srcdir && pwd`" != "`pwd`" && test -f $srcdir/config.status; then
  AC_MSG_ERROR([source directory already configured; run "make distclean" there first])
fi
ifelse([$3],,
AC_DEFINE_UNQUOTED(PACKAGE, "$PACKAGE", [Name of package])
AC_DEFINE_UNQUOTED(VERSION, "$VERSION", [Version number of package]))
AC_REQUIRE([AM_SANITY_CHECK])
AC_REQUIRE([AC_ARG_PROGRAM])
dnl FIXME This is truly gross.
missing_dir=`cd $ac_aux_dir && pwd`
AM_MISSING_PROG(ACLOCAL, aclocal, $missing_dir)
AM_MISSING_PROG(AUTOCONF, autoconf, $missing_dir)
AM_MISSING_PROG(AUTOMAKE, automake, $missing_dir)
AM_MISSING_PROG(AUTOHEADER, autoheader, $missing_dir)
AM_MISSING_PROG(MAKEINFO, makeinfo, $missing_dir)
AC_REQUIRE([AC_PROG_MAKE_SET])])

#
# Check to make sure that the build environment is sane.
#

AC_DEFUN(AM_SANITY_CHECK,
[AC_MSG_CHECKING([whether build environment is sane])
# Just in case
sleep 1
echo timestamp > conftestfile
# Do `set' in a subshell so we don't clobber the current shell's
# arguments.  Must try -L first in case configure is actually a
# symlink; some systems play weird games with the mod time of symlinks
# (eg FreeBSD returns the mod time of the symlink's containing
# directory).
if (
   set X `ls -Lt $srcdir/configure conftestfile 2> /dev/null`
   if test "[$]*" = "X"; then
      # -L didn't work.
      set X `ls -t $srcdir/configure conftestfile`
   fi
   if test "[$]*" != "X $srcdir/configure conftestfile" \
      && test "[$]*" != "X conftestfile $srcdir/configure"; then

      # If neither matched, then we have a broken ls.  This can happen
      # if, for instance, CONFIG_SHELL is bash and it inherits a
      # broken ls alias from the environment.  This has actually
      # happened.  Such a system could not be considered "sane".
      AC_MSG_ERROR([ls -t appears to fail.  Make sure there is not a broken
alias in your environment])
   fi

   test "[$]2" = conftestfile
   )
then
   # Ok.
   :
else
   AC_MSG_ERROR([newly created file is older than distributed files!
Check your system clock])
fi
rm -f conftest*
AC_MSG_RESULT(yes)])

dnl AM_MISSING_PROG(NAME, PROGRAM, DIRECTORY)
dnl The program must properly implement --version.
AC_DEFUN(AM_MISSING_PROG,
[AC_MSG_CHECKING(for working $2)
# Run test in a subshell; some versions of sh will print an error if
# an executable is not found, even if stderr is redirected.
# Redirect stdin to placate older versions of autoconf.  Sigh.
if ($2 --version) < /dev/null > /dev/null 2>&1; then
   $1=$2
   AC_MSG_RESULT(found)
else
   $1="$3/missing $2"
   AC_MSG_RESULT(missing)
fi
AC_SUBST($1)])


dnl AM_PROG_LEX
dnl Look for flex, lex or missing, then run AC_PROG_LEX and AC_DECL_YYTEXT
AC_DEFUN(AM_PROG_LEX,
[missing_dir=ifelse([$1],,`cd $ac_aux_dir && pwd`,$1)
AC_CHECK_PROGS(LEX, flex lex, "$missing_dir/missing flex")
AC_PROG_LEX
AC_DECL_YYTEXT])

# Define a conditional.

AC_DEFUN(AM_CONDITIONAL,
[AC_SUBST($1_TRUE)
AC_SUBST($1_FALSE)
if $2; then
  $1_TRUE=
  $1_FALSE='#'
else
  $1_TRUE='#'
  $1_FALSE=
fi])

AC_DEFUN(OASIS_DETERMINE_CC_CXX_LD,
[AC_MSG_CHECKING(oasis compiler/linker decision)
# The order must be maintained as CC -> CXX -> LD
OptimizePrefixForC=
case $target in
	*-pc-cygwin*)
	CC=${CC:-cl}
	CXX=${CXX:-cl}
	LD=${LD:-link}
			CC=${CC:-cc -q64}
			CXX=${CXX:-xlC -qlanglvl=extended0x -q64 -brtl -bexpall -qfuncsect}
	;;
	*-linux*)
		if test "$BUILD_64_BIT_OBJ" = yes ; then
			CC="gcc -m64 -rdynamic"
			CXX="c++ -m64 -rdynamic"
		else
			CC="gcc -m32 -rdynamic"
			CXX="c++ -m32 -rdynamic"
		fi
		;;
	*-aix7.3*)
		if test "$BUILD_64_BIT_OBJ" = yes ; then
			CC=${CC:-ibm-clang -m64 -fsigned-char }
                        CXX=${CXX:-ibm-clang++_r -lstdc++ -g -O0 -fsigned-char -lstdc++ -m64 -brtl -Wreturn-type -ffunction-sections -bbigtoc -fno-threadsafe-statics -Wno-register}
                        LD=${LD:-ibm-clang++_r -shared -W1,-G -g -bloadmap:load.map -m64 -bbigtoc -brtl }
			NM_option="-X64"
			AR_option="-X64"
		else
			CC=${CC:-ibm-clang}
			lslpp -L | fgrep vacpp.cmp >/dev/null 2>&1
			if test $? = 0 ; then
				VaSpecOpt="-bexpall"
			fi
			CXX=${CXX:-ibm-clang -std=gnu++98 -lstdc++ -g -O0 -brtl $VaSpecOpt -ffunction-sections -bbigtoc -fno-threadsafe-statics}

			###LD=${LD:-makeC++SharedLib -bloadmap:load.map -p 2000 -brtl }  --
			LD=${LD:-ibm-clang++_r -shared -Wl,-G -g -bbigtoc -bloadmap:load.map -brtl }

		fi
		echo "int main(){return 0;}" > __.cxx
		echo "$CXX -c -o __.o __.cxx"
		$CXX -c -o __.o __.cxx 2>&1 | grep -i "support"
		if test $? != 0 ; then
			CXX="$CXX "
		fi
		rm -f __.cxx __.o
		;;
	 *-aix*) 
		if test "$build_64_bit_obj" = yes ; then
			CC=${cc:-cc -q64}
			CXX=${CXX:-xlC -qlanglvl=extended0x -q64 -brtl -bexpall -qfuncsect}
			LD=${LD:-xlC -bloadmap:load.map -q64 -brtl}
			NM_option="-X64"
			AR_option="-X64"
		else
			CC=${CC:-cc}
			lslpp -L | fgrep vacpp.cmp >/dev/null 2>&1
			if test $? = 0 ; then
				VaSpecOpt="-bexpall"
			fi
			CXX=${CXX:-xlC -qlanglvl=extended0x -brtl $VaSpecOpt -qfuncsect}
			LD=${LD:-makeC++SharedLib -bloadmap:load.map -p 2000 -brtl}
		fi

		###
		### -rc-
		### xlC v7 by default make local symbol weak and
		### this is opposite of v6.
		### This is causing problem in resolving methods of
		### class string in STL - the system version is picked
		### up instead of the one in foundation.
		### To ensure the one in foundation is pickup, compiler
		### flag "-qnoweaksymbol" is specified.
		###
		echo "int main(){return 0;}" > __.cxx
		echo "$CXX -qnoweaksymbol -c -o __.o __.cxx"
		$CXX -qnoweaksymbol -c -o __.o __.cxx 2>&1 | grep -i "support"
		if test $? != 0 ; then
			CXX="$CXX -qnoweaksymbol"
		fi
		rm -f __.cxx __.o
	;;
	*-solaris*)
		CC_YEAR=`CC -V 2>&1 | sed 's/.* //' | sed 's/\/.*//'`
		OPTION=''
		if test "$BUILD_64_BIT_OBJ" = yes ; then
			### With 64-bit
			if test "$CC_YEAR" -ge 2017 ; then
				### With v5.15, change from generic to native
				OPTION='-m64 -xtarget=native'
			elif test "$CC_YEAR" -ge 2011 ; then
				### With v5.13, -m64 and -xtarget=generic
				OPTION='-m64'
			else
				### With v5.8 where no -m64
				OPTION='-xarch=generic64'
			fi
		else
			### With 32-bit
			if test "$CC_YEAR" -ge 2017 ; then
				OPTION='-xtarget=native'
			elif test "$CC_YEAR" -ge 2011 ; then
				### same as -m32 -xtarget=generic
				OPTION="-m32"
			else
				### same as -xtarget=generic
				OPTION=""
			fi
        fi
		CC=${CC:-cc $OPTION}
		CXX=${CXX:-CC $OPTION}
		LD=${LD:-CC $OPTION}
	    OptimizePrefixForC=x
	;;
	ia64*-hpux*)
		if test "$BUILD_64_BIT_OBJ" = yes ; then
        	CC=${CC:-cc +DD64}
        	CXX=${CXX:-aCC +DD64}
        	LD=${LD:-aCC +DD64}
	        LDFLAGS="$LDFLAGS -L/usr/lib/hpux64 -Wl,+s -Wl,-E"
	        LDF_PUSH_BACK=-L/usr/lib/hpux64
		else
	        CC=${CC:-cc}
        	CXX=${CXX:-aCC}
        	LD=${LD:-aCC}
	        LDFLAGS="$LDFLAGS -L/usr/lib/hpux32 -Wl,+s -Wl,-E"
	        LDF_PUSH_BACK=-L/usr/lib/hpux32
        fi
	    AC_SUBST(LDFLAGS)
	;;

	*-hpux*)
		if test "$BUILD_64_BIT_OBJ" = yes ; then
        	CC=${CC:-cc +DD64}
        	CXX=${CXX:-aCC +DD64}
        	LD=${LD:-aCC +DD64}
		else
	        CC=${CC:-cc}
        	CXX=${CXX:-aCC}
        	LD=${LD:-aCC}
        fi
	# Use this if don't want to embed path of libraries in executable
	# LDFLAGS="$LDFLAGS -Wl,+s -Wl,-E -Wl,+nodefaultrpath -ldld"
	LDFLAGS="$LDFLAGS -Wl,+s -Wl,-E"
	AC_SUBST(LDFLAGS)
	;;
	*-osf*)
	CC=${CC:-cc}
	CXX=${CXX:-cxx}
	LD=${LD:-cxx}
	;;
	*-ibm-opened*)
	CC=${CC:-ocxx390}
	CXX=${CXX:-ocxx390}
	LD=${LD:-ocxx390}
	;;
	*-sequent-sysv4)
	CC=${CC:-cc}
	CXX=${CXX:-c++}
	LD=${LD:-c++}
	;;
esac
echo "$CC/$CXX/$LD"
])

AC_DEFUN(OASIS_USE_LIBTOOL_LINK_EXEC,
[AC_MSG_CHECKING(checking whether we should use libtool to build executables)
if test "$CC" = "cl"; then
	COMPILE='$(LIBTOOL) --mode=compile $(CC) $(DEFS) $(INCLUDES) $(AM_CPPFLAGS) $(CPPFLAGS) $(AM_CFLAGS) $(CFLAGS)'
	AC_SUBST(COMPILE)

	CXXCOMPILE='$(LIBTOOL) --mode=compile $(CXX) $(DEFS) $(INCLUDES) $(AM_CPPFLAGS) $(CPPFLAGS) $(AM_CXXFLAGS) $(CXXFLAGS)'
	AC_SUBST(CXXCOMPILE)
	echo "yes"

else

	COMPILE='$(CC) $(DEFS) $(INCLUDES) $(AM_CPPFLAGS) $(CPPFLAGS) $(AM_CFLAGS) $(CFLAGS)'
	AC_SUBST(COMPILE)

	CXXCOMPILE='$(CXX) $(DEFS) $(INCLUDES) $(AM_CPPFLAGS) $(CPPFLAGS) $(AM_CXXFLAGS) $(CXXFLAGS)'
	AC_SUBST(CXXCOMPILE)
	echo "no"

fi])


AC_DEFUN(OASIS_SET_PLATFORM_ID,
[AC_MSG_CHECKING(platform identification)
case $target in
	*-pc-cygwin*)
	CFLAGS="$CFLAGS -DPROTOTYPE -DWIN32 -DWin32"
	CXXFLAGS="$CXXFLAGS -DPROTOTYPE -DWIN32 -DWin32"
	;;
    *-linux*)
	CFLAGS="$CFLAGS -DPROTOTYPE -Dunix -DLINUX -DLinux"
	# Well, we need : 
	#	-pedantic-errors to fail undeclared functions
	#	-ansi to skip 0-dimension array 
	#	-Wno-long-long to allow long long in JNI-1.3
	# CXXFLAGS="$CXXFLAGS -ansi -Werror -DPROTOTYPE -Dunix -DLINUX -DLinux"
	# -Wno-long-long does not work => has to remove -pedantic-error
	# Link-test, instead of compile-test will be performed to unsure
	# pthread prototypes are actually defined.
	CXXFLAGS="$CXXFLAGS -ansi -DPROTOTYPE -Dunix -DLINUX -DLinux"
	;;
    *-aix7.3*)
	CFLAGS="$CFLAGS -DPROTOTYPE -Dunix -ansi -DAIX -D_AIX -DAIX4_2 "
	CXXFLAGS="$CXXFLAGS -DPROTOTYPE -Dunix -ansi -DAIX -D_AIX -DAIX4_2 -Wno-reserved-user-defined-literal"
	;;
    *-aix*)
	CFLAGS="$CFLAGS -DPROTOTYPE -Dunix -DAIX -D_AIX -DAIX4_2 -qchars=signed -qnoro -qnoroconst"
	CXXFLAGS="$CXXFLAGS -DPROTOTYPE -Dunix -DAIX -D_AIX -DAIX4_2 -qchars=signed -qnoro -qnoroconst"
	;;
    *-solaris*)
	CFLAGS="$CFLAGS -DPROTOTYPE -Dunix -DSOLARIS -D_SOLARIS -DSOLARIS2_5"
	CXXFLAGS="$CXXFLAGS -DPROTOTYPE -Dunix -DSOLARIS -D_SOLARIS -DSOLARIS2_5"
	;;
    ia64*-hpux*)
	CFLAGS="$CFLAGS -DPROTOTYPE -Dunix -DHP_UX"
	CXXFLAGS="$CXXFLAGS -DPROTOTYPE -Dunix -DHP_UX +eh"
	;;
    *-hpux*)
	CFLAGS="$CFLAGS -DPROTOTYPE -Dunix -DHP_UX -DHP_UXB_10_20 -D__hp9000s800 -DHP_9000 -Ae +DAportable"
	CXXFLAGS="$CXXFLAGS -DPROTOTYPE -Dunix -DHP_UX -DHP_UXB_10_20 -D__hp9000s800 -DHP_9000 +DAportable +eh"
	;;
    *-osf*)
	CFLAGS="$CFLAGS -DPROTOTYPE -Dunix -DOSF -D_OSF -DOSF4_0 -D__alpha -DA_OSF -DALPHA -assume noaligned_objects"
	CXXFLAGS="$CXXFLAGS -DPROTOTYPE -Dunix -DOSF -D_OSF -DOSF4_0 -D__alpha -DA_OSF -DALPHA -assume noaligned_objects"
	;;
    *-ibm-opened*)
	# The original plan is to specify -W"0,langlvl(extended)" to turn on
	# flag __EXTENDED__ and hence _EXT indirectly. This becomes too difficult
	# because of the different escape requirement, for '(', ')', in 'configure'
	# and in 'libtool'. For this reason, macro '_EXT' is specified directly.
	# This may be less compatible, but I don't think it matters in short
	# and mid term.
	CFLAGS="$CFLAGS -DPROTOTYPE -Dunix -DOS390 -DOS390_2_7 -D_EXT -D_VARARG_EXT_ -D_ALL_SOURCE"
	CXXFLAGS="$CXXFLAGS -DPROTOTYPE -Dunix -DOS390 -DOS390_2_7 -D_EXT -D_VARARG_EXT_ -D_ALL_SOURCE"
	;;
	*-sequent-sysv4)
	CFLAGS="$CFLAGS -DPROTOTYPE -Dunix -DPTX -D_PTX"
	CXXFLAGS="$CXXFLAGS -DPROTOTYPE -Dunix -DPTX -D_PTX -anach -preansilibs -Kthread"
	;;
esac
if test "$BUILD_64_BIT_OBJ" = yes ; then
	CFLAGS="$CFLAGS -DOBJ64"
	CXXFLAGS="$CXXFLAGS -DOBJ64"
fi
echo $CFLAGS
AC_SUBST(CFLAGS)
AC_SUBST(CXXFLAGS)])

AC_DEFUN(OASIS_SET_TARGET,
[TARGET=\"$target\"
AC_SUBST(TARGET)
AC_DEFINE_UNQUOTED(TARGET,$TARGET)])

AC_DEFUN(OASIS_SET_INCLUDES,
[# Give me includes from the source directory and previously installed packages

### cannot trust automake to put -I. -I$(srcdir) -I../include into DEFS
INCLUDES="$INCLUDES"' -I. -I$(srcdir) -I../include -I$(srcdir)/../include -I$(includedir)'
AC_SUBST(INCLUDES)])

AC_DEFUN(OASIS_SET_LDFLAGS,
[# Where are the previously installed libraries

if test "${prefix}" = "NONE"
then
  echo "setting installed library path to default /usr/local/lib"
  LDFLAGS="$LDFLAGS -L/usr/local/lib"
else
  echo "setting installed library path to prefix ${prefix}"
  LDFLAGS="$LDFLAGS -L${prefix}/lib"
  # if LDF_PUSH_BACK is not empty (contains "-L/usr/lib/hpux32")
  # then move its occurance in LDFLAGS to the back
  if test X$LDF_PUSH_BACK != X; then
	LDFLAGS=`echo $LDFLAGS | sed "s#$LDF_PUSH_BACK##g"`
	LDFLAGS="$LDFLAGS $LDF_PUSH_BACK"
  fi
fi
AC_SUBST(LDFLAGS)])

AC_DEFUN(OASIS_CHK_DLFCN_H,
[# What type of shared libraries and dynamic linker do we have
# Test for dl.h is done first hpux has both and dl.h is the one being used.

AC_CHECK_HEADER(dl.h, dl_h=yes, dl_h=ni)
if test $dl_h = yes; then
	AC_DEFINE(HAVE_DL_H)
	DL_OBJS="$DL_OBJS dl.lo"
else

AC_CHECK_HEADER(dlfcn.h, dlfcn_h=yes, dlfcn_h=no)
if test $dlfcn_h = yes; then
  AC_DEFINE(HAVE_DLFCN_H)
  DL_OBJS="$DL_OBJS dlfcn.lo"

  AC_MSG_CHECKING(if RTLD_LAZY is defined)
  AC_TRY_COMPILE([#include <dlfcn.h>], [int foo = RTLD_LAZY;],
                 echo yes,AC_DEFINE(RTLD_LAZY, 1) echo no)

  AC_MSG_CHECKING(if RTLD_NOW is defined)
  AC_TRY_COMPILE([#include <dlfcn.h>], [int foo = RTLD_NOW;],
                 echo yes,AC_DEFINE(RTLD_NOW, 1) echo no)

  AC_MSG_CHECKING(if RTLD_GLOBAL is defined)
  AC_TRY_COMPILE([#include <dlfcn.h>], [int foo = RTLD_GLOBAL;],
                 echo yes,AC_DEFINE(RTLD_GLOBAL, 1) echo no)

  AC_CHECK_LIB(c, dlopen, ,
    AC_CHECK_LIB(dl, dlopen, LIBS="$LIBS -ldl")
  )
else

AC_MSG_CHECKING(if dll.h is defined)
AC_TRY_COMPILE([#include <dll.h>], [
dllhandle *aDllHdl = dllload( "" );
dllquery(aDllHdl, "" );
dllfree(aDllHdl) ;
],
dll_h=yes, dll_h=no)

if test $dll_h = yes; then
	echo yes
	AC_DEFINE(HAVE_DLL_H)
else
	echo no
fi

fi
fi
AC_SUBST(DL_OBJS)
AC_SUBST(LIBS)])

AC_DEFUN(OASIS_CHK_STRUCT_SEMUN,
[# Some (good) systems define this, but SystemV has brain damage and
# uses a void so we have to define our own system(!) structure for it

AC_MSG_CHECKING(for struct semun)
AC_TRY_COMPILE([
#include <sys/ipc.h>
#include <sys/sem.h>
], [
union semun foo;

int
bar()
{
  foo.val = 0;
}
],
AC_DEFINE(HAVE_STRUCT_SEMUN) echo yes, echo no)])

AC_DEFUN(OASIS_CHK_POSIX_FUNC,
[#--------------------------------------------------------------------
#	missing POSIX library procedures
#--------------------------------------------------------------------

AC_CHECK_FUNCS(getcwd, , AC_DEFINE(NO_GETCWD))

AC_REPLACE_FUNCS(opendir strstr)

AC_REPLACE_FUNCS(strtol tmpnam waitpid)
AC_CHECK_FUNC(strerror, , AC_DEFINE(NO_STRERROR))
AC_CHECK_FUNC(getwd, , AC_DEFINE(NO_GETWD))
AC_CHECK_FUNC(wait3, , AC_DEFINE(NO_WAIT3))
AC_CHECK_FUNC(uname, , AC_DEFINE(NO_UNAME))
AC_CHECK_FUNC(stpchr, AC_DEFINE(HAVE_STPCHR))
AC_CHECK_FUNC(stpcpy, AC_DEFINE(HAVE_STPCPY))])

AC_DEFUN(OASIS_CHK_STP_FUNC, [
#--------------------------------------------------------------------
#	missing stpchr/stpcpy (subset POSIX) library procedures
#--------------------------------------------------------------------
AC_CHECK_FUNC(stpchr, AC_DEFINE(HAVE_STPCHR))
AC_CHECK_FUNC(stpcpy, AC_DEFINE(HAVE_STPCPY))
])

AC_DEFUN(OASIS_SET_MATH_LIB,
[#--------------------------------------------------------------------
#	On a few very rare systems, all of the libm.a stuff is
#	already in libc.a.  Set compiler flags accordingly.
#	Also, Linux requires the "ieee" library for math to work
#	right (and it must appear before "-lm").
#--------------------------------------------------------------------

AC_CHECK_LIB(ieee, main, [LIBS="-lieee $LIBS"])
AC_CHECK_FUNC(sin, , LIBS="$LIBS -lm")
AC_SUBST(LIBS)])

AC_DEFUN(OASIS_SET_GETTIMEOFDAY_LIB,
[#--------------------------------------------------------------------
#       On AIX systems, libbsd.a has to be linked in to support
#       non-blocking file IO.  This library has to be linked in after
#       the MATH_LIBS or it breaks the pow() function.  The way to
#       insure proper sequencing, is to add it to the tail of MATH_LIBS.
#        This library also supplies gettimeofday.
#--------------------------------------------------------------------
libbsd=no
if test "`uname -s`" = "AIX" ; then
    AC_CHECK_LIB(bsd, gettimeofday, libbsd=yes)
    if test $libbsd = yes; then
	LIBS="$LIBS -lbsd"
    fi
fi
AC_SUBST(LIBS)])

AC_DEFUN(OASIS_CHK_STD_HDR,
[#--------------------------------------------------------------------
#	Supply substitutes for missing POSIX header files.  Special
#	notes:
#	    - stdlib.h doesn't define strtol, strtoul, or
#	      strtod insome versions of SunOS
#	    - some versions of string.h don't declare procedures such
#	      as strstr
#--------------------------------------------------------------------

AC_MSG_CHECKING(dirent.h)
AC_TRY_LINK([#include <sys/types.h>
#include <dirent.h>], [
#ifndef _POSIX_SOURCE
#   ifdef __Lynx__
	/*
	 * Generate compilation error to make the test fail:  Lynx headers
	 * are only valid if really in the POSIX environment.
	 */

	missing_procedure();
#   endif
#endif
DIR *d;
struct dirent *entryPtr;
char *p;
d = opendir("foobar");
entryPtr = readdir(d);
p = entryPtr->d_name;
closedir(d);
], tcl_ok=yes, tcl_ok=no)
if test $tcl_ok = no; then
    AC_DEFINE(NO_DIRENT_H)
fi
AC_MSG_RESULT($tcl_ok)
AC_CHECK_HEADER(errno.h, , AC_DEFINE(NO_ERRNO_H))
AC_CHECK_HEADER(float.h, , AC_DEFINE(NO_FLOAT_H))
AC_CHECK_HEADER(values.h, , AC_DEFINE(NO_VALUES_H))
AC_CHECK_HEADER(limits.h, , AC_DEFINE(NO_LIMITS_H))
AC_CHECK_HEADER(stdlib.h, tcl_ok=1, tcl_ok=0)
AC_EGREP_HEADER(strtol, stdlib.h, , tcl_ok=0)
AC_EGREP_HEADER(strtoul, stdlib.h, , tcl_ok=0)
AC_EGREP_HEADER(strtod, stdlib.h, , tcl_ok=0)
if test $tcl_ok = 0; then
    AC_DEFINE(NO_STDLIB_H)
fi
AC_CHECK_HEADER(string.h, tcl_ok=1, tcl_ok=0)
AC_EGREP_HEADER(strstr, string.h, , tcl_ok=0)
AC_EGREP_HEADER(strerror, string.h, , tcl_ok=0)
if test $tcl_ok = 0; then
    AC_DEFINE(NO_STRING_H)
fi
AC_CHECK_HEADER(sys/wait.h, , AC_DEFINE(NO_SYS_WAIT_H))
AC_HAVE_HEADERS(unistd.h)])

AC_DEFUN(OASIS_CHK_TERMIO_H,
[#---------------------------------------------------------------------------
#	Determine which interface to use to talk to the serial port.
#	Note that #include lines must begin in leftmost column for
#	some compilers to recognize them as preprocessor directives.
#---------------------------------------------------------------------------

AC_MSG_CHECKING([termios vs. termio vs. sgtty])
AC_TRY_RUN([
#include <termios.h>

main()
{
    struct termios t;
    if (tcgetattr(0, &t) == 0) {
	cfsetospeed(&t, 0);
	t.c_cflag |= PARENB | PARODD | CSIZE | CSTOPB;
	return 0;
    }
    return 1;
}], tk_ok=termios, tk_ok=no, tk_ok=no)
if test $tk_ok = termios; then
    AC_DEFINE(USE_TERMIOS)
else
AC_TRY_RUN([
#include <termio.h>

main()
{
    struct termio t;
    if (ioctl(0, TCGETA, &t) == 0) {
	t.c_cflag |= CBAUD | PARENB | PARODD | CSIZE | CSTOPB;
	return 0;
    }
    return 1;
}], tk_ok=termio, tk_ok=no, tk_ok=no)
if test $tk_ok = termio; then
    AC_DEFINE(USE_TERMIO)
else
AC_TRY_RUN([
#include <sgtty.h>

main()
{
    struct sgttyb t;
    if (ioctl(0, TIOCGETP, &t) == 0) {
	t.sg_ospeed = 0;
	t.sg_flags |= ODDP | EVENP | RAW;
	return 0;
    }
    return 1;
}], tk_ok=sgtty, tk_ok=none, tk_ok=none)
if test $tk_ok = sgtty; then
    AC_DEFINE(USE_SGTTY)
fi
fi
fi
AC_MSG_RESULT($tk_ok)])


AC_DEFUN(OASIS_CHK_SELECT_H,
[#--------------------------------------------------------------------
#	Include sys/select.h if it exists and if it supplies things
#	that appear to be useful and aren't already in sys/types.h.
#	This appears to be true only on the RS/6000 under AIX.  Some
#	systems like OSF/1 have a sys/select.h that's of no use, and
#	other systems like SCO UNIX have a sys/select.h that's
#	pernicious.  If "fd_set" isn't defined anywhere then set a
#	special flag.
#--------------------------------------------------------------------

AC_MSG_CHECKING([fd_set and sys/select])
AC_TRY_COMPILE([#include <sys/types.h>],
	[fd_set readMask, writeMask;], tk_ok=yes, tk_ok=no)
if test $tk_ok = no; then
    AC_HEADER_EGREP(fd_mask, sys/select.h, tk_ok=yes)
    if test $tk_ok = yes; then
	AC_DEFINE(HAVE_SYS_SELECT_H)
    fi
fi
AC_MSG_RESULT($tk_ok)
if test $tk_ok = no; then
    AC_DEFINE(NO_FD_SET)
fi])

AC_DEFUN(OASIS_CHK_TIME_HANDLING,
[#------------------------------------------------------------------------------
#       Find out all about time handling differences.
#------------------------------------------------------------------------------

AC_CHECK_HEADERS(sys/time.h)
AC_HEADER_TIME
AC_STRUCT_TIMEZONE

AC_MSG_CHECKING([tm_tzadj in struct tm])
AC_TRY_COMPILE([#include <time.h>], [struct tm tm; tm.tm_tzadj;],
        [AC_DEFINE(HAVE_TM_TZADJ)
         AC_MSG_RESULT(yes)],
         AC_MSG_RESULT(no))

AC_MSG_CHECKING([tm_gmtoff in struct tm])
AC_TRY_COMPILE([#include <time.h>], [struct tm tm; tm.tm_gmtoff;],
        [AC_DEFINE(HAVE_TM_GMTOFF)
         AC_MSG_RESULT(yes)],
         AC_MSG_RESULT(no))

#
# Its important to include time.h in this check, as some systems (like convex)
# have timezone functions, etc.
#
have_timezone=no
AC_MSG_CHECKING([long timezone variable])
AC_TRY_COMPILE([#include <time.h>],
        [extern long timezone;
         timezone += 1;
         exit (0);],
        [have_timezone=yes
	 AC_DEFINE(HAVE_TIMEZONE_VAR)
         AC_MSG_RESULT(yes)],
         AC_MSG_RESULT(no))

#
# On some systems (eg IRIX 6.2), timezone is a time_t and not a long.
#
if test "$have_timezone" = no; then
   AC_MSG_CHECKING([time_t timezone variable])
   AC_TRY_COMPILE([#include <time.h>],
        [extern time_t timezone;
         timezone += 1;
         exit (0);],
        [AC_DEFINE(HAVE_TIMEZONE_VAR)
         AC_MSG_RESULT(yes)],
         AC_MSG_RESULT(no))
fi

#
# AIX does not have a timezone field in struct tm. When the AIX bsd
# library is used, the timezone global and the gettimeofday methods are
# to be avoided for timezone deduction instead, we deduce the timezone
# by comparing the localtime result on a known GMT value.
#
if test $libbsd = yes; then
    AC_DEFINE(USE_DELTA_FOR_TZ)
fi])

AC_DEFUN(OASIS_CHK_STRSTR,
[#--------------------------------------------------------------------
#	On some systems strstr is broken: it returns a pointer even
#	even if the original string is empty.
#--------------------------------------------------------------------

AC_MSG_CHECKING(for working strstr)
AC_TRY_RUN([
extern int strstr();
int main()
{
    exit(strstr("\0test", "test") ? 1 : 0);
}
], tcl_ok=yes, tcl_ok=no, tcl_ok=no)
if test $tcl_ok = yes; then
    AC_MSG_RESULT(yes)
else
    AC_MSG_RESULT(broken)
    AC_DEFINE(NO_STRSTR) 
fi])

AC_DEFUN(OASIS_CHK_STRTOUL,
[#--------------------------------------------------------------------
#	Check for strtoul function.  This is tricky because under some
#	versions of AIX strtoul returns an incorrect terminator
#	pointer for the string "0".
#--------------------------------------------------------------------

AC_MSG_CHECKING(for working strtoul)
AC_TRY_RUN([
extern int strtoul();
int main()
{
    char *string = "0";
    char *term;
    int value;
    value = strtoul(string, &term, 0);
    if ((value != 0) || (term != (string+1))) {
        exit(1);
    }
    exit(0);
}], tcl_ok=yes, tcl_ok=no, tcl_ok=no)
if test $tcl_ok = yes; then
    AC_MSG_RESULT(yes)
else
    AC_MSG_RESULT(broken)
    AC_DEFINE(NO_STRTOUL)
fi])

AC_DEFUN(OASIS_CHK_STRTOD,
[#--------------------------------------------------------------------
#	Check for the strtod function.  This is tricky because in some
#	versions of Linux strtod mis-parses strings starting with "+".
#--------------------------------------------------------------------

AC_MSG_CHECKING(for working strtod)
AC_TRY_RUN([
extern double strtod();
int main()
{
    char *string = " +69";
    char *term;
    double value;
    value = strtod(string, &term);
    if ((value != 69) || (term != (string+4))) {
	exit(1);
    }
    exit(0);
}], tcl_ok=yes, tcl_ok=no, tcl_ok=no)
if test $tcl_ok = yes; then
    AC_MSG_RESULT(yes)
else
    AC_MSG_RESULT(broken)
    AC_DEFINE(NO_STRTOD)
fi

#--------------------------------------------------------------------
#	Under Solaris 2.4, strtod returns the wrong value for the
#	terminating character under some conditions.  Check for this
#	and if the problem exists use a substitute procedure
#	"fixstrtod" that corrects the error.
#--------------------------------------------------------------------

AC_CHECK_FUNC(strtod, tcl_strtod=1, tcl_strtod=0)
if test "$tcl_strtod" = 1; then
    AC_MSG_CHECKING([for Solaris strtod bug])
    AC_TRY_RUN([
extern double strtod();
int main()
{
    char *string = "NaN";
    char *term;
    strtod(string, &term);
    if ((term != string) && (term[-1] == 0)) {
	exit(1);
    }
    exit(0);
}], tcl_ok=1, tcl_ok=0, tcl_ok=0)
    if test $tcl_ok = 1; then
	AC_MSG_RESULT(ok)
    else
	AC_MSG_RESULT(buggy)
	AC_DEFINE(NO_STRTOD)
    fi
fi])


AC_DEFUN(OASIS_CHK_UNION_WAIT,
[#--------------------------------------------------------------------
#	The check below checks whether <sys/wait.h> defines the type
#	"union wait" correctly.  It's needed because of weirdness in
#	HP-UX where "union wait" is defined in both the BSD and SYS-V
#	environments.  Checking the usability of WIFEXITED seems to do
#	the trick.
#--------------------------------------------------------------------

AC_MSG_CHECKING([union wait])
AC_TRY_LINK([#include <sys/types.h> 
#include <sys/wait.h>], [
union wait x;
WIFEXITED(x);		/* Generates compiler error if WIFEXITED
			 * uses an int. */
], tcl_ok=yes, tcl_ok=no)
AC_MSG_RESULT($tcl_ok)
if test $tcl_ok = no; then
    AC_DEFINE(NO_UNION_WAIT)
fi])

AC_DEFUN(OASIS_CHK_FORK,
[#--------------------------------------------------------------------
#	Check to see whether the system provides a vfork kernel call.
#	If not, then use fork instead.  Also, check for a problem with
#	vforks and signals that can cause core dumps if a vforked child
#	resets a signal handler.  If the problem exists, then use fork
#	instead of vfork.
#--------------------------------------------------------------------

AC_TYPE_SIGNAL()
AC_CHECK_FUNC(vfork, tcl_ok=1, tcl_ok=0)
if test "$tcl_ok" = 1; then
    AC_MSG_CHECKING([vfork/signal bug]);
    AC_TRY_RUN([
#include <stdio.h>
#include <signal.h>
#include <sys/wait.h>
int gotSignal = 0;
sigProc(sig)
    int sig;
{
    gotSignal = 1;
}
main()
{
    int pid, sts;
    (void) signal(SIGCHLD, sigProc);
    pid = vfork();
    if (pid <  0) {
	exit(1);
    } else if (pid == 0) {
	(void) signal(SIGCHLD, SIG_DFL);
	_exit(0);
    } else {
	(void) wait(&sts);
    }
    exit((gotSignal) ? 0 : 1);
}], tcl_ok=1, tcl_ok=0, tcl_ok=0)
    if test "$tcl_ok" = 1; then
	AC_MSG_RESULT(ok)
    else
	AC_MSG_RESULT([buggy, using fork instead])
    fi
fi
rm -f core
if test "$tcl_ok" = 0; then
    AC_DEFINE(vfork, fork)
fi])

AC_DEFUN(OASIS_CHK_GETTIMEOFDAY,
[#--------------------------------------------------------------------
#	The code below deals with several issues related to gettimeofday:
#	1. Some systems don't provide a gettimeofday function at all
#	   (set NO_GETTOD if this is the case).
#	2. SGI systems don't use the BSD form of the gettimeofday function,
#	   but they have a BSDgettimeofday function that can be used instead.
#	3. See if gettimeofday is declared in the <sys/time.h> header file.
#	   if not, set the GETTOD_NOT_DECLARED flag so that tclPort.h can
#	   declare it.
#--------------------------------------------------------------------

AC_CHECK_FUNC(BSDgettimeofday, AC_DEFINE(HAVE_BSDGETTIMEOFDAY),
	AC_CHECK_FUNC(gettimeofday, , AC_DEFINE(NO_GETTOD)))
AC_MSG_CHECKING([for gettimeofday declaration])
AC_EGREP_HEADER(gettimeofday, sys/time.h, AC_MSG_RESULT(present), [
    AC_MSG_RESULT(missing)
    AC_DEFINE(GETTOD_NOT_DECLARED)
])])

AC_DEFUN(OASIS_CHK_SIGNED_CHAR,
[#--------------------------------------------------------------------
#	The following code checks to see whether it is possible to get
#	signed chars on this platform.  This is needed in order to
#	properly generate sign-extended ints from character values.
#--------------------------------------------------------------------

AC_C_CHAR_UNSIGNED
AC_MSG_CHECKING([signed char declarations])
AC_TRY_COMPILE(, [
signed char *p;
p = 0;
], tcl_ok=yes, tcl_ok=no)
AC_MSG_RESULT($tcl_ok)
if test $tcl_ok = yes; then
    AC_DEFINE(HAVE_SIGNED_CHAR)
fi])

AC_DEFUN(OASIS_SET_INET_LIB,
[#--------------------------------------------------------------------
#	Interactive UNIX requires -linet instead of -lsocket, plus it
#	needs net/errno.h to define the socket-related error codes.
#--------------------------------------------------------------------

AC_CHECK_LIB(inet, main, [LIBS="$LIBS -linet"])
AC_CHECK_HEADER(net/errno.h, AC_DEFINE(HAVE_NET_ERRNO_H))])


AC_DEFUN(OASIS_SET_SOCKET_LIB,
[#--------------------------------------------------------------------
#	Check for the existence of the -lsocket and -lnsl libraries.
#	The order here is important, so that they end up in the right
#	order in the command line generated by make.  Here are some
#	special considerations:
#	1. Use "connect" and "accept" to check for -lsocket, and
#	   "gethostbyname" to check for -lnsl.
#	2. Use each function name only once:  can't redo a check because
#	   autoconf caches the results of the last check and won't redo it.
#	3. Use -lnsl and -lsocket only if they supply procedures that
#	   aren't already present in the normal libraries.  This is because
#	   IRIX 5.2 has libraries, but they aren't needed and they're
#	   bogus:  they goof up name resolution if used.
#	4. On some SVR4 systems, can't use -lsocket without -lnsl too.
#	   To get around this problem, check for both libraries together
#	   if -lsocket doesn't work by itself.
#--------------------------------------------------------------------
#	On sequent, DYNIX/PTX, where the socket functions (eg. accept())
#	are defined as in-line, AC_CHECK_LIB is not good enough to  
#	determine the right combination of socket library. Instead, a
#	full-fledge AC_TRY_LINK is required.
#--------------------------------------------------------------------

#AC_TRY_RUN([int main() { return( (sizeof(long long) == 8)?0:1 ); }],
#	tk_ok=yes, tk_ok=no, tk_ok=no)


#AC_TRY_LINK([#include <strings.h>], [rindex(0, 0); bzero(0, 0);],
#  [AC_MSG_RESULT(yes)], [AC_MSG_RESULT(no); AC_DEFINE(USG)])

tcl_checkFurther=1
AC_MSG_CHECKING(connect)
AC_TRY_LINK(
	[#include <sys/socket.h>], 
	[connect(0,0,0);],
	[AC_MSG_RESULT(yes); tcl_checkFurther=0],
	[AC_MSG_RESULT(no)]
	)

if test "$tcl_checkFurther" = 1; then
	# Needs more libraries for socket functions.
	# 1st try: -lsocket -lnsl
    tk_oldLibs=$LIBS
    LIBS="$LIBS -lsocket -lnsl"
	AC_MSG_CHECKING(connect in -lsocket -lnsl)
	AC_TRY_LINK(
		[#include <sys/socket.h>], 
		[connect(0,0,0);],
		[AC_MSG_RESULT(yes); tcl_checkFurther=0],
		[AC_MSG_RESULT(no); LIBS=$tk_oldLibs]
		)
fi

if test "$tcl_checkFurther" = 1; then
	# Needs more libraries for socket functions.
	# 2nd try: -lnsl
    tk_oldLibs=$LIBS
    LIBS="$LIBS -lnsl"
	AC_MSG_CHECKING(connect in -lnsl)
	AC_TRY_LINK(
		[#include <sys/socket.h>], 
		[connect(0,0,0);],
		[AC_MSG_RESULT(yes); tcl_checkFurther=0],
		[AC_MSG_RESULT(no); LIBS=$tk_oldLibs]
		)
fi

if test "$tcl_checkFurther" = 1; then
	AC_MSG_ERROR(Fail to determine the socket libraries)
fi

#
#tcl_checkBoth=0
#AC_CHECK_FUNC(connect, tcl_checkSocket=0, tcl_checkSocket=1)
#if test "$tcl_checkSocket" = 1; then
#    AC_CHECK_LIB(socket, main, LIBS="$LIBS -lsocket -lnsl", tcl_checkBoth=1)
#fi
#if test "$tcl_checkBoth" = 1; then
#    tk_oldLibs=$LIBS
#    LIBS="$LIBS -lsocket -lnsl"
#    AC_CHECK_FUNC(accept, tcl_checkNsl=0, [LIBS=$tk_oldLibs])
#fi
#AC_CHECK_FUNC(gethostbyname, , AC_CHECK_LIB(nsl, main, [LIBS="$LIBS -lnsl"]))
#

AC_CHECK_FUNC(gethostname, AC_DEFINE(HAVE_GETHOSTNAME))
AC_SUBST(LIBS)
])

AC_DEFUN(OASIS_SET_DEBUG,
[# Set the default compiler switches based on the --enable-symbols option

AC_ARG_ENABLE(symbols, [  --enable-symbols        build with debugging symbols],
    [tcl_ok=$enableval], [tcl_ok=no])
if test "$tcl_ok" = "yes"; then
    CFLAGS="$CFLAGS -g" 
    CXXFLAGS="$CXXFLAGS -g" 
    JAVAFLAGS="$JAVAFLAGS -g" 
	AC_SUBST(CFLAGS)
	AC_SUBST(CXXFLAGS)
	AC_SUBST(JAVAFLAGS)
fi])

AC_DEFUN(OASIS_SET_DEBUG_IN_EXEC,
[# Set embed debug info into executable

AC_ARG_ENABLE(syminexec, [  --enable-syminexec      build with symbols in executable],
    [tcl_ok=$enableval], [tcl_ok=no])
if test "$tcl_ok" = "yes"; then
	case $target in
	  *-solaris*)
		### The created executable is 2x larger
		### - while performance impact is minimal
		CFLAGS="$CFLAGS -xs" 
		CXXFLAGS="$CXXFLAGS -xs" 
		AC_SUBST(CFLAGS)
		AC_SUBST(CXXFLAGS)
		;;
	esac
fi
])

AC_DEFUN(OASIS_SET_64_BIT_OBJ, [
# Set the default compiler switches based on the --enable-obj64 option

AC_ARG_ENABLE(obj64, [  --enable-obj64        building 64-bit objects],
    [tcl_ok=$enableval], [tcl_ok=no])
#
# Not only --enable-obj64 can trigger 64-bit code build.
# So is -64 in gen_env.
#
if test "$tcl_ok" = "yes" -o x$OBJECT_MODE = x64 ; then
	echo "Building 64-bit objects"
	BUILD_64_BIT_OBJ=yes
else
	echo "Building objects with default bit size"
	BUILD_64_BIT_OBJ=yes
fi
])

AC_DEFUN(OASIS_SET_OPTIMIZE,
[
# Set the default compiler switches based on the --enable-optimize option
# With this flag enabled, compiler is instructed to perform default 
# level of optimization.

AC_ARG_ENABLE(optimize, [  --enable-optimize       build with optimization],
    [tcl_ok=$enableval], [tcl_ok=no])
if test "$tcl_ok" = "yes"; then
    CFLAGS="$CFLAGS -O" 
    CXXFLAGS="$CXXFLAGS -O" 
	AC_SUBST(CFLAGS)
	AC_SUBST(CXXFLAGS)
fi

AC_ARG_WITH(olevel, [  --with-olevel build C++ with specific optimization level],
[O_level=$withval
AC_SUBST(O_level)

CXXFLAGS="$CXXFLAGS -O$O_level"
AC_SUBST(CXXFLAGS)
CFLAGS="$CFLAGS -${OptimizePrefixForC}O$O_level"
AC_SUBST(CFLAGS)

], [unset O_level])

#AC_ARG_WITH(olevelc, [  --with-olevelc build C with specific optimization level],
#[O_level=$withval
AC_SUBST(O_level)
#
#CFLAGS="$CFLAGS -O$O_level"
#AC_SUBST(CFLAGS)
#], [unset O_level])

])

AC_DEFUN(OASIS_SET_ZEROTRACE,
[
# Set the compiler switches based on the --enable-zerotrace option
# With this flag enabled, compiler is instructed to compile-away
# trace statements for maximum performance. 

AC_ARG_ENABLE(zerotrace, [  --enable-zerotrace       build with zero-trace],
    [tcl_ok=$enableval], [tcl_ok=no])
if test "$tcl_ok" = "yes"; then
    CFLAGS="$CFLAGS -DOC_ZEROTRACE" 
    CXXFLAGS="$CXXFLAGS -DOC_ZEROTRACE" 
	AC_SUBST(CFLAGS)
	AC_SUBST(CXXFLAGS)
fi])

AC_DEFUN(OASIS_SET_MINSTATIC,
[
# Set the compiler switches based on the --enable-minstatic option
# With this flag enabled, compiler is instructed to use minimum number
# of static objects. This does not make the modules MT-safe. On the other
# hand, the presence of static objects do implies MT-unsafe.
# Not using static objects always impacts performance.

AC_ARG_ENABLE(minstatic, [  --enable-minstatic       build with minimum-static objects],
    [tcl_ok=$enableval], [tcl_ok=no])
if test "$tcl_ok" = "yes"; then
    CFLAGS="$CFLAGS -DOC_MINSTATIC" 
    CXXFLAGS="$CXXFLAGS -DOC_MINSTATIC" 
	AC_SUBST(CFLAGS)
	AC_SUBST(CXXFLAGS)
fi])

AC_DEFUN(OASIS_SET_CXXFLAGS,
[AC_MSG_CHECKING(platform specific compile-flag adj)
echo Done
# For all platform except pc-cygwin, a futher test will be performed to
# determine if bool is natively defined by the compiler.
case $target in
	*-pc-cygwin*)
	CXXFLAGS="$CXXFLAGS -DBOOL_H -D_BOOL_EXISTS"
	;;
	*-linux*)
	# oc_datetime.cpp in package oc_lib requires strptime()
	# which is only defined when X/Open 5.0 compilance is turned on.
	# POSIX is enabled to define nanosleep(). 

	# It is necessary to define X/Open setting to both C & C++ flags
	# since the result of cfg (ie. HAVE_ULONG) may otherwise be different 
    if test "$BUILD_C11" = yes ; then
        CXXFLAGS="$CXXFLAGS -std=c++11"
    fi

	GCC_VERSION=$(c++ --version | head -1  | cut -d' ' -f3 | cut -d'.' -f1)
	if test "$GCC_VERSION" -ge 8 ; then
		CXXFLAGS="$CXXFLAGS -D_XOPEN_SOURCE=700 -D_POSIX_C_SOURCE=199506L -D_DEFAULT_SOURCE"
		CFLAGS="$CFLAGS -D_XOPEN_SOURCE=700 -D_DEFAULT_SOURCE"
	else
		# -rc- for redhat 7.3
		egrep '_XOPEN_SOURCE.*600' /usr/include/features.h >/dev/null 2>&1
		if test $? = 0 ; then
			CXXFLAGS="$CXXFLAGS -D_XOPEN_SOURCE=600 -D_POSIX_C_SOURCE=199506L -D_BSD_SOURCE"
			CFLAGS="$CFLAGS -D_XOPEN_SOURCE=600 -D_BSD_SOURCE"
		else
			CXXFLAGS="$CXXFLAGS -D_XOPEN_SOURCE=500 -D_POSIX_C_SOURCE=199506L -D_BSD_SOURCE"
			CFLAGS="$CFLAGS -D_XOPEN_SOURCE=500 -D_BSD_SOURCE"
		fi
	fi
	;;
	*-aix*)
	;;
	*-solaris*)
	;;
    ia64*-hpux*)
	CXXFLAGS="$CXXFLAGS -mt"
	;;
	*-hpux*)
	CXXFLAGS="$CXXFLAGS -DOC_HP_ACC"
	;;
	*-osf*)
	# Define _BOOL_EXISTS to always suppress the bool definition in rw-lib
	CXXFLAGS="$CXXFLAGS -D_BOOL_EXISTS"
	;;
    *-ibm-opened*)
	CXXFLAGS="$CXXFLAGS"
	;;
	*-sequent-sysv4)
	CXXFLAGS="$CXXFLAGS -D_BOOL_EXISTS"
	;;
esac
AC_SUBST(CXXFLAGS)])

AC_DEFUN(OASIS_SET_MISC_LIBS,
[AC_MSG_CHECKING(platform specific include/lib setting)
echo Done
CURSES_FLAGS=
MT_CFLAGS=
MT_LDFLAGS=
EH_CXXFLAGS=
case $target in
	*-pc-cygwin*)
		if test "$CC" = "cl"; then
			LIBS="$LIBS -lowinsupp -lws2_32.lib"
			AC_SUBST(LIBS)
			MT_LDFLAGS="$MT_LDFLAGS -lpthread"
		fi
	;;
	*-linux*)
	LIBS="$LIBS -lcrypt -lrt $PATH_STAMP_OBJ_FILE"
	AC_SUBST(LIBS)

	CURSES_LIBS="$CURSES_LIBS -lcurses"
	# The XOPEN_SOURCE=500 is required to turn on __USE_UNIX98
	# which is required to define pthread_mutexattr_settype()
	# _XOPEN_SOURCE is already defined in CFLAGS and CXXFLAGS
	MT_CFLAGS="$MT_CFLAGS -D_REENTRANT"
	MT_LDFLAGS="$MT_LDFLAGS -lpthread"
	;;
	*-aix7.3*)
	LIBS="$LIBS $PATH_STAMP_OBJ_FILE"
	AC_SUBST(LIBS)
	CURSES_LIBS="$CURSES_LIBS -bstatic -lcurses -bdynamic"
	MT_CFLAGS="$MT_CFLAGS  -pthread -D_REENTRANT"
	MT_LDFLAGS="$MT_LDFLAGS  -pthread -lpthread"
	;;
	*-aix*)
	LIBS="$LIBS $PATH_STAMP_OBJ_FILE"
	AC_SUBST(LIBS)
	CURSES_LIBS="$CURSES_LIBS -bstatic -lcurses -bdynamic"
	MT_CFLAGS="$MT_CFLAGS  -qthreaded -D_REENTRANT"
	MT_LDFLAGS="$MT_LDFLAGS  -qthreaded -lpthread"
	;;
	*-solaris*)
	LIBS="$LIBS $PATH_STAMP_OBJ_FILE"
	AC_SUBST(LIBS)
	POSIX_LIBS="$POS_LIBS -lposix4"
	# Different C++ lib depends on different compiler version
	CC -V 2>&1 | fgrep -s 'Compilers 4'
	if test $? = 0 ; then
		CPP_LIBS="$CPP_LIBS -lC"
	elif test x$USE_OS_STL = x1 ; then
		CPP_LIBS="$CPP_LIBS -lCstd -lCrun -lm -lw -lc"
		# CXXFLAGS="$CXXFLAGS -library=iostream"
	else
		CPP_LIBS="$CPP_LIBS -lCstd -lCrun -lm -lw -lc"
		# for C++ 5.1 we are getting rid of their STL and using stlsgi
		CXXFLAGS="$CXXFLAGS -library=no%Cstd -library=iostream"
	fi
	CURSES_LIBS="$CURSES_LIBS -lcurses"
	MT_CFLAGS="$MT_CFLAGS -mt"
	MT_LDFLAGS="$MT_LDFLAGS -mt -lpthread -lrt -lposix4 -R /usr/lib/lwp"
	;;
    ia64*-hpux*)
	CURSES_LIBS="$CURSES_LIBS -lcurses"
	MT_CFLAGS="$MT_CFLAGS -mt -D_POSIX_C_SOURCE=199506L -D_HPUX_SOURCE"
	### LDFLAGS already has "-L/usr/lib/hpux32" specified
	### LIBS already has "-lpthread -lrt" specified
	### No need to specify again in MT_LDFLAGS
	MT_LDFLAGS="$MT_LDFLAGS -mt"
	# -rc-
	# Even for originally binaries, they have to linked in libpthread, otherwise
	# the run-time linker will complain about thread-specific objects.
	LIBS="$LIBS -lpthread -lrt $PATH_STAMP_OBJ_FILE"
	AC_SUBST(LIBS)
	;;
	*-hpux*)
	CURSES_LIBS="$CURSES_LIBS -lcurses"
	CURSES_FLAGS="$CURSES_FLAGS -D_XOPEN_SOURCE_EXTENDED"
	# To be added by cfg_src_pkg.
	# If added there, bot_configure tests that compile on hpux will fail.
	# CFLAGS="$CFLAGS -Dmain=oasis_C_main"
	case $target in
		*-hpux11*)
			# oracle on hpux11 linked in -lpthread and this requires
			# all the main's to also link in -lpthread.
			# Otherwise, the runtime linker will complain "Can't shl_load()
			# a library containing Thread Local Storage: /usr/lib/libpthread.1"
			# and coredump.
			# To be save, we just link in -lpthread to all executables.
			# LIBS="$LIBS -lohighwatermark -lpthread"
			LIBS="$LIBS -lpthread"
			AC_SUBST(LIBS)
		;;
	esac
	MT_CFLAGS="$MT_CFLAGS -mt -D_POSIX_C_SOURCE=199506L -D_HPUX_SOURCE"
	MT_LDFLAGS="$MT_LDFLAGS -mt -lpthread -lrt"
	if test x$USE_OS_STL = x1 ; then
		CXXFLAGS="$CXXFLAGS -AA -mt"
		LDFLAGS="$LDFLAGS -mt"
	fi
	;;
	*-osf*)
	CURSES_LIBS="$CURSES_LIBS -lcurses"
	MT_CFLAGS="$MT_CFLAGS -pthread -D_REENTRANT"
	MT_LDFLAGS="$MT_LDFLAGS -pthread -lpthread -lexc -lrt"
	;;
	*-sequent-sysv4)
	CPP_LIBS="$CPP_LIBS -L/opt/ptxC++/lib/cfront -lec++ -lstd"
	CURSES_LIBS="$CURSES_LIBS -lcurses"
	;;
    *-ibm-opened*)
	CURSES_LIBS="$CURSES_LIBS -lcurses"
	;;
	*)
	CURSES_LIBS="$CURSES_LIBS -lcurses"
	MT_CFLAGS="$MT_CFLAGS -D_REENTRANT"
	MT_LDFLAGS="$MT_LDFLAGS -lpthread"
	;;
esac
AC_SUBST(MT_CFLAGS)
AC_SUBST(MT_LDFLAGS)
AC_SUBST(LDFLAGS)
AC_SUBST(EH_CXXFLAGS)
AC_SUBST(POSIX_LIBS)
AC_SUBST(CPP_LIBS)
AC_SUBST(CURSES_LIBS)
AC_SUBST(CFLAGS)])

AC_DEFUN(OASIS_SET_LIBTOOL_FOR_CL,
[AC_MSG_CHECKING(whether we are using libtool for MSVC)
${CONFIG_SHELL-/bin/sh} $ac_aux_dir/ltconfig_vcpp "$target_cpu" "$target_vendor" "$target_os" "$ac_aux_dir/ltmain_vcpp"
LIBTOOL='$(SHELL) $(top_builddir)/libtool'
echo "yes"
AC_SUBST(LIBTOOL)])

# First, determine JAVA_HOME (non-alpha), populate INCLUDES and
# assign values to JAVALIBS (which can be used in Makefile.am).
# This macro should be used in bot_configure.in since the java include
# directories should be specified after the standard ones.
#
# JNIFLAGS and JNILIBS defines platform specific compile/link options
# that are required for use of Java-Native-Interface.
AC_DEFUN(OASIS_SET_FLAG_FOR_JAVA,
[
JNIFLAGS=
JNILIBS=
INCLUDES="$INCLUDES"' -I$(includedir)/ots'
case $target in
  *-osf*)
	AC_MSG_CHECKING(JAVA_HOME)

	java -version 2>&1 | fgrep version | fgrep -v 'version "1.1' >/dev/null

	if test $? = 0 ; then
		# check JAVA_HOME before use
		if test x"${JAVA_HOME}" = x ; then
			AC_MSG_ERROR(JAVA_HOME directory: ${JAVA_HOME} is not valid)
		fi
		echo "osf style - JAVA_HOME:$JAVA_HOME"
		INCLUDES="$INCLUDES -I$JAVA_HOME/include -I$JAVA_HOME/include/alpha"
		JAVALIBS="-L/usr/shlib -ljava"
	else
		echo "osf style - all over the places"
		INCLUDES="$INCLUDES"' -I/usr/include/java -I/usr/include/java/alpha'
		JAVALIBS="-L/usr/shlib -ljava"
	fi

	AC_SUBST(INCLUDES)
	AC_SUBST(JAVALIBS)

	CFLAGS="$CFLAGS -pthread"
	AC_SUBST(CFLAGS)
	CXXFLAGS="$CXXFLAGS -pthread"
	AC_SUBST(CXXFLAGS)
	LDFLAGS="$LDFLAGS -pthread"
	AC_SUBST(LDFLAGS)
	;;
  *-pc-cygwin*)
	AC_MSG_CHECKING(JAVA_HOME)
	if test x"${JAVA_HOME}" = x -o ! -d "${JAVA_HOME}" ; then
		AC_MSG_ERROR(JAVA_HOME directory: ${JAVA_HOME} is not valid)
	fi
	INCLUDES="$INCLUDES -I$JAVA_HOME/include -I$JAVA_HOME/include/win32"
	AC_SUBST(INCLUDES)
	JAVALIBS="-L$JAVA_HOME/lib javai.lib"
	AC_SUBST(JAVALIBS)
	echo "Win/NT style"
	;;
  *)
	AC_MSG_CHECKING(JAVA_HOME)
	if test -z "$JAVA_HOME" -o ! -d "$JAVA_HOME" ; then
		if test -d /usr/java ; then
			JAVA_HOME=/usr/java		
		elif  test -d /opt/java ; then
			JAVA_HOME=/opt/java
		fi
	fi

	if test -z "$JAVA_HOME" -o ! -d "$JAVA_HOME" ; then
		echo "Unknown !!!"
	else
		echo "$JAVA_HOME"

		FOLLOW="-follow"
		case $target in
		  *-aix*)
			FOLLOW=
			;;
		esac

		JINC1=`find $JAVA_HOME/include $FOLLOW -name jni_md.h -exec dirname {} \;`
		# AIX 6, Java 5: there is no jni_md.h
		if test "x$JINC1" != "x" ; then
			JINC2=`dirname $JINC1`
			INCLUDES="$INCLUDES -I$JINC1 -I$JINC2"
		else
			INCLUDES="$INCLUDES -I$JAVA_HOME/include"
		fi
		AC_SUBST(INCLUDES)

		LIB1=`find $JAVA_HOME/lib $FOLLOW -name "libjava.*" -exec dirname {} \;`
		COUNT=`echo $LIB1|wc -w`
		if test $COUNT -ne 1 ; then
			LIB1=`echo $LIB1|cut -f1|cut -d" "  -f 1`
		fi
		JAVALIBS="-L$LIB1 -ljava"
		AC_SUBST(JAVALIBS)
	fi
	;;
esac

# The following is to modify the linking process of executables (not
# shared libraries) because of linking in libjava.
# Also, platform specific JNI options are assigned here.
case $target in
  *-aix7.3*)
	if test "$BUILD_64_BIT_OBJ" = yes ; then
		CXX="ibm-clang_r -m64 -brtl $VaSpecOpt "
	else
		CXX="ibm-clang_r -brtl $VaSpecOpt "
	fi
	;;
  *-aix*)
	if test "$BUILD_64_BIT_OBJ" = yes ; then
		CXX="xlC_r -qlanglvl=extended0x -q64 -brtl $VaSpecOpt -qfuncsect"
	else
		CXX="xlC_r -brtl $VaSpecOpt -qfuncsect"
	fi
	;;
  *-solaris*)
	# Sun suggests to use flag "-mt" instead of the library list.
	# Note that "libtool" does not accept "-mt" w/o modification.
	# JAVALIBS="$JAVALIBS -lC -lm -lw -lthread -lcx -lc"
	JAVALIBS="$JAVALIBS -mt"
	AC_SUBST(JAVALIBS)
	;;
  *-hpux*)
	JAVALIBS="$JAVALIBS -lpthread"
	AC_SUBST(JAVALIBS)
	JNIFLAGS="$JNIFLAGS +u4 -DNATIVE -D_HPUX"
	JNILIBS="$JNILIBS -lCsup -lstream -lstd"
	;;
  *-ibm-opened*)
	JNIFLAGS="$JNIFLAGS -DNEEDSLONGLONG"
	;;
esac
AC_SUBST(JNIFLAGS)
AC_SUBST(JNILIBS)
])

AC_DEFUN(OASIS_CHK_WIDE_CHARACTER_IN_IOSTREAM,
[AC_MSG_CHECKING(for wide character support in iostream.h)
# This macro will check whether iostream has support for
# wide characters
MY_SAVED_CXXFLAGS=$CXXFLAGS
CXXFLAGS="$CXXFLAGS -I$DEFAULT_PREFIX/include $BASELINE_INCLUDES"
AC_LANG_SAVE
AC_LANG_CPLUSPLUS
AC_TRY_COMPILE([

#if defined(OC_USE_NEW_STL)
#	include <iostream>
#else
#	include <iostream.h>
#endif
#include <wchar.h>
], [
wchar_t wchar;
cin >> wchar;
cin.get( wchar );
],
AC_DEFINE(HAVE_WCHAR_IN_IOSTREAM) echo yes, echo no)
AC_LANG_RESTORE
CXXFLAGS=$MY_SAVED_CXXFLAGS
])

AC_DEFUN(OASIS_CHK_DYNAMIC_CAST,
[AC_MSG_CHECKING(for compiler support for dynamic cast)
# This macro will check the compiler support for RTTI
AC_LANG_SAVE
AC_LANG_CPLUSPLUS
AC_TRY_COMPILE([
class A {
public:
	A() {}
	virtual void foo(void) {}
};

class D: public A {
public:
	D() {}
	virtual void foo(void) {}
};

void
foo(A* pA) 
{
  D* pd = dynamic_cast<D*> (pA);
};
], [

],
AC_DEFINE(USE_DYNAMIC_CAST) echo yes, echo no)
AC_LANG_RESTORE
])

AC_DEFUN(OASIS_DETERMINE_CMD_CPP,
[AC_MSG_CHECKING(C preprocessor)
CMD_CPP=
case $target in
  *-pc-cygwin*)
#	CMD_CPP=`type g++`
#	if test $? = 0 ; then
#		CMD_CPP='/'`echo $CMD_CPP | cut -d '/' -f2-`
#	else
		CMD_CPP=
		CMD_CPP2=
#	fi
	;;
  *)
	CMD_CPP=`type cpp 2>/dev/null`
	RES_FOUND_CPP=$?
	echo $CMD_CPP | fgrep 'not found' >/dev/null
	if test $RES_FOUND_CPP = 0 -a $? != 0 ; then
		CMD_CPP='/'`echo $CMD_CPP | cut -d '/' -f2-`
		CMD_CPP2=$CMD_CPP
	else
		if test -f /usr/lib/cpp ; then
			CMD_CPP=/usr/lib/cpp
			CMD_CPP2=$CMD_CPP
		elif test -f /usr/ccs/lbin/cpp ; then
			CMD_CPP=/usr/ccs/lbin/cpp
			CMD_CPP2=$CMD_CPP
		elif test -f /usr/lib/cpp ; then
			CMD_CPP=/usr/lib/cpp
			CMD_CPP2=$CMD_CPP
		elif test -f /usr/ccs/lib/cpp ; then
			CMD_CPP=/usr/ccs/lib/cpp
			CMD_CPP2=$CMD_CPP
		elif test "$CC" = "gcc"; then
			# Have to use cpp, gcc -E doesn't work on unexpected suffix
			CMD_CPP=cpp
			CMD_CPP2=$CMD_CPP
		else
			CMD_CPP='$(CC)'
			CMD_CPP2='$(CC) -E'
		fi
	fi
	;;
esac
if test x"$CMD_CPP" = x ; then
	echo "Unable to locate"
else
	echo "$CMD_CPP"
fi
AC_SUBST(CMD_CPP)
AC_SUBST(CMD_CPP2)
])

AC_DEFUN(OASIS_DETERMINE_TEST_SHELL,
[TESTS_ENVIRONMENT='sh'
AC_SUBST(TESTS_ENVIRONMENT)])

#
# Read:
#	$ORACLE_HOME
# Modify:
#	$DBM_EXTRALIBS
#	$CFLAGS
#	$CXXFLAGS
#	$INCLUDES
#
AC_DEFUN(OASIS_SET_ORACLE_ENV,
[if test x${ORACLE_HOME} = x ; then 
	AC_MSG_ERROR(must set ORACLE_HOME)
fi

if test ! -d ${ORACLE_HOME} ; then
	AC_MSG_ERROR(Oracle directory: ${ORACLE_HOME} is not valid)
fi

echo oracle is in $ORACLE_HOME

	# removed support for cygwin to simply structure

	# Locate sample makefile and determine the dependent-library symbol
	MK_FILE=
	MK_SYMBOL=

	# Oracle 12c or before have rdbms/demo
    if test x$MK_FILE = x ; then
        if test "$BUILD_64_BIT_OBJ" = yes ; then
            MK_FILE=`find $ORACLE_HOME/rdbms/demo -name 'demo_rdbms64.mk' 2>/dev/null`
        else
            MK_FILE=`find $ORACLE_HOME/rdbms/demo -name 'demo_rdbms32.mk' 2>/dev/null`
        fi
    fi

	# Oracle 19c does not have rdbms/demo
    # - look for alternative
    if test x$MK_FILE = x ; then
        MK_FILE=`find $ORACLE_HOME/rdbms -name 'env_rdbms.mk' 2>/dev/null`
        MK_SYMBOL="ORALIBPATH"
    fi

	if test x$MK_FILE = x ; then 
		MK_FILE=`find $ORACLE_HOME/rdbms/demo -name 'demo_rdbms.mk' 2>/dev/null`
	else
		DONT_ADD_TO_DBMLIB=yes
	fi

	if test x$MK_FILE = x ; then 
		MK_FILE=`find $ORACLE_HOME/rdbms/demo -name 'oracle.mk'`
	fi

	if test x$MK_FILE = x ; then 
		MK_FILE=`find $ORACLE_HOME/rdbms/lib -name 'oracle.mk'`
	fi

	if test x$MK_FILE != x ; then 
		echo "Use Sample Makefile [$MK_FILE]" 
		TMP_FILE="mkoracle.$$"
		trap "rm -f $TMP_FILE" 1 2 15
		#
		# We use OCISHAREDLIBS for all platforms except PTX
		# On PTX, OCISTATICLIBS is used instead. 
		# If OCISHAREDLIBS is used on PTX, fullpathname libraries 
		# (instead of -l*) is generated and choke libtool.
		#
		case $target in
		  *-sequent-sysv4)
			MK_SYMBOL="OCISTATICLIBS"
			test -f ${ORACLE_HOME}/lib/libclntsh.so \
				&& DBM_EXTRALIBS="$DBM_EXTRALIBS -L${ORACLE_HOME}/lib -lclntsh"
			;;
		  *)
			MK_SYMBOL="OCISHAREDLIBS"
			;;
		esac

		if test "$BUILD_64_BIT_OBJ" = yes ; then

		###
		### 64-bit
		###
		cat >$TMP_FILE <<END_OF_FILE
include $MK_FILE

ifdef ORALIBPATH64
  ifdef OCISHAREDLIBS64
    DBM_L = \$(ORALIBPATH64) \$(OCISHAREDLIBS64)
  else
    DBM_L = \$(ORALIBPATH64) \$(OCISHAREDLIBS)
  endif
else
  ifdef $MK_SYMBOL
    DBM_L = -L$ORACLE_HOME/lib \$($MK_SYMBOL)
  else
    ifdef OCILDLIBS
      DBM_L = \$(OCILDLIBS)
    else
      DBM_L = 
    endif
  endif
endif

displib: FORCE
	@echo \$(DBM_L)
include: FORCE
	@echo \$(INCLUDE)

FORCE:
END_OF_FILE

		else
		###
		### 32-bit
		###
		cat >$TMP_FILE <<END_OF_FILE
include $MK_FILE

ifdef ORALIBPATH32
  ifdef OCISHAREDLIBS32
    DBM_L = \$(ORALIBPATH32) \$(OCISHAREDLIBS32)
  else
    DBM_L = \$(ORALIBPATH32) \$(OCISHAREDLIBS)
  endif
else
  ifdef $MK_SYMBOL
    DBM_L = -L$ORACLE_HOME/lib32 \$($MK_SYMBOL)
  else
    ifdef OCILDLIBS
      DBM_L = \$(OCILDLIBS)
    else
      DBM_L = 
    endif
  endif
endif

displib: FORCE
	@echo \$(DBM_L)
include: FORCE
	@echo \$(INCLUDE)

FORCE:
END_OF_FILE

		fi

		dbm_libs=`make -f $TMP_FILE displib`

        if ! test -f /usr/lib/libnsl.so ; then
            dbm_libs2="$dbm_libs"
            dbm_libs=`echo $dbm_libs2 | sed 's/-lnsl//'`
        fi
	fi

	if test x$MK_FILE = x -o "x$dbm_libs" = "x" ; then 
		#
		# Fail to determine the lib info
		#
		if test -d ${ORACLE_HOME}/sdk/include ; then
			# Treat it as instant-client
			echo "This is an Oracle Instant-Client setup"
			dbm_libs="-L${ORACLE_HOME} -lclntsh"
			DBM_INCLUDES="-I${ORACLE_HOME}/sdk/include"
			INCLUDES="$INCLUDES $DBM_INCLUDES"
		else
			# Apply default
			echo "Unable to locate either Sample Makefile or Library Dependency, defaulting library list"
			dbm_libs="-L${ORACLE_HOME}/lib -lclntsh"
		fi

	else
		if test x$DONT_ADD_TO_DBMLIB != xyes ; then
			dbm_libs="-L${ORACLE_HOME}/lib $dbm_libs -lclntsh"
		fi
		DBM_INCLUDES=`make -f $TMP_FILE include`
		INCLUDES="$INCLUDES $DBM_INCLUDES"
	fi

	case $target in 
	*-solaris*)
		DBM_EXTRALIBS="$DBM_EXTRALIBS `echo $dbm_libs | sed 's/-lthread//'`"
		;;
	*)
		DBM_EXTRALIBS="$DBM_EXTRALIBS $dbm_libs"
		;;
	esac

	### Added -L ..., if -L is not present in the lib string
	DBM_EXTRALIBS=`echo $DBM_EXTRALIBS`
	DBM_EXTRALIBS2=`echo $DBM_EXTRALIBS | sed 's/-L//'`
	if test "$DBM_EXTRALIBS2" = "$DBM_EXTRALIBS" ; then
		DBM_EXTRALIBS="-L${ORACLE_HOME}/lib $DBM_EXTRALIBS"
	fi

	rm -f $TMP_FILE

	echo "Use DB Link options [$DBM_EXTRALIBS]"
	echo "Use DB include options [$DBM_INCLUDES]"

  	CFLAGS="$CFLAGS -DORACLE"
  	CXXFLAGS="$CXXFLAGS -DORACLE"

  	INCLUDES="$INCLUDES -I${ORACLE_HOME}/rdbms/public -I${ORACLE_HOME}/precomp/public -I${ORACLE_HOME}/rdbms/demo -I${ORACLE_HOME}/precomp/admin"
  	AC_SUBST(DBM_EXTRALIBS)
])


#
# Read:
#	$INFORMIXDIR
# Modify:
#	$DBM_EXTRALIBS
#	$CFLAGS
#	$CXXFLAGS
#	$INCLUDES
#
AC_DEFUN(OASIS_SET_INFORMIX_ENV,
[	if test x${INFORMIXDIR} = x ; then 
		AC_MSG_ERROR(must set INFORMIXDIR)
	fi

	echo informix is in $INFORMIXDIR

	informixlibs=`${INFORMIXDIR}/bin/esql -libs | xargs echo`
	newinformixlibs=
	withcheckapi=false
	for lib in ${informixlibs} ; do
		case ${lib} in
		-l*)
		  newinformixlibs="${newinformixlibs} ${lib}"
		  ;;
		/*.a)
		  lib=`echo $lib | sed -e "s%^.*/%%" -e "s/lib/-l/" -e "s/\.a//"`
		  newinformixlibs="${newinformixlibs} ${lib}"
		  ;;
		/*.so)
		  lib=`echo $lib | sed -e "s%^.*/%%" -e "s/lib/-l/" -e "s/\.so//"`
		  newinformixlibs="${newinformixlibs} ${lib}"
		  ;;
		/*.sl)
		  lib=`echo $lib | sed -e "s%^.*/%%" -e "s/lib/-l/" -e "s/\.sl//"`
		  newinformixlibs="${newinformixlibs} ${lib}"
		  ;;
		*)
		  ;;
		esac
	done 

	DBM_EXTRALIBS="$DBM_EXTRALIBS -L${INFORMIXDIR}/lib -L${INFORMIXDIR}/lib/esql ${newinformixlibs} ../tmplinkdir/checkapi.lo"
	AC_SUBST(DBM_EXTRALIBS)
	echo "DBM_EXTRALIBS = $DBM_EXTRALIBS"

	if test -d tmplinkdir ; then 
		rm -rf tmplinkdir
		mkdir tmplinkdir
	else
		mkdir tmplinkdir
	fi 

	ln -s ${INFORMIXDIR}/lib/esql/checkapi.o tmplinkdir/checkapi.lo
 
	CFLAGS="$CFLAGS -DINFORMIX"
	CXXFLAGS="$CXXFLAGS -DINFORMIX"
	INCLUDES="$INCLUDES -Dloc_t=informix_loc_t -I${INFORMIXDIR}/incl/esql"
])

#
# Read:
#	$ORACLE_HOME
# Modify:
#	$DBM_EXTRALIBS
#	$CFLAGS
#	$CXXFLAGS
#	$INCLUDES
#
AC_DEFUN(OASIS_SET_ORACLE_PROC_ENV,
[if test x${ORACLE_HOME} = x ; then 
	AC_MSG_ERROR(must set ORACLE_HOME)
fi

if test ! -d ${ORACLE_HOME} ; then
	AC_MSG_ERROR(Oracle directory: ${ORACLE_HOME} is not valid)
fi

echo oracle is in $ORACLE_HOME

case $target in
  *-pc-cygwin*)

	#
	# We have no support of proc on window yet.
	#
	DBM_EXTRALIBS="$DBM_EXTRALIBS -L${ORACLE_HOME}/OCI80/LIB/MSVC -lOCI.LIB"
	echo "Use DB Link options [$DBM_EXTRALIBS]"
	AC_SUBST(DBM_EXTRALIBS)

	CFLAGS="$CFLAGS -DORACLE"
	CXXFLAGS="$CXXFLAGS -DORACLE"
	INCLUDES="$INCLUDES -I${ORACLE_HOME}/OCI80/INCLUDE"
	;;
  *)
	# Locate sample makefile and determine the dependent-library symbol
	MK_FILE=
	MK_SYMBOL=

	# File location based on 8.0.5, 8.0.6
	MK_FILE=`find $ORACLE_HOME/precomp/lib -name 'env_precomp.mk' 2>/dev/null`

	if test x$MK_FILE != x ; then 
		# for 8.0.5
		fgrep PROLDLIBS $MK_FILE >/dev/null 2>&1
		if test $? = 0 ; then
			MK_SYMBOL="PROLDLIBS"
		fi

		# for 8.0.6
		if test x$MK_SYMBOL = x ; then
			fgrep CPPLDLIBS $MK_FILE >/dev/null 2>&1
			if test $? = 0 ; then
				MK_SYMBOL="CPPLDLIBS"
			fi
		fi
	fi

	echo "Use Sample Makefile [$MK_FILE] Symbol [$MK_SYMBOL]" 
	TMP_FILE="env_precomp.$$"
	trap "rm -f $TMP_FILE" 1 2 15
	# Insert -lclntsh before DBLIB since 8.1.6 no longer include libclntsh 
	cat >$TMP_FILE <<END_OF_FILE
include $MK_FILE
DBLIB = -L$ORACLE_HOME/lib32 -L$ORACLE_HOME/lib \$($MK_SYMBOL)

displib:
	@echo -L$ORACLE_HOME/lib32 -L$ORACLE_HOME/lib -lclntsh \$(DBLIB)
END_OF_FILE

	DBM_EXTRALIBS="$DBM_EXTRALIBS `make -f $TMP_FILE displib`"

	rm -f $TMP_FILE

	# -rc-
	# Have to remove the -lm, since their appearance before -lieee will
	# cause problem on linux
	DBM_EXTRALIBS=`echo $DBM_EXTRALIBS | sed -e 's/ -lm / /g' -e 's/ -lm$/ /'`

	echo "Use DB Link options [$DBM_EXTRALIBS]"

  	CFLAGS="$CFLAGS -DORACLE"
  	CXXFLAGS="$CXXFLAGS -DORACLE"

  	INCLUDES="$INCLUDES -I${ORACLE_HOME}/precomp/public -I${ORACLE_HOME}/rdbms/demo -I${ORACLE_HOME}/precomp/admin"
  	AC_SUBST(DBM_EXTRALIBS)
	;;
esac])

AC_DEFUN(OASIS_SET_BASELINE,
[AC_ARG_WITH(baseline,
[  --with-baseline=DIR  Use the baseline binary release in DIR],
[baseline=$withval

if test x"$baseline" = x -a x"$DEFAULT_BASELINEDIR" != x ; then
	echo "Use default Baseline in [$DEFAULT_BASELINEDIR]"
	baseline=$DEFAULT_BASELINEDIR
fi

BASELINE_INCLUDES=

echo "Use Baseline(s) in [$baseline]"

for DIR in `echo $baseline | sed 's/:/ /g'` ; do

	if test ! -d "$DIR" ; then
		echo "ERROR: Invalid baseline directory $DIR"
		AC_MSG_ERROR(must specify valid directory for baseline)
	fi

	INCLUDES="$INCLUDES -I$DIR/include"
	LDFLAGS="$LDFLAGS -L$DIR/lib"

	BASELINE_INCLUDES="$BASELINE_INCLUDES -I$DIR/include"
done

# if LDF_PUSH_BACK is not empty (contains "-L/usr/lib/hpux32")
# then move its occurance in LDFLAGS to the back
if test X$LDF_PUSH_BACK != X; then
	LDFLAGS=`echo $LDFLAGS | sed "s#$LDF_PUSH_BACK##g"`
	LDFLAGS="$LDFLAGS $LDF_PUSH_BACK"
fi

AC_SUBST(INCLUDES)
AC_SUBST(LDFLAGS)
AC_SUBST(BASELINE_INCLUDES)

],[])
])

AC_DEFUN(OASIS_CHK_ARRAY_IOB,
[ # Linux does not seem to has this array _iob or __iob

AC_MSG_CHECKING(for array _iob or __iob)
AC_LANG_SAVE
AC_LANG_CPLUSPLUS
AC_TRY_COMPILE([
#include <stdio.h>
#if defined(OC_USE_NEW_STL)
#	include <fstream>
using std::filebuf;
#else
#	include <fstream.h>
#endif
], [
	/* Just don't run */
	filebuf* aFileBuf = (filebuf*)0;
	int aFd = aFileBuf->fd();

	FILE* aVal ;
# ifdef __STDC__
	aVal = &__iob[aFd] ;
# else
	aVal = &_iob[aFd] ;
# endif
],
AC_DEFINE(HAVE_ARRAY_IOB) echo yes, echo no)
AC_LANG_RESTORE
])

AC_DEFUN(OASIS_CHK_SIGUSR1_SA_RESTART,
[# Check if the SA_RESTART bit for SIGUSR1 is ON by default.

AC_MSG_CHECKING([SA_RESTART bit for SIGUSR1 is ON by default])
AC_TRY_RUN([
#include <stdlib.h>
#include <signal.h>

main()
{
	struct sigaction oact;
	signal( SIGUSR1, SIG_DFL );
	sigaction( SIGUSR1, (struct sigaction *)NULL, &oact);
	if( oact.sa_flags & SA_RESTART )
	{	return 0;	}
    return 1;
}], tk_ok=yes, tk_ok=no )
if test $tk_ok = yes; then
    AC_DEFINE(HAVE_SIGUSR1_SA_RESTART)
fi
AC_MSG_RESULT($tk_ok)])

AC_DEFUN(OASIS_SET_LIBTOOL_FOR_OS390,
[AC_MSG_CHECKING(whether we are using GNU libtool for OS390)
sh $ac_aux_dir/ltconfig_os390 "$target_cpu" "$target_vendor" "$target_os" "$ac_aux_dir/ltmain_os390"
LIBTOOL='$(SHELL) $(top_builddir)/libtool'
echo "yes"
AC_SUBST(LIBTOOL)])

AC_DEFUN(OASIS_CHK_FN_STRICMP,
[AC_CHECK_FUNC(stricmp, AC_DEFINE(HAVE_STRICMP))])

AC_DEFUN(OASIS_CHK_FN_STRNICMP,
[AC_CHECK_FUNC(strnicmp, AC_DEFINE(HAVE_STRNICMP))])

AC_DEFUN(OASIS_CHK_FN_MEMMOVE,
[AC_CHECK_FUNC(memmove, AC_DEFINE(HAVE_MEMMOVE))])

AC_DEFUN(OASIS_CHK_HIRES_TIMER,
[# Different platform provides diff hi-res (msec or higher) timer function

# Need C++ to ensure function do exist in header file
AC_LANG_SAVE
AC_LANG_CPLUSPLUS

AC_MSG_CHECKING(for function getclock)
AC_TRY_COMPILE([
#include <time.h>
#include <sys/timers.h>
], [
	struct timespec	ts ;
	getclock( CLOCK_REALTIME, &ts );
], tk_ok=getclock, tk_ok=no )

if test $tk_ok = getclock; then
	AC_DEFINE(USE_GETCLOCK)
	echo yes
else

echo no

# case $target in
# 	*-linux*)
# 		# don't use clock_gettime() on linux
# 		tk_ok=no
# 		;;
# 	*)

AC_MSG_CHECKING(for function clock_gettime)
AC_TRY_COMPILE([#include <time.h>], [
	struct timespec	ts ;
	clock_gettime( CLOCK_REALTIME, &ts );
], tk_ok=clock_gettime, tk_ok=no )
#		;;
# esac

if test $tk_ok = clock_gettime; then
	AC_DEFINE(USE_CLOCK_GETTIME)
	echo yes
else

echo no
AC_MSG_CHECKING(for function timer_gettime)
AC_TRY_COMPILE([ #include <timer.h>], [
	struct timespec	ts ;
	timer_gettime( CLOCK_REALTIME, &ts );
], tk_ok=timer_gettime, tk_ok=no )

if test $tk_ok = timer_gettime; then
	AC_DEFINE(USE_TIMER_GETTIME)
	echo yes
else

echo no
AC_MSG_CHECKING(for function ftime)
AC_TRY_COMPILE([ #include <sys/timeb.h>], [
	struct timeb	ts ;
	ftime( &ts ) ;
], tk_ok=ftime, tk_ok=no )


if test $tk_ok = ftime; then
	AC_DEFINE(USE_FTIME)
	echo yes
else
	echo no
	AC_MSG_ERROR(run out of possibility for hi-res timer)
fi

fi
fi
fi

AC_LANG_RESTORE
])

AC_DEFUN(OASIS_CHK_HIRES_TIMER_RES,
[
AC_MSG_CHECKING(for hi-res timer resolution)

#case $target in
#	*-linux*)
#		echo no
#		;;
#
#	*)
AC_LANG_SAVE
AC_LANG_CPLUSPLUS
AC_TRY_COMPILE([#include <time.h>], [
	struct timespec	ts ;
	clock_getres( CLOCK_REALTIME, &ts ) ;
], AC_DEFINE(USE_CLOCK_GETRES) echo clock_getres, echo no)
AC_LANG_RESTORE
#		;;
#esac

])

AC_DEFUN(OASIS_CHK_64BIT_LONG,
[
AC_MSG_CHECKING(if long is 64-bit)
AC_TRY_RUN([int main() { return( (sizeof(long) == 8)?0:1 ); }],
	tk_ok=yes, tk_ok=no, tk_ok=no )

if test $tk_ok = yes; then
	echo yes
	AC_DEFINE(HAVE_64BIT_LONG) 
else

echo no

AC_MSG_CHECKING(if long long is 64-bit)
AC_LANG_SAVE
AC_LANG_CPLUSPLUS
AC_TRY_RUN([int main() { return( (sizeof(long long) == 8)?0:1 ); }],
	tk_ok=yes, tk_ok=no, tk_ok=no)
AC_LANG_RESTORE

if test $tk_ok = yes; then
	echo yes
	AC_DEFINE(HAVE_64BIT_LONG_LONG) 
else

echo no

fi
fi
])

AC_DEFUN(OASIS_CHK_ULONG,[
AC_MSG_CHECKING(if ulong is defined)
AC_TRY_COMPILE([
#include <sys/types.h>
#include <stdlib.h>
#include <stddef.h>],[ulong aVal = 0;],
AC_DEFINE(HAVE_ULONG) echo yes, echo no )
])

AC_DEFUN(OASIS_CHK_STDOUT_IS_STATIC_CONSTANT,[
AC_MSG_CHECKING(if stdout is static constant)
AC_TRY_COMPILE([#include <stdio.h>
FILE* sVal = stdout ;],[return(0);],
AC_DEFINE(HAVE_STATIC_CONST_STDOUT) echo yes, echo no )
])

AC_DEFUN(OASIS_CHK_MSG_CBYTES,[
AC_MSG_CHECKING(if struct msqid_ds has member msg_cbytes)
AC_TRY_COMPILE([#include <sys/msg.h>],[
struct msqid_ds mds ;
mds.msg_cbytes = 0 ;
],
AC_DEFINE(HAVE_MSG_CBYTES) echo yes, echo no )
])

AC_DEFUN(OASIS_CHK_HIRES_SLEEP,
[# Different platform provides diff hi-res sleep function

# Need C++ to ensure function exist in header
AC_LANG_SAVE
AC_LANG_CPLUSPLUS
NANOSLEEP_LIBS=
case $target in
  *-aix*)
	# The nanosleep() on AIX is non functional.
	tk_ok=no
	;;
  *)
	AC_MSG_CHECKING(if function nanosleep available)
	AC_TRY_COMPILE([#include <time.h>],[
	struct  timespec ts ;
	nanosleep( &ts, NULL ) ;
	], tk_ok=nanosleep, tk_ok=no )
	;;
esac

if test $tk_ok = nanosleep; then
	AC_DEFINE(USE_NANOSLEEP)
	echo yes
	case $target in
	  *-osf*)
		NANOSLEEP_LIBS="$NANOSLEEP_LIBS -lrt"
		;;
	esac
else

echo no

AC_MSG_CHECKING(if function usleep available)
AC_TRY_COMPILE([#include <unistd.h>],[
usleep( 0 ) ;
], tk_ok=usleep, tk_ok=no )

if test $tk_ok = usleep; then
	AC_DEFINE(USE_USLEEP)
	echo yes
else

echo no

AC_MSG_CHECKING(if function setitimer available)
AC_TRY_COMPILE([#include <sys/timer.h>],[
struct  itimerval ts ;
ts.it_value.tv_usec = ts.it_value.tv_sec = 0 ;
setitimer( ITIMER_REAL, &ts, NULL ) ;
], tk_ok=setitimer, tk_ok=no )

if test $tk_ok = setitimer; then
	AC_DEFINE(USE_SETITIMER)
	echo yes
else
	echo no

fi
fi
fi

AC_SUBST(NANOSLEEP_LIBS)
AC_LANG_RESTORE
])

AC_DEFUN(OASIS_CHK_TERMIO_IN_CURSES_H,[
AC_MSG_CHECKING(which struct termio come with in curses.h)

AC_TRY_COMPILE([#include <curses.h>],[
struct termio aVal ;
], tk_ok=termio, tk_ok=no )

if test $tk_ok = termio; then
	AC_DEFINE(HAVE_TERMIO_IN_CURSES_H)
    AC_DEFINE(USE_TERMIO)
	echo termio
else

AC_TRY_COMPILE([#include <curses.h>],[
struct termios aVal ;
], tk_ok=termios, tk_ok=no )

if test $tk_ok = termios; then
	AC_DEFINE(HAVE_TERMIOS_IN_CURSES_H)
    AC_DEFINE(USE_TERMIOS)
	echo termios
else
	echo none
fi

fi
])

AC_DEFUN(OASIS_CHK_MSGHDR_ACCRIGHTS,[
AC_MSG_CHECKING(if struct msghdr has member msg_accright)
AC_TRY_COMPILE([
#include <sys/types.h>
#include <sys/socket.h>
],[
struct msghdr mh ;
mh.msg_accrights = (caddr_t) 0 ;
],
AC_DEFINE(HAVE_accrights_IN_msghdr) echo yes, echo no )
])

#
# Read:
#	$SYBASE
# Modify:
#	$DBM_EXTRALIBS
#	$CFLAGS
#	$CXXFLAGS
#	$INCLUDES
#
AC_DEFUN(OASIS_SET_SYBASE_ENV,
[AC_MSG_CHECKING(for SYBASE directory)
if test x${SYBASE} = x ; then 
	AC_MSG_ERROR(must set SYBASE)
fi

if test ! -d ${SYBASE} ; then
	AC_MSG_ERROR(Sybase directory: ${SYBASE} is not valid)
fi
AC_MSG_RESULT(found)

echo sybase is in $SYBASE

case $target in
  *-aix*)		SYBPLATFORM=rs6000		;;
  *-hpux*)		SYBPLATFORM=hpux		;;
  *-osf*)		SYBPLATFORM=axposf		;;
  *-solaris*)	SYBPLATFORM=sun_svr4	;;
  *-pc-cygwin*) SYBPLATFORM=win32		;;	
  *-linux*)		SYBPLATFORM=linux		;;
  *)			SYBPLATFORM=unknown		;;
esac
export SYBPLATFORM

case $target in
  *-pc-cygwin*)
	AC_MSG_CHECKING(whether SYBASE.bat exists)
	if test -x $SYBASE/SYBASE.bat ; then
	 	AC_MSG_RESULT(yes)
		if test x$SYBASE_OCS = x ; then
			echo '----------------------------------------------------------------'
			echo 'Remember to run $SYBASE/SYBASE.bat for your runtime environment!'
			echo '----------------------------------------------------------------'
		else
			AC_MSG_RESULT(SYBASE_OCS already set, skipping SYBASE.bat)
		fi
	else
		AC_MSG_RESULT(no)
	fi

	if test x$SYBASE_OCS != x -a -d $(cygpath -u $SYBASE)/$SYBASE_OCS ; then
		SYBASE_HOME=$(cygpath -u $SYBASE)/$SYBASE_OCS
	else
		SYBASE_HOME=$(cygpath -u $SYBASE)
	fi

	DBM_EXTRALIBS="$DBM_EXTRALIBS -L$(cygpath -u $SYBASE_HOME)/lib -lct -lcs kernel32.lib advapi32.lib"

	echo "Use DB Link options $DBM_EXTRALIBS"

	CFLAGS="$CFLAGS -DSYBASE"
	CXXFLAGS="$CXXFLAGS -DSYBASE"
	INCLUDES="$INCLUDES -I${SYBASE_HOME}/include"
	;;

  *)
	AC_MSG_CHECKING(whether SYBASE.sh exists)
	if test -r $SYBASE/SYBASE.sh ; then
		AC_MSG_RESULT(yes)

		#
		# Don't skip sourcing the shell script when it has been run before
		#
		echo "sourcing SYBASE.sh"
		. $SYBASE/SYBASE.sh
		echo '------------------------------------------------------------------'
		echo 'Remember to source $SYBASE/SYBASE.sh for your runtime environment!'
		echo '------------------------------------------------------------------'
	else
		AC_MSG_RESULT(no)
	fi
	if test x$SYBASE_OCS != x -a -d $SYBASE/$SYBASE_OCS ; then
		SYBASE_HOME=$SYBASE/$SYBASE_OCS
	else
		SYBASE_HOME=$SYBASE
	fi

	# Locate sample makefile and determine the dependent-library symbol
	MK_DIR=$SYBASE_HOME/sample/ctlibrary
	MK_FILE=$SYBASE_HOME/sample/ctlibrary/Makefile

	if test ! -r $MK_FILE ; then 
		# Fail to determine the lib info, use the default
		echo "Unable to locate either Sample Makefile or Library Dependency"
		DBM_EXTRALIBS="$DBM_EXTRALIBS -L${SYBASE_HOME}/lib -lct -lcs -ltcl -lcomn -lintl"
	else
		echo "Use Sample Makefile [$MK_FILE]" 
		TMP_FILE="/tmp/mksybase.$$"
		trap "rm -f $TMP_FILE" 1 2 15
		cat >$TMP_FILE <<END_OF_FILE
include $MK_FILE
DBLIB = -L$SYBASE_HOME/lib \$(CTLIBS) \$(SYSLIBS)

displib:
	@echo \$(DBLIB)
END_OF_FILE

		DBM_EXTRALIBS="$DBM_EXTRALIBS `cd $MK_DIR; make -f $TMP_FILE displib`"
		rm -f $TMP_FILE
	fi	

	echo "Use DB Link options [$DBM_EXTRALIBS]"

  	CFLAGS="$CFLAGS -DSYBASE"
  	CXXFLAGS="$CXXFLAGS -DSYBASE"

  	INCLUDES="$INCLUDES -I${SYBASE_HOME}/include"
  	AC_SUBST(DBM_EXTRALIBS)
	;;
esac])

AC_DEFUN(OASIS_CHK_MUTABLE,
[AC_MSG_CHECKING(for mutable keyword use)
#This macro will check whether the compiler support mutable
AC_LANG_SAVE
AC_LANG_CPLUSPLUS
AC_TRY_COMPILE([
class A {
	mutable int a;
};
],[

],
AC_DEFINE(USE_MUTABLE) echo yes, echo no)
AC_LANG_RESTORE
])

AC_DEFUN(OASIS_CHK_EBCDIC_ENV,
[#--------------------------------------------------------------------
#	While most machines run in ascii natively, some (eg. s390) speak
#	ebcdic. A different set of source files is usually used for these
#	ebcdic machines.
#--------------------------------------------------------------------

AC_MSG_CHECKING(for ascii or ebcdic)
AC_TRY_RUN([
int main()
{
    return( ('A' != 0x41) ? 0 : 1);
}
], tcl_ok=yes, tcl_ok=no, tcl_ok=no)
if test $tcl_ok = yes; then
    AC_MSG_RESULT(ebcdic)
    AC_DEFINE(USE_EBCDIC) 
else
    AC_MSG_RESULT(ascii)
fi
AM_CONDITIONAL(XEBCDIC, test "${tcl_ok}" = yes)
])

AC_DEFUN(OASIS_CHK_ISLEAP,[
AC_MSG_CHECKING(if tzfile defines isleap)
AC_TRY_COMPILE([
#include <tzfile.h>
],[
int a = isleap(0) ;
],
AC_DEFINE(HAVE_ISLEAP_IN_TZFILE_H) echo yes, echo no )
])

AC_DEFUN(OASIS_CHK_STRERROR,[
AC_MSG_CHECKING(if strerror is defined)
AC_LANG_CPLUSPLUS
AC_TRY_COMPILE([
#include <string.h>
],[
char* a = strerror(0) ;
],
AC_DEFINE(HAVE_STRERROR) echo yes, echo no )
AC_LANG_RESTORE
])

AC_DEFUN(OASIS_CHK_BOOL,
[AC_MSG_CHECKING(for existence of bool type in compiler)
# This macro will check whether compiler defines bool natively
AC_LANG_SAVE
AC_LANG_CPLUSPLUS
AC_TRY_COMPILE([
bool myBoolValue = true ;
], ,
tk_ok=yes, tk_ok=no )
# Define BOOL_H to suppress the bool definition defined by STL
# Define OC_NO_BOOL to trigger the inclusion of bool.h
if test $tk_ok = yes ; then
	AC_MSG_RESULT(yes)
	CXXFLAGS="$CXXFLAGS -DBOOL_H"
else
	AC_MSG_RESULT(no)
	CXXFLAGS="$CXXFLAGS -DOC_NO_BOOL"
fi
echo "CXXFLAGS: $CXXFLAGS"
AC_SUBST(CXXFLAGS)
AC_LANG_RESTORE
])

AC_DEFUN(OASIS_CHK_X_CLS_TMPL_INSTANTIATION,
[AC_MSG_CHECKING(for explicit class template instantiation)
# This macro will check whether explicit class template 
# instantiation is possible
AC_LANG_SAVE
AC_LANG_CPLUSPLUS
AC_TRY_COMPILE([
template <class T>
class A
{
	T mVal ;
	A( T aVal ) : mVal( aVal ) {;}
};

template class A<int> ;
], [
],
AC_DEFINE(HAVE_X_CLS_TMPL_INSTANTIATION) echo yes, echo no)
AC_LANG_RESTORE
])

AC_DEFUN(OASIS_CHK_USE_TYPENAME,
[AC_MSG_CHECKING(for use of typename in class template)
# This macro will check whether keyword 'typename' is allowed
# in class template 
AC_LANG_SAVE
AC_LANG_CPLUSPLUS
AC_TRY_COMPILE([
class B
{
  public:
	typedef int RemoteType_t ;
};

template <class T>
class A
{
	typedef typename T::RemoteType_t LocalType_t ; 
	LocalType_t mVal ;
  public:
	A( LocalType_t aVal ) : mVal( aVal ) {;}
};
], [
	A<B> aVal( 123 );
],
tk_ok=yes, tk_ok=no)
if test $tk_ok = yes ; then
	AC_MSG_RESULT(yes)
	CXXFLAGS="$CXXFLAGS -DOC_USE_CPP_TYPENAME"
else
	AC_MSG_RESULT(no)
fi
echo "CXXFLAGS: $CXXFLAGS"
AC_SUBST(CXXFLAGS)
AC_LANG_RESTORE
])

AC_DEFUN(OASIS_CHK_OSTREAM_SENTRY,
[AC_MSG_CHECKING(for sentry class in ostream)
# This macro will check whether a member class 'sentry' 
# is defined class ostream
MY_SAVED_CXXFLAGS=$CXXFLAGS
CXXFLAGS="$CXXFLAGS -I$DEFAULT_PREFIX/include $BASELINE_INCLUDES"
AC_LANG_SAVE
AC_LANG_CPLUSPLUS
AC_TRY_COMPILE([
#include <iostream>
using namespace std;
void
f1( ostream& out )
{
	ostream::sentry opfx( out );
	if( opfx )
	{	return ;	}
}
], [
],
AC_DEFINE(HAVE_SENTRY_IN_OSTREAM) echo yes, echo no)
AC_LANG_RESTORE
CXXFLAGS=$MY_SAVED_CXXFLAGS
])

AC_DEFUN(OASIS_CHK_SEMAPHORE_H,
[
AC_CHECK_HEADER(semaphore.h, AC_DEFINE(HAVE_SEMAPHORE_H), )
])

AC_DEFUN(OASIS_CHK_POSIX_SEMAPHORE,
[
AC_REQUIRE([OASIS_CHK_SEMAPHORE_H])
AC_REQUIRE([OASIS_SET_MISC_LIBS])
AC_MSG_CHECKING(for sem_init() returns 0)
ORIG_LIBS="$LIBS"
LIBS="$MT_LDFLAGS $LIBS"
AC_TRY_RUN([
#include <semaphore.h>
int main()
{	
   sem_t sem;
   return sem_init( &sem, 0, 0 );
}
], AC_DEFINE(HAVE_POSIX_SEMAPHORE) echo yes, echo no, echo no)
LIBS="$ORIG_LIBS"
])

AC_DEFUN(OASIS_CHK_SYNCH_H,
[
AC_CHECK_HEADER(synch.h, AC_DEFINE(HAVE_SYNCH_H), )
])

AC_DEFUN(OASIS_CHK_THREAD_H,
[
AC_CHECK_HEADER(thread.h, AC_DEFINE(HAVE_THREAD_H), )
])

AC_DEFUN(OASIS_CHK_PTHREAD_H,
[
AC_CHECK_HEADER(pthread.h, AC_DEFINE(HAVE_PTHREAD_H), )
])

AC_DEFUN(OASIS_CHK_PTHREAD_ATTR_INIT,
[
# check whether the init/destroy or create/delete suite of functions
# should be used.
# AC_REQUIRE([OASIS_CHK_PTHREAD_H])
# AC_CHECK_FUNC(pthread_mutexattr_init, AC_DEFINE(HAVE_PTHREAD_ATTR_INIT))
AC_MSG_CHECKING(for pthread_mutexattr_init)
AC_LANG_SAVE
AC_LANG_CPLUSPLUS
AC_TRY_COMPILE([
#include <pthread.h>
], [
pthread_mutexattr_init( (pthread_mutexattr_t*)0 );
],
AC_DEFINE(HAVE_PTHREAD_ATTR_INIT) AC_MSG_RESULT(yes), AC_MSG_RESULT(no))
AC_LANG_RESTORE
])

AC_DEFUN(OASIS_CHK_PTHREAD_ATTR_DEFAULT,
[
# check whether pthread_attr_default exists
AC_REQUIRE([OASIS_CHK_PTHREAD_H])
AC_MSG_CHECKING(for pthread_attr_default)
AC_LANG_SAVE
AC_LANG_CPLUSPLUS
AC_TRY_COMPILE([
#include <pthread.h>
], [
int aVal = (int)pthread_attr_default;
],
AC_DEFINE(HAVE_PTHREAD_ATTR_DEFAULT) AC_MSG_RESULT(yes), AC_MSG_RESULT(no))
AC_LANG_RESTORE
])

dnl HAVE_PTHREAD_MUTEXATTR_DEFAULT
AC_DEFUN(OASIS_CHK_PTHREAD_MUTEXATTR_DEFAULT,
[
# check whether pthread_mutexattr_default exists
AC_REQUIRE([OASIS_CHK_PTHREAD_H])
AC_MSG_CHECKING(for pthread_mutexattr_default)
AC_TRY_COMPILE([
#include <pthread.h>
], [
int aVal = (int)pthread_mutexattr_default;
],
AC_DEFINE(HAVE_PTHREAD_MUTEXATTR_DEFAULT) AC_MSG_RESULT(yes), AC_MSG_RESULT(no))
])

dnl HAVE_PTHREAD_CONDATTR_DEFAULT
AC_DEFUN(OASIS_CHK_PTHREAD_CONDATTR_DEFAULT,
[
# check whether pthread_condattr_default exists
AC_REQUIRE([OASIS_CHK_PTHREAD_H])
AC_MSG_CHECKING(for pthread_condattr_default)
AC_LANG_SAVE
AC_LANG_CPLUSPLUS
AC_TRY_COMPILE([
#include <pthread.h>
], [
int aVal = (int)pthread_condattr_default;
],
AC_DEFINE(HAVE_PTHREAD_CONDATTR_DEFAULT) AC_MSG_RESULT(yes), AC_MSG_RESULT(no))
AC_LANG_RESTORE
])

dnl HAVE_PTHREAD_ADDR_T
AC_DEFUN(OASIS_CHK_PTHREAD_ADDR_T,
[
# check whether pthread_addr_t exists
AC_REQUIRE([OASIS_CHK_PTHREAD_H])
AC_MSG_CHECKING(for pthread_addr_t)
AC_LANG_SAVE
AC_LANG_CPLUSPLUS
AC_TRY_COMPILE([
#include <pthread.h>
], [
pthread_addr_t aVal;
],
AC_DEFINE(HAVE_PTHREAD_ADDR_T) AC_MSG_RESULT(yes), AC_MSG_RESULT(no))
AC_LANG_RESTORE
])

dnl HAVE_PTHREAD_MUTEXATTR_SETTYPE
AC_DEFUN(OASIS_CHK_PTHREAD_MUTEXATTR_SETTYPE,
[
# check whether pthread_mutexattr_settype exists
AC_REQUIRE([OASIS_CHK_PTHREAD_H])
#AC_CHECK_FUNC(pthread_mutexattr_settype,
#	AC_DEFINE(HAVE_PTHREAD_MUTEXATTR_SETTYPE))
AC_MSG_CHECKING(for pthread_mutexattr_settype)
ORIG_CXXFLAGS="$CXXFLAGS"
CXXFLAGS="$CXXFLAGS $MT_CFLAGS $EH_CXXFLAGS"
AC_LANG_SAVE
AC_LANG_CPLUSPLUS
AC_TRY_COMPILE([
#include <pthread.h>
], [
pthread_mutexattr_settype( (pthread_mutexattr_t*)0, 0 );
],
AC_DEFINE(HAVE_PTHREAD_MUTEXATTR_SETTYPE) AC_MSG_RESULT(yes), AC_MSG_RESULT(no))
AC_LANG_RESTORE
CXXFLAGS="$ORIG_CXXFLAGS"
])

dnl HAVE_PTHREAD_MUTEXATTR_SETKIND_NP
AC_DEFUN(OASIS_CHK_PTHREAD_MUTEXATTR_SETKIND_NP,
[
# check whether pthread_mutexattr_setkind_np exists
AC_REQUIRE([OASIS_CHK_PTHREAD_H])
# AC_CHECK_FUNC(pthread_mutexattr_setkind_np,
# AC_DEFINE(HAVE_PTHREAD_MUTEXATTR_SETKIND_NP))
AC_MSG_CHECKING(for pthread_mutexattr_setkind_np)
AC_LANG_SAVE
AC_LANG_CPLUSPLUS
AC_TRY_LINK([
#include <pthread.h>
], [
return pthread_mutexattr_setkind_np( (pthread_mutexattr_t*)0, 0 );
],
AC_DEFINE(HAVE_PTHREAD_MUTEXATTR_SETKIND_NP) AC_MSG_RESULT(yes), AC_MSG_RESULT(no))
AC_LANG_RESTORE
])

dnl HAVE_PTHREAD_KEY_CREATE
AC_DEFUN(OASIS_CHK_PTHREAD_KEY_CREATE,
[
# check whether pthread_key_create exists
# AC_REQUIRE([OASIS_CHK_PTHREAD_H])
# AC_CHECK_FUNC(pthread_key_create, AC_DEFINE(HAVE_PTHREAD_KEY_CREATE))
AC_MSG_CHECKING(for pthread_key_create)
AC_LANG_SAVE
AC_LANG_CPLUSPLUS
AC_TRY_COMPILE([
#include <pthread.h>
], [
pthread_key_create( (pthread_key_t*)0, 0 );
],
AC_DEFINE(HAVE_PTHREAD_KEY_CREATE) AC_MSG_RESULT(yes), AC_MSG_RESULT(no))
AC_LANG_RESTORE
])

dnl HAVE_PTHREAD_KEYCREATE
AC_DEFUN(OASIS_CHK_PTHREAD_KEYCREATE,
[
# check whether pthread_keycreate exists
# AC_REQUIRE([OASIS_CHK_PTHREAD_H])
# AC_CHECK_FUNC(pthread_keycreate, AC_DEFINE(HAVE_PTHREAD_KEYCREATE))
AC_MSG_CHECKING(for pthread_keycreate)
AC_LANG_SAVE
AC_LANG_CPLUSPLUS
AC_TRY_LINK([
#include <pthread.h>
], [
return pthread_keycreate( (pthread_key_t*)0, 0 );
],
AC_DEFINE(HAVE_PTHREAD_KEYCREATE) AC_MSG_RESULT(yes), AC_MSG_RESULT(no))
AC_LANG_RESTORE
])

dnl HAVE_PTHREAD_KEY_DELETE
AC_DEFUN(OASIS_CHK_PTHREAD_KEY_DELETE,
[
# check whether pthread_key_delete exists
# AC_REQUIRE([OASIS_CHK_PTHREAD_H])
# AC_CHECK_FUNC(pthread_key_delete, AC_DEFINE(HAVE_PTHREAD_KEY_DELETE))
AC_MSG_CHECKING(for pthread_key_delete)
AC_LANG_SAVE
AC_LANG_CPLUSPLUS
AC_TRY_COMPILE([
#include <pthread.h>
], [
pthread_key_t aVal;
pthread_key_delete( aVal );
],
AC_DEFINE(HAVE_PTHREAD_KEY_DELETE) AC_MSG_RESULT(yes), AC_MSG_RESULT(no))
AC_LANG_RESTORE
])

dnl HAVE_PTHREAD_RWLOCK
AC_DEFUN(OASIS_CHK_PTHREAD_RWLOCK,
[
# check whether pthread_rwlock_init exists
# AC_REQUIRE([OASIS_CHK_PTHREAD_H])
# AC_CHECK_FUNC(pthread_rwlock_init, AC_DEFINE(HAVE_PTHREAD_RWLOCK))
AC_MSG_CHECKING(for pthread_rwlock_init)
AC_LANG_SAVE
AC_LANG_CPLUSPLUS
AC_TRY_LINK([
#include <pthread.h>
], [
return pthread_rwlock_init( (pthread_rwlock_t*)0, (pthread_rwlockattr_t*)0 );
],
AC_DEFINE(HAVE_PTHREAD_RWLOCK) AC_MSG_RESULT(yes), AC_MSG_RESULT(no))
AC_LANG_RESTORE
])

dnl HAVE_PTHREAD_KILL
AC_DEFUN(OASIS_CHK_PTHREAD_KILL,
[
# check whether pthread_kill exists
# AC_REQUIRE([OASIS_CHK_PTHREAD_H])
# AC_CHECK_FUNC(pthread_kill, AC_DEFINE(HAVE_PTHREAD_KILL))
AC_MSG_CHECKING(for pthread_kill)
AC_LANG_SAVE
AC_LANG_CPLUSPLUS
AC_TRY_COMPILE([
#include <pthread.h>
#include <signal.h>
], [
pthread_t	aVal;
pthread_kill( aVal, 0 );
],
AC_DEFINE(HAVE_PTHREAD_KILL) AC_MSG_RESULT(yes), AC_MSG_RESULT(no))
AC_LANG_RESTORE
])

dnl HAVE_PTHREAD_SIGMASK
AC_DEFUN(OASIS_CHK_PTHREAD_SIGMASK,
[
# check whether pthread_sigmask exists
AC_REQUIRE([OASIS_CHK_PTHREAD_H])
# AC_CHECK_FUNC(pthread_sigmask, AC_DEFINE(HAVE_PTHREAD_SIGMASK))
AC_MSG_CHECKING(for pthread_sigmask)
AC_LANG_SAVE
AC_LANG_CPLUSPLUS
AC_TRY_COMPILE([
#include <pthread.h>
#include <signal.h>
], [
pthread_sigmask( 0, (sigset_t*)0, (sigset_t*)0 );
],
AC_DEFINE(HAVE_PTHREAD_SIGMASK) AC_MSG_RESULT(yes), AC_MSG_RESULT(no))
AC_LANG_RESTORE
])

dnl UNARY_PTHREAD_GETSPECIFIC
AC_DEFUN(OASIS_CHK_PTHREAD_GETSPECIFIC,
[
# check whether pthread_getspecific takes only 1 parameter
AC_REQUIRE([OASIS_CHK_PTHREAD_H])
AC_MSG_CHECKING(for single parameter in pthread_getspecific)
AC_LANG_SAVE
AC_LANG_CPLUSPLUS
AC_TRY_COMPILE([
#include <pthread.h>
], [
pthread_key_t aVal;
pthread_getspecific( aVal );
],
AC_DEFINE(UNARY_PTHREAD_GETSPECIFIC) AC_MSG_RESULT(yes), AC_MSG_RESULT(no))
AC_LANG_RESTORE
])

dnl PTHREAD_DETACH_USE_VALUE
AC_DEFUN(OASIS_CHK_PTHREAD_DETACH,
[
# check for passing thread by value in pthread_detach
AC_REQUIRE([OASIS_CHK_PTHREAD_H])
AC_MSG_CHECKING(for passing thread by value in pthread_detach)
AC_LANG_SAVE
AC_LANG_CPLUSPLUS
AC_TRY_COMPILE([
#include <pthread.h>
], [
pthread_t aVal;
pthread_detach( aVal );
],
AC_DEFINE(PTHREAD_DETACH_USE_VALUE) AC_MSG_RESULT(yes), AC_MSG_RESULT(no))
AC_LANG_RESTORE
])

dnl PTHREAD_USE_ATTR_ADDRESS
AC_DEFUN(OASIS_CHK_PTHREAD_USE_ATTR_ADDRESS,
[
# check for passing thread attr by address in pthread_create
AC_REQUIRE([OASIS_CHK_PTHREAD_H])
AC_MSG_CHECKING(for passing thread attr by address in pthread_create)
AC_LANG_SAVE
AC_LANG_CPLUSPLUS
AC_TRY_COMPILE([
#include <pthread.h>

extern "C"
{
typedef void *(*fn_t)(void*);
}
], [
pthread_create( (pthread_t*)0, (pthread_attr_t*)0, (fn_t)0, (void*)0 );
],
AC_DEFINE(PTHREAD_USE_ATTR_ADDRESS) AC_MSG_RESULT(yes), AC_MSG_RESULT(no))
AC_LANG_RESTORE
])

dnl HAVE_THREAD_EXCEPTION_HANDLE
AC_DEFUN(OASIS_CHK_THREAD_EXCEPTION_HANDLE,
[
AC_REQUIRE([OASIS_SET_MISC_LIBS])
AC_REQUIRE([OASIS_CHK_PTHREAD_H])
AC_REQUIRE([OASIS_CHK_PTHREAD_ATTR_DEFAULT])
AC_MSG_CHECKING(for use of exception in mt program)
ORIG_LIBS="$LIBS"
LIBS="$MT_LDFLAGS $LIBS"
ORIG_CXXFLAGS="$CXXFLAGS"
CXXFLAGS="$CXXFLAGS $MT_CFLAGS $EH_CXXFLAGS"
AC_LANG_SAVE
AC_LANG_CPLUSPLUS
AC_TRY_RUN([

#include <unistd.h>
#include <pthread.h>

#ifndef NULL
#	define NULL (void*)0
#endif

extern "C" void *except_routine (void *);
void *except_routine (void * aPtr)
{
	try
	{	sleep (0);	throw 1;	}
	catch(...)
	{	sleep(0);	}
	return NULL;
}

#ifdef HAVE_PTHREAD_ATTR_DEFAULT
#	define DEF_ATTR pthread_attr_default
#else
#	define DEF_ATTR NULL
#endif

int main()
{	
	pthread_t t1, t2;
	if( pthread_create( &t1, DEF_ATTR, except_routine, NULL ) == 0
	 && pthread_create( &t2, DEF_ATTR, except_routine, NULL ) == 0
	 && pthread_join( t1, NULL ) == 0
	 && pthread_join( t2, NULL ) == 0 )
		return( 0 );

	return( -1 );
}
], AC_DEFINE(HAVE_THREAD_EXCEPTION_HANDLE) AC_MSG_RESULT(yes), AC_MSG_RESULT(no), AC_MSG_RESULT(no))
AC_LANG_RESTORE

LIBS="$ORIG_LIBS"
CXXFLAGS="$ORIG_CXXFLAGS"
])


dnl IS_SELECT_CANCEL_POINT
AC_DEFUN(OASIS_CHK_SELECT_CANCEL_POINT,
[
AC_REQUIRE([OASIS_SET_MISC_LIBS])
AC_REQUIRE([OASIS_CHK_PTHREAD_H])
AC_REQUIRE([OASIS_CHK_PTHREAD_ATTR_DEFAULT])
AC_MSG_CHECKING(for if select is cancel point)
ORIG_LIBS="$LIBS"
LIBS="$MT_LDFLAGS $LIBS"
ORIG_CXXFLAGS="$CXXFLAGS"
CXXFLAGS="$CXXFLAGS $MT_CFLAGS $EH_CXXFLAGS"

AC_LANG_SAVE
AC_LANG_CPLUSPLUS
AC_TRY_RUN([

#include <stdlib.h>
#include <unistd.h>
#include <pthread.h>
#include <sys/time.h>

#ifndef NULL
#	define NULL (void*)0
#endif

extern "C" void *select_routine(void *);
void *select_routine(void * aPtr)
{
	struct timeval tv;
	tv.tv_sec = 10;
	tv.tv_usec = 0;
	int rc = select (0, NULL, NULL, NULL, &tv);
	exit( rc );
	return NULL;
}

#ifdef HAVE_PTHREAD_ATTR_DEFAULT
#	define DEF_ATTR pthread_attr_default
#else
#	define DEF_ATTR NULL
#endif

int main()
{	
	pthread_t t1;
	if( pthread_create( &t1, DEF_ATTR, select_routine, NULL ) == 0
	 && sleep(2) == 0
	 && pthread_cancel( t1 ) == 0
	 && pthread_join( t1, NULL ) == 0 )
		return( 0 );

	return( -1 );
}
], AC_DEFINE(IS_SELECT_CANCEL_POINT) AC_MSG_RESULT(yes), AC_MSG_RESULT(no), AC_MSG_RESULT(no))
AC_LANG_RESTORE

LIBS="$ORIG_LIBS"
CXXFLAGS="$ORIG_CXXFLAGS"
])

AC_DEFUN(OASIS_CHK_CONV_OPERATOR_LOOKUP_BUG,
[AC_MSG_CHECKING(for conversion operator lookup bug)
# This macro will check whether the existence of the function call operator in class C
# makes it impossible to explicitly call B::operator C()
AC_LANG_SAVE
AC_LANG_CPLUSPLUS

AC_TRY_COMPILE([ 
class C
{
public:
	int operator () (int);
};

class B
{
public:
	operator C() const;
};
], [
B b;
C c = b.operator C();
], [ AC_MSG_RESULT(no) ],
[ AC_DEFINE(HAS_CONV_OPERATOR_LOOKUP_BUG) AC_MSG_RESULT(yes) ]
)
AC_LANG_RESTORE
])

dnl HAVE_PTHREAD_TESTCANCEL
AC_DEFUN(OASIS_CHK_PTHREAD_TESTCANCEL,
[
# check whether pthread_testcancel exists
AC_REQUIRE([OASIS_CHK_PTHREAD_H])
AC_MSG_CHECKING(for pthread_testcancel)
AC_LANG_SAVE
AC_LANG_CPLUSPLUS
AC_TRY_COMPILE([
#include <pthread.h>
], [
pthread_testcancel();
],
AC_DEFINE(HAVE_PTHREAD_TESTCANCEL) AC_MSG_RESULT(yes), AC_MSG_RESULT(no))
AC_LANG_RESTORE
])

dnl HAVE_LOCALTIME_T
AC_DEFUN(OASIS_CHK_LOCALTIME_T,
[
AC_CHECK_FUNC(localtime_t, AC_DEFINE(HAVE_LOCALTIME_T))
])

AC_DEFUN(OASIS_CHECK_LICENSE,
[
AC_ARG_ENABLE(license, [  --enable-license build with license checking],
    [tcl_ok=$enableval], [tcl_ok=no])

if test "$tcl_ok" = "yes"; then
	case $target in
	  *-osf*)		
			# No license management on OSF
			;;
	  *)			
			AC_DEFINE(MB_LICENSE_CHECK)
			LIBS="$LIBS -lnonet"
			AC_SUBST(LIBS)
			;;
	esac
fi])

AC_DEFUN(OASIS_SET_HIGHWATERMARK,
[
AC_ARG_ENABLE(highwatermark,
	[  --enable-highwatermark link with highwatermark library],
    [tcl_ok=$enableval], [tcl_ok=no])

if test "$tcl_ok" = "yes"; then
	case $target in
	  *-hpux*)		
			# Only hpux have high-water-mark to worry about
			LIBS="$LIBS -lohighwatermark"
			AC_SUBST(LIBS)
			;;
	esac
fi])

AC_DEFUN(OASIS_SET_LIBOSTLSGI,
[
AC_ARG_ENABLE(libostlsgi,
	[  --enable-libostlsgi link with libostlsgi library],
    [tcl_ok=$enableval], [tcl_ok=no])

if test "$tcl_ok" = "yes"; then
	LIBS="$LIBS -lostlsgi"
	AC_SUBST(LIBS)
	CXXFLAGS="$CXXFLAGS -DOC_USE_LIBOSTLSGI"
fi])

AC_DEFUN(OASIS_CHK_PREFIX_OF_STD_CLASSES,
[
AC_MSG_CHECKING(for how standard classes should be specified)
# This macro will check whether how the exception class should be specified
AC_LANG_SAVE
AC_LANG_CPLUSPLUS
AC_TRY_COMPILE([
#include <exception>
],
[
class B : public std::exception {};
],
tk_ok=yes, tk_ok=no)

if test $tk_ok = yes ; then
	AC_MSG_RESULT(as std::)
	AC_DEFINE_UNQUOTED(STD_CLASS_PREFIX,std::)
else

AC_TRY_COMPILE([
#include <exception>
],
[
class B : public ::exception {};
],
tk_ok=yes, tk_ok=no)

if test $tk_ok = yes ; then
	AC_MSG_RESULT(as ::)
	AC_DEFINE_UNQUOTED(STD_CLASS_PREFIX,::)
else
	AC_MSG_RESULT(as NULL)
	AC_DEFINE_UNQUOTED(STD_CLASS_PREFIX,)
fi

fi

AC_LANG_RESTORE
])

AC_DEFUN(OASIS_CHK_GETSOCKETOPT,
[
AC_MSG_CHECKING(if getsockopt takes socklen_t argument)
# This macro will check whether how the exception class should be specified
AC_LANG_SAVE
AC_LANG_CPLUSPLUS
AC_TRY_COMPILE([
#include <sys/types.h>
#include <sys/socket.h>
],
[
int			s, level, optname;
void*		optval;
socklen_t	optlen;
getsockopt( s, level, optname, (void*)0, &optlen );
],
tk_ok=yes, tk_ok=no)

if test $tk_ok = yes ; then
	AC_MSG_RESULT(yes)
	AC_DEFINE(GETSOCKETOPT_ACCEPT_SOCKLEN,1)
else
	AC_MSG_RESULT(no)
fi

AC_LANG_RESTORE
])

#
# Defines the condition to trigger a minimal build.
# Mainly for creating a mini version of msgsim.
#
AC_DEFUN(OASIS_CHK_MINIMUM_DEPENDENCY,
[
AC_ARG_ENABLE(minimumdependency,
	[  --enable-minimumdependency       build with minimum dependency],
	[tcl_ok=$enableval], [tcl_ok=no])

if test "$tcl_ok" = "yes"; then
	echo "Enabled Minimum dependency build options"
	CFLAGS="$CFLAGS -DOC_NOMBOXDEPENDENCY"
	CXXFLAGS="$CXXFLAGS -DOC_NOMBOXDEPENDENCY"
	AC_SUBST(CFLAGS)
	AC_SUBST(CXXFLAGS)
fi

AM_CONDITIONAL(XNOSHCDEPENDENCY, test "${tcl_ok}" = yes)
AM_CONDITIONAL(XNOMBOXDEPENDENCY, test "${tcl_ok}" = yes)
AM_CONDITIONAL(XMINIMUMDEPENDENCY, test "$tcl_ok" = "yes" )

])

#
# Defines the condition to trigger a minimal build that
# depend on no more than mbox.
# Mainly for creating a smaller version of msgsim.
#
AC_DEFUN(OASIS_CHK_MBOXONLY_DEPENDENCY,
[
AC_ARG_ENABLE(mboxonlydependency,
	[  --enable-mboxonlydependency       build with mbox only dependency],
	[tcl_ok=$enableval], [tcl_ok=no])

AM_CONDITIONAL(XNOSHCDEPENDENCY, test "${tcl_ok}" = yes)

])

#
# Defines the condition to trigger a standalone build that
# does not depend on mbox
# Mainly for creating a smaller version of tokenizer.
#
AC_DEFUN(OASIS_CHK_STANDALONE,
[
AC_ARG_ENABLE(standalone,
	[  --enable-standalone       build with standalone],
	[tcl_ok=$enableval], [tcl_ok=no])

if test "$tcl_ok" = "yes"; then
	echo "Enabled Standalone build options"
	CFLAGS="$CFLAGS -DOC_STANDALONE"
	CXXFLAGS="$CXXFLAGS -DOC_STANDALONE"
	AC_SUBST(CFLAGS)
	AC_SUBST(CXXFLAGS)
fi

AM_CONDITIONAL(XSTANDALONE, test "${tcl_ok}" = yes)

])

#
# Defines the condition to trigger a build that depends on
# txn-stat API. Default is that it does not call txn-stat API
#
AC_DEFUN(OASIS_CHK_TXNSTAT,
[
AC_ARG_ENABLE(txnstat,
	[  --enable-txnstat       build with txnstat],
	[tcl_ok=$enableval], [tcl_ok=no])

if test "$tcl_ok" = "yes"; then
	echo "Enabled TxnState build options"
	CFLAGS="$CFLAGS -DTXNSTAT"
	CXXFLAGS="$CXXFLAGS -DTXNSTAT"
	AC_SUBST(CFLAGS)
	AC_SUBST(CXXFLAGS)
fi

AM_CONDITIONAL(XTXNSTAT, test "${tcl_ok}" = yes)

])

#
# 
#
AC_DEFUN(OASIS_CHK_PURE,
[
AC_ARG_ENABLE(pure,
	[  --enable-pure       build purify ready code ],
	[tcl_ok=$enableval], [tcl_ok=no])

if test "$tcl_ok" = "yes"; then
	echo "Enabled Purify frieldly build options"
	CFLAGS="$CFLAGS -DOC_PURE"
	CXXFLAGS="$CXXFLAGS -DOC_PURE"
	AC_SUBST(CFLAGS)
	AC_SUBST(CXXFLAGS)
fi

])

AC_DEFUN(OASIS_CHK_MT,
[
AC_ARG_ENABLE(mt,
	[  --enable-mt       build MT ready code ],
	[tcl_ok=$enableval], [tcl_ok=no])

if test "$tcl_ok" = "yes"; then
	echo "Enabled MT build options"
	CFLAGS="$CFLAGS $MT_CFLAGS"
	CXXFLAGS="$CXXFLAGS $MT_CFLAGS"
	LDFLAGS="$LDFLAGS $MT_LDFLAGS"
	AC_SUBST(CFLAGS)
	AC_SUBST(CXXFLAGS)
	AC_SUBST(LDFLAGS)
fi

])

AC_DEFUN( OASIS_CHK_EXPIRYDATE,
[
AC_ARG_WITH( expirydate, [  --with-expirydate=<<YYYYMMDD>> Binary to be expired on this date ], 
[expirydate=$withval 

AC_MSG_CHECKING(Software Expiry Date)

if test "x${expirydate}" = "x"; then
    AC_MSG_ERROR(must specify expiry date in YYYYMMDD format for --with-expirydate)
fi

dnl Calculate expiry date index 
EXPDATEIND=`echo "$expirydate - 19970406" | bc`
AC_MSG_RESULT( $expirydate ( $EXPDATEIND ) )

dnl -rc-
dnl 2 expiry date information entry is specified : 
dnl .	date string and
dnl	.	date index offset from a fixed date
dnl While the string is used only for display purpose,
dnl the index is in the actual calculation.
dnl There are 2 of them to create some confusion to
dnl potential hackers.
dnl CXXFLAGS="$CXXFLAGS -DOCEXPDATE=\"$expirydate\" -DOCEXPDATEIND=$EXPDATEIND"
dnl AC_SUBST(CXXFLAGS)
dnl CFLAGS="$CFLAGS -DOCEXPDATE=\"$expirydate\" -DOCEXPDATEIND=$EXPDATEIND"
dnl AC_SUBST(CFLAGS)

AC_DEFINE_UNQUOTED(OCEXPDATE, "$expirydate", [Expiry Date])
AC_DEFINE_UNQUOTED(OCEXPDATEIND, $EXPDATEIND, [Expiry Date Index])

], [unset expirydate])
])

AC_DEFUN(OASIS_CHK_NOSPECIALIZEDTRACE,
[
AC_ARG_ENABLE(nospecializedtrace, [  --enable-nospecializedtrace       build without specialized trace],
    [tcl_ok=$enableval], [tcl_ok=no])
if test "$tcl_ok" = "yes"; then
    CFLAGS="$CFLAGS -DOC_NOSPECIALIZEDTRACE" 
    CXXFLAGS="$CXXFLAGS -DOC_NOSPECIALIZEDTRACE" 
	AC_SUBST(CFLAGS)
	AC_SUBST(CXXFLAGS)
fi])

AC_DEFUN(	OASIS_CHK_BUILDSOONAIX,
[
	AC_ARG_ENABLE(	buildsoonaix,
		[  --enable-buildsoonaix       build so-DLL on AIX ],
		[tcl_ok=$enableval], [tcl_ok=no])
	if test "$tcl_ok" = "yes"; then
		DO_BUILDSOONAIX=1
		export DO_BUILDSOONAIX
	fi

	AM_CONDITIONAL(XBUILDSOONAIX, test "$tcl_ok" = yes )

])

AC_DEFUN(	OASIS_CHK_USEOSSTL,
[
	AC_ARG_ENABLE(	useosstl,
		[  --enable-useosstl       use the STL provided by OS ],
		[tcl_ok=$enableval], [tcl_ok=no])

	AC_MSG_CHECKING( checking for source of STL )
	if test "$tcl_ok" = "yes"; then
		USE_OS_STL=1
		export USE_OS_STL
		AC_MSG_RESULT( OS )

		CXXFLAGS="$CXXFLAGS -DOC_USE_NEW_STL" 
		AC_SUBST(CXXFLAGS)
	else
		AC_MSG_RESULT( SGI-STL )
	fi

	AM_CONDITIONAL(XUSEOSSTL, test "$tcl_ok" = yes )
])

AC_DEFUN(OASIS_CHK_STREAM_OPEN_HAS_PROT,
[ AC_MSG_CHECKING([fstream open has argument for file protection])
AC_LANG_SAVE
AC_LANG_CPLUSPLUS
AC_TRY_COMPILE([
#if defined(OC_USE_NEW_STL)
#	include <iostream>
#	include <fstream>
#else
#	include <iostream.h>
#	include <fstream.h>
#endif
void
f1()
{
	case $target in
	*-aix7.3*)		
		std::fstream aFile;
		aFile.open( "whatever", std::ios::in );
	*)
		fstream aFile;
		aFile.open( "whatever", ios::in, 0664 );
	esac

}
], [
],
AC_DEFINE_UNQUOTED(HAVE_FSTREAM_OPEN_PROT, , [fstream open has argu for file prot]) echo yes, echo no)
AC_LANG_RESTORE
])

AC_DEFUN(OASIS_CHK_VA_COPY,
[ AC_MSG_CHECKING([va_copy available])
AC_LANG_SAVE
AC_LANG_CPLUSPLUS
AC_TRY_COMPILE([
#include <stdarg.h>
void
f1()
{
	va_list	a;
	va_list	b;
	va_copy(a,b);
}
], [
],
AC_DEFINE_UNQUOTED(HAVE_VA_COPY, , [va_copy available]) echo yes, echo no)
AC_LANG_RESTORE
])

AC_DEFUN(OASIS_CHK___VA_COPY,
[ AC_MSG_CHECKING([__va_copy available])
AC_LANG_SAVE
AC_LANG_CPLUSPLUS
AC_TRY_COMPILE([
#include <stdarg.h>
void
f1()
{
	va_list	a;
	va_list	b;
	__va_copy(a,b);
}
], [
],
AC_DEFINE_UNQUOTED(HAVE___VA_COPY, , [__va_copy available]) echo yes, echo no)
AC_LANG_RESTORE
])

AC_DEFUN(OASIS_SET_C11, [
AC_ARG_ENABLE(c11, [  --enable-c11 build with C++11 compiler syntax],
    [tcl_ok=$enableval], [tcl_ok=no])
if test "$tcl_ok" = "yes" ; then
	echo "Building objects with standard C++11 compilation"
	BUILD_C11=yes
else
	echo "Building objects with default C++ standard compilation"
	BUILD_C11=no
fi
])
