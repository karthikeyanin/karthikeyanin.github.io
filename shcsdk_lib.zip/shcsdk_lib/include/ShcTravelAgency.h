//
// Copyright (C) 2009 eFunds Corporation ("eFunds").  All Rights Reserved.
// eFunds Canada Corporation is an authorized user.
//
// IST is a registered trademark of eFunds Corporation.  Other brand or
// product names are trademarks or registered trademarks of their respective
// holders.
//
// The information contained herein is the unpublished proprietary property
// of eFunds.  Except as specifically authorized in writing by eFunds, the
// holder of this document shall: i) keep all information contained herein
// confidential, and ii) protect the information, in whole or in part, from
// disclosure and dissemination to all third parties.
//
// This document and the software described in it are furnished under license
// and may be used or copied only in accordance with the terms of such license.
// This document is supplied for information purposes only, is subject to
// change without notice, and should not be construed as a commitment by
// either eFunds Corporation or eFunds Canada Corporation.
//
/*
 * Description:
 *
 *      MODIFICATION HISTORY
 *
 *  Date         SCR            Who        Description
 *  ===========================================================================
*/

#ifndef SHCTRAVELAGENCY_H
#define SHCTRAVELAGENCY_H
static const char* _ShcTravelAgency_h_what = "@(#) ShcTravelAgency.h p4.1.25 2014/09/08 00:44:40";

#include <oc/oc_string.h>
#include <DBMWrapper.hxx>
#include <dbm.h>
#include <dbm_private.h>
#include <auto_ptr.h>
#include <debug.h>
#include <ist_otrace.h>
#include <ShcmsgHelper.h>
#include <ShcmsgHeader.h> 
#include <ShcHelperBase.h>
#include <ShcHelper.h>
#include <ShcAppBase.h>

struct ShcTravelAgency_Data
{
  OCString travelAgencyAddendumSequence;
  OCString customIdType;
  OCString customIdDetail;
  OCString travelAgencySequenceNumber;
  OCString travelAgencyFeeAmount;
  OCString travelAgencyFeeCurrCode;
  OCString travelAgencyFeeRate;
  OCString travelAgencyFeeDesc;
};

class ShcTravelAgency
{
	public:
		ShcTravelAgency();
		~ShcTravelAgency();
		void setTagValue(char *TagName, const char *TagValue);
		void setTagValue(char *TagName, int TagValue);
		void setTagValue(char *TagName, double TagValue);
		int getBufferlength();
		char *getBuffer();
	protected:
	   char buff[1024];
	   int len;
};

#endif
