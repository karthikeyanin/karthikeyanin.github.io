#ifndef SHCMSGCACHE_INCLUDE
#define SHCMSGCACHE_INCLUDE
/*
 *  Copyright (C) 2004 eFunds Corporation ("eFunds").  All Rights Reserved.     
 *  eFunds Canada Corporation is an authorized user.                            
 *                                                                              
 *  IST is a registered trademark of eFunds Corporation.  Other brand or        
 *  product names are trademarks or registered trademarks of their respective   
 *  holders.                                                                    
 *                                                                              
 *  The information contained herein is the unpublished proprietary property    
 *  of eFunds.  Except as specifically authorized in writing by eFunds, the     
 *  holder of this document shall: i) keep all information contained herein     
 *  confidential, and ii) protect the information, in whole or in part, from    
 *  disclosure and dissemination to all third parties.                          
 *                                                                          
 *  This document and the software described in it are furnished under license  
 *  and may be used or copied only in accordance with the terms of such license.
 *  This document is supplied for information purposes only, is subject to      
 *  change without notice, and should not be construed as a commitment by       
 *  either eFunds Corporation or eFunds Canada Corporation. 
 */
/*
#pragma ident "@(#) ShcMsgCache.h 1.1 04/06/07 16:36:00"   
 *
 *                        MODIFICATION HISTORY                  REVIEW
 *
 *	SPR#	Who	Date	Description			Who	Date   
 * ===========================================================================
 *R009624 ztang 10Apr03 Created for database fallover
 */
 


#if !defined( SHCDLLEXPORT )
#   if defined( WIN32 )
#       define SHCDLLEXPORT __declspec(dllimport)
#   else
#       define SHCDLLEXPORT
#   endif
#endif

#include <stl/vector.h>
#include <ShcMsgCache.h>

#define MAX_SHC_MSG_QUEUE 20

struct ShcMsgCache
{
	int	dest_id;	/* Destination Mailbox ID */
	int src_id;		/* This is the source Mailbox ID */
	char *amsg;	/* This is the message that will be sent */
	int len;	/* This is the length */
};

extern void beginCacheMsg();

extern void endCacheMsg();

extern int cache_mb_write(int dest_id, int src_id, char *msg, int len);

extern int flush_mb_cache();

extern void reset_mb_cache();

#endif
