#ifndef _BRANDBLOCKED_H_
#define _BRANDBLOCKED_H_

static char _BrandBlocked_h_what[] = "@(#) BrandBlocked.h 1.4 10/07/29 09:43:45";

/*
 *  Copyright (C) 2004 eFunds Corporation ("eFunds").  All Rights Reserved.     
 *  eFunds Canada Corporation is an authorized user.                            
 *                                                                              
 *  IST is a registered trademark of eFunds Corporation.  Other brand or        
 *  product names are trademarks or registered trademarks of their respective   
 *  holders.                                                                    
 *                                                                              
 *  The information contained herein is the unpublished proprietary property    
 *  of eFunds.  Except as specifically authorized in writing by eFunds, the     
 *  holder of this document shall: i) keep all information contained herein     
 *  confidential, and ii) protect the information, in whole or in part, from    
 *  disclosure and dissemination to all third parties.                          
 *                                                                          
 *  This document and the software described in it are furnished under license  
 *  and may be used or copied only in accordance with the terms of such license.
 *  This document is supplied for information purposes only, is subject to      
 *  change without notice, and should not be construed as a commitment by       
 *  either eFunds Corporation or eFunds Canada Corporation. 
 *
 *
 *                        MODIFICATION HISTORY                  REVIEW
 *
 * SCR#     Who    Date  Description
 * ===========================================================================
 * R027802 jyang 25Jan10 Initial version to support feature of "Block by Brand"
 */
 
#include <shc.h>
#include <ShcBin.h>
#include <block_by_brand.h>

#define SHC_BrandBlocked 					"BrandBlocked"
#define BRAND_BLOCKED_MESSAGE_NAME			"shc-brand-blocked"

class BrandBlocked : public ShcHelperBase
{
protected:
	struct rules_keytab *appHead;
	char 				*appKey;
	
	BLOCK_BY_BRAND 		*brandEntries;
	int             	szBrand;

	// USP-1319
	// Blocked information
	char				blockedInstId[11];
	char				blockedTxnDest[11];
	char				blockedCardProd[11];
	char				blockedNetworkData[SHC_NETWORK_DATA_BUF_LEN];	// USP-1678
	bin_t  				blockedBin;				// repositioned here--this is the userbin Id

public:
	BrandBlocked();
	~BrandBlocked();
	
	const char *getName()
	{
		return (char *)SHC_BrandBlocked;
	}
	
	static BrandBlocked *getInstance()
	{
		static BrandBlocked *_instance=NULL;
		if ( !_instance )
		{
			_instance = new BrandBlocked;
		}
		return _instance;
	}
	
	virtual int  		lookup( char *src, char *dest, char *product );
	virtual void 		setBlockedBin( const bin_t aBin );
	virtual const char*	getBlockedBin() const;
	virtual const char* getBlockedDest() const;
	virtual const char* getBlockedProduct() const;

	virtual void 		setBlockedNetworkData( char* netData );	// USP-1678
	virtual const char* getBlockedNetworkData() const;			// USP-1678
	
protected:
	int createPseudoSharedMemory();
};

#endif

