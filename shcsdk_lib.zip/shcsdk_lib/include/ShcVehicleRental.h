#ifndef _SHC_VEHICLERENTAL_H_
#define _SHC_VEHICLERENTAL_H_

static char _shc_vehicleRental_h_what[] = "@(#) shc_vehicleRental.h 1.0 22/11/21 15:22:34";

/*
 *  Copyright (C) 2004 eFunds Corporation ("eFunds").  All Rights Reserved.     
 *  eFunds Canada Corporation is an authorized user.                            
 *                                                                              
 *  IST is a registered trademark of eFunds Corporation.  Other brand or        
 *  product names are trademarks or registered trademarks of their respective   
 *  holders.                                                                    
 *                                                                              
 *  The information contained herein is the unpublished proprietary property    
 *  of eFunds.  Except as specifically authorized in writing by eFunds, the     
 *  holder of this document shall: i) keep all information contained herein     
 *  confidential, and ii) protect the information, in whole or in part, from    
 *  disclosure and dissemination to all third parties.                          
 *                                                                          
 *  This document and the software described in it are furnished under license  
 *  and may be used or copied only in accordance with the terms of such license.
 *  This document is supplied for information purposes only, is subject to      
 *  change without notice, and should not be construed as a commitment by       
 *  either eFunds Corporation or eFunds Canada Corporation. 
 *
 *
 *                        MODIFICATION HISTORY                  REVIEW
 *
 * SCR#     Who    Date  Description
 * ===========================================================================
 * R0xxxxx 
 */
 
struct ShcVehicleRentalFields
{
	OCString rentalAgreemtNumber;
	OCString renterName;
	OCString rentalReturnCity;
	OCString rentalReturnState;
	OCString rentalReturnCntry;
	OCString rentalReturnDate;
	OCString rentalReturnLocId;
	OCString rentalLocationCity;
	OCString rentalLocationState;
	OCString rentalLocationCountry;
	OCString rentalLocationId;
	OCString rentalCustomerServicePhone;
	OCString csiTollFreeNumber;
	OCString rentalClassCode;
	OCString rentalRateIndicator;
	OCString amountDailyRate;
	OCString dailyRateCurrCode;
	OCString amountWeeklyRate;
	OCString weeklyRateCurrCode;
	OCString amountMonthlyRate;
	OCString monthlyRateCurrCode;
	OCString amountRateMileKm;
	OCString rateMileKmCurrCode;
	OCString totalMileKm;
	OCString maximumFreeMileKm;
	OCString insuranceIndicator;
	OCString amountInsuranceCharge;
	OCString insuranceChgCurrCode;
	OCString amountFuelCharge;
	OCString fuelChargeCurrCode;
	OCString amountOnewayDropoff;
	OCString onewayDropOffCurrCode;
	OCString adjustIndicator;
	OCString amountAdjust;
	OCString amountAdjustCurrCode;
	OCString programCode;
	OCString rentalCheckoutDate;
	OCString mileKmIndicator;
	OCString amounttRentalExtraCharge;
	OCString rentalExtraChargeCurrCode;
	OCString daysRented;
	OCString noShowIndicator;
	OCString rentalBusinessFormatCode;
	OCString commodityCode;
	OCString rentalExtraServiceCode;
	OCString taxExemptIndicator;
	OCString corporateId;
	OCString amountWeeklyRental;
	OCString weeklyRentalCurrCode;
	OCString amountTotalAuth;
	OCString totalAuthCurrCode;
	OCString amountRegularMileCharge;
	OCString regularMileChargeCurrCode;
	OCString amountExtraMileCharge;
	OCString extraMileChargeCurrCode;
	OCString lateChargeAmount;
	OCString lateChargeCurrCode;
	OCString towingChargeAmount;
	OCString towingChargeCurrCode;
	OCString otherChargeAmount;
	OCString otherChargeCurrCode;
	OCString totalTaxAmount;
	OCString totalTaxCurrCode;
	OCString totalTaxCollectionIndicator;
	OCString customerCode;
	OCString vehicleRegistrationNumber;
	OCString addtionalDrivers;
	OCString age;
	OCString odometer;
	OCString vehicleMake;
	OCString vehicleModel;
	OCString travelAgencyCode;
	OCString travelAgencyName;
	OCString taxType;
	OCString taxRate;
	OCString taxElements;
	OCString coupon;
	OCString additionalCoupon;
	OCString vehicleProgramCode;
	OCString phoneChargesAmount;
	OCString phoneChargesCurrCode;
	OCString gpsChargesAmount;
	OCString gpsChargesCurrCode;
	OCString comments;
	OCString totalAmount;
	OCString totalAmountCurrCode;
	OCString rentalReturnAddress;
	OCString rentalAddress;
	OCString cardScheme;
	OCString rentalAgencyName;
	OCString businessApplicationId;
};


class ShcVehicleRental
{
	char buff[1300];
	int len;
public:
	ShcVehicleRental();
	void setTagValue(char *TagName, const char *TagValue);
	void setTagValue(char *TagName, int TagValue);
	void setTagValue(char *TagName, double TagValue);
	char* getBuffer();
	int getBufferLength();
};

#endif

