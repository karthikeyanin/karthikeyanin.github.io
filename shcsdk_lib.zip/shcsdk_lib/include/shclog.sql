/*
 *  Copyright (C) 2004 eFunds Corporation ("eFunds").  All Rights Reserved.     
 *  eFunds Canada Corporation is an authorized user.                            
 *                                                                              
 *  IST is a registered trademark of eFunds Corporation.  Other brand or        
 *  product names are trademarks or registered trademarks of their respective   
 *  holders.                                                                    
 *                                                                              
 *  The information contained herein is the unpublished proprietary property    
 *  of eFunds.  Except as specifically authorized in writing by eFunds, the     
 *  holder of this document shall: i) keep all information contained herein     
 *  confidential, and ii) protect the information, in whole or in part, from    
 *  disclosure and dissemination to all third parties.                          
 *                                                                          
 *  This document and the software described in it are furnished under license  
 *  and may be used or copied only in accordance with the terms of such license.
 *  This document is supplied for information purposes only, is subject to      
 *  change without notice, and should not be construed as a commitment by       
 *  either eFunds Corporation or eFunds Canada Corporation. 
 *                    
 *  #pragma ident "@(#) shclog.sql 1.19.1.1 16/10/21 10:12:00";
 */
 
/* 
 *
 *				Modification History
 *
 *	Who		When		Why
 *	========================================================================
 *	ad		02Jan92		Expanded database to include new fields in
 *						shcmsg.
 *	ad		09mar92		Added index on refnum/pan
 *	ss		04Apr92		Re-arrange shclog_1 index 
 *								FROM
 *						trace, pan, local_time, local_datetime, acquirer, termid
 *								TO
 *						local_datetime, pan, trace, local_time, acquirer, termid
 *
 *	qd		06feb96		Add spaces to hold more info
 *	qd		21feb96		Add more fields to support IBFT 
 *  yh      22sep97     Add acquirer_data/issuer_data for SMS agent
 *  yh      25sep97     Add more fields for multi-ccy
 *  yh      26sep97     Add ledger_balance into shclog 
 *  R002421	jsun	Oct99	Added device_fee
 *	R003928	SG	31jan00	Added new feild of 400 bytes to be logged.
 *  R004671 Dds	23Jun00	Merge vsdc enhancement to 7.2, refer to 2007336 R009166
 *  2007336 Mch 20Feb00 Add 4 fields for logging chip data on 7.1.3
 *  2007336 Mch 21Feb00 Minor change according to latest physical design doc 
 *                      on 7.1.3.
 *  R009166 Rpc 13Apr00 move field card_seqno to other place instead
 *                      of being the filed on the table on 7.1.3.
 *R008717 ztang 10Dec02	Multi-instituion support.
 NOTE NOTE
	This version is specific to SAMBA
 * R012134 04Oct04 Emj Issuer Entity Support
 * R012160 10Oct04 Emj Added processor business day
 * R027170 03Sep09 Dipa Tokenization changes 

*/

create table shclog (
	msgtype			int,	
	flipped_msgtype	int,		/* The message type used when sending txn to networks. If no flipping use 0 */		
	pan				pan_token_t(19) null,	
	mask_pan		char(19) null,	
	pcode			int,					
	txntype			int,


	amount			money,				
	aval_balance	money,		
	amount_equiv	money,
	cash_back		money,

	iss_conv_rate		money,
	iss_currency_code	smallint,		
	iss_conv_date		date,
	acq_conv_rate		money,	
	acq_currency_code	smallint,		
	acq_conv_date		date,

	tra_amount			money,	  /* qd 21feb96 */	
	tra_conv_rate		money,	  /* qd 21feb96 */	
	tra_currency_code	smallint, /* qd 21feb96 */		
	gateway_id          smallint, /* Storing Gateway Id */
	tra_conv_date		date, /* qd 21feb96 */

	fee					money,
	new_fee				money,	  /* qd 21feb96 */
	new_amount			money,    /* qd 21feb96 */
	new_setl_amount   	money, 	  /* qd 21feb96 */
	settlement_fee		money,    /* qd 21feb96 */
	settlement_rate		money,
	settlement_code		smallint,
	settlement_amount	money,


	trandate		date,				
	trantime		int,				

	trace			int,					

	local_time		int,				
	local_date		date,				

	settlement_date		date,			
	cap_date		date,				


	pos_entry_code		smallint,			
	pos_condition_code	smallint,
	pos_pin_cap_code	char(1) null,
	pos_cap_code		smallint,
	life_cycle			int,


	acquirer		char(10) null,				
	issuer			char(10) null,					
	transferee		char(10) null,  /* qd 21feb96 added */					
	originator		char(10) null,		
	
	/* R008717 BEGIN */
	/* member_id is needed for duplicate checking. Remove use of Filler2 and 3 
	 * for europay duplicate checking. Also keeps log of what ID's 
	 * were shipped to Networks for authorization. 
	 * For 1xx, 2xx and 4xx stores field 32, For other messages, 
	 * it stores one of  field 32, field 99 and field 100
	 */
	member_id		char(11) null,	

	f_id			char(11) null,	/* F_ID, field 33 in XMF */
	txnsrc			varchar(10) null, 	/* Institution id to indicates where the txn comes from */
	txndest			varchar(10) null,  /* Institution id to indicates where the txn goes to */		
	alternateacquirer char(10) null, /* alternate acquirer */
	entityid		varchar(30),		/* entity id defined in UDM */
	iss_entityid	varchar(30),		/* issuer entity id defined in UDM */
	cardproduct		char(10),		/* Card Brand used */
	mvv				char(10),		/* Merchant Verification Value */
	invoice_number	char(6),		/* Invoice Number */
	trans_id		char(15),		/* Transaction ID for VISA */
	fpi				char(3),		/* Fee program indicator for VISA */
	txn_start_time	int,			/* Start time of the txn for statistic purpose */
	txn_end_time		int,			/* End time of the txn for statistic purpose */
	device_cap		int,			/* log the device_cap field in shcmsg */
	

	respcode		int,				
	reason_code		int,	/* qd 21feb96 */			
	revcode			int,				
	shcerror		int,
	saf				smallint,

	/*	reversal fields */
	origmsg			smallint,
	origflippedmsg	smallint,
	origtrace		int,
	origdate		date,
	origtime		int,


	/*	fields for visa */
	merchant_type	smallint,
	acq_country		smallint,

	refnum			char(12) null,		
	authnum			char(6) null,
	termid			char(8) null,	
	acceptorname	char(40) null,	
	termloc			char(25) null,
	addresponse		char(25) null,
	/* qd 21feb96 expanded from 38 to 42 */
	acctnum			char(65) null,	/* ad: 2Jan92 expanded */
	branch			smallint,
	serial_1		int,
	serial_2		int,

	/*Jan 2/92 a.d. */

	storeid			int,
	lane			int,
	terminal_trace			int,
	checker_id			int,
	supervisor			int,
	shift_number		int,
	batch_id			int,

	/*
	 * qd	21feb96		Add the following new fields
	 */
	device_devcap		int,	
	shc_devcap			int,	
	formatter_devcap	int,	
	auth_devcap 		int,	


	/*
	 * qd	06feb96		Add spaces to hold more info
	 */
	filler1				varchar(50),
	filler2				varchar(50),
	filler3				varchar(50),
	filler4				varchar(50),

    /*
     * yh: 1997/09/22.  Add issuer_data/acquirer_data for SMS
     */
     issuer_data        varchar(128),
     acquirer_data      varchar(128),
 
    /*
     * yh: 1997/09/25. Add mode fields for multiple currency support
     */
     new_amount_equiv		money,

	 acq_aval_balance 		money,
	 acq_ledger_balance		money,
	 setl_aval_balance		money,
	 setl_ledger_balance	money,
	 
	 aval_balance_type		smallint,
	 ledger_balance_type	smallint,

	 new_setl_fee			money,
	 
	 txn_amount				money,
	 txn_new_amount			money,
	 txn_currency_code		smallint,
	 txn_conv_rate			money,
	 txn_conv_date			date,
	 
	 ch_amount				money,
	 ch_new_amount			money,
	 ch_currency_code		smallint,
	 ch_conv_rate			money,
	 ch_conv_date			date,

     ledger_balance         money,

	 slot_num				smallint,
	 device_fee		money,
	 shc_data_buffer varbinary(254) ,
	 card_seqno				smallint,	/*2007336 R004671 Dds 23Jun00*/
	 alpharesponsecode		char(3),	/*2007336 R004671 Dds 23Jun00*/
	 chip_type				char(1),	/*2007336 R004671 Dds 23Jun00*/
	 chip_index				char(20) not null,   /*2007336 R004671 Dds 23Jun00*/
	 processor_busday       date,
	 seq_trace_no			int,
	 seg_req				varbinary(100),
	 seg_resp				varbinary(100),
	 site_id			    smallint,
	 version  				smallint,
	 src_node			    smallint,
	 dest_node			    smallint,
	submerchant_id			varchar(15),
	dest_id				varchar(15),
	payfacid			varchar(11)


)


/* 04Apr92 	 ***** C H A N G E D      S U N N Y ******
create index shclog_1 on shclog (trace, pan, local_time, local_datetime, 
											acquirer, termid)
*/

create index shclog_1 on shclog (local_date, pan, trace, local_time, 
											acquirer, termid, pcode)


create index shclog_2 on shclog (settlement_date, trace)

create index shclog_4 on shclog (refnum, pan)
create unique index shclog_5 on shclog ( chip_index, site_id )

GG_PARAM shclog
(
);

