#ifndef _SHCTRAVELCRUISE_H_
#define _SHCTRAVELCRUISE_H_

static char _ShcTravelCruise_h_what[] = "@(#) ShcTravelCruise.h 1.0 22/11/21 15:22:34";

/*
 *  Copyright (C) 2004 eFunds Corporation ("eFunds").  All Rights Reserved.     
 *  eFunds Canada Corporation is an authorized user.                            
 *                                                                              
 *  IST is a registered trademark of eFunds Corporation.  Other brand or        
 *  product names are trademarks or registered trademarks of their respective   
 *  holders.                                                                    
 *                                                                              
 *  The information contained herein is the unpublished proprietary property    
 *  of eFunds.  Except as specifically authorized in writing by eFunds, the     
 *  holder of this document shall: i) keep all information contained herein     
 *  confidential, and ii) protect the information, in whole or in part, from    
 *  disclosure and dissemination to all third parties.                          
 *                                                                          
 *  This document and the software described in it are furnished under license  
 *  and may be used or copied only in accordance with the terms of such license.
 *  This document is supplied for information purposes only, is subject to      
 *  change without notice, and should not be construed as a commitment by       
 *  either eFunds Corporation or eFunds Canada Corporation. 
 *
 *
 *                        MODIFICATION HISTORY                  REVIEW
 *
 * SCR#     Who    Date  Description
 * ===========================================================================
 * R0xxxxx 
*/

struct ShcTravelCruiseFields
{
	OCString rentalAgreemtNumber;
	OCString IATACarrierCode;
	OCString IATAAgencyNumber;
	OCString travelPackageIndicator;
	OCString passengerName;
	OCString travelTicketNumber;
	OCString travelDepartureDateSegment1;
	OCString travelDestinationCodeSegment1;
	OCString travelDepartureAirportSegment1;
	OCString airCarrierCodeSegment1;
	OCString flightNumberSegment1;
	OCString classCodeSegment1;
	OCString travelDepartureDateSegment2;
	OCString travelDestinationCodeSegment2;
	OCString travelDepartureAirportSegment2;
	OCString airCarrierCodeSegment2;
	OCString flightNumberSegment2;
	OCString classCodeSegment2;
	OCString travelDepartureDateSegment3;
	OCString travelDestinationCodeSegment3;
	OCString travelDepartureAirportSegment3;
	OCString airCarrierCodeSegment3;
	OCString flightNumberSegment3;
	OCString classCodeSegment3;
	OCString travelDepartureDateSegment4;
	OCString travelDestinationCodeSegment4;
	OCString travelDepartureAirportSegment4;
	OCString airCarrierCodeSegment4;
	OCString flightNumberSegment4;
	OCString classCodeSegment4;
	OCString lodgingCheckInDate;
	OCString lodgingCheckOutDate;
	OCString lodgingRoomRate1;
	OCString numberOfNightsAtRoomRate1;
	OCString lodgingName;
	OCString lodgingRegionCode;
	OCString lodgingCountryCode;
	OCString lodgingCityName;
};


class ShcTravelCruise
{
	char buff[1300];
	int len;
	public:
	ShcTravelCruise();
	void setTagValue(char *TagName, const char *TagValue);
	void setTagValue(char *TagName, int TagValue);
	void setTagValue(char *TagName, double TagValue);
	char* getBuffer();
	int getBufferLength();
};

#endif
