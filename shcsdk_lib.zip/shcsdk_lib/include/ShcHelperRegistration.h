#ifndef _SHCHELPERREGISTRATION_H_
#define _SHCHELPERREGISTRATION_H_

static char _ShcHelperRegistration_h_what[] = "@(#) ShcHelperRegistration.h 1.2 08/05/23 06:04:09";
/*
 *  Copyright (C) 2004 eFunds Corporation ("eFunds").  All Rights Reserved.     
 *  eFunds Canada Corporation is an authorized user.                            
 *                                                                              
 *  IST is a registered trademark of eFunds Corporation.  Other brand or        
 *  product names are trademarks or registered trademarks of their respective   
 *  holders.                                                                    
 *                                                                              
 *  The information contained herein is the unpublished proprietary property    
 *  of eFunds.  Except as specifically authorized in writing by eFunds, the     
 *  holder of this document shall: i) keep all information contained herein     
 *  confidential, and ii) protect the information, in whole or in part, from    
 *  disclosure and dissemination to all third parties.                          
 *                                                                          
 *  This document and the software described in it are furnished under license  
 *  and may be used or copied only in accordance with the terms of such license.
 *  This document is supplied for information purposes only, is subject to      
 *  change without notice, and should not be construed as a commitment by       
 *  either eFunds Corporation or eFunds Canada Corporation. 
 *
 *                        MODIFICATION HISTORY                  REVIEW
 *
 * SCR#     Who    Date  Description
 * ===========================================================================
 * R0xxxxx 
 * R023231  Ram  23May08 The SDK header should refer to external header
 */


#include <oasis.h>
#include <ShcBaseTxn.h>
#include <ShcHelperFactory.h>
#include <SdkRegistration.h>
#include <ShcHelperBase.h>	//	---	R023231

class ShcHelperRegistration : public Registration <ShcHelperBase, ShcHelperFactory>
{
public:
	ShcHelperRegistration(char *objName):
		Registration <ShcHelperBase, ShcHelperFactory>(objName)
	{};
	
};

#endif
