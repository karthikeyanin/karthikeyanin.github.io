/*
 *  Copyright (C) 2004 eFunds Corporation ("eFunds").  All Rights Reserved.
 *  eFunds Canada Corporation is an authorized user.
 *
 *  IST is a registered trademark of eFunds Corporation.  Other brand or
 *  product names are trademarks or registered trademarks of their respective
 *  holders.
 *
 *  The information contained herein is the unpublished proprietary property
 *  of eFunds.  Except as specifically authorized in writing by eFunds, the
 *  holder of this document shall: i) keep all information contained herein
 *  confidential, and ii) protect the information, in whole or in part, from
 *  disclosure and dissemination to all third parties.
 *
 *  This document and the software described in it are furnished under license
 *  and may be used or copied only in accordance with the terms of such license.
 *  This document is supplied for information purposes only, is subject to
 *  change without notice, and should not be construed as a commitment by
 *  either eFunds Corporation or eFunds Canada Corporation.
 *
 */

/*
 *                              Modification History
 *
 *      Who             When            Why
 *      ===================================================================
 */

#ifndef __IST_DISPATCHER_SHCDATA_H__
#define __IST_DISPATCHER_SHCDATA_H__

#include <shc.h>
#include <istdispatcher_data.h>
#include <istsafe.h>

#define SHC 0
#define DISPATCH_POINT_BUSIMON	"busimon"

static char _istdispatcher_shcdata_h_what[] = "@(#) istdispatcher_shcdata.h 1.3 19/12/16 15:16:08";


class IstShcDispatcherMsgData : public IstDispatcherMsgData
{
	private:
		struct shcmsg mShcMsg ;
		char mSegment[ SHC_SEG_MAX+1 ];	
		int mMsgSize ;
		
	public:
		IstShcDispatcherMsgData()
		{
			clearBuf();
		}

		static int dispatch(const char *dispatchPoint, struct shcmsg *msg, int len);
		static int dispatch(const char *dispatchPoint, const char *logId, int msgtype, int respcode, const char *txnSrc=NULL, const char *acquirer=NULL, const char *txnDest=NULL, const char *issuer=NULL);
		void clearBuf()
		{
			memset( &mShcMsg, 0, sizeof( struct shcmsg ) );
			memset( &mSegment, 0, SHC_SEG_MAX );
			mMsgSize = 0 ;
		}

		void Set( char * aMsgBuf, int aMsgSize )
		{
			memcpy( &mShcMsg, aMsgBuf, sizeof( struct shcmsg ) );

			if ( (aMsgSize > sizeof(struct shcmsg)) && (sizeof(mSegment) >= (aMsgSize - sizeof(struct shcmsg))) )
				memcpy( mSegment, aMsgBuf+sizeof( struct shcmsg ), (IstSafeInt(aMsgSize) - sizeof( struct shcmsg )).getInt() );

			mMsgSize = aMsgSize ;
		}

		char * Data()
		{
			return ( char * ) &mShcMsg ;
		}

		int Len()
		{
			return ( mMsgSize );
		}

		int Id()
		{
			return SHC;
		}

		void Dump()
		{
			dump_hex( ( unsigned char * ) &mShcMsg, mMsgSize );
		}

		~IstShcDispatcherMsgData(){}
};


#endif
