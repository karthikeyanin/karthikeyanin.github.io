#ifndef _SHCBALANCER_H_
#define _SHCBALANCER_H_

static char _ShcBalancer_h_what[] = "@(#) ShcBalancer.h 1.4 07/05/25 12:22:41";

/*
 *  Copyright (C) 2004 eFunds Corporation ("eFunds").  All Rights Reserved.     
 *  eFunds Canada Corporation is an authorized user.                            
 *                                                                              
 *  IST is a registered trademark of eFunds Corporation.  Other brand or        
 *  product names are trademarks or registered trademarks of their respective   
 *  holders.                                                                    
 *                                                                              
 *  The information contained herein is the unpublished proprietary property    
 *  of eFunds.  Except as specifically authorized in writing by eFunds, the     
 *  holder of this document shall: i) keep all information contained herein     
 *  confidential, and ii) protect the information, in whole or in part, from    
 *  disclosure and dissemination to all third parties.                          
 *                                                                          
 *  This document and the software described in it are furnished under license  
 *  and may be used or copied only in accordance with the terms of such license.
 *  This document is supplied for information purposes only, is subject to      
 *  change without notice, and should not be construed as a commitment by       
 *  either eFunds Corporation or eFunds Canada Corporation. 
 *
 *                        MODIFICATION HISTORY                  REVIEW
 *
 * SCR#     Who    Date  Description
 * ===========================================================================
 * R0xxxxx ztang 23Oct03 Creation
 * R016305 20Apr06 Log actual response code in security log
 */
 

//#include <ShcSdkCommon.h>
//#include <ShcmsgHeader.h>
#include <ShcHelperBase.h>

class ShcmsgHeader;

struct s_RoundRobinBalInfo
{
	long lastTime;
	long count;
};

class ShcBalancer : public ShcHelperBase
{
protected:
	ShcmsgHeader *header;
	struct shcpkg **pkgs;
	int num;
	int pkgi;
	virtual int findPkgs(char **bins, int n);
	virtual int choosePkg();
	int fit(int n);
	int copyPkgs(struct shcpkg **bins, int n);


public:
    const char *getName();
    
    ShcBalancer();
    
    void setShcmsgHeader(ShcmsgHeader *_header)
    {
    	header = _header;
    }
	
	virtual int chooseBin(char **bins, int n);
	virtual int chooseBin(struct shcpkg **bins, int n);
	virtual int toString(struct shcpkg *pkg, char *buf, int size);

};

#endif

