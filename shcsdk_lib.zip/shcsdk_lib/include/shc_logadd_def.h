/*
 *  Copyright (C) 2004 eFunds Corporation ("eFunds").  All Rights Reserved.     
 *  eFunds Canada Corporation is an authorized user.                            
 *                                                                              
 *  IST is a registered trademark of eFunds Corporation.  Other brand or        
 *  product names are trademarks or registered trademarks of their respective   
 *  holders.                                                                    
 *                                                                              
 *  The information contained herein is the unpublished proprietary property    
 *  of eFunds.  Except as specifically authorized in writing by eFunds, the     
 *  holder of this document shall: i) keep all information contained herein     
 *  confidential, and ii) protect the information, in whole or in part, from    
 *  disclosure and dissemination to all third parties.                          
 *                                                                          
 *  This document and the software described in it are furnished under license  
 *  and may be used or copied only in accordance with the terms of such license.
 *  This document is supplied for information purposes only, is subject to      
 *  change without notice, and should not be construed as a commitment by       
 *  either eFunds Corporation or eFunds Canada Corporation. 
 */
/*
#pragma ident "@(#) shc_logadd_def.h 1.1 04/06/07 16:36:01"
 *
 *                        MODIFICATION HISTORY                  REVIEW
 *
 *	SPR#	Who	Date	Description			Who	Date   
 * ===========================================================================
 * R006621	hsh	30Aug01	Create file to support segments with industry
 *						specific data or cheque data (from POS)
 */

#ifndef	SHC_LOG_ADD
#define SHC_LOG_ADD

#if !defined( SHCDLLEXPORT )
#	if defined( WIN32 )
#		define SHCDLLEXPORT __declspec(dllimport)
#	else
#		define SHCDLLEXPORT
#	endif
#endif


SHCDLLEXPORT	extern	int shc_logadd_open();
SHCDLLEXPORT	extern	int shc_logadd_fillrec( register struct shc *shcmsg );
SHCDLLEXPORT	extern	int shc_logadd_insert(struct shc *shcmsg);
SHCDLLEXPORT	extern	int shc_logadd_update(struct shc *shcmsg);

SHCDLLEXPORT	extern	int shc_logchq_open();
SHCDLLEXPORT	extern	int shc_logchq_fillrec( register struct shc *shcmsg );
SHCDLLEXPORT	extern	int shc_logchq_insert(struct shc *shcmsg);
SHCDLLEXPORT	extern	int shc_logchq_update(struct shc *shcmsg);

#define	SHC_INDSPE_SEG	"INDUSTRY_SPECIFIC_DATA"
#define	SHC_CHEQUE_SEG	"CHEQUE_DATA"

#define	SHC_LOGSEG	0x0001

#define	SHC_LOGSEG_INSERT	0x0001
#define	SHC_LOGSEG_UPDATE	0x0002

#endif
