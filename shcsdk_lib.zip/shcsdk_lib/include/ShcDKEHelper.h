#ifndef DSWITCH
#define DSWITCH
#endif

#ifndef _SHCDKEHELPER_H_
#define _SHCDKEHELPER_H_

static char _ShcDKEHelper_h_what[] = "@(#) ShcDKEHelper.h 1.8 06/12/07 11:37:26";

/*
 *  Copyright (C) 2004 eFunds Corporation ("eFunds").  All Rights Reserved.     
 *  eFunds Canada Corporation is an authorized user.                            
 *                                                                              
 *  IST is a registered trademark of eFunds Corporation.  Other brand or        
 *  product names are trademarks or registered trademarks of their respective   
 *  holders.                                                                    
 *                                                                              
 *  The information contained herein is the unpublished proprietary property    
 *  of eFunds.  Except as specifically authorized in writing by eFunds, the     
 *  holder of this document shall: i) keep all information contained herein     
 *  confidential, and ii) protect the information, in whole or in part, from    
 *  disclosure and dissemination to all third parties.                          
 *                                                                          
 *  This document and the software described in it are furnished under license  
 *  and may be used or copied only in accordance with the terms of such license.
 *  This document is supplied for information purposes only, is subject to      
 *  change without notice, and should not be construed as a commitment by       
 *  either eFunds Corporation or eFunds Canada Corporation. 
 *
 *                        MODIFICATION HISTORY                  REVIEW
 *
 * SCR#     Who    Date  Description
 * ===========================================================================
 * R0xxxxx ztang 23Oct03 Creation
 * R016305 20Apr06 Log actual response code in security log
 * R018352 30Nov06 Removed function overthreshold
 */
 

#include <shcextbuf.h>
#include <ShcSdkCommon.h>
#include <ShcmsgHeader.h>
#include <ShcHelperBase.h>

class ShcDKEHelper : public ShcHelperBase
{
protected:
	virtual int netid_to_trigid(char *issbin, char *nettrigid, size_t nettrigid_size);
public:
    const char *getName()
    {
        return (const char *)SHC_ShcDKEHelper;
    }

	virtual int shc_inc_kpecnt(bin_t issbin);
	virtual int shc_reset_kpecnt(bin_t issbin);
	virtual int shc_inc_kpeisscnt(bin_t issbin);
	virtual int shc_reset_kpeisscnt(bin_t issbin);
	virtual int shc_inc_pinerrcnt(bin_t issbin);
	virtual int shc_inc_pinerrcnt_x( ShcmsgHeader *header );
	virtual int shc_reset_pinerrcnt(bin_t issbin);
	virtual int shc_inc_kmaccnt(bin_t issbin);
	virtual int shc_reset_kmaccnt(bin_t issbin);
	virtual int shc_inc_macerrcnt(bin_t issbin);
	virtual int shc_inc_macerrcnt_x( ShcmsgHeader *header );
	virtual int shc_inc_macerrcnt( ShcmsgHeader *header, int respcode );
	virtual int shc_reset_macerrcnt(bin_t issbin);
	virtual int shc_inc_kmecnt(bin_t issbin);
	virtual int shc_reset_kmecnt(bin_t issbin);
	virtual int shc_inc_cmstocnt(bin_t issbin);
	virtual int shc_inc_cmstocnt_x( ShcmsgHeader *header );
	virtual int shc_reset_cmstocnt(bin_t issbin);
	virtual int shc_inc_keyrjtcnt(bin_t issbin);
	virtual int shc_inc_keyrjtcnt_x( ShcmsgHeader *header );
	virtual int shc_reset_keyrjtcnt(bin_t issbin);
	virtual int shc_inc_amerrcnt(bin_t issbin);
	virtual int shc_inc_amerrcnt_x( ShcmsgHeader *header );
	virtual int shc_inc_amerrcnt( ShcmsgHeader *header, int respcode );
	virtual int shc_reset_amerrcnt(bin_t issbin);
	virtual int shc_inc_akconverrcnt(bin_t issbin);
	virtual int shc_inc_akconverrcnt_x( ShcmsgHeader *header );
	virtual int shc_reset_akconverrcnt(bin_t issbin);
	virtual int shc_inc_akpesyncerrcnt(bin_t issbin);
	virtual int shc_inc_akpesyncerrcnt_x( ShcmsgHeader *header );
	virtual int shc_reset_akpesyncerrcnt(bin_t issbin);
	virtual int shc_inc_akmacsyncerrcnt(bin_t issbin);
	virtual int shc_inc_akmacsyncerrcnt_x( ShcmsgHeader *header );
	virtual int shc_inc_akmacsyncerrcnt_x( ShcmsgHeader *header, int respcode );
	virtual int shc_reset_akmacsyncerrcnt(bin_t issbin);
	virtual int shc_inc_akmesyncerrcnt(bin_t issbin);
	virtual int shc_inc_akmesyncerrcnt_x( ShcmsgHeader *header );
	virtual int shc_reset_akmesyncerrcnt(bin_t issbin);
	virtual int shc_tracein(char *funcname);
	virtual int shc_inc_imerrcnt(bin_t acqbin);
	virtual int shc_inc_imerrcnt_x( ShcmsgHeader *header );
	virtual int shc_reset_imerrcnt(bin_t acqbin);
	virtual int shc_inc_ikconverrcnt(bin_t acqbin);
	virtual int shc_inc_ikconverrcnt_x( ShcmsgHeader *header );
	virtual int shc_reset_ikconverrcnt(bin_t acqbin);
	virtual int shc_inc_ikpesyncerrcnt(bin_t acqbin);
	virtual int shc_inc_ikpesyncerrcnt_x( ShcmsgHeader *header );
	virtual int shc_reset_ikpesyncerrcnt(bin_t acqbin);
	virtual int shc_inc_ikmacsyncerrcnt(bin_t acqbin);
	virtual int shc_inc_ikmacsyncerrcnt_x( ShcmsgHeader *header );
	virtual int shc_reset_ikmacsyncerrcnt(bin_t acqbin);
	virtual int shc_inc_ikmesyncerrcnt(bin_t acqbin);
	virtual int shc_inc_ikmesyncerrcnt_x( ShcmsgHeader *header );
	virtual int shc_reset_ikmesyncerrcnt(bin_t acqbin);
	virtual int shc_reset_dynamic_keys( bin_t networkid, char key_type );
	virtual int shc_hsmerror_log( struct shcmsg *msg, char *loginfo );
	virtual int shc_hsmerror_log( struct shcmsg *msg, char *loginfo, int respcode );
	virtual int shc_traceout(char *funcname);
	virtual int shc_reset_pinkey_timer(bin_t issbin);
	virtual int shc_reset_mackey_timer(bin_t issbin);

};

#endif

