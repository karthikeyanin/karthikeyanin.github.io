/*
 *  Copyright (C) 2004 eFunds Corporation ("eFunds").  All Rights Reserved.     
 *  eFunds Canada Corporation is an authorized user.                            
 *                                                                              
 *  IST is a registered trademark of eFunds Corporation.  Other brand or        
 *  product names are trademarks or registered trademarks of their respective   
 *  holders.                                                                    
 *                                                                              
 *  The information contained herein is the unpublished proprietary property    
 *  of eFunds.  Except as specifically authorized in writing by eFunds, the     
 *  holder of this document shall: i) keep all information contained herein     
 *  confidential, and ii) protect the information, in whole or in part, from    
 *  disclosure and dissemination to all third parties.                          
 *                                                                          
 *  This document and the software described in it are furnished under license  
 *  and may be used or copied only in accordance with the terms of such license.
 *  This document is supplied for information purposes only, is subject to      
 *  change without notice, and should not be construed as a commitment by       
 *  either eFunds Corporation or eFunds Canada Corporation. 
 *                    
 *  #pragma ident "@(#) shcchiplog.sql 1.9.1.1 16/10/21 10:11:28"
 */
 
/*
 *				Modification History
 *
 *	Who		When		Why
 *	===================================================================
 *  Mch     18Feb00     Original Version  on 7.1.3 (2007336)
 *  Mch     18Feb00     Changed chip_index data type on 7.1.3 (2007336)
 * R004671  Dds 23Jun00 Merge vsdc enhancement to 7.2,new file,refer to 2007336
 * R007416  emj 12Feb02 Added Field for Issuer application Data 9F10
 * R012339  Emj 08Nov04 Emv buffer Bitmap
 * R012381  Emj 12Nov04 Added field tvr_cvr_status
 * R014452  Emj 28Jul05 Added field issuer_auth_data   
 */

create table shcchiplog (
	chip_index				char(20) not null,
	term_txn_date			date,					
	cvv_res_code			char(1),
	card_auth_res_code		char(1),	
	term_type				smallint,	
	term_entry_cap			smallint,	
	chip_cond_code			smallint,	
	ccps_txn_ind			smallint,	
	card_auth_rel_ind 		smallint,	
	msg_reason_code 		smallint,	
	deri_key_idx 			smallint,	
	crypto_version 			smallint,			
	crypto_txn_type 		smallint,			
	term_country_code 		smallint,
	crypto_curr_code		smallint,	
	neg_file_version		smallint,	
	ccard_pa_trace			smallint,	
	ccard_purch_trace		smallint,
	ccard_crypto_trace		smallint,
	mcard_batch_trace		smallint,		
	mcard_txn_trace			smallint,		
	crypto_amount 			money,				
	crypto_cb_amount 		money,			
	srv_restrict_code 		char(3), 
    term_cap_profile 		char(6),			
	tvr			  			char(10),		
	unpredictable_num 		char(8),	
	term_ser_num 			char(8),	
	cvr						char(6),			
	issuer_discre_data		char(32),		
	cryptogram				char(16),
	app_txn_counter 		char(4),			
	app_ichg_profile 		char(4),			
	arpc_cryptogram 		char(16),	
	arpc_respcode 			char(2),			
	issuer_script_res 		char(40),			
	ccard_sch_crypto 		char(16),
	issuer_app_data         char(64),
	bitmap                  int,
	tvr_cvr_status          char,
	issuer_auth_data		char(32),
	site_id			smallint
	);

create unique index shcchiplog_1 on shcchiplog (chip_index,site_id)

GG_PARAM shcchiplog
(
);

