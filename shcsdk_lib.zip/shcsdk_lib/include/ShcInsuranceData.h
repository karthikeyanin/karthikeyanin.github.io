#ifndef _SHC_INSURANCEDATA_H_
#define _SHC_INSURANCEDATA_H_

static char _shc_insuranceData_h_what[] = "@(#) shc_insuranceData.h 1.0 15/11/21 15:22:34";

/*
 *  Copyright (C) 2004 eFunds Corporation ("eFunds").  All Rights Reserved.     
 *  eFunds Canada Corporation is an authorized user.                            
 *                                                                              
 *  IST is a registered trademark of eFunds Corporation.  Other brand or        
 *  product names are trademarks or registered trademarks of their respective   
 *  holders.                                                                    
 *                                                                              
 *  The information contained herein is the unpublished proprietary property    
 *  of eFunds.  Except as specifically authorized in writing by eFunds, the     
 *  holder of this document shall: i) keep all information contained herein     
 *  confidential, and ii) protect the information, in whole or in part, from    
 *  disclosure and dissemination to all third parties.                          
 *                                                                          
 *  This document and the software described in it are furnished under license  
 *  and may be used or copied only in accordance with the terms of such license.
 *  This document is supplied for information purposes only, is subject to      
 *  change without notice, and should not be construed as a commitment by       
 *  either eFunds Corporation or eFunds Canada Corporation. 
 *
 *
 *                        MODIFICATION HISTORY                  REVIEW
 *
 * SCR#     Who    Date  Description
 * ===========================================================================
 * R0xxxxx 
 */
 
struct ShcInsuranceDataFields
{
	OCString policyType;
	OCString coveragePeriod;
	OCString coverageDates;
	OCString insuranceChargeType;
	OCString policyNumber;
	OCString coverageStartDate;
	OCString coverageEndDate;
	OCString premiumFrequency;
	OCString additionalPolicyNumber;
	OCString nameOfInsured;
};

class ShcInsuranceData
{
	char buff[1300];
	int len;
public:
	ShcInsuranceData();
	void setTagValue(char *TagName, const char *TagValue);
	void setTagValue(char *TagName, int TagValue);
	void setTagValue(char *TagName, double TagValue);
	char* getBuffer();
	int getBufferLength();
};

#endif

