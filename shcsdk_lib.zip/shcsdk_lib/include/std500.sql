/*
 *  Copyright (C) 2004 eFunds Corporation ("eFunds").  All Rights Reserved.     
 *  eFunds Canada Corporation is an authorized user.                            
 *                                                                              
 *  IST is a registered trademark of eFunds Corporation.  Other brand or        
 *  product names are trademarks or registered trademarks of their respective   
 *  holders.                                                                    
 *                                                                              
 *  The information contained herein is the unpublished proprietary property    
 *  of eFunds.  Except as specifically authorized in writing by eFunds, the     
 *  holder of this document shall: i) keep all information contained herein     
 *  confidential, and ii) protect the information, in whole or in part, from    
 *  disclosure and dissemination to all third parties.                          
 *                                                                          
 *  This document and the software described in it are furnished under license  
 *  and may be used or copied only in accordance with the terms of such license.
 *  This document is supplied for information purposes only, is subject to      
 *  change without notice, and should not be construed as a commitment by       
 *  either eFunds Corporation or eFunds Canada Corporation.                     
 */

create table std500 
    (
     msgtype int,
     trace int,
     trandate date,
     trantime int,
     flags int,
     settlement_date date,
     forward_inst char(10) null,
     issuer char(10) null,
     acquirer char(10) null,
     settlement_agent char(10) null,
     currency_code smallint,
     advice_reason int,
     respcode int,
     serial_number int,
     network_data char(30) null,
     num_credit int,
     num_credit_rev int,
     num_debit int,
     num_debit_rev int,
     num_transfer int,
     num_transfer_rev int,
     num_inquiry int,
     num_auth int,
     num_auth_rev int,
     fee_cr_processing money,
     fee_cr_transaction money,
     fee_db_processing money,
     fee_db_transaction money,
     amt_credit money,
     amt_credit_rev money,
     amt_debit money,
     amt_debit_rev money,
     amt_auth money,
     amt_auth_rev money,
     amt_netset money,
	 o_rowid int,
	 shclog_id             char(20) not null,
    site_id    smallint	
    )




/*oasis is owner of index std500_1*/
create index std500_1 on std500 (msgtype, issuer, settlement_date)
create index std500_rid on std500 (o_rowid)
create unique index std500_uix on std500 (shclog_id,site_id)

GG_PARAM std500
(
);

