//
// Copyright (C) 2009 eFunds Corporation ("eFunds").  All Rights Reserved.
// eFunds Canada Corporation is an authorized user.
//
// IST is a registered trademark of eFunds Corporation.  Other brand or
// product names are trademarks or registered trademarks of their respective
// holders.
//
// The information contained herein is the unpublished proprietary property
// of eFunds.  Except as specifically authorized in writing by eFunds, the
// holder of this document shall: i) keep all information contained herein
// confidential, and ii) protect the information, in whole or in part, from
// disclosure and dissemination to all third parties.
//
// This document and the software described in it are furnished under license
// and may be used or copied only in accordance with the terms of such license.
// This document is supplied for information purposes only, is subject to
// change without notice, and should not be construed as a commitment by
// either eFunds Corporation or eFunds Canada Corporation.
//
/*
 * Description:
 *
 *      MODIFICATION HISTORY
 *
 *  Date         SCR            Who        Description
 *  ===========================================================================
*/
#ifndef _SHC_RAILDATA_H_
#define _SHC_RAILDATA_H_

static char _shc_railData_h_what[] = "@(#) shc_railData.h 1.0 08/02/22 15:22:34";
struct ShcRailDataFields
{
	OCString transactionType;
	OCString ticketNumber;
	OCString passengerName;
	OCString iataCarrierCode;
	OCString ticketIssuerName;
	OCString ticketIssueCity;
	OCString departureStation1;
	OCString departureDate1;
	OCString arrivalStation1;
	OCString departureStation2;
	OCString departureDate2;
	OCString arrivalStation2;
	OCString departureStation3;
	OCString departureDate3;
	OCString arrivalStation3;
	OCString departureStation4;
	OCString departureDate4;
	OCString arrivalStation4;
	OCString departureStation5;
	OCString departureDate5;
	OCString arrivalStation5;
	OCString departureStation6;
	OCString departureDate6;
	OCString arrivalStation6;
};


class ShcRailData
{
	char buff[1300];
	int len;
public:
	ShcRailData();
	void setTagValue(char *TagName, const char *TagValue);
	void setTagValue(char *TagName, int TagValue);
	void setTagValue(char *TagName, double TagValue);
	char* getBuffer();
	int getBufferLength();
};

#endif
