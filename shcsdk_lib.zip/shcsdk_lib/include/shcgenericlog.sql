/*
 *  Copyright (C) 2004 eFunds Corporation ("eFunds").  All Rights Reserved.     
 *  eFunds Canada Corporation is an authorized user.                            
 *                                                                              
 *  IST is a registered trademark of eFunds Corporation.  Other brand or        
 *  product names are trademarks or registered trademarks of their respective   
 *  holders.                                                                    
 *                                                                              
 *  The information contained herein is the unpublished proprietary property    
 *  of eFunds.  Except as specifically authorized in writing by eFunds, the     
 *  holder of this document shall: i) keep all information contained herein     
 *  confidential, and ii) protect the information, in whole or in part, from    
 *  disclosure and dissemination to all third parties.                          
 *                                                                          
 *  This document and the software described in it are furnished under license  
 *  and may be used or copied only in accordance with the terms of such license.
 *  This document is supplied for information purposes only, is subject to      
 *  change without notice, and should not be construed as a commitment by       
 *  either eFunds Corporation or eFunds Canada Corporation. 
 *                    
 *  #pragma ident "@(#) shcgenericlog.sql 1.5.1.1 16/10/21 10:12:11";
 */
 
/*
* Modification History
*
* SCR		Date	Who	Why
* ========================================================================
*  				
*/

create table shcgenericlog (
	switch_date date,
	log_id		char(20) not null,
	msgtype	int,
	reqresp		char(1),
	field1		varchar(512),
	field2		varchar(512),
	field3		varchar(512),
	field4		varchar(512),
	field5		varchar(512),
	field6		varchar(512),
	field7		varchar(512),
	field8		varchar(512),
	field9		varchar(512),
	field10		varchar(512),
	field11		varchar(512),
	field12		varchar(512),
	field13		varchar(512),
	field14		varchar(512),
	field15		varchar(512),
	field16		varchar(512),
	field17		varchar(512),
	field18		varchar(512),
	field19		varchar(512),
	field20		varchar(512),
	field21		varchar(512),
	field22		varchar(512),
	field23		varchar(512),
	field24		varchar(512),
	field25		varchar(512),
	field26		varchar(512),
	field27		varchar(512),
	field28		varchar(512),
	field29		varchar(512),
	field30		varchar(512),
	field31		varchar(512),
	field32		varchar(512),
	field33		varchar(512),
	field34		varchar(512),
	field35		varchar(512),
	field36		varchar(512),
	field37		varchar(512),
	field38		varchar(512),
	field39		varchar(512),
	field40		varchar(512),
	binfield1	varbinary(2000),
	binfield2	varbinary(2000),
	binfield3	varbinary(2000),
	binfield4	varbinary(2000),
	binfield5	varbinary(2000),
	site_id		smallint
)


create unique index shcgenericlog_1 on shcgenericlog (log_id, reqresp, site_id)
create index shcgenericlog_2 on shcgenericlog (switch_date)

GG_PARAM shcgenericlog
(
);

