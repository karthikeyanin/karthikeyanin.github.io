//
// Copyright (C) 2004 eFunds Corporation ("eFunds").  All Rights Reserved.
// eFunds Canada Corporation is an authorized user.
//
// IST is a registered trademark of eFunds Corporation.  Other brand or
// product names are trademarks or registered trademarks of their respective
// holders.
//
// The information contained herein is the unpublished proprietary property
// of eFunds.  Except as specifically authorized in writing by eFunds, the
// holder of this document shall: i) keep all information contained herein
// confidential, and ii) protect the information, in whole or in part, from
// disclosure and dissemination to all third parties.
//
// This document and the software described in it are furnished under license
// and may be used or copied only in accordance with the terms of such license.
// This document is supplied for information purposes only, is subject to
// change without notice, and should not be construed as a commitment by
// either eFunds Corporation or eFunds Canada Corporation.
//
 /*
 *  Date    SCR     Who     Description
 *  ===========================================================================
 *
 *
 */

#ifndef __shc_genericlog_binary_h_
#define __shc_genericlog_binary_h_ 1

static char _shc_genericlog_binary_h_what[] = "@(#) ShcGenericLogBinary.h 1.1.1.1 12/01/30 01:03:43";

#include <CShcGenericLog.h>
#include <DBM3.h>
#include <ShcmsgHeader.h>
#include <ist_seg_list.h>

class ShcGenericLogBinary : public ShcGenericLog
{
	protected:

		int SHC_GENERIC_LOG_BINARY_FIELD_NUM;
		char *valueBuf;
		int valueBufLen;
		int shcGenericLogBinaryFieldSize;
		DBMHSTMT shUpdate;
		int map76seg; // R030273


	public:

		ShcGenericLogBinary();
    	virtual const char *getName()
		{
			return (const char *)"ShcGeneric_logBinary";
		}

		virtual void initialize();
		virtual void fillSegment(ShcmsgHeader *header, char *logHeader, int *logHeaderLen);
		virtual void insert();
		virtual IstSegList *restore(ShcmsgHeader *header, char _reqresp, char *reqBufHeader, int reqBufHeaderLen, char *respBufHeader, int respBufHeaderLen);
		virtual void update();
		~ShcGenericLogBinary();
};

#endif
