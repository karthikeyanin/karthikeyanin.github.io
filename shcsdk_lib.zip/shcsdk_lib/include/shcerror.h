/*
 *	IST and IST/Share are registered trademarks of Oasis Technology Ltd.
 *
 *	Copyright (C) 1990 - 1997 Oasis Technology Ltd.
 *	All Rights Reserved
 *	This Module contains Proprietary Information of
 *	Oasis Technology Ltd., and should be treated as Confidential.
 *
 *	THIS IS UNPUBLISHED PROPRIETARY SOURCE CODE OF OASIS TECHNOLOGY LTD.
 *	The copyright notice above does not evidence any
 *	actual or intended publication of such source code.
 */
/*
#pragma ident "@(#) shcerror.h 2.31.15.1 20/01/27 05:46:14";
 *
 *    MODIFICATION HISTORY                  REVIEW
 *
 *	SPR#	Who	Date	Description			Who	Date
 * ===========================================================================
 * 10002273 la  19aug96 Added response code for IBFT transactions
 * ACXSYS   qd  01dec97 Added new codes and re-organized the contents
 * R003531	rlo	04Feb00	Added response code for CVV2 failure
 * R004368	jsun	10Apr00	Added SHC_RC_NoCreditAccount & SHC_RC_ViolationLaw
 * R004984	lsun04Aug00	Added SHC_RC_UnsolicitedReversal &
 *						SHC_RC_DuplicateTransmission
 *R007636 ztang 27Mar02 Added new response code SHC_RC_ExceedCashbackLimit
 *R009893 jyang 17Sep03 Support stop recurring and installment payment
 *R010978 hsh	04Jun04	Add BNA response and reason codes
 *R011799 lsun	09Sep04	Add new response code requested by Visa
 *R020938 spa	16Aug07	Added response codes for IST LM Bridge
 *R022506 lee	04Feb08 Added response codes for Discover Interface
 *R022717 lee	06Mar08 Added Definition SHC_RR_Successful in shcerror.h
 *R022738 ram	12Mar08 Added SHC_RC_PurchaseAmountOnly for MCDebit transactions
 *R025639 vmp	16Jan09	Added RC SHC_RC_Declined_On_FMTimeout for FM timeout
 *R027802 jyang 25Jan10 Added "Block by Brand" Support
 *R027905 dipa  25Mar10 Added "Reversal-Void" support
 *R028467 Ash	28Aug10 SHC_RC_PinNotChanged for MC & MDS Compliance OCT 2010
 *R028580 sks	27Sep10	Added SHC_RC_ChipTag_NotFound for Discover Compliance OCT 2010
 *R031980 sks	20Sep13	Added SHC_RC_OfflineDeclined,SHC_RC_UnableToGoOnline for Diners Compliance OCT 2013
 *IST_S_120107-12	sks	19Feb1d	Added SHC_RC_TvrCvrFailed for Diners Compliance Apr 2014
 */

#ifndef SHCERROR_INCLUDE
#define SHCERROR_INCLUDE

/*------------------------------------------------------------------------*
 * IST Response Codes
 *------------------------------------------------------------------------*/
#define	SHC_RC_Approved					0
#define SHC_RC_ReferCardIssuer			2
#define SHC_RC_InvalidMerchant			3
#define SHC_RC_DoNotHonor				4
#define SHC_RC_UnableToProcess			5
#define SHC_RC_InvalidTransactionTerm	6
#define SHC_RC_QRC_UPDATIPION                           7
#define SHC_RC_IssuerTimeout			8
#define SHC_RC_NoOriginal				9
#define SHC_RC_UnableToReverse          10
#define SHC_RC_InvalidPolicy            11   //New Error code for MC Invalid Policy
#define	SHC_RC_InvalidTransaction		12
#define SHC_RC_InvalidAmount			13		/*	sanctionable */
#define SHC_RC_InvalidCard				14		/*	no such number */
#define SHC_RC_No_FinancialImpact		15
#define SHC_RC_InvalidCaptureDate		17
#define	SHC_RC_SystemErrorReenter		19
#define SHC_RC_NoFromAccount			20
#define SHC_RC_NoToAccount				21
#define SHC_RC_NoCheckingAccount		22
#define SHC_RC_NoSavingAccount			23
#define SHC_RC_NoCreditAccount			24	/* R004368 */
#define SHC_RC_UnableLocateRecord		25
#define SHC_RC_MessageFormatError		30
#define SHC_RC_TransactionNotAllowed	39
#define SHC_RC_HotCard					41
#define	SHC_RC_SpecialPickup			42
#define SHC_RC_HotCardPickUp			43
#define SHC_RC_PickUpCard				44
#define SHC_RC_TxnBackOff				45
/* Ssc 29Jun00 R004671 VSDC 7.2 integration */
#define SHC_RC_ChipOffDeclined          46    /* Sli 29Feb00  for Chip card */
#define SHC_RC_ChipUnableOnline         47    /* Sli 29Feb00  for Chip card */
#define SHC_RC_ChipArqcFail             48 /* Rpc - 2007336 ARQC Validate Fail*/
#define SHC_RC_ChipTag_NotFound			49 /* R028580 Mandatory EMV tag missing */
/* Ssc end */
#define SHC_RC_NoFunds					51
#define SHC_RC_ExpiredCard				54
#define SHC_RC_IncorrectPIN				55
#define SHC_RC_NoCardRecord				56 /* qd 01dec97 ACXSYS */
#define SHC_RC_TxnNotPermittedOnCard	57
#define SHC_RC_TxnNotPermittedOnTerm	58 /* qd 01dec97 ACXSYS */
#define SHC_RC_SuspectedFraud			59 /* Apr 2007 Visa Comp 2.13 */
#define SHC_RC_Addl_Cust_ID_Reqd                60
#define SHC_RC_ExceedsLimit				61
#define SHC_RC_RestrictedCard			62
#define SHC_RC_MACKeyError				63
#define SHC_RC_TxnNotFulfillAMLReqmnt           64
#define SHC_RC_ExceedsFreqLimit			65
#define SHC_RC_ExceedsAcquirerLimit	    66 /* qd 01dec97 ACXSYS */
#define SHC_RC_RetainCard				67
#define SHC_RC_LateResponse				68
#define SHC_RC_ExceedsPINRetry			75
#define SHC_RC_InvalidAccount			76
#define SHC_RC_NoSharingArrangement		77
#define SHC_RC_FunctionNotAvailable		78
#define SHC_RC_KeyValidationError		79
#define	SHC_RC_PinLengthError			80	/* qd 01dec97 ACXSYS */
#define	SHC_RC_InvalidPinBlock			81	/* qd 01dec97 ACXSYS */
#define	SHC_RC_InvalidCVV				82
#define	SHC_RC_CounterSyncError			83	/* qd 01dec97 ACXSYS */
#define SHC_RC_InvalidLifeCycle			84
#define	SHC_RC_NoKeysToUse	     		85	/* qd 01dec97 ACXSYS */
#define	SHC_RC_KMESyncError	     		86	/* qd 01dec97 ACXSYS */
#define SHC_RC_PINKeyError				87
#define SHC_RC_MACSyncError				88
#define SHC_RC_SecurityViolation		89
#define SHC_RC_SwitchNotAvailable		91
#define SHC_RC_InvalidIssuer			92
#define SHC_RC_InvalidAcquirer			93
#define SHC_RC_InvalidOriginator		94
#define SHC_RC_ViolationLaw			95	/* R004368 */
#define SHC_RC_SystemError				96
#define	SHC_RC_NoFundsTransfer			97 /*Acct no funds during txf. 11Feb93*/
#define SHC_RC_DuplicateReversal		98
#define SHC_RC_DuplicateTransaction		99
#define SHC_RC_InvalidCountryCode               193 /*Amex GCAG AMEX GNS*/

/*
 *	ATM specify response code that I need .... Sunny
 */
#define SHC_RC_JptNoReceipt				101
#define SHC_RC_PartialDispense			102
#define SHC_RC_UnableDispense			103
#define	SHC_RC_LowReceipt				104
#define SHC_RC_RptNoReceipt				105
#define SHC_RC_DeviceTimeOut			106
#define SHC_RC_BothPrinter				107
#define SHC_RC_LowCash					108
#define SHC_RC_CustomerCancel			109
#define	SHC_RC_HiDispenserOut			110
#define	SHC_RC_LowDispenserOut			111
#define SHC_RC_UncertainDispense		112
#define SHC_RC_DepositError				113
#define SHC_RC_KeyReload				114
#define SHC_RC_CardRetract				115
#define SHC_RC_UndivisiableAmount		116
#define SHC_RC_TsfAmountZero			117
#define SHC_RC_IndivisibleAmount		118
#define SHC_RC_AmountTooLarge           119
#define SHC_RC_BNA_CancelOrTimeout      120	//	---	R010978
#define SHC_RC_BNA_DepositError         121	//	---	R010978
#define SHC_RC_BNA_DeviceInoperative    122	//	---	R010978
#define SHC_RC_BNA_NoBillsInEscrow      123	//	---	R010978
#define SHC_RC_BNA_BillsAtPowerUp       124	//	---	R010978
#define SHC_RC_BNA_UnableToMoveBills    125	//	---	R010978
#define SHC_RC_BNA_BillsRemainInEscrow  126	//	---	R010978
#define SHC_RC_BNA_DeviceFault          127	//	---	R010978
#define SHC_RC_BNA_VaultFull            128	//	---	R010978
#define SHC_RC_BNA_ReportedFault        129	//	---	R010978

#define SHC_RC_SurchargeAmtNotPermitted 131 // R011799
#define SHC_RC_SurchargeAmtNotSupported 132 // R011799
#define SHC_RC_OfflineDeclinedResubmnAllwd 133
#define SHC_RC_OfflineDeclined			140	//	R031980
#define SHC_RC_UnableToGoOnline			141	//	R031980
#define SHC_RC_TvrCvrFailed				198	//	IST_S_120107-12

#define SHC_RC_StrongAuthenticationRequired	130

//	>>>	R020938
#define SHC_RC_LMDeclined				150
#define SHC_RC_Declined_On_LMTimeout	151
#define SHC_RC_FMDeclined				152
//	<<<	R020938
#define SHC_RC_Declined_On_FMTimeout	153	//	---	R025639
#define SHC_RC_ODDeclined               154
#define SHC_RC_Declined_On_ODTimeout    155
#define SHC_RC_Declined_On_ODDown       156

#define SHC_RC_MismatchBatch			161 //R027905
#define SHC_RC_VoidedByAcquirer			162 //R027905
#define SHC_RC_ReversedByAcquirer		163 //R027905

#define SHC_RC_DomainRestCtrlFailure    183
#define SHC_RC_LostCard					200
#define	SHC_RC_AccountClosed			201
#define SHC_RC_AccountSuspended			202
#define SHC_RC_AccountCancelled			203
#define SHC_RC_AccountInactive			204
#define	SHC_RC_AccountPastDue30			205
#define	SHC_RC_AccountPastDue60			206
#define	SHC_RC_AccountPastDue90			207
#define	SHC_RC_TerminalAccessBar		208
#define	SHC_RC_InvalidTerminalId		209
#define	SHC_RC_UpdateLostCard			210
#define	SHC_RC_InvalidCheckDigit		211
#define	SHC_RC_HoldAndCallIssuer		212
#define SHC_RC_CallIssuer				213
#define	SHC_RC_OverCashAdvanceLimit		214
#define	SHC_RC_NegativeRecAdded			215
#define	SHC_RC_NegativeRecExisted		216
#define	SHC_RC_NegativeRecNotFound		217
#define SHC_RC_NegativeRecDeleted		218
#define	SHC_RC_CardDeclined				219
#define	SHC_RC_NegativeFileDeclined		220
#define	SHC_RC_OverPurchaseLimit		221
#define SHC_RC_MerchantClose			222
#define SHC_RC_OverAmountLimit			223
#define SHC_RC_Reconfirm				224
#define SHC_RC_TransferAccountsSame		225
#define SHC_RC_RemoteFileError			226
#define SHC_RC_CustomerFrozen			227
#define SHC_RC_PassbookLost				228
#define SHC_RC_NotIdentified			229
#define SHC_RC_OwnerDeceased			230
#define SHC_RC_AccountBlocked			231
#define SHC_RC_AccountReferCR			232
#define SHC_RC_AccountReferDR			233
#define SHC_RC_AccountReferAll			234
#define SHC_RC_AccountStopped			235
#define SHC_RC_DRLimitExpired			236
#define SHC_RC_ChequeStopped			237
#define SHC_RC_InsufficientFunds		238
#define SHC_RC_AfterBalanceError		239
#define SHC_RC_RecordLocked				240
#define SHC_RC_NoAccountTransaction		241
#define SHC_RC_OverdraftNotAllowed		242
#define SHC_RC_CurrencyMismatch			243
#define SHC_RC_BeyondEndOfDay			244
#define SHC_RC_ChequeNoUnknown			245
#define SHC_RC_CRLimitExceeded			246
#define SHC_RC_ODRequiresOverride		247
#define SHC_RC_LocationUnknown			248
#define SHC_RC_NoRelationship			249
#define SHC_RC_SpecialCard				250
#define SHC_RC_BadPinChange1			251
#define SHC_RC_BadPinChange2			252
#define SHC_RC_InvalidCardForDevice		253
#define SHC_RC_ExceedsTsfLimit			254

/* the next two limit exceeded codes are used when daily limit exceeded
   on first attempt (ie. customer has not used any of available limit
   but the transaction amount exceeds the allowed daily limit).
   11jul94
*/
#define SHC_RC_ExceedsLimit_1			255
#define SHC_RC_ExceedsLimit_2			256

/* Error codes for SAMBA -- limit validation */
#define	SHC_RC_GsExceedCardLimit					257
#define	SHC_RC_GsExceedProdLimit					258
#define	SHC_RC_GsExceedProdAmtUsed100Limit			259
#define	SHC_RC_GsExceedCardAmtUsed100Limit			260
#define	SHC_RC_GsExceedProdAmtAmtUsedLimit			261
#define	SHC_RC_GsExceedCardAmtAmtUsedLimit			262
#define	SHC_RC_WdExceedCardCombLimit				263
#define	SHC_RC_WdExceedProdCombLimit				264
#define	SHC_RC_WdExceedCardWdLimit					265
#define	SHC_RC_WdExceedProdWdLimit					266
#define	SHC_RC_WdExceedCardAmtUsed100CombLimit		267
#define	SHC_RC_WdExceedProdAmtUsed100CombLimit		268
#define	SHC_RC_WdExceedCardAmtUsed100WdLimit		269
#define	SHC_RC_WdExceedProdAmtUsed100WdLimit		270
#define	SHC_RC_WdExceedCardAmtAmtUsedCombLimit		271
#define	SHC_RC_WdExceedProdAmtAmtUsedCombLimit		272
#define	SHC_RC_WdExceedCardAmtAmtUsedWdLimit		273
#define	SHC_RC_WdExceedProdAmtAmtUsedWdLimit		274
#define	SHC_RC_TcExceedCardCombLimit				275
#define	SHC_RC_TcExceedProdCombLimit				276
#define	SHC_RC_TcExceedCardTcLimit					277
#define	SHC_RC_TcExceedProdTcLimit					278
#define	SHC_RC_TcExceedCardAmtUsed100CombLimit		279
#define	SHC_RC_TcExceedProdAmtUsed100CombLimit		280
#define	SHC_RC_TcExceedCardAmtUsed100TcLimit		281
#define	SHC_RC_TcExceedProdAmtUsed100TcLimit		282
#define	SHC_RC_TcExceedCardAmtAmtUsedCombLimit		283
#define	SHC_RC_TcExceedProdAmtAmtUsedCombLimit		284
#define	SHC_RC_TcExceedCardAmtAmtUsedTcLimit		285
#define	SHC_RC_TcExceedProdAmtAmtUsedTcLimit		286
#define	SHC_RC_TsfExceedCardTsfPayLimit				287
#define	SHC_RC_TsfExceedProdTsfPayLimit				288
#define	SHC_RC_ExceedsCardDepositUsedLimit			289
#define	SHC_RC_ExceedsProdDepositUsedLimit			290
#define	SHC_RC_TsfExceedCardAmtAmtUsedTsfPayLimit	291
#define	SHC_RC_TsfExceedProdAmtAmtUsedTsfPayLimit	292

#define	SHC_RC_TsfExceedCardTsfLimit				310
#define	SHC_RC_TsfExceedProdTsfLimit				311
#define	SHC_RC_ExceedsCardDepositLimit				312
#define	SHC_RC_ExceedsProdDepositLimit				313
#define	SHC_RC_TsfExceedCardAmtAmtUsedTsfLimit		314
#define	SHC_RC_TsfExceedProdAmtAmtUsedTsfLimit		315

#define	SHC_RC_TsfExceedCardUsdTxnLimit				293
#define	SHC_RC_ExceedsDepositLimit					294
#define	SHC_RC_TsfExceedProdUsdTxnLimit				295

#define	SHC_RC_TsfExceedCardStaffLimit				296
#define	SHC_RC_TsfExceedProdStaffLimit				297

/* end of error codes for limit validation */

#define SHC_RC_Adjustment				298
#define SHC_RC_TerminalGeneratedRev		299

/*	Internal inter-application error codes */
#define SHC_RC_InvalidServiceRequest	300
#define	SHC_RC_NoRecordFound			301
#define SHC_RC_StatusChangeAccepted		302
#define SHC_RC_StatusChangeRejected		303
#define SHC_RC_NotOnUsIssuer			304
#define SHC_RC_InvalidResponseCode      305						/* R001387 */
#define SHC_RC_ExceedCashbackLimit		306						/* R007636 */

/* codes 								310
 * 										...
 * to									315
 * are occupied
 */
#define SHC_RC_ExceedsFreqLimitCardWd	316
#define SHC_RC_ExceedsFreqLimitProdWd	317
#define SHC_RC_ExceedsFreqLimitCardTc	318
#define SHC_RC_ExceedsFreqLimitProdTc	319
#define	SHC_RC_TransferToStaff			320

#define	SHC_RC_StopPayment				330		/* R009893 */
#define	SHC_RC_RevocationAuth			331		/* R009893 */
#define SHC_RC_RevocationAllOrder		332

/*	Error codes for preauth. messages */
#define	SHC_RC_PreauthNoRequest			400		/* no original request */
#define SHC_RC_PreauthDuplicateComp		401		/*	duplicate confirmation */
#define SHC_RC_PreauthExpired			402		/*	expired preauth */
#define	SHC_RC_PreauthAmtExceeded		403		/*	comp. amt. > requested */
#define	SHC_RC_PreauthAmtAdjust			404		/*	comp. amt. < requested */
#define SHC_RC_PurchaseAmountOnly		405		//      ---     R022738

/*	Error codes for http response codes */
#define SHC_RC_HTTPRespBadRequest 			 421
#define SHC_RC_HTTPRespUnauthorized 		 422
#define SHC_RC_HTTPRespForbidden 			 423
#define SHC_RC_HTTPRespNotFound 			 424
#define SHC_RC_HTTPRespMethodNotAllowed 	 425
#define SHC_RC_HTTPRespUnsupportedMediaType	 426
#define SHC_RC_HTTPRespUnprocessableEntity	 427
#define SHC_RC_HTTPRespInternalServerError	 428
#define SHC_RC_HTTPRespBadGateway 			 429
#define SHC_RC_HTTPRespServiceUnavailable 	 430
#define SHC_RC_HTTPRespGatewayTimeout 		 431

/*	Error codes used by pre-authorization server */
#define SHC_RC_ServerApproved			700		/*	server approved txn */
#define SHC_RC_Continue					701		/*	continue processing */
#define SHC_RC_ServerDeclined			702		/*	server declined */
#define SHC_RC_PreAuthRequired			703		/*	internal in shc.c */
#define SHC_RC_NoIssuerEntry			704
#define SHC_RC_ApprovedNoForward		705


/* Add Codes Here For Test C1, C2 Txn. Ch.L. 23Apr92 */
#define SHC_RC_Clarification_One		800
#define SHC_RC_Clarification_Two		801

/* R003531 Added response code for CVV2 failure */
#define SHC_RC_InvalidCVV2				802
/* End R003531 */

/*	Internal Error Codes */
#define SHC_RC_IssuerDown				900
#define SHC_RC_AcquirerDown				901
#define SHC_RC_OriginatorDown			902
#define SHC_RC_RejectMessage			903
#define SHC_RC_FunctionNotSupported		904
#define SHC_RC_ShcTimeout				905
#define SHC_RC_TransfereeDown			906	/* 10002273 */
#define SHC_RC_DestinationBlocked   	907	// R027802 

								/* R001570 BEGIN */
#define SHC_RC_InvalidReceiver          920
#define SHC_RC_InvalidFileUpdateCode    921
#define SHC_RC_NoActionNeeded           922
#define SHC_RC_DBError                  923
#define SHC_RC_DBNoData                 924
#define SHC_RC_SHCCardChangeNotAllowed  139	//R171321825
#define SHC_RC_SHCCardDuplicateStatus   138     //R171437911
								/* R001570 END */

								/* R004984 BEGIN */
#define SHC_RC_UnsolicitedReversal		925
#define SHC_RC_DuplicateTransmission	926
								/* R004984 End */

#define SHC_RC_ApproveDeniedAdvice		927

//  >>> R022506
/*  Added for Discover Interface    */

#define SHC_RC_CallAcquirerResponse         928
#define SHC_RC_CallAcquirerSecurityResp     929

#define SHC_RC_SystemUp     930
#define SHC_RC_SoftDown     931
#define SHC_RC_SystemDown   932
//  <<< R022506

//	>>>		R028467
/*  Added for   Mastercard Interface */
#define SHC_RC_PinNotChanged    933
//	<<<		R028467
#define SHC_RC_InvalidHmacCAAV    934
#define SHC_RC_InvalidCvc2CAAV    935
#define SHC_RC_InvalidCSC    936

/* Added for Visa Interface */
#define SHC_RC_AddCustomerAuthentication	937
#define SHC_RC_PIN_DATA     938
#define SHC_RC_InvalidVisCvc2CAAV	939
#define SHC_RC_InvalidVis3DSCvc2CAAV	940

#define SHC_RC_FILE_UPDATE_FAILED     	1000
#define SHC_RC_FILE_UPDATE_DUPLICATE    1001
#define SHC_RC_ForceSTPI               	943
#define	SHC_RC_StolenCard		944
#define SHC_RC_CardBlocked		945
#define SHC_RC_VerificationDataFailed	946

/* Added for Amex Interface	*/
#define	SHC_RC_CardMemb_NOT_ENROLLED	941
#define	SHC_RC_DENY_CLOSEDMERCH			942

/* Added for Pos API Interface */
#define SHC_RC_MismatchCaptureType 947

/* Added for Cortex Interface   */
#define SHC_RC_PartialAmount                 18

/* Added for Diners Interface     */
#define SHC_RC_ApprovedByXpress		948

/* Added for Rapid Connect Interface */
#define SHC_RC_ExpiryDateMismatch	950
#define SHC_RC_InvalidTPPID			951
#define SHC_RC_PayAtPumpNotAllowed	952

/* Added for Rupay Interface     */
#define SHC_RC_UDIRReversalBasisAcqRes                961
#define SHC_RC_DuplicateTxnSameUPI                    962
#define SHC_RC_TransactionNotAvailableUPI             963
#define SHC_RC_UPITransactionProgress                 964
#define SHC_RC_TxntypeNotSupportedAcquirer            965
#define SHC_RC_TxntypeNotSupportedIssuer              966
#define SHC_RC_TxnOriginCountryNotAllowedForAcquirer  967
#define SHC_RC_OriginCountryNotSupportedIssuer        968
#define SHC_RC_OriginChannelNotAllowedIssuer          969
#define SHC_RC_OriginPointNotSupportedBin             970
#define SHC_RC_InvalidTxnCurrencyAcquirer             971

//10000 to 10999 are used by business monitoring to store reason code
//These codes are logged in txnlog table only
#define SHC_RC_UnableParseMsgHeader		10000
#define SHC_RC_UnableParseMsg    		10001
#define SHC_RC_UnableParseOther    		10002
#define SHC_RC_UnableProcessMsgOther	10003


/*------------------------------------------------------------------------*
 * Reversal reason codes Block
 *------------------------------------------------------------------------*/
#define SHC_RR_CustomerCancel			17
#define SHC_RR_InvalidResponse			20
#define SHC_RR_HardwareError			22
#define SHC_RR_MACKeyError				30
#define SHC_RR_MACSyncError				31
#define SHC_RR_PartialDispense			32
#define SHC_RR_TimeOut					68
#define SHC_RR_DestinationDown			82
#define SHC_RR_CancelRequest			91
#define SHC_RR_RejectMessage			92
#define SHC_RR_UncertainDispense		93
#define SHC_RR_TransactionInDoubt		94
#define SHC_RR_DepositError				95
#define SHC_RR_BNADepositError			100	//	---	R010978
#define SHC_RR_ValueAddedTax			164	//	--- IST_S_0695587-7
#define SHC_RR_DeferredAuthorization	165	//	---	IST_S_0695587-11
#define SHC_RR_AFTCompletion_Adv	166	//	---	IST_S_721854-13
#define SHC_RR_DeviceBinding_Results	167	//	---	IST_S_721854-14
#define SHC_RR_CardVerification	        168	//	---	IST_S_721854-14

#define SHC_RR_VoidCancel				169 // --- IST_S_0772006-9
#define SHC_RR_EMVOffline				170 // --- IST_S_0772006-9
#define SHC_RR_IncompleteTxn	 		171 // --- IST_S_0772006-9
#define SHC_RR_BelowFloorLimitTxn		172 // --- IST_S_0772006-9
#define SHC_RR_OnlineTnxNotPerformed	173 // --- IST_S_0772006-9
#define SHC_RR_ClearingAuthorizedTxn	174 // --- IST_S_0772006-9
#define SHC_RR_ClearingUnAuthorizedTxn	175 // --- IST_S_0772006-9
#define SHC_RR_IncrementalTxn			176 // --- IST_S_0772006-9
#define SHC_RR_ResubmissionTxn			177 // --- IST_S_0772006-9
#define SHC_RR_DelayedChargeTxn			178 // --- IST_S_0772006-9
#define SHC_RR_ReauthTxn				179 // --- IST_S_0772006-9
#define SHC_RR_NoShowTxn				180 // --- IST_S_0772006-9

//Added For Chase
#define SHC_RC_InvalidCashBackAmount    181
#define SHC_RC_InvalidMop               182
#define SHC_RC_TooManySCAExemption      183
#define SHC_RC_PartiaAuthNotAlloced     184
#define SHC_RC_InvalidTransDivNumber    185
#define SHC_RC_InvalidPaymentSecureData 186

/* Added for WEX Interface */
#define SHC_RC_InvalidNetwork 187
#define SHC_RC_InvalidPrompts 188

/*------------------------------------------------------------------------*
 * New reversal reason code (qd 01dec97 Added for ACXSYS)
 *------------------------------------------------------------------------*/
#define SHC_RR_FraudTransaction         3
#define SHC_RR_EditError                6
#define SHC_RR_InvalidTransaction       12
#define SHC_RR_InvalidAmount            13
#define SHC_RR_InvalidCardNumber        14
#define SHC_RR_UnacceptableFee          23
#define SHC_RR_RestrictedCard           36
#define SHC_RR_NoCreditAccount          39
#define SHC_RR_NotSupported             40
#define SHC_RR_LostCard                 41
#define SHC_RR_StolenCard               43
#define SHC_RR_NoSufficientFounds       51
#define SHC_RR_NoChecquingAccount       52
#define SHC_RR_NoSavingsAccount         53
#define SHC_RR_ExpiredCard              54
#define SHC_RR_IncorrectPIN             55
#define SHC_RR_NoCardRecord             56
#define SHC_RR_NotPermittedToCardholder 57
#define SHC_RR_NotPermittedToTerminal   58
#define SHC_RR_ExceedsLimit             61
#define SHC_RR_DisallowedCard           62
#define SHC_RR_ExceedsFreqLimit         65
#define SHC_RR_IssuerUnavailable        66
#define SHC_RR_AutomatedFuelDispenser   73
#define SHC_RR_HostCapture              74
#define SHC_RR_InvalidCaptureDate       77
#define SHC_RR_ExceedsOriginalAmount    78
#define SHC_RR_ExceedsTimeLimit         79
#define SHC_RR_KMESyncError             86
#define SHC_RR_NoRoute                  90
#define SHC_RR_SystemError              96
#define SHC_RR_CaptureDateError         97
#define SHC_RR_InvalidAuthorizationID   98
#define SHC_RR_DuplicateTransmission    99
#define SHC_RR_Successful				9	//	---	R022717
#define SHC_RR_ReversedByAcquirer		163 

/*------------------------------------------------------------------------*
 * Trace Reason Code Block (qd 01dec97 Added for ACXSYS)
 *------------------------------------------------------------------------*/
#define SHC_TR_CustomerInquiry        1
#define SHC_TR_CustomerDispute        2
#define SHC_TR_FraudTransaction       3
#define SHC_TR_CustomerDeny           4
#define SHC_TR_EditError              6
#define SHC_TR_InvalidTransaction     12
#define SHC_TR_InvalidAmount          13
#define SHC_TR_InvalidCard            14
#define SHC_TR_UnacceptableFee        23
#define SHC_TR_RestrictedCard         36
#define SHC_TR_NoCreditAccount        39
#define SHC_TR_LostCard               41
#define SHC_TR_StolenCard             43
#define SHC_TR_NoFunds                51
#define SHC_TR_NoChequingAccount      52
#define SHC_TR_NoSavingAccount        53
#define SHC_TR_ExpiredCard            54
#define SHC_TR_IncorrectPIN           55
#define SHC_TR_TxnNotPermit           57
#define SHC_TR_ExceedsLimit           61
#define SHC_TR_DisallowedCard         62
#define SHC_TR_ExceedsFreqLimit       65
#define SHC_TR_InvalidCapDate         77
#define SHC_TR_ExceedsPreauthAmt      78
#define SHC_TR_PreauthTimedOut        79
#define SHC_TR_DuplicateTxn           94

/*------------------------------------------------------------------------*
 * Trace Action Code Block(qd 01dec97 Added for ACXSYS)
 *------------------------------------------------------------------------*/
#define SHC_TA_BeingInvestigated        1
#define SHC_TA_AdjustmentWillFollow     2
#define SHC_TA_TransactionIsValid       3
#define SHC_TA_AdjustmentIsApplied      4

/*------------------------------------------------------------------------*
 *	Internal processing error codes
 *------------------------------------------------------------------------*/
#define SHC_IE_NoMatch					1
#define SHC_IE_InvalidTransaction		2
#define SHC_IE_Reversed					3
#define SHC_IE_NoBalance				4
#define	SHC_IE_ReversalToEDS			5
#define SHC_IE_Voided					6
#define SHC_IE_Duplicate                7  //R027320
#define SHC_IE_SafReply                 8  //R027562
#define SHC_IE_Reversed_Other_Site      9
#define SHC_IE_Capture					10	//capture message


#endif
/*------------------------------------------------------------------------*
 *	End of File
 *------------------------------------------------------------------------*/
