//
// Copyright (C) 2009 eFunds Corporation ("eFunds").  All Rights Reserved.
// eFunds Canada Corporation is an authorized user.
//
// IST is a registered trademark of eFunds Corporation.  Other brand or
// product names are trademarks or registered trademarks of their respective
// holders.
//
// The information contained herein is the unpublished proprietary property
// of eFunds.  Except as specifically authorized in writing by eFunds, the
// holder of this document shall: i) keep all information contained herein
// confidential, and ii) protect the information, in whole or in part, from
// disclosure and dissemination to all third parties.
//
// This document and the software described in it are furnished under license
// and may be used or copied only in accordance with the terms of such license.
// This document is supplied for information purposes only, is subject to
// change without notice, and should not be construed as a commitment by
// either eFunds Corporation or eFunds Canada Corporation.
//
/*
 * Description:
 *
 *      MODIFICATION HISTORY
 *
 *  Date         SCR            Who        Description
 *  ===========================================================================
*/

#ifndef SHCDUPLICATECHK_H
#define SHCDUPLICATECHK_H
static const char* _ShcDuplicateChk_h_what = "@(#) ShcDuplicateChk.h p4.1.25 2014/09/08 00:44:40";

#include <oc/oc_string.h>
#include <DBMWrapper.hxx>
#include <dbm.h>
#include <dbm_private.h>
#include <auto_ptr.h>
#include <debug.h>
#include <ist_otrace.h>
#define TBL_SHCDUPLICATECHK			"shcduplicatechk"
#include <ShcmsgHelper.h>
#include <ShcmsgHeader.h> 
#include <ShcHelperBase.h>
#include <ShcHelper.h>
#include <ShcAppBase.h>

class ShcDuplicateChk : public ShcHelperBase 
{
	public:
			ShcDuplicateChk();
			~ShcDuplicateChk();
			const char *getName()
			{
				return (const char *)SHC_ShcDuplicateChk;
			} 
			int 			site_id;
			OCDateTime    created;
			OCDateTime    updated;
			DBMInt 		siteid;
			char    		pan[SHC_PAN_LEN+1];
			long            lasttxntime;
		   	amount_t	lasttxnamt;
			char            lasttxntid[9];
			char			lasttxnacq[11];
			char 			lasttxnanum[7];
			long 			lasttxnrespcode;			
			long 			lasttxntrace;			
			int check(ShcmsgHeader *header);
			int update(ShcmsgHeader *header,int onlylasttime=0,long lasttxntime=0);
			DBMDateTime cur_time;
	protected:
			
			int _ind[50];
			DBMConn* _dbConn;
			DBMStmt* _stmt;
			DBMStmt* _smtUpdate;
			DBMStmt* _smtSelOne;
			DBMStmt* _updateTbl;
			DBMStmt* _smtInsert;
			int selectOne(ShcmsgHeader *header);
			int insertOne(ShcmsgHeader *header);
			int updateOne(ShcmsgHeader *header,int onlylasttime=0,long lasttxntime=0);
			OCDateTime &getOCDateTime(date_t dt);
			void dbInit();
			void recycle();
			static int 		dumpMoney(const char *fmt, amount_t *m);
			static const char *getAmtStr( amount_t *amt ){return getAmtStr(amt,2);}
			static const char *getAmtStr( amount_t *amt, int n );
};
#define OTraceDumpMoney  (*OTraceLevel<OTRACE_DUMP)?0:ShcDuplicateChk::dumpMoney

#endif
