#ifndef SHCSHIPTOADDRESS_INCLUDE
#define SHCSHIPTOADDRESS_INCLUDE
static char _shcshiptoaddress_include[] = "@(#) ShcShipToAddress.h 1.6 01/04/21 07:54:41";

/*
 *  Copyright (C) 2004 eFunds Corporation ("eFunds").  All Rights Reserved.     
 *  eFunds Canada Corporation is an authorized user.                            
 *                                                                              
 *  IST is a registered trademark of eFunds Corporation.  Other brand or        
 *  product names are trademarks or registered trademarks of their respective   
 *  holders.                                                                    
 *                                                                              
 *  The information contained herein is the unpublished proprietary property    
 *  of eFunds.  Except as specifically authorized in writing by eFunds, the     
 *  holder of this document shall: i) keep all information contained herein     
 *  confidential, and ii) protect the information, in whole or in part, from    
 *  disclosure and dissemination to all third parties.                          
 *                                                                          
 *  This document and the software described in it are furnished under license  
 *  and may be used or copied only in accordance with the terms of such license.
 *  This document is supplied for information purposes only, is subject to      
 *  change without notice, and should not be construed as a commitment by       
 *  either eFunds Corporation or eFunds Canada Corporation. 
 *                    
 *
 *                        MODIFICATION HISTORY                  REVIEW
 *
 *	SPR#	Who	Date	Description			Who	Date   
 * ===========================================================================
 *R000000 basker 04Apr21 Added class for formating shiptoaddress field in shcmsg
 */

#if !defined( ShcShipToAddress_h_export_directive )
#   if defined( WIN32 )
#       define ShcShipToAddress_h_export_directive __declspec(dllimport)
#   else
#       define ShcShipToAddress_h_export_directive
#   endif
#endif

#include "ist_win32.h"
#include <string.h>
#include <ShcHelperBase.h>
#include <ShcAcceptorName.h>

#define SHC_SHIPTO_LEN	168			/* ship to address details */

class ShcmsgHeader;

//There are two usage of this class
//1. construct class use ShcShipToAddress(char *shcShipToAddress), and retrieve subfields.
//2. construct class use ShcShipToAddress(), set subfields, and retrieve the whole field.
class ShcShipToAddress_h_export_directive ShcShipToAddress : public ShcAcceptorName
{
public:
    const char *getName();

	ShcShipToAddress(char *shiptoaddress) { loadShipToAddress(shiptoaddress); }
	ShcShipToAddress();
        void getName(char *nameBuf) { strcpy(nameBuf, nameSeg); }
        void getStateName(char *stateNameBuf) { strcpy(stateNameBuf, stateSeg); }
	void getCityName(char *cityNameBuf) { strcpy(cityNameBuf, citySeg); }
        void getPhone(char *phoneBuf) { strcpy(phoneBuf, phoneSeg); }
        void getCountryCode(char *countrycodeBuf) { strcpy(countrycodeBuf, countrySeg); }
        void getPostalcode(char *postalcodeBuf) { strcpy(postalcodeBuf, postalSeg); }
	void getLastName(char *lastnameBuf) { strcpy(lastnameBuf, lastnameSeg); }
	void getTelephoneType(char *telephonetype) { *telephonetype = phonetypeSeg[0]; }
	void getAddressLine1(char *addressline1Buf) { strcpy(addressline1Buf, address1Seg); }
	void getAddressLine2(char *addressline2Buf) { strcpy(addressline2Buf, address2Seg); };
	virtual int* getShipToAddressFieldsLength();
		
	virtual void setPhoneType(const char *phonetypeBuf);
	virtual void setLastName(const char *lastnameBuf);
	virtual void getShipToAddress(char *shiptoAddressBuf);

private:
	static int initialized;
	static int nameLen;
	static int lastnameLen;
	static int cityLen;
	static int stateLen;
	static int countryLen;
	static int address1Len;
	static int address2Len;
	static int phoneLen;
	static int postalLen;
	
	char name[30];
	char lastname[30];
	char state[2];
	char city[20];
	char phoneno[14];
	char addressline1[30];
	char addressline2[28];
	char postalcode[10];
	char CountryCode[2];
	char phonetype;

	void initialize(void);

public:
	static const int LEN_NAME    = 30;
	static const int LEN_LASTNAME = 30;
	static const int LEN_CITY    = 20;
	static const int LEN_STATE   = 2;
	static const int LEN_COUNTRY = 2;
	static const int LEN_ADDRESS1 = 30;
	static const int LEN_ADDRESS2 = 28;
	static const int LEN_POSTAL  = 10;
	static const int LEN_PHONE   = 14;
	static const int LEN_PHONETYPE = 1;
	static const int LEN_SEG_MAX = LEN_NAME + LEN_LASTNAME + LEN_CITY + LEN_STATE + LEN_COUNTRY + LEN_ADDRESS1 + LEN_ADDRESS2 + LEN_POSTAL + LEN_PHONE + LEN_PHONETYPE;
	
	static const int MAX_NETWORKS = 10;
	
	struct shiptoaddress_layout_t
	{
		char network[10+1];
		int  lenName;
		int  lenCity;
		int  lenState;
		int  lenCountry;
	};
	typedef struct shiptoaddress_layout_t SHIPTOADDRESS_LAYOUT;

protected:
	//char nameSeg[LEN_NAME+1];
	char lastnameSeg[LEN_LASTNAME+1];
	//char citySeg[LEN_CITY+1];
	//char stateSeg[LEN_STATE+1];
	//char countrySeg[LEN_COUNTRY+1];
	char address1Seg[LEN_ADDRESS1+1];
	char address2Seg[LEN_ADDRESS2+1];
	//char postalSeg[LEN_POSTAL+1];
	//char phoneSeg[LEN_PHONE+1];
	char phonetypeSeg[LEN_PHONETYPE+1];
	
	//char segBuffer[LEN_SEG_MAX+1];
	//char outputBuffer[LEN_SEG_MAX+1];

	static unsigned short mySegmentId;
	
public:
	static ShcShipToAddress *getInstance() { 
		static ShcShipToAddress *_instance=NULL;
		return ( _instance ? _instance : (_instance=new ShcShipToAddress()) );
	}

	void loadShipToAddress(char *shiptoaddress);
	virtual void  resetData();

	// output acceptor name string for formatter DE43
	virtual int   parseSegShipToAddress( const char *segData, int segLen );
	virtual char *outputShipToAddress( const char *network );
	virtual char *getShipToAddressFromSegment( const char *segData, int segLen, const char *network );
	
	
	// generate segment data  of acceptor name string 
	virtual void  setShipToAddress(const char *name, const char *city, const char *state, const char *country);
	virtual char *generateSegmentData(const char *name, const char *city, const char *state, const char *country);
	virtual char *generateSegmentData();
	virtual char *getSegBuffer() { return segBuffer; }
	virtual void  clearSegBuffer() { memset( segBuffer, 0, sizeof(segBuffer) ); }
	
	virtual char *getAddress1Seg();
	virtual char *getAddress2Seg();

	virtual int   getAddress1Seg(char *target, int len){ return formatIt(target, address1Seg,len); }
	virtual int   getAddress2Seg(char *target, int len){ return formatIt(target, address2Seg,len); }
	
	virtual void  setAddress1Seg( const char *cc ) { strncpy( address1Seg,cc, sizeof(address1Seg)-1 ); }
	virtual void  setAddress2Seg( const char *cc ) { strncpy( address2Seg,cc, sizeof(address2Seg)-1 ); }
	virtual void  setLastNameSeg( const char *cc ) { strncpy( lastnameSeg,cc, sizeof(lastnameSeg)-1 ); }
	virtual void  setPhoneTypeSeg( const char *cc ) { strncpy( phonetypeSeg,cc, sizeof(phonetypeSeg)-1 ); }

	virtual int   saveSegment( ShcmsgHeader *hdr );
	virtual int   loadSegment( ShcmsgHeader *hdr );
	
};

#endif
