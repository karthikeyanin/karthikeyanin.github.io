#ifndef _SHCMSGHEADER_H_
#define _SHCMSGHEADER_H_

static char _ShcmsgHeader_h_what[] = "@(#) ShcmsgHeader.h 1.14.6.3 16/10/21 10:08:54";
/*
 *  Copyright (C) 2004 eFunds Corporation ("eFunds").  All Rights Reserved.     
 *  eFunds Canada Corporation is an authorized user.                            
 *                                                                              
 *  IST is a registered trademark of eFunds Corporation.  Other brand or        
 *  product names are trademarks or registered trademarks of their respective   
 *  holders.                                                                    
 *                                                                              
 *  The information contained herein is the unpublished proprietary property    
 *  of eFunds.  Except as specifically authorized in writing by eFunds, the     
 *  holder of this document shall: i) keep all information contained herein     
 *  confidential, and ii) protect the information, in whole or in part, from    
 *  disclosure and dissemination to all third parties.                          
 *                                                                          
 *  This document and the software described in it are furnished under license  
 *  and may be used or copied only in accordance with the terms of such license.
 *  This document is supplied for information purposes only, is subject to      
 *  change without notice, and should not be construed as a commitment by       
 *  either eFunds Corporation or eFunds Canada Corporation. 
 *
 *                        MODIFICATION HISTORY                  REVIEW
 *
 * SCR#     Who    Date  Description
 * ===========================================================================
 * R028104	Dipa	29Apr10	Removed routingInfo
 * R028354	Dipa	26Jul10	Added reset()
 */

#include <ShcBin.h>
#include <ShcHeader.h>
#include <shc.h>
#include <ist_seg_list.h>


#define SHCMSG_HEADER_SEG_PARSED 0x00000001

class ShcmsgHeader : public ShcHeader
{
public:
	struct shcmsg msg;				//Current message
	char   segment[SHC_SEG_MAX+1];	// segment buffer
	struct shcmsg *origMsg;			//Original messages for void and reversal etc
	struct shcmsg *reqMsg;			//Request messages from event for responses
	ShcBin *transfereeShcBin;
	char  *pindata;

    const char *getName()
    {
        return (const char *)SHC_ShcmsgHeader;
    }

	void  setPinData(char *d) { pindata = d; }
	const char *getPinData() { return pindata; }
	int isVoidTxn();
	int isrepeat() { return msg.msgtype%2 == 1; };
	int transfereeBinValid();
	int allocateAndCopyOrigMsg(struct shcmsg *msg);
	int allocateAndCopyReqMsg(struct shcmsg *msg);
	emv     *emvbuf;/* 2007336 */
	
	int segListFlag;
	IstSegList *segList;
	int reqSegListFlag;
	IstSegList *reqSegList;
	int origSegListFlag;
	IstSegList *origSegList;

	virtual void setSenderId(int newSenderId);
	virtual void setTxnStartTime();
	virtual int setTransfereeShcBin(char *bin);
	int toShcStruct(struct shc *shcP);
	int fromShcStruct(struct shc *shcP);
	
	ShcmsgHeader(struct shcmsg *newMsg);
	ShcmsgHeader(ShcmsgHeader &oldHeader);
	ShcmsgHeader();
	
	~ShcmsgHeader();
	

	int truelength(struct shcmsg *msg=NULL);

	IstSegList *getSegList();
	IstSegList *getOrigSegList();
	IstSegList *getReqSegList();

	int setSegList(IstSegList *newList);
	int setOrigSegList(IstSegList *newList);
	int setReqSegList(IstSegList *newList);
	
	IstSegBase *getSegmentObj(ist_ElfId_t segmentId, int segflag=0)
	{
		IstSegList *sl = getSegList();
		IstSegBase *s = sl->getSegItem(segmentId);
		if ((segflag & IST_SEG_CREATE) && (!s))
		{
			s = sl->createObject(segmentId);
			if ( s )
				sl->setSegItem(segmentId, s);
		}
		return s;
	}
	IstSegBase *getReqSegmentObj(ist_ElfId_t segmentId, int segflag=0)
	{
		IstSegList *sl = getReqSegList();
		if (!sl)
			return NULL;
		IstSegBase *s = sl->getSegItem(segmentId);
		if ((segflag & IST_SEG_CREATE) && (!s))
		{
			s = sl->createObject(segmentId);
			if ( s )
				sl->setSegItem(segmentId, s);
		}
		return s;
	}
	IstSegBase *getOrigSegmentObj(ist_ElfId_t segmentId, int segflag=0)
	{
		IstSegList *sl = getOrigSegList();
		if (!sl)
			return NULL;
		IstSegBase *s = sl->getSegItem(segmentId);
		if ((segflag & IST_SEG_CREATE) && (!s))
		{
			s = sl->createObject(segmentId);
			if ( s )
				sl->setSegItem(segmentId, s);
		}
		return s;
	}
	
	void getSegmentData(char *segBuf, int *segBufLen, ist_ElfId_t segmentId, int subElementId)
	{
		IstSegBase *s = getSegmentObj(segmentId);
		if (!s)
		{
			*segBufLen = 0;
			return;
		}
		if (!subElementId)
			s->flattenSegMemcpy(segBuf, segBufLen);
		else
			s->getFieldMemcpy(subElementId, segBuf, segBufLen);
	}
	void getReqSegmentData(char *segBuf, int *segBufLen, ist_ElfId_t segmentId, int subElementId)
	{
		IstSegBase *s = getReqSegmentObj(segmentId);
		if (!s)
		{
			*segBufLen = 0;
			return;
		}
		if (!subElementId)
			s->flattenSegMemcpy(segBuf, segBufLen);
		else
			s->getFieldMemcpy(subElementId, segBuf, segBufLen);
	}
	void getOrigSegmentData(char *segBuf, int *segBufLen, ist_ElfId_t segmentId, int subElementId)
	{
		IstSegBase *s = getOrigSegmentObj(segmentId);
		if (!s)
		{
			*segBufLen = 0;
			return;
		}
		if (!subElementId)
			s->flattenSegMemcpy(segBuf, segBufLen);
		else
			s->getFieldMemcpy(subElementId, segBuf, segBufLen);
	}
	void setSegmentData(char *segBuf, int segBufLen, ist_ElfId_t segmentId, int subElementId)
	{
		IstSegBase *s = getSegmentObj(segmentId, IST_SEG_CREATE);
		if (!subElementId)
			s->unflattenSegMemcpy(segBuf, segBufLen);
		else
			s->setFieldMemcpy(subElementId, segBuf, segBufLen);
	}
	void setReqSegmentData(char *segBuf, int segBufLen, ist_ElfId_t segmentId, int subElementId)
	{
		IstSegBase *s = getReqSegmentObj(segmentId, IST_SEG_CREATE);
		if (!subElementId)
			s->unflattenSegMemcpy(segBuf, segBufLen);
		else
			s->setFieldMemcpy(subElementId, segBuf, segBufLen);
	}
	void setOrigSegmentData(char *segBuf, int segBufLen, ist_ElfId_t segmentId, int subElementId)
	{
		IstSegBase *s = getOrigSegmentObj(segmentId, IST_SEG_CREATE);
		if (!subElementId)
			s->unflattenSegMemcpy(segBuf, segBufLen);
		else
			s->setFieldMemcpy(subElementId, segBuf, segBufLen);
	}
	
	void restoreSegmentFromReq()
	{
		if (!reqMsg)
			return;
		getSegList()->restore(getReqSegList(), IST_SEG_DIRECTION_REQ_TO_RESP);
	}

	//R028354 >>>
	void reset();
	//<<< R028354

        int appendReplicationData(const char* service, const char* msgtosave, int msglen);
        int  getMsgSiteId();
	
};

#endif
