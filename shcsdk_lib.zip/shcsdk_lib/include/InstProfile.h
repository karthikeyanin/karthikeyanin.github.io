#ifndef _INSTPROFILE_H_
#define _INSTPROFILE_H_

static char _InstProfile_h_what[] = "@(#) InstProfile.h 1.15.2.6 20/02/27 15:21:14";

/*
 *  Copyright (C) 2004 eFunds Corporation ("eFunds").  All Rights Reserved.     
 *  eFunds Canada Corporation is an authorized user.                            
 *                                                                              
 *  IST is a registered trademark of eFunds Corporation.  Other brand or        
 *  product names are trademarks or registered trademarks of their respective   
 *  holders.                                                                    
 *                                                                              
 *  The information contained herein is the unpublished proprietary property    
 *  of eFunds.  Except as specifically authorized in writing by eFunds, the     
 *  holder of this document shall: i) keep all information contained herein     
 *  confidential, and ii) protect the information, in whole or in part, from    
 *  disclosure and dissemination to all third parties.                          
 *                                                                          
 *  This document and the software described in it are furnished under license  
 *  and may be used or copied only in accordance with the terms of such license.
 *  This document is supplied for information purposes only, is subject to      
 *  change without notice, and should not be construed as a commitment by       
 *  either eFunds Corporation or eFunds Canada Corporation. 
 *
 *
 *                        MODIFICATION HISTORY                  REVIEW
 *
 * SCR#     Who    Date  Description
 * ===========================================================================
 * R0xxxxx 
 * R012134  Emj  02Oct04 Issuer Entity Support
 * R030556	Dipa 14Jun12 Clone of R030592
 * R031154  Dipa 21Dec12 Clone of R031026
 */
 

#include <ShcSdkCommon.h>
#include <mt_extbin.h>
#include <multi_institution.h>
#include <ShcHelperBase.h>

class BinrouteGroupRelation;

typedef vector<NetworkInfo
#if ! defined(OC_USE_NEW_STL)
	, __STL_DEFAULT_ALLOCATOR(NetworkInfo)
#endif
	>InstProfileList;

#define MAX_INST_RESULT          100
extern int setRoutingWithInstProfile;
struct InstProfilesList
{
    struct InstitutionProfileShm *p;
//    struct shcpkg *pkg;
};

class InstProfile : public ShcHelperBase
{
public:
    const char *getName()
    {
        return (const char *)SHC_InstProfile;
    }

	virtual void locateNetworkInfo(const char * txnSrc, 
								   const char *txnDest, const char *iss_entityId,
								   const int msgType, const bin_t bin, 
								   NetworkInfo &networkInfo);
	virtual void locateIssuerFromNetwork(const char *txnSrc, const int msgType, const char *externalId, 
					const char *member_ID, const char *F_ID, IssuerInfo &issuerInfo);
	virtual void locateIssuerFromInstitution(const char *inst, const char *entityId, const int msgType, IssuerInfo &issuerInfo);

	virtual int getInstProfileList(const char *txnSrc,
								   const char *txnDst,
								   const char *iss_entityId,
								   InstProfileList &ipList,
								   InstProfileList &groupList);
	virtual int getInstProfileList(const char *txnSrc,
								   const char *txnDst,
								   const char *iss_entityId,
								   InstProfileList &ipList,
								   char *bin=NULL);

	virtual int pauseDisplay(int i);
	virtual void display(char *txnSrc, char *txnDest);
        virtual InstitutionProfile *chooseEntry(int routeRemoteSite=0);
	virtual void locateNetworkInfoByKeyParam(int keyParam, NetworkInfo &networkInfo);
	virtual void locateAcquirerNetworkInfo(const char *txnSrc, const int msgType, const char *externalId, 
						const char *member_ID, const char *F_ID, NetworkInfo &networknfo);
	virtual int locateById(int id);
	virtual int changeInstProfileStatus(int id, int status, char *broadcastStr);
        int changeInstProfileStatus(const char *binrouteGroup, int status, char *broadcastStr);
	int addAllBroadcastString(char *broadcastStr, size_t broadcastStr_size);
	void locateNetworkInfoByKeyParamStr(const char *instId, const char * keyParam, NetworkInfo &networkInfo, 
					const char *bin=NULL);
	struct InstitutionProfile * locateByBinroute(struct s_binroute *pBinRoute);
	int setInstRuleParam();
	struct InstitutionProfileShm *getEntry(int i);
	
protected:
	virtual int MatchBin(const struct InstitutionProfile &ip, const char *txnSrc, 
					     const char *txnDest, const char *iss_entityId,
			             const char *msgType, const bin_t bin);
	virtual int Match(const struct InstitutionProfile &ip, const char *txnSrc, 
			const char *msgType, const char *externalId, const char *member_ID, const char *F_ID);
        int reverseMatch(const struct InstitutionProfile *ip, const char *txnSrc,
                        const char *msgType, const char *externalId, const char *member_ID, const char *F_ID);
	virtual int Match(const struct InstitutionProfile &ip, const char *inst, 
					  const char *entityId, const char *msgType);
	virtual int initialize();
	virtual void print(int i, struct InstitutionProfile *InstProf);
	virtual int MatchNetMsg (const struct InstitutionProfile &ip,
									  char *txnSrc, char *txnDest, char *iss_entityId);
	virtual int addInstProfile (InstProfileList &binlist, const struct InstitutionProfile &ip);

	static int initialized;
	static struct InstitutionProfileShm *institutionProfileData;
	static struct     rules_keytab    *institutionRuleKeyp;
	static int institutionProfileAppid;
	struct InstProfilesList profileResult[MAX_INST_RESULT];
	int resultNum;
	struct RoutingInfo m_route;
	bool m_route_set;

};

extern int instProfileIdLocateByKeyParam ;	//The inst_profile_id that should be matched when calling locateNetworkInfoByKeyParam

#endif

