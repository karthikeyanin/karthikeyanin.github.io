#ifndef _SHCAPPBASE_H_
#define _SHCAPPBASE_H_

static char _ShcAppBase_h_what[] = "@(#) ShcAppBase.h 1.15.3.5 18/07/06 17:13:23";

/*
 *  Copyright (C) 2004 eFunds Corporation ("eFunds").  All Rights Reserved.     
 *  eFunds Canada Corporation is an authorized user.                            
 *                                                                              
 *  IST is a registered trademark of eFunds Corporation.  Other brand or        
 *  product names are trademarks or registered trademarks of their respective   
 *  holders.                                                                    
 *                                                                              
 *  The information contained herein is the unpublished proprietary property    
 *  of eFunds.  Except as specifically authorized in writing by eFunds, the     
 *  holder of this document shall: i) keep all information contained herein     
 *  confidential, and ii) protect the information, in whole or in part, from    
 *  disclosure and dissemination to all third parties.                          
 *                                                                          
 *  This document and the software described in it are furnished under license  
 *  and may be used or copied only in accordance with the terms of such license.
 *  This document is supplied for information purposes only, is subject to      
 *  change without notice, and should not be construed as a commitment by       
 *  either eFunds Corporation or eFunds Canada Corporation. 
 *
 *                        MODIFICATION HISTORY                  REVIEW
 *
 * SCR#     Who    Date  Description
 * ===========================================================================
 * R0xxxxx ztang 05Nov03 Creation
 * R030492 dipa	 20Apr12	Remove reference to shcversion.h
 */
 

#include <ShcSdkCommon.h>
#include <shcextbuf.h>
#include <Queue.h>
#include <CShcLog.h>
#include <ShckeyParamsList.h>
#include <ShcHelperBase.h>
#include <ShcHelperRegistration.h>
#include <ShcHeaderRegistration.h>
#include <EntityStatus.h>
#include <IssProfileExtended.h>

class ShcmsgHelper;
class ShcKeyHelper;
class ShcMacHelper;
class ShcNotify;
class ShcTimerHelper;
class ShcHelper;
class IssProfile;
class AcqProfile;
class InstProfile;
class ShcDKEHelper;
class ShcLog;
class Shc600Log;
class ShcSafIOHelper;
class ShcBin;


class ShcProcessor;

/* The class that holds the global variables */
class ShcAppBase : public ShcHelperBase
{
public:
	ShcAppBase();
	~ShcAppBase(){};
    const char *getName()
    {
        return (const char *)SHC_ShcAppBase;
    }

	Queue <ShcProcessor *> msgQueue;
	
	ShcLog *shcmsgLogObj;
	Shc600Log *shc600LogObj;
	
	int	shcExtendedEventLocate;
	int serverMailboxId;
	//struct shccard shccard;
	int pcode_req;
	int	shcIsSwitch;
	static struct	shc_txn_def shc_txn_def[11];
	static struct	shc_bin_cfg shc_bin_cfg[30];
	int				shcGenAuthNumFrom;
	int				shc_add_auth_saf;
	int				shcReturnDBError;
	int				shc_use_sw_des;
	
	
	/*
	 *	Standard message class descriptions
	 */
	unsigned long	*shcmsgdesc;
	int				DEBUG_ON;
	int flrfd;
	int netid;
	int settlementid;
	InstitutionParams shckeyParams;
	ShckeyParamsList *shckeyParamsList;
	int	saf_interleave; /* R011925 */

	/* for Credicard, 23Feb94 */
	
	char			omsg_chip_index[31];			/* R007984 */
	
	int				shclog_specified_msgtype;		/* The message type that should be located. *
													 * 0 means not specified         R008689    */  
	ShcInstParamsList *acquirerShcParamsList;
	ShcInstParamsList *issuerShcParamsList;
	int				shcNewGentrace;
	InstitutionParams		shcParams;
	
	struct shc *tmpShcOmsg;
	
	ShcmsgHelper		*shcmsgHelperObj;
	ShcKeyHelper			*shcKeyObj ;
	ShcMacHelper				*shcMacObj;
	ShcNotify			*shcNotifyObj;
	ShcSafIOHelper			*shcSafIOHelperObj;
	ShcTimerHelper				*shcTimerObj;
	ShcHelper		*shcHelperObj;
	IssProfile			*issProfileObj;
	AcqProfile			*acqProfileObj;
	InstProfile			*instProfileObj;
	ShcDKEHelper 		*shcDKEApiObj;
	ShcBin			*shcBinObj;
	EntityStatus    *entityStatusObj;
};

extern ShcAppBase *shcApp;
extern ShcHelperRegistration shcHelperRegister;
extern ShcHeaderRegistration shcHeaderRegister;
extern ist_ElfId_t NETWORK_DATA_REQ_id;
extern ist_ElfId_t NETWORK_SETTLEMENT_DATA_id;
extern ist_ElfId_t NETWORK_SETTLEMENT_DATA_RESP_id;
extern ist_ElfId_t EMV_BUF_id;;
extern ist_ElfId_t DN_SEG_id;;
extern ist_ElfId_t ORIG_ENV_id;

extern IssProfileExtended *issProfileExtObj;

#endif

