//
// Copyright (C) 2004 eFunds Corporation ("eFunds").  All Rights Reserved.
// eFunds Canada Corporation is an authorized user.
//
// IST is a registered trademark of eFunds Corporation.  Other brand or
// product names are trademarks or registered trademarks of their respective
// holders.
//
// The information contained herein is the unpublished proprietary property
// of eFunds.  Except as specifically authorized in writing by eFunds, the
// holder of this document shall: i) keep all information contained herein
// confidential, and ii) protect the information, in whole or in part, from
// disclosure and dissemination to all third parties.
//
// This document and the software described in it are furnished under license
// and may be used or copied only in accordance with the terms of such license.
// This document is supplied for information purposes only, is subject to
// change without notice, and should not be construed as a commitment by
// either eFunds Corporation or eFunds Canada Corporation.
//
 /*
 *  Date    SCR     Who     Description
 *  ===========================================================================
 *
 *
 */

#ifndef __shc_genericlog_h_
#define __shc_genericlog_h_ 1

static char _shc_genericlog_h_what[] = "@(#) CShcGenericLog.h 1.5.2.1 17/05/25 05:10:32";

#include <ShcHelperBase.h>
#include <DBM3.h>
#include <ShcmsgHeader.h>

#define SHC_GENERIC_LOG_FIELD_NUM	40
#define MAX_SEG_NAME_LEN		32

extern int shcGenericLogFieldSize;
extern int noOfGenLogItem;
extern int processError(int ret, DBMHSTMT sh);

struct dbBuffer
{
	char *buf;
	int bufferSize;
	int flag;
};

struct SegmentItem
{
	int segmentHashValue;
	int segmentDataLen;
	char *value;
	char segmentName[MAX_SEG_NAME_LEN+1];
	char dataType;
	char separator;
	char restoreFlag;
	unsigned char sequence;
	unsigned char fieldNum;
};

class ShcGenericLog : public ShcHelperBase
{
	protected:

		char logid[21];
		int msgType;
		char reqresp;
		struct SegmentItem *segmentList;
		struct dbBuffer *bufList;
		int shcGenericLogFieldList[SHC_GENERIC_LOG_FIELD_NUM];
		int ind[SHC_GENERIC_LOG_FIELD_NUM+3];

		DBMHSTMT shInsert;
		DBMHSTMT shLoadBoth;
		DBMHSTMT shLoad1;
		DBMHDBC ch;
		dbm_date_t switch_date;

	public:

		ShcGenericLog();
    	virtual const char *getName()
		{
			return (const char *)"ShcGeneric_log";
		}

		virtual void initialize();
		virtual void fillSegment(ShcmsgHeader *header, char *logHeader=NULL, int *logHeaderLen=NULL);
		virtual void insert();
		virtual IstSegList *restore(ShcmsgHeader *header, char _reqresp, char *reqBufHeader=NULL, int reqBufHeaderLen=0, char *respBufHeader=NULL, int respBufHeaderLen=0);
		int hashValue(const char* ptr);
		~ShcGenericLog();
};

#endif
