#ifndef _SHCKEYSMRHELPER_H_
#define	_SHCKEYSMRHELPER_H_ 

static char _ShcKeysMRHelper_h_what[] =  "@(#) ShcKeysMRHelper.h 1.3 15/12/08 21:29:21";

/*
 *  Copyright (C) 2004 eFunds Corporation ("eFunds").  All Rights Reserved.     
 *  eFunds Canada Corporation is an authorized user.                            
 *                                                                              
 *  IST is a registered trademark of eFunds Corporation.  Other brand or        
 *  product names are trademarks or registered trademarks of their respective   
 *  holders.                                                                    
 *                                                                              
 *  The information contained herein is the unpublished proprietary property    
 *  of eFunds.  Except as specifically authorized in writing by eFunds, the     
 *  holder of this document shall: i) keep all information contained herein     
 *  confidential, and ii) protect the information, in whole or in part, from    
 *  disclosure and dissemination to all third parties.                          
 *                                                                          
 *  This document and the software described in it are furnished under license  
 *  and may be used or copied only in accordance with the terms of such license.
 *  This document is supplied for information purposes only, is subject to      
 *  change without notice, and should not be construed as a commitment by       
 *  either eFunds Corporation or eFunds Canada Corporation. 
 *
 *                        MODIFICATION HISTORY                  REVIEW
 *
 * SCR#     Who    Date  Description
 * ===========================================================================
 *
 */
 
#include <ShcHelperBase.h>
#include <ShcmsgHeader.h>
#include <oc/oc_string.h>
#include <shc.h>

const char* const SHCKEYSMRHELPER_OBJ_NAME = "ShcKeysMRHelper";

class ShcKeysMRHelper:public ShcHelperBase
{
	public:
	
		ShcKeysMRHelper();
		virtual ~ShcKeysMRHelper();
		static ShcKeysMRHelper* getInstance();

		virtual const char *getName(){return SHCKEYSMRHELPER_OBJ_NAME;};

		virtual int sendKeyWait(struct shckey_buf *bufp, char *newkey, char *newchk, char status);
		virtual int sendKey(struct shckey_buf *bufp, char *newkey, char *newchk, char status);
		virtual int getWaitTime();
		virtual int setMRDataUnique(struct shckey_buf *bufp, char status);

		virtual int sendMRMsgShared(int waitResp);
		virtual int setMRDataShared(struct shckey_buf *bufp, char *newkey, char *newchk, char status );


		virtual int getIstparam();
		virtual int processRespMRMsg();

	private:
		int _waitTime;		
		char _workbuf[2048];
		char _fromMboxid;





};






#endif

