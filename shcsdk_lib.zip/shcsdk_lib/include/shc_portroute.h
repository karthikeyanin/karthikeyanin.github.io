/*
 *  Copyright (C) 2004 eFunds Corporation ("eFunds").  All Rights Reserved.     
 *  eFunds Canada Corporation is an authorized user.                            
 *                                                                              
 *  IST is a registered trademark of eFunds Corporation.  Other brand or        
 *  product names are trademarks or registered trademarks of their respective   
 *  holders.                                                                    
 *                                                                              
 *  The information contained herein is the unpublished proprietary property    
 *  of eFunds.  Except as specifically authorized in writing by eFunds, the     
 *  holder of this document shall: i) keep all information contained herein     
 *  confidential, and ii) protect the information, in whole or in part, from    
 *  disclosure and dissemination to all third parties.                          
 *                                                                          
 *  This document and the software described in it are furnished under license  
 *  and may be used or copied only in accordance with the terms of such license.
 *  This document is supplied for information purposes only, is subject to      
 *  change without notice, and should not be construed as a commitment by       
 *  either eFunds Corporation or eFunds Canada Corporation. 
 */
/*
#pragma ident "@(#) shc_portroute.h 1.2 08/06/19 11:18:55"
 *
 *                        MODIFICATION HISTORY                  REVIEW
 *
 *  SPR#    Who Date    Description         Who Date
 * ===========================================================================
 *  R004218  fg 14Apr00 Created to decide credit/debit route in SHC 
 *	R004998	jyang 14Aug00 Exporting for NT
 *	R023659	ram	19Jun08	Callback prototype changed to improve performance 
*/

#ifndef _SHC_PORT_ROUTE_H_
#define _SHC_PORT_ROUTE_H_

#include "shc_callback.h"

class portRouteCallBack: public shcCallBack
{
public:
	static portRouteCallBack*	getInstance();
	int execute(struct shc *shcmsg, OCString& ProcessingPoint);  //	---	R023659
	
protected:
	portRouteCallBack() {};

private:
	static portRouteCallBack*	_instance;
};


extern "C" CALLBACKDLLEXPORT int register_all(shcCallBackFactory* cbFactory); /* R004998 */

#endif
		

