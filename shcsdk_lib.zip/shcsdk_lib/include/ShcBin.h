#ifndef DSWITCH
#define DSWITCH
#endif

#ifndef _SHCBIN_H_
#define _SHCBIN_H_

static char _ShcBin_h_what[] = "@(#) ShcBin.h 1.17 13/10/24 07:43:28";
/*
 *  Copyright (C) 2004 eFunds Corporation ("eFunds").  All Rights Reserved.     
 *  eFunds Canada Corporation is an authorized user.                            
 *                                                                              
 *  IST is a registered trademark of eFunds Corporation.  Other brand or        
 *  product names are trademarks or registered trademarks of their respective   
 *  holders.                                                                    
 *                                                                              
 *  The information contained herein is the unpublished proprietary property    
 *  of eFunds.  Except as specifically authorized in writing by eFunds, the     
 *  holder of this document shall: i) keep all information contained herein     
 *  confidential, and ii) protect the information, in whole or in part, from    
 *  disclosure and dissemination to all third parties.                          
 *                                                                          
 *  This document and the software described in it are furnished under license  
 *  and may be used or copied only in accordance with the terms of such license.
 *  This document is supplied for information purposes only, is subject to      
 *  change without notice, and should not be construed as a commitment by       
 *  either eFunds Corporation or eFunds Canada Corporation. 
 *                    
 *
 *
 *                        MODIFICATION HISTORY                  REVIEW
 *
 * SCR#     Who    Date  Description
 * ===========================================================================
 * R0xxxxx 
 * R016347 Emj 01May06 Updated setBinPkg functioons to set key and pin pointers
 * R020941 spa 16Aug07 Removed unnecessary semicolon
 */
#include <shc.h>
#include <shcdef.h>
#include <ShcHelperBase.h>

class ShcmsgHeader;


class ShcBin : public ShcHelperBase
{
public:
    const char *getName()
    {
        return (const char *)SHC_ShcBin;
    }

	struct shcpkg      *binPkg;
	struct	pinverparm	*pin;				/*	pin data */
	struct	shcsecurity	*key;				/*	encryption key data */
	
	
	ShcBin() : binPkg(0), pin(0), key(0)
	{
	};
	
	ShcBin(bin_t bin) : binPkg(0), pin(0), key(0)
	{ 
		initShcBin( bin );
	}
	
	ShcBin(ShcBin *pBin);
	ShcBin(ShcBin &sBin);
	
	virtual ~ShcBin() { binPkg=0; key=0; pin=0; }
	
	int initShcBin( bin_t bin )
	{
		if ( setBinPkg( bin ) < 0 )	//	---	R020941
			return -1;
		return 0;
	}

	int setBinPkg( bin_t bin );
	int setBinPkg( char *instId, char *userBinId );
	void  setBinPkg( shcpkg *p); 
	
	const struct shcpkg *getBinPkg() const { return binPkg; }
	
	const shcsecurity* getKey() const { return key; }
	void  setKey(shcsecurity *k) { key = k; }
	
	const struct pinverparm* getPinParm() const { return pin; }
	void  setPinParm(struct pinverparm *p) { pin = p; }
	
	virtual int shc_keys_set_pointers( struct shckey_buf *bufp );
//	virtual int shc_keys_init_buf(  struct shckey_buf *bufp, char key_class, char type, char index );
	virtual int shcnet_keys_init( ShcmsgHeader *header, struct shckey_buf *bufp);
//	virtual int shc_keyidx(struct shckeys *shckeys);
//	virtual int shc_keys_get_pointers(struct shckey_buf *bufp, short p_keyidx);
	virtual void shckeys_setindex_ptr(struct shckey_buf *bufp );
	virtual void shckeys_setkey_ptr(  struct shckey_buf *bufp, struct shcsecurity *secp, 
			char key_class, char key_type, char key_index );
	virtual int shckeys_setpkg(struct shckey_buf *bufp);
	virtual int shckeys_setclass( struct shckey_buf *bufp, char key_class );
	virtual int shckeys_settype(struct shckey_buf *bufp, char key_type );
	virtual int shckeys_getindex_next(struct shckey_buf *bufp, char *key_index );
	virtual char shckeys_getindex(struct shckey_buf *bufp, char key_index );
	virtual int shckeys_setindex(struct shckey_buf *bufp, char key_index );
	virtual int shckeys_getkey( struct shckey_buf *bufp, char key_class, char key_type, char key_index );
	virtual int shckeys_GetKey(struct shckey_buf *bufp, char key_class, char key_type, char key_index );
	virtual int shckeys_UpdIndex(struct shckey_buf *bufp, char index );
	virtual int shckeys_SetStatus(struct shckey_buf *bufp, char status );
	virtual int shckeys_GenerateKey(struct shckey_buf *bufp, char *k_kpe, char *k_chk );
	virtual int shckeys_TranslateKey(struct shckey_buf *bufp, char *k_kpe, char *k_chk, char *k_cnt );
	virtual int shckeys_ClrKeys( char *classp, char *typep,	char *indexp, char status );
	virtual int shckeys_RstKeys();
	virtual int shckeys_Key2Shc(struct shckey_buf *bufp, ShcmsgHeader *header );
	virtual int shckeys_FillMsg( ShcmsgHeader *header, char key_class, char type);
	virtual int shckeys_Mem2Dbm(struct shckey_buf *bufp);
	virtual int shckeys_Dbm2Mem( struct shcsecurity *keyp );
	virtual int shckeys_GetKeyUsage( struct shckey_buf *bufp);
	virtual int shc_setkeypointers(ShcmsgHeader *header);
	virtual int shcmac_verify( ShcmsgHeader *header, char key_class );
	virtual int shc_get_pin_translate_parameters_xt(ShcmsgHeader *header,
												int		is_issuer,
												struct shcsecurity **secp,
												PINVERPARM	**pinp,
												char		**key,
												int *keylen);
	virtual int shc_get_pin_translate_parameters_xt_xt(ShcmsgHeader *header,
												  int		is_issuer,
												  struct shcsecurity **secp,
												  PINVERPARM	**pinp,
												  char		**key,
												  int *keylen,
												  char *keyidx);
	virtual int shckme_DecryptBalance( ShcmsgHeader *header, char key_class, char index );											
	virtual int shckme_EncryptBalance( ShcmsgHeader *header, char key_class, char index );
	virtual int setInstUp(int force = 0);
	virtual int setInstDown(int force = 0);
	virtual int clearInst();
	virtual int shc_locate_bin(struct shcpkg **shcpkg, char *institutionId, char *userBinId);
	virtual int shc_locate_bin(struct shcpkg **shcpkg, bin_t bin);
	virtual int shc_search_bintable(bin_t bin);
	virtual int internalBin2ExternalBin(char *institutionId, char *userBinId, const char *networkid);
	virtual int externalBin2InternalBin(char *networkid, const char *institutionId, const char *userBinId) ;
	virtual int shc_test_compare(char *bin, char *lowbin, char *highbin);
	virtual int shc_getissnetkpe(ShcmsgHeader *header, char *kpe_cnt);	

	int isFullEntry();
	int isVerifyARQCReq();
	int isGenARPCReq();
	int declineIfARQCFails();
	int logChipData();
	int isEmvStip();
	int isInterac();
	int isDynamicSQL();
	int isNDKE();
	int isCheckDupRev();
	int isRestoreTranTime();
	int isCapdateOverride();
	int isTokenTxnChkSkip();
	struct shcpkg *getBinPkg(char *shcDefaultIssuerId);

	int setKey ( struct InstitutionProfile *ip );
	
//	virtual int shc_keys_init();
};


#endif
