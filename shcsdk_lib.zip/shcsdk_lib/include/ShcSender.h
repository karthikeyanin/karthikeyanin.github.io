#ifndef SHCSENDER_INCLUDE
#define SHCSENDER_INCLUDE
static char _shcsender_include[] = "@(#) ShcSender.h 1.6 04/12/23 15:39:45";

/*
 *  Copyright (C) 2004 eFunds Corporation ("eFunds").  All Rights Reserved.     
 *  eFunds Canada Corporation is an authorized user.                            
 *                                                                              
 *  IST is a registered trademark of eFunds Corporation.  Other brand or        
 *  product names are trademarks or registered trademarks of their respective   
 *  holders.                                                                    
 *                                                                              
 *  The information contained herein is the unpublished proprietary property    
 *  of eFunds.  Except as specifically authorized in writing by eFunds, the     
 *  holder of this document shall: i) keep all information contained herein     
 *  confidential, and ii) protect the information, in whole or in part, from    
 *  disclosure and dissemination to all third parties.                          
 *                                                                          
 *  This document and the software described in it are furnished under license  
 *  and may be used or copied only in accordance with the terms of such license.
 *  This document is supplied for information purposes only, is subject to      
 *  change without notice, and should not be construed as a commitment by       
 *  either eFunds Corporation or eFunds Canada Corporation. 
 *
 *                        MODIFICATION HISTORY                  REVIEW
 *
 *	SPR#	Who	Date	Description			Who	Date   
 * ===========================================================================
 *R007563 ztang 03Mar02 Added class for formating acceptor_name field in shcmsg
 *R009021 ztang 31Jan03	Seprated from shcfmt.h
 *
 */

#if !defined( ShcSender_h_export_directive )
#   if defined( WIN32 )
#       define ShcSender_h_export_directive __declspec(dllimport)
#   else
#       define ShcSender_h_export_directive
#   endif
#endif

#include "ist_win32.h"
#include "string.h"
#include <mb.h>
#include <ShcHelperBase.h>

class ShcmsgHeader;

#define SHC_NOTIFICATION_RESPONSE	0x00000001L
#define SHC_NOTIFICATION_REQUEST	0x00000002L
#define SHC_NOTIFICATION_ATM		0x00000004L
#define SHC_NOTIFICATION_POS		0x00000008L
#define SHC_NOTIFICATION_OTHER		0x00000010L
#define SHC_NOTIFICATION_APPROVED	0x00000020L
#define SHC_NOTIFICATION_DENIED		0x00000040L

class ShcSender_h_export_directive ShcSenderBase : public ShcHelperBase
{
public:
    const char *getName()
    {
        return (const char *)SHC_ShcSenderBase;
    }

	ShcSenderBase(const char *mboxName);
	virtual int send(ShcmsgHeader *header, const int mailboxId, const int msgLen);

protected:
	char	m_mboxName[MB_MAX_NAME + 1];
	int		m_mboxId;	/* -1 means not initialized, -2 means initialize failed */
	virtual void initialize(void);
};


class ShcSender_h_export_directive AdviceSender : public ShcSenderBase
{
public:
	AdviceSender();
    const char *getName()
    {
        return (const char *)SHC_AdviceSender;
    }
	int send(ShcmsgHeader *header, const int mailboxId, const int msgLen);
};

class ShcSender_h_export_directive AccumulationSender : public ShcSenderBase
{
public:
	AccumulationSender();
    const char *getName()
    {
        return (const char *)SHC_AccumulationSender;
    }
	int send(ShcmsgHeader *header, const int mailboxId, const int msgLen);
};

extern void setShcNotificationCondition(long condition);
extern void setShcNotificationCondition(char *strCondition);

#endif
