#ifndef SHCACCEPTORNAME_INCLUDE
#define SHCACCEPTORNAME_INCLUDE
static char _shcacceptorname_include[] = "@(#) ShcAcceptorName.h 1.6 10/04/20 07:54:41";

/*
 *  Copyright (C) 2004 eFunds Corporation ("eFunds").  All Rights Reserved.     
 *  eFunds Canada Corporation is an authorized user.                            
 *                                                                              
 *  IST is a registered trademark of eFunds Corporation.  Other brand or        
 *  product names are trademarks or registered trademarks of their respective   
 *  holders.                                                                    
 *                                                                              
 *  The information contained herein is the unpublished proprietary property    
 *  of eFunds.  Except as specifically authorized in writing by eFunds, the     
 *  holder of this document shall: i) keep all information contained herein     
 *  confidential, and ii) protect the information, in whole or in part, from    
 *  disclosure and dissemination to all third parties.                          
 *                                                                          
 *  This document and the software described in it are furnished under license  
 *  and may be used or copied only in accordance with the terms of such license.
 *  This document is supplied for information purposes only, is subject to      
 *  change without notice, and should not be construed as a commitment by       
 *  either eFunds Corporation or eFunds Canada Corporation. 
 *                    
 *
 *                        MODIFICATION HISTORY                  REVIEW
 *
 *	SPR#	Who	Date	Description			Who	Date   
 * ===========================================================================
 *R007563 ztang 03Mar02 Added class for formating acceptor_name field in shcmsg
 *R009021 ztang 31Jan03	Seprated from shcfmt.h
 *R027879 jyang 05Feb10 Acceptor name enhancement
 *R028078 dipa  20Apr10 Added store number & mall name
 */

#if !defined( ShcAcceptorName_h_export_directive )
#   if defined( WIN32 )
#       define ShcAcceptorName_h_export_directive __declspec(dllimport)
#   else
#       define ShcAcceptorName_h_export_directive
#   endif
#endif

#include "ist_win32.h"
#include <string.h>
#include <ShcHelperBase.h>
#include <istsafe.h>

class ShcmsgHeader;
											//R007563 BEGIN

//There are two usage of this class
//1. construct class use ShcAcceptorName(char *shcAcceptorName), and retrieve subfields.
//2. construct class use ShcAcceptorName(), set subfields, and retrieve the whole field.
class ShcAcceptorName_h_export_directive ShcAcceptorName : public ShcHelperBase
{
public:
    const char *getName();

	ShcAcceptorName(char *acceptorname) { loadShcmsgAcceptorname(acceptorname); }
	ShcAcceptorName();
	void getName(char *nameBuf) { istsafe_strcpy(nameBuf, 41, name); }
	void getStateName(char *stateNameBuf) { strcpy(stateNameBuf, state); }
	void getCityName(char *cityNameBuf) { strcpy(cityNameBuf, city); }
	virtual void getTwoCharCountryCode(char *countryCodeBuf);
	virtual void getThreeCharCountryCode(char *countryCodeBuf);
	virtual void getNumericCountryCode(short *countryCode);
	virtual int* getAcceptorFieldsLength();
		
	virtual void setName(const char *newName);
	virtual void setStateName(const char *newStateName);
	virtual void setCityName(const char *newCityName);
	virtual void setCountryCode(const char *newCountryCode);
	virtual void setNumericCountryCode(const short newCountryCode);
	virtual void getAcceptorName(char *acceptorNameBuf);

    virtual int compareToCountryCode(char *cc_2, char *cc_3);

private:
	static int initialized;
	static int nameLen;
	static int cityLen;
	static int stateLen;
	static int countryLen;
	
	char name[40];
	char state[20];
	char city[20];
	char twoCharCountryCode[4];
	char threeCharCountryCode[4];
	short	numericCountryCode;
	
	void initialize(void);



public:
	static const int LEN_NAME    = 40;
	static const int LEN_CITY    = 20;
	static const int LEN_STATE   = 20;
	static const int LEN_COUNTRY = 3;
	static const int LEN_ADDRESS = 40;
	static const int LEN_POSTAL  = 10;
	static const int LEN_PHONE   = 15;
	static const int LEN_STORE   = 5;  //R028078
	static const int LEN_MALL    = 21; //R028078
	static const int LEN_ADDTIONAL = 40;
	static const int LEN_EMAIL = 60;
	static const int LEN_SEG_MAX = LEN_NAME + LEN_CITY + LEN_STATE + LEN_COUNTRY + LEN_ADDRESS + LEN_POSTAL + LEN_PHONE + LEN_ADDTIONAL + LEN_STORE + LEN_MALL + LEN_EMAIL; //R028078
	
	static const int OFST_NAME  = 0;
	static const int OFST_CITY  = OFST_NAME + LEN_NAME;
	static const int OFST_STATE = OFST_CITY + LEN_CITY;
	static const int OFST_COUNTRY=OFST_STATE+ LEN_STATE;
	static const int OFST_ADDRESS=OFST_COUNTRY + LEN_COUNTRY;
	static const int OFST_POSTAL = OFST_ADDRESS + LEN_ADDRESS;
	static const int OFST_PHONE  = OFST_POSTAL  + LEN_POSTAL;
	static const int OFST_STORE  = OFST_PHONE + LEN_PHONE; //R028078
	static const int OFST_MALL   = OFST_STORE + LEN_STORE; //R028078
	static const int OFST_ADDITIONAL=OFST_MALL + LEN_MALL;
	
	static const int MAX_NETWORKS = 10;
	
	struct acceptorname_layout_t
	{
		char network[10+1];
		int  lenName;
		int  lenCity;
		int  lenState;
		int  lenCountry;
	};
	typedef struct acceptorname_layout_t ACCEPTORNAME_LAYOUT;

protected:
	char nameSeg[LEN_NAME+1];
	char citySeg[LEN_CITY+1];
	char stateSeg[LEN_STATE+1];
	char countrySeg[LEN_COUNTRY+1];
	char addressSeg[LEN_ADDRESS+1];
	char postalSeg[LEN_POSTAL+1];
	char phoneSeg[LEN_PHONE+1];
	char storeSeg[LEN_STORE+1]; //R028078
	char mallSeg[LEN_MALL+1];   //R028078
	char additional_data[LEN_ADDTIONAL+1];
        char emailSeg[LEN_EMAIL+1];

	char segBuffer[LEN_SEG_MAX+1];
	char outputBuffer[LEN_SEG_MAX+1];

	static ACCEPTORNAME_LAYOUT networkLayout[MAX_NETWORKS];
	ACCEPTORNAME_LAYOUT acceptorLayout;
	static unsigned short mySegmentId;
	
public:
	static ShcAcceptorName *getInstance() { 
		static ShcAcceptorName *_instance=NULL;
		return ( _instance ? _instance : (_instance=new ShcAcceptorName()) );
	}
	
	void loadShcmsgAcceptorname(char *acceptorname);
	virtual void  resetData();
	virtual int   isDataReady();
	virtual int   formatIt( char *target, char *source, int len, char c=' ' );	

	// output acceptor name string for formatter DE43
	virtual int   parseSegAcceptorName( const char *segData, int segLen );
	virtual char *outputAcceptorName( const char *network );
	virtual char *getAcceptorNameFromSegment( const char *segData, int segLen, const char *network );
	
	
	// generate segment data  of acceptor name string 
	virtual void  setAcceptorName(const char *name, const char *city, const char *state, const char *country);
	virtual char *generateSegmentData(const char *name, const char *city, const char *state, const char *country);
	virtual char *generateSegmentData();
	virtual char *getSegBuffer() { return segBuffer; }
	virtual void  clearSegBuffer() { memset( segBuffer, 0, sizeof(segBuffer) ); }
	
	virtual char *getNameSeg   ();
	virtual char *getCitySeg   ();
	virtual char *getStateSeg  ();
	virtual char *getCountrySeg();
	virtual char *getPostalSeg ();
	virtual char *getPhoneSeg  ();
	virtual char *getAddressSeg();
	virtual char *getStoreSeg  ();  //R028078
	virtual char *getMallSeg   ();  //R028078
	virtual char *getAdditionalData();
        virtual char *getEmailSeg();

	virtual int   getNameSeg   (char *target, int len){ return formatIt(target, nameSeg   ,len); }
	virtual int   getCitySeg   (char *target, int len){ return formatIt(target, citySeg   ,len); }
	virtual int   getStateSeg  (char *target, int len){ return formatIt(target, stateSeg  ,len); }
	virtual int   getCountrySeg(char *target, int len){ return formatIt(target, countrySeg,len); }
	virtual int   getPostalSeg (char *target, int len){ return formatIt(target, postalSeg ,len); }
	virtual int   getPhoneSeg  (char *target, int len){ return formatIt(target, phoneSeg  ,len); }
	virtual int   getAddressSeg(char *target, int len){ return formatIt(target, addressSeg,len); }
	virtual int   getStoreSeg(char *target, int len){ return formatIt(target, storeSeg,len); } //R028078
	virtual int   getMallSeg(char *target, int len){ return formatIt(target, mallSeg,len); }   //R028078
	virtual int   getAdditionalData(char *target, int len) { return formatIt(target,additional_data,len); }
        virtual int   getEmailSeg  (char *target, int len){ return formatIt(target, emailSeg  ,len); }

	virtual void  setNameSeg   ( const char *cc ) { strncpy( nameSeg,   cc, sizeof(nameSeg)-1 ); }
	virtual void  setCitySeg   ( const char *cc ) { strncpy( citySeg,   cc, sizeof(citySeg)-1 ); }
	virtual void  setStateSeg  ( const char *cc ) { strncpy( stateSeg,  cc, sizeof(stateSeg)-1 ); }
	virtual void  setCountrySeg( const char *cc ) { strncpy( countrySeg,cc, sizeof(countrySeg)-1 ); }
	virtual void  setAddressSeg( const char *cc ) { strncpy( addressSeg,cc, sizeof(addressSeg)-1 ); }
	virtual void  setPostalSeg ( const char *cc ) { strncpy( postalSeg, cc, sizeof(postalSeg)-1 ); }
	virtual void  setPhoneSeg  ( const char *cc ) { strncpy( phoneSeg,  cc, sizeof(phoneSeg)-1 ); }
	virtual void  setStoreSeg  ( const char *cc ) { strncpy( storeSeg,  cc, sizeof(storeSeg)-1 ); }    //R028078
	virtual void  setMallSeg  ( const char *cc ) { strncpy( mallSeg,  cc, sizeof(mallSeg)-1 ); }    //R028078
	virtual void  setAdditionalData( const char *cc ) { strncpy( additional_data, cc, sizeof(additional_data)-1 ); }
        virtual void  setEmailSeg  ( const char *cc ) { strncpy( emailSeg,  cc, sizeof(emailSeg)-1 ); }

	virtual char *getCountryChar2();
	virtual char *getCountryChar3();
	virtual char *getCountryChar3Digits();
	virtual int   getCountryNumeric() { return atoi(getCountryChar3Digits()); }
	
	virtual int   setLayoutDef(const char* network, int lenName, int lenCity, int lenState, int lenCountry);
	virtual ACCEPTORNAME_LAYOUT* getLayoutDef( const char* network );
	virtual int   getNameLength( const char* network ) { return getLayoutDef(network)->lenName; }
	virtual int   getCityLength( const char* network ) { return getLayoutDef(network)->lenCity; }
	virtual int   getStateLength( const char* network ) { return getLayoutDef(network)->lenState; }
	virtual int   getCountryLength( const char* network ) { return getLayoutDef(network)->lenCountry; }

	virtual int   saveSegment( ShcmsgHeader *hdr );
	virtual int   loadSegment( ShcmsgHeader *hdr );
	
};

//class ShcAcceptorName_h_export_directive ShcAcceptorNameException
//{
//public:
//	ShcAcceptorNameException(char *newErrmsg) { strcpy (errMsg, newErrmsg); }
//	const char *getErrMsg() { return errMsg; }
//private:
//	char errMsg[200];
//};
#endif
