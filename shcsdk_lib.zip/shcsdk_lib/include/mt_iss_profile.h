/*
 *  Copyright (C) 2004 eFunds Corporation ("eFunds").  All Rights Reserved.     
 *  eFunds Canada Corporation is an authorized user.                            
 *                                                                              
 *  IST is a registered trademark of eFunds Corporation.  Other brand or        
 *  product names are trademarks or registered trademarks of their respective   
 *  holders.                                                                    
 *                                                                              
 *  The information contained herein is the unpublished proprietary property    
 *  of eFunds.  Except as specifically authorized in writing by eFunds, the     
 *  holder of this document shall: i) keep all information contained herein     
 *  confidential, and ii) protect the information, in whole or in part, from    
 *  disclosure and dissemination to all third parties.                          
 *                                                                          
 *  This document and the software described in it are furnished under license  
 *  and may be used or copied only in accordance with the terms of such license.
 *  This document is supplied for information purposes only, is subject to      
 *  change without notice, and should not be construed as a commitment by       
 *  either eFunds Corporation or eFunds Canada Corporation. 
 */
/*
#pragma ident "@(#) mt_iss_profile.h 1.4.1.2 18/07/06 17:17:17"   
 *
 *                        MODIFICATION HISTORY                  REVIEW
 *
 *	SPR#	Who	Date	Description			Who	Date   
 * ===========================================================================
 *R008717 ztang 15Nov02 Created for multi-institution support
 *						Added alternateAcqBin to shc structure
 *R012134 Emj   01Oct04 Issuer Entity Support
 *        hsh   27Jun18 IST_S770SP12-154: Support addional selection conditions
 */

#ifndef ISS_PROFILE_INCLUDE
#define ISS_PROFILE_INCLUDE

#if !defined( SHCDLLEXPORT )
#   if defined( WIN32 )
#       define SHCDLLEXPORT __declspec(dllimport)
#   else
#       define SHCDLLEXPORT
#   endif
#endif


#ifdef PREPROC_MT_LIB

#if defined ( SHCDLLEXPORT )
#   undef     SHCDLLEXPORT
#   define    SHCDLLEXPORT
#endif
#endif

#include <string.h>
#include <shc.h>
#include <multi_inst_def.h>
#include <multi_institution.h>


struct IssuerProfile
{
	char	m_txnSrc[40+1];
	char	m_txnDest[40+1];
	char	m_entityId[60+1];
	char	m_cardProduct[60+1];
	char	m_msgType[40+1];
	char	m_deviceType[120+1];
	char	m_pcode[80+1];
	char	m_hasPIN;
	bin_t	m_bin;
	unsigned char	m_isLocal;
	int		m_priority;
	bin_t	m_routing_bin;
	char	m_addCondition[80+1];
};

#endif
