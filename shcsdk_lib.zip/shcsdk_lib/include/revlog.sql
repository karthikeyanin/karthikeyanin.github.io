/*
 *	IST and IST/Share are registered trademarks of Oasis Technology Ltd.
 *
 *	Copyright (C) 1990 - 1997 Oasis Technology Ltd.
 *	All Rights Reserved
 *	This Module contains Proprietary Information of
 *	Oasis Technology Ltd., and should be treated as Confidential.
 *
 *	THIS IS UNPUBLISHED PROPRIETARY SOURCE CODE OF OASIS TECHNOLOGY LTD.
 *	The copyright notice above does not evidence any  
 *	actual or intended publication of such source code.
 */
/*
#pragma ident "@(#) revlog.sql 1.7.2.2 17/04/27 13:25:47"
 *
 *				Modification History
 *
 *  SCR		Who		When		Why
 *	========================================================================
 * 	mwang		03March04	Create to store the reversal message for CUSC
 *  R021760 Emj 15Oct07     Moved bold to end of table
 *  R027170 Dipa  03Sep09   PADSS changes
 *  R032405 Dipa  20Dec13   Change local_date, cap_date from datetime to date type
*/

create table revlog (
	msgtype			int,	
	pan				pan_token_t(19) null,	
	pcode			int,					
	trace			int,					

	local_time		int,				
	local_date		date,				
	cap_date        date,

	termid			char(8) null,	
	termloc         char(25) null,
	acquirer		char(10) null,				
	issuer			char(10) null,					
	
	txnsrc			char(10) null,
	txndest			char(10) null,
	alternateacquirer char(10) null,

	entityid		char(30),
	issentityid		char(30),
	member_id		char(11) null,	
	f_id		char(11) null,	

	filler1			char(50) null,
	filler2			char(50) null,
	filler3			char(50) null,
	filler4			char(50) null,

	cardproduct		char(10) null,
	segsize         int,


	device_devcap		int,	
	device_cap		int,	
	formatter_devcap	int,	
	shc_devcap			int,	
	auth_devcap 		int,

	pos_condition_code	smallint,
	pos_pin_cap_code	char(1) null,
	pos_cap_code		smallint,
	merchant_type		smallint,
	iss_currency_code    smallint,
	shclog_id			char(20) not null,
	segdata         blob,
        site_id         smallint,
        sys_dt_time     datetime,
        status    char (1),
	refnum  CHAR(12),
	authnum CHAR(6),
	acceptorname    CHAR(40),
	counter 			int
)
create index revlog_1 on revlog (local_date, pan, trace, local_time, 
											 termid, pcode)
create unique index revlog_uix on revlog (shclog_id,site_id)

GG_PARAM revlog
(
);

