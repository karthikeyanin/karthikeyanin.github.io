/*
 *  Copyright (C) 2004 eFunds Corporation ("eFunds").  All Rights Reserved.     
 *  eFunds Canada Corporation is an authorized user.                            
 *                                                                              
 *  IST is a registered trademark of eFunds Corporation.  Other brand or        
 *  product names are trademarks or registered trademarks of their respective   
 *  holders.                                                                    
 *                                                                              
 *  The information contained herein is the unpublished proprietary property    
 *  of eFunds.  Except as specifically authorized in writing by eFunds, the     
 *  holder of this document shall: i) keep all information contained herein     
 *  confidential, and ii) protect the information, in whole or in part, from    
 *  disclosure and dissemination to all third parties.                          
 *                                                                          
 *  This document and the software described in it are furnished under license  
 *  and may be used or copied only in accordance with the terms of such license.
 *  This document is supplied for information purposes only, is subject to      
 *  change without notice, and should not be construed as a commitment by       
 *  either eFunds Corporation or eFunds Canada Corporation. 
 */
/*
#pragma ident "@(#) binroute_ext.sql 1.2 15/07/16 12:51:16";
 *
 *                        MODIFICATION HISTORY                  REVIEW
 *
 *	SPR#	Who		Date	Description			Who	Date   
 * ===========================================================================
 * Rxxxxx ztang 13Jul15 Creation
 */

/* This table is only used when binroute.extend in istparam.cfg is set to Y
 * When it's used, binroute and this table will form a outer join:
 *		binroute.node = binroute_ext.node
 *		binroute.port = binroute_ext.route
 *		binroute.site_id = binroute_ext.site_id
 * Here is the shared memory fields they are loaded to:
 *		table				shared memory
 *		route 				base_port_name
 *		sub_route			port(if empty, use route-forwarding_node)
 *		forwarding_node		blrnode
 */
create table binroute_ext
(
	node varchar(30) not null,
	route varchar(30) not null,		
	sub_route varchar(30) null,	
	forwarding_node varchar(30) not null,
	site_id smallint	
)




/*oasis is owner of index shcbin_ix*/
create index binroute_ext_ix on binroute_ext (site_id, node, route)
create UNIQUE index binroute_ext_ix_2 on binroute_ext (site_id, node, route, forwarding_node)

GG_PARAM binroute_ext
(
);
