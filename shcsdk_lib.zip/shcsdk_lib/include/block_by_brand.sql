/*
 *  Copyright (C) 2004 eFunds Corporation ("eFunds").  All Rights Reserved.     
 *  eFunds Canada Corporation is an authorized user.                            
 *                                                                              
 *  IST is a registered trademark of eFunds Corporation.  Other brand or        
 *  product names are trademarks or registered trademarks of their respective   
 *  holders.                                                                    
 *                                                                              
 *  The information contained herein is the unpublished proprietary property    
 *  of eFunds.  Except as specifically authorized in writing by eFunds, the     
 *  holder of this document shall: i) keep all information contained herein     
 *  confidential, and ii) protect the information, in whole or in part, from    
 *  disclosure and dissemination to all third parties.                          
 *                                                                          
 *  This document and the software described in it are furnished under license  
 *  and may be used or copied only in accordance with the terms of such license.
 *  This document is supplied for information purposes only, is subject to      
 *  change without notice, and should not be construed as a commitment by       
 *  either eFunds Corporation or eFunds Canada Corporation. 
 */
/*
#pragma ident "@(#) block_by_brand.sql 1.4.1.1 16/10/21 10:09:34";
 *
 *                        MODIFICATION HISTORY                  REVIEW
 *
 *	SPR#	Who		Date	Description			Who	Date   
 * ===========================================================================
 * R027802	jyang	22Jan10 Creation to support "Block by Brand"
 * R028371	Dipa 	29Jul10 Modified the data type of the fields
 */
create table block_by_brand
(
	institutionid varchar2(10) not null,
	cardproduct   varchar2(30),
	destination   varchar2(30),
	description   varchar2(255) null,
)

create unique index block_by_brand_ix on block_by_brand (institutionid, cardproduct, destination)

GG_PARAM block_by_brand
(
);

