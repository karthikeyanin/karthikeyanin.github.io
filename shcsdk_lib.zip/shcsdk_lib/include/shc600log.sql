/*
 *  Copyright (C) 2004 eFunds Corporation ("eFunds").  All Rights Reserved.     
 *  eFunds Canada Corporation is an authorized user.                            
 *                                                                              
 *  IST is a registered trademark of eFunds Corporation.  Other brand or        
 *  product names are trademarks or registered trademarks of their respective   
 *  holders.                                                                    
 *                                                                              
 *  The information contained herein is the unpublished proprietary property    
 *  of eFunds.  Except as specifically authorized in writing by eFunds, the     
 *  holder of this document shall: i) keep all information contained herein     
 *  confidential, and ii) protect the information, in whole or in part, from    
 *  disclosure and dissemination to all third parties.                          
 *                                                                          
 *  This document and the software described in it are furnished under license  
 *  and may be used or copied only in accordance with the terms of such license.
 *  This document is supplied for information purposes only, is subject to      
 *  change without notice, and should not be construed as a commitment by       
 *  either eFunds Corporation or eFunds Canada Corporation. 
 */
/*
#pragma ident "@(#) shc600log.sql 1.10.1.1 16/10/21 10:11:01"
 *
 *  MODIFICATION HISTORY                    REVIEW
 *
 *	SPR#	Who	Date	Description			Who	Date   
 * ===========================================================================
 * ACXSYS   qd  05dec97 Creation
 * IST_S_71623-1	dipa	20Mar14		GeoDisp changes: Added log_id
 */
create table shc600log 
(
	msgtype			int,			
	pan				pan_token_t(19) null,	
	mask_pan		char(19) null,	
	pcode			int,					
	txntype			int,


	amount			money,				
	aval_balance	money,		
	amount_equiv	money,
	cash_back		money,

	iss_conv_rate		money,
	iss_currency_code	smallint,		
	iss_conv_date		date,
	acq_conv_rate		money,	
	acq_currency_code	smallint,		
	acq_conv_date		date,

	tra_amount			money,	  /* qd 21feb96 */	
	tra_conv_rate		money,	  /* qd 21feb96 */	
	tra_currency_code	smallint, /* qd 21feb96 */		
	tra_conv_date		date, /* qd 21feb96 */

	fee					money,
	new_fee				money,	  /* qd 21feb96 */
	new_amount			money,    /* qd 21feb96 */
	new_setl_amount   	money, 	  /* qd 21feb96 */
	settlement_fee		money,    /* qd 21feb96 */
	settlement_rate		money,
	settlement_code		smallint,
	settlement_amount	money,


	trandate		date,				
	trantime		int,				

	trace			int,					

	local_time		int,				
	local_date		date,				

	settlement_date		date,			
	cap_date		date,				


	pos_entry_code		smallint,			
	pos_condition_code	smallint,
	pos_pin_cap_code	char(1) null,
	pos_cap_code		smallint,
	life_cycle			int,


	acquirer		char(10) null,				
	issuer			char(10) null,					
	transferee		char(10) null,  /* qd 21feb96 added */					
    originator      char(10) null,


	member_id       char(11) null,  /* member id in XMF. (for field 32 99 100... */
	f_id			char(11) null,	/* F_ID, field 33 in XMF */
	txnsrc			varchar(10) null, 	/* Institution id to indicates where the txn comes from */
	txndest			varchar(10) null,  /* Institution id to indicates where the txn goes to */		
	alternateacquirer char(10) null, /* alternate acquirer */
	entityid		varchar(30),		/* entity id defined in UDM */
	iss_entityid    varchar(30),        /* issuer entity id defined in UDM */
	device_cap		int,			/* log the device_cap field in shcmsg */
	txn_start_time	int,			/* Start time of the txn for statistic purpose */
	txn_end_time		int,			/* End time of the txn for statistic purpose */

	respcode		int,				
	reason_code		int,	/* qd 21feb96 */			
	revcode			int,				
	shcerror		int,
	saf				smallint,

	/*	reversal fields */
	origmsg			smallint,
	origtrace		int,
	origdate		date,
	origtime		int,


	/*	fields for visa */
	acq_country		smallint,

	track2			char(79) null,
	track3			char(104) null, /* qd 21feb96 */
	refnum			char(12) null,		
	authnum			char(6) null,
	termid			char(8) null,	
	acceptorname	char(40) null,	
	termloc			char(25) null,
	addresponse		char(25) null,
	/* qd 21feb96 expanded from 38 to 42 */
	acctnum			char(42) null,	/* ad: 2Jan92 expanded */
	branch			smallint,
	serial_1		int,
	serial_2		int,

	/*Jan 2/92 a.d. */

	storeid			int,
	lane			int,
	terminal_trace			int,
	checker_id			int,
	supervisor			int,
	shift_number		int,
	batch_id			int,


	/*
	 * qd	21feb96		Add the following new fields
	 */
	device_devcap		int,	
	shc_devcap			int,	
	formatter_devcap	int,	
	auth_devcap 		int,	


	/*
	 * qd	06feb96		Add spaces to hold more info
	 */
	filler1				char(50),
	filler2				char(50),
	filler3				char(50),
	filler4				char(50),

    /*
     * yh: 1997/09/22.  Add issuer_data/acquirer_data for SMS
     */
     issuer_data        char(128),
     acquirer_data      char(128),
 
    /*
     * yh: 1997/09/25. Add mode fields for multiple currency support
     */
     new_amount_equiv		money,

	 acq_aval_balance 		money,
	 acq_ledger_balance		money,
	 setl_aval_balance		money,
	 setl_ledger_balance	money,
	 
	 aval_balance_type		smallint,
	 ledger_balance_type	smallint,

	 new_setl_fee			money,
	 
	 txn_amount				money,
	 txn_new_amount			money,
	 txn_currency_code		smallint,
	 txn_conv_rate			money,
	 txn_conv_date			date,
	 
	 ch_amount				money,
	 ch_new_amount			money,
	 ch_currency_code		smallint,
	 ch_conv_rate			money,
	 ch_conv_date			date,

     ledger_balance         money,
	 adm_msg_buf            varchar(255),
	 log_id					varchar(20) not null,
	 site_id  				smallint,
	 src_node			    smallint,
	 dest_node			    smallint


)

create index shc600log_1 on shc600log (local_date, pan, trace, local_time, acquirer, termid, pcode)
create unique index shc600log_uix on shc600log(log_id, site_id);

GG_PARAM shc600log
(
);

