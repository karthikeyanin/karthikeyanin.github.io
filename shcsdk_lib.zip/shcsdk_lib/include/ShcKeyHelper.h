#ifndef _SHCKEYHELPER_H_
#define _SHCKEYHELPER_H_

static char _ShcKeyHelper_h_what[] = "@(#) ShcKeyHelper.h 1.6 19/09/27 07:42:53";

/*
 *  Copyright (C) 2004 eFunds Corporation ("eFunds").  All Rights Reserved.     
 *  eFunds Canada Corporation is an authorized user.                            
 *                                                                              
 *  IST is a registered trademark of eFunds Corporation.  Other brand or        
 *  product names are trademarks or registered trademarks of their respective   
 *  holders.                                                                    
 *                                                                              
 *  The information contained herein is the unpublished proprietary property    
 *  of eFunds.  Except as specifically authorized in writing by eFunds, the     
 *  holder of this document shall: i) keep all information contained herein     
 *  confidential, and ii) protect the information, in whole or in part, from    
 *  disclosure and dissemination to all third parties.                          
 *                                                                          
 *  This document and the software described in it are furnished under license  
 *  and may be used or copied only in accordance with the terms of such license.
 *  This document is supplied for information purposes only, is subject to      
 *  change without notice, and should not be construed as a commitment by       
 *  either eFunds Corporation or eFunds Canada Corporation. 
 *
 *
 *                        MODIFICATION HISTORY                  REVIEW
 *
 * SCR#     Who    Date  Description
 * ===========================================================================
 * R0xxxxx 
 */
 

#include <ShcSdkCommon.h>
#include <shcextbuf.h>
#include <ShcHelperBase.h>

#include <multi_institution.h>

class ShcKeyHelper : public  ShcHelperBase
{
public:
    const char *getName()
    {
        return (const char *)SHC_ShcKeyHelper;
    }

	virtual int shc_keys_set_class( char key_class, char *dest );
	virtual int shc_keys_set_type( char type, char *dest );
	virtual int shc_keys_set_index( char index, char *dest );
	virtual int shc_keys_init_buf( struct shckey_buf *bufp,	char key_class,	char type, char index );
	virtual int shc_keys_set_status( struct shckey_buf *bufp, char status );
	virtual int shc_keys_set_status_as2805( struct shckey_buf *bufp, char status, int device_flag );
	virtual int shc_keys_upd_db( struct shckey_buf *bufp );
	virtual int shc_keys_xchg( struct shckey_buf *keybufp, char *k_kpe, char *k_chk, 
					char status );
	virtual int shc_keys_xchg_td( struct shckey_buf *keybufp, char *k_kpe, char *k_chk, 
					char status, int *keylen );
	virtual int shc_keys_xchg_td_xt( struct shckey_buf *keybufp, char *k_kpe, char *k_chk,
					char status, int *keylen, int keyType );
	virtual int shc_keys_xchg_td_xt_xt( struct shckey_buf *keybufp, char *k_kpe, char *k_chk,
					char status, int *keylen, int keyType, char keyVersion, int atalla_var);
	int shc_keys_xchg_as2805( struct shckey_buf *keybufp, char *k_kpe, char *k_kpe_chk,
					char *k_mac, char *k_mac_chk, char *k_kme, char *k_kme_chk, char status);
	int shc_keys_xchg_as2805_td( struct shckey_buf *keybufp, char *k_kpe, char *k_kpe_chk,
					char *k_mac, char *k_mac_chk, char *k_kme, char *k_kme_chk, char status, int *keylen );
	int shc_keys_xchg_as2805_td_xt( struct shckey_buf *keybufp, char *k_kpe, char *k_kpe_chk,
					char *k_mac, char *k_mac_chk, char *k_kme, char *k_kme_chk, char status, int *keylen, int ketType );
	virtual int shc_keyidx(struct shckeys *shckeys);
	virtual int shc_keys_get_pointers( struct shckey_buf *bufp, short p_keyidx);
	virtual int shckeys_getnext_index(char *instid, char *key_index );
	virtual int shc_counter_check( char *buf );
	virtual int shc_counter_inc( char *buf );
	virtual int shckeys_getdbmfd();
	virtual int shc_keys_init();
	long getHashValue(const char *ptr);
	int getKeyParam(const char *instId, const char *keyparam);
	struct shcsecurity * getKey(const char *instId, const char *keyparam);
};

const char* const SHC_KeyXchgHelper = "ShcKeyXchgHelper";

class KeyXchgHelper : public ShcHelperBase
{
public:
	const char *getName() { return(const char *)SHC_KeyXchgHelper; }

	int collect(ShcKeyHelper &,struct shckey_buf *,NetworkInfo &,char);
	int preProc(ShcKeyHelper &,struct shckey_buf *,NetworkInfo &,char,int *,char *,char *&);
	int proc(struct shckey_buf *,char *,char *,char,int *,char *,char *,char*,char *);
	virtual int proc_xt(struct shckey_buf *,char *,char *,char,int *,char *,char *,char*,char *,int);
	virtual int proc_xt_xt(struct shckey_buf *,char *,char *,char,int *,char *,char *,char*,char *,int,char,int);
	int proc_as2805(struct shckey_buf *, char *, char *, char *, char *, char *, char *, char, int *, char *, char *, char *, char *, char*, char *);
	int resume(ShcKeyHelper &,struct shckey_buf *,char *,char,int *,char *,char *);
	int resume_as2805(ShcKeyHelper &,struct shckey_buf *,char *, char *, char,int *,char *,char *, char *,char *);
};

#endif

