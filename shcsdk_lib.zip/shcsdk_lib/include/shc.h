#ifndef DSWITCH
#define DSWITCH
#endif

/*
 *  Copyright (C) 2004 eFunds Corporation ("eFunds").  All Rights Reserved.
 *  eFunds Canada Corporation is an authorized user.
 *
 *  IST is a registered trademark of eFunds Corporation.  Other brand or
 *  product names are trademarks or registered trademarks of their respective
 *  holders.
 *
 *  The information contained herein is the unpublished proprietary property
 *  of eFunds.  Except as specifically authorized in writing by eFunds, the
 *  holder of this document shall: i) keep all information contained herein
 *  confidential, and ii) protect the information, in whole or in part, from
 *  disclosure and dissemination to all third parties.
 *
 *  This document and the software described in it are furnished under license
 *  and may be used or copied only in accordance with the terms of such license.
 *  This document is supplied for information purposes only, is subject to
 *  change without notice, and should not be construed as a commitment by
 *  either eFunds Corporation or eFunds Canada Corporation.
 *
 *
 *
 *                        MODIFICATION HISTORY                  REVIEW
 *
 *	SPR#	Who	Date	Description			Who	Date
 * ===========================================================================
 * 	        yh  26Aug97 Added shcLeadingZeroBin/shcLeadingZeroChar
 *          yh  09Sep97 Added new fileds in shcmsg for multiple currency support
 *  		yh  22sep97 Added acquirer_data/issuer_data for SMS
 *          la  07oct97 Added new structure and declarations for multiple keys.
 * ACXSYS   qd  24nov97 Added New fields and new configuration prameters
 * ACXSYS   qd  10dec97 Added New macro to calculate server buffer size
 * R000587  la  10jan98 Added counter pointers.
 * ACXSYS   yh  25Feb98 Added shcDeviceEncryptBalance
 * R000871	rc	23Mar98	Added padding in front of elfbuffer in shcmsg to
 *						ensure elfbuffer is appropiately aligned.
 * R000960  et  22apr98 Added shcRestoreTrantime
 * R001008  qd  14may98 Increase MAC_DATA_LEN to 512 from 255
 * R001007  wc  26may98 porting to WIN32
 * R001053  qd  05jun98 Added shcnetDebug to allow appl trace for shcnet
 * R001531  qd  25nov98 Added shcCapdateOverride for ACXSYS
 * R001531  qd  25nov98 Added more members for structure syskeys_buf
 * R001538  zt  24Dec98 Added more member cvv2 for structure shcmsg
 *				Added definition for type CONF_DATA_t
 * 0001303  yh  10mar99 Added recon_mid & settlementid.
 * R001835  qd  13apr99 Added bin level configuration to shcbin
 * R002251  zt  29Jul99 Added varaible shc_back_office_enabled
 * R002517  fg  13Aug99 Removed settlementid.
 * R002521  fg  13Aug99 Removed recon_mid.
 * R002639 	zt  01Sep99 Added network_data to structure shcextbin
 * R003308  fg  28Oct99 Move SHC configuration parameters to bin level
 *                      shc.verify_mac, shc.encrypt_balance, shc.support_NDKE
 *                      shc.restore_trantime, shc.capdate_override
 * R003309  fg  28Oct99 Remove three configuration parameters
 *                      shc.device_encrypt, shc_leading_zero_bin
 *                       shc.leading_zero_char
 * R002421	jsun	28Oct99	Added device_fee to shcmsg
 * R003638	kc	10Dec99	COPAC enhancement - add new fields to shcmsg
 * R003928  SG  25jan00 Added one more char field shc shcmsg structure
 *                      which should be overlayed by the structure.
 * R001319  rlo 16Feb00 Added a field to shc_data_buffer for logging device_cap
 * R004460 ztang24Apr00 Defined SHC_NETWORK_DATA_LEN,
 *						Added new field network_data to struct shc_data
 * R004511 ztang01May00 Changed SHC_NETWORK_DATA_LEN to
 *						SHC_NETWORK_DATA_BUF_LEN
 * R004752 jsun 08Jun00 Changed proto type of shc_getissnetkpe()
 * R004649	cg	12Jun00	Interac enhancement - log specific security errors
 * R004671(SPR2007336) Rpc  26Jun00 VSDC Enhancement.
 * R004671(SPR2007336) Mch  18Jun00 Added 1 field in shcbin struct
 * R004671(SPR2007336) Ssc  28Jun00 7.2 integration
 * R005025 ztang 14Aug00	Added avs_data to shc_data structure
 * R005141 knguyen 26sep00 increase seg size to 10K
 * R005324 emj 18dec00 Added support for multiple length keys (TDES)
 * R005924 rzhou 19Apr01 Eliminate the compilation error of shcmsg_map in NT platform
 * R005896	jy	31May01	extern and export function shc_saf_resp_convertmsg()
 * R006136 emj 15Jun01 Added include of time.h
 * R006365 rzhou 03Aug01 Added a new structur _secdukpt_t for DUKPT support
 * R006401 ztang 21Jun01 Added new field cvv_resultcode
 * R007062 gbeeng 04Dec01 Removed function prototype for local function of
 *							shc_util
 * R007206,R007237 jyang 10Jan02 export two function prototypes for Europay
 * R006976 jyang 08Mar02 Extend CVV2 field to 5 chars to cantain 4 digits for AMEX
 * R007498 rzhou 11Mar02 Added UCAF data in shcmsg buffer
 * R007650 jyang 29Mar02 Changed UCAF_indicator type to char to fix BusError bug
 *R007781 ztang 02May02	Added shc_is_empty_buf()
 * R007908 Emj 19Jun02  Added function shc_setupLogging()
 *R007984 jyang 21Jun02 Added omsg_chip_index field
 *R008049 ztang 15Jul02	Added pos_condition_code_x to shc_data structure
 *R007197 ztang 06Aug02 Added networkCAVVResult, and issuerCAVVResult to shc_data structure
 *R008224 ztang 06Sep02 Added shcSendIss_VoidNoOrig
 *R008689 ztang 05Dec02 Added shclog_specified_msgtype
 *R008717 ztang 15Nov02 Multi-institution support, changed:
 *                      shcmsg structure
 *                      shcbin structure
 *                      shcextbin structure
 *R008844 Emj   15Jan03 Increase key fields to 74 + 1 to hold Atalla Key Block
 *R008925 ztang 22jan03 Increase alpha_response_code to 3+1.
 *R009021 ztang 01Feb03 include ShcAcceptorName.h
 *R009132 ztang 12Feb03	rewind shclog_add and shclog_cheque
 *R009398 Emj   10Feb03 Added function to get next key index
 *R009697 rzhou 02May03 Expanded shc_data to contain additional indicator
 *R009493 Emj   10Jun03 Added function for shccmd commands at inst profile level
 *R009904 Emj   16Jul03 Added new trigger for acquirer ISS KPE
 *R010134 jyang 22Sep03 Added pcode_req to save request message pcode
 *R012134 Emj   04Oct04 Issuer entity Support
 *R012160 Emj   10Oct03 Added Processor Business Day
 *R011307 Emj   18Oct04 Removed Cutoff from shcbin structure
 *R011925 jyang 16Sep04 Saf interleave support
 *R015826 pve	02Mar06 Add Generic Log class object
 *R019657 Emj   18Apr07 Moved include of shcseg.h to after struct shcmsg 
 *R028470 Ash	28Aug10 Chip to Magnetic Stripe Conversion Service Enhancements - Fall 2010 Compliance 
 *R029416 las   18May11 add issuer country code to shcextbin struct
 *R030207 dipa  01Feb12 Clone R029189
 *R030207 dipa  14Feb12 Increse the size of RoutingInfo struct fields - mailbox, port
 *R030207 dipa  28Feb12 Revert the fix - Increse the size of RoutingInfo struct fields - mailbox, port
 *R030556 dipa	04Jun12 B/w compatibility for SHM versioning
 *IST_S761SP8-47	dipa	17Apr14	Clone of R032410,IST_S761SP7-5
 */


#ifndef SHC_INCLUDE
#define SHC_INCLUDE

static const char* _shc_h_what = "@(#) shc.h 1.30.16.14 20/03/19 10:26:16";

#if !defined( SHCDLLEXPORT )
#   if defined( WIN32 )
#       define SHCDLLEXPORT __declspec(dllimport)
#   else
#       define SHCDLLEXPORT
#   endif
#endif


#ifdef PREPROC_SHCMSG

#if defined ( SHCDLLEXPORT )
#   undef     SHCDLLEXPORT
#   define    SHCDLLEXPORT
#endif

/* >> R005924 */
#if defined(WIN32)
#include <ist_dec.h>
#include <shcdef.h>
#include <shckeys.h>
#include <pinverparm.h>
#include <ic/ic.h>
#define dec_t oasis_dec_t


#endif
/* R005924 << */

#endif


#ifndef PREPROC_SHCMSG

/*------------------------------------------------------------------------*
 * Include Block
 *------------------------------------------------------------------------*/
#include <time.h>
#include "ist_win32.h"
#include <ic/ic.h>

#ifndef MBMSG_INCLUDE
#include <mbmsg.h>
#endif

#include <mb.h>

#include <dbm.h>

#include <shcerror.h>
#include <shcdb.h>
#include <shcdef.h>
/* #include <shcpreauth.h> */
#include <pinverparm.h>
#include <multi_inst_def.h>
#include <shclog.h>
#endif /* PREPROC_SHCMSG */

#include <stl/vector.h>

/*------------------------------------------------------------------------*
 * Macro Block
 *------------------------------------------------------------------------*/

int shc_makekey(struct shc *shcP);
int shc_gettrace(int t);

extern struct shclog *_tmplog; //Used to get size of fields, no really used

/*
 *	Define the types
 */
typedef dec_t	amount_t;		/*	amount type */
typedef	char	bin_t[11];			/*	bin type */
#include <ist_date_def.h>
#define MAX_KEYLEN     160   //MAX Key Length
struct  _seckey_t {
	char	key[MAX_KEYLEN+1];		/*	the key  R005324 increase to 48*/
	char	chk[24+1];			/*	the check digits */
};

typedef	struct	_seckey_t	seckey_t;

/* R006365 >> */
struct  _secdukpt_t {
	char	KSNdesc[4];		/*	3 bytes KSN descriptor: bdk ndentifier length + '0' + device identifier length */
	char	KSN[21];			/*	KSN length: 10 - 20 bytes */
};

typedef	struct	_secdukpt_t	secdukpt_t;
/* << R006365 */
								/* R004511 */
#define SHC_NETWORK_DATA_BUF_LEN	11	/*network_data length MAX */ /*R004460*/

															/* R008717 BEGIN */
#define MAX_TXN_DESTINATION_LEN 10		/* max txn destination name len */
#define MAX_ENTITY_ID_LEN 30		/* max Entity Id len */
#define MAX_CARD_BRAND_NAME_LEN 10
															/* R008717 END */
#define MAX_ATM_INQ_FILE_SIZE	512 * 4		/* max segment size for atm inq file */


#define SHC_PAN_LEN		19			/*	pan length MAX */
#define SHC_TRACK2_LEN	79			/*	length of track two on card */
#define SHC_TRACK3_LEN	104			/*  qd 21feb96 track three length */
#define SHC_REFNUM_LEN	12			/*	reference retrieval number */
#define SHC_AUTHNUM_LEN	6			/*	issuers auth. number */
#define SHC_TERMID_LEN	8			/*	terminal id length */
#define SHC_ACCEPT_LEN	40			/*	acceptor name and location */
#define SHC_PIN_LEN		16			/*	pin length */
#define SHC_TERMLOC_LEN	25
#define SHC_MACVALUE_LEN	16		/*	mac value on each message */
#define SHC_BIN_LEN		10			/*	length of a BIN number */
#define SHC_FORMATTER_USE	255     /*  qd 24nov97 Inc to 255 for ACXSYS* */
#define SHC_ADDRESPONSE_LEN		25
/* qd 21feb96 change account number length from 39 to 42 */
#define SHC_ACCT_LEN			65	 /*	additional or returned acct # */
#define SHC_BANKNAME_LEN		22
/*
 * qd: 06feb96  Filler spaces to store more info
 */
#define SHC_FILLER_LEN		    50

#define SHC_KEY_LEN		        16   /* qd 24nov97 added for ACXSYS */
#define MAC_DATA_LEN	        512  /* R001008 */
#define ADM_MSG_LEN	            255  /* qd 24nov97 added for ACXSYS */
#define KEY_CNT_LEN	            20   /* qd 24nov97 added for ACXSYS */

													/* R001538 BEGIN */
/* Definitions of field length for CONF_DATA_t */
#define CVV_LEN	            	3    /* Length of CVV*/
#define SHC_CONF_PASSWORD_LEN	30	 /* Length of the Password */
#define SHC_CONF_BIRTHDATE_LEN	8	 /* Length of the birthdate */
#define SHC_CONF_EMBNAME_1_LEN	25	 /* Length of the name on card */
#define SHC_CONF_CITY_LEN		35	 /* Length of city name */
#define SHC_CONF_STREET_ADDR_LEN 	35	/* Length of street address */
#define SHC_CONF_COUNTRY_CODE_LEN	3	/* Length of the country code */
#define SHC_CONF_POSTAL_CODE_LEN	10	/* Length of the postal code */
#define SHC_CONF_MMN_LEN		25	/* Length of the mother's maiden name */
#define SHC_CONF_SSN_LEN		10	/* Length of the social security number */
#define SHC_CONF_MAGIC_NUM		168	/* Magic number of confidential structure */
#define SHC_DATA_LEN            254 /*Buffer for SHC R003928*/

#define TAG_TRIP_LEG_KEY						"TA0"
#define TAG_TRIP_CARRIER_CODE					"TA1"
#define TAG_TRIP_FLIGHT_NUMBER					"TA2"
#define TAG_TRIP_DEPARTURE_DATE					"TA3"
#define TAG_TRIP_DEPARTURE_TIME_SEGMENT			"TA4"
#define TAG_TRIP_ARRIVAL_DATE					"TA5"
#define TAG_TRIP_ARRIVAL_TIME_SEGMENT			"TA6"
#define TAG_TRIP_ORIGIN_CITY_AIRPORT_CODE		"TA7"
#define TAG_TRIP_DESTINATION_CITY_AIRPORT_CODE	"TA8"
#define TAG_TRIP_SERVICE_CLASS_CODE				"TA9"
#define TAG_TRIP_FARE_BASIS_CODE				"TB0"
#define TAG_TRIP_STOP_OVER_CODE					"TB1"
#define TAG_TRIP_CONJUNCTION_TICKET				"TB2"
#define TAG_TRIP_EXCHANGE_TICKET				"TB3"
#define TAG_TRIP_AMOUNT_FARE_TICKET_LEG			"TB4"
#define TAG_TRIP_FARE_TICKET_LEG_CURR_CODE		"TB5"
#define TAG_TRIP_AMOUNT_FEE_TICKET_LEG			"TB6"
#define TAG_TRIP_FEE_TICKET_LEG_CURR_CODE		"TB7"
#define TAG_TRIP_AMOUNT_TAX_TICKET_LEG			"TB8"
#define TAG_TRIP_TAX_TICKET_CURR_CODE			"TB9"
#define TAG_TRIP_COUPON_NUMBER					"TC0"
#define TAG_TRIP_ENDORSE_RESTRICTION			"TC1"
#define TAG_TRIP_ISSUE_DATE						"TC2"
#define TAG_TRIP_TOTAL_TAX_AMOUNT				"TC3"
#define TAG_TRIP_TOTAL_TAX_CURR_CODE			"TC4"
#define TAG_TRIP_TOTAL_TAX_COLLECTION_INDICATOR	"TC5"
#define TAG_TRIP_CARD_SCHEME					"TC6"
#define TAG_TRIP_DEPARTURE_TAX_AMOUNT			"TC7"
#define TAG_TRIP_DEPARTURE_TAX_CURR_CODE		"TC8"

/* CAM Result length */
#define CAM_RESULT_LEN 16

#define TAG_PASSENGER_TRANSPORT_TICKET_ISSUE_DATE			"T00"
#define TAG_PASSENGER_TRANSPORT_CUSTOMER_CODE				"T01"
#define TAG_PASSENGER_TRANSPORT_PASSENGER_NAME				"T02"
#define TAG_PASSENGER_TRANSPORT_COMPUTER_RESERVATION_SYSTEM		"T03"
#define TAG_PASSENGER_TRANSPORT_TRAVEL_AGENCY_CODE			"T04"
#define TAG_PASSENGER_TRANSPORT_TRAVEL_AGENCY_NAME                      "T05"
#define TAG_PASSENGER_TRANSPORT_RESTRICTED_TICKET_INDICATOR             "T06"
#define TAG_PASSENGER_TRANSPORT_ISSUING_CARRIER_CODE                    "T07"
#define TAG_PASSENGER_TRANSPORT_AMOUNT_TOTAL_FARE                       "T08"
#define TAG_PASSENGER_TRANSPORT_TOTAL_FARE_CURR_CODE                    "T09"
#define TAG_PASSENGER_TRANSPORT_AMT_TOTAL_FEES                          "T10"
#define TAG_PASSENGER_TRANSPORT_TOTAL_FEES_CURR_CODE                    "T11"
#define TAG_PASSENGER_TRANSPORT_AMOUNT_TOTAL_TAXES                      "T12"
#define TAG_PASSENGER_TRANSPORT_TOTAL_TAXES_CURR_CODE                   "T13"
#define TAG_PASSENGER_TRANSPORT_COUPON_NUMBER                           "T14"
#define TAG_PASSENGER_TRANSPORT_TICKET_ID                               "T15"
#define TAG_PASSENGER_TRANSPORT_CARRIER_NAME                            "T16"
#define TAG_PASSENGER_TRANSPORT_AIRLINE_TRANSACTION_TYPE                "T17"
#define TAG_PASSENGER_TRANSPORT_ISSUER_CITY                             "T18"
#define TAG_PASSENGER_TRANSPORT_NUMBER_OF_PEOPLE_IN_PARTY               "T19"
#define TAG_PASSENGER_TRANSPORT_MISC_DOCUMENT_TYPE                      "T20"
#define TAG_PASSENGER_TRANSPORT_DOCUMENT_NUMBER                         "T21"
#define TAG_PASSENGER_TRANSPORT_ROUTE_DESCRIPTION                       "T22"
#define TAG_PASSENGER_TRANSPORT_EXTENDED_PAY_CODE                       "T23"
#define TAG_PASSENGER_TRANSPORT_COMMODITY_CODE                          "T24"
#define TAG_PASSENGER_TRANSPORT_TAX_EXEMPT_INDICATOR                    "T25"
#define TAG_PASSENGER_TRANSPORT_AMOUNT_EXCHANGE_TICKET                  "T26"
#define TAG_PASSENGER_TRANSPORT_EXCHANGE_TICKET_CODE                    "T27"
#define TAG_PASSENGER_TRANSPORT_AMOUNT_EXCHANGE_FEE                     "T28"
#define TAG_PASSENGER_TRANSPORT_EXCHANGE_FEE_CURR_CODE                  "T29"
#define TAG_PASSENGER_TRANSPORT_TRAVEL_AUTHORIZATION_CODE               "T30"
#define TAG_PASSENGER_TRANSPORT_IATA_CLIENT_CODE                        "T31"
#define TAG_PASSENGER_TRANSPORT_CONTROL_ID                              "T32"
#define TAG_PASSENGER_TRANSPORT_NATIONAL_TAX_AMOUNT                     "T33"
#define TAG_PASSENGER_TRANSPORT_NATIONAL_TAX_CURR_CODE                  "T34"
#define TAG_PASSENGER_TRANSPORT_EXCHANGE_TICKET_IDENTIFIER              "T35"
#define TAG_PASSENGER_TRANSPORT_EXCHANGE_TICKET_INDICATOR               "T36"
#define TAG_PASSENGER_TRANSPORT_INTERNET_INDICATOR                      "T37"
#define TAG_PASSENGER_TRANSPORT_TOTAL_TAX_AMOUNT                        "T38"
#define TAG_PASSENGER_TRANSPORT_TOTAL_TAX_CURR_CODE                     "T39"
#define TAG_PASSENGER_TRANSPORT_TOTAL_TAX_COLLECTION_INDICATOR		    "T40"
#define TAG_PASSENGER_TRANSPORT_IATA_NUMBER_CODE                            "T41"
#define TAG_PASSENGER_TRANSPORT_CONJUNCTION_TICKET_INDICATOR                "T42"
#define TAG_PASSENGER_TRANSPORT_TRAVEL_PACKAGE_INDICATOR                    "T43"
#define TAG_PASSENGER_TRANSPORT_COMMENTS                                    "T44"
#define TAG_PASSENGER_TRANSPORT_PLAN_NUMBER                                 "T45"
#define TAG_PASSENGER_TRANSPORT_INVOICE_NUMBER                              "T46"
#define TAG_PASSENGER_TRANSPORT_ORIGINAL_AMOUNT                             "T47"
#define TAG_PASSENGER_TRANSPORT_ORIGINAL_AMOUNT_CURR_CODE                   "T48"
#define TAG_PASSENGER_TRANSPORT_ARRIVAL_DATE                                "T49"
#define TAG_PASSENGER_TRANSPORT_TICKET_TYPE                                 "T50"
#define TAG_PASSENGER_TRANSPORT_CORPORATION_CLIENT_CODE                     "T51"
#define TAG_PASSENGER_TRANSPORT_CUSTOMER_REFERENCE_NUMBER                   "T52"
#define TAG_PASSENGER_TRANSPORT_CARD_SCHEME                                 "T53"
#define TAG_PASSENGER_TRANSPORT_CREDIT_REASON_INDICATOR                     "T54"
#define TAG_PASSENGER_TRANSPORT_TICKET_CHANGE_INDICATOR                     "T55"
#define TAG_PASSENGER_TRANSPORT_ANCILLARY_TICKET_ID                         "T56"
#define TAG_PASSENGER_TRANSPORT_ANCILLARY_SERVICE_CATEGORY_CODE1            "T57"
#define TAG_PASSENGER_TRANSPORT_ANCILLARY_SERVICE_SUBCATEGORY_CODE1         "T58"
#define TAG_PASSENGER_TRANSPORT_ANCILLARY_SERVICE_CATEGORY_CODE2            "T59"
#define TAG_PASSENGER_TRANSPORT_ANCILLARY_SERVICE_SUBCATEGORY_CODE2         "T60"
#define TAG_PASSENGER_TRANSPORT_ANCILLARY_SERVICE_CATEGORY_CODE3            "T61"
#define TAG_PASSENGER_TRANSPORT_ANCILLARY_SERVICE_SUBCATEGORY_CODE3         "T62"
#define TAG_PASSENGER_TRANSPORT_ANCILLARY_SERVICE_CATEGORY_CODE4            "T63"
#define TAG_PASSENGER_TRANSPORT_ANCILLARY_SERVICE_SUBCATEGORY_CODE4         "T64"
#define TAG_PASSENGER_TRANSPORT_ANCILLARY_PASSENGER_NAME                    "T65"
#define TAG_PASSENGER_TRANSPORT_ANCILLARY_CREDIT_REASON_INDICATOR           "T66"
#define TAG_PASSENGER_TRANSPORT_ANCILLARY_ADDITIONAL_TICKET_ID              "T67"
#define TAG_PASSENGER_TRANSPORT_ISSUER_NAME                                 "T68"
#define TAG_PASSENGER_TRANSPORT_ETICKET_INDICATOR                           "T69"
#define TAG_PASSENGER_TRANSPORT_CONJUNCTION_TICKET                          "T70"
#define TAG_PASSENGER_TRANSPORT_BUSINESS_APPLICATION_ID                     "T71"
#define TAG_PASSENGER_TRANSPORT_ANCILLARY_BUSINESS_APPLICATION_ID           "T72"
#define TAG_PASSENGER_TRANSPORT_AIRLINE_PNR_NUMBER                          "T73"
#define TAG_PASSENGER_TRANSPORT_NUMBER_OF_LEGS                              "T74"

#define TAG_INSURANCE_POLICY_TYPE			 "IN0"
#define TAG_INSURANCE_COVERAGE_PERIOD                    "IN1"
#define TAG_INSURANCE_COVERAGE_DATES                     "IN2"
#define TAG_INSURANCE_INSURANCE_CHARGE_TYPE              "IN3"
#define TAG_INSURANCE_POLICY_NUMBER                      "IN4"
#define TAG_INSURANCE_COVERAGE_START_DATE                "IN5"
#define TAG_INSURANCE_COVERAGE_END_DATE                  "IN6"
#define TAG_INSURANCE_PREMIUM_FREQUENCY                  "IN7"
#define TAG_INSURANCE_ADDITIONAL_POLICY_NUMBER           "IN8"
#define TAG_INSURANCE_NAME_OF_INSURED                    "IN9"

#define TAG_VEHICLE_RENTAL_RENTAL_AGREEMT_NUMBER			                "V00"
#define TAG_VEHICLE_RENTAL_RENTER_NAME			                            "V01"
#define TAG_VEHICLE_RENTAL_RENTAL_RETURN_CITY		                    	"V02"
#define TAG_VEHICLE_RENTAL_RENTAL_RETURN_STATE		                       	"V03"
#define TAG_VEHICLE_RENTAL_RENTAL_RETURN_COUNTRY	                       	"V04"
#define TAG_VEHICLE_RENTAL_RENTAL_RETURN_DATE		                        "V05"
#define TAG_VEHICLE_RENTAL_RENTAL_RETURN_LOCID		                        "V06"
#define TAG_VEHICLE_RENTAL_RENTAL_LOCATION_CITY		                     	"V07"
#define TAG_VEHICLE_RENTAL_RENTAL_LOCATION_STATE		                   	"V08"
#define TAG_VEHICLE_RENTAL_RENTAL_LOCATION_COUNTRY		                  	"V09"
#define TAG_VEHICLE_RENTAL_RENTAL_LOCATIONID			                    "V10"
#define TAG_VEHICLE_RENTAL_RENTAL_CUSTOMER_SERVICE_PHONE	         		"V11"
#define TAG_VEHICLE_RENTAL_CSI_TOLL_FREE_NUMBER			                    "V12"
#define TAG_VEHICLE_RENTAL_RENTAL_CLASS_CODE			                    "V13"
#define TAG_VEHICLE_RENTAL_RENTAL_RATE_INDICATOR			                "V14"
#define TAG_VEHICLE_RENTAL_AMOUNT_DAILY_RATE			                    "V15"
#define TAG_VEHICLE_RENTAL_DAILY_RATE_CURRCODE			                    "V16"
#define TAG_VEHICLE_RENTAL_AMOUNT_WEEKLY_RATE			                    "V17"
#define TAG_VEHICLE_RENTAL_WEEKLY_RATE_CURRCODE			                    "V18"
#define TAG_VEHICLE_RENTAL_AMOUNT_MONTHLY_RATE			                    "V19"
#define TAG_VEHICLE_RENTAL_MONTHLY_RATE_CURRCODE			                "V20"
#define TAG_VEHICLE_RENTAL_AMOUNT_RATE_MILE_KM			                    "V21"
#define TAG_VEHICLE_RENTAL_RATE_MILE_KM_CURRCODE			                "V22"
#define TAG_VEHICLE_RENTAL_TOTAL_MILE_KM			                        "V23"
#define TAG_VEHICLE_RENTAL_MAXIMUM_FREE_MILE_KM			                    "V24"
#define TAG_VEHICLE_RENTAL_INSURANCE_INDICATOR			                    "V25"
#define TAG_VEHICLE_RENTAL_AMOUNT_INSURANCE_CHARGE			                "V26"
#define TAG_VEHICLE_RENTAL_INSURANCE_CHG_CURR_CODE			                "V27"
#define TAG_VEHICLE_RENTAL_AMOUNT_FUEL_CHARGE			                    "V28"
#define TAG_VEHICLE_RENTAL_FUEL_CHARGE_CURR_CODE			                "V29"
#define TAG_VEHICLE_RENTAL_AMOUNT_ONEWAY_DROPOFF			                "V30"
#define TAG_VEHICLE_RENTAL_ONEWAY_DROPOFF_CURRCODE			                "V31"
#define TAG_VEHICLE_RENTAL_ADJUST_INDICATOR			                        "V32"
#define TAG_VEHICLE_RENTAL_AMOUNT_ADJUST			                        "V33"
#define TAG_VEHICLE_RENTAL_AMOUNT_ADJUST_CURRCODE			                "V34"
#define TAG_VEHICLE_RENTAL_PROGRAM_CODE			                            "V35"
#define TAG_VEHICLE_RENTAL_RENTAL_CHECKOUT_DATE			                    "V36"
#define TAG_VEHICLE_RENTAL_MILE_KM_INDICATOR			                    "V37"
#define TAG_VEHICLE_RENTAL_AMOUNT_RENTAL_EXTRA_CHARGE		                "V38"
#define TAG_VEHICLE_RENTAL_RENTAL_EXTRA_CHARGE_CURRCODE	                    "V39"
#define TAG_VEHICLE_RENTAL_DAYS_RENTED			                            "V40"
#define TAG_VEHICLE_RENTAL_NO_SHOW_INDICATOR		     	                "V41"
#define TAG_VEHICLE_RENTAL_RENTAL_BUSINESS_FORMAT_CODE		                "V42"
#define TAG_VEHICLE_RENTAL_COMMODITY_CODE			                        "V43"
#define TAG_VEHICLE_RENTAL_RENTAL_EXTRA_SERVICE_CODE		                "V44"
#define TAG_VEHICLE_RENTAL_TAX_EXEMPT_INDICATOR			                    "V45"
#define TAG_VEHICLE_RENTAL_CORPORATE_ID			                            "V46"
#define TAG_VEHICLE_RENTAL_AMOUNT_WEEKLY_RENTAL			                    "V47"
#define TAG_VEHICLE_RENTAL_WEEKLY_RENTAL_CURRCODE			                "V48"
#define TAG_VEHICLE_RENTAL_AMOUNT_TOTAL_AUTH			                    "V49"
#define TAG_VEHICLE_RENTAL_TOTAL_AUTH_CUR_CODE			                    "V50"
#define TAG_VEHICLE_RENTAL_AMOUNT_REGULAR_MILE_CHARGE			            "V51"
#define TAG_VEHICLE_RENTAL_REGULAR_MILE_CHARGE_CURRCODE			            "V52"
#define TAG_VEHICLE_RENTAL_AMOUNT_EXTRA_MILE_CHARGE			                "V53"
#define TAG_VEHICLE_RENTAL_EXTRA_MILE_CHARGE_CURRCODE			            "V54"
#define TAG_VEHICLE_RENTAL_LATE_CHARGE_AMOUNT			                    "V55"
#define TAG_VEHICLE_RENTAL_LATE_CHARGE_CURRCODE			                    "V56"
#define TAG_VEHICLE_RENTAL_TOWING_CHARGE_AMOUNT			                    "V57"
#define TAG_VEHICLE_RENTAL_TOWING_CHARGE_CURRCODE			                "V58"
#define TAG_VEHICLE_RENTAL_OTHER_CHARGE_AMOUNT			                    "V59"
#define TAG_VEHICLE_RENTAL_OTHER_CHARGE_CURRCODE			                "V60"
#define TAG_VEHICLE_RENTAL_TOTAL_TAX_AMOUNT			                        "V61"
#define TAG_VEHICLE_RENTAL_TOTAL_TAX_CURRCODE			                    "V62"
#define TAG_VEHICLE_RENTAL_TOTAL_TAX_COLLECTION_INDICATOR			        "V63"
#define TAG_VEHICLE_RENTAL_CUSTOMER_CODE			                        "V64"
#define TAG_VEHICLE_RENTAL_VEHICLE_REGISTRATION_NUMBER			            "V65"
#define TAG_VEHICLE_RENTAL_ADDTIONAL_DRIVERS			                    "V66"
#define TAG_VEHICLE_RENTAL_AGE			                                    "V67"
#define TAG_VEHICLE_RENTAL_ODOMETER		                                 	"V68"
#define TAG_VEHICLE_RENTAL_VEHICLE_MAKE			                            "V69"
#define TAG_VEHICLE_RENTAL_VEHICLE_MODEL			                        "V70"
#define TAG_VEHICLE_RENTAL_TRAVEL_AGENCY_CODE		                     	"V71"
#define TAG_VEHICLE_RENTAL_TRAVEL_AGENCY_NAME		                     	"V72"
#define TAG_VEHICLE_RENTAL_TAX_TYPE			                                "V73"
#define TAG_VEHICLE_RENTAL_TAX_RATE			                                "V74"
#define TAG_VEHICLE_RENTAL_TAX_ELEMENTS		                         	    "V75"
#define TAG_VEHICLE_RENTAL_COUPON			                                "V76"
#define TAG_VEHICLE_RENTAL_ADDITIONAL_COUPON			                    "V77"
#define TAG_VEHICLE_RENTAL_VEHICLE_PROGRAM_CODE			                    "V78"
#define TAG_VEHICLE_RENTAL_PHONE_CHARGES_AMOUNT			                    "V79"
#define TAG_VEHICLE_RENTAL_PHONE_CHARGES_CURRCODE			                "V80"
#define TAG_VEHICLE_RENTAL_GPS_CHARGES_AMOUNT			                    "V81"
#define TAG_VEHICLE_RENTAL_GPS_CHARGES_CURRCODE			                    "V82"
#define TAG_VEHICLE_RENTAL_COMMENTS			                                "V83"
#define TAG_VEHICLE_RENTAL_TOTAL_AMOUNT			                            "V84"
#define TAG_VEHICLE_RENTAL_TOTAL_AMOUNT_CURRCODE			                "V85"
#define TAG_VEHICLE_RENTAL_RENTAL_RETURN_ADDRESS			                "V86"
#define TAG_VEHICLE_RENTAL_RENTAL_ADDRESS			                        "V87"
#define TAG_VEHICLE_RENTAL_CARD_SCHEME			                            "V88"
#define TAG_VEHICLE_RENTAL_RENTAL_AGENCY_NAME			                    "V89"
#define TAG_VEHICLE_RENTAL_BUSINESS_APPLICATIONID			                "V90"

#define TAG_TRAVEL_AGENCY_ADDENDUM_SEQUENCE									"TA0"
#define TAG_TRAVEL_AGENCY_CUSTOM_ID_TYPE									"TA1"
#define TAG_TRAVEL_AGENCY_CUSTOM_ID_DETAIL									"TA2"
#define TAG_TRAVEL_AGENCY_SEQUENCE_NUMBER									"TA3"
#define TAG_TRAVEL_AGENCY_FEE_AMOUNT										"TA4"
#define TAG_TRAVEL_AGENCY_FEE_CURR_CODE										"TA5"
#define TAG_TRAVEL_AGENCY_FEE_RATE											"TA6"
#define TAG_TRAVEL_AGENCY_FEE_DESC											"TA7"

#define TAG_HEALTH_CARE_AMOUNT_TYPE											"HC0"
#define TAG_HEALTH_CARE_AMOUNT_CURRENCY										"HC1"
#define TAG_HEALTH_CARE_AMOUNT												"HC2"
#define TAG_HEALTH_CARE_AMOUNT_SIGN											"HC3"

#define TAG_COMM_SERVICES_CALL_DATE											"CS0"
#define TAG_COMM_SERVICES_CALL_TIME											"CS1"
#define TAG_COMM_SERVICES_CALL_DURATION_TIME								"CS2"
#define TAG_COMM_SERVICES_CALL_FROM_LOCATION_NAME							"CS3"
#define TAG_COMM_SERVICES_CALL_FROM_REGION_CODE								"CS4"
#define TAG_COMM_SERVICES_CALL_FROM_COUNTRY_CODE							"CS5"
#define TAG_COMM_SERVICES_CALL_FROM_PHONE_NUMBER							"CS6"
#define TAG_COMM_SERVICES_CALL_TO_LOCATION_NAME								"CS7"
#define TAG_COMM_SERVICES_CALL_TO_REGION_CODE								"CS8"
#define TAG_COMM_SERVICES_CALL_TO_COUNTRY_CODE								"CS9"
#define TAG_COMM_SERVICES_CALL_TO_PHONE_NUMBER								"CT0"
#define TAG_COMM_SERVICES_PHONE_CARD_ID										"CT1"
#define TAG_COMM_SERVICES_SERVICE_DESCRIPTION								"CT2"
#define TAG_COMM_SERVICES_BILLING_PERIOD									"CT3"
#define TAG_COMM_SERVICES_COMMUNICATIONS_CALL_TYPE_CODE						"CT4"
#define TAG_COMM_SERVICES_COMMUNICATIONS_RATE_CLASS							"CT5"

#define TAG_ENTRTNMNT_TCKTING_EVENT_NAME                                    "ET0"
#define TAG_ENTRTNMNT_TCKTING_EVENT_DATE                                    "ET1"
#define TAG_ENTRTNMNT_TCKTING_TICKET_INDIVIDUAL_TICKET_SIZE_AMOUNT          "ET2"
#define TAG_ENTRTNMNT_TCKTING_EVENT_TICKET_QUANTITY                         "ET3"
#define TAG_ENTRTNMNT_TCKTING_EVENT_LOCATION                                "ET4"
#define TAG_ENTRTNMNT_TCKTING_EVENT_REGION_CODE                             "ET5"
#define TAG_ENTRTNMNT_TCKTING_EVENT_COUNTRY_CODE                            "ET6"

#define TAG_RETAIL_INDUSTRY_RETAIL_DEPARTMENT_NAME                          "R00"
#define TAG_RETAIL_INDUSTRY_RETAIL_ITEM_DESCRIPTION1                        "R01"
#define TAG_RETAIL_INDUSTRY_RETAIL_QUANTITY1                                "R02"
#define TAG_RETAIL_INDUSTRY_RETAIL_ITEM_AMOUNT1                             "R03"
#define TAG_RETAIL_INDUSTRY_RETAIL_ITEM_DESCRIPTION2                        "R04"
#define TAG_RETAIL_INDUSTRY_RETAIL_ITEM_QUANTITY2                           "R05"
#define TAG_RETAIL_INDUSTRY_RETAIL_ITEM_AMOUNT2                             "R06"
#define TAG_RETAIL_INDUSTRY_RETAIL_ITEM_DESCRIPTION3                        "R07"
#define TAG_RETAIL_INDUSTRY_RETAIL_ITEM_QUANTITY3                           "R08"
#define TAG_RETAIL_INDUSTRY_RETAIL_ITEM_AMOUNT3                             "R09"
#define TAG_RETAIL_INDUSTRY_RETAIL_ITEM_DESCRIPTION4                        "R10"
#define TAG_RETAIL_INDUSTRY_RETAIL_ITEM_QUANTITY4                           "R11"
#define TAG_RETAIL_INDUSTRY_RETAIL_ITEM_AMOUNT4                             "R12"
#define TAG_RETAIL_INDUSTRY_RETAIL_ITEM_DESCRIPTION5                        "R13"
#define TAG_RETAIL_INDUSTRY_RETAIL_ITEM_QUANTITY5                           "R14"
#define TAG_RETAIL_INDUSTRY_RETAIL_ITEM_AMOUNT5                             "R15"
#define TAG_RETAIL_INDUSTRY_RETAIL_ITEM_DESCRIPTION6                        "R16"
#define TAG_RETAIL_INDUSTRY_RETAIL_ITEM_QUANTITY6                           "R17"
#define TAG_RETAIL_INDUSTRY_RETAIL_ITEM_AMOUNT6                             "R18"

#define TAG_TRAVEL_CRUISE_IATA_CARRIER_CODE					"TD0"
#define TAG_TRAVEL_CRUISE_IATA_AGENCY_NUMBER					"TD1"
#define TAG_TRAVEL_CRUISE_TRAVEL_PACKAGE_INDICATOR				"TD2"
#define TAG_TRAVEL_CRUISE_PASSENGER_NAME					"TD3"
#define TAG_TRAVEL_CRUISE_TRAVEL_TICKET_NUMBER					"TD4"
#define TAG_TRAVEL_CRUISE_TRAVEL_DEPARTURE_DATE_SEGMENT1			"TD5"
#define TAG_TRAVEL_CRUISE_TRAVEL_DESTINATION_CODE_SEGMENT1			"TD6"
#define TAG_TRAVEL_CRUISE_TRAVEL_DEPARTURE_AIRPORT_SEGMENT1 			"TD7"
#define TAG_TRAVEL_CRUISE_AIR_CARRIER_CODE_SEGMENT1				"TD8"
#define TAG_TRAVEL_CRUISE_FLIGHT_NUMBER_SEGMENT1				"TD9"
#define TAG_TRAVEL_CRUISE_CLASS_CODE_SEGMENT1					"TE0"
#define TAG_TRAVEL_CRUISE_TRAVEL_DEPARTURE_DATE_SEGMENT2			"TE1"
#define TAG_TRAVEL_CRUISE_TRAVEL_DESTINATION_CODE_SEGMENT2			"TE2"
#define TAG_TRAVEL_CRUISE_TRAVEL_DEPARTURE_AIRPORT_SEGMENT2			"TE3"
#define TAG_TRAVEL_CRUISE_AIR_CARRIER_CODE_SEGMENT2				"TE4"
#define TAG_TRAVEL_CRUISE_FLIGHT_NUMBER_SEGMENT2				"TE5"
#define TAG_TRAVEL_CRUISE_CLASS_CODE_SEGMENT2					"TE6"
#define TAG_TRAVEL_CRUISE_TRAVEL_DEPARTURE_DATE_SEGMENT3			"TE7"
#define TAG_TRAVEL_CRUISE_TRAVEL_DESTINATION_CODE_SEGMENT3			"TE8"
#define TAG_TRAVEL_CRUISE_TRAVEL_DEPARTURE_AIRPORT_SEGMENT3			"TE9"
#define TAG_TRAVEL_CRUISE_AIR_CARRIER_CODE_SEGMENT3				"TF0"
#define TAG_TRAVEL_CRUISE_FLIGHT_NUMBER_SEGMENT3				"TF1"
#define TAG_TRAVEL_CRUISE_CLASS_CODE_SEGMENT3					"TF2"
#define TAG_TRAVEL_CRUISE_TRAVEL_DEPARTURE_DATE_SEGMENT4			"TF3"
#define TAG_TRAVEL_CRUISE_TRAVEL_DESTINATION_CODE_SEGMENT4			"TF4"
#define TAG_TRAVEL_CRUISE_TRAVEL_DEPARTURE_AIRPORT_SEGMENT4			"TF5"
#define TAG_TRAVEL_CRUISE_AIR_CARRIER_CODE_SEGMENT4				"TF6"
#define TAG_TRAVEL_CRUISE_FLIGHT_NUMBER_SEGMENT4				"TF7"
#define TAG_TRAVEL_CRUISE_CLASS_CODE_SEGMENT4					"TF8"
#define TAG_TRAVEL_CRUISE_LODGING_CHECKIN_DATE					"TF9"
#define TAG_TRAVEL_CRUISE_LODGING_CHECKOUT_DATE					"TG0"
#define TAG_TRAVEL_CRUISE_LODGING_ROOM_RATE1					"TG1"
#define TAG_TRAVEL_CRUISE_NUMBER_OF_NIGHTS_AT_ROOM_RATE1			"TG2"
#define TAG_TRAVEL_CRUISE_LODGING_NAME						"TG3"
#define TAG_TRAVEL_CRUISE_LODGING_REGION_CODE					"TG4"
#define TAG_TRAVEL_CRUISE_LODGING_COUNTRY_CODE					"TG5"
#define TAG_TRAVEL_CRUISE_LODGING_CITY_NAME					"TG6"

#define TAG_RAIL_DATA_TRANSACTION_TYPE							"RA0"
#define TAG_RAIL_DATA_TICKET_NUMBER                          	"RA1"
#define TAG_RAIL_DATA_PASSENGER_NAME                         	"RA2"
#define TAG_RAIL_DATA_IATA_CARRIER_CODE                      	"RA3"
#define TAG_RAIL_DATA_TICKET_ISSUER_NAME                     	"RA4"
#define TAG_RAIL_DATA_TICKET_ISSUE_CITY                      	"RA5"
#define TAG_RAIL_DATA_DEPARTURE_STATION1                     	"RA6"
#define TAG_RAIL_DATA_DEPARTURE_DATE1                          "RA7"
#define TAG_RAIL_DATA_ARRIVAL_STATION1                         "RA8"
#define TAG_RAIL_DATA_DEPARTURE_STATION2                     	"RA9"
#define TAG_RAIL_DATA_DEPARTURE_DATE2                          "RB0"
#define TAG_RAIL_DATA_ARRIVAL_STATION2                         "RB1"
#define TAG_RAIL_DATA_DEPARTURE_STATION3                       "RB2"
#define TAG_RAIL_DATA_DEPARTURE_DATE3                          "RB3"
#define TAG_RAIL_DATA_ARRIVAL_STATION3                         "RB4"
#define TAG_RAIL_DATA_DEPARTURE_STATION4                       "RB5"
#define TAG_RAIL_DATA_DEPARTURE_DATE4                          "RB6"
#define TAG_RAIL_DATA_ARRIVAL_STATION4                         "RB7"
#define TAG_RAIL_DATA_DEPARTURE_STATION5                       "RB8"
#define TAG_RAIL_DATA_DEPARTURE_DATE5                          "RB9"
#define TAG_RAIL_DATA_ARRIVAL_STATION5                         "RC0"
#define TAG_RAIL_DATA_DEPARTURE_STATION6                       "RC1"
#define TAG_RAIL_DATA_DEPARTURE_DATE6                          "RC2"
#define TAG_RAIL_DATA_ARRIVAL_STATION6                         "RC3"

/*------------------------------------------------------------------------*
 *	Define the confidential data
 *------------------------------------------------------------------------*/
typedef struct CONF_DATA_t_ {
	unsigned char	usage;		/*  If =SHC_CONF_MAGIC_NUM,
							means fields have be type cast to this structure*/
	char 	password[SHC_CONF_PASSWORD_LEN+1];
	char	birthdate[SHC_CONF_BIRTHDATE_LEN+1];
	char	cvv2[CVV_LEN+1];
	char 	embossname_1[SHC_CONF_EMBNAME_1_LEN+1];
	char 	city[SHC_CONF_CITY_LEN+1];
	char	street_address[SHC_CONF_STREET_ADDR_LEN+1];
	char	country_code[SHC_CONF_COUNTRY_CODE_LEN+1];
	char	postal_code[SHC_CONF_POSTAL_CODE_LEN+1];
	char	mmn[SHC_CONF_MMN_LEN+1];
	char	ssn[SHC_CONF_SSN_LEN+1];
	/* R007498 >> */
	char	UCAF_aav[33];
	char	UCAF_indicator;	// R007650 change type to char from int
							// to avoid Bus Error on Solaris platform
	/* << R007498 */
} CONF_DATA_t;
													/* R001538 END */

/*R003928 This structure should have all fields of type char so it is easy to
			log and retrive*/
struct shc_data
{
	char cvv2_resultcode;
	char cvv2_indicator;
	char avs_resultcode;
	char issuer_country_code[4];
	char mcard_sno[33]; /*Merchant card Serial number*/
	char ccard_sno[33]; /*Customer card Serial number*/
	char expiry_date[5];
	char trans_id[41];   /*E-Commerce txn idenetifier*/
	char trans_stain[41]; /*SET signature hashing algo value*/
	char device_cap[5]; /* R001319 For logging device_cap in shcmsg structure */
	char service_code[4]; /*service code in tracks */
	char network_data[SHC_NETWORK_DATA_BUF_LEN]; /* NETWORKS specific data */
											 /* R004460 */ /* R004511 */
	char avs_data[55];   /* R005025 */
	char cvv_resultcode; /* R006401 - 'M':Match, 'N':NotMatch, '\0':NotVerified */
	char pos_condition_code_x; /* R008049 */
	char networkCAVVResult;	/* CAVV result created by networks, e.g. VISA, definiton follow visa manual */ /* R007197 */
	char issuerCAVVResult; /* CAVV result created by issuer, e.g. host definiton follow visa manual */ /* R007197 */
	/* R009697 >> */
	char promotion_code[7]; /* MasterCard Promotion Code */
	char cin[5];  			/* Customer ID number */
	char inter_program_ind; /* Interchange program status indicator */
	/* << R009697 */
	
	//	>>>		R028470
	/* C - Conversion of the M/Chip transaction to a magnetic stripe trans completed from pos_entry_code 05 or 79*/
	/* M - Conversion of the M/Chipfallback transaction to a magnetic stripe trans completed from pos_entry_code 80*/
	/* S - Conversion of the M/Chip transaction to a magnetic stripe trans completed from pos_entry_code 07 */

	char pos_entry_conv_code;
	//	<<<		R028470
};

/*
 * yh: 1997/09/22
 *     SMS issuer & acquirer data length
 */
#define SMS_DATA_LEN            128

#define SHC_SEG_MAX				10240

/*  2007336 Rpc -   26Feb00 VSDC Enhancement.Chip Option Type */
#define SHC_CHIP_TYPE_FULL                  1
#define SHC_CHIP_TYPE_EARLY                 0

/* #define ELF_BUFF_SIZE			16384 */ /* nzs */

/*------------------------------------------------------------------------*
 *	Define the universal shared cash message
 * moved struct shcmsg to istswitch_base_headers package
 *------------------------------------------------------------------------*/
#include <shcimf.h>


#include <shcseg.h>

/*
 * qd 10dec97 Define a macro which can be used by any other IST server
 */
#define IST_SERVER_BUFLEN	(sizeof(struct shcmsg) + SHC_SEG_MAX)

/*------------------------------------------------------------------------*
 *		P A C K A G E  I N F O R M A T I O N
 *------------------------------------------------------------------------*/
/*
 *	This section describes the package information and rules allowed in shc
 */
#define	SHC_NUM_PACKAGES		10			/*	ten packages */

struct	shckeysmem {											/* 10001935 */
	bin_t		bin;			/*	this is the:	the bin */
	bin_t		institutionid;	/* Institution id of the bin */
	bin_t		userbinid;		/* User BIN id of the bin */
	bin_t		owner;			/*	the owner of this bin */
	short		textid;
	short		pinid;
	short		keyid;
};

struct	shcrmtbin {
	/*	Used on the master node for monitor purpose only */
	bin_t		bin;
	long		flags;
};

extern shcbindb *__tmpshcdb;
struct	shcbin {
	/*	Routing and config package package */
	bin_t			institutionid;		/*	institution id */
	bin_t			userbinid;			/*	user bin id */
	bin_t			networkid;			/*	internal bin id */
	bin_t			owner;				/*	owner network */
	int				mailbox;			/*	outbound route */
	int				port;				/* 	outbound port id */
	int				netmgrid;			/*	net mgr. mail box id */
	int				bintype;			/*	type of entry */
	long			timeout;			/*	time out value as aquirer */
	unsigned long	flags;				/*	flags on type of entry */
	date_t			settle_date;		/*	current settlement date */
	int				pinparm;		/*	pin parm index */
//	int				keyparm;		/*	index to key parm index */
	short			country_code;
	short			currency_code;
	short			cvvdate;		/*	date after which CVV is valid */
	short			addflag;		
	int				cardid;			/*	card type */
	int				statid;			/*	set >= 0 if stats being collected */
	long			last_online_activity;	/*	time of last on-line activity */
	char			bankname[SHC_BANKNAME_LEN + 1];
	int             cammailboxid;   /* Mch 18Feb00 -Card Authen. Mailbox ID */
	unsigned long   bin_cfg;        /*  R001835 Bin Level Configuration */
	char			node[sizeof(__tmpshcdb->node)];
	unsigned long	bin_cfg2;
};

struct	shctransaction {
	/*	flags and values for transaction processing */
	amount_t	amount;		/*	daily limit on withdrawals */
	short		npintry;	/*	number of failed pin attempts */
	unsigned long	txnset;	/*	allowed transaction set */
};


struct	shcauth {
	/*	authorization package */
	short		type;				/*	type of authorization permited */
	int			authserver;			/*	server id of authorization server */
									/*	set up at load time */
	/*	Floor limits */
	amount_t	floor_1,
				floor_2,
				floor_3;

	/*	transaction limits */
	amount_t	acq_minamount,
				iss_minamount;

	/*	default accounts */
	short		def_from_acct;
	short		def_to_acct;
};


struct	shcsaf {
	/*	store and forward package */
	short		type;			/*	type of store and forward */
	amount_t	amount;			/*	limit on stfwd withdrawals */
	int			num;			/*	number of withdrawals allowed */
	long		refreshtime;	/*	when do limits refresh */
	int			fd;				/*	store and forward file pointer */
	int			posmailbox;		/*	pos authorization mailbox */
	int			replayid;		/*	pid of replay server */
};

/*******/
/*	Multiple Routing package */
/*******/
struct shcmrt {
	int dum;
};

struct	shcstats {
	/*	Status information on the bin */
	long	start_stats;
	long	time_last_msg;
	int		type_last_msg;
	int		num_messages;
	int		msgtype[1000];
	int		respcode[1000];
	int	counter[10];
};

struct	shcrespcode {
	/*	Used by monitor and shccmd for display purposes */
	const char	*name;
	int		code;
	int		flags;
};


//R030556
struct	shcsecurity {
	/*	mac/pin/com keys package */

	struct	shckeys		k;	/*	database image of keys */		/* 10001935 */

	int		macusage;		/*	how many times have we used this key */
	int		pinusage;
	int		pinchange;		/*	change after this many times */
	int		macchange;
	long 	hash;
};


/*
 *	The major package
 *
 *	This structure represents the basic entry for each BIN we deal with
 */
struct	shcpkg {
	struct	shcbin			bin;
	struct	shctransaction	txn;
	struct	shcauth			auth;
	struct	shcsaf			saf;
	long    balInfo[20];            //Stores information needed for balancing, can be cast to different structure};
};

/*
 *	Global statistics structure
 */
struct	shcglobstat {
	int		msg[100];					/*	one bin for each message type */
	int		errcodes[500];				/*	one bin for each error type */
};


/*
 *	The internal transaction structure
 */
struct	shc {
	/*	The header which encapsulates the message */
	int		shcerr;			/*	error while processing the message */
	int		time_in;		/*	time in for the message */
	int		time_out;		/*	time out for the message */
	int		eventid;		/*	timer event id */
	int		applmbid;		/*	external application mailbox */

	/*	routing and bin entry information */
	struct	shcpkg		*issbin;
	struct	shcpkg		*acqbin;
	struct	shcpkg		*trabin;			/* qd 22feb96 */
	struct	shcpkg		*orgbin;
	struct 	shcpkg		*alternateAcqBin;	/* R008717 */
	struct	pinverparm	*pin;				/*	pin data */
	struct	shcsecurity	*key;				/*	encryption key data */
	char				*pindata;			/*	pin data pointer */

	/*	the message	*/
	struct	shcmsg		msg;
};

/* Added to support message segments  09Nov93 */

struct shcsegrec {
	double	dummy;		/* for alignment */
	char	*segdata;
	int		segsize;
};

/* R008717 BEGIN */
struct ShcmsgWithSegment
{
	struct shcmsg msg;
	char segmentData[SHC_SEG_MAX];
};

struct ShcWithSegment
{
	struct shc shc;
	char segmentData[SHC_SEG_MAX];
};

struct  a_msgmap {
    int         srcmsg;
    int         dstmsg;
    char        *tag;
};

struct s_OrigMsgDigist
{
	int shcerror;
	amount_t amount;
	int respcode;
	int pcode;
	int msgtype;
	int site_id;
	short saf;
	short pos_condition_code;
	int flipped_msgtype;
	char alpha_response_code[3+1];
	char    shclog_id[21];
};
/* R008717 END */

#include <shcextbin_shm.h>
// moved to istswitch_base_headers package shcextbin_shm.h
//struct	shcextbin	{
//	char	lowbin[8];		/* The bin is stored as BCD, so it can store up to 16 digits.
//	char	highbin[8];		/* Same comment as lowbin */
//	char	destination[11];/* Where the entry comes from, e.g. "VISA", "CIBC" */
//	char	cardProduct[11];	/* Card LOGO name. e.g. "PLUS", "CIRRUS" */
//	char	network_data[11]; /* Network specific data */
//	char    entityId[31];  /* issuer entity ID */
//	short	country_code; /* issuer country code R029416 */
//};

#include <binroute.h>

extern BINROUTE *_nousebinrouteinshc_h;
struct RoutingInfo
{
	char destNode[sizeof(__tmpshcdb->node)];
	char mailbox[MB_MAX_NAME+1]; 
	char srcNode[sizeof(__tmpshcdb->node)];
	long time_out; 
	char port[MB_MAX_NAME+1]; 
	unsigned long flag;
	char misc[sizeof(_nousebinrouteinshc_h->misc)];
        short siteId;
        short srcSiteId;
};

struct shcextbinGroupHeader
{
	bin_t destination;
	char entityId[31];
	char cardProduct[MAX_CARD_BRAND_NAME_LEN+1];
	int startEntry;
	int endEntry;
	int bin_length;
};

/*
*	19March92
*	This struct is used by shc_locatetransaction_seq function (shc_log.c)
*	to attempt to locate the transaction matching this fields
*/
struct shclogmatch {
long		pcode;
amount_t	amount;
};


#define	shcSegmentOffset(a)		((size_t)(a) + sizeof( struct shc ))


/*------------------------------------------------------------------------*
 *	External references
 *------------------------------------------------------------------------*/
#ifdef __cplusplus
extern "C" {
#endif

SHCDLLEXPORT	extern	ICReturn ICShcmsg_putFld( struct shcmsg* shcmsgp, char *, char* ); /* R005156 */

SHCDLLEXPORT	extern	struct	shcextbin		*shcExtBin;
SHCDLLEXPORT	extern	struct	shckeysmem		*shcBinKeys;					/* 10001935 */
SHCDLLEXPORT	extern	struct	shcpkg			*shcBinPkg;
SHCDLLEXPORT	extern	struct	pinverparm		*shcPin;
SHCDLLEXPORT	extern	struct	shcpkg			*shcDefaultIssuer;
SHCDLLEXPORT	extern	struct	shcsecurity		*shcSecurity;
SHCDLLEXPORT	extern	struct	shcrmtbin		*shcRmtBin;
SHCDLLEXPORT	extern	int						shcRmtBinAppid;
SHCDLLEXPORT	extern	int						shcExtBinAppid;
SHCDLLEXPORT	extern	struct	rules_keytab	*rulekeyp;
SHCDLLEXPORT	extern	struct	rules_keytab	*rmtbin_rulekeyp;
SHCDLLEXPORT	extern	struct	rules_keytab	*shcextbin_rulekeyp;

SHCDLLEXPORT	extern	struct	shcstats		*shcStats;

SHCDLLEXPORT    extern  bin_t	shcDefaultIssuerId;

//#define shcDefaultIssuer shcApp->shcBinObj->getBinPkg(shcDefaultIssuerId)

SHCDLLEXPORT	extern	int						shcAppid;
SHCDLLEXPORT	extern	int						shcStatsAppid;
SHCDLLEXPORT	extern	int						shcPinAppid;
SHCDLLEXPORT	extern	int						shcSecurityAppid;
SHCDLLEXPORT	extern	struct	rules_keytab	*stats_rulekeyp;
SHCDLLEXPORT	extern	long					shc_current_time;
SHCDLLEXPORT	extern	int						shc_current_millisecond;
SHCDLLEXPORT	extern	int						dbmid;
SHCDLLEXPORT	extern	int						shcmid;
SHCDLLEXPORT	extern	bin_t					shc_orgid;
SHCDLLEXPORT	extern	int						shcDebugFlag;
SHCDLLEXPORT	extern	long					shc_local_istdate;
SHCDLLEXPORT	extern	int						DoCurrencyConv; //This should be deleted after mcfmt_util is fixed
SHCDLLEXPORT	extern	int						haveDNSupport; 
SHCDLLEXPORT	extern	int						haveLCRSupport; 		// R027759
SHCDLLEXPORT	extern	int						haveTieBreaker; 		// R027759
SHCDLLEXPORT	extern	int						haveReferCardIssuer;
SHCDLLEXPORT    extern  int             		useTxnDestInEventMatching;
SHCDLLEXPORT    extern  int             		useTxnDestInShclogLocating;
SHCDLLEXPORT    extern  int             		respMsgFromShc;

SHCDLLEXPORT    extern  int             		delaySendCachedMsg;

SHCDLLEXPORT    extern  int                             UcafCtrlByte;
SHCDLLEXPORT    extern  int                             netMsginLocalSite;

SHCDLLEXPORT    extern  int                             SkipCvvChipOrContactless;
SHCDLLEXPORT    extern  int                     bindRefNumLocate;
SHCDLLEXPORT    extern  int				DateCheckBeforeLogging;


//
///* 22Oct93 */
//SHCDLLEXPORT	extern	int						useTermtot;
//
///*27Feb95 */
//SHCDLLEXPORT	extern	int						dynam_key_exch;
//SHCDLLEXPORT	extern	int						Use_PinIdx_from_Msg;
//SHCDLLEXPORT	extern	int						Acquirer_Key_Flag;
//SHCDLLEXPORT	extern	int						IsHub;
//
//SHCDLLEXPORT	extern	int						shcReturnDBError;
//
///*
// * qd 24nov97 New configuration parameters for ACXSYS
// */
//SHCDLLEXPORT	extern	int						shcnetDebug;
SHCDLLEXPORT	extern  long    				shc_current_istdate;
//SHCDLLEXPORT	extern	int						shcNewGentrace;
//
//SHCDLLEXPORT 	extern 	int						shclog_specified_msgtype; /* R008689 */
//SHCDLLEXPORT 	extern 	int						pcode_req; 	/* R010134 */
//
/* being moved here from the end	7oct97 > */
    struct shckey_buf
    {
        struct shcsecurity *keyp;
		char			key_class;
		char			type;
		char			index;
        char            change;
		char			ctype[4];
		char			status;
        char            *akeyp;
        char            *achkp;
        char            *astatp;
        short           *aidxp;
		char			aidx;									/* R000587 */
		char			*acntp;									/* R000587 */
        char            *ikeyp;
        char            *ichkp;
        char            *istatp;
        short           *iidxp;
		char			iidx;									/* R000587 */
		char			*icntp;									/* R000587 */

		/* R001531 -> */
	    char            *list_index;
        char            *list_type;
        char            *list_xgen;
        char            *list_xreq;
		/* R001531 <- */

		/*R005324  >>>>>*/
		short *keklen;
		short *akeylen;
		short *ikeylen;
		/*<<<<<<<R005324*/
    };
    
    struct s_ShcRestoreInfo
    {
    	int origmsg;
    };
/* < 7oct97 */

//
///* R004148 BEGIN */
//SHCDLLEXPORT extern int shc_safdump(char *bin, char *output, FILE *fp);
//SHCDLLEXPORT extern int shc_msgdump(struct shcmsg *shcmsg, char *ct);
SHCDLLEXPORT extern int sh_create_segment(struct shc *shcmsg, char *name, int nrec, char *r1, int r1l, char *r2, int r2l);
///* R005924 << */
SHCDLLEXPORT extern long shc_next_auth_number();
//SHCDLLEXPORT extern long shc_old_auth_num();
//SHCDLLEXPORT extern long shc_generate_auth_number(struct shc *shcmsg);
//SHCDLLEXPORT extern int shc_request_convert(struct shc *shcmsg);
//SHCDLLEXPORT extern int shc_response_convert(struct shc * shcmsg);
//SHCDLLEXPORT extern int shc_use_default_currency(struct shc *shcmsg);
//SHCDLLEXPORT extern int shc_set_currency_codes(struct shc *shcmsg);
//SHCDLLEXPORT extern int shc_set_conversion_rates(struct shc *shcmsg);
//SHCDLLEXPORT extern int shc_is_req_or_resp(struct shc	*shcmsg);
//SHCDLLEXPORT extern int amount_conversion(amount_t *amount, amount_t rate, char method);
//SHCDLLEXPORT extern int shc_convert_amount(struct shc *shcmsg, amount_t *amount, int convert_from_to);
SHCDLLEXPORT extern int shc_invert_rate(amount_t *in_rate);
///* R005924 ** SHCDLLEXPORT extern shc_get_current_date();  **/
SHCDLLEXPORT extern int shc_get_current_date();
//SHCDLLEXPORT extern long shc_make_gmt(int y, int m, int d, int H, int M, int S);
//SHCDLLEXPORT extern long shc_make_istdate(int y, int m, int d);
//SHCDLLEXPORT extern long shc_derive_date();
SHCDLLEXPORT extern long shc_gmt_adddays(long unix_date, int ndays);
SHCDLLEXPORT extern long shc_date_unix_to_ist(struct tm *tp, int type);
SHCDLLEXPORT extern long shc_gmt_currentdate();
SHCDLLEXPORT extern long shc_gmt_currenttime();
SHCDLLEXPORT extern long shc_local_currentdate();
SHCDLLEXPORT extern long shc_local_currenttime();
SHCDLLEXPORT extern long shc_date_ist_to_unix(long gmt_date, long gmt_time);
SHCDLLEXPORT extern long shc_make_local_date(long gmt_date, long gmt_time);
//SHCDLLEXPORT extern long shc_make_local_time(long gmt_date, long gmt_time);
//SHCDLLEXPORT extern int shc_expand_date(char *yymm, char *yyyymm);
//SHCDLLEXPORT extern int shc_inc_kpecnt(bin_t issbin);
//SHCDLLEXPORT extern int shc_kpe_overthreshold(bin_t issbin);
///** >> R005924 ** SHCDLLEXPORT extern shc_reset_kpecnt(bin_t issbin); **
//SHCDLLEXPORT extern shc_inc_pinerrcnt(bin_t issbin);
//SHCDLLEXPORT extern shc_inc_pinerrcnt_x(struct shc* shcmsg);*/ /* R005156 */
//
//
///* R009904 */
//
//SHCDLLEXPORT extern int shc_inc_kpeisscnt(bin_t issbin);
//SHCDLLEXPORT extern int shc_kpeiss_overthreshold(bin_t issbin);
//SHCDLLEXPORT extern int shc_reset_kpeisscnt(bin_t issbin);
//
//
//SHCDLLEXPORT extern int shc_reset_kpecnt(bin_t issbin);
//SHCDLLEXPORT extern int shc_inc_pinerrcnt(bin_t issbin);
//SHCDLLEXPORT extern int shc_inc_pinerrcnt_x(struct shc* shcmsg);
///* R005924 << */
//SHCDLLEXPORT extern int shc_pinerr_overthreshold(bin_t issbin);
//SHCDLLEXPORT extern int shc_reset_pinerrcnt(bin_t issbin);
//SHCDLLEXPORT extern int shc_inc_kmaccnt(bin_t issbin);
//SHCDLLEXPORT extern int shc_kmac_overthreshold(bin_t issbin);
///* >> R005924 *
//SHCDLLEXPORT extern shc_reset_kmaccnt(bin_t issbin);
//SHCDLLEXPORT extern shc_inc_macerrcnt(bin_t issbin);
//SHCDLLEXPORT extern shc_inc_macerrcnt_x(struct shc *shcmsg); **/
//SHCDLLEXPORT extern int shc_reset_kmaccnt(bin_t issbin);
//SHCDLLEXPORT extern int shc_inc_macerrcnt(bin_t issbin);
//SHCDLLEXPORT extern int shc_inc_macerrcnt_x(struct shc *shcmsg);
///* R005924 << */
//SHCDLLEXPORT extern int shc_macerr_overthreshold(bin_t issbin);
//SHCDLLEXPORT extern int shc_reset_macerrcnt(bin_t issbin);
//SHCDLLEXPORT extern int shc_inc_kmecnt(bin_t issbin);
//SHCDLLEXPORT extern int shc_kme_overthreshold(bin_t issbin);
///** >> R005924 **
//SHCDLLEXPORT extern shc_reset_kmecnt(bin_t issbin);
//SHCDLLEXPORT extern shc_inc_cmstocnt(bin_t issbin);
//SHCDLLEXPORT extern shc_inc_cmstocnt_x(struct shc *shcmsg); **/
//SHCDLLEXPORT extern int shc_reset_kmecnt(bin_t issbin);
//SHCDLLEXPORT extern int shc_inc_cmstocnt(bin_t issbin);
//SHCDLLEXPORT extern int shc_inc_cmstocnt_x(struct shc *shcmsg);
///* R005924 << */
//SHCDLLEXPORT extern int shc_cmsto_overthreshold(bin_t issbin);
//SHCDLLEXPORT extern int shc_reset_cmstocnt(bin_t issbin);
//SHCDLLEXPORT extern int shc_inc_keyrjtcnt(bin_t issbin);
//SHCDLLEXPORT extern int shc_inc_keyrjtcnt_x(struct shc *shcmsg);
//SHCDLLEXPORT extern int shc_keyrjt_overthreshold(bin_t issbin);
//SHCDLLEXPORT extern int shc_reset_keyrjtcnt(bin_t issbin);
//SHCDLLEXPORT extern int shc_inc_amerrcnt(bin_t issbin);
//SHCDLLEXPORT extern int shc_inc_amerrcnt_x(struct shc *shcmsg);
//SHCDLLEXPORT extern int shc_amerr_overthreshold(bin_t issbin);
///** >> R005924 **
//SHCDLLEXPORT extern shc_reset_amerrcnt(bin_t issbin);
//SHCDLLEXPORT extern shc_inc_akconverrcnt(bin_t issbin);
//SHCDLLEXPORT extern shc_inc_akconverrcnt_x(struct shc *shcmsg); **/
//SHCDLLEXPORT extern int shc_reset_amerrcnt(bin_t issbin);
//SHCDLLEXPORT extern int shc_inc_akconverrcnt(bin_t issbin);
//SHCDLLEXPORT extern int shc_inc_akconverrcnt_x(struct shc *shcmsg);
///* R005924 << */
//SHCDLLEXPORT extern int shc_akconverr_overthreshold(bin_t issbin);
//SHCDLLEXPORT extern int shc_reset_akconverrcnt(bin_t issbin);
//SHCDLLEXPORT extern int shc_inc_akpesyncerrcnt(bin_t issbin);
//SHCDLLEXPORT extern int shc_inc_akpesyncerrcnt_x(struct shc *shcmsg);
//SHCDLLEXPORT extern int shc_akpesyncerr_overthreshold(bin_t issbin);
//SHCDLLEXPORT extern int shc_reset_akpesyncerrcnt(bin_t issbin);
//SHCDLLEXPORT extern int shc_inc_akmacsyncerrcnt(bin_t issbin);
//SHCDLLEXPORT extern int shc_inc_akmacsyncerrcnt_x(struct shc *shcmsg);
//SHCDLLEXPORT extern int shc_akmacsyncerr_overthreshold(bin_t issbin);
//SHCDLLEXPORT extern int shc_reset_akmacsyncerrcnt(bin_t issbin);
//SHCDLLEXPORT extern int shc_inc_akmesyncerrcnt(bin_t issbin);
//SHCDLLEXPORT extern int shc_inc_akmesyncerrcnt_x(struct shc *shcmsg);
//SHCDLLEXPORT extern int shc_akmesyncerr_overthreshold(bin_t issbin);
//SHCDLLEXPORT extern int shc_reset_akmesyncerrcnt(bin_t issbin);
///** >> R005924 **
//SHCDLLEXPORT extern shc_tracein(char *funcname);
//SHCDLLEXPORT extern shc_traceout(char *funcname);
//SHCDLLEXPORT extern shc_inc_imerrcnt(bin_t acqbin);
//SHCDLLEXPORT extern shc_inc_imerrcnt_x(struct shc *shcmsg);  **/
//SHCDLLEXPORT extern int shc_tracein(char *funcname);
//SHCDLLEXPORT extern int shc_traceout(char *funcname);
//SHCDLLEXPORT extern int shc_inc_imerrcnt(bin_t acqbin);
//SHCDLLEXPORT extern int shc_inc_imerrcnt_x(struct shc *shcmsg);
///* R005924 */
//SHCDLLEXPORT extern int shc_imerr_overthreshold(bin_t acqbin);
//SHCDLLEXPORT extern int shc_reset_imerrcnt(bin_t acqbin);
//SHCDLLEXPORT extern int shc_inc_ikconverrcnt(bin_t acqbin);
//SHCDLLEXPORT extern int shc_ikconverr_overthreshold(bin_t acqbin);
//SHCDLLEXPORT extern int shc_reset_ikconverrcnt(bin_t acqbin);
//SHCDLLEXPORT extern int shc_inc_ikpesyncerrcnt(bin_t acqbin);
//SHCDLLEXPORT extern int shc_inc_ikpesyncerrcnt_x(struct shc *shcmsg);
//SHCDLLEXPORT extern int shc_ikpesyncerr_overthreshold(bin_t acqbin);
//SHCDLLEXPORT extern int shc_reset_ikpesyncerrcnt(bin_t acqbin);
//SHCDLLEXPORT extern int shc_inc_ikmacsyncerrcnt(bin_t acqbin);
//SHCDLLEXPORT extern int shc_inc_ikmacsyncerrcnt_x(struct shc *shcmsg);
//SHCDLLEXPORT extern int shc_ikmacsyncerr_overthreshold(bin_t acqbin);
//SHCDLLEXPORT extern int shc_reset_ikmacsyncerrcnt(bin_t acqbin);
//SHCDLLEXPORT extern int shc_inc_ikmesyncerrcnt(bin_t acqbin);
//SHCDLLEXPORT extern int shc_inc_ikmesyncerrcnt_x(struct shc *shcmsg);
//SHCDLLEXPORT extern int shc_ikmesyncerr_overthreshold(bin_t acqbin);
//SHCDLLEXPORT extern int shc_reset_ikmesyncerrcnt(bin_t acqbin);
//SHCDLLEXPORT extern int shc_hsmerror_log(struct shcmsg *shcmsg, char *loginfo);
//SHCDLLEXPORT extern int shc_reset_dynamic_keys( bin_t networkid, char key_type );
SHCDLLEXPORT extern int shc_resptomsg(int respcode, char *msg, size_t msg_size);
SHCDLLEXPORT extern int scan(FILE *fp, int error, char *msg, size_t msg_size);
SHCDLLEXPORT extern int default_msg(int respcode, char *msg, size_t msg_size);
///** R005924 **
SHCDLLEXPORT extern int shc_init_formatter(const char *name, int *m_in, int *m_out, int *s_id, int *st_id, int single_formatter);
SHCDLLEXPORT extern long		shc_fmtgetdate_from_mmdd( long	mmdd );
SHCDLLEXPORT extern int shc_fmt_balance( char *buf, int accttype, int amttype, int currency, amount_t *amount) ;
//
///* R007781 */
SHCDLLEXPORT extern int shc_is_empty_buf(register char *buf, register int len);
//
///** R005924 **
//SHCDLLEXPORT extern shc_fx_convert(amount_t *srcamt, int src_curcode, amount_t *dstamt, int dst_curcode,	amount_t *sell_spread,	amount_t *buy_spread,	int base_curcode, amount_t	*src_currency_rate,	amount_t *dst_currency_rate,	amount_t	*agr_currency_rate)	; */
//SHCDLLEXPORT extern int shc_fx_convert(amount_t *srcamt, int src_curcode, amount_t *dstamt, int dst_curcode,	amount_t *sell_spread,	amount_t *buy_spread,	int base_curcode, amount_t	*src_currency_rate,	amount_t *dst_currency_rate,	amount_t	*agr_currency_rate);
//
SHCDLLEXPORT extern int shc_GetCurrencyRate( int code, bin_t bin, struct istcurrency_key *r ); /* R005156 */
//
SHCDLLEXPORT extern int shc_gentrace();
//SHCDLLEXPORT extern int shc_get_bin_entries(struct shc *shcmsg);
SHCDLLEXPORT extern int shc_get_iss_acq(struct shc *shcmsg);
SHCDLLEXPORT extern int shc_get_iss_acq_xt(struct shc *shcmsg, int useextbin );
//SHCDLLEXPORT extern int shc_getoriginator(struct shc *shcmsg);
//SHCDLLEXPORT extern int shc_gettransferee(struct shc *shcmsg);
//SHCDLLEXPORT extern int shc_search_bintable(bin_t bin);
//SHCDLLEXPORT extern int shc_locate_default_issuer();
///** R005924 ** SHCDLLEXPORT extern int locate_compare( struct shcextbin *entry, char *mybin	\
//										, int credit, int *precedence ); */
//SHCDLLEXPORT extern int locate_compare( struct shcextbin *entry, char *mybin, int credit, int *precedence );
//
//SHCDLLEXPORT extern int shc_normalize_leading_zero(register char *entry, char * replace);
//SHCDLLEXPORT extern int shc_denormalize_leading_zero(register char *entry, char * replace);
//SHCDLLEXPORT extern int shc_denormalizenumber(register char *nbp, register char *obp, size_t);
///** R005924 ** SHCDLLEXPORT extern shc_init_formatter(char *name, int *m_in, int *m_out	\
//										, int *s_id, int *st_id, int single_formatter); **/
//SHCDLLEXPORT extern int shc_init_formatter(const char *name, int *m_in, int *m_out, int *s_id, int *st_id, int single_formatter);
//
SHCDLLEXPORT extern int shc_init();
SHCDLLEXPORT extern int shc_initsys();
//SHCDLLEXPORT extern int shc_initparm();
//SHCDLLEXPORT extern int shc_locate_switch_entry();
//SHCDLLEXPORT extern int shc_setswitchflag(int flag);
//SHCDLLEXPORT extern int shc_initparm();
//SHCDLLEXPORT extern int shcinst_SetUp( struct shcpkg *pkgp );
//SHCDLLEXPORT extern int shcinst_SetDown( struct shcpkg *pkgp );
//SHCDLLEXPORT extern int shcinst_Clr( struct shcpkg *pkgp );
//SHCDLLEXPORT extern int shcinst_Reset( struct shcpkg *pkgp );
//SHCDLLEXPORT extern int shc_keys_init();
//
//
///** R005924 ** SHCDLLEXPORT extern int shc_keys_init_buf( struct shckey_buf *bufp, char key_class	\
//											, char type, char index ); */
//SHCDLLEXPORT extern int shc_keys_init_buf( struct shckey_buf *bufp, char key_class, char type, char index );
//
//SHCDLLEXPORT extern int shc_keys_set_pointers( struct shckey_buf *bufp );
//
SHCDLLEXPORT extern int shc_keys_set_status( struct shckey_buf *bufp, char status );
//
SHCDLLEXPORT extern int shc_keys_set_status_as2805( struct shckey_buf *bufp, char status, int device_flag );
//
//SHCDLLEXPORT extern int shc_keys_upd_db( struct shckey_buf *bufp );
//
SHCDLLEXPORT extern int shcnet_keys_init( struct shc *shcmsg, struct shcpkg *pkgp, struct shckey_buf *keybufp );
//
//SHCDLLEXPORT extern int shc_keys_get_pointers( struct shckey_buf *bufp, short p_keyidx);
//
//SHCDLLEXPORT extern int shckeys_getindex_next( struct shckey_buf *keyp, char *key_index );
//SHCDLLEXPORT extern int shckeys_getnext_index(char *instid, char *key_index );
//
//SHCDLLEXPORT extern int shckeys_UpdIndex( struct shckey_buf *bufp, char index );
//
//SHCDLLEXPORT extern int shckeys_SetStatus( struct shckey_buf *bufp, char status );
//
//SHCDLLEXPORT extern int shckeys_GenerateKey( struct shckey_buf *keybufp, char *k_kpe, char *k_chk );
//
//SHCDLLEXPORT extern int shckeys_TranslateKey( struct shckey_buf *keybufp, char *k_kpe, char *k_chk, char *k_cnt );
//
//SHCDLLEXPORT extern int shckeys_Mem2Dbm( struct shckey_buf *bufp );
//
//SHCDLLEXPORT extern int shckeys_GetKeyUsage( struct shckey_buf *keybufp, struct shcpkg *pkgp );
//
//SHCDLLEXPORT extern int shc_notify_build( struct shc *smsg, struct istadvice *amsg, int len);
//
//SHCDLLEXPORT extern int shc_notify_construct_tag( struct shc *smsg, struct istadvice *amsg);
//
//SHCDLLEXPORT extern int shc_notify_adjust_msg( struct istadvice *amsg );
//
//SHCDLLEXPORT extern int	shc_notify_send( struct istadvice *amsg , int len);
//
//SHCDLLEXPORT extern int shc_determine_correct_currency(struct shc *shcmsg);
//
///** R005924 ** SHCDLLEXPORT extern shc_saf_locate_transaction(struct shc *shcmsg, int fd, struct istadvice *advicemsg);
//SHCDLLEXPORT extern shc_saf_calculate_capdate(struct istadvice *advicep, struct shc *shcmsg) ;
//SHCDLLEXPORT extern shc_settlement_get_values( struct shc500std *std500, struct shc *shcmsg	\
//							, long *count, dec_t *amount, long *revcount, dec_t *revamount );
//SHCDLLEXPORT extern shc_keyidx(struct shckeys *shckeys);  **/
//
//SHCDLLEXPORT extern int shc_saf_locate_transaction(struct shc *shcmsg, int fd, struct istadvice *advicemsg);
//SHCDLLEXPORT extern int shc_saf_calculate_capdate(struct istadvice *advicep, struct shc *shcmsg) ;
//SHCDLLEXPORT extern int shc_settlement_get_values( struct shc500std *std500, struct shc *shcmsg, long *count, dec_t *amount, long *revcount, dec_t *revamount );
//SHCDLLEXPORT extern int shc_keyidx(struct shckeys *shckeys);
///* R005924 << */
//
//SHCDLLEXPORT extern int shc_settlement_format_message(struct shc *shcmsg, struct shc500std *std500);
//
//SHCDLLEXPORT extern int shc_settlement_inquire(struct shc500std *msg);
//
//
//SHCDLLEXPORT extern int shckeys_RstKeys( struct shcpkg *pkgp );
SHCDLLEXPORT extern int shc_logtransaction(struct shc *shcmsg);
SHCDLLEXPORT extern int shc_logrepeat(struct shc *shcmsg);
//SHCDLLEXPORT extern int shc_updatetransaction(struct shc *shcmsg, struct shc *oldmsg);
//SHCDLLEXPORT extern int shc_writetransaction(struct shc *shcmsg);
//SHCDLLEXPORT extern int shc_rewind();
//SHCDLLEXPORT extern int shc_locatetransaction(struct shc *shcmsg, struct shc *oldmsg);
//SHCDLLEXPORT extern int shc_locatetransaction_refnum(struct shc *shcmsg, struct shc *oldmsg);
//SHCDLLEXPORT extern int shc_locatetransaction_seq(struct shc *shcmsg, struct shc *oldmsg, struct shclogmatch *shclogmatch);
//SHCDLLEXPORT extern int shc_locatetransaction_refnum(struct shc *shcmsg, struct shc *oldmsg);
//SHCDLLEXPORT extern int shc_locatetransaction_seq(struct shc *shcmsg, struct shc *oldmsg, struct shclogmatch *shclogmatch);
//SHCDLLEXPORT extern int fill_transaction(register struct shc *shcmsg);
//SHCDLLEXPORT extern int fill_message(register struct shc *shcmsg);
//SHCDLLEXPORT extern int shc_user_fill_message_from_log(struct shc *shcmsg, struct shclog *shclog);
//SHCDLLEXPORT extern int open_index();
//SHCDLLEXPORT extern int new_transaction();
///* Ssc 30Jun00 R004671 support VSDC chip txn log */
//SHCDLLEXPORT extern int new_transaction_x(int);
//SHCDLLEXPORT extern int locate_transaction(struct shc *shcmsg, struct shc *oldmsg);
//SHCDLLEXPORT extern int shc_get_cam_stored_results(unsigned char *, unsigned char *);
//SHCDLLEXPORT extern int shc_set_cam_stored_results(unsigned char *, unsigned char *);
///* Ssc end */
//SHCDLLEXPORT extern int locate_transaction_refnum(struct shc *shcmsg, struct shc *oldmsg);
//SHCDLLEXPORT extern int shclog_LocateTxn( struct shc *shcmsg, struct shc *oldmsg, char *prefix );
//SHCDLLEXPORT extern int locate_EDC_transaction_refnum(struct shc *shcmsg, struct shc *oldmsg);
//SHCDLLEXPORT extern int locate_transaction_refnum(struct shc *shcmsg, struct shc *oldmsg);
//SHCDLLEXPORT extern int write_transaction();
///*Ssc 30Jun00 R004671 new function for VSDC chip txn log */
//SHCDLLEXPORT extern int write_transaction_x(int);
//SHCDLLEXPORT extern int shc_saf_write_transaction(struct shc *shcmsg);
//SHCDLLEXPORT extern int shc_set_deny_origin(register struct shc *shcmsg);
//SHCDLLEXPORT extern int shc_update_respcode_log( struct shc *shcmsg );
//SHCDLLEXPORT extern int shc_use_log(struct shc *shcmsg);
//SHCDLLEXPORT extern int shc_locate_original(struct shc *shcmsg, struct shc *omsg);
//SHCDLLEXPORT extern int shc_locate_original(struct shc *shcmsg, struct shc *omsg);
//SHCDLLEXPORT extern int shc_user_log_init();
//SHCDLLEXPORT extern int shcRespNotVerifyMac(register struct shc *shcmsg);
//SHCDLLEXPORT extern int	shc_saf_reversal(register struct shc *shcmsg);
//SHCDLLEXPORT extern int shcmac_verify( struct shc *shcmsg, struct shcpkg *pkg, char key_class );
//SHCDLLEXPORT extern int shcmac_addfields( struct shc *shcmsg );
//SHCDLLEXPORT extern int shcmac_ChgKey( struct shc *shcmsg );
SHCDLLEXPORT extern int shc_set_return_msgno(struct shc *shcmsg);
SHCDLLEXPORT extern int shc_get_return_msgno(int msgno);
//SHCDLLEXPORT extern int shc_net(struct shc *shcmsg);
//SHCDLLEXPORT extern int shc_groupdown(struct shc *shcmsg, struct shcpkg *pkg);
//SHCDLLEXPORT extern int shc_setdown(struct shc *shcmsg, struct shcpkg *pkg);
//SHCDLLEXPORT extern int shc_markdown(struct shc *shcmsg, struct shcpkg *pkg);
//SHCDLLEXPORT extern int shc_stopreplay(struct shc *shcmsg, struct shcpkg *pkg);
//SHCDLLEXPORT extern int shc_groupup(struct shc *shcmsg, struct shcpkg *pkg);
//SHCDLLEXPORT extern int shc_setup(struct shc *shcmsg, struct shcpkg *pkg);
//SHCDLLEXPORT extern int shc_echotest(struct shc *shcmsg, struct shcpkg *pkg);
//SHCDLLEXPORT extern int shc_build_800(struct shc *shcmsg, struct shc *net , struct shcpkg *pkg, int code);
//SHCDLLEXPORT extern int shc_send_800(struct shc *shcmsg, struct shcpkg *pkg);
SHCDLLEXPORT extern int			shc_notify_echo( struct shc *smsg );
//SHCDLLEXPORT extern int shc_notify_netcode_allowed(struct shc *smsg);
SHCDLLEXPORT extern int shc_normalizepan(char *pan);
SHCDLLEXPORT extern int shc_denormalizepan(char *pan);
SHCDLLEXPORT extern int shc_normalizebin(char *bin);
SHCDLLEXPORT extern int shc_denormalizebin(char *bin);
SHCDLLEXPORT extern int shc_normalizenumber(register char *nbp, register char *obp, int len);
//SHCDLLEXPORT extern int shc_user_recon_init();
//SHCDLLEXPORT extern int shc_recon_send( struct shc *shc, int private_mid );
//SHCDLLEXPORT extern int shc_send_recon_500( struct shc *shcmsg );
///*SHCDLLEXPORT extern int shc_revreq(register struct shc *shcmsg);
//SHCDLLEXPORT extern int shc_revreq_mac( struct shc *shcmsg );
//SHCDLLEXPORT extern int shc_reverse_switch(struct shc *shcmsg);
//SHCDLLEXPORT extern int shc_route_reversal(struct shc *shcmsg, int omsg_is_saf);
//SHCDLLEXPORT extern int shc_return_reversal(struct shc *shcmsg);
//SHCDLLEXPORT extern int shc_locate_original(struct shc *shcmsg, struct shc *omsg); */
//SHCDLLEXPORT extern int shc_locate_original(struct shc *shcmsg, struct shc *omsg);
///*SHCDLLEXPORT extern int shc_rev_updoriginal(struct shc *shcmsg, struct shc *omsg);
//SHCDLLEXPORT extern int shc_revreq_mac( struct shc *shcmsg );
//SHCDLLEXPORT extern int shc_route_reversal(struct shc *shcmsg, int omsg_is_saf);
//*/
//SHCDLLEXPORT extern int shc_route(register struct shc *shcmsg);
//SHCDLLEXPORT extern int shc_route_settlement(struct shc *shcmsg);
//SHCDLLEXPORT extern int shc_dispmsg(struct shc *shcmsg);
//SHCDLLEXPORT extern int shc_dispmsg_x(struct shc *shcmsg, int dispmbox, int mbox);
///*SHCDLLEXPORT extern int shc_dispmsg_x(struct shc *shcmsg, int dispmbox, int mbox);*/
//SHCDLLEXPORT extern int shc_save_currency(struct shc *shcmsg, amount_t *amt, amount_t *bal);
//SHCDLLEXPORT extern int shc_restore_currency(struct shc *shcmsg, amount_t *amt, amount_t *bal);
//SHCDLLEXPORT extern int shc_debug_route(struct shc *shcmsg, int outbound);
SHCDLLEXPORT extern int shc_truelength(struct shc *shcmsg);
//SHCDLLEXPORT extern struct shcpkg *shc_saf_determine_file(struct shc *shcmsg);
///** >> R005924 **
//SHCDLLEXPORT extern shc_saf_write_transaction(struct shc *shcmsg);
//SHCDLLEXPORT extern shc_saf_open_file(char *netid);
//SHCDLLEXPORT extern shc_saf_close_file(struct shcpkg *pkg);
//SHCDLLEXPORT extern shc_saf_writefile(struct shcpkg *pkg, struct shc *shcmsg);
//SHCDLLEXPORT extern shc_saf_checkduplicate_write(struct shc *shcmsg, struct shcpkg *pkg);
//SHCDLLEXPORT extern shc_saf_find_txn(struct shc *shcmsg, int code); **/
//SHCDLLEXPORT extern int shc_saf_write_transaction(struct shc *shcmsg);
//SHCDLLEXPORT extern int shc_saf_open_file(char *netid);
//SHCDLLEXPORT extern int shc_saf_close_file(struct shcpkg *pkg);
//SHCDLLEXPORT extern int shc_saf_writefile(struct shcpkg *pkg, struct shc *shcmsg);
//SHCDLLEXPORT extern int shc_saf_checkduplicate_write(struct shc *shcmsg, struct shcpkg *pkg);
//SHCDLLEXPORT extern int shc_saf_find_txn(struct shc *shcmsg, int code);
///** R005924 << */
//SHCDLLEXPORT extern int shc_saf_toistadvice(struct shcpkg *pkg, struct shc *shcmsg);
//SHCDLLEXPORT extern int shc_saf_byname(struct shcpkg *pkg, struct shc *shcmsg, char *name, int send );
//SHCDLLEXPORT extern int shc_saf_convertmsg(struct shc *shcmsg);
//SHCDLLEXPORT extern int shc_saf_resp_convertmsg(struct shc *shcmsg); /* R005896 */
//SHCDLLEXPORT extern int shc_saf_calculate_cutoff(struct shcpkg *pkg);
//SHCDLLEXPORT extern int shc_setkeypointers(struct shc *shcmsg, struct shcpkg *pkg);
SHCDLLEXPORT extern int shc_getissnetkpe(struct shc *shcmsg, struct shcpkg *pkg, char *kpe_cnt);
SHCDLLEXPORT extern int shc_getissnetmac(struct shc *shcmsg, struct shcpkg *pkg, char *mackey);
SHCDLLEXPORT extern int shc_segnsegments(struct shcseg *seg);
SHCDLLEXPORT extern int shc_seglength(struct shcseg *seg);
SHCDLLEXPORT extern int shc_segnopt(struct shcseg *seg, struct shcsegstart *sp);
SHCDLLEXPORT extern char *shc_segcf_getdata(struct shc *shcmsg, char *segname);
//SHCDLLEXPORT extern int shc_route_settlement(struct shc *shcmsg);
//SHCDLLEXPORT extern int shc_settlement_findroute(struct shc *shcmsg);
//SHCDLLEXPORT extern int shcsql_find( struct shc *shcmsg, char *dstp, char *prefix );
//SHCDLLEXPORT extern int shc_stats(struct shc *shcmsg);
//SHCDLLEXPORT extern int shc_set_timers(struct shc *shcmsg);
//SHCDLLEXPORT extern int shc_time_message(struct shc *shcmsg);
//SHCDLLEXPORT extern int shc_time_message_300(struct shc *shcmsg);
//SHCDLLEXPORT extern int shc_time_message_x( struct shc *shcmsg, unsigned char *seg );
//SHCDLLEXPORT extern int shc_time_message_300(struct shc *shcmsg);
SHCDLLEXPORT extern int shc_locate_event_300(register struct shc *shcmsg, struct shc *omsg);
SHCDLLEXPORT extern int shc_locate_event_300(register struct shc *shcmsg, struct shc *omsg);
SHCDLLEXPORT extern int shc_locate_event(register struct shc *shcmsg, struct shc *omsg);
SHCDLLEXPORT extern int shc_locate_event_x( register struct shc *shcmsg, struct shc *omsg, unsigned char *seg );
SHCDLLEXPORT extern int shcmsgIsContactless(struct shcmsg *msg);

//SHCDLLEXPORT extern int shc_time_message_x( struct shc *shcmsg, unsigned char *seg );
//SHCDLLEXPORT extern int shc_locate_event_x( register struct shc *shcmsg, struct shc *omsg, unsigned char *seg );
SHCDLLEXPORT extern int shc_determine_track(struct shc *shcmsg);
SHCDLLEXPORT extern int shc_get_pin_data(struct shc *shcmsg);
//SHCDLLEXPORT extern char *shc_user_get_pindata(struct shc *shcmsg, char *track2, char *pindata)	;
///** R005924 *** SHCDLLEXPORT extern PINVERPARM *shc_user_get_pinverparm(struct shc *shcmsg,	char *track	\
//													, char *pindata, PINVERPARM *pinverparm); */
//SHCDLLEXPORT extern PINVERPARM *shc_user_get_pinverparm(struct shc *shcmsg,	char *track, char *pindata, PINVERPARM *pinverparm);
//
//SHCDLLEXPORT extern char *shc_user_get_pinvaldata(struct shc *shcmsg, char *track2,char *pindata);
//SHCDLLEXPORT extern int shc_user_fill_log_from_message(struct shc *shcmsg, struct shclog *shclog);
//SHCDLLEXPORT extern int shc_user_fill_message_from_log(struct shc *shcmsg, struct shclog *shclog);
///* This should not be global */
//SHCDLLEXPORT extern struct	shc			*shcmsgP ;
///**/
SHCDLLEXPORT extern int					MessageLength ;
//SHCDLLEXPORT extern char	*segbuf1 ;
//SHCDLLEXPORT extern struct	tm	shc_gmt_date ;
SHCDLLEXPORT extern struct	tm	shc_local_date ;
//SHCDLLEXPORT extern struct	tm	shc_work_date ;
//SHCDLLEXPORT extern long		shc_derived_istdate ;
//SHCDLLEXPORT   extern struct shcrespcode error_codes[];
//
SHCDLLEXPORT extern struct shcmsg *tmpShcOmsg;
SHCDLLEXPORT 	extern 	char	mcInst[MAX_TXN_DESTINATION_LEN+1];
SHCDLLEXPORT 	extern 	char	mcInstOther[MAX_TXN_DESTINATION_LEN+1];
SHCDLLEXPORT 	extern 	char	visaInst[MAX_TXN_DESTINATION_LEN+1];
SHCDLLEXPORT 	extern 	int gShcExtendedEventLocate ;
SHCDLLEXPORT	extern char		noBraodcastFlag;
SHCDLLEXPORT    extern int              ofThisSite;             //infomation being processed is of this site
SHCDLLEXPORT    extern int visaSkipCvv;

SHCDLLEXPORT	extern const char		sharedCashRuleName[];
SHCDLLEXPORT	extern const char		sharedCashSecurityRuleName[];
SHCDLLEXPORT    extern int FullCheckDigit;
SHCDLLEXPORT    extern int notifyOnIssResponse;


//
///*	R004832, R004684, R004685, R004686 --> */
//SHCDLLEXPORT extern int shc_isEuroAcquirer( struct shc *shcmsg );
//SHCDLLEXPORT extern int shc_chkEuropayDupTxn(struct shc *shcmsg);
///* <--- Added in shc_log.cxx */
//SHCDLLEXPORT extern int shc_isEuroIssuer( struct shc *shcmsg );	/* R007206 & R007237 */
//SHCDLLEXPORT extern int shc_isEuroNet( struct shc *shcmsg );	/* R007206 & R007237 */
//SHCDLLEXPORT extern int shc_locateEuropayExistedTxn( struct shc *shcmsg, struct shc *omsg, int flagCheckDup);
///* R007984 >> */
//SHCDLLEXPORT extern int shcMakeEventKey(struct shc *shcmsg);
//SHCDLLEXPORT extern	int shc_logadd_restoreSegment( struct shc *, struct shc * );
///* R007984 << */
//
//SHCDLLEXPORT extern	int shc_saf_get_name(char *filename); 	/* R009023 */
//
//
///* R004148 END */
//
///* R007908 */
SHCDLLEXPORT extern int shc_setupLogging();


#ifdef __cplusplus
}
#endif

#ifndef PREPROC_SHCMSG
/*	Additional includes which depend on shc.h first */
#include <shc300.h>
#endif /* PREPROC_SHCMSG */

/* original place of 	7oct97 > */

#ifndef PREPROC_SHCMSG

#include <shcnotify.h>      /* 13jan94*/
#include <shcprototype.h>   /* qd 18dec97 Added  ACXSYS*/
#include <shcextbuf.h> 		/* R003638 */
#include <shc_param.h>
#include <ShcAcceptorName.h>
#include <McastHelper.h>
#include <ShcBalancer.h>

#endif /* PREPROC_SHCMSG */

SHCDLLEXPORT extern char * shc_maskpan (const char *pan);
SHCDLLEXPORT extern int shc_locate_bin(struct shcpkg **shcpkg, bin_t bin);
SHCDLLEXPORT extern int shc_locate_bin(struct shcpkg **shcpkg, char *institutionId, char *userBinId);
SHCDLLEXPORT extern int shc_internalBin2ExternalBin(char *institutionId, char *userBinId, const char *networkid);
SHCDLLEXPORT extern int shc_externalBin2InternalBin(char *networkid, const char *institutionId, const char *userBinId);
SHCDLLEXPORT extern int shc_getInstitutionIdFromCardScheme(char *institutionId, const char *cardScheme);
SHCDLLEXPORT extern	int shc_segAppend4Restore( struct shcmsg *msg, char *segName, char *segData, int segLen );
SHCDLLEXPORT extern	int shc_restoreSegField( struct shcmsg *msg, struct shcmsg *omsg );
SHCDLLEXPORT extern int isMC(ShcmsgHeader *header);
//
//											/* R009132 BEGIN */
//SHCDLLEXPORT extern void shc_logchq_rewind();
//SHCDLLEXPORT extern void shc_logadd_rewind();
//											/* R009132 END   */
//
typedef vector<OCString
#if ! defined(OC_USE_NEW_STL)
		, __STL_DEFAULT_ALLOCATOR(OCString)
#endif
	> listBINS;

//SHCDLLEXPORT extern void shc_inst_profile_display(char *txnSrc, char *txnDest);
//SHCDLLEXPORT extern int shc_inst_profile_getnetworkbin (char *txnSrc, char *txnDst, listBINS &binlist);
//SHCDLLEXPORT extern int shc_inst_profile_getnetworkbin (char *txnSrc, char *txnDst, listBINS &binlist, listBINS &groupBINlist);
//SHCDLLEXPORT extern void shc_callback_log( struct shc *shcmsgP, int logType);
//SHCDLLEXPORT extern int shc_deny_txn(struct shc *shcmsgP);
/* Objects for customization */

//	>>>	R015826
class ShcGenericLog;
SHCDLLEXPORT extern ShcGenericLog *shcGenericLogObj;
class ShcGenericLogHelper;
SHCDLLEXPORT extern ShcGenericLogHelper *shcGenLogHelperObj;
SHCDLLEXPORT extern struct	shckeysmem		*newlyFoundShcBinKey;
extern ShcBalancer *shcBalancerObj;
extern McastHelper *mcastHelperObj;

SHCDLLEXPORT extern void shc_set_contactless_txn(ShcmsgHeader *header);

class ShcDuplicateChk;
extern ShcDuplicateChk *shcDuplicateChkObj;

class ShcPinTryCounter;
extern ShcPinTryCounter *shcPinTryCounterObj;

class ShcCardStatusHelper;
extern ShcCardStatusHelper *shcCardStatusHelperObj;

class ShcCardStatusChngAlw;
extern ShcCardStatusChngAlw *shcCardStatusChngAlwObj;

class Shc300ReqDB;
extern Shc300ReqDB *shc300ReqDBObj;

class SHC300;
extern SHC300 *shc300Obj;

class ShcCardStatusChngAlw;
extern ShcCardStatusChngAlw *shcCardStatusChngAlwObj;

class BinRoute;
extern BinRoute *binRouteObj;
class SingletonBase;
extern SingletonBase *shcSingletonObj;
class UpdateMemHelper;
extern UpdateMemHelper *updateMemHelperObj;
class ShcSharedMemoryHelper;
extern ShcSharedMemoryHelper *shcSharedMemoryHelperObj;

extern int shcIsReplay(struct shcpkg *bp, char *issEntity);
extern int shc_setSafMode(char *formailbox, int mode);
extern int shc_setSafOn ( char *formailbox );
extern int shc_setSafOff( char *formailbox );
extern int shc_setSafOn ( char *instId, char *entityId );
extern int shc_setSafOff( char *instId, char *entityId );
extern int shc_alterIssuerByEntityId( struct shcmsg *msg, struct shcpkg **pkg );
extern int shc_getIssuerByEntityId( struct shcmsg *msg, struct shcpkg **pkg, char *issuer, size_t issuerSize );
extern short extBinCountryCode;		//The country code of chosen extbindb entry
extern int shcEnableSubssecondTimeout;
extern int gShckeysSetDBLock;
extern short extBinLength;		//bin length  of chosen extbindb entry
extern int shcSetTxnStartDate;

extern ShcmsgHeader *headerForLocateNetworkInfo;

//	<<<	R015826

extern void checkDbCon();
struct SenderReciverData
{
        char FirstName[45+1];
        char MiddleName[10];
        char LastName[45+1];
        char StreetAddress[50+1];
        char City[25+1];
        char StateProvinceCode[3+1];
        char Country[3+1];
        char postalCode[20+1];
        char PhoneNumber[20];
        char DateOfBirth[8+1];
        char AccountNumber[16+1];
        char ReferenceNumber[16+1];
        int IdentificationType;
        char IdentificationNumber[12+1];
        char IdentificationCountryCode[3+1];
        int IdentificationExpirationDate;
        char Nationality[3+1];
        char CountryOfBirth[25+1];
        int infoExist;
};
struct TxnData
{
    char UniqueTxnReff[20];
    char FundingSrc[4];
    char ParticipanId[4];
    char txnPurpos[4];
};
typedef struct SenderReciverData SenderReciverData;
typedef struct TxnData TxnData;


extern int parseMSSegment(char *f104MTData, SenderReciverData *sender, SenderReciverData *receiver, TxnData *txnData);
extern int getTagValue(char *srcData, int tagNumber, char *tagValue, int tagValueLen);
extern int  parseSRSegment(char *srcData, SenderReciverData *dataBuff);
extern int  parseTXNSegment(char *srcData, TxnData *dataBuff);

#endif

/*------------------------------------------------------------------------*
 * Old History (1992 - 1996)
 *------------------------------------------------------------------------*/
/*	ad		02Jan92		Added support for retail environment
 *	ad		02Jan92		Expanded acctnum
 *	ss		13Jan92		Add struct shcextbin to support bin ranges
 *	ad		03feb92		Added extended locate variable
 *	ad		03feb92		Added shcKeepPin
 *	ad		28feb92		Changed pcode from 'int' to 'long' just to be safe
 *	ss		19mar92		add struct shclogmatch
 *	ss		07Apr92		Support of 7 digits trace number.
 *	ad		09sep92		added shc300.h	at bottem of file
 *	ad		21sep92		Added include for mbmsg.h
 *	ad		02oct92		Added extern shc_add_auth_saf
 *	ad		20nov92		Added parameter shcNewGentrace
 *	ss		15Apr93		Added paramter shc_use_sw_des
 *	aes		16Apr93		Added DoCurrencyConv to be used by CIBC Cayman.
 *	ad		29apr93		Added shcDupTxnLength
 *	MI		26May93		Added shcagent.h for preauth agent
 *  bsa		09Nov93		Changed seg definition to be more usable
 *	jsn		13jan94		Add shcnotify.h include.
 *	la		15May94		Expanded size of bin range.
 *	ad		17may94		Added extern for shcActionOnTimeout
 *	ad		16nov94		Added extern for shcDuplicateResponse
 *	alf		12Jan95		Added new shcextbin struct
 *	ad		10apr95		Added extern shcReturnDBError
 *  la		01feb95		Replace occurances of shcpin with pinverparm.
 *  qd 		06feb96  	Add filler spaces in shcmsg to store more info
 *  qd 		06feb96   	Add shclog.h include
 *  qd 		21feb96   	Add more fields in shcmsg structure to support IBFT
 *  qd 		22feb96   	Add trabin in shc structure to support IBFT
 *  la	    24mar96     Added extra balance fields.
 * 10002122 la  29may96 Added configuration to route network messages.
 * 10001935 la  31may96 Renamed struct shckeys to struct shckeysmem.
 *                      Renamed struct shcsecdb to struct shckeys.
 *  zm	    02jun96     Added origpcode to struct shcmsg
 *          wrg 961115  Added macro to calculate end-of-msg
 * 1002864  jt  13dec96 Added config for shcSendIss_420NoOrig.
 */
/*------------------------------------------------------------------------*
 * End of file
 *------------------------------------------------------------------------*/
