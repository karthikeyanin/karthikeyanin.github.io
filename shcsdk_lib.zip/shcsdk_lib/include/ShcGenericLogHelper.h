#ifndef _SHCGENLOG_HELPER_H_
#define _SHCGENLOG_HELPER_H_

static char _ShcGenericLogHelper_h_what[] = "@(#) ShcGenericLogHelper.h 1.0 11/12/02 15:22:34";

/*
 *  Copyright (C) 2004 eFunds Corporation ("eFunds").  All Rights Reserved.
 *  eFunds Canada Corporation is an authorized user.
 *
 *  IST is a registered trademark of eFunds Corporation.  Other brand or
 *  product names are trademarks or registered trademarks of their respective
 *  holders.
 *
 *  The information contained herein is the unpublished proprietary property
 *  of eFunds.  Except as specifically authorized in writing by eFunds, the
 *  holder of this document shall: i) keep all information contained herein
 *  confidential, and ii) protect the information, in whole or in part, from
 *  disclosure and dissemination to all third parties.
 *
 *  This document and the software described in it are furnished under license
 *  and may be used or copied only in accordance with the terms of such license.
 *  This document is supplied for information purposes only, is subject to
 *  change without notice, and should not be construed as a commitment by
 *  either eFunds Corporation or eFunds Canada Corporation.
 *
 *
 *                        MODIFICATION HISTORY                  REVIEW
 *
 * SCR#     Who    Date  Description
 * ===========================================================================
 * R030464	Dipa	11Apr12	Implement restore()
 */

#include <dbm_private.h>
#include <dbm.h>
#include <ShcHelperBase.h>
#include <shcchiplog.h>
#include <CShcGenericLog.h>

struct dbBufferHlpr
{
	char *buf;
	int bufferSize;
	int flag;
};

struct SegmentItemHlpr
{
	int segmentHashValue;
	int segmentDataLen;
	char *value;
	char segmentName[MAX_SEG_NAME_LEN+1];
	char dataType;
	char separator;
	char restoreFlag;
	unsigned char sequence;
	unsigned char fieldNum;
};

struct segmentMap
{
	char oldSegName[MAX_SEG_NAME_LEN+1];
	char newSegName[MAX_SEG_NAME_LEN+1];
	char newSubSegName[MAX_SEG_NAME_LEN+1];
};

class ShcGenericLogHelper : public ShcHelperBase
{
	protected:

		int shcchiplogfd;
		int shcchiploginsertfd;
		struct  shcchiplog  shcchiplog;

		char logid[21];
		int msgType;
		char reqresp;
		int noOfGenLogItem;
		int noOfSegMapItem;
		struct SegmentItemHlpr *segmentList;
		struct dbBufferHlpr *bufList;
		int shcGenericLogFieldList[SHC_GENERIC_LOG_FIELD_NUM];
		int ind[SHC_GENERIC_LOG_FIELD_NUM+3];

		DBMHSTMT shInsert;
		DBMHSTMT shLoadBoth;
		DBMHSTMT shLoad1;
		DBMHDBC ch;
		dbm_date_t switch_date;

		int SHC_GENERIC_LOG_BINARY_FIELD_NUM;
		char *valueBuf;
		int valueBufLen;
		struct dbBufferHlpr *sbufList;
		int shcGenericLogBinaryFieldSize;
		DBMHSTMT shUpdate;
		int indb[8];
		struct segmentMap *segMapList;

	public:

		ShcGenericLogHelper();
		~ShcGenericLogHelper();
		const char *getName()
		{
			return (const char *)SHC_ShcGenericLogHelper;
		}

		virtual void initialize();
		virtual void fillSegment(ShcmsgHeader *header, char *logHeader, int *logHeaderLen);
		virtual void insert();
		int hashValue(const char* ptr);

		virtual int insertSegments(ShcmsgHeader *header);
		virtual int map_Shcchiplog(ShcmsgHeader *header);
		virtual int shc_logadd_open();
		virtual int map_Shclogadd(ShcmsgHeader *header);
		virtual IstSegList *restore(ShcmsgHeader *header, char _reqresp, char *reqBufHeader, int reqBufHeaderLen, char *respBufHeader, int respBufHeaderLen);
		int map_ShcchiplogIns(ShcmsgHeader *header, emv* emvbuf);

};

#endif
