//
// Copyright (C) 2009 eFunds Corporation ("eFunds").  All Rights Reserved.
// eFunds Canada Corporation is an authorized user.
//
// IST is a registered trademark of eFunds Corporation.  Other brand or
// product names are trademarks or registered trademarks of their respective
// holders.
//
// The information contained herein is the unpublished proprietary property
// of eFunds.  Except as specifically authorized in writing by eFunds, the
// holder of this document shall: i) keep all information contained herein
// confidential, and ii) protect the information, in whole or in part, from
// disclosure and dissemination to all third parties.
//
// This document and the software described in it are furnished under license
// and may be used or copied only in accordance with the terms of such license.
// This document is supplied for information purposes only, is subject to
// change without notice, and should not be construed as a commitment by
// either eFunds Corporation or eFunds Canada Corporation.
//
/*
 * Description:
 *
 *      MODIFICATION HISTORY
 *
 *  Date         SCR            Who        Description
 *  ===========================================================================
*/

#ifndef SHCPINTRYCOUNTER_H
#define SHCPINTRYCOUNTER_H
static const char* _ShcPinTryCounter_h_what = "@(#) ShcPinTryCounter.h p4.1.25 2014/09/08 00:44:40";

#include <oc/oc_string.h>
#include <dbm.h>
#include <debug.h>
#include <ist_otrace.h>
#define TBL_SHCPINTRYCOUNTER                   "shcpintrycounter"
#include <ShcmsgHeader.h> 
#include <ShcHelperBase.h>
#include <ShcAppBase.h>
#include <ShcHelper.h>

class ShcPinTryCounter : public ShcHelperBase 
{
	public:
			ShcPinTryCounter();
			~ShcPinTryCounter();

			const char *getName()
                        {
                                return (const char *)SHC_ShcPinTryCounter;
                        }
			const char *getTblName() { return TBL_SHCPINTRYCOUNTER; }
			int getCnt(ShcmsgHeader *header,int reset_hours);
			int resetCnt(ShcmsgHeader *header);
			int incCnt(ShcmsgHeader *header);
			int incCnt(ShcmsgHeader *header, int increment);

	protected:
			DBMConn* _dbConn;
			void dbInit();
			void recycle();
			int selectOne(char *pan);
			int getCount(char *pan);
			int insertInPintry(ShcmsgHeader *header,int increment);
			int insertOne(ShcmsgHeader *header);
			int _ind[50];
			int                     site_id;
                        OCDateTime      created;
                        char                    pan[20];
                        OCDateTime      updated;
			DBMInt siteid;
			DBMInt failedCount;
			DBMInt inc;
			DBMDateTime updatedtime;
			DBMStmt* _smtUpdateInc1;
			DBMStmt* _smtUpdateIncN;
			DBMStmt* _smtUpdate;
			DBMStmt* _smtSelOne;
			DBMStmt* _smtInsert;
			DBMStmt* stmt;
};


#endif
