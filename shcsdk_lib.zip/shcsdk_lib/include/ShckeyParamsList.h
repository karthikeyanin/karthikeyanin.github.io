#ifndef _SHCKEYPARAMSLIST_H_
#define _SHCKEYPARAMSLIST_H_

static char _ShckeyParamsList_h_what[] = "@(#) ShckeyParamsList.h 1.4 05/12/01 09:19:00";
/*
 *  Copyright (C) 2004 eFunds Corporation ("eFunds").  All Rights Reserved.     
 *  eFunds Canada Corporation is an authorized user.                            
 *                                                                              
 *  IST is a registered trademark of eFunds Corporation.  Other brand or        
 *  product names are trademarks or registered trademarks of their respective   
 *  holders.                                                                    
 *                                                                              
 *  The information contained herein is the unpublished proprietary property    
 *  of eFunds.  Except as specifically authorized in writing by eFunds, the     
 *  holder of this document shall: i) keep all information contained herein     
 *  confidential, and ii) protect the information, in whole or in part, from    
 *  disclosure and dissemination to all third parties.                          
 *                                                                          
 *  This document and the software described in it are furnished under license  
 *  and may be used or copied only in accordance with the terms of such license.
 *  This document is supplied for information purposes only, is subject to      
 *  change without notice, and should not be construed as a commitment by       
 *  either eFunds Corporation or eFunds Canada Corporation. 
 *
 *
 *                        MODIFICATION HISTORY                  REVIEW
 *
 * SCR#     Who    Date  Description
 * ===========================================================================
 * R015209 Emj 01Dec05 Support for double and triple length MAC keys for Racal
 */

#include <security.h>
#include <ShcHelperBase.h>

	struct shckeys_cfg
	{
		char def_class;
		char def_index;
		char val_new;
		char val_seq;
		char val_chk;
		char upd_tbl;
		char clr_all;                                           /* R001835 */
        char tkpe[IST_SECURITY_KEY_SZ + 1];                     /* R000573 */
		char tkr_double[32 + 1];
		char tkr_triple[48+ 1];
	};

class SHCDLLEXPORT ShckeyParamsList: public InstParamsList, public ShcHelperBase
{

public:
    const char *getName()
    {
        return (const char *)SHC_ShckeyParamsList;
    }

	virtual void Load();
	virtual ShckeyParamsList* clone() {return(new ShckeyParamsList(*this));}
	struct shckeys_cfg *getShccfg() { return &shccfg; }
private:
	struct shckeys_cfg shccfg;
};

//static InstitutionParams shckeyParams;
//static ShckeyParamsList *shckeyParamsList;

extern InstitutionParams shckeyParams;
extern ShckeyParamsList *shckeyParamsList;

#endif
