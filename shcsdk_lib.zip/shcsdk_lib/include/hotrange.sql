/*
 *  Copyright (C) 2004 eFunds Corporation ("eFunds").  All Rights Reserved.     
 *  eFunds Canada Corporation is an authorized user.                            
 *                                                                              
 *  IST is a registered trademark of eFunds Corporation.  Other brand or        
 *  product names are trademarks or registered trademarks of their respective   
 *  holders.                                                                    
 *                                                                              
 *  The information contained herein is the unpublished proprietary property    
 *  of eFunds.  Except as specifically authorized in writing by eFunds, the     
 *  holder of this document shall: i) keep all information contained herein     
 *  confidential, and ii) protect the information, in whole or in part, from    
 *  disclosure and dissemination to all third parties.                          
 *                                                                          
 *  This document and the software described in it are furnished under license  
 *  and may be used or copied only in accordance with the terms of such license.
 *  This document is supplied for information purposes only, is subject to      
 *  change without notice, and should not be construed as a commitment by       
 *  either eFunds Corporation or eFunds Canada Corporation. 
 *                    
 *  #pragma ident "@(#) hotrange.sql 1.3.1.1 16/10/21 10:09:24"
 */
/*

		Hot cards based on card ranges
*/

create table hotrange (
	pan_low			char(19) not null,
	pan_hi			char(19) null,
	status			int,
	cardalert		char(1) null,
	o_rowid			int
)

create unique index hotrange_1 on hotrange (pan_hi, pan_low)
create index hotrange_rid on hotrange (o_rowid)

gg_param  hotrange
(
    extract: TABLE @@@schema@@@.hotrange FILTER (@STREQ(@STRUP(@GETENV('TRANSACTION', 'USERNAME')), @@@gui_user@@@) = 1);
)

