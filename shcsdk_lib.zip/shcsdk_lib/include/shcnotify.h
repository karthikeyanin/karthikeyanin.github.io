/*
 *	IST and IST/Share are registered trademarks of Oasis Technology Ltd.
 *
 *	Copyright (C) 1990 - 1997 Oasis Technology Ltd.
 *	All Rights Reserved
 *	This Module contains Proprietary Information of
 *	Oasis Technology Ltd., and should be treated as Confidential.
 *
 *	THIS IS UNPUBLISHED PROPRIETARY SOURCE CODE OF OASIS TECHNOLOGY LTD.
 *	The copyright notice above does not evidence any  
 *	actual or intended publication of such source code.
 */
/*
#pragma ident "@(#) shcnotify.h 1.5.2.1 16/10/21 10:12:51"
 *
 *                        MODIFICATION HISTORY                  REVIEW
 *
 *	SPR#	Who	Date	Description			Who	Date   
 * ===========================================================================
 * 2002855  la  19mar97 Added copyright header
 *
 *	jsn		13jan94		Kick off: hijacked from istauth.h for samba.
 *	jsn		18feb94		Add respcode field to struct istadvice; 
 *	jsn		05jun94		Add changes for version 2!
 *	hg		11jul94		Add some details regarding the SAF files
 *	hg		15dec94		Added field sendtime in istadvice structure 
 *	la		12jan95		Added field to append to file name
 *  wc		11dec97		Change MAX_ADVICE_BUF definition to include 
 *						sizeof(struct shcmsg)
 *	wc		18dec97		Change MAX_ADVICE_BUF definition and ADVICE_LENGTH
 *						definition
 *  R000737 wc	23feb98	Change file extention "420" to "REV"
 *R008779 jyang 02Jan03 Multi-institution support
 *R021026 jyang 27Aug07 Added new seqno field
 */

#ifndef SHC_NOTIFY_H
#define SHC_NOTIFY_H

#include <oasis.h>
#include <mb.h>
#include <shc.h>

#define		ADVICE_EVENT_MASK	900000000L	/*	added to trace to form 'key' */

#define AUTH_ADVICE_NAME				"istAdviceServer"
#define AUTH_ADVICE_RESPONSE_NAME		"istAdviceResponseServer"

#define ADVICE_CMD_MBOX					"istAdviceCmd"

/* wc	18dec97	*/
#define ADVICE_LENGTH 			(sizeof(struct istadvice))
#define ADVICE_HEADER_LENGTH() 	(sizeof(struct istadvice) - MAX_ADVICE_BUF)

/* #define ADVICE_SAF_FILE		"log/saf/istadvice.SAF" */

#define DSAFF	"reqlog"  /* default history file for in coming requests */
#define SAFDIR	"advice" /* default directory */
#define	DEFEXT	".SAF" 	/* default extension for SAF files and history file */
#define	REVEXT	".REV" 	/* default extension for REV report files */
#define	BAKEXT	".BAK" 	/* default extension for BACKUP files */

#define MAX_ADVICE_ROUTE		60

/* wc	18dec97	*/
#define MAX_ADVICE_BUF			(SHC_SEG_MAX + sizeof(struct shcmsg) )

/*
 *		Advice server message format: same as istauthadvice struct.
 */
struct	istadvice {
	char		route[MAX_ADVICE_ROUTE+1];
	char		formailbox[MAX_ADVICE_ROUTE+1];	/*	used internaly */
	int			datalen;					/*	length of databufer */
	int			len;						/*	used internaly */
	int			status;						/*	used internaly */
	int			replay;						/*	used internaly */
	long		key;						/*	used internaly */
	long		offset;						/*	location in file */
	int			sender;
	long		sendtime;					/*	14Dec94 - time stamp */
	long		sleeptime;					/*	how long to wait */
	int			respcode;					/*  18feb94: */
	char		suffix[10];					/* 12Jan95 */
	double		dummy;
	char		buf[MAX_ADVICE_BUF];
	int			safcutofftime;
	date_t		safcutoffdate;
	int 		eventId;					
	int 		retries; 					// limited retry times
	char		seqno[10+9+1];		// long + ###+ID+### (tps up to 999+NODEID+pid)
        int             dual_site_source_node_id;
};



/*	05jun94
 *	Classification flags for new istadvice routing table.	
 */
#define		ADV_NUM_TKN			6	

#define		ADV_ISS_TKN			1
#define		ADV_ACQ_TKN			2
#define		ADV_MSG_TKN			3
#define		ADV_PCD_TKN			4
#define		ADV_RSP_TKN			5
#define		ADV_FLG_TKN			6

#define		ADV_ISSBIN_SET		0x00000001	
#define		ADV_ACQBIN_SET		0x00000002
#define		ADV_MSGTYP_SET		0x00000004
#define		ADV_PCODE_SET		0x00000008 
#define		ADV_FLAG_SET		0x00000010
#define		ADV_RESP_SET		0x00000020

#define		ADV_Ibin_HasAlias	0x00000001
#define		ADV_Abin_HasAlias	0x00000002

#define		ADV_Resp_Approve		0x00000001 
#define		ADV_Resp_Deny			0x00000002 
#define		ADV_Resp_Specific		0x00000004 
#define		ADV_Resp_Any			0x00000008

#define		ADV_Flag_StandinOnly	0x00000001
#define		ADV_Flag_ForwardOnly	0x00000002

#endif
