#ifndef DSWITCH
#define DSWITCH
#endif

#ifndef _SHCMSGHELPER_H_
#define _SHCMSGHELPER_H_

static char _ShcmsgHelper_h_what[] = "@(#) ShcmsgHelper.h 1.20.10.1 20/05/15 14:15:26";

/*
 *  Copyright (C) 2004 eFunds Corporation ("eFunds").  All Rights Reserved.     
 *  eFunds Canada Corporation is an authorized user.                            
 *                                                                              
 *  IST is a registered trademark of eFunds Corporation.  Other brand or        
 *  product names are trademarks or registered trademarks of their respective   
 *  holders.                                                                    
 *                                                                              
 *  The information contained herein is the unpublished proprietary property    
 *  of eFunds.  Except as specifically authorized in writing by eFunds, the     
 *  holder of this document shall: i) keep all information contained herein     
 *  confidential, and ii) protect the information, in whole or in part, from    
 *  disclosure and dissemination to all third parties.                          
 *                                                                          
 *  This document and the software described in it are furnished under license  
 *  and may be used or copied only in accordance with the terms of such license.
 *  This document is supplied for information purposes only, is subject to      
 *  change without notice, and should not be construed as a commitment by       
 *  either eFunds Corporation or eFunds Canada Corporation. 
 *
 *                        MODIFICATION HISTORY                  REVIEW
 *
 * SCR#     Who    Date  Description
 * ===========================================================================
 * R0xxxxx 
 * R011307  Emj   18Oct04 Capture date and settlement date from business day profile
 * R000000 jyang  17Oct06 Locate issuer by iss_entityId
 * R020162 Emj    01Jum07 Support for DCVV/ICVV/CVC3/SCVC3 validation
 * R027876 dipa   02Mar10 USPS changes
 * R160134010 IS  29Feb16 Addition of a flag to log into shccard table 
 */
 
#include <ShcBin.h>
#include <ShcmsgHeader.h>
#include <Shc300Header.h>
#include <ShcHelperBase.h>
#include <multi_institution.h>

class ShcmsgHelper : public ShcHelperBase
{
public:
    const char *getName()
    {
        return (const char *)SHC_ShcmsgHelper;
    }

	virtual char *shc_locate_track_data(struct shcmsg *msg);
	virtual int shc_determine_track(ShcmsgHeader *header);
	virtual int shc_get_pin_data(ShcmsgHeader *header);
	virtual int shc_stats(ShcmsgHeader *header);
	virtual int shc_dispmsg(ShcmsgHeader *header);
	virtual int shc_dispmsg_x(struct shcmsg *msg, int dispmbox, int mbox);
	virtual int shc_save_currency(ShcmsgHeader *header, amount_t *amt, amount_t *bal);
	virtual int shc_restore_currency(ShcmsgHeader *header, amount_t *amt, amount_t *bal);
	virtual int shc_debug_route(struct shcmsg *msg, int outbound);
	virtual int dump_emv( struct shcmsg *msg, FILE *fd );
	virtual int shc_set_return_msgno(struct shcmsg *shcmsg);
	virtual int shc_get_return_msgno(int msgno);
//	virtual int shc_gentrace();
	virtual int shc_fx_convert(amount_t *srcamt,
	 		   		int src_curcode,
	 		   		amount_t *dstamt,
	 		   		int dst_curcode,	/*	to currency */
	 		   		amount_t *sell_spread,	/*	sell spread */
	 		   		amount_t *buy_spread,	/*	buy spread */
	 		   		int base_curcode,
	 		   		amount_t	*src_currency_rate,	/* rate used */
	 		   		amount_t *dst_currency_rate,	/* rate used */
	 		   		amount_t	*agr_currency_rate);	/* rate used if going from acq -> iss directly */
	virtual int Initialise();
	virtual int shc_determine_correct_currency(ShcmsgHeader *header);
	virtual int shc_request_convert(ShcmsgHeader *header);
	virtual int shc_response_convert(ShcmsgHeader *header);
	virtual int shc_use_default_currency(ShcmsgHeader *header);
	virtual int shc_set_currency_codes(ShcmsgHeader *header);
	virtual int shc_set_conversion_rates(ShcmsgHeader *header);
	virtual int shc_is_req_or_resp(struct shcmsg	*msg);
	virtual int amount_conversion(amount_t *amount, amount_t rate, char method);
	virtual int shc_convert_amount(struct shcmsg *msg, amount_t *amount, int convert_from_to);
	virtual int shc_invert_rate(amount_t *in_rate);
	virtual int shc_deny_txn(ShcmsgHeader *header);
	virtual void shc_callback_log( ShcmsgHeader *header, int logType);
	virtual long shc_next_auth_number();
	virtual long shc_old_auth_num();
	virtual long shc_generate_auth_number(ShcmsgHeader *header);//R027876
	virtual int shc_init_from_device(register ShcmsgHeader *header);
	virtual int shc_check_pan (char *pan);
	virtual int find_preauth_agent();
	virtual int shc_verify_cvv2(ShcmsgHeader *header);
	virtual int shc_pinblk_ob2tb(ShcmsgHeader *header);
	virtual int shc_cvv(ShcmsgHeader *header);
	virtual int shc_txn_has_pin(ShcmsgHeader *header);
	virtual int shc_keys_check_status(ShcmsgHeader *header, ShcBin *shcBin, char *kpe_cnt);
	virtual int shc_readcard(struct shcmsg *msg);
	virtual int shc_createcard(struct shcmsg *msg);
	virtual int shc_updatecard();
	virtual int shc_writecard();
	virtual int shc_getcard(struct shcmsg *msg);
	virtual int shc_iscardhot(ShcmsgHeader *header);
	virtual int shc_check_hot_card(ShcmsgHeader *header);
	virtual int shc_check_hot_range(ShcmsgHeader *header);
	virtual int shc_iscardexpired(ShcmsgHeader *header);
	virtual int shc_normalizepan(char *pan);
	virtual int shc_normalizebin(char *bin);
	virtual int shc_denormalizebin(char *bin);
//	virtual int shc_normalizenumber(register char *nbp, register char *obp, int len);
	virtual int shc_denormalizepan(char *pan);
	virtual int shcGetIssAcq(ShcmsgHeader *header, int getIssuerFromPan);
	virtual int shc_locateEuropayOriginal( ShcmsgHeader *header);
	virtual int locateOrigTxn(ShcmsgHeader *header);
	virtual int setLateResponseFlags(ShcmsgHeader *header);
	virtual int setSettleRespAdviceFlags(ShcmsgHeader *header);
	virtual int setPinParm(ShcmsgHeader *header);
	virtual int setPinFlag(ShcmsgHeader *header);
	virtual int shcMakeKey(ShcmsgHeader *header);
	int shcMakeKeyLog(ShcmsgHeader *header);
	virtual int shcGetTrace(int eventKey);
        virtual int replicateMessageToOtherSite( ShcmsgHeader *header );
protected:
	ShcmsgHeader *tmpShcOmsg;
	virtual int recon_api_getserver();
	virtual int recon_api_getprivate();


public:
	virtual int shc_checkscode(ShcmsgHeader *shcmsg);
	virtual int shc_verify_check_digit(ShcmsgHeader *shcmsg);
	virtual int shc_checkduptxn(ShcmsgHeader *shcmsg);
	virtual int shc_setCvvResultCode( ShcmsgHeader *shcmsg, char val );
	virtual char shc_getCvvResultCode(ShcmsgHeader *shcmsg );
	virtual int shc_checkCvvCvv2( ShcmsgHeader *shcmsg );
	virtual int shc_isEuroAcquirer( ShcmsgHeader *shcmsg );		// Europay Network is Acquirer
	virtual int shc_isEuroIssuer( ShcmsgHeader *shcmsg );		// Europay Network is Issuer
	virtual int shc_isEuroNet( ShcmsgHeader *shcmsg );
	virtual int shc_isEuroTxn(ShcmsgHeader *shcmsg, char which ); // A: asEuroAcquirer, I: asEuroIssuer
	virtual int shc_chkEuropayDupTxn(ShcmsgHeader *shcmsg);
	virtual int checkEuAcquirerProfile( ShcmsgHeader *shcmsg, unsigned long lNetworkData );
	virtual int shc_updateduptxn_info(ShcmsgHeader *shcmsg);
	virtual int shc_openfloorlim();
	virtual int shc_balance_encryption(ShcmsgHeader *shcmsg, char *kme, char procmode);
	virtual int shc_build_balance_data(char * data_buf, amount_t *src);
	virtual int shc_normalize_amount(register char *nbp, register char *obp, int len);
	virtual int data_edit_error(char * data);
	virtual int shc_restoreOriginal(ShcmsgHeader *shcmsg);
	virtual int shc_set_return_msgno(ShcmsgHeader *header);
	virtual int shc_locate_device_message(ShcmsgHeader *header);
	virtual int shc_route(ShcmsgHeader *header);
	virtual int dumpShcmsg( struct shcmsg *msg, int mbOutbound=0 );
	virtual int dumpHexShcmsg( struct shcmsg *msg, FILE *fd );
	virtual int shc_send_recon_500( ShcmsgHeader *header );
	virtual int shc_recon_send( ShcmsgHeader *header, int private_mid );
	virtual int shc_route_settlement(ShcmsgHeader *header);
	virtual int shc_settlement_findroute(ShcmsgHeader *header);
	virtual int shc_settlement_format_message(ShcmsgHeader *header, struct shc500std *std500);
	virtual int shc_settlement_inquire(struct shc500std *msg);
	virtual int shc_settlement_get_values( struct shc500std *std500, ShcmsgHeader *header,
				long *count, dec_t *amount, long *revcount, dec_t *revamount );
	
    virtual int getBusinessDayType(ShcmsgHeader *header);
	virtual long getCaptureDate(ShcmsgHeader *header);
	virtual long getSettlementDate(ShcmsgHeader *header);
	
	virtual int getAlterIssuerByEntityId( struct shcmsg *msg, char *alterIssuer, struct shcpkg **pkg, size_t alterIssrSize );
	
	virtual int fillTransNodeInfo(ShcmsgHeader *header, ShcBin *bin,RoutingInfo*, int *outbound, struct InstitutionProfile *ip);
	virtual int fillRetNodeInfo(ShcmsgHeader *header, RoutingInfo *routingBuf);
	virtual int shc_verify_dcvv(ShcmsgHeader *);
	virtual int shc_verify_cvc3(ShcmsgHeader *);
	virtual int shc_verify_icvv(ShcmsgHeader *);
	virtual int shc_verify_scvc3(ShcmsgHeader *);
	virtual int checkRouting(ShcmsgHeader *header);
	virtual int addRoutingInfoSegment(ShcmsgHeader *header, NetworkInfo& netInfo);//	---	R030556
	virtual int shc_checkCavvCaav( ShcmsgHeader *shcmsg );
	virtual int shc_verify_cavv_caav( ShcmsgHeader *shcmsg );
	virtual int shc_setissuerCAVVResultCode( ShcmsgHeader *shcmsg, char val );
	virtual char shc_getissuerCAVVResultCode(ShcmsgHeader *shcmsg );
	virtual int shc_checkCsc( ShcmsgHeader *shcmsg );
	virtual int shc_verify_csc( ShcmsgHeader *shcmsg );
	virtual void shc_set_contactless_txn(ShcmsgHeader *header);
	virtual int verify_master_spa2_hmac(const char *pan, PINVERPARM *pp, char *pandata, char *merchant_name, char *amount, int  currency_code, char *txn_id, unsigned char  *iavdata);
	virtual int verify_master_spa2_hmac(const char *pan, PINVERPARM *pp, char *pandata, char *txn_id, unsigned char  *iavdata);
	virtual int checkStandinCounterValue(ShcmsgHeader* header);
	virtual int checkStandInDecisionByIssuerResponse( ShcmsgHeader* header );
	virtual int performStandInOnlyChecks( ShcmsgHeader* header );

};
extern int log_to_shccard;  //  --- R160134010
extern int shcAsynchSecMode;

#endif

