/*
 *  Copyright (C) 2004 eFunds Corporation ("eFunds").  All Rights Reserved.     
 *  eFunds Canada Corporation is an authorized user.                            
 *                                                                              
 *  IST is a registered trademark of eFunds Corporation.  Other brand or        
 *  product names are trademarks or registered trademarks of their respective   
 *  holders.                                                                    
 *                                                                              
 *  The information contained herein is the unpublished proprietary property    
 *  of eFunds.  Except as specifically authorized in writing by eFunds, the     
 *  holder of this document shall: i) keep all information contained herein     
 *  confidential, and ii) protect the information, in whole or in part, from    
 *  disclosure and dissemination to all third parties.                          
 *                                                                          
 *  This document and the software described in it are furnished under license  
 *  and may be used or copied only in accordance with the terms of such license.
 *  This document is supplied for information purposes only, is subject to      
 *  change without notice, and should not be construed as a commitment by       
 *  either eFunds Corporation or eFunds Canada Corporation. 
 */
/*
#pragma ident "@(#) shcbin.sql 1.6.1.1 16/10/21 10:10:39"
 *
 *                        MODIFICATION HISTORY                  REVIEW
 *
 *	SPR#	Who	Date	Description			Who	Date   
 * ===========================================================================
 *  R001835 qd  16feb99 Added bin_cfg field to hold bin level configurations
 *  R004671 Dds	23Jun00	Merge vsdc enhancement to 7.2, refer to 2007336 
 *  2007336 Mch 18Feb00 Added bin_cfg and cammailbox for chipdata enhancement 
 *                      on 7.1.3
 *R008717 ztang 11Nov02	Multi-institution support
 *R016654 Emj   19Jun06 Added field keyparam to share keys between bins
 */
create table shcbin 
    (
     institutionid varchar(10) not null,
     userbinid char(10) null,
     networkid char(10) null,
     description char(30) null,
     cardname char(10) null,
     network char(10) null,
     pinparm char(10) null,
     mailbox char(30) null,
     port char(30) null,
     bintype int,
     timeout int,
     netmgr char(40) null,
     usekeys char(1) null,
     txn_set char(20) null,
     saftype char(1) null,
     saffile char(1) null,
     safinter char(1) null,
     safamount money,
     saflimit int,
     refresh int,
     posmailbox char(30) null,
     authflag char(4) null,
     authserver char(30) null,
     txnamount money,
     iss_minamount money,
     acq_minamount money,
     floor_1 money,
     floor_2 money,
     floor_3 money,
     npintry smallint,
     def_from_acct smallint,
     def_to_acct smallint,
     debit_credit char(1) null,
     checkexp char(1) null,
     checkpin char(1) null,
     checkhot char(1) null,
     checkscode char(1) null,
     checkcvv char(1) null,
     cvvdate smallint,
     checkmod10 char(1) null,
     cardalert char(1) null,
     cutoff int,
     send500 char(1) null,
     cutovertype char(1) null,
     ccstlmt char(1) null,
     currency_code smallint,
     country_code smallint,
     bankname char(22) null,
     echotest char(1) null,
     binrange char(1) null,
     bin_cfg char(32) null, /* R001835 */
     cammailbox char(30) null,	/* 2007336 R004671 Dds 23Jun00 cam server mailbox name*/
	 keyparam char(10) null,
	 node varchar(30) null,
	 bin_cfg2 char(32) null
    )




/*oasis is owner of index shcbin_ix*/
create unique index shcbin_ix on shcbin (networkid)
create unique index shcbin_ix_2 on shcbin (institutionid, userbinid)

GG_PARAM shcbin
(
);

