#ifndef DSWITCH
#define DSWITCH
#endif

#ifndef INCLUDE_SHCDB
#define INCLUDE_SHCDB
static char _shcdb_h_what[] = "@(#) shcdb.h 2.15.1.1 16/10/21 10:11:19";

/*
 *	IST and IST/Share are registered trademarks of Oasis Technology Ltd.
 *
 *	Copyright (C) 1990 - 1996 Oasis Technology Ltd.
 *	All Rights Reserved
 *	This Module contains Proprietary Information of
 *	Oasis Technology Ltd., and should be treated as Confidential.
 *
 *	THIS IS UNPUBLISHED PROPRIETARY SOURCE CODE OF OASIS TECHNOLOGY LTD.
 *	The copyright notice above does not evidence any  
 *	actual or intended publication of such source code.
 *
 *                        MODIFICATION HISTORY                  REVIEW
 *
 *	SPR#	Who	Date	Description			Who	Date   
 * ===========================================================================
 *  10001860 la 25apr96 Removed definition of hotrange structure.
 *                      Use table definition of shccard.
 *                      Use table definition of posauth.
 *                      Use table definition of postxn.
 *                      Use table definition of shcbinmap.
 *                      Use table definition of shcextbindb.
 *                      Removed definition of floorlim structure.
 *                      Removed definition of cardaudit structure.
 * 10001935 la  31may96 Removed definition of shcsecdb and use shckeys instead.
 * 10002572 jt	15oct96 Added o_rowid to synchonise with database table.
 *	ad		08Jan92		New shcbin definition (add ccstlmt)
 *	ss		13Jan92		Add struct shcextbindb structure to support bin range
 *	ss		29Apr93		Change layout of shccard to support duplicate authreq.
 *	alf		12Jan95		changed the shcextbindb table.
 * R002113  yh 30Mar99  Remove authnumdb definition from this file.
 * R001835  qd 13apr99  Added bin level configuration 
 * R004671  Ssc 28Jun00 integration 7.2 for VSDC  
 *R008717 ztang 10Nov02 Multi-institution support
 *R011218 Emj   16Jun04 Removed shcbinmap functionality
 *R016654 Emj   19JUn06 Added field keyparam to share keys between bins
 */

#include <stdio.h>

#include <shcextbindb.h>										/* 10001860 */
#include <shckeys.h>											/* 10001935 */
#include <shcbin_db.h>


#endif
