//
// Copyright (C) 2009 eFunds Corporation ("eFunds").  All Rights Reserved.
// eFunds Canada Corporation is an authorized user.
//
// IST is a registered trademark of eFunds Corporation.  Other brand or
// product names are trademarks or registered trademarks of their respective
// holders.
//
// The information contained herein is the unpublished proprietary property
// of eFunds.  Except as specifically authorized in writing by eFunds, the
// holder of this document shall: i) keep all information contained herein
// confidential, and ii) protect the information, in whole or in part, from
// disclosure and dissemination to all third parties.
//
// This document and the software described in it are furnished under license
// and may be used or copied only in accordance with the terms of such license.
// This document is supplied for information purposes only, is subject to
// change without notice, and should not be construed as a commitment by
// either eFunds Corporation or eFunds Canada Corporation.
//
/*
 * Description: Event manager encapsulates event management code 
 *
 *	MODIFICATION HISTORY
 *
 *  Date     SCR        Who       Description
 *  ===========================================================================
 *
 */

#ifndef SHCNEGATIVEAUTH_H
#define SHCNEGATIVEAUTH_H
static const char* _ShcNegativeAuth_h_what = "@(#) ShcNegativeAuth.h p4.1.25 2014/09/08 00:44:40";

#include <oc/oc_string.h>
#include <dbm.h>
#include <debug.h>
#include <ist_otrace.h>
#include <ShcmsgHeader.h>
#include <ShcHelperBase.h>
#include <ShcAppBase.h>
#include <ShcHelper.h>
const char* const SHCNEGATIVEAUTH_OBJ_NAME = "ShcNegativeAuth";
struct NegAuth
{
	int saf_num;
	amount_t        saf_amount;
};

class ShcNegativeAuth:public ShcHelperBase
{
public:		
	
	ShcNegativeAuth();	
	static ShcNegativeAuth *getInstance();
	virtual ~ShcNegativeAuth();
	virtual const char *getName(){return SHCNEGATIVEAUTH_OBJ_NAME;};
	virtual int resetLimit(ShcmsgHeader *header,long safdate=0);		
	virtual int reverseLimit(ShcmsgHeader *header);		
	virtual int checkLimit(ShcmsgHeader *header,NegAuth*);
	virtual int updateLimit(ShcmsgHeader *header,NegAuth*);

protected:

		int              _site_id;
		char	             _pan[19+1];
		long              _safdat;
		long              _safno;
                amount_t        _safamt;
                OCDateTime      _updated;
                OCDateTime      current;

		DBMDateTime 	updateddate;
		DBMInt              d_site_id;

		char	buf1[50];
		NegAuth negauth; 
		virtual int prepareSelectOne();
		virtual int prepareInsertOne();
		virtual int prepareUpdateOne();
		virtual int getData(ShcmsgHeader* header);
        virtual int insertCardData(ShcmsgHeader*);
        virtual int getCount(char * pan);
       
	    virtual void dbInit();
		virtual void recycle();
		int _ind[50];
		DBMConn* _dbConn;
		DBMStmt* stmt;
		DBMStmt* _smtUpdate;
		DBMStmt* _smtSelOne;
		DBMStmt* _updateTbl;
		DBMStmt* _smtInsert;

                        
};


#endif

