#ifndef _SHCSAFIOHELPER_H_
#define _SHCSAFIOHELPER_H_

static char _ShcSafIOHelper_h_what[] = "@(#) ShcSafIOHelper.h 1.6 20/01/30 12:56:36";

/*
 *  Copyright (C) 2004 eFunds Corporation ("eFunds").  All Rights Reserved.     
 *  eFunds Canada Corporation is an authorized user.                            
 *                                                                              
 *  IST is a registered trademark of eFunds Corporation.  Other brand or        
 *  product names are trademarks or registered trademarks of their respective   
 *  holders.                                                                    
 *                                                                              
 *  The information contained herein is the unpublished proprietary property    
 *  of eFunds.  Except as specifically authorized in writing by eFunds, the     
 *  holder of this document shall: i) keep all information contained herein     
 *  confidential, and ii) protect the information, in whole or in part, from    
 *  disclosure and dissemination to all third parties.                          
 *                                                                          
 *  This document and the software described in it are furnished under license  
 *  and may be used or copied only in accordance with the terms of such license.
 *  This document is supplied for information purposes only, is subject to      
 *  change without notice, and should not be construed as a commitment by       
 *  either eFunds Corporation or eFunds Canada Corporation. 
 *
 *
 *                        MODIFICATION HISTORY                  REVIEW
 *
 * SCR#     Who    Date  Description
 * ===========================================================================
 * R0xxxxx ztang 05Nov03 Creation
 * R016871  spa  06Jul06 Added new method net_saf_exists(struct shcpkg *pkg)
 */
 

#include <shc.h>
#include <shcextbuf.h>
#include <ShcSdkCommon.h>
#include <ShcmsgHeader.h>
#include <ShcHelperBase.h>


class ShcSafIOHelper : public ShcHelperBase
{
public:
    const char *getName()
    {
        return (const char *)SHC_ShcSafIOHelper;
    }

	virtual ShcBin *shc_saf_determine_file(ShcmsgHeader *header);
	virtual int shc_saf_write_transaction(ShcmsgHeader *header);
	virtual int shc_saf_open_file(char *netid);
	virtual int shc_saf_close_file(ShcBin *shcBin);
	virtual int shc_saf_writefile(ShcBin *shcBin, ShcmsgHeader *header);
	virtual int shc_saf_checkduplicate_write(ShcmsgHeader *header, ShcBin *shcBin);
	virtual int shc_saf_find_txn(ShcmsgHeader *header, int code);
	virtual int shc_saf_locate_transaction(ShcmsgHeader *header, int fd, struct istadvice *advicemsg);
	virtual int shc_saf_byname(ShcBin *shcBin, ShcmsgHeader *header, char *name, int send );
	virtual int shc_saf_convertmsg(ShcmsgHeader *header);
	virtual int shc_saf_resp_convertmsg(ShcmsgHeader *header);
//  virtual int shc_saf_calculate_cutoff(ShcBin *shcBin);
	virtual int shc_saf_get_name(char *filename, size_t filenmeSze);
	virtual int shc_saf_calculate_capdate(struct istadvice *advicep, ShcmsgHeader *header);
	virtual char *shc_saf_routename_pure(char *fName);
	virtual int shc_saf_toistadvice(ShcBin *shcBin, ShcmsgHeader *header);
	virtual int net_saf_exists(struct shcpkg *pkg); //      ---     R016871

};

#endif

