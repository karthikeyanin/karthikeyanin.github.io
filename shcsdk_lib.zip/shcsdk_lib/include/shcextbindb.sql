/*
 *  Copyright (C) 2004 eFunds Corporation ("eFunds").  All Rights Reserved.     
 *  eFunds Canada Corporation is an authorized user.                            
 *                                                                              
 *  IST is a registered trademark of eFunds Corporation.  Other brand or        
 *  product names are trademarks or registered trademarks of their respective   
 *  holders.                                                                    
 *                                                                              
 *  The information contained herein is the unpublished proprietary property    
 *  of eFunds.  Except as specifically authorized in writing by eFunds, the     
 *  holder of this document shall: i) keep all information contained herein     
 *  confidential, and ii) protect the information, in whole or in part, from    
 *  disclosure and dissemination to all third parties.                          
 *                                                                          
 *  This document and the software described in it are furnished under license  
 *  and may be used or copied only in accordance with the terms of such license.
 *  This document is supplied for information purposes only, is subject to      
 *  change without notice, and should not be construed as a commitment by       
 *  either eFunds Corporation or eFunds Canada Corporation. 
 *                    
 *  #pragma ident "@(#) shcextbindb.sql 1.9.2.1 16/10/21 10:11:50"
 *
 * R012134 Emj 04Oct04 Issuer Entity Support 
 * R029416 las 19May11 add issuer country code
 */

create table shcextbindb (
	
	lowbin			char(15)  not	null,		/* external bin		*/
	highbin			char(15)	null,		/* external bin		*/

	o_level			int,					/* indicate the properties	*/
	status			char(1)		null,		/* Active, Inactive, Delete, Error*/

	description		char(50)	null,
	destination		varchar(10),				/* Where the entry comes from
											 * e.g. "VISA", "CIBC"
											 */
    entity_id       varchar(30),
	cardproduct		char(10),				/* Card LOGO name. e.g. 
											 *"PLUS", "CIRRUS"
											 */
	network_data	char(10),
	file_name		char(20)	null,		/* the text file name	*/
	file_version	char(10)	null,
	file_date		date,				/* file load date	*/
	country_code	smallint	null,			/* issuer country code  */
	network_config  char(10)		,
	bin_length		int				/* bin length  */
)

create unique index shcextbindb_1 on shcextbindb (lowbin, highbin, destination, entity_id, cardproduct, status)
create index shcextbindb_4 on shcextbindb (file_name)
create index shcextbindb_5 on shcextbindb (status)
gg_param shcextbindb
(
    extract: TABLE @@@schema@@@.shcextbindb FILTER (@STREQ(@STRUP(@GETENV('TRANSACTION', 'USERNAME')), @@@gui_user@@@) = 1);
)

