/*
 *  Copyright (C) 2004 eFunds Corporation ("eFunds").  All Rights Reserved.     
 *  eFunds Canada Corporation is an authorized user.                            
 *                                                                              
 *  IST is a registered trademark of eFunds Corporation.  Other brand or        
 *  product names are trademarks or registered trademarks of their respective   
 *  holders.                                                                    
 *                                                                              
 *  The information contained herein is the unpublished proprietary property    
 *  of eFunds.  Except as specifically authorized in writing by eFunds, the     
 *  holder of this document shall: i) keep all information contained herein     
 *  confidential, and ii) protect the information, in whole or in part, from    
 *  disclosure and dissemination to all third parties.                          
 *                                                                          
 *  This document and the software described in it are furnished under license  
 *  and may be used or copied only in accordance with the terms of such license.
 *  This document is supplied for information purposes only, is subject to      
 *  change without notice, and should not be construed as a commitment by       
 *  either eFunds Corporation or eFunds Canada Corporation. 
 *                    
 */
/*
 *
 *                        MODIFICATION HISTORY                  REVIEW
 *
 * SPR#    Who Date    Description         Who Date
 * ===========================================================================
 *  R002797 fguo 30Dec99 SHC Callback
 *  R006874 ccy 31Oct01 Change char* to const char*
 *  R007909 Emj 13Jun02 Added return values for callbacks
 *  R023659 ram 19Jun08 Callback prototype changed to improve performance
 *
 */


#if !defined( CALLBACKDLLEXPORT )
#   if defined( WIN32 )
#       define CALLBACKDLLEXPORT __declspec(dllimport)
#   else
#       define CALLBACKDLLEXPORT
#   endif
#endif


#ifndef _SHC_CALLBACK_H_
#define _SHC_CALLBACK_H_

static char _shc_callback_h_what[] = "@(#) shc_callback.h 1.3 08/06/19 11:19:33";

#include "shc.h"

#ifdef WIN32
	#define STLExport 
#else
	#define STLExport
#endif

#ifdef __cplusplus

#include "oc/oc_string.h"
#include "SCBMap.hh"
#include "ShcHeader.h"	//	---	R023659

#define SHCCALLBACKNONE         0 		/* No return value */
#define SHCCALLBACKOVERRIDE     1		/* Override existing function */
#define SHCCALLBACKCONTINUE     2		/* Continue as normal */
#define SHCCALLBACKDENY     	3		/* Deny this transaction if possible */
#define SHCCALLBACKDROP     	4		/* Drop this transactionif possible */

// Abstract CallBack Class
class CALLBACKDLLEXPORT shcCallBack
{
public:

	shcCallBack() {};
	virtual int execute( ShcHeader *shcmsg, OCString& ProcessingPoint) = 0;	//  --- R023659
};

// Factory Class
class CALLBACKDLLEXPORT shcCallBackFactory
{
public:

	shcCallBackFactory() {};

	int register_callback( shcCallBack* cb, const OCString& name);
	shcCallBack*    lookup(const OCString& name) const;

	static shcCallBackFactory*	getFactory();

private:
	SCBMap<OCString, shcCallBack*>    factoryMap;
	static	shcCallBackFactory* _instance;
};

#endif

#ifdef __cplusplus
extern "C" {
#endif


CALLBACKDLLEXPORT extern int fillClassNames(char** ptoPbegin);

class CALLBACKDLLEXPORT cbTblEntry;

CALLBACKDLLEXPORT extern int fillKeyFields (cbTblEntry& anEntry, int i, char** ptoPbegin);

CALLBACKDLLEXPORT extern int readCallBackConfig(void);

CALLBACKDLLEXPORT extern int shc_callback ( ShcHeader *shcmsg, const char* processingPoint);	//	---	R023659





#ifdef __cplusplus
}
#endif

#endif
