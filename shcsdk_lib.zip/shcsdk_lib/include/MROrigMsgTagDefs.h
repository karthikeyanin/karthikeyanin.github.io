#ifndef _MR_ORIGMSG_TAG_DEFS_H_
#define _MR_ORIGMSG_TAG_DEFS_H_

static char _MROrigMsgTagDefs_h_what[] = "@(#) MROrigMsgTagDefs.h 1.1"; 

/*
 *  Copyright (C) 2004 eFunds Corporation ("eFunds").  All Rights Reserved.     
 *  eFunds Canada Corporation is an authorized user.                            
 *                                                                              
 *  IST is a registered trademark of eFunds Corporation.  Other brand or        
 *  product names are trademarks or registered trademarks of their respective   
 *  holders.                                                                    
 *                                                                              
 *  The information contained herein is the unpublished proprietary property    
 *  of eFunds.  Except as specifically authorized in writing by eFunds, the     
 *  holder of this document shall: i) keep all information contained herein     
 *  confidential, and ii) protect the information, in whole or in part, from    
 *  disclosure and dissemination to all third parties.                          
 *                                                                          
 *  This document and the software described in it are furnished under license  
 *  and may be used or copied only in accordance with the terms of such license.
 *  This document is supplied for information purposes only, is subject to      
 *  change without notice, and should not be construed as a commitment by       
 *  either eFunds Corporation or eFunds Canada Corporation. 
 *
 *
 *                        MODIFICATION HISTORY                  REVIEW
 *
 * SCR#     Who    Date  Description
 * ===========================================================================
 */

#include <shc.h>
//TAG defines - Tag IDs less than 5000 are reserved for core data elements. Tag IDs 5001-9999 are reserved for custom tags

#define	TAG_ORIGMSG_SITE_ID				1
#define	TAG_ORIGMSG_SHCLOG_ID			2
#define TAG_ORIGMSG_SENDER_NODEID       3

#define ORIGMSG_LOOKUP_MSG_SIZE sizeof(struct ShcmsgWithSegment)+160

#define ORIGMSG_ERR_MISSING_SHCLOG_ID   -1
#define ORIGMSG_ERR_ORIGMSG_NOT_FOUND   -2
#endif
