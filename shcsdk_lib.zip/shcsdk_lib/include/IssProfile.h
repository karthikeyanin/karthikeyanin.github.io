#ifndef _ISSPROFILE_H_
#define _ISSPROFILE_H_

static char _IssProfile_h_what[] = "@(#) IssProfile.h 1.19.1.3 18/08/09 03:18:16";

/*
 *  Copyright (C) 2004 eFunds Corporation ("eFunds").  All Rights Reserved.     
 *  eFunds Canada Corporation is an authorized user.                            
 *                                                                              
 *  IST is a registered trademark of eFunds Corporation.  Other brand or        
 *  product names are trademarks or registered trademarks of their respective   
 *  holders.                                                                    
 *                                                                              
 *  The information contained herein is the unpublished proprietary property    
 *  of eFunds.  Except as specifically authorized in writing by eFunds, the     
 *  holder of this document shall: i) keep all information contained herein     
 *  confidential, and ii) protect the information, in whole or in part, from    
 *  disclosure and dissemination to all third parties.                          
 *                                                                          
 *  This document and the software described in it are furnished under license  
 *  and may be used or copied only in accordance with the terms of such license.
 *  This document is supplied for information purposes only, is subject to      
 *  change without notice, and should not be construed as a commitment by       
 *  either eFunds Corporation or eFunds Canada Corporation. 
 *
 *
 *                        MODIFICATION HISTORY                  REVIEW
 *
 * SCR#     Who    Date  		Description
 * ===========================================================================
 * R0xxxxx 
 * R012134 	Emj 	4Oct04 		Issuer Entity Support
 * R027802 	jyang 	25Jan10 	Added "Block by Brand" Support
 * R027759 	EdC		09Feb2010	moved a structure from .cxx to here
 * R029450	las	19May11		make block by brandBlockedObj static
 * R030492	dipa	20Apr12		Remove reference to shcversion.h
 * R032576  Dipa  	06Feb14 	Spring Compliance 2014 - VISA - Req:11.1.1
 */
 

#include <ShcSdkCommon.h>
#include <mt_extbin.h>
#include <multi_institution.h>
#include <ShcHelperBase.h>
#include <BrandBlocked.h>
#include <LCRHelper.h>
#include <TieBreaker.h>


// R027759
// Moved from the .cxx file 
#define MAX_RESULT			100
struct profilesList
{
	struct IssuerProfile *p;
	struct shcextbin *e;
	struct shcpkg *pkg;
};

int shc_isdown(struct shcpkg *bp);

struct routingpkg
{
        bin_t bin; //routing bin
        int id; //routing inst id
        int flags;
		bin_t issuer;	//for which issuer the routing bin is set
};

extern struct routingpkg routingRecord;

class IssProfile : public ShcHelperBase
{
public:
	
    const char *getName()
    {
        return (const char *)SHC_IssProfile;
    }

	virtual int locate_extbin(	const char *txnSrc, const char *pan, const int msgType, 
						const int merchantType, const long pcode, const int hasPIN, 
						IssuerInfo &issuerInfo, ShcmsgHeader *header=NULL);
	virtual int locate_extbin(	const char *txnSrc, const char *pan, const int msgType, 
						const char *deviceType, const long pcode, const int hasPIN, 
						IssuerInfo &issuerInfo, ShcmsgHeader *header=NULL);
	virtual int locate_issuerByEntityId( const char *txnSrc, const int msgType, 
						int merchantType, const long pcode, const int hasPIN, const char *issBin,
						const char *entityId, const char *destination, const char *cardProduct,
						IssuerInfo &issuerInfo);
	int isRegularExp(const char *str);
protected:
	virtual int initialize();
	virtual int extbin_compare(const char *pan, const char *low, const char *high, int size);
	virtual void search_extbin(const char *pan, ExtBinResult &searchResult);
	virtual int MatchTxnSrc(const struct IssuerProfile &ip, const char *txnSrc);
	virtual int	MatchMsgContents(const struct IssuerProfile &ip, const char *msgType, 
					const char *deviceType, const char *pcode, const char hasPIN);
	virtual int	MatchCardInfo(const struct IssuerProfile &ip, const char *txnDest, 
					          const char *entityId,  const char *cardProduct);

	static int initialized;
	static struct IssuerProfile *issuerProfileData;
	static struct shcextbin *shcExtBinData;
	static struct shcextbinGroupHeader *shcextbinGroupData;
	static struct rules_keytab    	*issuerRuleKeyp;
	static struct rules_keytab	   	*shcExtBinRuleKeyp;
	static int issuerProfileAppid;

	static int shcExtBinAppid;

	// USP-1412
	// Note that outside of SHC, this may not be populated
	// so care should be taken before using this
	ShcmsgHeader*	pHdr;

	static BrandBlocked *brandBlockedObj;
	struct profilesList profileResult[MAX_RESULT];
public:
	virtual int isBrandBlocked( char *src, char *dest,  char *product, int msgtype ) const;
	virtual int setBlockedBin( IssuerInfo &issuerInfo );
	virtual int validate_PANLen(char* pan, int ix);						// R027759
	virtual int filterout_shortBIN(ExtBinResult &searchResult, int ix);	// R027759
	int setIssRuleParam();
	int setExtRuleParam();

	//R032576 >>>
	char* getExtBin_networkconfig()
	{
		if (profileResult[0].e)
			return (profileResult[0].e->network_config);
		else
			return NULL;
	}
	//R032576 <<<
	//Added for Fall 2018 -Article 3.1
	 char* getExtBin_file_version()
	 {
		 if (profileResult[0].e)
			 return (profileResult[0].e->file_version);
		 else
			 return NULL;
	 }

};

extern char _onlyForDestination[10+1];
extern char _issProfile_locate_extbin_gatewayId[50+1];
extern char _issProfile_locate_extbin_gatewayId_used[2+1];

#endif

