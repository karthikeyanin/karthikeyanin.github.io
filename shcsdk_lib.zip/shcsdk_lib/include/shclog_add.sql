/*
 *  Copyright (C) 2004 eFunds Corporation ("eFunds").  All Rights Reserved.     
 *  eFunds Canada Corporation is an authorized user.                            
 *                                                                              
 *  IST is a registered trademark of eFunds Corporation.  Other brand or        
 *  product names are trademarks or registered trademarks of their respective   
 *  holders.                                                                    
 *                                                                              
 *  The information contained herein is the unpublished proprietary property    
 *  of eFunds.  Except as specifically authorized in writing by eFunds, the     
 *  holder of this document shall: i) keep all information contained herein     
 *  confidential, and ii) protect the information, in whole or in part, from    
 *  disclosure and dissemination to all third parties.                          
 *                                                                          
 *  This document and the software described in it are furnished under license  
 *  and may be used or copied only in accordance with the terms of such license.
 *  This document is supplied for information purposes only, is subject to      
 *  change without notice, and should not be construed as a commitment by       
 *  either eFunds Corporation or eFunds Canada Corporation. 
 *                    
 *  #pragma ident "@(#) shclog_add.sql 1.5.1.1 16/10/21 10:12:19"
 */
 
/*
* Modification History
*
* 			Who	When	Why
* ========================================================================
* 			mm	31Aug01	File creation.
* R006621	hsh	31Aug01	Add file to shc_lib package
* R007461	hsh	13Feb02	Update table fields as required by new POS subsystem
* R008003 jyang 26Jun02 Restructure index and other fields for new POS
*/

create table shclog_add (
	shclog_idx			char(20) not null,	/* index key - R008003 */
	industry_data_ind	number(2),	/* R008003 */
	comm_crd_data_ind	char(1),	/* R008003 */
	req_payment_srv		number(2),
	product_cd			char(6),	/* changed from number(2) - R008003 */
	valid_cd			char(4),	/* R008003 */
	req_aci				char(1),	/* R008003 */
	resp_aci			char(1),	/* R008003 */
	start_date			date,
	end_date			date,
	day_rate			money,
	no_show_ind			char(1),
	extra_charges		char(6),
	market_spec_req		char(1),
	market_spec_resp	char(1),
	first_auth_amt		money,
	duration			number(2),
	purch_id			char(25),	/* R008003 */
	prest_prop_ind		char(1),
	comm_card_req_ind	char(1),
	comm_card_resp_ind	char(1),
	sales_tax_flag		char(1),
	sales_tax			money,
	purch_order_nr		char(17),
	fleet_type			char(1),
	fleet_id_nr			char(17),
	fleet_restr			char(1),
	ch_auth_entity		char(1),
	reimbursement_attr	char(1),
	discount_amt		money,
	freight_amt			money,
	duty_amt			money,
	dest_zip_cd			char(20),
	site_id			smallint,
	msgtype			int
)

create unique index pkshclog_add on shclog_add( shclog_idx, site_id, msgtype )	/* R008003 */

GG_PARAM shclog_add
(
);

