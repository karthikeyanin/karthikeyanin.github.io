#ifndef _SHCTIMERHELPER_H_
#define _SHCTIMERHELPER_H_

static char _ShctimerHelper_h_what[] = "@(#) ShcTimerHelper.h 1.3.2.1 16/10/21 10:08:37";

/*
 *  Copyright (C) 2004 eFunds Corporation ("eFunds").  All Rights Reserved.
 *  eFunds Canada Corporation is an authorized user.
 *
 *  IST is a registered trademark of eFunds Corporation.  Other brand or
 *  product names are trademarks or registered trademarks of their respective
 *  holders.
 *
 *  The information contained herein is the unpublished proprietary property
 *  of eFunds.  Except as specifically authorized in writing by eFunds, the
 *  holder of this document shall: i) keep all information contained herein
 *  confidential, and ii) protect the information, in whole or in part, from
 *  disclosure and dissemination to all third parties.
 *
 *  This document and the software described in it are furnished under license
 *  and may be used or copied only in accordance with the terms of such license.
 *  This document is supplied for information purposes only, is subject to
 *  change without notice, and should not be construed as a commitment by
 *  either eFunds Corporation or eFunds Canada Corporation.
 *
 *                        MODIFICATION HISTORY                  REVIEW
 *
 * SCR#     Who    Date  Description
 * ===========================================================================
 * R0xxxxx ztang 05Nov03 Creation
 */
 

#include <shcextbuf.h>
#include <ShcSdkCommon.h>
#include <ShcmsgHeader.h>
#include <Shc300Header.h>
#include <ShcHelperBase.h>

class ShcTimerHelper : public ShcHelperBase
{
public:
    const char *getName()
    {
        return (const char *)SHC_ShcTimerHelper;
    }

	virtual int shc_set_timers(ShcHeader *header);
	virtual int shc_time_message(ShcmsgHeader *header);
	virtual int shc_locate_event(register ShcmsgHeader *header);
	virtual int shc_locate_event(register ShcmsgHeader *header, struct shcmsg *omsg);
	virtual int shc_time_message_x( ShcmsgHeader *header, unsigned char *seg );
	virtual int shc_locate_event_x(ShcmsgHeader *header, struct shcmsg *omsg, unsigned char *seg );
	
};

#endif

