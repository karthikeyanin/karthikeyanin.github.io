#ifndef _EXCEPTIONOBJECT_H_
#define _EXCEPTIONOBJECT_H_
/*****************************************************************************/
static char _ExceptionObject_h_what[] = "@(#) ExceptionObject.h 1.1 04/12/15 15:17:54";
/*
 *  Copyright (C) 2004 eFunds Corporation ("eFunds").  All Rights Reserved.     
 *  eFunds Canada Corporation is an authorized user.                            
 *                                                                              
 *  IST is a registered trademark of eFunds Corporation.  Other brand or        
 *  product names are trademarks or registered trademarks of their respective   
 *  holders.                                                                    
 *                                                                              
 *  The information contained herein is the unpublished proprietary property    
 *  of eFunds.  Except as specifically authorized in writing by eFunds, the     
 *  holder of this document shall: i) keep all information contained herein     
 *  confidential, and ii) protect the information, in whole or in part, from    
 *  disclosure and dissemination to all third parties.                          
 *                                                                          
 *  This document and the software described in it are furnished under license  
 *  and may be used or copied only in accordance with the terms of such license.
 *  This document is supplied for information purposes only, is subject to      
 *  change without notice, and should not be construed as a commitment by       
 *  either eFunds Corporation or eFunds Canada Corporation. 
 *
 *
 *                        MODIFICATION HISTORY                  REVIEW
 *
 * SCR#     Who    Date  Description
 * ===========================================================================
 * Created Dec2004
 */

#include <stdio.h>
#include <ist_otrace.h>

class ExceptionObject
{
protected:
	typedef enum {
		EXCPTN_NONE    = 0x0000 ,
		EXCPTN_FATAL   = 0x0001 ,
		EXCPTN_ERROR   = 0x0002 ,
		EXCPTN_IGNORE  = 0x0004 ,
		EXCPTN_ABORT   = 0x0008 ,
		EXCPTN_RETRY   = 0x0010 , 
		MAX_ERRMSG_LEN = 1024
	} ExceptionType;

	ExceptionType exceptionLevel;
	char message[MAX_ERRMSG_LEN+1];
	
public:
	ExceptionObject() {
				exceptionLevel = EXCPTN_NONE;
				memset(message, 0, sizeof(message)); 
			}
	ExceptionObject(const char *s ) {
				exceptionLevel = EXCPTN_NONE;
				strncpy(message, s, MAX_ERRMSG_LEN); 
			}
	virtual ~ExceptionObject() {};
	
	virtual const char* getErrMsg() const { return message; }
	virtual void logMsg() { OTraceInfo( "(W): %s\n", message ); }
};


class ExceptionFatal : public ExceptionObject
{
public:
	ExceptionFatal() { exceptionLevel = EXCPTN_FATAL; }
	ExceptionFatal(const char *s) {
		exceptionLevel = EXCPTN_FATAL;
		strncpy(message, s, MAX_ERRMSG_LEN); 
		OTraceFatal("(F): %s\n", message); 
	}
};

class ExceptionError : public ExceptionObject
{
public:
	ExceptionError() { exceptionLevel=EXCPTN_ERROR; }
	ExceptionError(const char *s) {
		exceptionLevel=EXCPTN_ERROR;
		strncpy(message, s, MAX_ERRMSG_LEN); 
		OTraceError("(E): %s\n", message); 
	}
};

class ExceptionIgnore : public ExceptionObject
{
public:
	ExceptionIgnore() { exceptionLevel=EXCPTN_IGNORE; }
	ExceptionIgnore(const char *s) {
		exceptionLevel=EXCPTN_IGNORE;
		strncpy(message, s, MAX_ERRMSG_LEN); 
		OTraceWarning("(W): %s\n", message); 
	}
};

class ExceptionAbort : public ExceptionObject
{
public:
	ExceptionAbort() { exceptionLevel= EXCPTN_ABORT;}
	ExceptionAbort(const char *s) {
		exceptionLevel=EXCPTN_ABORT;
		strncpy(message, s, MAX_ERRMSG_LEN); 
		OTraceWarning("(A): %s\n", message); 
	}

};

class ExceptionRetry : public ExceptionObject
{
public:
	ExceptionRetry() { exceptionLevel=EXCPTN_RETRY;}
	ExceptionRetry(const char *s) {
		exceptionLevel=EXCPTN_RETRY;
		strncpy(message, s, MAX_ERRMSG_LEN); 
		OTraceWarning("(R): %s\n", message); 
	}
};

#endif
