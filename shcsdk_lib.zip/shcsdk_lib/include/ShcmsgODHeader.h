/*
 *  Copyright (C) 2004 eFunds Corporation ("eFunds").  All Rights Reserved.
 *  eFunds Canada Corporation is an authorized user.
 *
 *  IST is a registered trademark of eFunds Corporation.  Other brand or
 *  product names are trademarks or registered trademarks of their respective
 *  holders.
 *
 *  The information contained herein is the unpublished proprietary property
 *  of eFunds.  Except as specifically authorized in writing by eFunds, the
 *  holder of this document shall: i) keep all information contained herein
 *  confidential, and ii) protect the information, in whole or in part, from
 *  disclosure and dissemination to all third parties.
 *
 *  This document and the software described in it are furnished under license
 *  and may be used or copied only in accordance with the terms of such license.
 *  This document is supplied for information purposes only, is subject to
 *  change without notice, and should not be construed as a commitment by
 *  either eFunds Corporation or eFunds Canada Corporation.
 *
 *                        MODIFICATION HISTORY                  REVIEW
 *
 * SCR#     Who    Date  Description
 * ===========================================================================
 * R000000 ztang 26Jul17 New file created
 */

#ifndef _SHCMSGODHEADER_H_
#define _SHCMSGODHEADER_H_

static char _ShcmsgODHeader_h_what[] = "@(#) @(#) ShcmsgODHeader.h 1.2 20/07/08 00:37:10";

#include <ShcHeader.h>
#include <shc.h>
#include <ShcmsgHeader.h>


struct s_ODDecision
{
	int msgtype;	//must be 8610
	char logId[20+1];	//Same logid as in 8600 request
	int	eventId;		//Same id sent in the 8600 request
	char OnDotVector[40];	
	char DE39[4];	//response from On Dot, 0 means pass
};


class ShcmsgODHeader : public ShcmsgHeader
{
	friend class ShcHeaderFactory;

protected:
	ShcmsgODHeader(struct s_ODDecision* _ODMsg)
	{
		memcpy(&ODMsg, _ODMsg, sizeof(ODMsg));
	}

public:

	const char *getName()
	{
		return (char *)SHC_ShcmsgODHeader;
	}

	struct s_ODDecision *getDecision()
	{
		return &ODMsg;
	}
	struct s_ODDecision ODMsg;
};

#endif
