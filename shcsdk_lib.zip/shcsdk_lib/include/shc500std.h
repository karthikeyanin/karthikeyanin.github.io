#ifndef DSWITCH
#define DSWITCH
#endif

#ifndef SHC500STD_INCLUDE
#define SHC500STD_INCLUDE
static char _shc500std_h_what[] = "@(#) shc500std.h 1.4 06/12/07 11:37:13";

/*
 *	IST and IST/Share are registered trademarks of Oasis Technology Ltd.
 *
 *	Copyright (C) 1990 - 2003 Oasis Technology Ltd. 
 *	All Rights Reserved
 *	This Module contains Proprietary Information of
 *	Oasis Technology Ltd., and should be treated as Confidential.
 *
 *	THIS IS UNPUBLISHED PROPRIETARY SOURCE CODE OF OASIS TECHNOLOGY LTD.
 *	The copyright notice above does not evidence any  
 *	actual or intended publication of such source code.
 *
 *
 *                        MODIFICATION HISTORY                  REVIEW
 *
 *	SPR#	Who	Date	Description			Who	Date   
 * ===========================================================================
 * XXXXXXXX la  24jul96 Added definition for 5xx message types.
 * XXXXXXXX jt	24oct96 Use database definition for std500 i/o shc500stddb.
 *
 *	ad		08jan92		Added auth_amt and auth_amt_rev fields to message
 *						and database
 * R007062 gbeeng 04Dec01 Removed function prototype for local functions of
 *							shc_util.
 * R009697 rzhou  02May03 Added a new flag to indicate no fees include in amt_netset field
 * R012134 Emj   12Oct04  Issuer Entity Support
 */

#if !defined( SHCDLLEXPORT )
#   if defined( WIN32 )
#       define SHCDLLEXPORT __declspec(dllimport)
#   else
#       define SHCDLLEXPORT
#   endif
#endif
/* R005156 */
#ifdef __cplusplus
extern "C" {
#endif
/* R005156 */


#define SHC500STD_MAILBOX		"StdSettlement"
#define SHC500STD_RULENAME		"settlement-tables"

#define SHC500STD_NUM_OF_DAYS_TO_STORE		3
#define SHC500STD_YESTERDAY					0
#define SHC500STD_TODAY						1
#define SHC500STD_TOMMOROW					2


#define	SHC_NETWORK_DATA_LEN	30


/*	Types of messages we support:	anything else is a on-line request */
#define SHC500_MSG_INQUIRE					1500
#define SHC500_MSG_DAYEND					1501
#define SHC500_MSG_TRANSACTION				1502
#define SHC500_MSG_UPDATE_DB				1503




/*	Flags:		key.flags: on all entries */
#define SHC500_INUSE						0x00000001
#define SHC500_NEEDS_UPDATE					0x00000002


/*	Values for shc500std.flags */
#define SHC500_TXN_REVERSAL					0x00000001
#define SHC500_TOTAL_AMT_NO_FEES			0x00000004 /* R009697 */

/*	24oct96 jt */
#include <std500.h>
#define shc500stddb std500


struct	shc500std {
	/*	Standard 500 message (ISO & X9.2) */
	
	/*	this MUST be the first field: To match with the shcmsg structure */
	int		msgtype;
	
	int			index;			/*	internal pointer used by shc500std.c */

	long		trace;
	date_t		trandate;
	long		trantime;
	long		flags;
	int			unit;			/*	required on return trip by formatter */

	date_t		settlement_date;

	bin_t		forward_inst;
	bin_t		issuer;
	bin_t		acquirer;
	bin_t		settlement_agent;

	short		currency_code;
	long		advice_reason;
	long		respcode;
	long		serial_number;

	char		network_data[SHC_NETWORK_DATA_LEN + 1];

	long		num_credit;
	long		num_credit_rev;

	long		num_debit;
	long		num_debit_rev;

	long		num_transfer;
	long		num_transfer_rev;

	long		num_inquiry;

	long		num_auth;
	long		num_auth_rev;

	/*	fees */
	amount_t	fee_cr_processing;
	amount_t	fee_cr_transaction;
	amount_t	fee_db_processing;
	amount_t	fee_db_transaction;


	/*	amounts */
	amount_t	amt_credit;
	amount_t	amt_credit_rev;
	amount_t	amt_debit;
	amount_t	amt_debit_rev;
	amount_t	amt_auth;
	amount_t	amt_auth_rev;


	amount_t	amt_netset;

	bin_t		institution_id;
    char        entityId[30+1];	
	char        shclog_id[21];
};

/*
 *	Structures for the rule database
 */
struct	shc500std_key {
	bin_t		issuer;				/*	settlement for this bin */
	int			textid;				/*	where the text starts */
	int			flags;				/*	flags on this entry */
};

struct	shc500std_text {
	int			flags;				/*	flags on this entry */
	struct	shc500std	msg;		/*	settlement information */
};




/*
 *	Database access
 */

/*	24oct96 jt
	Use the database definition instead of hardcoding here.

struct shc500stddb {
long		msgtype;
long		trace;
long		trandate;
long		trantime;
long		flags;
long		settlement_date;
char		forward_inst[11];
char		issuer[11];
char		acquirer[11];
char		settlement_agent[11];
short		currency_code;
long		advice_reason;
long		respcode;
long		serial_number;
char		network_data[31];
long		num_credit;
long		num_credit_rev;
long		num_debit;
long		num_debit_rev;
long		num_transfer;
long		num_transfer_rev;
long		num_inquiry;
long		num_auth;
long		num_auth_rev;
dec_t		fee_cr_processing;
dec_t		fee_cr_transaction;
dec_t		fee_db_processing;
dec_t		fee_db_transaction;
dec_t		amt_credit;
dec_t		amt_credit_rev;
dec_t		amt_debit;
dec_t		amt_debit_rev;
dec_t		amt_auth;
dec_t		amt_auth_rev;
dec_t		amt_netset;
};

*/

/*
SHCDLLEXPORT extern	struct	shc500std_key	*shc500StdKey;
SHCDLLEXPORT extern	struct	shc500std_text	*shc500StdText;
SHCDLLEXPORT extern	struct	rules_keytab	*shc500StdRuleKeyp;
SHCDLLEXPORT extern	int						shc500StdAppid;
SHCDLLEXPORT extern	bin_t					shc500SwitchId;

#define	shc500StdNumKeys		shc500StdRuleKeyp->keysused
#define shc500StdNumText		shc500StdRuleKeyp->textused
#define shc500StdMaxKeys		shc500StdRuleKeyp->nkeys
*/
#define shc500MarkEntryChanged(k)		((k)->flags |= SHC500_NEEDS_UPDATE)
#define shc500MarkEntryClean(k)			((k)->flags &= ~SHC500_NEEDS_UPDATE)
#define shc500EntryIsChanged(k)			((k)->flags & SHC500_NEEDS_UPDATE)

struct	shc500std				*shc500FindEntry();

#define shcIs5xx(m)							((m / 100) == 5)	/* XXXXXXXX */

/*SHCDLLEXPORT extern int shc500InstantDBUpdate( struct shc500std *msg );*/
/* R005156 */
#ifdef __cplusplus
}
#endif
/* R005156 */

#endif
