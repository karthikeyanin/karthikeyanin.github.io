/*
 * Copyright (C) 2004 eFunds Corporation ("eFunds").  All Rights Reserved.
 * eFunds Canada Corporation is an authorized user.
 *
 * IST is a registered trademark of eFunds Corporation.  Other brand or
 * product names are trademarks or registered trademarks of their respective
 * holders.
 *
 * The information contained herein is the unpublished proprietary property
 * of eFunds.  Except as specifically authorized in writing by eFunds, the
 * holder of this document shall: i) keep all information contained herein
 * confidential, and ii) protect the information, in whole or in part, from
 * disclosure and dissemination to all third parties.
 *
 * This document and the software described in it are furnished under license
 * and may be used or copied only in accordance with the terms of such license.
 * This document is supplied for information purposes only, is subject to
 * change without notice, and should not be construed as a commitment by
 * either eFunds Corporation or eFunds Canada Corporation.
 */
/*
 *	IST and IST/Share are registered trademarks of Oasis Technology Ltd.
 *
 *	Copyright (C) 1990 - 1996 Oasis Technology Ltd.
 *	All Rights Reserved
 *	This Module contains Proprietary Information of
 *	Oasis Technology Ltd., and should be treated as Confidential.
 *
 *	THIS IS UNPUBLISHED PROPRIETARY SOURCE CODE OF OASIS TECHNOLOGY LTD.
 *	The copyright notice above does not evidence any
 *	actual or intended publication of such source code.
 */

// "@(#)shc300lib.h 1.5 14/12/03 03:00:37"


#ifndef __shc3xx_h__
#define __shc3xx_h__



#include <shcerror.h>
#include <shc300.h>
#include <ist_seg_list.h>
#include <ist_seg_shc300_req.h>
#include <ShcAppBase.h>
#include <ShcHelper.h>

//  >>> Shifted struct from gui pkg to shcsdk 
struct  shc300fileupdt {
    char    txn_id[256];            /* Created by New Tmap */
    int     msgtype;
    char    pan[SHC_PAN_LEN + 1];
    date_t  trandate;
    long    trantime;
    long    trace;
    char    refnum[SHC_REFNUM_LEN+1];
    int     respcode;
    char    DateAction[7];
    char    member_id[11+1];
    int     nFileUpdateCode;
    char    OperatorId[3];
    char    strFileName[18];
    char    ActionCode[3];
    char    RegionCoding[10];
    char    Postalcd[10];
    char    Addrvv[6];
    char    Pinverdata[23];
    bin_t   receiveBin;
    bin_t   txnSrc;
    int     Statecd;
    char    StatecdIdent[2];
};

extern struct shc300fileupdt shc3xxmsg;

//  <<< R027479


class SHC300 : public ShcHelperBase
{
public:
	const char *getName()
	{
		return (const char *)SHC_Shc300;
    }

	~SHC300(){};
	int setShc300Route(ShcmsgHeader *header);
	int shc3xxSegmentData(ShcmsgHeader *header,struct shc300fileupdt *shc3xxmsg );

private:
	long flags;

};


#endif

