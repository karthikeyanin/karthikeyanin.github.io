#ifndef _QUEUE_H
#define _QUEUE_H

static char _Queue_h_what[] = "@(#) Queue.h 1.3 05/01/12 19:38:40";

/*
 *  Copyright (C) 2004 eFunds Corporation ("eFunds").  All Rights Reserved.     
 *  eFunds Canada Corporation is an authorized user.                            
 *                                                                              
 *  IST is a registered trademark of eFunds Corporation.  Other brand or        
 *  product names are trademarks or registered trademarks of their respective   
 *  holders.                                                                    
 *                                                                              
 *  The information contained herein is the unpublished proprietary property    
 *  of eFunds.  Except as specifically authorized in writing by eFunds, the     
 *  holder of this document shall: i) keep all information contained herein     
 *  confidential, and ii) protect the information, in whole or in part, from    
 *  disclosure and dissemination to all third parties.                          
 *                                                                          
 *  This document and the software described in it are furnished under license  
 *  and may be used or copied only in accordance with the terms of such license.
 *  This document is supplied for information purposes only, is subject to      
 *  change without notice, and should not be construed as a commitment by       
 *  either eFunds Corporation or eFunds Canada Corporation. 
 *
 *
 *                        MODIFICATION HISTORY                  REVIEW
 *
 * SCR#     Who    Date  Description
 * ===========================================================================
 * R0xxxxx jyang 17Oct03 Created
 */


/*****************************************************************************/

#include <stdio.h>

template <class T> class QueueItem;
template <class T> class Queue;

template <class T> class Queue
{
protected:
	QueueItem<T>* _pFront;
public:
	Queue() : _pFront(0) {};
	Queue(const Queue<T>& other);
	~Queue();
	Queue& operator = (const Queue<T>& q);
	T front() const { return ( _pFront ? _pFront->_item : 0 ); }
	int getSize() const;
	void join(T item);
	void remove();
	void removeAll();
	bool isEmpty() const;
};

template <class T>class QueueItem
{
	friend class Queue<T>;
protected:
	QueueItem(T item) : _item(item), _pNext(0) {};
	T _item;
	QueueItem<T> *_pNext;
public:
	QueueItem <T> *next() { return _pNext; }
	T item() { return _item; }
};

/*****************************************************************************/

template <class T>Queue<T>::Queue(const Queue<T>& q)
{
	if( q.isEmpty() )
		_pFront=0;
	else
	{
		QueueItem<T> *pf = q._pFront;
		QueueItem<T> *pn = new QueueItem<T>(pf->_item);
		_pFront=pn;
		while(pf->_pNext!=0)
		{
			pf=pf->_pNext;
			pn->_pNext=new QueueItem<T>(pf->_item);
			pn=pn->_pNext;
		}
	}
}

template <class T> Queue<T>& Queue<T>::operator = (const Queue<T>& q)
{
	if(this != &q)
	{
		removeAll();
		if(q.isEmpty())
			_pFront=0;
		else{
			QueueItem<T> *pf=q._pFront;
			QueueItem<T> *pn=new QueueItem<T>(pf->_item);
			_pFront=pn;
			while(pf->_pNext!=0)
			{
				pf=pf->_pNext;
				pn->_pNext=new QueueItem<T>(pf->_item);
				pn=pn->_pNext;
			}
		}
	}
	return *this;
}
		
template <class T>Queue<T>::~Queue()
{
	removeAll();
}
				                                                                                                                 
template <class T> void Queue<T>::join(T item)
{
	if(isEmpty())
		_pFront=new QueueItem<T>(item);
	else
	{
		QueueItem<T>* pf = _pFront;
		while(pf->_pNext!=0)
			pf=pf->_pNext;
		pf->_pNext=new QueueItem<T>(item);
	}
}

template <class T> int Queue<T>::getSize() const
{
	QueueItem<T> *pf=_pFront;
	int i=0;
	while(pf!=0)
	{
		pf=pf->_pNext;
		i++;
	}
	return i;
}
	
template <class T> void Queue<T>::remove()
{
	if( _pFront )
	{
		QueueItem<T> * pCurr=_pFront;
		_pFront=pCurr->_pNext;
		delete pCurr;
	}
}

template <class T> void Queue<T>::removeAll()
{
	while ( _pFront )
		remove();
}

template <class T>bool Queue<T>::isEmpty() const
{
	return (_pFront==0);
}

#endif
