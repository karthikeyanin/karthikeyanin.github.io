#ifndef _COMMON_H_
#define _COMMON_H_

static char _Common_h_what[] = "@(#) ShcSdkCommon.h 1.1.1.1 10/08/10 16:07:20";
/*
 *  Copyright (C) 2004 eFunds Corporation ("eFunds").  All Rights Reserved.     
 *  eFunds Canada Corporation is an authorized user.                            
 *                                                                              
 *  IST is a registered trademark of eFunds Corporation.  Other brand or        
 *  product names are trademarks or registered trademarks of their respective   
 *  holders.                                                                    
 *                                                                              
 *  The information contained herein is the unpublished proprietary property    
 *  of eFunds.  Except as specifically authorized in writing by eFunds, the     
 *  holder of this document shall: i) keep all information contained herein     
 *  confidential, and ii) protect the information, in whole or in part, from    
 *  disclosure and dissemination to all third parties.                          
 *                                                                          
 *  This document and the software described in it are furnished under license  
 *  and may be used or copied only in accordance with the terms of such license.
 *  This document is supplied for information purposes only, is subject to      
 *  change without notice, and should not be construed as a commitment by       
 *  either eFunds Corporation or eFunds Canada Corporation. 
 *
 *
 *                        MODIFICATION HISTORY                  REVIEW
 *
 * SCR#     Who    Date  Description
 * ===========================================================================
 * R0xxxxx 
 */
 
#include <shc.h>
#include <shcextbuf.h>
#include <shcmsgdef.h>
#include <shc300.h>
#include <shc500std.h>
#include <ist_otrace.h>


//ShcHeader::logFlag definitions
#define SHC_LOG_REQ 			0x00000001
#define SHC_LOG_UPD_REQ 		0x00000002
#define SHC_LOG_LATE_RESP		0x00000004
#define SHC_LOG_UPD_ORIG		0x00000008
#define SHC_LOG_REPEAT			0x00000010
#define SHC_LOG_TXN_SPECIFIC	0x00000020
#define SHC_LOG_SKIP_LOCATE_ORIG	0x00000040	// 
#define SHC_LOG_ORIG 			0x00000080
#define SHC_LOG_UPD_GENLOG            0x00000100

//ShcHeader::flag definitions
#define MSG_CREATED_INTERNAL 0X00000001

#define SHC_Shc300Header		"Shc300Header"


//#include <tmp_ShcOthers.h>
#endif

