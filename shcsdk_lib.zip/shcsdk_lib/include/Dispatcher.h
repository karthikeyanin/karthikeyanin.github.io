#ifndef _DISPATCHER_H_
#define _DISPATCHER_H_

static char _Dispatcher_h_what[] = "@(#) Dispatcher.h 1.3 14/02/26 14:57:24";

/*
 *  Copyright (C) 2004 eFunds Corporation ("eFunds").  All Rights Reserved.     
 *  eFunds Canada Corporation is an authorized user.                            
 *                                                                              
 *  IST is a registered trademark of eFunds Corporation.  Other brand or        
 *  product names are trademarks or registered trademarks of their respective   
 *  holders.                                                                    
 *                                                                              
 *  The information contained herein is the unpublished proprietary property    
 *  of eFunds.  Except as specifically authorized in writing by eFunds, the     
 *  holder of this document shall: i) keep all information contained herein     
 *  confidential, and ii) protect the information, in whole or in part, from    
 *  disclosure and dissemination to all third parties.                          
 *                                                                          
 *  This document and the software described in it are furnished under license  
 *  and may be used or copied only in accordance with the terms of such license.
 *  This document is supplied for information purposes only, is subject to      
 *  change without notice, and should not be construed as a commitment by       
 *  either eFunds Corporation or eFunds Canada Corporation. 
 *                    
 *
 *                        MODIFICATION HISTORY                  REVIEW
 *
 *  SPR#    Who Date    Description         Who Date
 * ===========================================================================
 *
 *
 */

#include <stdio.h>

class Dispatcher
{
public:
	static int BusinessMon(struct shcmsg *msg, int len);
	static int BusinessMon(const char *logId, int msgtype, int respcode, char *txnSrc=NULL, char *acquirer=NULL, char *txnDest=NULL, char *issuer=NULL);
	static int AfterShcLog(struct shcmsg *msg, int len);   //this is the original istnotify point developed by Arun

	static int POS(struct shcmsg *msg, int len); 
	//more can be added as needed
};

#endif
