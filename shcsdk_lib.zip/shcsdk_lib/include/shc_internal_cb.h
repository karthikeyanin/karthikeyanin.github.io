/*
 *  Copyright (C) 2004 eFunds Corporation ("eFunds").  All Rights Reserved.     
 *  eFunds Canada Corporation is an authorized user.                            
 *                                                                              
 *  IST is a registered trademark of eFunds Corporation.  Other brand or        
 *  product names are trademarks or registered trademarks of their respective   
 *  holders.                                                                    
 *                                                                              
 *  The information contained herein is the unpublished proprietary property    
 *  of eFunds.  Except as specifically authorized in writing by eFunds, the     
 *  holder of this document shall: i) keep all information contained herein     
 *  confidential, and ii) protect the information, in whole or in part, from    
 *  disclosure and dissemination to all third parties.                          
 *                                                                          
 *  This document and the software described in it are furnished under license  
 *  and may be used or copied only in accordance with the terms of such license.
 *  This document is supplied for information purposes only, is subject to      
 *  change without notice, and should not be construed as a commitment by       
 *  either eFunds Corporation or eFunds Canada Corporation. 
 *                    
 */
/*
#pragma ident "@(#) shc_internal_cb.h 1.3 08/06/19 11:19:14"
 *
 *                        MODIFICATION HISTORY                       REVIEW
 *
 *	SPR#	Who	Date	Description								Who	Date   
 * =============================================================================
 *  R002797 fguo 30Dec99 SHC Callback
 *  R006136 emj 15Jun01 Changed to use stl headers in foundation
 *  R023659 ram 19Jun08 Callback prototype changed to improve performance
 */

#if !defined( CALLBACKDLLEXPORT )
#   if defined( WIN32 )
#       define CALLBACKDLLEXPORT __declspec(dllimport)
#   else
#       define CALLBACKDLLEXPORT
#   endif
#endif


#ifndef _SHC_INTERNAL_CB_H_
#define _SHC_INTERNAL_CB_H_
#include "shc_callback.h"
#include <stl/vector.h>

// Base Class for Predicate
class CALLBACKDLLEXPORT cbPredicateBase
{
	public:
		virtual ~cbPredicateBase() {};
		virtual bool query (const ShcHeader* shcmsg) = 0; // --- R023659
		virtual ostream& print(ostream& s) const=0;
};

inline ostream& operator << (ostream& s, const cbPredicateBase& b)
{ return b.print(s); }

inline ostream& operator << (ostream& s, const cbPredicateBase* pb)
{ return pb->print(s); }

// Table Entry
class CALLBACKDLLEXPORT cbTblEntry
{
	public:
		cbTblEntry() {};	

		void setName (char* aName) {name = aName;}
		void setProcPoint (char* aPP) {procPoint = aPP; }

		OCString getName () {return name;}
		OCString getProcPoint () {return procPoint; }
		
		void addPredicate (cbPredicateBase* aPredicate) {
			predicateVec.push_back(aPredicate);
		}
		const OCString Match(const ShcHeader *shcmsg, const OCString& ProcessingPoint);	//	---	R023659

	private:
		vector<cbPredicateBase*
#if ! defined(OC_USE_NEW_STL)
				,  __STL_DEFAULT_ALLOCATOR(cbPredicateBase*)
#endif
			> predicateVec;

		OCString procPoint;
		OCString name;
};

class CALLBACKDLLEXPORT shcCallBackLookupTable
{
public:
	// Constructor
	shcCallBackLookupTable() {};

	int	insert(cbTblEntry& anEntry);
	shcCallBack* search(const ShcHeader *shcmsg, 			//  --- R023659
						const OCString& ProcessingPoint);
	static shcCallBackLookupTable* getTable();

private:
	vector<cbTblEntry
#if ! defined(OC_USE_NEW_STL)
			, __STL_DEFAULT_ALLOCATOR(cbTblEntry)
#endif
		>	cbVec;
	static	shcCallBackLookupTable*	_instance;
};

// Maker for the Base Class
class CALLBACKDLLEXPORT PredicateMaker {

	public:
		typedef SCBMap<OCString, PredicateMaker*> MakerMap; 
		PredicateMaker() {};
		static cbPredicateBase* newPredicate (OCString& className, 
											  OCString& val);
		static	MakerMap* getRegistryInstance();

	protected:
		virtual cbPredicateBase* makePredicate(OCString& val) const = 0;
		static	MakerMap* Registry;
};

#endif
