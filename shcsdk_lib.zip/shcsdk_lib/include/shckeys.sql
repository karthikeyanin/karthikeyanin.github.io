/*
 *  Copyright (C) 2004 eFunds Corporation ("eFunds").  All Rights Reserved.     
 *  eFunds Canada Corporation is an authorized user.                            
 *                                                                              
 *  IST is a registered trademark of eFunds Corporation.  Other brand or        
 *  product names are trademarks or registered trademarks of their respective   
 *  holders.                                                                    
 *                                                                              
 *  The information contained herein is the unpublished proprietary property    
 *  of eFunds.  Except as specifically authorized in writing by eFunds, the     
 *  holder of this document shall: i) keep all information contained herein     
 *  confidential, and ii) protect the information, in whole or in part, from    
 *  disclosure and dissemination to all third parties.                          
 *                                                                          
 *  This document and the software described in it are furnished under license  
 *  and may be used or copied only in accordance with the terms of such license.
 *  This document is supplied for information purposes only, is subject to      
 *  change without notice, and should not be construed as a commitment by       
 *  either eFunds Corporation or eFunds Canada Corporation. 
 *                    
 *  #pragma ident "@(#) shckeys.sql 1.4.1.1 16/10/21 10:11:37"
 */
 
/*
 *                        MODIFICATION HISTORY                  REVIEW
 *
 *	SPR#	Who	Date	Description			Who	Date   
 * ===========================================================================
 *              07oct97  Added field for multiple keys support.
 * ACXSYS   qd  17dec97  Added KEK counter for each key
 * R005324  emj 18dec00  Increased key size from 16 to 48 and added key length
 *                       Fields
 * R008844  Emj 14Jan03  Increased key size from 48 to 74 to hold Atalla Key Block
 * R009097  Emj 06Feb03  Added Institutionid and userbinid
 */

/*
	Key descriptor table for institutions
*/

create table shckeys (
	institutionid   varchar(10) not null,
	userbinid   CHAR(10),
	bin			char(10) null,				/*	owner institution */
	keytypes	char(1) null,				/*	types of keys
											B		both
											M		Mac only
											P		Pin only
										*/
	/*
		Key Exchange Key
	*/
	kek			char(160) null,
	kekchk		char(24) null,

	/*
		Pin key stuff
	*/
	acqpinidx	smallint,
	acqpin1		char(160) null,
	acqpin1chk	char(24) null,
	acqpin2		char(160) null,
	acqpin2chk	char(24) null,


	isspinidx	smallint,
	isspin1		char(160) null,
	isspin1chk	char(24) null,
	isspin2		char(160) null,
	isspin2chk	char(24) null,


	/*
		MAC Key stuff
	*/
	acqmacidx	smallint,
	acqmac1		char(160) null,
	acqmac1chk	char(24) null,
	acqmac2		char(160) null,
	acqmac2chk	char(24) null,

	issmacidx	smallint,
	issmac1		char(160) null,
	issmac1chk	char(24) null,
	issmac2		char(160) null,
	issmac2chk	char(24) null,
	flags		char(5) null,
	o_rowid		int,

	/* 7oct97 > */
	/* Additional Fields */
	acqbin		char(10) null,
	issbin		char(10) null,

	acqkek		char(160) null,
	acqkekchk	char(24) null,

	acqpin3		char(160) null,
	acqpin3chk	char(24) null,
	acqmac3		char(160) null,
	acqmac3chk	char(24) null,

	isspin3		char(160) null,
	isspin3chk	char(24) null,
	issmac3		char(160) null,
	issmac3chk	char(24) null,

	/* KME field */
	acqkmeidx	smallint,
	acqkme1		char(160) null,
	acqkme1chk	char(24) null,
	acqkme2		char(160) null,
	acqkme2chk	char(24) null,
	acqkme3		char(160) null,
	acqkme3chk	char(24) null,

	isskmeidx	smallint,
	isskme1		char(160) null,
	isskme1chk	char(24) null,
	isskme2		char(160) null,
	isskme2chk	char(24) null,
	isskme3		char(160) null,
	isskme3chk	char(24) null,

	/* Status */
	acqkekstat		char(1) null,
	acqpin1stat		char(1) null,
	acqmac1stat		char(1) null,
	acqkme1stat		char(1) null,
	acqpin2stat		char(1) null,
	acqmac2stat		char(1) null,
	acqkme2stat		char(1) null,
	acqpin3stat		char(1) null,
	acqmac3stat		char(1) null,
	acqkme3stat		char(1) null,

	isskekstat		char(1) null,
	isspin1stat		char(1) null,
	issmac1stat		char(1) null,
	isskme1stat		char(1) null,
	isspin2stat		char(1) null,
	issmac2stat		char(1) null,
	isskme2stat		char(1) null,
	isspin3stat		char(1) null,
	issmac3stat		char(1) null,
	isskme3stat		char(1) null,

	/* < 7oct97 */

	/*
	 * qd 17dec97 Added KEK counter for each key (ACXSYS)
	 */
	acqkekcnt		char(20) null,

	acqpin1cnt	    char(20) null,
	acqpin2cnt	    char(20) null,
	acqpin3cnt	    char(20) null,

	acqmac1cnt	    char(20) null,
	acqmac2cnt	    char(20) null,
	acqmac3cnt	    char(20) null,

	acqkme1cnt	    char(20) null,
	acqkme2cnt		char(20) null,
	acqkme3cnt		char(20) null,

	isskekcnt		char(20) null,

	isspin1cnt	    char(20) null,
	isspin2cnt	    char(20) null,
	isspin3cnt	    char(20) null,

	issmac1cnt	    char(20) null,
	issmac2cnt	    char(20) null,
	issmac3cnt	    char(20) null,

	isskme1cnt	    char(20) null,
	isskme2cnt		char(20) null,
	isskme3cnt		char(20) null,

/* LS 18jun99 To change system level configuration to bin level*/
        def_class		char(1) null,	
        def_index		char(1) null,
        val_new			char(1) null,
        val_seq			char(1) null,
        val_chk			char(1) null,
        upd_tbl			char(1) null,

/* R005234 new fields for key lengths 16, 32 48 */
	    kek_len         smallint null,
	    isskpe_len      smallint null,
	    isskme_len      smallint null,
	    issmac_len      smallint null,
	    acqkpe_len      smallint null,
	    acqkme_len      smallint null,
	    acqmac_len      smallint null,
	    site_id	    smallint
)

create index shckeys_1 on shckeys (bin)
create unique index shckeys_2 on shckeys (institutionid, userbinid, site_id)
create index shckeys_rid on shckeys (o_rowid)

GG_PARAM shckeys
(
        extract: TABLE @@@schema@@@.shckeys FILTER (@STREQ(@STRUP(@GETENV('TRANSACTION', 'USERNAME')), @@@gui_user@@@) = 1);

);

