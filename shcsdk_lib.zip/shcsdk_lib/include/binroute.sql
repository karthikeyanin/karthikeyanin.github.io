/*
 *  Copyright (C) 2004 eFunds Corporation ("eFunds").  All Rights Reserved.     
 *  eFunds Canada Corporation is an authorized user.                            
 *                                                                              
 *  IST is a registered trademark of eFunds Corporation.  Other brand or        
 *  product names are trademarks or registered trademarks of their respective   
 *  holders.                                                                    
 *                                                                              
 *  The information contained herein is the unpublished proprietary property    
 *  of eFunds.  Except as specifically authorized in writing by eFunds, the     
 *  holder of this document shall: i) keep all information contained herein     
 *  confidential, and ii) protect the information, in whole or in part, from    
 *  disclosure and dissemination to all third parties.                          
 *                                                                          
 *  This document and the software described in it are furnished under license  
 *  and may be used or copied only in accordance with the terms of such license.
 *  This document is supplied for information purposes only, is subject to      
 *  change without notice, and should not be construed as a commitment by       
 *  either eFunds Corporation or eFunds Canada Corporation. 
 */
/*
#pragma ident "@(#) binroute.sql 1.10.1.2 16/10/21 10:06:44";
 *
 *                        MODIFICATION HISTORY                  REVIEW
 *
 *	SPR#	Who		Date	Description			Who	Date   
 * ===========================================================================
 * Rxxxxx ztang 22Feb08 Creation
 */

create table binroute 
(
	institutionid varchar(10) not null,
	userbinid char(10),
	node varchar(30),
	mailbox varchar(30) null,
	port varchar(31) null,
	cfg varchar(31) null, 
	init_status char(1), 	/* Initial status 'D' for down, 'U' for up */
	echo char(1), 				/* Condition to send echo. 'D' only when route down, 'U' only when route up, 'A' always */
	grouptype char(1), 		/* How to choose route at same priority. 'R' for round-robin */
	priority int,					/* Higher priority has smaller number */
	misc	varchar(39),		/* misc. info, for futureuse */
	inst_profile_id int,
	base_port_name varchar(30) null,
	blrnode varchar(30),
	site_id smallint,
	binroute_group varchar(15)
)




/*oasis is owner of index shcbin_ix*/
create UNIQUE index binroute_ix on binroute (institutionid, userbinid, binroute_group, node,  port, site_id)

GG_PARAM binroute
(
);

