/*
 * Copyright (C) 2004 eFunds Corporation ("eFunds").  All Rights Reserved.
 * eFunds Canada Corporation is an authorized user.
 *
 * IST is a registered trademark of eFunds Corporation.  Other brand or
 * product names are trademarks or registered trademarks of their respective
 * holders.
 *
 * The information contained herein is the unpublished proprietary property
 * of eFunds.  Except as specifically authorized in writing by eFunds, the
 * holder of this document shall: i) keep all information contained herein
 * confidential, and ii) protect the information, in whole or in part, from
 * disclosure and dissemination to all third parties.
 *
 * This document and the software described in it are furnished under license
 * and may be used or copied only in accordance with the terms of such license.
 * This document is supplied for information purposes only, is subject to
 * change without notice, and should not be construed as a commitment by
 * either eFunds Corporation or eFunds Canada Corporation.
 */

#ifndef __UPDATE_MEM_HELPER_H_
#define __UPDATE_MEM_HELPER_H_

static char _UpdateMemHelper_h_what[] = "@(#) UpdateMemHelper.h 1.2 11/06/22 18:20:58";

#include <string>

#include <shc.h>

using namespace std ;

#define UPD_MEM_MAX_LEN 		10240


class UpdateMemHelper
{
	protected:
		int shccmdMailboxId;
		int fromMbId;

	public:
		UpdateMemHelper(int fromMailboxId=-1);
		int sendMemUpdate( char *ruleName, const char * ruleData, int ruleDataLen );
};


#endif

