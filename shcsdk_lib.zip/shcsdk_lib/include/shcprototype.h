#ifndef SHCPROTOTYPE_INCLUDE
#define SHCPROTOTYPE_INCLUDE
static char _shcprototype_h_what[] = "@(#) shcprototype.h 1.2 05/08/16 10:35:29";

/*
 *  Copyright (C) 2004 eFunds Corporation ("eFunds").  All Rights Reserved.     
 *  eFunds Canada Corporation is an authorized user.                            
 *                                                                              
 *  IST is a registered trademark of eFunds Corporation.  Other brand or        
 *  product names are trademarks or registered trademarks of their respective   
 *  holders.                                                                    
 *                                                                              
 *  The information contained herein is the unpublished proprietary property    
 *  of eFunds.  Except as specifically authorized in writing by eFunds, the     
 *  holder of this document shall: i) keep all information contained herein     
 *  confidential, and ii) protect the information, in whole or in part, from    
 *  disclosure and dissemination to all third parties.                          
 *                                                                          
 *  This document and the software described in it are furnished under license  
 *  and may be used or copied only in accordance with the terms of such license.
 *  This document is supplied for information purposes only, is subject to      
 *  change without notice, and should not be construed as a commitment by       
 *  either eFunds Corporation or eFunds Canada Corporation. 
 *
 *                        MODIFICATION HISTORY                  REVIEW
 *
 *	SPR#	Who	Date	Description			Who	Date   
 * ===========================================================================
 * ACXSYS   yh  18Dec97 Created for function prototype
 * R000587  la  10jan97 Added argument #4 to shc_keys_xchg()
 *          la  24mar97 Removed PROTOTYPE macro.
 *	R002169	wc  10Apr98	Fix for NT porting
 * R005324  emj 18Dec00 TDES keychange function
 * R007062  gbeeng 04Dec01  Removed function prototype for local function
 *							of shc_util (used in shc_kme.cxx)
 * R007416  emj 12Feb02 Added functions to split issuer application data
 */

/*------------------------------------------------------------------------*
 * Function Prototypes Defined under Share 
 *------------------------------------------------------------------------*/
/*
 * shc_keys.c
 */
/* R000587 */
/* R005156 */
#include <shcextbuf.h>
#ifdef __cplusplus
extern "C" {
#endif
/* R005156 */
SHCDLLEXPORT extern int shc_keys_xchg( struct shckey_buf *, char *, char *, char );
SHCDLLEXPORT extern int shc_keys_xchg_td( struct shckey_buf *, char *, char *, char, int * );
SHCDLLEXPORT extern int shc_keys_xchg_td_xt( struct shckey_buf *, char *, char *, char, int *, int);
SHCDLLEXPORT extern int shc_keys_xchg_td_xt_xt( struct shckey_buf *, char *, char *, char, int *, int, char, int);
/* R000925 > */
SHCDLLEXPORT extern int shckeys_GetPvp( struct shc *,struct shcpkg *, struct shckey_buf * );
SHCDLLEXPORT extern int shckeys_SetPtrs( struct shckey_buf * );
SHCDLLEXPORT extern int shckeys_SetStat( struct shckey_buf *, char );
/* R000925 < */
/*extern int shckeys_ClrKeys( struct shcsecurity * );
*/
SHCDLLEXPORT extern int shckeys_GetKey( struct shckey_buf *, struct shcpkg *, char, char, char );
SHCDLLEXPORT extern int shckeys_Key2Shc( struct shckey_buf *, struct shc * );
SHCDLLEXPORT extern int shckeys_FillMsg( struct shc *, struct shcpkg *, char, char );
SHCDLLEXPORT extern int shckeys_ChangeKey( struct shcpkg *pkgp, char key_class, char type, char idx, char *obin );
/* extern int shckeys_ChangeKey( char *, char, char, char, char * );
*/
SHCDLLEXPORT extern int shckeys_Dbm2Mem( struct shcsecurity * );

/*
 * shc_kme.c
 */
/*SHCDLLEXPORT extern int shc_balance_encryption( struct shc *, char *, char );
SHCDLLEXPORT extern int shc_change_keys(bin_t, char, short);
SHCDLLEXPORT extern int shc_edc_get_workingkey(struct shc *, char, char **);
SHCDLLEXPORT extern int shc_edc_generate_workingkey(struct shc *, char, char **);
SHCDLLEXPORT extern int shc_get_key_parameters(struct shc *, int, char, char,
                                  struct shcsecurity **, char **);
*/
/*
 * misc
 */
SHCDLLEXPORT extern	struct pinverparm		*shc_getpinparm(char *bin);
SHCDLLEXPORT extern	char					*shc_locate_track_data(struct shc *shcmsg);
SHCDLLEXPORT extern	char					*shcmsg_locate_track_data(struct shcmsg *msg);
SHCDLLEXPORT extern time_t shc_adjust_date(long date_in, int ndays);
/* R005156 */

/* R007416 */

SHCDLLEXPORT extern int split_issuer_app_data_vsdc(emv *emvbuf);
SHCDLLEXPORT extern int split_issuer_app_data_mchip(emv *emvbuf);

#ifdef __cplusplus
}
#endif
/* R005156 */

#endif /* For SHCPROTOTYPE_INCLUDE */
/*------------------------------------------------------------------------*
 * End of File shcprototype.h
 *------------------------------------------------------------------------*/


