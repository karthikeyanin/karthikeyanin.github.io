/*
 *  Copyright (C) 2004 eFunds Corporation ("eFunds").  All Rights Reserved.     
 *  eFunds Canada Corporation is an authorized user.                            
 *                                                                              
 *  IST is a registered trademark of eFunds Corporation.  Other brand or        
 *  product names are trademarks or registered trademarks of their respective   
 *  holders.                                                                    
 *                                                                              
 *  The information contained herein is the unpublished proprietary property    
 *  of eFunds.  Except as specifically authorized in writing by eFunds, the     
 *  holder of this document shall: i) keep all information contained herein     
 *  confidential, and ii) protect the information, in whole or in part, from    
 *  disclosure and dissemination to all third parties.                          
 *                                                                          
 *  This document and the software described in it are furnished under license  
 *  and may be used or copied only in accordance with the terms of such license.
 *  This document is supplied for information purposes only, is subject to      
 *  change without notice, and should not be construed as a commitment by       
 *  either eFunds Corporation or eFunds Canada Corporation. 
 *
 *                        MODIFICATION HISTORY                  REVIEW
 *
 * SCR/JIRA Story   Who    Date    Description
 * ===========================================================================
 * R0xxxxx                                                                    
 * IST_SxxxSPyy-zzz xxx: Switch Version; yy: Service Pack Num; zzz: Story Num
 * IST_S770SP12-154 hsh    28Jun18 Created to extend Issuer Profile
 */
#ifndef _ISSPROFILEEXTENDED_H_
#define _ISSPROFILEEXTENDED_H_

static char _IssProfileExtended_h_what[] = "@(#) IssProfileExtended.h 1.1 18/07/06 17:17:53";

#include <ShcSdkCommon.h>
#include <ShcHelperBase.h>
#include <mt_iss_profile.h>
#include <ShcHelperRegistration.h>

#define SHC_IssProfileExtended "IssProfileExtended"
#define SHC_IssProfileExtSegTag "SGMT"

class IssProfileExtended : public ShcHelperBase
{
public:
	//IssProfileExtended() : _issuerProfile(NULL), _shcmsgHeader(NULL) {};
	IssProfileExtended();
	~IssProfileExtended();
	virtual void setShcmsgHeader(ShcmsgHeader *header );
	virtual int MatchMsgAddCondition( const struct IssuerProfile &issProf);
	const char *getName() { return (const char *)SHC_IssProfileExtended; }
protected:
	ShcmsgHeader *_shcmsgHeader;
};

extern IssProfileExtended *issProfileExtObj;
extern ShcHelperRegistration shcHelperRegister;

#endif // _ISSPROFILEEXTENDED_H_

