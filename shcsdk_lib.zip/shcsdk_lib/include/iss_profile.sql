/*
 *  Copyright (C) 2004 eFunds Corporation ("eFunds").  All Rights Reserved.     
 *  eFunds Canada Corporation is an authorized user.                            
 *                                                                              
 *  IST is a registered trademark of eFunds Corporation.  Other brand or        
 *  product names are trademarks or registered trademarks of their respective   
 *  holders.                                                                    
 *                                                                              
 *  The information contained herein is the unpublished proprietary property    
 *  of eFunds.  Except as specifically authorized in writing by eFunds, the     
 *  holder of this document shall: i) keep all information contained herein     
 *  confidential, and ii) protect the information, in whole or in part, from    
 *  disclosure and dissemination to all third parties.                          
 *                                                                          
 *  This document and the software described in it are furnished under license  
 *  and may be used or copied only in accordance with the terms of such license.
 *  This document is supplied for information purposes only, is subject to      
 *  change without notice, and should not be construed as a commitment by       
 *  either eFunds Corporation or eFunds Canada Corporation. 
 *                    
 *  #pragma ident "@(#) iss_profile.sql 1.4.1.3 18/07/06 17:16:09"
 */
/*
 *				Modification History
 *
 *	Who		When		Why
 *	========================================================================
 *R008717 ztang 21Nov02	Created for multi-institution support
 *R012134 Emj   01Oct04 Issuer Entity Support
 *        hsh   27Jun18 IST_S770SP12-154: Support addional selection conditions
 */

create table iss_profile (
	txnsrc			varchar(10) not null,	/* Transaction Source */
	txndest			varchar(10),	/* Transaction Destination */
	entity_id		char(60),		/* Issuer enitity ID */
	cardproduct		char(60),		/* Card Brand, e.g. PLUS, Interac, Cirrus */
	msgtype			char(40),		/* Message Type, e.g. 100, 200 */
	devicetype		char(3),		/* Device Type(merchant type), e.g. 6011, 6012 */
	pcode			char(80),		/* Processing Code, e.g. 010000, 000000 */
	haspin			char(1),		/* Has PIN or not, e.g. Y, N */

	/* Institution ID of the issuer bin. */
	/* References institution id in institution table */
	iss_inst_id		char(10),

	/* User bin id of the bin. iss_inst_id and iss_userbin_id together */
	/* serves as foreign key to shcbin table */
	iss_userbin_id	char(10),

	priority		int,			/* Priority of this entry, the less, the higher*/
	node			varchar(60),	/* Which nodes are allowed to use this entry */
	routing_bin		char(10),
	routing_inst_id	char(10),
	add_condition	varchar(80)		/* IST_S770SP12-154 */
)

create index iss_profile_i on iss_profile (txnsrc)
create unique index iss_profile_uix on iss_profile ( txnsrc, txndest, entity_id , cardproduct , msgtype, devicetype, pcode, haspin, iss_inst_id, iss_userbin_id );

GG_PARAM iss_profile
(
);

