/*
 *  Copyright (C) 2004 eFunds Corporation ("eFunds").  All Rights Reserved.     
 *  eFunds Canada Corporation is an authorized user.                            
 *                                                                              
 *  IST is a registered trademark of eFunds Corporation.  Other brand or        
 *  product names are trademarks or registered trademarks of their respective   
 *  holders.                                                                    
 *                                                                              
 *  The information contained herein is the unpublished proprietary property    
 *  of eFunds.  Except as specifically authorized in writing by eFunds, the     
 *  holder of this document shall: i) keep all information contained herein     
 *  confidential, and ii) protect the information, in whole or in part, from    
 *  disclosure and dissemination to all third parties.                          
 *                                                                          
 *  This document and the software described in it are furnished under license  
 *  and may be used or copied only in accordance with the terms of such license.
 *  This document is supplied for information purposes only, is subject to      
 *  change without notice, and should not be construed as a commitment by       
 *  either eFunds Corporation or eFunds Canada Corporation. 
 */
/*
#pragma ident "@(#) shc300.h 1.3.2.1 16/10/21 10:06:54"
 *
 *                        MODIFICATION HISTORY                  REVIEW
 *
 *	SPR#	Who	Date	Description			Who	Date   
 * ===========================================================================
 * 2002855  la  19mar97 Added copyright header.
 *	ad		25jun93		Created structure shc300priv
 *R008958 ztang 27Jan03 Added txnsrc to shc300 structure
 */

#ifndef DSWITCH
#define DSWITCH
#endif

#ifndef SHC300_INCLUDE
#define SHC300_INCLUDE

/*****************************************************************************
 *	Define server name
 *****************************************************************************/
#define SHC_300_SERVER		"03xxServer"

/*****************************************************************************
 *      Define card status
    *****************************************************************************/
#define SHC300_HOTBLOCK         "01"
#define SHC300_UNBLOCK          "00"
#define SHC300_BLOCK            "02"

/*****************************************************************************
 *	Define the server structure
 *****************************************************************************/
struct shc300 {

	/***	MUST MATCH EXACTLY AS IN 'struct shcmsg' ***/

	int		msgtype;			/*	the message type */
	int		flipped_msgtype;	/*	To which message type the formatters/agents flipped. If no flipping, use 0	*/
	char	pan[SHC_PAN_LEN + 1];	/*	pan of card */
	long	pcode;					/*	processing code */

	/***	END OF MATCH SEQUENCE ***/


	date_t			trandate;
	long			trantime;
	long			trace;
	bin_t			acquirer;
	bin_t			issuer;
	int				respcode;
	int				senderid;
	int				unit;
	unsigned char	formatter_use[SHC_FORMATTER_USE];
	long			serial_1;
	long			serial_2;
	char			refnum[SHC_REFNUM_LEN + 1];
	char			file_security_code[3];
	char			file_name[18];
	double			dummy;
	char			action[256];
	char			txnSrc[MAX_TXN_DESTINATION_LEN+1];
	char			shclog_id[21];
};


struct	shc300fileupd {
	/*	Card Issuer UPDate 
		Redefines the 'action' field

		(Clearly this is closer to Visa -- we await the Mastercard soon)
	*/

	int				updcode;
	char			pan[SHC_PAN_LEN + 1];
	date_t			purge_date;
	char			action[4];
	char			region[20];
	char			special_processing[50];
};


struct	shc300pvv {
	/*
	 *	Redefines 'action' field
	 *
	 *	PVV Update transaciton
	 */
	int				updcode;
	char			pan[SHC_PAN_LEN + 1];
	date_t			purge_date;
	char			algo[4];
	char			security_info[50];	/*	Visa == pin */
};


/*****************************************************************************
 *	Define private 0300 message: Cannot be mapped unto shc
 *****************************************************************************/
struct shc300priv {

	/***	MUST MATCH EXACTLY AS IN 'struct shcmsg' ***/

	int		msgtype;			/*	the message type */

	char	pan[SHC_PAN_LEN + 1];	/*	pan of card */
	long	pcode;					/*	processing code */

	/***	END OF MATCH SEQUENCE ***/


	date_t			trandate;
	long			trantime;
	date_t			local_date;
	long			local_time;
	long			trace;
	bin_t			acquirer;
	bin_t			issuer;
	int				respcode;
	int				senderid;
	int				unit;
	unsigned char	formatter_use[SHC_FORMATTER_USE];
	long			serial_1;
	long			serial_2;
	char			refnum[SHC_REFNUM_LEN + 1];
	char			file_security_code[3];
	char			file_name[18];
	double			dummy;
	char			action[512];
};
#endif
