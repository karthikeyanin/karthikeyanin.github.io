#ifndef _SHCHELPER_H_
#define _SHCHELPER_H_

static char _ShcHelper_h_what[] = "@(#) ShcHelper.h 1.12.1.2 20/02/27 15:21:20";

/*
 *  Copyright (C) 2004 eFunds Corporation ("eFunds").  All Rights Reserved.     
 *  eFunds Canada Corporation is an authorized user.                            
 *                                                                              
 *  IST is a registered trademark of eFunds Corporation.  Other brand or        
 *  product names are trademarks or registered trademarks of their respective   
 *  holders.                                                                    
 *                                                                              
 *  The information contained herein is the unpublished proprietary property    
 *  of eFunds.  Except as specifically authorized in writing by eFunds, the     
 *  holder of this document shall: i) keep all information contained herein     
 *  confidential, and ii) protect the information, in whole or in part, from    
 *  disclosure and dissemination to all third parties.                          
 *                                                                          
 *  This document and the software described in it are furnished under license  
 *  and may be used or copied only in accordance with the terms of such license.
 *  This document is supplied for information purposes only, is subject to      
 *  change without notice, and should not be construed as a commitment by       
 *  either eFunds Corporation or eFunds Canada Corporation. 
 *
 *                        MODIFICATION HISTORY                  REVIEW
 *
 * SCR#     Who    Date  Description
 * ===========================================================================
 * R0xxxxx 
 * R012339  Emj   08Nov04 Emv Buffer Bitmap
 */
 

#include <ShcSdkCommon.h>
#include <ShcBin.h>
#include <IssProfile.h>
#include <AcqProfile.h>
#include <ShcHelperBase.h>


class ShcHelper : public ShcHelperBase
{
public:
    const char *getName()
    {
        return (const char *)SHC_ShcHelper;
    }

	virtual int shc_initparm();
	virtual int shc_setswitchflag(int flag);
	virtual int shc_initsys();
	virtual int shc_init();
	virtual int shc_gentrace();
	virtual int shc_set_cam_stored_results(unsigned char *ARQC, unsigned char *ARPC);
	virtual int shc_get_cam_stored_results(unsigned char *ARQC, unsigned char *ARPC);
	virtual int split_issuer_app_data_mchip(emv *emvbuf);
	virtual int split_issuer_app_data(emv *emvbuf, int version);
	virtual int split_issuer_app_data_vsdc(emv *emvbuf);
	virtual int shc_resptomsg(int respcode, char *msg, size_t msg_size);
	virtual int scan(FILE *fp, int error, char *msg, size_t msg_size);
	virtual int default_msg(int respcode, char *msg, size_t msg_size);
	virtual int shc_getIssuerAcquirerInfo(const char *txnSrc, const char *pan, const int msgType, 
							const int merchantType, const long pcode, const int hasPIN,
							const char *entityId, const int currency, 
							IssuerInfo &issuerInfo, AcquirerInfo &acquirerInfo ,ShcmsgHeader *header);
	virtual int shc_getIssuerAcquirerInfo(const char *txnSrc, const char *pan, const int msgType, 
							const char *deviceType, const long pcode, const int hasPIN,
							const char *entityId, const int currency, 
							IssuerInfo &issuerInfo, AcquirerInfo &acquirerInfo ,ShcmsgHeader *header);
	virtual struct pinverparm *shc_getpinparm(char *bin);
	virtual int shc_normalizenumber(register char *nbp, register char *obp, int len);
	virtual int shc_is_empty_buf(register char *buf, register int len);
	virtual int shc_fmt_balance( char *buf,
				int accttype, int amttype, int currency, amount_t *amount) ;
	virtual long shc_fmtgetdate_from_mmdd( long	mmdd );
	virtual int shc_GetCurrencyRate( int code, bin_t inst_id, struct istcurrency_key *r );
	
	// 20Apr2010
	virtual int shc_getCardSchemeFromCardProduct(char* cdscheme, char* cdprod, size_t cdschemeSize, char* instId=NULL);

	virtual int shc_getInstitutionIdFromCardScheme(char *institutionId, const char *cardScheme);
	virtual int shc_init_formatter(const char *name, int *m_in, int *m_out, int *s_id, int *st_id, int single_formatter);
	virtual void beginCacheMsg();
	virtual void endCacheMsg();
	virtual int cache_mb_write(int dest_id, int src_id, char *msg, int len);
	virtual int flush_mb_cache();
	virtual void reset_mb_cache();
	virtual void setEmvBitMapOn(emv  *emvbuf, shcemvbit field);
	virtual void setEmvBitMapOff(emv  *emvbuf, shcemvbit field);
	virtual int isEmvBitMap (emv  *emvbuf, shcemvbit field);
	virtual char * shc_maskpan(const char *pan);
	int isMC(ShcmsgHeader *header);
	struct pinverparm *shc_getpinparm(int pinparm);
};

#endif

