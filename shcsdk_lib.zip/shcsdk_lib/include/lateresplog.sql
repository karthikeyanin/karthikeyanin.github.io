/*
 *	IST and IST/Share are registered trademarks of Oasis Technology Ltd.
 *
 *	Copyright (C) 1990 - 1997 Oasis Technology Ltd.
 *	All Rights Reserved
 *	This Module contains Proprietary Information of
 *	Oasis Technology Ltd., and should be treated as Confidential.
 *
 *	THIS IS UNPUBLISHED PROPRIETARY SOURCE CODE OF OASIS TECHNOLOGY LTD.
 *	The copyright notice above does not evidence any  
 *	actual or intended publication of such source code.
 */
/*
#pragma ident "@(#) lateresplog.sql 1.7.2.1 16/10/21 10:10:03";
 *
 *				Modification History
 *
 *	Who		When		Why
 *	========================================================================
 * 	mwang		09March04	Create to store the late 0210 message for CUSC
 * 	Dipa 		03Sep09     PADSS Changes
 * 	Dipa 		20Dec13     Change local_date, trandate from datetime to date type
*/

create table lateresplog (
	msgtype			int,	
	pan				pan_token_t(19) null,	
	pcode			int,					
	trace			int,					
	termid			char(8) null,	

	local_time		int,				
	local_date		date,				
	trandate		date,
	trantime		int,
	respcode		int,
	acquirer		char(10) null,
	issuer			char(10) null,
	log_id			varchar(20) not null,
        site_id                 smallint,
	sys_dt_time     	datetime,
	authnum			VARCHAR2(6),
        status    char (1)
)
create index lateresplog_1 on lateresplog (local_date, pan, trace, local_time,
												 termid, pcode)
create unique index lateresplog_uix on lateresplog (log_id,site_id)

GG_PARAM lateresplog
(
);

