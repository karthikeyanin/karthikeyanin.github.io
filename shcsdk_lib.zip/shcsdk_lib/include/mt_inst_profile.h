/*
 *  Copyright (C) 2004 eFunds Corporation ("eFunds").  All Rights Reserved.     
 *  eFunds Canada Corporation is an authorized user.                            
 *                                                                              
 *  IST is a registered trademark of eFunds Corporation.  Other brand or        
 *  product names are trademarks or registered trademarks of their respective   
 *  holders.                                                                    
 *                                                                              
 *  The information contained herein is the unpublished proprietary property    
 *  of eFunds.  Except as specifically authorized in writing by eFunds, the     
 *  holder of this document shall: i) keep all information contained herein     
 *  confidential, and ii) protect the information, in whole or in part, from    
 *  disclosure and dissemination to all third parties.                          
 *                                                                          
 *  This document and the software described in it are furnished under license  
 *  and may be used or copied only in accordance with the terms of such license.
 *  This document is supplied for information purposes only, is subject to      
 *  change without notice, and should not be construed as a commitment by       
 *  either eFunds Corporation or eFunds Canada Corporation. 
 */
/*
#pragma ident "@(#) mt_inst_profile.h 1.4 11/06/14 16:07:28";
 *
 *                        MODIFICATION HISTORY                  REVIEW
 *
 *	SPR#	Who	Date	Description			Who	Date   
 * ===========================================================================
 *R008717 ztang 15Nov02 Created for multi-institution support
 *						Added alternateAcqBin to shc structure
 *R012134 Emj 04Oct04 Issuer Entity Support
 */

#ifndef INST_PROFILE_INCLUDE
#define INST_PROFILE_INCLUDE

#if !defined( SHCDLLEXPORT )
#   if defined( WIN32 )
#       define SHCDLLEXPORT __declspec(dllimport)
#   else
#       define SHCDLLEXPORT
#   endif
#endif


#ifdef PREPROC_MT_LIB

#if defined ( SHCDLLEXPORT )
#   undef     SHCDLLEXPORT
#   define    SHCDLLEXPORT
#endif


#endif

//#include <string.h>
//#include <shc.h>
//#include <mt_iss_profile.h>
//#include <multi_inst_def.h>
//#include <multi_institution.h>
#include <inst_profile.h>


struct InstitutionProfile
{
	char	m_txnSrc[40+1];
	char	m_txnDest[40+1];
	char    m_iss_entityId[30+1];
	char	m_msgType[40+1];
	char	m_externalId[11+1];
	char	m_externalIdDesc[30+1];
	char	m_member_ID[12];
	char	m_F_ID[12];
	bin_t	m_bin;
	int		m_priority;
	int		keyparm;		//<0:no key used for this entry. >=0:the text id into key shared memory
	long    balInfo[20];
	char	status;
	int 	id;
	char    instId[sizeof(((struct inst_profile *)0)->inst_id)];
	char    keyparamStr[sizeof(((struct inst_profile *)0)->keyparam)];
        char    binrouteGroup[sizeof(((struct inst_profile *)0)->binroute_group)];
};

struct InstitutionProfileShm
{
	char	m_txnSrc[40+1];
	char	m_txnDest[40+1];
	char    m_iss_entityId[30+1];
	char	m_msgType[40+1];
	char	m_externalId[11+1];
	char	m_externalIdDesc[30+1];
	char	m_member_ID[12];
	char	m_F_ID[12];
	bin_t	m_bin;
	int		m_priority;
	int		keyparm;		//<0:no key used for this entry. >=0:the text id into key shared memory
	long    balInfo[20];
	char	status;
	int 	id;
	char    instId[sizeof(((struct inst_profile *)0)->inst_id)];
	char    keyparamStr[sizeof(((struct inst_profile *)0)->keyparam)];
	char    binrouteGroup[sizeof(((struct inst_profile *)0)->binroute_group)];
};

#endif
