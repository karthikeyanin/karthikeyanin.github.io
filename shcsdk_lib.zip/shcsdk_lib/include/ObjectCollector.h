#ifndef _OBJECTCOLLECTOR_H_
#define _OBJECTCOLLECTOR_H_

static char _ObjectCollector_h_what[] = "@(#) ObjectCollector.h 1.4 13/12/06 05:55:00";
/*
 *  Copyright (C) 2004 eFunds Corporation ("eFunds").  All Rights Reserved.     
 *  eFunds Canada Corporation is an authorized user.                            
 *                                                                              
 *  IST is a registered trademark of eFunds Corporation.  Other brand or        
 *  product names are trademarks or registered trademarks of their respective   
 *  holders.                                                                    
 *                                                                              
 *  The information contained herein is the unpublished proprietary property    
 *  of eFunds.  Except as specifically authorized in writing by eFunds, the     
 *  holder of this document shall: i) keep all information contained herein     
 *  confidential, and ii) protect the information, in whole or in part, from    
 *  disclosure and dissemination to all third parties.                          
 *                                                                          
 *  This document and the software described in it are furnished under license  
 *  and may be used or copied only in accordance with the terms of such license.
 *  This document is supplied for information purposes only, is subject to      
 *  change without notice, and should not be construed as a commitment by       
 *  either eFunds Corporation or eFunds Canada Corporation. 
 *
 *
 *                        MODIFICATION HISTORY                  REVIEW
 *
 * SCR#     Who    Date  Description
 * ===========================================================================
 * Created Dec2004
 */

#include <oasis.h>
#include <ist_otrace.h>
#include <ist_types.h>
#include <ist_dll.h>
#include <stl/vector.h>
#include <oc/oc_string.h>
#include <ExceptionObject.h>


template <class T> class InstancePool;

template <class T>
class ObjectCollector
{
protected:
	typedef InstancePool<T>  TO;
	vector<TO *>  objectTable;

public:
	ObjectCollector(){};
	virtual ~ObjectCollector();
	
	virtual T    *createInstance(const char *objName, const void *msg) = 0;
	virtual int  reuseInstance( T *instance, const char *objName, const void *msg ) = 0;
	
	virtual int  recycle();
	virtual TO *getInstancePool(const char *objName);
	virtual T *getObject(const char *objName, const void *msg);
};


#define MAX_INSTANCE_NUM 300
template <class T>
class InstancePool
{
public:
	OCString ocObjectName;
	int		 maxUsedInstance;
	int		 lastInstance;
	T *_instance[MAX_INSTANCE_NUM];

public:
	InstancePool(OCString &ocStr);
	virtual ~InstancePool();
	
	virtual T **getInstance();
	virtual int  recycle();
	virtual void dump() const;
	
};



template <class T>
ObjectCollector<T>::~ObjectCollector()
{
	for (int i = 0; i < objectTable.size(); i++)
    {
    	
    	OTraceDebug("D-AUTH-0701: Dtor InstancePool[%s]\n", objectTable[i]->ocObjectName.data() );
    	delete objectTable[i];
    }
}

template <class T>
int  ObjectCollector<T>::recycle()
{
    for (int i = 0; i < objectTable.size(); i++)
    {
    	if ( objectTable[i]->lastInstance >= 0 )
    	{
	    	OTraceDebug("D-AUTH-0702:   Recycle InstancePool[%s]/%d/%d\n"
	    				, objectTable[i]->ocObjectName.data()
	    				, objectTable[i]->lastInstance
	    				, objectTable[i]->maxUsedInstance );
	    	objectTable[i]->recycle();
    	}
    }
	return 0;
}

template <class T>
T *ObjectCollector<T>::getObject(const char *objName, const void *msg)
{
	T **instance = getInstancePool(objName)->getInstance();
	
	if ( *instance == NULL )
	{
		*instance = createInstance(objName, msg);
	}
	else
	{
		reuseInstance( *instance, objName, msg );
	}

	return *instance;
}

template <class T>
InstancePool<T>* ObjectCollector<T>::getInstancePool(const char *name)
{
	int i;
	OCString ocName(name);
	
    for (i = 0; i < objectTable.size(); i++)
    {
        if ( ocName == objectTable[i]->ocObjectName )
        {
//        	OTraceDebug("D-AUTH-0703: Found InstancePool[%s]\n", ocName.data() );
        	return objectTable[i];
        }
    }
    
	OTraceDebug("D-AUTH-0704: Create InstancePool[%s]\n", ocName.data() );
	InstancePool<T> *newObject = new InstancePool<T>(ocName);
	if ( newObject == NULL )
	{
		OTraceFatal("F-AUTH-0705: Cannot create a new InstancePool[%s] object\n", ocName.data());
		throw ExceptionFatal("F-AUTH-0706: ObjectCollector::getInstancePool()\n" );
	}
	
	objectTable.push_back(newObject);
	return newObject;
}

/*===========================================================================*/

template <class T>
InstancePool<T>::InstancePool(OCString &ocStr) : ocObjectName(ocStr)
{
	maxUsedInstance = 0;
	lastInstance 	= 0;
	for ( int i=0; i<MAX_INSTANCE_NUM; i++)
		_instance[i] = NULL;
}
	
template <class T>
InstancePool<T>::~InstancePool()
{
	for ( int i=0; _instance[i]&&i<MAX_INSTANCE_NUM; i++)
	{
		delete _instance[i];
		_instance[i] = NULL;
	}
	maxUsedInstance = 0;
	lastInstance 	= 0;
}
	
template <class T>
T **InstancePool<T>::getInstance()
{
	if ( maxUsedInstance >= MAX_INSTANCE_NUM )
	{
		throw ExceptionFatal("F-AUTH-0712: Exceed MAX_INSTANCE_NUM\n" );
	}
	
	if ( lastInstance < maxUsedInstance-1 )
	{
		lastInstance++;
		OTraceDebug("D-AUTH-0713: Reuse InstancePool[%s][%d]\n", ocObjectName.data(), lastInstance );
	}
	else
	{
		maxUsedInstance++;
		lastInstance = maxUsedInstance-1;
		_instance[lastInstance] = NULL;
		OTraceDebug("D-AUTH-0714:        Use Instance[%s][%d]\n", ocObjectName.data(), lastInstance );
	} 
	
	return &_instance[lastInstance];
}
	

template <class T>
int InstancePool<T>::recycle()
{
//	dump();
	
	for ( int i=0; _instance[i]&&i<=lastInstance; i++)
		(T *)_instance[i]->recycle();
	
	lastInstance = -1;
	return 0;
}

template <class T>
void InstancePool<T>::dump() const
{
	OTraceDump("D-AUTH-0715: MaxInstance[%d] MaxUsedInstance[%d] CurrentInstanceNo.[%d]\n"
			, MAX_INSTANCE_NUM, maxUsedInstance, lastInstance );
	for( int i=0; i<=lastInstance; i++ )
		OTraceDump("D-AUTH-0716: ObjectName[%s] address[%p]\n", ocObjectName.data(), _instance[i]);
}

#endif

