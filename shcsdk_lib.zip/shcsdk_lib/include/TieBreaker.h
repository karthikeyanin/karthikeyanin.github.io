#ifndef _TIEBREAKER_H_
#define _TIEBREAKER_H_

static char _TieBreaker_h_what[] = "@(#) TieBreaker.h 1.3 05/01/10 15:07:26";

/*
 *  Copyright (C) 2004 eFunds Corporation ("eFunds").  All Rights Reserved.     
 *  eFunds Canada Corporation is an authorized user.                            
 *                                                                              
 *  IST is a registered trademark of eFunds Corporation.  Other brand or        
 *  product names are trademarks or registered trademarks of their respective   
 *  holders.                                                                    
 *                                                                              
 *  The information contained herein is the unpublished proprietary property    
 *  of eFunds.  Except as specifically authorized in writing by eFunds, the     
 *  holder of this document shall: i) keep all information contained herein     
 *  confidential, and ii) protect the information, in whole or in part, from    
 *  disclosure and dissemination to all third parties.                          
 *                                                                          
 *  This document and the software described in it are furnished under license  
 *  and may be used or copied only in accordance with the terms of such license.
 *  This document is supplied for information purposes only, is subject to      
 *  change without notice, and should not be construed as a commitment by       
 *  either eFunds Corporation or eFunds Canada Corporation. 
 *
 *
 *                        MODIFICATION HISTORY                  REVIEW
 *
 * SCR#     Who		Date  		Description
 * ===========================================================================
 * R0xxxxx  EdC		09Feb2010	Start
 */
 

#include <ShcSdkCommon.h>
#include <shcextbuf.h>
#include <ist_otrace.h>
#include <mt_extbin.h>
#include <IssProfile.h>
#include <mt_iss_profile.h>
#include <ShcmsgHeader.h>
#include <ShcHelperBase.h>


#define SHC_TieBreaker 			"TieBreaker"


class TieBreaker : public ShcHelperBase
{
public:
    const char *getName()
    {
        return (const char *)SHC_TieBreaker;
    }

	TieBreaker();
	TieBreaker(ShcmsgHeader *header);

	virtual int initialize(void* Arg = NULL);
	virtual	int breakIssuerTie(struct profilesList* profileResult, int numEntries);

	// for flexibility - 18May2010
	virtual	void setOption(int pOpt) { processOpt = 0; };
	virtual int  getOption()		 { return processOpt; };

	ShcmsgHeader* 	headerP;
	struct shcmsg*	msg;
protected:
	int				processOpt;
	bool			objStatusOK;
};

#endif

