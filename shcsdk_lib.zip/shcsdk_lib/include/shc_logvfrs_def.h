/*
 *	IST and IST/Share are registered trademarks of Oasis Technology Ltd.
 *
 *	Copyright (C) 1990 - 1997 Oasis Technology Ltd.
 *	All Rights Reserved
 *	This Module contains Proprietary Information of
 *	Oasis Technology Ltd., and should be treated as Confidential.
 *
 *	THIS IS UNPUBLISHED PROPRIETARY SOURCE CODE OF OASIS TECHNOLOGY LTD.
 *	The copyright notice above does not evidence any  
 *	actual or intended publication of such source code.
 */
/*
#pragma ident "@(#) SCCS/s.shc_logvfrs_def.h 1.2 04/07/22 15:17:20"
 *
 *                        MODIFICATION HISTORY                  REVIEW
 *
 *	SPR#	Who	Date	Description			Who	Date   
 * ===========================================================================
 * R010373	lsun08May04	Create file to support Visa FRS Message
 */

#ifndef	SHC_LOG_VFRS
#define SHC_LOG_VFRS

#if !defined( SHCDLLEXPORT )
#	if defined( WIN32 )
#		define SHCDLLEXPORT __declspec(dllimport)
#	else
#		define SHCDLLEXPORT
#	endif
#endif


//SHCDLLEXPORT	extern	int shc_logvfrs_open();
//SHCDLLEXPORT	extern	int shc_logvfrs_insert(struct shc *shcmsg);
//SHCDLLEXPORT	extern	int shc_logvfrs_update(struct shc *shcmsg);


#define	SHC_VFRS_SEG	"VISA_FRS_DATA"

#endif
