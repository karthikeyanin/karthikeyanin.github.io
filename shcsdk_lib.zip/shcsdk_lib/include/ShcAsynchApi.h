#ifndef _SHCASYNCHAPI_H_
#define _SHCASYNCHAPI_H_

static char _ShcAsynchApi_h_what[] = "@(#) ShcAsynchApi.h 1.3 19/10/15 16:56:55";

/*
 *  Copyright (C) 2004 eFunds Corporation ("eFunds").  All Rights Reserved.     
 *  eFunds Canada Corporation is an authorized user.                            
 *                                                                              
 *  IST is a registered trademark of eFunds Corporation.  Other brand or        
 *  product names are trademarks or registered trademarks of their respective   
 *  holders.                                                                    
 *                                                                              
 *  The information contained herein is the unpublished proprietary property    
 *  of eFunds.  Except as specifically authorized in writing by eFunds, the     
 *  holder of this document shall: i) keep all information contained herein     
 *  confidential, and ii) protect the information, in whole or in part, from    
 *  disclosure and dissemination to all third parties.                          
 *                                                                          
 *  This document and the software described in it are furnished under license  
 *  and may be used or copied only in accordance with the terms of such license.
 *  This document is supplied for information purposes only, is subject to      
 *  change without notice, and should not be construed as a commitment by       
 *  either eFunds Corporation or eFunds Canada Corporation. 
 *
 *
 *                        MODIFICATION HISTORY                  REVIEW
 *
 * SCR#     Who    Date  Description
 * ===========================================================================
 *
 */

#include <stdio.h>
#include <shc.h>
#include <ShcmsgHeader.h>
#include <ShcAppBase.h>
#include <ShcTimerHelper.h>

// Asynchronous Response Buffer
struct asynchRespBuf
{
	int		cmdId;			// Security Command Id
	int		respCode;		// Command Response Code
	char	keyZMK[128+1];	// Key Under ZMK
	char	keyLMK[128+1];	// Key Under LMK
	char	checkVal[64+1];	// Check Value
	char	addRsp[1024+1];	// Additional Response Data
};

extern int isAsynchResume();
extern int shcIsAsynchSecMode();
extern int setAsynchMbName(const char *);
extern int setAsynchHeader(ShcmsgHeader *);
extern int setAsynchSrcId(ShcmsgHeader *,const char *,char *,int);
extern int setAsynchSrcId(ShcmsgHeader *,char *,int);
extern int setAsynchSrcId(char *,int);
extern int setAsynchWait();
extern int isAsynchHeaderSet(const char *);
// extern int setAsynchTxnFlgs(ShcmsgHeader *,struct  shcmsg *);
extern int setAsynchTxnFlgs(ShcHeader *,struct  shcmsg *);
extern ShcmsgHeader *getAsynchHeader();
extern int setAsynchSecResp(int,struct shcmsg *,char *);
extern int getAsynchEvent(char *,int &,int,struct shcmsg *);
extern int getAsynchEvent(char *,int &,int,struct shcmsg *,struct asynchRespBuf *);

#endif

