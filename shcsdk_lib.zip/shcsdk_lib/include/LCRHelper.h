#ifndef _LCRHELPER_H_
#define _LCRHELPER_H_

static char _LCRHelper_h_what[] = "@(#) LCRHelper.h 1.5 11/02/07 14:18:02" ;

/*
 *  Copyright (C) 2010 FIS Corporation ("FIS").  All Rights Reserved.     
 *  FIS Canada is an authorized user.                            
 *                                                                              
 *  IST is a registered trademark of FIS Corporation.  Other brand or        
 *  product names are trademarks or registered trademarks of their respective   
 *  holders.                                                                    
 *                                                                              
 *  The information contained herein is the unpublished proprietary property    
 *  of FIS.  Except as specifically authorized in writing by FIS, the     
 *  holder of this document shall: i) keep all information contained herein     
 *  confidential, and ii) protect the information, in whole or in part, from    
 *  disclosure and dissemination to all third parties.                          
 *                                                                          
 *  This document and the software described in it are furnished under license  
 *  and may be used or copied only in accordance with the terms of such license.
 *  This document is supplied for information purposes only, is subject to      
 *  change without notice, and should not be construed as a commitment by       
 *  either FIS Corporation or FIS Canada.
 *
 *
 *                        MODIFICATION HISTORY                  REVIEW
 *
 * SCR#     Who    Date  Description
 * ===========================================================================
 * R0xxxxx 
 */
 

#include <ShcSdkCommon.h>
#include <shcextbuf.h>
#include <string.h>
#include <ic/ic_bin.h>
#include <ic/ic_instid.h>
#include <ctype.h>
#include <ist_otrace.h>
#include <mt_extbin.h>
#include <mt_iss_profile.h>
#include <mt_acq_profile.h>
#include <mt_inst_profile.h>
#include <ShcmsgHeader.h>
#include <ShcHelperBase.h>


// The following are stored in segments and could have
// different layouts depending on the system
// This definition is still not final--this may go to the segment handler class
// #include <shclog_dn.h>

#define SHC_LCRHelper 			"LCRHelper"
#define SHCSEG_DN_NAME  		"DN_SEGMENT"
#define SHCSEG_CLIENT_NAME  	"CLIENT_SEGMENT"

#define	SIGNATURE_DEBIT			'S'
#define	DEBIT_CARDCATEGORY		'D'
#define	CREDIT_CARDCATEGORY		'C'
#define	OFFSET_SDI				 6		// shcextbindb.network_data

#define MAX_ENTRY               50
#define BLACK_HOLE_PRIORITY     50
#define BLACKHOLE_BIN           ((char*)"BLACKHOLE")
#define EBTG_NETWORK            ((char*)"EBTG")
#define STATE_OFFSET            ((int)7)
#define PRIORITY_OFFSET         ((int)7)
#define NETWORKRULE_OFFSET      ((int)9)
#define NATL_OFFSET             ((int)9)
#define NATIONAL_NETWORK        ('N')
#define REGIONAL_NETWORK        ('R')
#define ISSUER_PRIORITY         ('I')
#define NETWORK_PRIORITY        ('N')

static	const	char*			BlackHoleBin;
static	const	char*			EBTG_Network;

typedef struct lcr_cfgdata
{
    char    net_name[16];
    char    priority[3];
    char    net_type;
    char    net_id[16];
} LCR_CFGDATA;

typedef struct lcr_statemap
{
    char    frState[5];
    char    toState[5];
} LCR_STATEMAP;



class LCRHelper : public ShcHelperBase
{
public:
    const char *getName()
    {
        return (const char *)SHC_LCRHelper;
    }

	LCRHelper();
	LCRHelper(ShcmsgHeader *header);
	~LCRHelper();

	int				doLCR(ExtBinResult&);
	bool    		InitOK(){ return objStatusOK; };
    virtual int 	clientRoutingRule(struct shcmsg*, ExtBinResult&);
	int				initialize(ShcmsgHeader*);
	void			setProcessOption(char c) { processOption = c; };
	char			getProcessOption() { return processOption; };

	char    fileloc[512];

protected:
    // These pointers are expected to get its value from callers
    // should not be deleted on exit
    char                        stateTable[1024];
    struct  rules_keytab        *issuerRuleKeyp;
    struct  rules_keytab        *shcExtBinRuleKeyp;
    struct  shcextbin           *shcExtBinData;
    struct  shcextbinGroupHeader *shcextbinGroupData;
    struct  IssuerProfile       *issuerProfileData;
    struct  InstitutionProfile  *institutionProfileData;
    struct  rules_keytab        *institutionRuleKeyp;

    struct  shcmsg              *oMsg;

	char						processOption;				// 18May2010

    bool    					objStatusOK;
    int     					institutionProfileAppid;
    int     					issuerProfileAppid;
    int  						appid;

    LCR_CFGDATA         		cfg_list[MAX_ENTRY];
    LCR_STATEMAP        		statemap_list[20];

// These are subject for review--may not be necesary
private:
	int							initDone;

    void                		getOtherData(IssuerInfo&);
    int                 		binCompare(const char*, const char*, const char*, int);
    int                 		lcrStateRule(ExtBinResult&, int);
};

#endif

