#ifndef SHCSEG_H
#define SHCSEG_H
static char _shcseg_h_what[] = "@(#) shcseg.h 1.3 06/10/17 16:25:43";

/*
 *  Copyright (C) 2004 eFunds Corporation ("eFunds").  All Rights Reserved.     
 *  eFunds Canada Corporation is an authorized user.                            
 *                                                                              
 *  IST is a registered trademark of eFunds Corporation.  Other brand or        
 *  product names are trademarks or registered trademarks of their respective   
 *  holders.                                                                    
 *                                                                              
 *  The information contained herein is the unpublished proprietary property    
 *  of eFunds.  Except as specifically authorized in writing by eFunds, the     
 *  holder of this document shall: i) keep all information contained herein     
 *  confidential, and ii) protect the information, in whole or in part, from    
 *  disclosure and dissemination to all third parties.                          
 *                                                                          
 *  This document and the software described in it are furnished under license  
 *  and may be used or copied only in accordance with the terms of such license.
 *  This document is supplied for information purposes only, is subject to      
 *  change without notice, and should not be construed as a commitment by       
 *  either eFunds Corporation or eFunds Canada Corporation. 
 *
 *                        MODIFICATION HISTORY                  REVIEW
 *
 *	SPR#	Who	Date	Description			Who	Date   
 * ===========================================================================
 * R005141 knguyen 26sep00 increase segment size to 10K
 * R006874 ccy  31Oct01 Changed char* to const char*
 * R008117 jyang 06Aug02 Add 2 functions to support to append segment fields
 *R008717 ztang 11Dec02	Add get_seg_from_shcmsg()
 *
 **************************************************************************
 *
 *	This file defines user segments that can be added to shcmsg
 *	These segements are preserved according to the specific flags
 *	set in the processing options
 *
 **************************************************************************

 **************************************************************************
 *
 *	User segments have the general layout
 *
 *	header
 *		segstart
 *		[options]
 *		[data]
 *
 *	The segstart field is defined for each segment within the message.
 *
 *	The options section is an optional section that defines processing on
 *	the segment (ie. does shc keep, transfer to issuer etc.)
 *
 *	The data portion is currently user defined. Future implementations
 *	will allow switch specific items to be placed in this area.
 *
 *	User segments are expected to follow the general format of
 *
 *		[fid][fidlen][data]
 *
 *	where fid is the field identifier, fidlen is an optional element indicating
 *	the length of the field (including fid and fidlen) in bytes, and
 *	data is the data for this field.
 *
 *	IST does not examine or verify this structure. However, future 
 *	implementations of IST will use this structure internaly. Hence it is
 *	in the users benefit to follow this standard.
 *
 **************************************************************************/

#if !defined( SHCDLLEXPORT )
#   if defined( WIN32 )
#       define SHCDLLEXPORT __declspec(dllimport)
#   else
#       define SHCDLLEXPORT
#   endif
#endif
struct shcmsg;

/**************************************************************************
 *
 *	Defines
 *
 **************************************************************************/
#define SHCSEG_MAX_SEGMENT		10240	/*R005141 expect it to be lifted later*/
#define SHCSEG_MAX_SEGTYPE		30

#define shcLocateSegmentStart(shcmsg) \
	((struct shcseg *)( ( (struct shc *)shcmsg ) + 1) )


/**************************************************************************
 *
 *	Options
 *
 **************************************************************************/

/**************************************************************************
 *
 *	Structures
 *
 **************************************************************************/

typedef	long	shcsegopt_t;

struct shcsegopt {
	/*	structure that defines the operating options set on this segment */
	shcsegopt_t		opt;
	long			optlen;
	long			datalen;
	long			action;
	char			optdata[1];
};

struct shcsegstart {
	long		segsize;		/*	total size of this segment */
	char		type[SHCSEG_MAX_SEGTYPE + 1];
	int			optlen;
	int			nopt;			/*	number of options */
	long		datalen;

	/*	parsing fields */
	int			current;
	struct	shcsegopt	*sopt;
};

struct	shcseg {
	long		totalsize;		/*	total size of segment including header */
	long		nsegments;

	/*	fields used internaly during parse */
	long		current;
	char		*p;
	struct	shcsegstart	*sp;
};

#ifdef __cplusplus
extern "C" {
#endif

SHCDLLEXPORT extern struct shcseg *shcmsgLocateSegmentStart(struct shcmsg *msg);
SHCDLLEXPORT extern  struct  shcsegstart *shc_segfind(struct  shcseg *seg,const char  *type);
SHCDLLEXPORT extern struct  shcsegstart *shc_segfindnext(struct  shcseg *seg,struct  shcsegstart *sp,const char  *type);
SHCDLLEXPORT extern struct  shcsegstart *shc_segfirst(struct  shcseg *seg);
SHCDLLEXPORT extern struct  shcsegstart *shc_segnext(struct  shcseg *seg,struct  shcsegstart *sp);
SHCDLLEXPORT extern struct  shcsegopt *shc_segfirstopt(struct  shcseg *seg,struct  shcsegstart *sp);
SHCDLLEXPORT extern struct  shcsegopt *shc_segnextopt(struct  shcseg *seg,struct  shcsegstart *sp,struct  shcsegopt *sopt);
SHCDLLEXPORT extern char  *shc_seggetdata_pointer(struct  shcseg *seg,struct  shcsegstart *sp);
SHCDLLEXPORT extern int  shc_seggetdata_len(struct  shcseg *seg,struct  shcsegstart *sp);
SHCDLLEXPORT extern struct  shcseg *shc_segallocate(long  size);
SHCDLLEXPORT extern int  shc_segbegin(struct  shcseg *seg);
SHCDLLEXPORT extern int  shc_segaddsegment(struct  shcseg *seg, const char *type);
SHCDLLEXPORT extern int  shc_segaddoption(struct shcseg *seg, shcsegopt_t opt, long action, const char *data, long datalen);
SHCDLLEXPORT extern int  shc_segadddata(struct  shcseg *seg,const char  *bp,int  len);
SHCDLLEXPORT extern int  shc_segend(struct  shcseg *seg);
SHCDLLEXPORT extern char *shc_segname(struct shcseg *seg, struct shcsegstart *sp);
SHCDLLEXPORT extern char *shc_seggetoptdata(struct shcseg *seg,	struct shcsegstart *sp, struct shcsegopt *sopt);
SHCDLLEXPORT extern struct	shcsegopt 	*shc_segfindopt(struct shcseg *seg, struct shcsegstart *sp, int type);
SHCDLLEXPORT extern int  shc_segAppendBegin(struct shcseg *pSeg);	/* R008117 */
SHCDLLEXPORT extern int  shc_segAppendNoOpt( struct shcmsg *msg, char *segName, char *segData, int segLen ); /* R008117 */
SHCDLLEXPORT extern void *get_seg_from_shcmsg(struct shcmsg *shcmsg, char *segName, int *segLen);	/* R008717 */

#ifdef __cplusplus
 }
#endif
#endif
