/*
 *  Copyright (C) 2004 eFunds Corporation ("eFunds").  All Rights Reserved.     
 *  eFunds Canada Corporation is an authorized user.                            
 *                                                                              
 *  IST is a registered trademark of eFunds Corporation.  Other brand or        
 *  product names are trademarks or registered trademarks of their respective   
 *  holders.                                                                    
 *                                                                              
 *  The information contained herein is the unpublished proprietary property    
 *  of eFunds.  Except as specifically authorized in writing by eFunds, the     
 *  holder of this document shall: i) keep all information contained herein     
 *  confidential, and ii) protect the information, in whole or in part, from    
 *  disclosure and dissemination to all third parties.                          
 *                                                                          
 *  This document and the software described in it are furnished under license  
 *  and may be used or copied only in accordance with the terms of such license.
 *  This document is supplied for information purposes only, is subject to      
 *  change without notice, and should not be construed as a commitment by       
 *  either eFunds Corporation or eFunds Canada Corporation. 
 */
/*
#pragma ident "@(#) multi_institution.h 1.11.1.2 18/08/09 03:18:23";
 *
 *                        MODIFICATION HISTORY                  REVIEW
 *
 *	SPR#	Who	Date	Description			Who	Date   
 * ===========================================================================
 *R008717 ztang 15Nov02 Created for multi-institution support
 *						Added alternateAcqBin to shc structure
 *R012134 Emj   01Oct04 Issuer Entity Support
 */

#ifndef MULTI_INSTITUTION_INCLUDE
#define MULTI_INSTITUTION_INCLUDE

#if !defined( SHCDLLEXPORT )
#   if defined( WIN32 )
#       define SHCDLLEXPORT __declspec(dllimport)
#   else
#       define SHCDLLEXPORT
#   endif
#endif


#ifdef PREPROC_MT_LIB

#if defined ( SHCDLLEXPORT )
#   undef     SHCDLLEXPORT
#   define    SHCDLLEXPORT
#endif


#endif

#include <string.h>
#include <shc.h>
#include <mt_inst_profile.h>
#include <multi_inst_def.h>


struct AcquirerProfile;

extern int instProfileFindUpBin;
extern int acqProfileFindUpBin;
class SHCDLLEXPORT AcquirerInfo
{
public:
	bin_t	m_acqBin;
	bin_t	m_alternateAcqBin;
	AcquirerInfo() { m_acqBin[0] = '\0'; }
	const char *getAcqBin() { return &m_acqBin[0]; }
	const char *getAlternateAcqBin() { return &m_alternateAcqBin[0]; }
	int	foundAcquirer()
	{
		if (m_acqBin[0])
			return 1;
		else
			return 0;
	}
	void reset() { m_acqBin[0] = '\0'; m_alternateAcqBin[0] = '\0';}
};




struct IssuerProfile;

class SHCDLLEXPORT IssuerInfo
{
	bin_t 	m_issuerBin;
	char 	m_txnDest[MAX_TXN_DESTINATION_LEN+1];
	char 	m_cardProduct[MAX_CARD_BRAND_NAME_LEN+1];
	char	m_networkData[SHC_NETWORK_DATA_BUF_LEN];
	char    m_entityId[31];

public:
	
        IssuerInfo() { m_issuerBin[0] = 0; m_txnDest[0] = 0; m_cardProduct[0] = 0; m_entityId[0] = 0; }

	
	const char *getIssuerBin() { return m_issuerBin; }
	const char *getTxnDest() { return &m_txnDest[0]; }
	const char *getCardProduct() { return &m_cardProduct[0]; }
	const char *getNetworkData() { return m_networkData; }
	const char *getEntityId() { return m_entityId; }
	void setIssuerBin(const char *issuerBin) { strcpy(m_issuerBin, issuerBin); }
	void setTxnDest (const char *txnDest) { strcpy(m_txnDest, txnDest); }
	void setCardProduct (const char *cardProduct) { strcpy(m_cardProduct, cardProduct); }
	void setNetworkData (const char *networkData) { strcpy(m_networkData, networkData); }
	void setEntityId (const char *entityId) { strcpy(m_entityId, entityId); }
	
	int	foundIssuer()
	{
		if (m_issuerBin[0])
			return 1;
		else
			return 0;
	}
        void reset() { m_issuerBin[0] = 0; m_txnDest[0] = 0; m_cardProduct[0] = 0; m_entityId[0] = 0; }

};


//struct InstitutionProfile;

class NetworkInfo
{
private:
	struct InstitutionProfile m_ip;
	//	>>>	R030643
	struct RoutingInfo m_ri;
	bool m_isRouteSet;
	//	<<<	R030643
public:
	NetworkInfo();
	NetworkInfo(struct InstitutionProfile ip);
	int foundNetworkInfo ();
	const char *getTxnSrc();
	const char *getTxnDest();
	const char *getDestEntityId();
	const char *getExternalId();
	const char *getExternalIdDesc();
	const char *getMember_ID();
	const char *getF_ID();
	const char *getBin();
	int   getKeyparam();
	struct shcsecurity *getKey();
	const char  *getInstId();
	const char  *getKeyparamStr();
	const struct InstitutionProfile *getInstProfileEntry();
	void putExternalId(const char *externalId);
	void putExternalIdDesc(const char *externalIdDesc);
	void putMember_ID(const char *member_ID);
	void putF_ID(const char *F_ID);
	void putInstProfileEntry(struct InstitutionProfile *p);
	//	>>>	R030643
	const struct RoutingInfo* getRoutingInfo();
	void putRoutingInfo(struct RoutingInfo* ri);
	bool isRouteSet();
	//	<<<	R030643
	void reset();
};


SHCDLLEXPORT void shc_locate_acquirer(const char *txnSrc, const char *txnDest, const char *entityId, 
						const int currency, const char *deviceType, AcquirerInfo &acquirerInfo);
SHCDLLEXPORT void shc_locate_acquirer(const char *txnSrc, const char *txnDest, const char *entityId, 
						const int currency, const int deviceType, AcquirerInfo &acquirerInfo);
	
SHCDLLEXPORT int shc_locate_extbin(  const char *txnSrc, const char *pan, const int msgType,
									const int merchantType, const long pcode, const int hasPin,
									IssuerInfo &issuerInfo);
SHCDLLEXPORT int shc_locate_extbin(  const char *txnSrc, const char *pan, const int msgType,
									const char *deviceType, const long pcode, const int hasPin,
									IssuerInfo &issuerInfo);

SHCDLLEXPORT void shc_locate_issuer_from_network(const char *txnSrc, const int msgType, const char *externalId,
									const char *member_ID, const char *F_ID, IssuerInfo &issuerInfo);
SHCDLLEXPORT void shc_locate_issuer_from_institution(const char *inst, const char* entityId, const int msgType, IssuerInfo &issuerInfo);
SHCDLLEXPORT void shc_locate_issuer_from_institution(const char *inst, const int msgType, IssuerInfo &issuerInfo);
SHCDLLEXPORT void shc_locate_network_info(const char * txnSrc, const int msgType, const bin_t bin, NetworkInfo &networkInfo);
SHCDLLEXPORT void shc_locate_network_info(const char * txnSrc, 
										  const char * txnDest, const char*iss_entityId,
										  const int msgType, const bin_t bin, NetworkInfo &networkInfo);

SHCDLLEXPORT int shc_externalBin2InternalBin(char *networkid, const char *institutionId, const char *userBinId);
SHCDLLEXPORT int shc_internalBin2ExternalBin(char *institutionId, char *userBinId, const char *networkid);
SHCDLLEXPORT void shc_getIssuerAcquirerInfo(const char *txnSrc, const char *pan, const int msgType,
						const char *deviceType, const long pcode, const int hasPIN,
						const char *entityId, const int currency,
						IssuerInfo &issuerInfo, AcquirerInfo &acquirerInfo );

SHCDLLEXPORT void shc_getIssuerAcquirerInfo(const char *txnSrc, const char *pan, const int msgType,
						const int merchantType, const long pcode, const int hasPIN,
						const char *entityId, const int currency,
						IssuerInfo &issuerInfo, AcquirerInfo &acquirerInfo );

SHCDLLEXPORT char* shc_getextbin_networkconfig(const char *txnSrc, const char *pan, const int msgType,
						const char *deviceType, const long pcode, const int hasPIN,
						IssuerInfo &issuerInfo);

SHCDLLEXPORT char* shc_getextbin_networkconfig(const char *txnSrc, const char *pan, const int msgType,
						const int merchantType, const long pcode, const int hasPIN,
						IssuerInfo &issuerInfo);

SHCDLLEXPORT char* shc_getextbin_fileversion(const char *txnSrc, const char *pan, const int msgType,
                                                const char *deviceType, const long pcode, const int hasPIN,
                                                IssuerInfo &issuerInfo);

SHCDLLEXPORT char* shc_getextbin_fileversion(const char *txnSrc, const char *pan, const int msgType,
                                                const int merchantType, const long pcode, const int hasPIN,
                                                IssuerInfo &issuerInfo);

#endif
