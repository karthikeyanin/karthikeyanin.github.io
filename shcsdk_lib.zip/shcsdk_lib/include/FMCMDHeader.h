//
// Copyright (C) 2004 eFunds Corporation ("eFunds").  All Rights Reserved.
// eFunds Canada Corporation is an authorized user.
//
// IST is a registered trademark of eFunds Corporation.  Other brand or
// product names are trademarks or registered trademarks of their respective
// holders.
//
// The information contained herein is the unpublished proprietary property
// of eFunds.  Except as specifically authorized in writing by eFunds, the
// holder of this document shall: i) keep all information contained herein
// confidential, and ii) protect the information, in whole or in part, from
// disclosure and dissemination to all third parties.
//
// This document and the software described in it are furnished under license
// and may be used or copied only in accordance with the terms of such license.
// This document is supplied for information purposes only, is subject to
// change without notice, and should not be construed as a commitment by
// either eFunds Corporation or eFunds Canada Corporation.
//
 /*
 *  SCR     Who     Date	Description
 *  ===========================================================================
 *  R020052 spa	   21May07	New file created
 *	R025639 vmp		13Apr09	Added fields dur,reason for FM PhaseII enhancement
 *
 */

/* File Number */

#ifndef __FMCMDHEADER__
#define __FMCMDHEADER__

static const char* _FMCMDHeader_h_what = "@(#) FMCMDHeader.h 1.1.2.4 17/07/24 13:42:02";

#include <ShcHeader.h>

struct s_BlockCMD
{
	int msgtype;
	long trace;
	char inst[MAX_TXN_DESTINATION_LEN+1];
	long action;
	char blockInfo[256];
	//	>>>	R025639
	char respcode[2+1];
	char dur[8];
	char reason[128];
	//	<<<	R025639
	char echodata[500];
	int unit;
};

class FMCMDHeader : public ShcHeader
{

	public:
		struct s_BlockCMD blockCMD;

		FMCMDHeader(struct s_BlockCMD *_blockCMD)
		{
			memcpy(&blockCMD, _blockCMD, sizeof(struct s_BlockCMD));
		}
		const char *getName()
		{
			return (char *)SHC_FMCMDHeader;
		}
};

#endif
