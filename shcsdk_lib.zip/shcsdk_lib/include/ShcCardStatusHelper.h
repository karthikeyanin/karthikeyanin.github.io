#ifndef _SHC_CARDSTATUSHELPER_H_
#define _SHC_CARDSTATUSHELPER_H_

static char _ShcCardStatusHelper_h_what[] = "@(#)ShcCardStatusHelper.h 1.14 14/10/28 06:01:0";

/*
 *  Copyright (C) 2004 eFunds Corporation ("eFunds").  All Rights Reserved.     
 *  eFunds Canada Corporation is an authorized user.                            
 *                                                                              
 *  IST is a registered trademark of eFunds Corporation.  Other brand or        
 *  product names are trademarks or registered trademarks of their respective   
 *  holders.                                                                    
 *                                                                              
 *  The information contained herein is the unpublished proprietary property    
 *  of eFunds.  Except as specifically authorized in writing by eFunds, the     
 *  holder of this document shall: i) keep all information contained herein     
 *  confidential, and ii) protect the information, in whole or in part, from    
 *  disclosure and dissemination to all third parties.                          
 *                                                                          
 *  This document and the software described in it are furnished under license  
 *  and may be used or copied only in accordance with the terms of such license.
 *  This document is supplied for information purposes only, is subject to      
 *  change without notice, and should not be construed as a commitment by       
 *  either eFunds Corporation or eFunds Canada Corporation. 
 *
 *                        MODIFICATION HISTORY                  REVIEW
 *
 * SCR#     Who    Date  Description
 * ===========================================================================
 */
 
#include <ShcmsgHeader.h>
#include <ShcHelperBase.h>
#include <dbm.h>
#define TBL_SHCCARDSTATUS                   "shccardstatus"
#include <dbm.h>
#include <oc/oc_string.h>
#include <ist_otrace.h>
#include <shc.h>
#include <ShcAppBase.h>
#include <ShcHelper.h>
#include <shccardstatus.h>
#include <shccardstatusmap.h>
#include <ISTRulCardStatusMap.h>
#include <ISTRulCardStatusMapShmReader.h>

struct FResult{
   char status[5];
   int respCode;
   OCDateTime eff_to;
   OCDateTime eff_from;
};

class ShcCardStatusHelper : public ShcHelperBase
{
	public:
		ShcCardStatusHelper();
		~ShcCardStatusHelper();
		int checkCardStatus(ShcmsgHeader *header, struct FResult *result, char *flag_to_trace_nodata_tbl = NULL);
		void dbInit();
		const char *getTblName() { return TBL_SHCCARDSTATUS; }
		const char *getName()
		{
			return (const char *)SHC_ShcCardStatusHelper;
		}
	protected:
		DBMConn* _dbConn;
		DBMStmt* _smtSelOne;
		DBMStmt* _stmt;
		int _ind[50];
		char _status[5];
		OCDateTime effective_to;
		OCDateTime effective_from;
		DBMDateTime effective;
		DBMDateTime effectivefrom;
		char Pan[20];
		int                     site_id;
		DBMInt          siteid;
};

#endif

