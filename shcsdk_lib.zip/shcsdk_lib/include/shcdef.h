/*
 *  Copyright (C) 2004 eFunds Corporation ("eFunds").  All Rights Reserved.
 *  eFunds Canada Corporation is an authorized user.
 *
 *  IST is a registered trademark of eFunds Corporation.  Other brand or
 *  product names are trademarks or registered trademarks of their respective
 *  holders.
 *
 *  The information contained herein is the unpublished proprietary property
 *  of eFunds.  Except as specifically authorized in writing by eFunds, the
 *  holder of this document shall: i) keep all information contained herein
 *  confidential, and ii) protect the information, in whole or in part, from
 *  disclosure and dissemination to all third parties.
 *
 *  This document and the software described in it are furnished under license
 *  and may be used or copied only in accordance with the terms of such license.
 *  This document is supplied for information purposes only, is subject to
 *  change without notice, and should not be construed as a commitment by
 *  either eFunds Corporation or eFunds Canada Corporation.
 *
 *
 *
 *                        MODIFICATION HISTORY                  REVIEW
 *
 *	SPR#	Who	Date	Description			Who	Date
 * ===========================================================================
 *          qd	29feb96	Added SH_SENDTRA for routing to tansferee bank
 * 10001845 la  960424  Added point of service condition code for unattended
 *                      terminal, customer operated.  i.e. ATM's.
 *          dwk 960813  Added ISSUER-only, ACQUIRER-only bin types
 * 10001959 la  960512  Use istadvicecmd instead of shcreplay.
 * 10002273 la  960819  Defined simpler macros for IBFT processing.
 *          jt	961104	Added flags for formatter_devcap use.
 * 10002675 jsg 961108  Enhanced shcIsIBFT
 *          wrg 961115  Added bin-type flag SH_NO_LOG (suppresses shclog)
 *                      access macro shcUseLog( struct shcmsg * )
 *          wrg 961115  Added
 * 10002898 cw  961126  Add SHC_STLMTREQ_ISSUER_ADVICE and
 *							SHC_STLMTREQ_ISSUER_ADVICE_RESPONSE
 * xxxxxxxx qd  26may97 Add SHC_CHARGE_BACK_ADVICE and
 *							SHC_CHARGE_BACK_ADVICE_RESPONSE
 * xxxxxxxx yh  28Aug97 Add SH_DEVCAP_SHC_EVENT
 *          la  7oct97  Added new status for multiple keys support.
 *			JSG	30Oct97	Added shcServiceProcessOn; shcServiceProcessOff.
 * ACXSYS   qd  24nov97 Added 0602/0612 0622/0632 and new service codes
 * ACXSYS   yh  16Jan98 Added SH_DEVCAP_AUTH_ENCRYPTION for message encryption.
 *              21Jan98 Moved define block about 6xx from shc_admin.c.
 *                      Added shcIsRevIssReq & shcIsRevIssResp macros.
 * ACXSYS   yh  05Feb98 Added macro shcNextKeyIndex for key exchange.
 * R001002  qd  12may98 Added macros for acquirer T.O. duplicate rev check
 * 0001015  qd  15may98 Added FORWARD MODE flags
 * R000935 jsun	18Sep98	Added SH_ISO_BALANCE_INQUIRY 31
 * R001538 zt   25Dec98 Added Definitions for DE61 BIT11
 *						Changed many bit flags for POS_COND and POS_CAP
 *						Ecommerce Enhancement
 *							Added definition SH_TXIDX_AUTHENTICATE
 *							Added definition SH_TX_AUTHENTICATE
 *							Added definition SHC_TXNTYPE_AUTHENTICATE
 * R001538  qd  03mar99 Added CVV2 Support
 * R001835  qd  13apr99 Added Bin level cfg related macros
 * R002251  zt  29Jul99 Added difination for backoffice message flags
 * R003308  fg  28Oct99 Move SHC configuration parameters to bin level
 *                      shc.verify_mac, shc.encrypt_balance, shc.support_NDKE
 *                      shc.restore_trantime, shc.capdate_override
 * R003313  zt  02Dec99 Added defination of SH_POS_PANENTRY_ECOMMERCE80
 *                      Added defination of SH_FORMATDEVCAP_FIRST_REPLAY
 * R003638	kc	10Dec99	Added COPAC definitions
 * R003567  sl  13Dec99 Added defination SH_ECOM_NOTAPPLICABLE
 *                      Added defination SH_ECOM_SECT
 *                      Added defination SH_ECOM_NSTWITHSET
 *                      Added defination SH_ECOM_NSTWITHOUTSET
 *                      Added defination SH_ECOM_NONSECURE
 * R001570 ztang26Jan00 Added definations for shc300 server
 * R003900 ztang03Feb00 Added more security level definition.
 * R004103 fg   022900  Changed the definition of SH_CFG_TRANTIME and
 *			SH_CFG_CAPDATEOVERRIDE
 * R004120 rlo	07Mar00 Added definition SHC_NET_GROUP_SIGNON_CR
 *						Added definition SHC_NET_GROUP_SIGNOFF_CR
 * R004155 lsun 29Mar00 Added definition SHC_POS_CAP_CAT_ECOMMERCE.
 * R004755 jsun 03Jun00 Added SH_FORMATDEVCAP_INTERAC
 * 2007336 Mch 18Feb00 Added 5 macros for VSDC extensions
 *          Mch 21Feb00 Changed name (latest phys. design document)
 *          Mch 24Feb00 Added new macro to check if it's a chip txn
 * 2007336  Ssc 17Apr00 Added new macro to check advice response txn
 * R004671  Ssc 28Jun00 7.2 integration
 * R005338	jy	18Dec00	Added definition SHC_NET_EU_REJECT
 * R005896	jy	31May01	Added definition SH_DEVCAP_SHC_STDIN
 * R006087 jiz  05Jun01 Added definition SH_CFGIX_AVS_FLAG.
 * R006273 jiz  02Aug01 Added definitino for AVS service indicator(0,1,2,3).
 * R006274 jiz  02Aug01 Changed SH_CFGIX_AVS_FLAG from 15 to 6
 * R006365 rzhou  03Aug01 Added device capture flag: SH_DEVCAP_TERMINALDUKPT
 * R007206,R007237 jyang 10Jan02 Added definition for Europay BIN/MBR checking
 * R007369 jiz  29Jan01 Added some definition for R007369
 *R007502 ztang 15Feb02 Added support for Account Funding transaction
 *R007195 ztang 27Feb02 Added support for Cardholer account transfer
 * R006940 Emj  02Nov01 EMV STIP - Card/Issuer Authentication
 * R007400 Emj 18Feb02 Added SH_DEVCAP_HYEDC_MAP
 * R007894 jyang 04Jun02 Added support for new POS module
 *R007686 ztang 04Jun02 Added more flags for CPS
 *R007927 jyang 10Jun02 Change the Europay indicator in shcextbindb
 *R007983 emj 24jun02   Added defines for 382/392 Messages
 *R008041 jyang 12Jul02 Added has_shclog_add() and has_shclog_cheque() macros
 *R008056 jyang 12Jul02 Added definition SEG_MERCHANT_NAME
 *R008106 ztang 25Jul02 Added new pcode SH_ISO_CARD_VERIFICATION
 *R007163 ztang 08Aug02 Added new pcode SH_ISO_PAYMENT
 *R008717 ztang 15Nov02 Added some new definition for multi-institution support
 *R009399 jyang 11Mar03 Added a Marco for Visa Account length checking
 *R009697 rzhou 03May03 Added a Marco for MasterCard TIPS interchange program indicator
 *R009856 ztang 02Jul03 Added a new flag
 *R010456 jyang 06Feb04 Added definition Ecommerce indicator SH_ECOM_NSTATSET
 *R010532 rzhou 12Mar04 Added contactless card entry code defintions
 *R011925 jyang 16Sep04 Saf interleave support
 *R011822 rzhou 09Nov04 Added internal flags for electronic participant role
 *R013179 rzhou 18Jan05 Added some defintions for extended POS condition codes
 *R015719 emj   16Feb06 Added flags for 2006 compliance
 *R016047 spa	22Mar06	Added new macro to check 120/121/220/221/420/421 messages
 *R016062 spa	22Mar06	Added new flag SH_FORMATDEVCAP_NOCURRENCY_CONV
 *R016096 spa	24Mar06	Added new flag SH_FORMATDEVCAP_USER_SEGMENT
 *R016678 jyang 20Jun06 Added new macros for MasterCard product codes(in file IP0040T1)
 *R018963 pve	20Feb07	Re-arrange the devcap flags
 *R018983 pve	22Feb07	Remove SH_DEVCAP_HAS_EXPDATE, move SH_DEVCAP_EBCDIC & SH_DEVCAP_TERMINALREV to formatter_devcap
 *R020052 spa	21May07	Added new flags, msgtypes related to FM
 *R020162 Emj   01JUn07 DCVV/ICVV/CVC3/SCVC3 validation
 *R020414 pve	25Jun07	Add new pcode definition SH_ISO_PINUNBLOCK for MC Oct 2007 compliance
 *R020521 jyang 03Jul07 Added new difines to support dual-message transaction
 *R020617 spa	13Jul07	Added new flag SH_FORMATDEVCAP_ALT_ISSUER
 *R020622 spa	13Jul07	Added new flag SH_DEVCAP_SHC_PIN_BASED
 *R020938 spa	16Aug07	Added new flags, msgtypes for IST LM Bridge
 *R022506 lee	04Feb08 Added new flags for Discover Interface
 *R022755 vmp	17Mar08	Removed '-' from SHC_AMOUNT_TYPE_CO_PAY_AMT
 *R023692 jyang 15Jul08 Added new macro for MC non-IIAS-certified txn
 *R025361 sel	21Nov05	Transaction routing service enhancement- added new netcodes
 *R025506 Ash   12Dec08 Flag SH_DEVCAP_AUTH_MERCH_AUTH_ENT Added to support authentication by merchant
 *R025639 vmp	16Jan09	Added new flag SH_DEVCAP_AUTH_FMTimeout for FMtimeout
 *R025862 sel	05Feb09	Added new PAN entry modes; MC April 2009 compliance
 *R026957 sks	16Jul09	New flags added to support authentication by ICC(Integrated Circuit card)& CAD(Card Acceptor Device)
 *R027101 sel   18Aug09 Added new flags for MC Fall'09 compliance 
 *R027102 sel   18Aug09 Added new flags for MC Fall'09 compliance
 *R027876 dipa  02Mar10 Removed SEG_ROUTINGINFO and SHC_APPLBIN_SEG
 *R027905 dipa  25Mar10 Added new macros and constants for USPS:Reversal-void Enhancements
 *R028473 Ash	28Aug10	October 2010 Compliance :Enhancement for Maestro Secure, Mobile Initiated Transactions in Brazil
 *R029153 sks	22Mar11	Added SH_POS_PANENTRY_PRE_REG_CHECKOUT_SERVICE for Visa Apr Comp 2011
 *R029258 Emj   31Mar11 Added bintype SH_KEYS_REQUIRED to force keys to be loaded in shcinitprofiles
 *R030207 Dipa  02Feb12 Clone of R029300
 *R030492 Dipa  20Apr12 Remove reference to shcversion.h
 *R031195 Dipa	17Jan13	Spring Compliance 2013 - Added SH_DEVICE_POSCOND_TransitAccessInd
 *R031357 Dipa	13Jun13	Voice auth - Added SH_FORMATDEVCAP_FORCE_CAPTURE
 *R032576 Dipa	10Feb14 Added SH_NETWORK_CONFIG_IDX_TOKEN_IND
 *IST_S761SP8-43 Dipa	16Apr14	Change the value of SH_FORMATDEVCAP_FORCE_CAPTURE
 */


#if !defined( SHCDLLEXPORT )
#   if defined( WIN32 )
#       define SHCDLLEXPORT __declspec(dllimport)
#   else
#       define SHCDLLEXPORT
#   endif
#endif

#ifndef SHCDEF_INCLUDE
#define SHCDEF_INCLUDE

static const char* _shcdef_h_what = "@(#)shcdef.h 1.70.43.3 20/07/08 00:37:10";


/* R005156 */
#ifdef __cplusplus
extern "C" {
#endif
/* R005156 */
/*------------------------------------------------------------------------*
 * Include Block
 *------------------------------------------------------------------------*/
#include "ist_win32.h"

/*------------------------------------------------------------------------*
 *	Transaction set defines
 *------------------------------------------------------------------------*/
/*		These indexes refer to the database field txnset. The transaction
		permissions are held in an array. It is very important that we
		don't mess around with the order of the fields. Note that this only
		affects the INIT program and does nothing to the runtime.

		To add a new transaction:

		1.		added to the database screen
		2.		add the index in SH_TXIDX_????
		3.		add the flag value as SH_TX_????
		4.		Edit shc_data.c and add the definition in the sch_txn_def[]
				table.

*/
#define	SH_TXIDX_WD					0
#define SH_TXIDX_DEP				1
#define SH_TXIDX_TSF				2
#define SH_TXIDX_BAL				3
#define SH_TXIDX_BILLPAY			4
#define SH_TXIDX_LOANPAY			5
#define SH_TXIDX_CC					6
#define SH_TXIDX_SERVICES			7
#define SH_TXIDX_CHECK_GUARANTEE	8
#define SH_TXIDX_RESERVED_1			9		/* used for other applications */
/**	Index of reversal flag in txn_set	**/
#define SH_TXIDX_REVFLAG		SH_TXIDX_RESERVED_1
#define SH_TXIDX_CHKFLRLIM				10
#define SH_TXIDX_SENDREV				11
#define SH_TXIDX_SAFAUTH				12
#define SH_TXIDX_SENDACK				13
#define SH_TXIDX_PREAUTH_ON_VALIDATE	14
#define SH_TXIDX_CHECKDUP				15
#define SH_TXIDX_CURRENCY_CONV			16
#define SH_PREAUTH_SUPPORT				17
#define SH_FULLAUTH_SUPPORT				18
#define SH_TXIDX_ACQTO_CHK_DUPREV		19 /* R001002 */
#define SH_TXIDX_AUTHENTICATE			19 /* R001538 */

/*
 * These are the flags which we use at runtime for the transaction set.
 */
#define SH_TX_WD				0x0001
#define SH_TX_DEP				0x0002
#define SH_TX_TSF				0x0004
#define SH_TX_BAL				0x0008
#define SH_TX_BILLPAY			0x0010
#define SH_TX_LOANPAY			0x0020
#define SH_TX_SERVICES			0x0040		/*	goods/services purchase */
#define SH_TX_CHECK_GUARANTEE	0x0080
#define SH_TX_CC				0x0100
#define	SH_TX_DEBIT				0x0200
#define SH_TX_CREDIT			0x0400
#define SH_TX_SCRIP				0x0800
#define SH_TX_UPD_BALANCE		0x1000
#define SH_TX_AUTHENTICATE		0x2000		/* R001538 */
#define SH_TX_SUSPECT_WD		0x4000

#define shcIsUpdateBalance(txntype)	(txntype == SH_TX_UPD_BALANCE)

/*------------------------------------------------------------------------*
 *	These are the ISO equivilents shcmsg.msg.pcode
 *------------------------------------------------------------------------*/
/*	account debit */
#define SH_ISO_WITHDRAW_CLASS	0
#define SH_ISO_WITHDRAW_CLASS2	1

#define SH_ISO_G_AND_S			0
#define	SH_ISO_WD				1
#define SH_ISO_DEBIT_ADJUST		2
#define SH_ISO_CHECK_GUAR		3
#define SH_ISO_CHECK_VER		4

#define SH_ISO_TEST_DEBIT		5
#define SH_ISO_TEST_DEBIT_2		6
#define SH_ISO_ACCOUNT_FUNDING	7		/* R007502 */
#define SH_ISO_G_AND_S_CASH		9
#define SH_ISO_PREAUTHREQ		10
#define SH_ISO_PREAUTHRESP		10
#define SH_ISO_BIOMETRIC_VERIFY		10
#define SH_ISO_PREAUTHCONF		11
#define SH_ISO_PREAUTHCANCEL            12
#define SH_ISO_TC_MONEY_ORDER	14
/* Transfer money from customer account to fund other special accounts. For example *
* SEARS may originate this txn to transfer money from customer VISA account to *
* customer's SEARS card account. *
*/
#define SH_ISO_CH_FUND_TRANSFER	15	
#define SH_ISO_TC				16		/*	traverler cheques */
#define	SH_ISO_CASH_ADVANCE		17
#define SH_ISO_SCRIP_ISSUE		18
#define SH_ISO_POSDEBIT			19	/* 13mar93 */

/*	account credit */
#define SH_ISO_DEPOSIT_CLASS	2
#define SH_ISO_PAYMENT_CLASS	SH_ISO_DEPOSIT_CLASS
#define	SH_ISO_PURCH_RETURN		20
#define SH_ISO_DEPOSIT			21
#define SH_ISO_CREDIT_ADJUST	22
#define SH_ISO_CHECK_DEP_GUAR	23
#define SH_ISO_CHECK_DEP		24
#define SH_ISO_LOAN_DEP			25
#define SH_ISO_PAYMENT			26	/* General payment transation, for example MasterCard payment txn */ /* R007163 */
#define SH_ISO_OCT			26
#define SH_ISO_LOYALTY_REDEEM		27
#define SH_ISO_ENV_PAYMENT		28
#define SH_ISO_MONEYLOAD		28
#define	SH_ISO_CORRECTION		29
#define	SH_ISO_MONEYLOAD_BAL_UPD	29

#define SH_ISO_POSCREDIT		50
#define SH_ISO_RECEIVE_PAYMENT	53	/* Payment to this card */
#define SH_ISO_PREPAID_LOAD		96     /* prepaid account load */

/*	inquiries */
#define SH_ISO_BALANCE_CLASS	3
#define SH_ISO_BALANCE			30
#define SH_ISO_BALANCE_INQUIRY		31	/* R000935, ISO definition */
#define SH_ISO_CARD_VERIFICATION 	32	/* R008106 */
#define SH_ISO_ACCOUNT_INQUIRY		34	/* Discover Account Inquiry transaction */
#define	SH_ISO_INQACCT			35

#define SH_ISO_CARDVALIDATE		36
#define	SH_ISO_ELIGB_INQUIRY	97		/* R014167 Visa Eligibility Inquiry txn for healthcare */

#define SH_ISO_AADHAR_INQUIRY		37

#define SH_ISO_BALFILE1			37
#define SH_ISO_BALFILE2			38
#define SH_ISO_BALFILE3			39		/*	user defined balance inquiry
											the net effect is to transfer
											the information to the driver
											in a known file location. The
											information in the file should
											be pre-formatted.
										*/

#define SH_ISO_LOYALTY_INQUIRY		39

/*	account transfers */
#define SH_ISO_TRANSFER_CLASS	4
#define SH_ISO_TRANSFER			40
#define SH_ISO_LOAN_TSF			41
#define SH_ISO_TRANSFER_CNF_1	41		/* 08jul94 */
#define SH_ISO_PAYMENT_ACCT		42
#define SH_ISO_TRANSFER_CNF_2	48		/* 08jul94 */
#define SH_ISO_TRANSFER_OTHER	49	/* tsf into other account (same inst) */
#define	SH_ISO_CHIP_PREAUTH		68		/* R003638 */
#define SH_ISO_CASHOUT          43	//	---	R022506

/*	User defined classes */
#define SH_ISO_USERDEFINED_CLASS1	8
#define SH_ISO_USERDEFINED_CLASS2	9
#define SH_ISO_UTIL_TRANSFER		81		/*	other types of transfer */
#define SH_ISO_ARQC_APRC		81
#define SH_ISO_UTIL_PAYMENT_ENV		82		/*	payment to util from env. */
#define SH_SERVICE_CREATION		83
#define SH_ISO_UTIL_PAYMENT_ACCT	84		/*	payment to util from account */
#define SH_ISO_SERVICE_REQUEST		90		/*	customer service request */
#define SH_ISO_CHKBOOK_REQUEST		91		/*	Check Book Request */
#define SH_ISO_STMT_REQUEST		92		/*	Statement Request */
#define SH_ISO_PASSBOOK_UPD_REQUEST	93		/*	PassBook Update Request */
#define SH_ISO_PINCHANGE		94
#define SH_ISO_CREATE_NEWPIN		944000		/*	Create new pin request - via API */
#define SH_ISO_PIN_VERIFY		945000		/*	Pin verification request - via API */
#define SH_ISO_PINUNBLOCK		98		//Unblock pin - R020414

#define SH_ISO_TERMINAL_REQUEST		95		/* special terminal requests */
#define SH_ISO_PREPAID_ACTIVATION	72			/* prepaid account activation */

#define SH_ISO_PRIOR_G_AND_S		60		/*	Prior Auth Goods service */
#define SH_ISO_PRIOR_CASH_ADV		61		/*	Prior Auth Cash advance */
#define SH_ISO_PRIOR_GS_CASH_ADV	62		/*	Prior Auth Goods service with cash back */
#define SH_ISO_REDEMPTION 		63		/*	Redemption */
#define SH_ISO_DEACTIVATION		64		/*	Deactivation */
#define SH_ISO_PRIOR_ADD_VALUE		65		/*	Prior add value */
#define SH_ISO_PRIOR_ACTIVATION		66		/*	Prior Activation */
#define SH_ISO_PRIOR_REDEMPTION		67		/*	Prior Redemption */
#define SH_ISO_REDEMPTION_COMPLETION	69		/*	Redemption completion */
#define SH_ISO_ACTIVATION		70		/*	activation */
#define SH_ISO_ISSUANCE_ADD_VALUE	71		/*	Issuance add value */
#define SH_ISO_BLOCK_ACTIVATION		73		/*	Block Activation */
#define	SH_ISO_REACTIVATION		74		/*	Reactivation */
#define SH_ISO_MAC_REV			75		/*	MAC Reversal */
#define SH_ISO_CURR_KEY_REQ		76		/*	Current Key request */
#define SH_ISO_BATCH_INQUIRY		77		/*	Batch Inquiry */
#define SH_ISO_BATCH_RELEASE_REQ	78		/*	Batch Release req */
#define SH_ISO_QUERY_BATCH		79		/*	Query Batch */
#define SH_ISO_TOKEN_REQUEST      80      /*  Token Request for PAN */

										/* R001570 BEGIN */
#define SHC300_UpdateDatabase       1
#define SHC300_NeedRouting          2
#define SHC300_RouteDebit           4

#define SHC300_ADD              1
#define SHC300_UPDATE           2
#define SHC300_DELETE           3
#define SHC300_REPLACE          4
#define SHC300_QUERY            5

#define SHC300_UpdateDatabase       1
#define SHC300_NeedRouting          2
#define SHC300_RouteDebit           4
										/* R001570 END */

/*
*	03Mar94
*	Conflict of defined when mergeing Nabanco code. Make it the
*	same for now. Sunny
*/
#define SH_ISO_MESSAGE_TO_BANK		96
#define SH_ISO_GET_BATCH_ID			96

#define	SH_AUTORECON				951010
#define SH_ONLINE_TOTALS			951011

#define SH_BATCH_RECAP_TRAILER		970300  /* zm 30Jan96 */

#define	SH_300_FILE_UPDATE			1		/*	03xx file update */
#define SH_300_PVV_UPDATE			2		/*	03xx pvv update */
#define SH_300_FILE_INQ				3
#define SH_300_PVV_INQ				4


/*
*	Do currency conv  from X to base currency and
*	from base to X currency
*/
#define	SHC_CurrConv_FromBase		10
#define SHC_CurrConv_ToBase			11

/* 25Apr95, 27Jun95
 * Flag for terminal_trace field to bypass zero value test at switch,
 * and request assignment of a value of zero.
 */
#ifdef	solaris
#define SH_MAP_TERMINAL_TRACE_ZERO		~(0UL)
#else
#define SH_MAP_TERMINAL_TRACE_ZERO		~(0)
#endif

/*------------------------------------------------------------------------*
 *	Macros used to determine tyfpe of transaction
 *------------------------------------------------------------------------*/
#define shcIsDeposit(pcode)		((pcode) / 100000 == 2)
#define shcIsInquiry(pcode)		((pcode) / 100000 == 3)
#define shcIsBalance(pcode)		shcIsInquiry((pcode))
#define shcIsTransfer(pcode)	((pcode) / 100000 == 4)
#define shcIsWithdrawal(pcode)	((pcode) / 10000 >= 0 && (pcode) / 10000 < 20)
#define shcIsCredit(pcode)		shcIsDeposit(pcode)
#define shcIsDebit(pcode)		shcIsWithdrawal(pcode)
#define shcIsPayment(pcode)		((pcode) / 10000 == SH_ISO_ENV_PAYMENT)
#define shcIsPurchWithCash(pcode)	((pcode) / 10000 == SH_ISO_G_AND_S_CASH)
#define shcGetProcessCode(pcode)	((pcode) / 10000)
#define shcIsPOSCredit(pcode)	((pcode) / 10000 == SH_ISO_POSCREDIT)
#define shcIsAccountFunding(pcode)  ((pcode) / 10000 == SH_ISO_ACCOUNT_FUNDING )	/* R007502 */
#define shcIsATM(shcmsg)	((shcmsg)->msg.merchant_type == 6011)
#define shcGetISOClass(pcode)\
	((pcode) / 100000L < 2 ? SH_ISO_WITHDRAW_CLASS : (pcode) / 100000L )
#define shcMakeProcessingCode(tx, f, t) ((tx) * 10000L + (f) * 100 + (t))

#define shcIsRefund(pcode)	((pcode) / 10000 == SH_ISO_PURCH_RETURN) //R027905

#define shcIsPreAuth(shcmsg) \
	(shcIsCustomerRequest(shcmsg) && shcIsPreAuthReq(shcmsg))

#define shcIsReAuthed(shcmsg) \
	(shcmsg->msg.device_cap & SH_DEVCAP_REAUTHED)

#define	shcIsPreAgentConfReq(shcmsg) \
	(shcmsg->msg.device_cap & SH_DEVCAP_PREAGENT_STATE)

#define	shcIsProAgentConfReq(shcmsg) \
	(shcmsg->msg.device_cap & SH_DEVCAP_PROAGENT_STATE)

#define shcIsPreAuthRsp(shcmsg) \
	((shcGetProcessCode((shcmsg)->msg.pcode) == SH_ISO_PREAUTHRESP) && \
	 (shcIsResponse(shcmsg)))

#define shcIsPreAuthReq(shcmsg) \
	((shcGetProcessCode((shcmsg)->msg.pcode) == SH_ISO_PREAUTHREQ) && \
	 (shcIsRequest(shcmsg)))

#define shcIsPreAuthCancelReq(shcmsg) \
        ((shcGetProcessCode((shcmsg)->msg.pcode) == SH_ISO_PREAUTHCANCEL) && \
         (shcIsRequest(shcmsg)))

#define shcIsPreAuthCancelReqOld(shcmsg) \
        ((shcGetProcessCode((shcmsg)->msg.pcode) == 20) && \
         (shcIsRequest(shcmsg)))

#define shcIsPreAuthConfReq(shcmsg) \
	((shcGetProcessCode((shcmsg)->msg.pcode) == SH_ISO_PREAUTHCONF) && \
	 (shcIsRequest(shcmsg)))

#define shcIsPreAuthConfRsp(shcmsg) \
	((shcGetProcessCode((shcmsg)->msg.pcode) == SH_ISO_PREAUTHCONF) && \
	 (shcIsResponse(shcmsg)))

#define shcIsCreditTxn(shcmsg)	\
	((shcmsg)->msg.pos_condition_code & SH_POS_COND_CREDIT_TXN)

#define shcIsEDC(shcmsg)	((shcmsg)->msg.device_cap & SH_DEVCAP_EDC)

#define shcHasSegment(shcmsg) \
		((shcmsg)->msg.device_cap & SH_DEVCAP_USER_SEGMENT)

#define shcIsTERMINALREV(shcmsg) \
	((shcmsg)->msg.formatter_devcap & SH_FORMATDEVCAP_TERMINALREV)	//	R018983

/* R006365 */
#define shcIsDUKPT(shcmsg) \
	((shcmsg)->msg.device_devcap & SH_DEVCAP_TERMINALDUKPT)

/* 10002273 */
/* 961108 */
#define shcIsIBFT(shcmsg)	((shcmsg)->msg.shc_devcap & SH_DEVCAP_SHC_IBFT)
//	((shcmsg)->msg.shc_devcap & SH_DEVCAP_SHC_DU((shcIsTransfer((shcmsg)->msg.pcode) || \
//	shcIsTransfer((shcmsg)->msg.origpcode)) && \
//	atol((shcmsg)->msg.transferee) > 0 )))

#define shcIsIBFTW(shcmsg)	((shcmsg)->msg.shc_devcap & SH_DEVCAP_SHC_IBFTW)
#define shcIsIBFTD(shcmsg)	((shcmsg)->msg.shc_devcap & SH_DEVCAP_SHC_IBFTD)

#define shcIsDualFirstMsg(shcmsg)	((shcmsg)->msg.shc_devcap & SH_DEVCAP_SHC_DUAL_FIRST_MSG)
#define shcIsDualSecondMsg(shcmsg)	((shcmsg)->msg.shc_devcap & SH_DEVCAP_SHC_DUAL_SECOND_MSG)

										/* R008041 >> */
#define has_shclog_add(shcmsg)  \
		( ((shcmsg)->msg.device_devcap & SH_DEVICE_LOG_SHCLOG_ADD) \
		&& ((shcmsg)->msg.device_cap & SH_DEVCAP_USER_SEGMENT) )

#define has_shclog_cheque(shcmsg)  \
		( ((shcmsg)->msg.device_devcap & SH_DEVICE_LOG_SHCLOG_CHEQUE) \
		&& ((shcmsg)->msg.device_cap & SH_DEVCAP_USER_SEGMENT) )

										/* R008041 << */
#define has_shclog_vfrs(shcmsg)  \
        ( ((shcmsg)->msg.device_devcap & SH_DEVICE_LOG_SHCLOG_VFRS) \
        && ((shcmsg)->msg.device_cap & SH_DEVCAP_USER_SEGMENT) )
                                        /* R010373 */
#define has_shclog_ifd(shcmsg)  \
        ( ((shcmsg)->msg.device_devcap & SH_DEVICE_LOG_SHCLOG_IFD) \
        && ((shcmsg)->msg.device_cap & SH_DEVCAP_USER_SEGMENT) )
										/* R011615 */
/* R011824 >> */
#define has_shclog_mc(shcmsg)  \
		( ((shcmsg)->msg.device_devcap & SH_DEVICE_LOG_SHCLOG_MC) \
		&& ((shcmsg)->msg.device_cap & SH_DEVCAP_USER_SEGMENT) )

#define set_shclog_mc(shcmsg)  \
		( (shcmsg)->device_devcap |= SH_DEVICE_LOG_SHCLOG_MC )

/* << R011824 */

#define SHC_TXNTYPE_DEBIT		1
#define SHC_TXNTYPE_CREDIT		2
#define SHC_TXNTYPE_INQUIRY		3
#define SHC_TXNTYPE_TRANSFER	4
#define SHC_TXNTYPE_AUTHORIZE	5
#define SHC_TXNTYPE_AUTHENTICATE	6		/* R001538 */

struct	shc_txn_def {
	int		offset;
	int		flag;
	const 	char	*desc;
	int		type;
};

SHCDLLEXPORT extern	struct shc_txn_def shc_txn_def[];

/*------------------------------------------------------------------------*
 *	Allowed account types
 *------------------------------------------------------------------------*/
#define SH_ACCT_SAV				10
#define SH_ACCT_CHEQ			20
#define SH_ACCT_CHECK			SH_ACCT_CHEQ
#define SH_ACCT_CC				30
#define SH_ACCT_CREDIT_LINE		38
#define SH_ACCT_CORPORATE		39
#define SH_ACCT_UNIVERSAL		40
#define SH_ACCT_MONEY_MARKET	50
#define SH_ACCT_INVESTMENT		58
#define SH_ACCT_SPENDING_POWER	64 /* R003638 */
#define SH_ACCT_STORED_VALUE	60
#define SH_ACCT_LOAN			90
#define SH_ACCT_CC_0			0
#define SH_ACCT_DEFAULT			0
#define SH_ACCT_CASH_BENEFIT            96
#define SH_ACCT_WIC         		97
#define SH_ACCT_FOOD            	98
#define	SH_ACCT_FASTCASH		99
#define	SH_ACCT_FASTCASH		99
#define SH_ACC_BATCH_INQUIRY		61
#define SH_ACC_DEBIT_CARD		92
#define	SH_ACC_GIFT_CARD		95

#define shcIsCreditCard(acct)	((acct) == SH_ACCT_CC)
#define shcGetFromAcct(pcode)	((pcode) / 100 % 100)
#define shcGetToAcct(pcode)		((pcode) % 100)

//Flag for gShckeysSetDBLock
#define SHCKEYS_DB_LOCK			1
#define SHCKEYS_DB_UNLOCK		2

/*------------------------------------------------------------------------*
 *	Bin types in the shcbin sql table
 *------------------------------------------------------------------------*/
#define SH_DEVICE_WILL_ACK		0x00000001
#define	SH_USES_MAC_KEY			0x00000002
#define SH_USES_PIN_KEY			0x00000004
#define SH_USES_KEYS			(SH_USES_PIN_KEY | SH_USES_MAC_KEY)
#define SH_DEFAULT_ISSUER		0x00000008

#define SH_ALLOW_KEY_EXCHANGE	0x00000010
#define SH_CCSTLMT_AUTH         0x00000020						/* R001387 */
#define SH_CCSTLMT_FIN          0x00000040						/* R001387 */
#define SH_CCSTLMT_SYSTEM       (SH_CCSTLMT_FIN | SH_CCSTLMT_AUTH)/* R001387 */
#define SH_USES_MAC				0x00000020						/* R001014 */
#define SH_USES_KME				0x00000040
#define	SH_USE_EXTBIN			0x00000080

#define SH_PREAUTH_ALLOWED		0x00000100
#define SH_PREAUTH_FORWARD		0x00000200
#define SH_PREAUTH_REVERSE		0x00000400
#define SH_ONUS_BIN				0x00000800

#define SH_FULL_AUTHORIZATION	0x00001000
#define SH_REFUSE_KEY_EXCHANGE	0x00002000
#define SH_INDEX_1				0x00004000
#define SH_INDEX_2				0x00008000
#define SH_SPECIAL_BIN1			0x00010000 /* R003638 */

#define	SH_ISS_ONLY				0x00020000
#define	SH_ACQ_ONLY				0x00040000
#define	SH_NO_LOG				0x00080000

#define	SH_FORWARD_NAK			0x00100000
#define SH_ACQTO_GEN_REV		0x00200000
#define SH_ACQTO_CHK_DUPREV		0x00400000 /* R001002 */
#define SH_FORWARD_MODE		    0x00800000 /* 0001015 */

#define	SH_CHECK_CVV2			0x01000000 /* R001538 */
#define SH_KEYS_REQUIRED        0x02000000
#define SH_KEYS_SHARED          0x04000000
#define SH_KEYS_AS2805		0x08000000

/*		Macros on above flags */
#define shcBinCheckCVV2(pkg) (pkg->bin.bintype & SH_CHECK_CVV2)   /*R001538*/
#define shcBinSetCheckCVV2(pkg) (pkg->bin.bintype |= SH_CHECK_CVV2)/* R001538 */
#define shcBinIsFwdOnly(pkg) (pkg->bin.bintype & SH_FORWARD_MODE) /*0001015*/
#define shcBinIsSpecial1(pkg) (pkg->bin.bintype & SH_SPECIAL_BIN1) /*R003638*/

/* R001387 > */
#define shcCCStlmtAuth(f)   ( ( (f) &  SH_CCSTLMT_SYSTEM ) == SH_CCSTLMT_AUTH)
#define shcCCStlmtFin(f)    ( ( (f) &  SH_CCSTLMT_SYSTEM ) == SH_CCSTLMT_FIN)
#define shcCCStlmtSys(f)    ( ( (f) &  SH_CCSTLMT_SYSTEM )==SH_CCSTLMT_SYSTEM)
#define shcCCStlmtType(f)   ( (f) & SH_CCSTLMT_SYSTEM)
/* R001387 < */

#define shcSetVerifyMac(pkg) (pkg->bin.bintype |= SH_USES_MAC)	/* R001014 */
#define shcIsVerifyMac(pkg) (pkg->bin.bintype & SH_USES_MAC)	/* R001014 */
#define shcSetUseKme(pkg) (pkg->bin.bintype |= SH_USES_KME)
#define shcUseKme(pkg) (pkg->bin.bintype & SH_USES_KME)

/* 960813 */
#define shcIsIssuerOnly(f)	( (f) & SH_ISS_ONLY )
#define shcIsAcquirerOnly(f)( (f) & SH_ACQ_ONLY )
/* 961115 */
#define	_shcBinUseLog(sB)	!(sB->bin.bintype & SH_NO_LOG)
#define	_shcNoIBFTUseLog(s)	( _shcBinUseLog((s)->acqbin) && \
								_shcBinUseLog((s)->issbin) )
#define	_shcIBFTUseLog(s)	( _shcNoIBFTUseLog(s) && \
								_shcBinUseLog((s)->trabin) )
#define	shcUseLog(s)		( shcIsIBFT((struct shc *)(s)) ? \
								_shcIBFTUseLog((struct shc *)(s)) : \
								_shcNoIBFTUseLog((struct shc *)(s)) )
/* 961115 */
#define	shcFwdNak(s)			(s->issbin->bin.bintype & SH_FORWARD_NAK)
#define	shcAcqTOGenRev(s)		(s->issbin->bin.bintype & SH_ACQTO_GEN_REV )

/* 25Apr95, 27jun95
 * Macros for the terminal_trace field.
 * shcMapTerminalTrace() -	If shcmsg->msg.terminal_trace ==
 *							SH_MAP_TERMINAL_TRACE_ZERO, assign 0, return True.
 */
#define shcMapTerminalTrace(shcmsg) \
	(((shcmsg)->msg.terminal_trace == SH_MAP_TERMINAL_TRACE_ZERO) ? \
	shcAssignTerminalTrace(shcmsg) : 0)
#define shcAssignTerminalTrace(shcmsg) \
	(((shcmsg)->msg.terminal_trace=0) ? 1 : 1)

/*------------------------------------------------------------------------*
 *	Defines to go with the flags field on the bin entry
 *------------------------------------------------------------------------*/
#define	SH_CHECKEXP				0x00000001
#define SH_CHECKPIN				0x00000002
#define SH_CHECK_INDIV_HOT		0x00000004
#define SH_SEND500				0x00000008
//#define SH_IS_DEVICE			0x00000010
#define SH_CHECKPIN_STAND_IN	0x00000010
#define SH_IS_NODE				0x00000020	/*	entry is a node not an */
											/*	acquirer */
#define SH_DOWN					0x00000040	/*	entry is down */
#define SH_REPLAY				0x00000080	/*	currently replaying stfwd */
#define SH_KEY_MAC				0x00000100	/*	mac key in exchange */
#define SH_KEY_PIN				0x00000200	/*	pin key in exchange */
#define SH_KEY_EXCHANGE			(SH_KEY_PIN | SH_KEY_MAC)
#define SH_ONLINE_SETTLEMENT	0x00000400
#define SH_CHECKSCODE			0x00000800	/*	check service code on card */
#define SH_CHECKCVV				0x00001000	/*	check CVV on card */
#define SH_VERIFY_CHECK_DIGIT	0x00002000
#define SH_DEBIT_CARD			0x00004000
#define SH_CREDIT_CARD			0x00008000
#define SH_CHECK_RANGE_HOT		0x00010000
#define SH_CHECKHOT				(SH_CHECK_INDIV_HOT | SH_CHECK_RANGE_HOT)
#define SH_CARDALERT_ALWAYS		0x00020000
#define SH_CARDALERT_BYCARD		0x00040000
#define SH_CARDALERT			(SH_CARDALERT_ALWAYS | SH_CARDALERT_BYCARD)
#define SH_TRACE				0x00080000
#define SH_CUTOVER_EXTERNAL		0x00100000
#define SH_ECHOTEST_ALWAYS		0x00200000
#define SH_ECHOTEST_DOWN		0x00400000
#define SH_ECHOTEST				(SH_ECHOTEST_ALWAYS | SH_ECHOTEST_DOWN)
#define SH_GETAPP_HOST          0x00800000  /* get iss approval for reversal */
#define SH_CHKFLRLIM			0x01000000
#define SH_SENDREV				0x02000000
#define SH_SAFAUTH				0x04000000
#define SH_SENDREV_ALWAYS		0x08000000
#define SH_SENDACK				0x10000000
#define SH_PREAUTH_ON_VALIDATE	0x20000000
#define SH_CHECKDUP				0x40000000
#define SH_CURRENCY_CONV		0x80000000
#define SH_FLIP_MSGTYPE         0x400000000L

/************************************************************
 * CVV2 request value defination
 * Used in cvv2_indicator field in struct shc_data
 ************************************************************/
#define CVV2_INTENTIONALLY_NOT_PROVIDED     '0'
#define CVV2_VALUE_IS_PRESENT               '1'
#define CVV2_VALUE_PRESENT_BUT_INVALID      '2'
#define CVV2_VALUE_NOT_IMPRINTED            '9'

/*------------------------------------------------------------------------*
 * Some Useful Macros
 *------------------------------------------------------------------------*/
#define	shcIsTraceOn(pkg)		((pkg)->bin.flags & SH_TRACE)
#define shcTurnTraceOn(pkg)		((pkg)->bin.flags |= SH_TRACE)
#define shcTurnTraceOff(pkg)	((pkg)->bin.flags &= ~SH_TRACE)

#define shcIsDebugOn()			(shcDebugFlag)
#define shcTurnDebugOn()		(shcDebugFlag = 1)
#define shcTurnDebugOff()		(shcDebugFlag = 0)

#define shcNeedsEcho(pkg)		((pkg)->bin.flags & SH_ECHOTEST)
#define shcEchoAlways(pkg)		((pkg)->bin.flags & SH_ECHOTEST_ALWAYS)
#define shcEchoDown(pkg)		((pkg)->bin.flags & SH_ECHOTEST_DOWN)

#define shcPreauthReversalAllowed(shcmsg) \
	(shcmsg->issbin->bin.bintype & SH_PREAUTH_REVERSE)

#define shcPreauthForwardAllowed(shcmsg) \
	(shcmsg->issbin->bin.bintype & SH_PREAUTH_FORWARD)

#define shcPreauthAllowed(shcmsg) \
	(shcmsg->issbin->bin.bintype & SH_PREAUTH_ALLOWED)

#define shcIsFullAuth(shcmsg) \
	(shcmsg->issbin->bin.bintype & SH_FULL_AUTHORIZATION)

/* Ssc - 28Jun00	R004671 integration to 7.2 */
/*------------------------------------------------------------------------*
 * Mch 18Feb00 - 5 macros to allow lookup of the new bin_cfg data
 *------------------------------------------------------------------------*/
#define SH_CFGIX_FULL_ENTRY                10
#define SH_CFGIX_CARD_AUTH                 11
#define SH_CFGIX_ISS_AUTH                  12
#define SH_CFGIX_DECL_AUTH_FAI             13
#define SH_CFGIX_CHIP_LOG                  14
#define SH_CFGIX_EMV_STIP                  15       /* R006940 */
#define SH_CFGIX_FWD_CAPTURE				16
#define SH_CFGIX_ACCOUNT_FUNDING			17		/* R007502 BEGIN */
#define SH_CFGIX_DCVV_CVC3					18		/* R007502 BEGIN */
#define SH_CFGIX_CHECK_MERCHANT		   19	//	---	R020052
#define SH_CFGIX_DCVVCVC3_TYPE             20
#define	SH_CFGIX_REV_LATERESP				21
#define	SH_CFGIX_CAAV_CAVV_VERIFY			22
#define	SH_CFGIX_AMEX_CSC				23
#define SH_CFGIX_ALLOW_ZERO_AMT_PREAUTH                 24
#define	SH_CFGIX_SUBSECOND_TIMEOUT			25
#define SH_CFGIX_ON_DOT						26
#define SH_CFGIX_CAAV_CAVV_3DS_VERIFY			27
#define SH_CFGIX_CAAV_CAVV_3DS_VERIFY_STAND_IN_ONLY		28
#define SH_CFGIX_TOKEN_TXN_CHK				29
#define SH_CFGIX_KPE_KEYBLOCK 				30
#define SH_CFGIX_ENABLE_REFNUM_EVENTKEY			31

/* Mch 29Feb00 R2007336 - bug fix. */
#define SH_CFG_FULL_ENTRY                 0x00000200
#define SH_CFG_CARD_AUTH                  0x00000400
#define SH_CFG_ISS_AUTH                   0x00000800
#define SH_CFG_DECL_AUTH_FAI              0x00001000
#define SH_CFG_CHIP_LOG                   0x00002000
#define SH_CFG_EMV_STIP                   0x00004000
#define SH_CFG_ACCOUNT_FUNDING			  0x00008000	/* R007502 */


//Flags stored in addflag
#define SH_ADDFLAG_TIMEOUT_DECISECOND		0x0001
#define SH_ADDFLAG_CAVV_MASK				0x0070
#define SH_ADDFLAG_HMAC_MAS					0x0010
#define SH_ADDFLAG_CVC2_MAS    				0x0020
#define SH_ADDFLAG_HMAC_VIS                	0x0030
#define SH_ADDFLAG_CAVV_VIS                	0x0040
#define SH_ADDFLAG_AMEX_CSC                	0x0050
#define SH_ADDFLAG_HMAC_MAS_DECL		0x0100
#define SH_ADDFLAG_CVC2_MAS_DECL		0x0200
#define SH_ADDFLAG_HMAC_VIS_DECL		0x0300
#define SH_ADDFLAG_CAVV_VIS_DECL		0x0400

#define SH_ADDFLAG_CAVV_3DS_SPA2_MASK		0xF000
#define SH_ADDFLAG_CAVV_SPA2_APPROVE		0x1000
#define SH_ADDFLAG_CAVV_SPA2_DECLINE		0x2000
#define SH_ADDFLAG_CAVV_VIS_3DS_APPROVE		0x4000
#define SH_ADDFLAG_CAVV_VIS_3DS_DECLINE		0x8000


#define shcIsFullEntry(pkg)     (pkg && (pkg->bin.bin_cfg & SH_CFG_FULL_ENTRY))
#define shcIsVerifyARQCReq(pkg) (pkg && (pkg->bin.bin_cfg & SH_CFG_CARD_AUTH))
#define shcIsGenARPCReq(pkg)    (pkg && (pkg->bin.bin_cfg & SH_CFG_ISS_AUTH))
#define shcDeclineIfARQCFails(pkg) (pkg && (pkg->bin.bin_cfg & SH_CFG_DECL_AUTH_FAI))
#define shcLogChipData(pkg)     (pkg && (pkg->bin.bin_cfg & SH_CFG_CHIP_LOG))
#define shcIsCavvCaavRequired(pkg)     (pkg && (pkg->bin.addflag & SH_ADDFLAG_CAVV_MASK))
/* Mch 18Feb00 -End-------------------------------------------------------*/
/* R006940 Emj 02Nov EMV STIP */

#define shcEmvStip(pkg)     (pkg && (pkg->bin.bin_cfg & SH_CFG_EMV_STIP))

/* Ssc - 28Jun00	R004671 integration to 7.2 */
/* Mch 24Feb00 -----------------------------------------------------------*/

/* Determine if it is a chip transaction */
/* Rpc 07Mar00 shcIsChipTxn check if F22(pos_entry_code) is 5 or 95 to indicate
    if it's VSDC chip transaction */
int shcmsgIsChipTxn(struct shcmsg *msg);
class ShcmsgHeader;
extern int shcmsgHeaderIsChipTxn(ShcmsgHeader *h);
#define shcIsChipTxn(shcmsg) \
		(shcmsgIsChipTxn(&((shcmsg)->msg)))
//    ((((shcmsg)->msg.pos_entry_code & SH_POS_PINPANENTRY_MASK) / 10 == 5)|| \
//    (((shcmsg)->msg.pos_entry_code & SH_POS_PINPANENTRY_MASK) / 10 == 7)|| \
//    (((shcmsg)->msg.pos_entry_code & SH_POS_PINPANENTRY_MASK) / 10 == 95 ))
/* Mch 24Feb00 -End-------------------------------------------------------*/


/* Card Scheme D3finitions */
#define VISA_CARD_SCHEME		"04"
#define MASTERCARD_CARD_SCHEME	"05"
#define EUROPAY_CARD_SCHEME		"06"
#define RAFT_SCHEME		"21"

#define DISCOVER_CARD_SCHEME		"08"
#define CHASE_CARD_SCHEME			"25"
#define CHASE_DEBIT_CARD_SCHEME		"26"

#define CHASE_PIN_DEBIT_SCHEME		"27"
#define CHASE_PINLESS_DEBIT_SCHEME	"28"

/* mailbox names of other servers */
#define ADVICE_SERVER_MBOX_NAME		"AdviceServer"
#define ACCUMULATION_SERVER_MBOX_NAME	"AccumulationServer"

/*------------------------------------------------------------------------*
 *	Define the values of shcmsg.shcerr
 *	This variable is used to indicate internal progress during the
 *	processing of a transaction
 *------------------------------------------------------------------------*/
#define SH_SENDISS 				0x00000001		/*	send to issuer */
#define SH_STOP					0x00000002		/*	stop processing */
#define SH_SENDACQ				0x00000004		/*	return to sender */
#define SH_SETTIMER				0x00000008		/*	set a timer on txn */
#define SH_IGNORE				0x00000010		/*	ignore this error */
#define SH_RETURN				0x00000020		/*	return to sender */
#define SH_NOROUTE				0x00000040		/*	do not reply to acq */
#define SH_CONTINUE				0x00000080		/*	used to cont. processing */
#define SH_SENDAPPL				0x00000100		/*	send to ext. appl. */
#define SH_NO_TIMER_PRESENT		0x00000200
#define SH_TIMER_PRESENT		0x00000400
#define SH_NOREVUPD				0x00000800
#define SH_SENDTRA 				0x00001000		/* 	send to transferee */
#define SH_RECON				0x00002000		/* sent to reconcillation */
#define SH_SENDAPPLBIN          0x00004000      /*  send to ext. appl. through a bin*/
#define SH_ASYNCH_RESUME		0x00008000		// Resume txn from Async processing

/*------------------------------------------------------------------------*
 *	Define the type of transactions we process
 *------------------------------------------------------------------------*/
#define shcIsDeviceAck(shcmsg)			(((shcmsg)->msg.msgtype/1000 % 10) == 9)
#define shcIsAuthorizationRequest(shcmsg)	(((shcmsg)->msg.msgtype / 100) == 1)
#define shcIsFinancialRequest(shcmsg)		(((shcmsg)->msg.msgtype / 100) == 2)
#define shcIsFileUpdateRequest(shcmsg)		(((shcmsg)->msg.msgtype/100)%10==3)
#define shcIsIstAuthFileUpdateMessage(shcmsg)		( (((shcmsg)->msg.msgtype/100)%10==3) &&  (((shcmsg)->msg.msgtype/1000 % 10) == 7) )
#define shcIs03xx(shcmsg)					shcIsFileUpdateRequest(shcmsg)
#define shcIsReversal(shcmsg)				(((shcmsg)->msg.msgtype / 100) == 4)
#define shcIsSettlement(shcmsg)				(((shcmsg)->msg.msgtype / 100) == 5)
#define shcIsAdmin(shcmsg)					(((shcmsg)->msg.msgtype / 100) == 6)
#define shcIsRequest(shcmsg)				(!shcIsResponse((shcmsg)))
#define shcIsAdviceResp(shcmsg) ((shcmsg)->msg.msgtype == SHC_FINREQ_ADVICE_RESPONSE)
/* Ssc - 28Jun00	R004671 integration to 7.2 */
/* Ssc - 17Apr00    SPR # 2007336 Create macro to check 130,230 and 430 txn */
#define shcIsAdviceRespInclu(shcmsg)\
    ((shcmsg)->msg.msgtype == SHC_FINREQ_ADVICE_RESPONSE || \
     (shcmsg)->msg.msgtype == SHC_AUTHREQ_ADVICE_RESPONSE || \
     (shcmsg)->msg.msgtype == SHC_REVREQ_ADVICE_RESPONSE)

// >>> R026315 : Created new macro to check 230/130 messages
#define shcIsFinOrAuthAdviceResp(shcmsg)\
	((shcmsg)->msg.msgtype == SHC_FINREQ_ADVICE_RESPONSE || \
	(shcmsg)->msg.msgtype == SHC_AUTHREQ_ADVICE_RESPONSE )
// <<< R026315

#define shcIsRevAdviceResp(shcmsg) ((shcmsg)->msg.msgtype == SHC_REVREQ_ADVICE_RESPONSE)
#define shcIsAdvice(shcmsg) ((shcmsg)->msg.msgtype == SHC_AUTHREQ_ADVICE || \
							 (shcmsg)->msg.msgtype == SHC_FINREQ_ADVICE)
//	>>>	R016047; Created new macro to check 120/121/220/221/420/421 messages
#define shcIsAllAdvice(shcmsg) ((shcmsg)->msg.msgtype == SHC_AUTHREQ_ADVICE || \
				(shcmsg)->msg.msgtype == SHC_AUTHREQ_ADVICE_REPEAT || \
				(shcmsg)->msg.msgtype == SHC_FINREQ_ADVICE || \
				(shcmsg)->msg.msgtype == SHC_FINREQ_ADVICE_REPEAT || \
				(shcmsg)->msg.msgtype == SHC_REVREQ_ADVICE || \
				(shcmsg)->msg.msgtype == SHC_REVREQ_ADVICE_REPEAT )
//	<<<	R016047
#define shcIsCustomerRequest(shcmsg)\
	(shcIsAuthorizationRequest((shcmsg)) || shcIsFinancialRequest((shcmsg)))

/*	A response has an odd digit in the 10's position */
#define shcIsResponse(shcmsg)		( ((shcmsg)->msg.msgtype / 10 % 10) & 1)
#define shcIsNetwork(shcmsg)		(((shcmsg)->msg.msgtype / 100) == 8)
#define shcIsLogRequest(shcmsg) \
	(((shcmsg)->msg.msgtype - ((shcmsg)->msg.msgtype % 1000)) == SHC_LOGREQ)
#define shcIsRevAdvice(shcmsg) ((shcmsg)->msg.msgtype == SHC_REVREQ_ADVICE)

#define shcIsPreauthServReq(shcmsg)\
	((shcmsg)->msg.msgtype == SHC_PREAUTH_SERVICEREQ)

#define shcIsPreauthServRsp(shcmsg)\
	((shcmsg)->msg.msgtype == SHC_PREAUTH_SERVICERSP)

#define PreauthServInsRec		1
#define PreauthServRetRec		2

#define shcIsPreauthServRetRsp(shcmsg)\
	(((shcmsg)->msg.netcode == PreauthServRetRec) && (shcIsPreauthServRsp))

#define shcIsPreauthServInsRsp(shcmsg)\
	(((shcmsg)->msg.netcode == PreauthServInsRec) && (shcIsPreauthServRsp))

/*------------------------------------------------------------------------*
 * Message Number Define Block
 *------------------------------------------------------------------------*/
#define SHC_AUTHREQ							100
#define SHC_AUTHREQ_REPEAT					101
#define SHC_AUTHCOMP						102	/* auth. complet confirm */
#define SHC_AUTHCOMP_REPEAT					103
#define SHC_AUTHREQ_RESPONSE				110
#define SHC_AUTHCOMP_RESPONSE				112
#define SHC_AUTHREQ_ADVICE					120
#define SHC_AUTHREQ_ADVICE_REPEAT			121
#define SHC_AUTHREQ_ADVICE_CMP				122
#define SHC_AUTHREQ_ADVICE_CMP_REPEAT		123
#define SHC_AUTHREQ_ADVICE_RESPONSE			130
#define SHC_AUTHREQ_ADVICE_CMP_RESPONSE		132
#define SHC_AUTHREQ_ACK						180
#define SHC_AUTHREQ_NAK						190

#define	SHC_FINREQ							200
#define SHC_FINREQ_REPEAT					201
#define SHC_FINREQ_COMP						202
#define SHC_FINREQ_COMP_REPEAT				203
#define SHC_FINREQ_RESPONSE					210
#define SHC_FINREQ_COMP_RESPONSE			212
#define SHC_FINREQ_ADVICE					220
#define SHC_FINREQ_ADVICE_REPEAT			221
#define SHC_FINREQ_ADVICE_COMP				222
#define SHC_FINREQ_ADVICE_COMP_REPEAT		223
#define SHC_FINREQ_ADVICE_RESPONSE			230
#define SHC_FINREQ_ADVICE_COMP_RESPONSE		232
#define SHC_FINREQ_ACK						280
#define SHC_POSAUTH_REQ						270 /*Internal propritarie */
#define SHC_POSAUTH_RESPONSE				280 /*Internal propritarie */

#define SHC_FILEUPD_ACQREQ					300
#define SHC_FILEUPD_ACQREQ_RESPONSE			310
#define SHC_FILEUPD_ISSREQ					302
#define SHC_FILEUPD_ISSREQ_RESPONSE			312
#define SHC_FILEUPD_ACQREQ_ADVICE			320
#define SHC_FILEUPD_ACQREQ_ADVICE_RESP		330
#define SHC_NEGATIVEFILE_ADVICE_MSG         324
#define SHC_NEGATIVEFILE_ADVICE_RESP        334
#define SHC_LOCAL_FILEUPD_ISSREQ           	382
#define SHC_LOCAL_FILEUPD_ISSREQ_RESPONSE	392

#define SHC_REVREQ							400
#define SHC_REVREQ_REPEAT					401
#define SHC_REVREQ_RESPONSE					410
#define SHC_REVREQ_ADVICE					420
#define SHC_REVREQ_ADVICE_REPEAT			421
#define SHC_REVREQ_ADVICE_RESPONSE			430
#define SHC_CHARGE_BACK_ADVICE				422 /* qd 26may97 */
#define SHC_CHARGE_BACK_ADVICE_RESPONSE		432 /* qd 26may97 */

#define SHC_STLMTREQ						500
#define SHC_STLMTREQ_RESPONSE				510
#define SHC_STLMTREQ_ADVICE					520
#define SHC_STLMTREQ_ADVICE_REPEAT			521
#define SHC_STLMTREQ_ISSUER_ADVICE			522
#define SHC_STLMTREQ_ISSUER_ADVICE_REPEAT	523
#define SHC_STLMTREQ_ADVICE_RESPONSE		530
#define SHC_STLMTREQ_ISSUER_ADVICE_RESPONSE	532
#define SHC_STLMTREQ_EDC					502
#define SHC_STLMTREQ_EDC_RESPONSE			512

#define SHC_ADMIN							600
#define SHC_ADMIN_RESPONSE					610
#define SHC_ADMIN_ADVICE					620
#define SHC_ADMIN_ADVICE_RESPONSE			630
#define SHC_ISS_ADMIN						602  /* qd 24nov97 ACXSYS */
#define SHC_ISS_ADMIN_RESPONSE				612  /* qd 24nov97 ACXSYS */
#define SHC_ISS_ADMIN_ADVICE				622  /* qd 24nov97 ACXSYS */
#define SHC_ISS_ADMIN_ADVICE_RESPONSE		632  /* qd 24nov97 ACXSYS */
#define SHC_FRS_ADVICE						9620 /* R010373 */
#define SHC_FRS_ADVICE_RESPONSE				9630 /* R010373 */

#define SHC_NETWORK							800
#define SHC_NETWORK_RESPONSE				810
#define SHC_NETWORK_ADVICE					820
#define SHC_NETWORK_ADVICE_RESPONSE			830
#define SHC_NETWORK_ADVICE_REPEAT			821
#define SHC_REPRESENTMENT_ADVICE_MSG                    282
#define SHC_REPRESENTMENT_ADVICE_RESP                   292

#define SHC_NETWORK_PORT_NOTIFICATION		2800
#define SHC_STANDIN_DECISION_BY_ISS_RESP_NOTIFICATION   2900
#define SHC_STANDIN_DECISION_BY_ISS_RESP_NOTIFICATION_EVENT   12900
#define	SHC_LATE_RESPONSE		            6000 /* added to message number */

#define SHC_PREAUTH_REQ						7100
#define SHC_PREAUTH_RESP					7110
#define SHC_PREAUTH_SERVICEREQ				7200
#define SHC_PREAUTH_SERVICERSP				7210

#define	SHC_SERVICE_HIGHVALUE	            8099 /*	ad: 21may93 */
#define SHC_LOGREQ				            8000 /*	log the message */
#define	SHC_PRIVATE_NEWDATE		            8001 /*	date in settlement_date */
#define SHC_SERVICE_REQUEST		            8002

//	>>>	R020052
#define SHC_FM_REQ		8100
#define SHC_FM_RESP		8110
#define SHC_FM_CMD_REQ		8200
#define SHC_FM_CMD_RESP 	8210
#define SHC_FM_INST_REQ 	8300
#define SHC_FM_INST_RESP	8310
//	<<<	R020052

//	>>>	R020938
#define SHC_LM_REQ      	8400
#define SHC_LM_RESP     	8410
#define SHC_LM_REVREQ      	8420
#define SHC_LM_REVRESP     	8430
#define SHC_LM_LATEREQ     	8422
#define SHC_LM_LATERESP     8432
//	<<<	R020938

#define SHC_ISTAUTH_FILE_UPD_REQ					7304
#define SHC_ISTAUTH_FILE_UPD_RESP					7314
#define SHC_ISTAUTH_FILE_UPD_REQ_REPEAT				7305
#define SHC_ISTAUTH_FILE_UPD_REQ_REPEAT_RESP		7315

#define SHC_KEY_GRACE_PERIOD                    8500
#define SHC_OD_REQ            8600    //Online request
#define SHC_OD_RESP           8610	  //Online/final-response response
#define SHC_OD_LATERESP       8630    //Late Response from On Dot


#define SHC_DEVICE_ACK			            9000
#define SHC_DEVICE_NAK			            9001

#define SHC_EVENT				            10000

/*------------------------------------------------------------------------*
 *	Define some values for the service request
 *------------------------------------------------------------------------*/
#define	shcServiceReadRecord		1
#define shcServiceGetRoute			2
#define shcServiceReadRefnum		3
#define shcServiceMatchShclog		4
#define shcServiceRouteIssuer		5
#define shcServiceRouteAcquirer		6
#define shcServiceInvalidPIN		7
#define shcServiceRouteToSender		8
#define shcServiceManageToIssuer	9
#define shcServiceManageToAcquirer	10
#define shcServiceRespondToSender	11
#define shcServiceMarkCardStatus	12
#define shcServiceRouteToOnUsIssuer	13
#define shcServiceUpdateRespcode	14						/* 21jul95 */
/* Note: 15,16,17 are used for Suspect Matrix; to be merged. 30Oct97 */
#define	shcServiceProcessOn			18						/* 30Oct97 */
#define	shcServiceProcessOff		19						/* 30Oct97 */
#define	shcServiceReplayFast		20		/* qd 24nov97 ACXSYS */
#define	shcServiceReplaySlow		21	    /* qd 24nov97 ACXSYS */

/*------------------------------------------------------------------------*
 * Statistics values
 *------------------------------------------------------------------------*/
#define	SH_STAT_AUTHREQ						0
#define SH_STAT_AUTHREQ_RESPONSE			1
#define SH_STAT_FINREQ						2
#define SH_STAT_FINREQ_RESPONSE				3
#define SH_STAT_REVREQ						4
#define SH_STAT_REVREQ_RESPONSE				5
#define SH_STAT_NETWORK						6
#define SH_STAT_NETWORK_RESPONSE			7

/*------------------------------------------------------------------------*
 *	Define 800 network values (netcode)
 *------------------------------------------------------------------------*/
#define SHC_NET_SIGNON						1
#define SHC_NET_SIGNON_ISSUER                                   9035
#define SHC_NET_SIGNOFF						2
#define SHC_NET_SIGNOFF_ISSUER                                  9065
#define SHC_NET_START_SAF					60
#define SHC_NET_STOP_SAF					61
#define SHC_NET_ENTER_SI					62
#define SHC_NET_EXIT_SI						63
#define SHC_NET_GROUP_SIGNON				64
#define SHC_NET_GROUP_SIGNOFF				65
#define SHC_NET_CLOSE_BATCH					66
#define SHC_NET_CLOSE_DAY					67
#define SHC_NET_GET_TOTALS					68
#define SHC_NET_EU_REJECT                   69  /* Europay Reject */
#define SHC_NET_SIGNON_START				9001 /*	Internal numbers	*/
#define SHC_NET_SIGNOFF_START				9002 /*	Internal numbers	*/
#define SHC_NET_GROUPSIGNON_START			9061 /*	Internal numbers	*/
#define SHC_NET_GROUPSIGNOFF_START			9062 /*	Internal numbers	*/
#define SHC_NET_GROUP_SIGNON_CR				9063 /* R004120 */
#define SHC_NET_GROUP_SIGNOFF_CR			9064 /* R004120 */
#define SHC_NET_MARKDOWN					9070
#define SHC_NET_CLOSE_BATCH_START			9066
#define SHC_NET_CLOSE_DAY_START				9067
#define SHC_NET_GET_TOTALS_START			9068
#define	SHC_NET_PREFIX_SIGNON				9075	//	---	R024361
#define	SHC_NET_PREFIX_SIGNOFF				9076	//	---	R024361
#define SHC_NET_HOST_SESSION_DEACT                      9082

#define SHC_NET_KEYS_START					9161
#define SHC_NET_KEYS_START_2LEG             9162
#define SHC_NET_KEYS_REQ_SINGLE_LEG			9165
#define SHC_NET_KEYS						161
#define SHC_NET_KEYS_ACQUIRER				160 /* zm 10feb98 scr 651 */
#define SHC_NET_KEYS_ISSUER					161 /* zm 10feb98 scr 651 */
#define SHC_NET_KEYS_ACQUIRER_VALIDATION	162 /* zm 10feb98 scr 651 */
#define SHC_NET_KEYS_ISSUER_VALIDATION		163 /* zm 10feb98 scr 651 */
#define	SHC_NET_KEY_VALIDATION				162

#define SHC_SPAN_KEYS						101
#define SHC_SPAN_KEYS_START					9101

#define SHC_NET_KEYREQ						180
#define SHC_NET_KEYREQ_START				9180

#define SHC_NET_TERM_KEY					191
#define SHC_NET_TERM_KEY_START				9191

#define	SHC_NET_CUTOVER						201
#define	SHC_NET_CUTOVER_START				9201

#define SHC_NET_CUTOVER_COMPLETE			202
#define SHC_NET_CUTOVER_COMPLETE_START		9202
#define SHC_REQUEST_ADVICE					261

#define SHC_NET_ECHO						301
#define SHC_NET_ECHO_ISSUER                                     9302
#define SHC_NET_ECHO_START					9301
#define SHC_NET_AUTH_DELAY					361
#define SHC_NET_FIN_DELAY					362
#define SHC_NET_SAF_EOF						363 /* copy it from ncrrps */

#define SHC_NET_STARTREPLAY					900
#define SHC_NET_CONTINUE_SIGNON				901
#define SHC_NET_ABORT_KEY					902
#define SHC_NET_DONE_KEY					903
#define SHC_NET_STOPREPLAY					904
#define SHC_TKN_REQ                                            	890

/* IST_ROLE definitions are stored in from_acct field in shcmsg */
#define	IST_ROLE_DEVICE_MASK  	0x000f
#define	IST_ROLE_ATM    		0x0001
#define	IST_ROLE_POS    		0x0002
#define	IST_ROLE_OTHER  		0x0004

#define	IST_ROLE_TYPE_MASK   	0x00f0
#define	IST_ROLE_ACQ     		0x0010
#define	IST_ROLE_ISS     		0x0020
#define	IST_ROLE_SW      		0x0040

#define IST_ROLE_COMBINED_MASK 0x0f00
#define IST_ROLE_COMBINED_MSG  0x0100
#define IST_ROLE_COMBINED_BAL  0x0200

#define RETURN_RESP_TO_SENDER  0x1000

/*------------------------------------------------------------------------*
 *	Values for key type in format_code[0]
 *------------------------------------------------------------------------*/
#define SH_KEYTYPE_PIN						'P'					/* 7oct97 */
#define SH_KEYTYPE_MAC						'M'
#define SH_KEYTYPE_KME						'K'					/* 7oct97 */
#define SH_KEYTYPE_PIN_BOTH					'B'					/* 7oct97 */
#define SH_KEYTYPE_PIN_ACQ					'A'					/* 7oct97 */
#define SH_KEYTYPE_PIN_ISS					'I'					/* 7oct97 */
#define SH_KEYSTAT_ACTIVE					'A'					/* 7oct97 */
#define SH_KEYSTAT_STATIC					'S'
#define SH_KEYSTAT_INACTIVE					'I'					/* 7oct97 */
#define SH_KEYSTAT_EXCHANGE					'X'					/* 7oct97 */
#define SH_KEYSTAT_MARKED					'M'					/* R001387 */
#define SH_KEYSTAT_RETRY 					'R'					/* R001387 */
#define SH_KEYIDX_CURRENT					'0'					/* R001072 */
#define SH_KEYIDX_NEXT      				'+'					/* R001072 */

#define SH_SPAN_PIN_KEY						'1'
#define SH_SPAN_MAC_KEY						'3'
#define SH_SPAN_ACQ							'A'
#define SH_SPAN_ISS							'I'

/*------------------------------------------------------------------------*
 *	Define values for authorization type flag
 *------------------------------------------------------------------------*/
#define	SHC_AUTHTYPE_FULL						1
#define SHC_AUTHTYPE_PREAUTH					2
#define SHC_AUTHTYPE_COMPLETE_PASSTHRU			3
#define SHC_AUTHTYPE_MGT_PASSTHRU				4

#define SHC_DBAUTH_FULL							"FULL"
#define SHC_DBAUTH_PREAUTH						"PREA"
#define SHC_DBAUTH_COMPLETE_PASSTHRU			"PASS"
#define SHC_DBAUTH_MGT_PASSTHRU					"MPAS"

#define shcIsPassThrough(pkg)	((pkg)->auth.type == SHC_AUTHTYPE_COMPLETE_PASSTHRU || (pkg)->auth.type == SHC_AUTHTYPE_MGT_PASSTHRU)

#define shcRequiresPreAuthorization(pkg) \
	( (pkg)->auth.type == SHC_AUTHTYPE_PREAUTH && (pkg)->auth.authserver >= 0)

/*------------------------------------------------------------------------*
 *	Values for the pos_capability fields
 *------------------------------------------------------------------------*/
 /*
 *						Added:
 *							SH_POS_PANENTRY_ECOMMERCE
 *							SH_POS_PINPANENTRY_MASK
 *							SH_POS_DATAENTRY_MASK
 *							SH_POS_DATAENTRY_NOTERM
 *							SH_POS_DATAENTRY_MAGSTRIP
 *							SH_POS_DATAENTRY_BARCODE
 *							SH_POS_DATAENTRY_CHARRECOG
 *							SH_POS_DATAENTRY_KEYENTRY
 *							SH_POS_DATAENTRY_ICC
 *							SH_POS_COND_REQ_MASK
 *							SH_POS_COND_REQ_ELECT
 *							SH_POS_COND_REQ_PHONE
 *							SH_POS_COND_REQ_STAND
 *							SH_POS_COND_TERMHOMEPC
 *							SH_POS_COND_NOTERM
 *							SH_POS_CAP_NOTERM
 *							SH_POS_CAP_CAT_MASK
 *							SH_POS_CAP_CAT_ADMWITHPIN
 *							SH_POS_CAP_CAT_SELFSERV
 *							SH_POS_CAP_CAT_LIMITEDAMT
 *							SH_POS_CAP_CAT_INFLIGHT
 *						Changed:
 * 							SH_POS_COND_REQ_MAIL
 * 							SH_POS_COND_MANREV
 * 							SH_POS_COND_TERMERROR
 * 							SH_POS_COND_REQ_PREAUTH
 *						Removed:
 *							SH_POS_COND_REQ_DOWNSUB
 *							SH_POS_COND_REQ_RESUB
 *							SH_POS_COND_MERCHAUTH
 *							SH_POS_COND_CASHBACK
 */
#define SH_POS_PANENTRY_UNKNOWN			0
#define SH_POS_PANENTRY_MANUAL			1
#define SH_POS_PANENTRY_MAGSTRIP		2
#define SH_POS_PANENTRY_BARCODE			3
#define SH_POS_PANENTRY_OCR				4
#define SH_POS_PANENTRY_IC				5	/*	integerated cicuit */
#define SH_POS_PANENTRY_KEY				6
#define SH_POS_PANENTRY_MANUALICC      79
#define SH_POS_PANENTRY_ECOMMERCE      81   /*  R001538               */
#define SH_POS_PANENTRY_ECOMMERCE80    80   /*  R003313               */
#define SH_POS_PANENTRY_TRK1OR2	       90   /*  cvv checking 23Mar93  */
#define SH_POS_PANENTRY_PRE_REG_CHECKOUT_SERVICE	93	//	---	R029153 Stored Value from Pre-Registered Checkout Service
/* R010532 >> */
//Use shcmsgIsContactless() to decide whether it's contactless transaction.
#define SH_POS_PANENTRY_CONTACTLESS_IC			 7
#define SH_POS_PANENTRY_CONTACTLESS_MAGSTRIP	91
#define SH_POS_PANENTRY_CONTACTLESS_PAYPASS		92
#define SH_POS_PANENTRY_QRC_CHIP_INCLUDED		89
#define SH_POS_PANENTRY_QRC_CHIP_EXCLUDED		94
/* << R010532 */
//	>>>	R025862
#define	SH_POS_PANENTRY_IC_PAYPASS		56
#define	SH_POS_PANENTRY_CONTACTLESS_IC_PAYPASS	8
//	<<<	R025862

/*For Mastercard Interface */
#define SH_POS_PANENTRY_ECOM_MOBILE_INITIATED 	82	//	---		R028473
#define SH_POS_PANENTRY_ECOM_WITH_REMOTE_CHIP   9       //      ---             R032558

#define SH_POS_PANENTRY_BLUETOOTH_LOW_ENERGY   10

/*For Discover Interface */
#define SH_POS_PANENTRY_CONTACTLESS_INTERFACE_CHANGE  86

//  >>> R022506
/*  For Discover Interface  */
#define SH_POS_PANENTRY_CPMAGSTRIPDEF           96
#define SH_POS_PANENTRY_RFID                    97
#define SH_POS_PANENTRY_MCOMMERCE               98
#define SH_POS_PANENTRY_VOICEAUTH               99
#define SH_POS_PANENTRY_VRU                     100
#define SH_POS_PANENTRY_BATCHAUTH               101
#define SH_POS_PANENTRY_BATCHAUTH_CASHACCESS    102
#define SH_POS_PANENTRY_BIOMETRICS              103

#define SH_POS_PANENTRY_STORED_CREDENTIAL		87	

//  <<< R022506
/*For Visa Interface */
#define SH_POS_PANENTRY_CREDENTIAL_FILE                 10

/* For IST RAFT Interface */
#define SH_POS_PANENTRY_TRANSTERMINAL            11
#define SH_POS_PANENTRY_RAFT_RFID                     85

/* For PSO Interface */
#define SH_POS_PANENTRY_CHIP_CARD_READ		88

/* Ssc 29Jun00  R004671 VSDC integration 7.2 */
#define SH_POS_PANENTRY_UNIC           95   /*  R2007336 Sli 24Feb00  */
#define SH_POS_PANENTRY_TRANSIT_ACCESS_TERMINAL    11
#define SH_POS_PANENTRY_CREDIT_EMD                 85
#define SH_POS_PINENTRY_UNKNOWN			0
#define SH_POS_PINENTRY_HASCAP			1	/*	terminal has capability */
#define SH_POS_PINENTRY_NOCAP			2	/*	no capability */
#define SH_POS_PINENTRY_INOPERATIVE		8	/*	has cap. but is inoperative */
#define SH_POS_PINENTRY_VERIFIED		9	/*	verified by device */
#define SH_POS_PINENTRY_CONTACTLESS_IC          7
										/* R007894 >> */
#define SH_POS_PINENTRY_ESIGNITURE        3
#define SH_POS_PINENTRY_BIOMETRICS        4
#define SH_POS_PINENTRY_BIOGRAPHICS       5
#define SH_POS_PINENTRY_OTHER             6
										/* R007894 << */
/* R001538 BEGIN*/
#define SH_POS_PINPANENTRY_MASK 	0x03ff  /* Mask for PANENTRY/PINENTRY */
#define SH_POS_DATAENTRY_MASK		0xfc00  /* Mask for DATAENTRY */
#define SH_POS_DATAENTRY_NOTERM		0x0400  /* No Terminal used */
#define SH_POS_DATAENTRY_MAGSTRIP	0x0800  /* Magnetic stripe reader */
/* R010532 >> */
#define SH_POS_DATAENTRY_CONTACTLESS_ICC		0x1000  /* Contactless M/Chip */
#define SH_POS_DATAENTRY_CONTACTLESS_MAGSTRIP	0x2000  /* Contactless Magnetic Stripe */
/* << R010532 */
#define SH_POS_DATAENTRY_KEYENTRY	0x4000  /* Key entry only */
#define SH_POS_DATAENTRY_ICC		0x8000  /* EMV compatible ICC reader */
/* R001538 END*/

/*------------------------------------------------------------------------*
 *	The following fields are coded (bit coded) *
 *------------------------------------------------------------------------*/
/* R001538 BEGIN */

#define SH_POS_COND_TERMATOWNER		0x0001	/* if true then located at owner */
#define SH_POS_COND_CUSTPRESENT		0x0002	/* customer present */
#define SH_POS_COND_CARDPRESENT		0x0004	/*	card present */
#define SH_POS_COND_AVS				0x0008	/*	verfication request */
#define SH_POS_COND_REQ_MASK      	0x0070  /*  8 different req values */
#define SH_POS_COND_REQ_NORMAL		0x0010	/*	normal request */
#define SH_POS_COND_REQ_MAIL      	0x0020  /*  mail telephone order */
#define SH_POS_COND_MANREV        	0x0030  /*  Manual Reversal (by retailer)*/
#define SH_POS_COND_TERMERROR     	0x0040  /*  Terminal Error  */
#define SH_POS_COND_REQ_ELECT     	0x0050  /*  Electronic order:PC, Internet*/
#define SH_POS_COND_REQ_PHONE     	0x0060  /*  Cardholder not present,
                                             telephone/ARU order  */
#define SH_POS_COND_REQ_STAND     	0x0070  /*  Cardholder not present,
                                              standing order or
                                              recurring transactions */
#define SH_POS_COND_REQ_PREAUTH   	0x0080  /*  pre-authorization */


#define SH_POS_COND_SUSPECT			0x0100	/*	suspect fraud */
#define SH_POS_COND_IDENTITY_VER	0x0200	/*	identiy verified */
#define SH_POS_COND_AVS_AUTH		0x0400	/*	avs with authorization */
/* Unattended terminal, customer operated */
#define SH_POS_COND_UNATTENDEDTERM	0x0800	/* 10001845 */
#define SH_POS_COND_TERMHOMEPC    	0x1000  /*  On premises of cardholder */
#define SH_POS_COND_ECR             0x2000  /*  terminal is ECR */
#define SH_POS_COND_NOTERM        	0x4000  /* No Terminal used */
#define SH_POS_COND_CREDIT_TXN		0x8000	/*	to be set by formatter/switch */

/* Definition for device_cap in shc_data. 						*
 * This is bit flag field. We define the bit index in order to  *
 * use shc_isbitset macro. bit index counts from 0. bit 0x10 of *
 * every byte can't be used  									*/
#define SHC_DATA_DEVICE_CAP_IS_AUTHCOMP		0	//The txn is an 102 msg from Visa
#define SHC_DATA_DEVICE_CAP_PIN_TRANSLATE_DONE		1	//PIN translation is done already
#define SHC_DATA_DEVICE_CAP_PIN_SRCKEY		2	//PIN translation src key is stored in message already
#define SHC_DATA_DEVICE_CAP_IS_NOTUSE1		3	//This bit can't be used
#define SHC_DATA_DEVICE_CAP_QR_CODE      	4   /* capabilityCode:QR Code */
#define SHC_DATA_DEVICE_CAP_RFID      		5	/* capabilityCode: RFID */
#define SHC_DATA_DEVICE_CAP_DEFERRED_AUTH	6	// Deferred authorization (added for Visa)
#define SHC_DATA_DEVICE_CAP_PAR_REQ_IND		7	// PAR quest indicator, Indicates if the Payment Account Reference (if available) is returned in the response or not.
#define SHC_DATA_DEVICE_CAP_OFFLINE_TXN_IND     8	// Offline transaction Indicator
#define SHC_DATA_DEVICE_CAP_IS_NOTUSE2		11	//This bit can't be used
#define SHC_DATA_DEVICE_CAP_UNSCHEDULED_COF	12	//Unscheduled credential on file transaction – can be merchant initiated as well as customer initiated.
#define SHC_DATA_DEVICE_CAP_ISSUER_RISK_BASED	13	//Issuer risk based decisioning
#define SHC_DATA_DEVICE_CAP_MERCHANT_RISK_BASED	14	//Merchant risk based decisioning or Merchant MDES token or Merchant SCA Authentication Exemption Request
#define SHC_DATA_DEVICE_CAP_SINGLE_FIRST         15 //Single First
#define SHC_DATA_DEVICE_CAP_INSTALLMENT_FIRST    16 //Installment First
#define SHC_DATA_DEVICE_CAP_DEFERRED_PMENT_FIRST 17 //Deferred Payment First
#define SHC_DATA_DEVICE_CAP_TRANSIT_SINGLE_PMENT 18 //Transit Single Payments
#define SHC_DATA_DEVICE_CAP_POST_PURCH_ADJUST    20 //Post purchase adjustment
#define SHC_DATA_DEVICE_CAP_DEFERRED_PMENT       21 //Deferred payment
#define SHC_DATA_DEVICE_CAP_NONAUTHENTICATED_SEOM 22 //Non-authen ticated secure electronic commerce transaction where authentication cannot be performed.
                                                      //Other security mechanisms may be present e.g. channel encryption.
#define SHC_DATA_DEVICE_CAP_IS_POS		23	//POS terminal type
#define SHC_DATA_DEVICE_CAP_IS_VOICE		24	//Connected to an automated system
#define SHC_DATA_DEVICE_CAP_IS_TABLET		25	//Device used Tablet
#define SHC_DATA_DEVICE_CAP_ON_MERC_DEVICE	26	//Merchant app installed on merchant device
#define SHC_DATA_DEVICE_CAP_ON_CALL_CENTER	28	//Call Center
#define SHC_DATA_DEVICE_CAP_ECOM_CASH_REG   29 //Electronic Cash Register
#define SHC_DATA_DEVICE_CAP_TKT_VENDING_MACHINE 30 //Travel Ticket Vending machine
#define SHC_DATA_DEVICE_CAP_ON_CUST_DEVICE	31	//Merchant app installed on customer device
#define SHC_DATA_DEVICE_CAP_IS_MOBILE		32
#define SHC_DATA_DEVICE_CAP_IS_ON_MERC_WEBSITE	33
#define SHC_DATA_DEVICE_CAP_CUST_PC		34
#define SHC_DATA_DEVICE_CAP_APP_PHONE		36
#define SHC_DATA_DEVICE_CAP_APP_PC		37	
#define SHC_DATA_DEVICE_CAP_WEB_PHONE		38
#define SHC_DATA_DEVICE_CAP_WEB_PC		39
#define SHC_DATA_DEVICE_CAP_IS_NOTUSE3		19	//This bit can't be used
#define SHC_DATA_DEVICE_CAP_IS_NOTUSE4		27	//This bit can't be used
#define SHC_DATA_DEVICE_CAP_IS_NOTUSE5		35	//This bit can't be used
#define SHC_DATA_DEVICE_CAP_RESTORE_MASK1	0xef//These bits in byte 1 need to be restored to response
/* capabilityCode:QR Code */
#define SHC_DATA_DEVICE_CAP_QR_CODE      4   
/* capabilityCode: RFID */
#define SHC_DATA_DEVICE_CAP_RFID      5
/* Barcode read */
#define SHC_DATA_DEVICE_CAP_BARCODE  6


														/* R008049 BEGIN */
/* Definition for pos_condition_code_x in shc_data *
 * pos_condition_code_x is one byte                *
 * bit 0x10 can't only be used                     */

#define SH_POS_COND_X_REQ_MASK      	0xef  /*  16 different req values */
#define SH_POS_COND_X_REQ_MERAUTH     	0x01  /*  merchant-authorization */
#define SH_POS_COND_X_REQ_STANDIN     	0x02  /*  stand-in */
#define SH_POS_COND_X_REQ_ADDRVER     	0x04  /*  Address Verfication request */
#define SH_POS_COND_X_REQ_CASHBCK     	0x08  /*  Cash back */
#define SH_POS_COND_X_REQ_DUMMY     	0x10  /*  This flag should not be used */
#define SH_POS_COND_X_REQ_DOWNSUB     	0x20  /*  Dwontime submission request */
#define SH_POS_COND_X_REQ_CDC		0x40  /*  Dwontime submission request */
#define SH_POS_COND_X_REQ_TKN		0x80  /*  Tokenization Request */

														/* R008049 END */
/* R009697 >> */
/* Definition for interchange_program_ind in shc_data *
 * interchange_program_ind is one byte                *
 */
#define SH_INTERCHANGE_PROGRAM_REQ_MASK  0xff  /* 8 different req values */
#define SH_INTERCHANGE_PROGRAM_REQ_TIPS  0x01  /* Travel Industries Premier Service, enrolled in a customer program and track may be absent */
/* << R009697 */

#define SH_POS_CAP_UNSPECIFIED		0x0001
#define SH_POS_CAP_UNATTENDED		0x0002	/*	terminal unattended */
#define SH_POS_CAP_NOTERM         	0x0004  /*  No terminal used*/ /* R001538 */
#define SH_POS_CAP_CARDCAPTURE		0x0008	/*	can capture cards */
#define SH_POS_CAP_DEBIT			0x0010	/*	can support debit cards */
#define SH_POS_CAP_CREDIT			0x0020	/*	can support credit cards */
#define SH_POS_CAP_NOCARDREAD		0x0040	/*	can read card data */
#define SH_POS_CAP_ECR				0x0080	/*	terminal is ECR */
#define SH_POS_CAP_DIALTERM			0x0100	/*	dial terminal */
#define SH_POS_CAP_CARDCAPTURE_UNKNOWN	0x0200	/* Terminal/operator card capture capability is unknown R013179 */
#define SH_POS_CAP_CONF_PENDING		0x0400	/*	this is for a confirm. of a
												pending txn.	*/
#define SH_POS_CAP_ACK_PROCESSED	0x0800	/*	9000/280 processed at another node already */

/* R001538 BEGIN */
/* Activated Terminal Level Indicator */
#define SH_POS_CAP_CAT_MASK       	0xF000	/*  Changed to accomodate extra flag R027101*/
#define SH_POS_CAP_CAT_ADMWITHPIN 	0x1000  /*  Automated dispensing machine with PIN */
#define SH_POS_CAP_CAT_SELFSERV   	0x2000  /*  Self service terminal */
#define SH_POS_CAP_CAT_LIMITEDAMT 	0x3000  /*  Limited amount terminal */
#define SH_POS_CAP_CAT_INFLIGHT   	0x4000  /*  In-flight commerce */
#define SH_POS_CAP_CAT_FUEL         0x5000	/*  Fuel Dispenser R007894 */
#define SH_POS_CAP_CAT_ECOMMERCE   	0x6000  /*  electronic commerce  R004155*/
#define SH_POS_CAP_CAT_TRANSPONDER  0x7000  /*  transponder transaction R007207*/
#define SH_POS_CAP_CAT_MOBILE		0x9000	/*  Reserved for future R027101*/
#define SH_POS_CAP_CAT_TAP_ON_MOBILENO 0xA000

/* R001538 END */
#define SH_POS_CAP_CONTACTLESS 		0x8000  /* --> Moved this to EXTENDED_POS_CONDITION_CODE segment as SH_DEVICE_POSCOND_CONTACTLESS. */


/* R003567 BEGIN */
#define SH_ECOM_NOTAPPLICABLE    0   /* Not applicable */
#define SH_ECOM_MOTO_SINGLE		1 /* single payment initiated by the cardholder */
#define SH_ECOM_MOTO_RECURRENT		2 /* recurring payment arrangement */
#define SH_ECOM_MOTO_INSTALLMENT	3 /* multiple payments for a specified term */
#define SH_ECOM_SECT             5   /* Secure Electronic Commerce Transaction */
#define SH_ECOM_NSTWITHSET       6   /* Nonauthenticated Security Transaction with SET merchant certificate */
#define SH_ECOM_NSTWITHOUTSET    7   /* Nonauthenticated Security Transaction without SET merchant certificate */
#define SH_ECOM_NONSECURE        8   /* Nosecure transaction */
/* R003567 END */
#define SH_ECOM_NSTATSET         9   /* Nonauthenticated security transaction at a SET-capable merchant */
#define SH_ECOM_IN_APP           4   /* In-App Authendication */
/* R003900 BEGIN */
/* 11:	SET encryption, No cardholder certificate
 * 13:	SET encryption, Chip Card, No cardholder certificate
 * 14:	SET encryption, Chip Card, Cardholder certificate used
 * 23:	Nonauthenticated Security Transaction, Chip card,
 *		No cardholder certificate
 */
#define SH_ECOM_SET_NO_CHCERT			11
#define SH_ECOM_SET_CHIP_NO_CHCERT		13
#define SH_ECOM_SET_CHIP_CHCERT			14
#define SH_ECOM_CHIP_NSTWITHOUTSET    	23
#define SH_ECOM_MASTERPASS			22	// --- R027102 //Updated from SH_ECOM_NST_CHCERT to SH_ECOM_MASTERPASS
#define SH_ECOM_NONSECURE_CHCERT		92	// --- R027102
/* R003900 END */
#define SH_ECOM_DSRP                            24      // Digital Secure Remote Payment
#define SH_ECOM_BOPIS            15

											/* R007894 >> */
#define SH_ECOM_SET_CHCERT          12	/* SET with certificate (Discover) */
#define SH_ECOM_VRUAuth             31	/* VRU Authorization 		*/
#define SH_ECOM_VoiceAgentAuth      32	/* Voice Agent Authorization*/
#define SH_ECOM_DFSBatchAuth        33	/* DFS Batch Authorization	*/
#define SH_ECOM_MICRNoImage         34	/* MICR without Image 		*/
#define SH_ECOM_MICRImage           35	/* MICR with Image 			*/
											/* R007894 << */

										/*	Compliance 14 Nov 2012	*/
#define SH_ECOM_AUTONOMOUS			36	/*	Issuer Autonomous identification mode	*/
#define SH_ECOM_ASSIST				37	/*	Issuer Autonomous identification mode	*/
										/*	Compliance 14 Nov 2012	*/
#define SH_POS_PANENTRY_STORE_AND_FORWARD                         45
#define SH_POS_PANENTRY_STORE_AND_FORWARD_RESUBMISSION           46
#define USE_REFUM_FOR_EVENT_KEY 		-99

#define	shcIsAckProcessed(shcmsg)	(shcmsg->msg.pos_cap_code & \
										SH_POS_CAP_ACK_PROCESSED)
#define	shcIsConfirmPending(shcmsg)	(shcmsg->msg.pos_cap_code & \
										SH_POS_CAP_CONF_PENDING)

/*------------------------------------------------------------------------*
 *	Flags and values on the extract_flags field - pk 12sep94
 *	AVERTISSEMENT: WARNING: This setting is on the shclog structure!!
 *------------------------------------------------------------------------*/
#define SH_XFLAG_SWITCH_DENY	0x00000001
#define SH_XFLAG_NETWRK_DENY	0x00000002 /* Default */

#define shcIsSwitchDeny(m)		(m->extract_flags & SH_XFLAG_SWITCH_DENY)
#define shcIsNetwrkDeny(m)		(m->extract_flags & SH_XFLAG_NETWRK_DENY)
#define shcSetSwitchDeny(m)		(m->extract_flags |= SH_XFLAG_SWITCH_DENY)
#define shcSetNetwrkDeny(m)		(m->extract_flags |= SH_XFLAG_NETWRK_DENY)

/*------------------------------------------------------------------------*
 *	Define the name of my rule as is known to the world
 *------------------------------------------------------------------------*/
#define SHC_MESSAGE_NAME		"shared-cash"
#define SHC_STATS_MESSAGE_NAME	"shared-cash-stats"
#define SHC_PIN_MESSAGE_NAME	"shared-cash-pins"
#define SHC_SECURITY_MESSAGE_NAME	"shared-cash-security"
#define SHC_RMTBIN_MESSAGE_NAME	"shared-cash-rmtbin"
#define	SHC_EXTBIN_MESSAGE_NAME	"shared-cash-extbin"

/*------------------------------------------------------------------------*
 *	Define the name of task as is known to the world
 *------------------------------------------------------------------------*/
#define SHC_SERVER_NAME			"SharedCash"
#define SHC_REPLAY_TASK			"istadvicecmd"					/* 10001959 */
#define SHC_KEYXCHG_TASK		"shckeys"
#define SHC_TRACESERVER_NAME	"SequenceNumber"

#define shcNumberOfKeys     (rulekeyp->keysused)    /*  Must include rules.h */
#define shcNumberOfText     (rulekeyp->textused)
#define shcNumberOfRmtBin   (rmtbin_rulekeyp->textused)

/*------------------------------------------------------------------------*
 * Those special macros which every body thinks are functions
 *------------------------------------------------------------------------*/
//#define shc_isdown(bp)		    ( (bp) && (bp)->bin.flags & SH_DOWN)
#define shc_safallowed(bp)	    ((bp)->saf.type & SH_SAF_ALLOWED)
#define shc_needpincheck(bp)	(((bp)->bin.flags & SH_CHECKPIN) ||\
								 (!isPostiveSAF(bp) && ((bp)->bin.flags & SH_CHECKPIN_STAND_IN)) )

#define shc_safBridgeEnabled(bp)        ((bp)->bin.bin_cfg & SH_CFG_ALLOW_SAF_ACROSS_SITE)
#define shc_isreplay(bp)        ( (bp) && ((bp)->bin.flags & SH_REPLAY) && (((bp)->saf.type & SH_SAF_POSFILE)||((bp)->saf.type & SH_SAF_NEGFILE)) )

/*------------------------------------------------------------------------*
 * Some date macros (used on ist internal dates YYYYMMDD)
 *------------------------------------------------------------------------*/
#define	shc_xday(d)		((d) % 100)
#define shc_xmon(d)		((d) / 100 % 100)
#define shc_xyear(d)	((d) / 10000L)
#define shc_xcentury(d)	( (d) / 1000000L)
#define shc_xfullyear(d)	( (d) / 10000L)
#define shc_getcentury(d) (shc_xfullyear((d)) * 10000L)

/*------------------------------------------------------------------------*
 * Bit map defines
 *------------------------------------------------------------------------*/
#define shc_isbitset(bm,c)	( (bm)[(c) >> 3] & (0x80 >> ((c) & 7)) )
#define shc_setbiton(bm,c)	( (bm)[(c) >> 3] |= (0x80 >> ((c) & 7)) )
#define shc_setbitoff(bm,c)	( (bm)[(c) >> 3] &= ~(0x80 >> ((c) & 7)) )

/*------------------------------------------------------------------------*
 * device_cap Flags Define Block
 *------------------------------------------------------------------------*/
#define	SH_DEVCAP_NOPIN					0x00000001
#define SH_DEVCAP_TRACK_1				0x00000002
#define SH_DEVCAP_FROMDEVICE			0x00000004
#define SH_DEVCAP_USE_REFNUM			0x00000008
#define SH_DEVCAP_PIN_VERIFIED			0x00000010
#define SH_DEVCAP_WILLACK				0x00000020
#define SH_DEVCAP_NOTRACK_DATA			0x00000040
#define	SH_DEVCAP_SET_CAPDATE			0x00000080
#define	SH_DEVCAP_KEEP_FORMATTER_USE	0x00000100
#define SH_DEVCAP_FROM_REPLAY			0x00000200
#define SH_DEVCAP_KEEPORIGINATOR		0x00000400
#define SH_DEVCAP_FROMIBM4730			0x00000800
#define SH_DEVCAP_NETZKA				0x00000800	//	---	R025604
#define SH_DEVCAP_INTERNALREV			0x00001000
#define SH_DEVCAP_KEEP_PCODE			0x00002000
#define SH_DEVCAP_KEEP_ACCEPTORNAME		0x00004000
#define SH_DEVCAP_FROM_NETWORK			0x00008000
#define SH_DEVCAP_INGORE_SERIAL         0x00010000
#define	SH_DEVCAP_PREAGENT_STATE		0x00020000
#define	SH_DEVCAP_PROAGENT_STATE		0x00040000
#define SH_DEVCAP_REAUTHED				0x00080000
#define SH_DEVCAP_USER_SEGMENT			0x00100000
#define SH_DEVCAP_EDC					0x00200000
#define SH_DEVCAP_UPDATE_LOGS			0x00400000
#define SH_DEVCAP_KEEP_DEVCAP			0x00800000
#define SH_DEVCAP_OAR					0x01000000
#define SH_DEVCAP_NEXTSTATE				0x02000000
#define SH_DEVCAP_USE_SETTLEMENT_AMOUNT	0x04000000
#define SH_DEVCAP_USE_ISSUER_AMOUNT		0x08000000 /* ??? same value */
#define SH_DEVCAP_DUPLICATE_TXN			0x10000000
#define SH_DEVCAP_REV_REQUIREORIG		0x20000000
#define SH_DEVCAP_SAVE_CAP_DATE         0x40000000 /* ??? same value */
#define SH_DEVCAP_HYEDC_MAP         	0x80000000	// ---  R007400

/*
 *	Flags and values on the Dev Cap field
 */
#define shc_excpect_ack(m)		((m)->msg.device_cap & SH_DEVCAP_WILLACK)
#define shc_fromdevice(m)		((m)->msg.device_cap & SH_DEVCAP_FROMDEVICE)
#define shc_set_willack(m)		((m)->msg.device_cap |= SH_DEVCAP_WILLACK)
#define shc_set_fromdevice(m)	((m)->msg.device_cap |= SH_DEVCAP_FROMDEVICE)
#define shc_devcap_setedc(m)	((m)->msg.device_cap |= SH_DEVCAP_EDC)
#define shc_unset_fromdevice(m)	((m)->msg.device_cap &= ~(SH_DEVCAP_FROMDEVICE))
#define shc_internalrev(m)		((m)->msg.device_cap &  SH_DEVCAP_INTERNALREV)

/*------------------------------------------------------------------------*
 * device_cap Flags Block end
 *------------------------------------------------------------------------*/


/*------------------------------------------------------------------------*
 * device_devcap Flags Define Block
 *------------------------------------------------------------------------*/
															/* R007894 >> */
/* 0x00000000 - 0x000000ff : Reserved for storing atoi(sec_fmt_code)&0xff */
#define SH_DEVICE_SECFMTCODE_MASK                0x000000ff

/* PosChPresent_...  - to extend pos_condition_code */
#define SH_DEVICE_POSCOND_MASK                   0x0000ff00
#define SH_DEVICE_POSCOND_Fax                    0x00000100
#define SH_DEVICE_POSCOND_InternetDeliverElectr  0x00000200
#define SH_DEVICE_POSCOND_InternetDeliverPhys    0x00000300
#define SH_DEVICE_POSCOND_InternetDeliverUnknown 0x00000400
#define SH_DEVICE_POSCOND_OneTimeMOTO            0x00000500
#define SH_DEVICE_POSCOND_InstallmentMOTO        0x00000600
#define SH_DEVICE_POSCOND_Recurrent              0x00000700
#define SH_DEVICE_POSCOND_UnknownMOTO            0x00000800
/* R013179 >> Enriched POS Data Entry for MasterCard DE61 */
#define SH_DEVICE_POSCOND_EXTEND_MASK            0x0000f000
#define SH_DEVICE_POSCOND_CardHolderUnattended   0x00001000
#define SH_DEVICE_POSCOND_LocationUnknown        0x00002000
#define SH_DEVICE_POSCOND_CustomerUnknown        0x00004000
#define SH_DEVICE_POSCOND_CardUnknown            0x00008000
/* << R013179 */

// EXTENDED SEGMENT POSCOND FLAG
// These flag values has to be set in
// NSD.EXTENDED_POS_CONDITION_CODE segment to denote different codes.
//POSITION 0
#define SH_DEVICE_POSCOND_OnPremises            0x01     //Position 0 value 1
#define SH_DEVICE_POSCOND_TransitAccessInd      0x02     //Position 0 value 2
#define SH_DEVICE_POSCOND_Token                 0x04     //Position 0 value 4
#define SH_DEVICE_POSCOND_RecurringToken        0x08     //Position 0 value 8
#define SH_DEVICE_POSCOND_mPOS                  0x10     //Position 1 value 1
#define SH_DEVICE_POSCOND_DEFAULT               0x20     //Position 1 value 2
#define SH_DEVICE_POSCOND_INTERNET              0x40     //Position 1 value 4
#define SH_DEVICE_POSCOND_TEXT_MSG              0x80     //Position 1 value 8
#define SH_DEVICE_POSCOND_VOICE                 0x01     //Position 2 value 1
#define SH_DEVICE_POSCOND_NONE                  0x02     //Position 2 value 2
#define SH_DEVICE_POSCOND_PRINTING              0x04     //Position 2 value 4
#define SH_DEVICE_POSCOND_DISPLAY               0x08     //Position 2 value 8
#define SH_DEVICE_POSCOND_BankCounterManual     0x10     //Position 3 value 1
//      >>>     IST_S_166334-47
#define SH_DEVICE_POSCOND_CredentialOnFile              0x20     //Position 3 value 2
#define SH_DEVICE_POSCOND_IncrementalAuth               0x40     //Position 3 value 4
#define SH_DEVICE_POSCOND_Resubmission                  0x80     //Position 3 value 8
#define SH_DEVICE_POSCOND_DelayedCharges                0x01     //Position 4 value 1
#define SH_DEVICE_POSCOND_NoShow                        0x02     //Position 4 value 2
#define SH_DEVICE_POSCOND_AccountTopUp                  0x04     //Position 4 value 4
#define SH_DEVICE_POSCOND_PAYBUTTON             0x08    //Position 4 value 8
//      <<<     IST_S_166334-47
#define SH_DEVICE_POSCOND_AUTHAGENT             0x10    //Position 5 value 1
#define SH_DEVICE_POSCOND_AFT_REFUND            0x20    //Position 5 value 2
#define SH_DEVICE_POSCOND_CONTACTLESS		0x40	//Position 5 value 4
#define SH_DEVICE_POSCOND_AdditionalPOSTermLoc	0x80	//Position 5 value 8
#define SH_DEVICE_POSCOND_AcctDataOnFile	0x01	//Position 6 value 1
#define SH_DEVICE_POSCOND_DATAENTRY_BARCODE	0x02	//Position 6 value 2
#define SH_DEVICE_POSCOND_DATAENTRY_OCR		0x04	//Position 6 value 4
#define SH_DEVICE_POSCOND_PARTIALSHIPMENT	0x08	//Position 6 value 8
#define SH_DEVICE_POSCOND_InstallPayment    	0x10    //Position 7 value 1
#define SH_DEVICE_POSCOND_UnscheduledPayment    0x20    //Position 7 value 2
#define SH_DEVICE_POSCOND_ExcludeFee		0x40	//Position 7 value 4
#define SH_DEVICE_POSCOND_SET_CERT              0x80    //Position 7 value 8
#define SH_DEVICE_POSCOND_DigitalWallet         0x01    //Position 8 value 1
#define SH_DEVICE_POSCOND_SET_NOCERT            0x02    //Position 8 value 2
#define SH_DEVICE_POSCOND_ELEC_COMM_TXN         0x04    //Position 8 value 4
#define SH_DEVICE_POSCOND_NSEC_ELEC_COMM_TXN    0x08    //Position 8 value 8

#define SH_DEVICE_POSCOND_MSR_NO_READ           0x01    //Position 9 value 1
#define SH_DEVICE_POSCOND_AVS_TOKEN		0x02	//Position 9 value 2
#define SH_DEVICE_POSCOND_COUPON_WRITEOFF       0x04    //Position 9 value 4
#define SH_DEVICE_POSCOND_HOTEL_NOSHOW		0x08	//Position 9 value 8

#define SH_DEVICE_POSCOND_ThirdPartyInstallmentPayment   0x01    //Position 10 value 1
#define SH_DEVICE_POSCOND_IssuerInstallmentPayment       0x02    //Position 10 value 2 
#define SH_DEVICE_POSCOND_SpecialMOTO                    0x04    //Position 10 value 4
#define SH_DEVICE_POSCOND_SpecialCOUNTRY                 0x08    //Position 10 value 8

//#define SH_DEVICE_POSCOND_EXTEND_MASK_2			 0x000f0000 //R031195
//#define SH_DEVICE_POSCOND_TransitAccessInd       0x00010000 //R031195

/* PosAuthMode_... */
#define SH_DEVICE_AUTHMODE_MASK                  0x000f0000
#define SH_DEVICE_AUTHMODE_NoAuth                0x00010000
#define SH_DEVICE_AUTHMODE_ESigniture            0x00020000
#define SH_DEVICE_AUTHMODE_Biometrics            0x00030000
#define SH_DEVICE_AUTHMODE_Biographics           0x00040000
#define SH_DEVICE_AUTHMODE_ManualSignVerif       0x00050000
#define SH_DEVICE_AUTHMODE_OtherManualVerif      0x00060000	/* (e.g. drivers license) */
#define SH_DEVICE_AUTHMODE_ElectrTicketEnv       0x00070000
#define SH_DEVICE_AUTHMODE_SETAMEX               0x00080000
#define SH_DEVICE_AUTHMODE_PwdWDigitalCertif     0x00090000
#define SH_DEVICE_AUTHMODE_PwdWODigitalCertif    0x000a0000
#define SH_DEVICE_AUTHMODE_NoSecurityConcern	 0x000b0000

/* Stored flags to indicate shclog addenda tables */
#define SH_DEVICE_TABLES_MASK                    0x0ff00000
#define SH_DEVICE_LOG_SHCLOG_ADD                 0x00100000
#define SH_DEVICE_LOG_SHCLOG_CHEQUE              0x00200000
#define SH_DEVICE_LOG_SHCCHIPLOG                 0x00400000
#define SH_DEVICE_LOG_SHCLOG_FLEET               0x00800000
#define SH_DEVICE_LOG_SHCLOG_VFRS      	         0x01000000
#define SH_DEVICE_LOG_SHCLOG_MC      	         0x04000000
#define SH_DEVICE_LOG_SHCLOG_IFD      	         0x02000000

/* PosCardInputCap_...  - to extend Data Entry Mode(pos_entry_code) */
#define SH_DEVICE_DATAENTRY_MASK                 0xf0000000
#define SH_DEVICE_DATAENTRY_imageMICRMagStr      0x10000000
#define SH_DEVICE_DATAENTRY_MICRMagRead          0x20000000
#define SH_DEVICE_DATAENTRY_UnableReadMagStripe  0x40000000
#define SH_DEVICE_DATAENTRY_ICC_WRITE		 0x80000000 /*Used for Card Data Output Capability */
															/* R007894 << */

/* R006365 */
#define SH_DEVCAP_TERMINALDUKPT			0x80000000

/* R006365 */
#define shc_set_dukpt(m)      ((m)->msg.device_devcap |= SH_DEVCAP_TERMINALDUKPT)

// MoneySend tag in segment sub-element SHCIMF_MONEYSEND_SPECIFIC_DATA
#define TAG_RECEIVER_DATA   100
#define TAG_SENDER_DATA     200
#define TAG_TXN_DATA        300
/* sender/receiver */
#define TAG_FIRST_NAME                  1
#define TAG_MIDDLE_NAME                 2
#define TAG_LAST_NAME                   3
#define TAG_STREET_ADDRESS              4
#define TAG_CITY                        5
#define TAG_STATE                       6
#define TAG_CNTRY                       7
#define TAG_POSTAL_CODE                 8
#define TAG_PHONE_NUMBER                9
#define TAG_DOB                         10
#define TAG_ACCT_NUM                    11
#define TAG_IDENTIFICATION_TYPE         12
#define TAG_IDENTIFICATION_NUMBER       13
#define TAG_IDENTIFICATION_CNTRY_CODE   14
#define TAG_IDENTIFICATION_EXP_DATE     15
#define TAG_NATIONALITY                 16
#define TAG_CNTRY_OF_BIRTH              17
/* transaction */
#define TAG_SOURCE_OF_FUNDS      3
/*------------------------------------------------------------------------*
 * device_devcap Flags Block end
 *------------------------------------------------------------------------*/


/*------------------------------------------------------------------------*
 * formatter_devcap Flags Define Block
 *------------------------------------------------------------------------*/
#define	SH_FORMATDEVCAP_VISA_ACI_Y		0x00000001
#define	SH_FORMATDEVCAP_VISA_ACI_I		0x00000002
#define	SH_FORMATDEVCAP_VISA_ACI_P		0x00000004
#define	SH_FORMATDEVCAP_VISA_ACI_R		0x00000100
#define	SH_FORMATDEVCAP_VISA_ACI_N		0x00000200
#define SH_FORMATDEVCAP_VISA_ACI	(SH_FORMATDEVCAP_VISA_ACI_Y | SH_FORMATDEVCAP_VISA_ACI_I | SH_FORMATDEVCAP_VISA_ACI_P | SH_FORMATDEVCAP_VISA_ACI_R)

#define	SH_FORMATDEVCAP_RETURN   		0x00000008   /* qd 08jan98 ACXSYS */
#define	SH_FORMATDEVCAP_NOROUTE   		0x00000010   /* qd 08jan98 ACXSYS */
#define SH_FORMATDEVCAP_FIRST_REPLAY    0x00000020   /* R003313 */
#define SH_FORMATDEVCAP_INTERAC			0x00000040
#define SH_FORMATDEVCAP_CASH_DEPOSIT	0x00000080	//	---	R010978
#define SH_FORMATDEVCAP_NOCURRENCY_CONV	0x00000400	//	---	R016062
#define SH_FORMATDEVCAP_USER_SEGMENT	0x00100000	//	---	R016096
#define SH_FORMATDEVCAP_EBCDIC			0x00000800	//	---	R018983
#define SH_FORMATDEVCAP_TERMINALREV		0x00001000	//	---	R018983
#define SH_FORMATDEVCAP_CAPTURE_ONLY	0x00002000
#define SH_FORMATDEVCAP_ALT_ISSUER		0x00004000	//	---	R020617
#define SH_FORMATDEVCAP_REJECT_MESSAGE	0x00008000	//	---	R030481
#define SH_FORMATDEVCAP_EMV_MASK		0x00030000	//	---	R026570
#define SH_FORMATDEVCAP_EMV_YES			0x00010000	//	---	R026570
#define SH_FORMATDEVCAP_EMV_NO			0x00020000	//	---	R026570
#define SH_FORMATDEVCAP_EMV_UNKNOWN		0x00000000	//	---	R026570
#define SH_FORMATDEVCAP_MATCH_BATCH_ID	0x00040000	// R027905
#define SH_FORMATDEVCAP_VOICE_AUTH		0x00080000
#define SH_FORMATDEVCAP_FORCE_CAPTURE   0x00200000  //R031357
#define SH_FORMATDEVCAP_MVISA		0x00400000	//mVisa
#define SH_FORMATDEVCAP_OCT_TXN			0x00800000 //OCT
#define SH_FORMATDEVCAP_ADVICE_TIMEOUT          0x01000000 //Pulse Network Advice Timeout flag
#define SH_FORMATDEVCAP_ORIG_MSG_RESTORED		0X02000000	//original message is restored already

/*------------------------------------------------------------------------*
 * formatter_devcap Flags Block end
 *------------------------------------------------------------------------*/

/*------------------------------------------------------------------------*
 * shc_devcap Flags Define Block
 *------------------------------------------------------------------------*/
#define SH_DEVCAP_SHC_EVENT 			0x00000001

/* memo transactions, no settlement effect, normally set be advice server */
#define SH_DEVCAP_SHC_MEMO 				0x00000002
#define SH_DEVCAP_SHC_PIN_BASED				0x00000004		//	---	R020622
#define SH_DEVCAP_SHC_MSG_REPLIED       0x00000010      //  Msg already replied
#define SH_DEVCAP_SHC_REQ_REPEAT       	0x00000020      /*  The txn is approved as a repeat txn */
#define SH_DEVCAP_SHC_IBFTW				0x00000100		/* 10002273 */
#define SH_DEVCAP_SHC_IBFTD				0x00000200		/* 10002273 */
#define SH_DEVCAP_SHC_IBFT  			0x00800000
#define SH_DEVCAP_SHC_STDIN				0x00000400		/* R005896 */
#define SH_DEVCAP_SHC_VOID				0x00000800		/* R008224 */
#define SH_DEVCAP_SHC_LATE_RESPONSE		0x00001000		/* R009856 */
#define SH_DEVCAP_SHC_CALLBACK_ACTION	0x00002000		/* R009856 */
#define SH_DEVCAP_SHC_PARTIAL_AUTH		0x00004000		/* R014008 */
#define SH_DEVCAP_SHC_ICCFALLBACK       0x00008000      /* R015275 */
#define SH_DEVCAP_SHC_CASHOVER_PARTIAL  0x00000008		//	---	R022506
#define SH_DEVCAP_SHC_DCC_IND           0x00000040             // R029769

/* R011822 >> */
#define SH_DEVCAP_SHC_ELEC_MASK		0x000f0000
#define SH_DEVCAP_SHC_REG_ACQUIRER	0x00010000
#define SH_DEVCAP_SHC_REG_MERCHANT	0x00020000
#define SH_DEVCAP_SHC_REG_MC_ONLY	0x00040000
/* << R011822 */
#define SH_DEVCAP_SHC_ATM_REMOTE_TERM		0x00100000
#define SH_DEVCAP_SHC_DUAL_FIRST_MSG  		0x00200000
#define SH_DEVCAP_SHC_DUAL_SECOND_MSG  		0x00400000
														/* R002251 BEGIN */
#define SH_DEVCAP_SHC_BO_MASK					0xff000000
#define SH_DEVCAP_SHC_BO_REPRESENTMENT_FIRST	0x01000000
#define SH_DEVCAP_SHC_BO_REPRESENTMENT_SECOND	0x02000000
#define SH_DEVCAP_SHC_BO_REPRESENTMENT_THIRED	0x03000000
#define SH_DEVCAP_SHC_BO_ADJUSTMENT_FIRST		0x11000000
#define SH_DEVCAP_SHC_BO_ADJUSTMENT_SECOND		0x12000000
#define SH_DEVCAP_SHC_BO_ADJUSTMENT_THIRED		0x13000000
#define SH_DEVCAP_SHC_BO_GOOD_FAITH_FIRST		0x21000000
#define SH_DEVCAP_SHC_BO_GOOD_FAITH_SECOND		0x22000000
#define SH_DEVCAP_SHC_BO_GOOD_FAITH_THIRED		0x23000000
#define SH_DEVCAP_SHC_BO_CHARGEBACK_FIRST		0x31000000
#define SH_DEVCAP_SHC_BO_CHARGEBACK_SECOND		0x32000000
#define SH_DEVCAP_SHC_BO_CHARGEBACK_THIRED		0x33000000
#define SH_DEVCAP_SHC_BO_CHARGEBACK_REV_FIRST	0x41000000
#define SH_DEVCAP_SHC_BO_CHARGEBACK_REV_SECOND	0x42000000
#define SH_DEVCAP_SHC_BO_CHARGEBACK_REV_THIRED	0x43000000
#define SH_DEVCAP_SHC_BO_ACQUIRER_FEE			0x50000000
#define SH_DEVCAP_SHC_BO_ISSUER_FEE				0x51000000
														/* R002251 END */

/*------------------------------------------------------------------------*
 * shc_devcap Flags Block end
 *------------------------------------------------------------------------*/

//auth_devcap flags for 8xx messages only
#define NET_DEVCAP_AUTH_SIGNOFF_TYPE_BIN			0x00000001	//Bin Signoff, otherwise is binroute sinoff

/*------------------------------------------------------------------------*
 * auth_devcap Flags Define Block
 *------------------------------------------------------------------------*/
#define SH_DEVCAP_AUTH_CONFIRM        		          0x00000001 /* 12mar96 */
#define SH_DEVCAP_AUTH_ENCRYPTION   		          0x00000002  /* 16Jan98. ACXSYS. */
#define SH_DEVCAP_AUTH_AES_ENCRYPTION   	          0x00000002  /* 06Apr23. AES KEY BLOCK. */
#define SH_DEVCAP_AUTH_TxnSecurityUnknown             0x00000004	// --- R022506
#define SH_DEVCAP_AUTH_BIOMETRICS	  		          0x00000008   // --- R022506
#define SH_DEVCAP_AUTH_NO_ORIG		  		          0x00000010   // No orig msg found, mainly for reversal
#define SH_DEVCAP_AUTH_FINAL                          0x00000020    // --- Final Authorization (MC Fall 2013)
#define SH_DEVCAP_AUTH_INCREMENT	  0x00000040

#define SH_DEVCAP_AUTH_OD_MASK		  0x00000180    //On Dot flag mask
#define SH_DEVCAP_AUTH_ODTimeout	  0x00000080
#define SH_DEVCAP_AUTH_ODDown		  0x00000180
#define SH_DEVCAP_AUTH_OD			  0x00000100    //Msg sent to On Dot

#define SH_DEVCAP_AUTH_DUALSITE_REV_EVENT              		0x00000200		//The event is dual-site delay reversal event
#define	SH_DEVCAP_AUTH_ICC				0x00000800		//Card Data Output Capability
#define SH_DEVCAP_AUTH_RECUR_FIRST                    0x00001000
#define SH_DEVCAP_AUTH_MERCH_AUTH_ENT                 0x00002000	//	---	R025506
#define SH_DEVCAP_AUTH_ICC_AUTH_ENT				0x00004000	//	---	R026957
#define SH_DEVCAP_AUTH_CAD_AUTH_ENT				0x00008000	//	---	R026957
#define SH_DEVCAP_AUTH_PARTIAL_ALLOWED                0x00010000
#define SH_DEVCAP_AUTH_PREPAID_BAL_ALLOWED		      0x00020000
#define SH_DEVCAP_AUTH_PREPAID_CARD_USED  	  		  0x00040000
#define SH_DEVCAP_AUTH_PURCH_AMOUNT_ONLY_ALLOWED      0x00080000
#define SH_DEVCAP_AUTH_PURCH_AMOUNT_ONLY	          0x00100000
#define SH_DEVCAP_AUTH_FM			                  0x00200000	// --- R020052
//	>>>	R020938
#define SH_DEVCAP_AUTH_LM							  0x00400000
#define SH_DEVCAP_AUTH_LMTimeout	                  0x00800000
#define SH_DEVCAP_AUTH_LMForcePost	                  0x01000000
#define SH_DEVCAP_AUTH_LMLateResp					  0x02000000
//	<<<	R020938
#define SH_DEVCAP_AUTH_FMTimeout					  0x20000000	//	---	R025639
#define SH_DEVCAP_AUTH_ACCT_VERIFICATION_ONLY		  0x04000000      // R022354
#define SH_DEVCAP_TERMINAL_IIAS_VERIFIED	      	  0x08000000
#define SH_DEVCAP_NON_IIAS_SUBSTANTIATION             0x10000000
//      >>>     IST_S_166334-47
#define SH_DEVCAP_AUTH_ESTIMATED_AMOUNT                           0x40000000
#define SH_DEVCAP_AUTH_PARTIAL_ESTIMATED                          0x80000000
#define SH_DEVCAP_AUTH_ADVICE_INCREMENT                           0x00000400
//      <<<     IST_S_166334-47

/*------------------------------------------------------------------------*
 * auth_devcap Flags Block end
 *------------------------------------------------------------------------*/

/*------------------------------------------------------------------------*
 *	saf_devcap Flags Define Block
 *------------------------------------------------------------------------*/
#define SH_SAF_NEGFILE				0x00000001
#define SH_SAF_POSFILE				0x00000002
#define SH_SAF_NOFILE				0x00000004	/*	do not save in log file */
#define SH_SAF_FORCE_DOWN			0x00000008	/*  on time out force down */
#define SH_SAF_ALLOWED				(SH_SAF_NEGFILE | SH_SAF_POSFILE)
#define SH_SAF_TIMEOUT_DONOTHING	0x00000010
#define SH_SAF_TIMEOUT_RETRY		0x00000020
#define SH_SAF_TIMEOUT_SHUTDOWN		SH_SAF_FORCE_DOWN

/*------------------------------------------------------------------------*
 *	saf_devcap Flags Block end
 *------------------------------------------------------------------------*/


/*------------------------------------------------------------------------*
 *	Define Values for the saf flag in the log file
 *------------------------------------------------------------------------*/
#define SH_SAF_TIMEOUT			-2
#define SH_SAF_PENDING			1
#define SH_SAF_DONE				2
#define SH_SAF_SKIPPED			3
#define SH_SAF_FORWARD			4               /* qd 23dec97 ACXSYS */
#define SH_SAF_DROPPED			5               /* qd 29dec97 ACXSYS */


/*------------------------------------------------------------------------*
 * ACXSYS Specific Block
 *------------------------------------------------------------------------*/
#define     ELF_BUFF_SIZE           16384 /* qd 11dec97 ACXSYS moved here*/
#define     SHC_ISS_BIN             1    /* qd 18dec97 ACXSYS */
#define     SHC_ACQ_BIN             0    /* qd 18dec97 ACXSYS */
#define     SHC_ISS_KEY            'I'   /* qd 18dec97 ACXSYS */
#define     SHC_ACQ_KEY            'A'   /* qd 18dec97 ACXSYS */

/* >>>>> ACXSYS. 21Jan98 */
#define shcIsAdmIssReq(shcmsg) (shcmsg->msg.msgtype == SHC_ISS_ADMIN || \
                                shcmsg->msg.msgtype == SHC_ISS_ADMIN_ADVICE)
#define shcIsAdmIssResp(shcmsg) \
                   (shcmsg->msg.msgtype == SHC_ISS_ADMIN_RESPONSE || \
                    shcmsg->msg.msgtype == SHC_ISS_ADMIN_ADVICE_RESPONSE)
#define shcIsRevIssReq(shcmsg) \
                   (shcmsg->msg.msgtype == SHC_CHARGE_BACK_ADVICE)
#define shcIsRevIssResp(shcmsg) \
				   (shcmsg->msg.msgtype == SHC_CHARGE_BACK_ADVICE_RESPONSE)

/* <<<<< ACXSYS. 21Jan98 */


#define SHC_TOTAL_INDEX 2										/* ACXSYS. 05Feb98 */
#define shcNextKeyIndex(index)  ((index+1 ) % SHC_TOTAL_INDEX)	/* ACXSYS. 05Feb98 */

/*------------------------------------------------------------------------*
 * Misc.  Block
 *------------------------------------------------------------------------*/
#define		shcExtBinRecordUpdated		0x00000001L /* for shcextbin.flags*/
#define		shcGenAuthNumRandom		0
#define		shcGenAuthNumFromDB		1


/*------------------------------------------------------------------------*
 * Bin Level Configuration Defines (R001835)	Start
 *------------------------------------------------------------------------*/
//flags for SHCBIN.BIN_FLAG field in shared memory - start
#define	SH_CFG_INTERAC                                 0x00000001L  /* Interac BIN */
#define	SH_CFG_DSQL                                    0x00000002L  /* Dynamic SQL */
#define	SH_CFG_NDKE                                    0x00000004L  /* Network Dynamic Key Exchange */
#define	SH_CFG_CHKDUPREV                               0x00000008L  /* Check Duplicate Reversal */

#define SH_NO_AVS               0x00000000   /* Not support AVS;R006273 Begin, belongs to SH_CFG_ flags*/
#define SH_CFG_TRANTIME                                0x00000010L  /* Restore Transmission Time */
#define SH_CFG_CAPDATEOVERRIDE                         0x00000020L  /* Capture Date Override */
#define SH_NONCONDENSED_AVS     0x00000040   /* Support non-condensed AVS, belongs to SH_CFG_ flags */
#define SH_CONDENSED2_AVS       0x00000080   /* Support condensed(2) AVS, belongs to SH_CFG_ flags */
#define SH_CONDENSED3_AVS       0x000000c0   /* Support condensed(3) AVS, belongs to SH_CFG_ flags */
#define SH_CONDENSED4_AVS       0x00000100   /* Support condensed(4) AVS, belongs to SH_CFG_ flags. Only numbers in address exist */
#define SH_CFG_FULL_ENTRY                              0x00000200
#define SH_CFG_CARD_AUTH                               0x00000400
#define SH_CFG_ISS_AUTH                                0x00000800

#define SH_CFG_DECL_AUTH_FAI                           0x00001000
#define SH_CFG_CHIP_LOG                                0x00002000
#define SH_CFG_EMV_STIP                                0x00004000
#define SH_CFG_ACCOUNT_FUNDING                         0x00008000	/* R007502 */

#define SH_ISSUER_ONLY          0x00010000   /* Support Issuer only, belongs to SH_CFG_ flags */
#define SH_ACQUIRER_ONLY        0x00020000   /* Support Acquirer only, belongs to SH_CFG_ flags */
#define SH_CFG_DCVV_CHECK                              0x00040000   /* Support Issuer only, belongs to SH_CFG_ flags */
#define SH_CFG_DCVV_VERIFY                             0x00080000   /* Support Acquirer only, belongs to SH_CFG_ flags */
#define SH_ISSUER_ACQURIER      0x00030000   /* Support Both, belongs to SH_CFG_ flags */

#define SH_CFG_CHECK_MERCHANT                          0x00100000   /* Checks hot merchant, belongs to SH_CFG flags */	//	---	R020052
#define SH_CFG_DCVV                                    0x00200000
#define SH_CFG_CVC3                                    0x00400000
#define SH_CFG_SCVC3                                   0x00800000

#define SH_CFG_ICVV                                    0x01000000
#define	SH_SESSION_DONE                                0x02000000   //	---	R026452	session activation done flag. NOT USED?
#define SH_CFG_ReturnRefund     0x04000000   /* Return Refund txns w/o forwarding to issuer */
#define SH_CFG_ReturnVoid       0x08000000   /* Return Void txns w/o forwarding to issuer */

#define SH_CFG_ENABLE_DUAL_SITE_BRIDGE                  0x10000000       /* Route msg across site  */
#define SH_CFG_ALLOW_SAF_ACROSS_SITE                    0x20000000       /* Route saf msg across site  */
#define	SH_REV_LATERESP			0x40000000	 /* Send reversal on receiving late response */
#define SH_CFG_ALLOW_ZERO_AMT_PREAUTH	0x80000000       /* Allow zero amount pre auth transaction */

#define SH_CFG_ONDOT_MASK		0x300000000L  //OnDot Config, 64-bit switch only
#define SH_CFG_ONDOT_DOWN_CONT	0x100000000L  //Continue when On Dot down/timeout
#define SH_CFG_ONDOT_DOWN_DENY	0x200000000L  //Deny when On Dot down/timeout
#define SH_CHECKCVV_STANDIN_ONLY                      0x400000000L  //standin only check 
#define SH_CHECKCVV2_STANDIN_ONLY                     0x800000000L  //standin only check 
#define SH_CHECK_CVV_CVV2_STANDIN_ONLY                0xc00000000L  //standin only check 

#define SH_CFG_DCVV_CHECK_VERIFY_STAND_IN_ONLY       0x1000000000L  //standin only check 
#define SH_CFG_CAVV_3DS_STAND_IN_ONLY                0x2000000000L  //standin only check 
#define SH_CSC_CHECK_STAND_IN_ONLY                   0x4000000000L  //standin only check 
#define SH_CFG_TOKEN_TXN_CHK			     0x8000000000L  //Token Txn checks to be done
#define SH_CFG_TOKEN_TXN_NO_CHK                      0x10000000000L  //Token Txn checks not to be done
#define SH_CFG_KPE_KEYBLOCK							 0x20000000000L		// Key Type variant or keyblock
#define SH_CFG_FWD_CAPTURE                      	 0x40000000000L  //Forward capture msg to issuer
#define SH_CFG_ENABLE_REFNUM_EVENTKEY			0x80000000000L	//Enable REFNUM based eventkey creation to issuer
//Existing bin_cfg bit 30 will be used for tr31 KB versionID configuration
#define SH_KB_VERSIONID_A						0x100000000000L	//Keyblock Version ID cofiguration
#define SH_KB_VERSIONID_B						0x200000000000L	//Keyblock Version ID cofiguration
#define SH_KB_VERSIONID_C						0x400000000000L	//Keyblock Version ID cofiguration
#define SH_KB_VERSIONID_D						0x800000000000L	//Keyblock Version ID cofiguration

//Flags for different SHCBIN config of key block options
#define SH_KB_RACL_ATL_VAR						0x1000000000000L	//Thales KB to use Atalla Variant keys
//flags for SHCBIN.BIN_FLAG field in shared memory - end
//Other defines related to the BIN_CFG 

#define	SH_CFGIX_INTERAC		0  		 /* Interac BIN */
#define	SH_CFGIX_DSQL	   		1  		 /* Dynamic SQL */
#define	SH_CFGIX_NDKE	    	2  		 /* Dynamic Key Exchange */
#define	SH_CFGIX_CHKDUPREV   	3  		 /* Check Duplicate Reversal */

/* R003308 */
#define SH_CFGIX_TRANTIME       4        /* Restore Transmission Time */
#define SH_CFGIX_CAPDATEOVERRIDE      5        /* Capture Date Override */

/* R006087 */
#define SH_CFGIX_AVS_FLAG      6        /* AVS flag */ /* R006274*/
/* R007010 */
#define SH_CFGIX_ACQ_ISS_FLAG   7        /* ACquier-Isuser flag */

//R027905
#define SH_CFGIX_REFUND_VOID_FLAG  8	/* Void and Refund processing flag. */

#define SH_CFGIX_ENABLE_DUAL_SITE_BRIDGE  9     /* Void and Refund processing flag. */

#define shcBinIsInterac(pkg) 		(pkg && (pkg->bin.bin_cfg & SH_CFG_INTERAC))
#define shcBinIsDynamicSQL(pkg)		(pkg && (pkg->bin.bin_cfg & SH_CFG_DSQL))
#define shcBinIsNDKE(pkg) 			(pkg && (pkg->bin.bin_cfg & SH_CFG_NDKE))
#define shcBinIsCheckDupRev(pkg) 	(pkg && (pkg->bin.bin_cfg & SH_CFG_CHKDUPREV))

/* R003308 */
#define shcBinIsRestoreTranTime(pkg) (pkg && (pkg->bin.bin_cfg & SH_CFG_TRANTIME))
#define shcBinIsCapdateOverride(pkg) (pkg && (pkg->bin.bin_cfg & SH_CFG_CAPDATEOVERRIDE))

/* R011822 >> */
#define elecIsAcqParticipate(shcmsg)	(((shcmsg)->msg.shc_devcap & SH_DEVCAP_SHC_ELEC_MASK) | SH_DEVCAP_SHC_REG_ACQUIRER )
#define elecIsMerchParticipate(shcmsg)	(((shcmsg)->msg.shc_devcap & SH_DEVCAP_SHC_ELEC_MASK) | SH_DEVCAP_SHC_REG_MERCHANT )
#define elecIsBothParticipate(shcmsg)	( elecIsAcqParticipate(shcmsg) && elecIsMerchParticipate(shcmsg) )
#define elecIsMasterCardParticipate(shcmsg)	(((shcmsg)->msg.shc_devcap & SH_DEVCAP_SHC_ELEC_MASK) | SH_DEVCAP_SHC_REG_MC_ONLY )
#define elecIsNoneParticipate(shcmsg)	(!((shcmsg)->msg.shc_devcap & SH_DEVCAP_SHC_ELEC_MASK) )

#define shc_set_electronic_acquirer_flag(shcmsg)  \
		( (shcmsg)->msg.shc_devcap |=  SH_DEVCAP_SHC_REG_ACQUIRER )
#define shc_set_electronic_merchant_flag(shcmsg)  \
		( (shcmsg)->msg.shc_devcap |=  SH_DEVCAP_SHC_REG_MERCHANT )
#define shc_set_electronic_mastercard_flag(shcmsg)  \
		( (shcmsg)->msg.shc_devcap |=  SH_DEVCAP_SHC_REG_MC_ONLY )
#define shc_set_electronic_unknown_flag(shcmsg)  \
		( (shcmsg)->msg.shc_devcap &= ~SH_DEVCAP_SHC_ELEC_MASK )
/* << R011822 */

// Stand-only checks begin - perform checks only when in stand in
#define isPostiveSAF(bp)  ((bp)->saf.type & SH_SAF_POSFILE)
#define shcIsStandIn(header)   (header->msg.shc_devcap & SH_DEVCAP_SHC_STDIN)
//CVV defines
#define isCVVEnabled(pkg)    (pkg->bin.flags & SH_CHECKCVV)
#define isCVVEnabledForStandInOnly(pkg) ( (pkg->bin.bin_cfg & SH_CHECKCVV_STANDIN_ONLY) ||  \
													(pkg->bin.bin_cfg & SH_CHECK_CVV_CVV2_STANDIN_ONLY) \
												)
#define isCVVVerifyNeeded(header, pkg) ( isCVVEnabled(pkg) || \
								( isCVVEnabledForStandInOnly(pkg) && shcIsStandIn(header) )  )

#define isCSCEnabledOnlyForStandIn(pkg)  ( pkg->bin.bin_cfg & SH_CSC_CHECK_STAND_IN_ONLY )
//CVV2 defines
#define isCVV2EnabledForStandInOnly(pkg) ( (pkg->bin.bin_cfg & SH_CHECKCVV2_STANDIN_ONLY ) ||  \
											(pkg->bin.bin_cfg &  SH_CHECK_CVV_CVV2_STANDIN_ONLY) )
#define isCVV2VerifyNeeded(header, pkg)  ( shcBinCheckCVV2(pkg) || ( isCVV2EnabledForStandInOnly(pkg) && shcIsStandIn(header) ) )

//DCVV defines
#define isDCVVVerifyEnabled(pkg)  ( pkg->bin.bin_cfg & SH_CFG_DCVV_VERIFY )
#define isDCVVCheckEnabled(pkg)  ( pkg->bin.bin_cfg & SH_CFG_DCVV_CHECK )
#define isDCVVEnabledForStandInOnly(pkg)  ( pkg->bin.bin_cfg & SH_CFG_DCVV_CHECK_VERIFY_STAND_IN_ONLY )
#define isDCVVCheckNeeded(header, pkg)  ( isDCVVCheckEnabled(pkg)  || \
								( isDCVVEnabledForStandInOnly(pkg) && shcIsStandIn(header) ) )
#define isDCVVVerifyNeeded(header, pkg)  ( isDCVVVerifyEnabled(pkg)  || \
								( isDCVVEnabledForStandInOnly(pkg) && shcIsStandIn(header) ) )
//CAVV defines
#define isCAVVEnabledForStandInOnly(pkg)  ( pkg->bin.bin_cfg & SH_CFG_CAVV_3DS_STAND_IN_ONLY )
//PIN define
#define isPINCheckNeededInStandIn(pkg)  ( pkg->bin.flags & SH_CHECKPIN_STAND_IN )

#define isStandInOnlyCheckNeeded(header)	( 	(shcIsAuthorizationRequest(header)) || \
												(shcIsFinancialRequest(header)) \
											)
// Stand-only checks end


#define terminalIsIIASSupport(shcmsg)	((shcmsg)->msg.auth_devcap & SH_DEVCAP_TERMINAL_IIAS_VERIFIED )

#define shc_set_terminal_IIAS_support(shcmsg)  \
		( (shcmsg)->msg.auth_devcap |=  SH_DEVCAP_TERMINAL_IIAS_VERIFIED )

/*--------------------------------------------------------------------------*
 * Additional Amount Segment (ADDITIONAL_AMTS) Tag Group Define Block
 *--------------------------------------------------------------------------*/
#define SHC_ADDITIONAL_AMOUNT_SEG                    "ADDITIONAL_AMTS"

#define SHC_ADD_AMOUNT_HEALTHCARE                    2  /* Healthcare Group */
#define SHC_ADD_AMOUNT_TRANSIT                       3  /* Transit Group */
#define SHC_ADD_AMOUNT_CURRENCY_CONVERSION           4  /* Currency Conversion Group */

/* Amount Type Internal Shared Value (Formatter needs to map them to their
 * accpetable external value by formatter itself)
 */
/* FSA Eligible Expenditure */
#define SHC_AMOUNT_TYPE_FSA_ELIG_EXPEND              10
/* Prescription Eligibility Amount */
#define SHC_AMOUNT_TYPE_PRESCRIPTION_ELIG_AMT        11
/* Vision Rx Eligibility Amount*/
#define SHC_AMOUNT_TYPE_VISIONRX_ELIGIBILITY_AMT     12
/* Original Amount */
#define SHC_AMOUNT_TYPE_ORIGINAL_AMT                 57
/* Transaction Amount in merchant's local currency (POI Amount) */
#define SHC_AMOUNT_TYPE_POI_AMT                      58
/* Healthcare Co-pay Amount */
#define SHC_AMOUNT_TYPE_CO_PAY_AMT                   80
/*--------------------------------------------------------------------------*
 * Additional Amount Segment (ADDITIONAL_AMTS) Tag Group Block end
 *--------------------------------------------------------------------------*/


/*
 * These indexes refer to the database field bin_cfg. The bin
 *		configuration is held in an array. It is very important that we
 *		don't mess around with the order of the fields. Note that this only
 *		affects the INIT program and does nothing to the runtime.
 *
 *		To add a new transaction:
 *
 *		1.		added to the database screen
 *		2.		add the index in SH_CFGIDX_????
 *		3.		add the flag value as SH_CFG_????
 * 		4.		Edit shc_data.c and add the definition in the shc_bin_cfg[]
 * 				table.
 *
*/
struct	shc_bin_cfg
{
	int		offset;
	unsigned int	flag;
	const char	*desc;
};

SHCDLLEXPORT extern	struct shc_bin_cfg shc_bin_cfg[];

/*------------------------------------------------------------------------*
 * Bin Level Configuration Defines (R001835)    End
 *------------------------------------------------------------------------*/

	/* R007206 & R007237 >> Support for Europay BIN/MBR checking */
/* Terminal Category */
#define	EU_BIN_MASK_TERMINAL	0x000f
#define	EU_BIN_ATM		0x0001	/*  A	EU_BIN_ATM */
#define	EU_BIN_POS		0x0002	/*  P	EU_BIN_POS */
#define	EU_BIN_NOTERM	0x0004	/*  N	EU_BIN_NOTERM */

/* Acceptance Domain */
#define EU_BIN_DOMESTIC	0x0010
#define EU_BIN_EUROPEAN	0x0020
#define EU_BIN_WORLD	0x0040

/* ATM Acquirer */
#define	EU_BIN_MASK_ATM_ACQ		0xff00
#define	EU_BIN_ECHA		0x0100	/*	EU_BIN_EUCHEQUE		*/
#define	EU_BIN_CRUS		0x0200  /*	EU_BIN_CIRRUS		*/
#define	EU_BIN_ECCR		0x0400  /*	EU_BIN_EUCHK_CIRRUS	*/
#define	EU_BIN_MAES		0x0800  /*	EU_BIN_MAESTRO		*/

/* Eurocard-MasterCard Acquirer */
#define EU_BIN_MASK_CARD_ACQ	0xf000
#define	EU_BIN_ECMC		0x1000  /*	EU_BIN_EURO-MASTERCARD	*/
#define	EU_BIN_MAST		0x2000  /*	EU_BIN_MASTERCARD	*/

#define EU_BIN_HEADER	"06:"		/* R007927 */
//#define EU_BIN_FLAG		"Europay_Entry_Flag"
	/* << R007206 & R007237 */

#define mGetAcctLenBit(len)	(1 << (len>10 ? (len-10) : 0))	/* R009399 */

/*------------------------------------------------------------------------*
 * Segment Field Name Defines (R008056)
 *------------------------------------------------------------------------*/
#define SEG_MERCHANT_NAME	"MERCHANT_NAME"

/*------------------------------------------------------------------------*
 * Segment Options Action Value Defines (R008056)
 *------------------------------------------------------------------------*/
//#define	SHC_LOGSEG_INSERT	0x0001
//#define	SHC_LOGSEG_UPDATE	0x0002
#define		SHC_SEG_RESTORE		0x0003

//Following 2 macros convert visa flags in network_data
#define visaCharToFlag(c) (c-0x21)
#define visaFlagToChar(i) ((char)(i+0x21))

//Definitions for Visa Flags
#define VISA_SHARED_DEPOSITS_INDICATOR 		0x01

//Macro for network_data for visa card
#define NETWORK_DATA_VISA_FLAG_INDEX 	7

//Macro for SHCEXTBINDB.NETWORK_CONFIG
#define SH_NETWORK_CONFIG_IDX_TOKEN_IND	0

#define shcIsTokenInd(nwconfig)  ( nwconfig[SH_NETWORK_CONFIG_IDX_TOKEN_IND] == 'Y' )

// Macros for RAFT SHCCEXTBINDB.NETWORK_DATA
// shcextbindb.network_data[3]
#define RAFT_DEBIT_FLAG				0x0001		
#define RAFT_CHECK_CARD_FLAG 			0x0002		
#define RAFT_CREDIT_CARD_FLAG			0x0004			
#define RAFT_CARD_HOLD_FUNDS_TRANSFER_FLAG	0x0008
// shcextbindb.network_data[4]
#define RAFT_DURAL_MESSAGE_FLAG			0x0001	
#define RAFT_INTERNATIONAL_FLAG			0x0002	
#define RAFT_CURRENCY_CONVENTION_FLAG		0x0004
#define RAFT_COMMERCIAL_BUSINESS_CARD_FLAG	0x0008
// shcextbindb.network_data[5]
#define RAFT_FLEET_CARD_FLAG			0x0001
#define RAFT_PREPAID_CARD_FLAG			0x0002
#define RAFT_RELOAD_FLAG 			0x0004		
#define RAFT_HSA_FLAG				0x0008
// shcextbindb.network_data[6]
#define RAFT_FSA_FLAG				0x0001
#define RAFT_EBT_FLAG				0x0002
#define RAFT_WIC_FLAG				0x0004
// #define RAFT_PINLESS_POS_FLAG		0x0000	 // need confirm, hold the bit with 0x0000 in case
// shcextbindb.network_data[7]
#define RAFT_PINLESS_BILL_PAY_FLAG		0x0001
#define RAFT_TOKEN_FLAG				0x0002
#define RAFT_ECOMMERCE_FLAG			0x0004
#define RAFT_ECOMMERCE_FLAG_BILLPAY 		0x0100
#define RAFT_NET_DATA_FLAG			0x0007
// shcextbindb.network_data[8]:			RAFT_NETWORK_REGULATION_VALUE
// shcextbindb.network_data[9]:			RAFT_PINLESS_POS_FLAG  // need confirm, treated as non Y-N flag 

/* R016678 >> MasterCard Product Codes for network_data field in shcextbindb */
#define MC_ND_CIR 0x00000001
#define MC_ND_MBE 0x00000002
#define MC_ND_MCB 0x00000004
#define MC_ND_MCC 0x00000008
#define MC_ND_MCD 0x00000010
#define MC_ND_MCE 0x00000020
#define MC_ND_MCF 0x00000040
#define MC_ND_MCG 0x00000080
#define MC_ND_MCO 0x00000100
#define MC_ND_MCP 0x00000200
#define MC_ND_MCS 0x00000400
#define MC_ND_MCW 0x00000800
#define MC_ND_MDG 0x00001000
#define MC_ND_MDO 0x00002000
#define MC_ND_MDP 0x00004000
#define MC_ND_MDR 0x00008000
#define MC_ND_MDS 0x00010000
#define MC_ND_MEC 0x00020000
#define MC_ND_MNW 0x00040000
#define MC_ND_MPL 0x00080000
#define MC_ND_MPP 0x00100000
#define MC_ND_MSI 0x00200000
#define MC_ND_PMC 0x00400000
#define MC_ND_PMD 0x00800000
#define MC_ND_PSC 0x01000000
#define MC_ND_PSD 0x02000000
#define MC_ND_SOL 0x04000000
#define MC_ND_SWI 0x08000000

#define MC_ND_PVL 0x08000001
#define MC_ND_MAV 0x08000002
#define MC_ND_PRO 0x08000003
#define MC_ND_WBE 0x08000004
#define MC_ND_DAG 0x08000005
#define MC_ND_DAP 0x08000006
#define MC_ND_DAS 0x08000007
#define MC_ND_DOS 0x08000008
#define MC_ND_MOC 0x08000009
#define MC_ND_SAS 0x08000010
#define MC_ND_SAG 0x08000011
#define MC_ND_SAL 0x08000012
#define MC_ND_SAP 0x08000013
#define MC_ND_SOS 0x08000014
#define MC_ND_MBP 0x08000015
#define MC_ND_MBT 0x08000016
#define MC_ND_VIS 0x08000017     
#define MC_ND_AMX 0x08000018
#define MC_ND_CBL 0x08000019
#define MC_ND_DCC 0x08000020
#define MC_ND_DLG 0x08000021
#define MC_ND_DLH 0x08000022
#define MC_ND_DLI 0x08000023
#define MC_ND_DLP 0x08000024
#define MC_ND_DLS 0x08000025
#define MC_ND_DLU 0x08000026
#define MC_ND_EXC 0x08000027
#define MC_ND_HNR 0x08000028
#define MC_ND_ITT 0x08000029
#define MC_ND_JCB 0x08000030
#define MC_ND_LNC 0x08000031
#define MC_ND_MAB 0x08000032
#define MC_ND_MAC 0x08000033
#define MC_ND_MBD 0x08000034
#define MC_ND_MBK 0x08000035
#define MC_ND_MCA 0x08000036
#define MC_ND_MCH 0x08000037
#define MC_ND_MCM 0x08000038
#define MC_ND_MCT 0x08000039
#define MC_ND_MCU 0x08000040
#define MC_ND_MCV 0x08000041
#define MC_ND_MDB 0x08000042
#define MC_ND_MDH 0x08000043
#define MC_ND_MDJ 0x08000044
#define MC_ND_MDL 0x08000045
#define MC_ND_MDM 0x08000046
#define MC_ND_MDN 0x08000047
#define MC_ND_MDQ 0x08000048
#define MC_ND_MDT 0x08000049
#define MC_ND_MDU 0x08000050
#define MC_ND_MEB 0x08000051
#define MC_ND_MED 0x08000052
#define MC_ND_MEF 0x08000053
#define MC_ND_MEO 0x08000054
#define MC_ND_MEP 0x08000055
#define MC_ND_MFB 0x08000056
#define MC_ND_MFD 0x08000057
#define MC_ND_MFE 0x08000058
#define MC_ND_MFH 0x08000059
#define MC_ND_MFL 0x08000060
#define MC_ND_MFW 0x08000061
#define MC_ND_MGF 0x08000062
#define MC_ND_MHA 0x08000063
#define MC_ND_MHB 0x08000064
#define MC_ND_MHC 0x08000065
#define MC_ND_MHH 0x08000066
#define MC_ND_MIA 0x08000067
#define MC_ND_MIB 0x08000068
#define MC_ND_MIC 0x08000069
#define MC_ND_MID 0x08000070
#define MC_ND_MIG 0x08000071
#define MC_ND_MIH 0x08000072
#define MC_ND_MIJ 0x08000073
#define MC_ND_MIK 0x08000074
#define MC_ND_MIL 0x08000075
#define MC_ND_MIP 0x08000076
#define MC_ND_MIS 0x08000077
#define MC_ND_MIU 0x08000078
#define MC_ND_MLA 0x08000079
#define MC_ND_MLC 0x08000080
#define MC_ND_MLD 0x08000081
#define MC_ND_MLL 0x08000082
#define MC_ND_MNF 0x08000083
#define MC_ND_MOG 0x08000084
#define MC_ND_MOP 0x08000085
#define MC_ND_MOW 0x08000086
#define MC_ND_MPA 0x08000087
#define MC_ND_MPB 0x08000088
#define MC_ND_MPC 0x08000089
#define MC_ND_MPF 0x08000090
#define MC_ND_MPG 0x08000091
#define MC_ND_MPJ 0x08000092
#define MC_ND_MPK 0x08000093
#define MC_ND_MPM 0x08000094
#define MC_ND_MPN 0x08000095
#define MC_ND_MPO 0x08000096
#define MC_ND_MPR 0x08000097
#define MC_ND_MPT 0x08000098
#define MC_ND_MPV 0x08000099
#define MC_ND_MPW 0x08000100
#define MC_ND_MPX 0x08000101
#define MC_ND_MPY 0x08000102
#define MC_ND_MPZ 0x08000103
#define MC_ND_MRB 0x08000104
#define MC_ND_MRC 0x08000105
#define MC_ND_MRF 0x08000106
#define MC_ND_MRG 0x08000107
#define MC_ND_MRH 0x08000108
#define MC_ND_MRJ 0x08000109
#define MC_ND_MRL 0x08000110
#define MC_ND_MRK 0x08000111
#define MC_ND_MRO 0x08000112
#define MC_ND_MRP 0x08000113
#define MC_ND_MRS 0x08000114
#define MC_ND_MRW 0x08000115
#define MC_ND_MSA 0x08000116
#define MC_ND_MSB 0x08000117
#define MC_ND_MSD 0x08000118
#define MC_ND_MSF 0x08000119
#define MC_ND_MSG 0x08000120
#define MC_ND_MSJ 0x08000121
#define MC_ND_MSM 0x08000122
#define MC_ND_MSN 0x08000123
#define MC_ND_MSO 0x08000124
#define MC_ND_MSQ 0x08000125
#define MC_ND_MSR 0x08000126
#define MC_ND_MSS 0x08000127
#define MC_ND_MST 0x08000128
#define MC_ND_MSV 0x08000129
#define MC_ND_MSW 0x08000130
#define MC_ND_MSX 0x08000131
#define MC_ND_MSY 0x08000132
#define MC_ND_MSZ 0x08000133
#define MC_ND_MUP 0x08000134
#define MC_ND_MUS 0x08000135
#define MC_ND_MUW 0x08000136
#define MC_ND_MWB 0x08000137
#define MC_ND_MWD 0x08000138
#define MC_ND_MWE 0x08000139
#define MC_ND_MWO 0x08000140
#define MC_ND_MWR 0x08000141
#define MC_ND_NYC 0x08000142
#define MC_ND_OLB 0x08000143
#define MC_ND_OLG 0x08000144
#define MC_ND_OLI 0x08000145
#define MC_ND_OLP 0x08000146
#define MC_ND_OLS 0x08000147
#define MC_ND_OLW 0x08000148
#define MC_ND_PLU 0x08000149
#define MC_ND_PUL 0x08000150
#define MC_ND_PVA 0x08000151
#define MC_ND_PVB 0x08000152
#define MC_ND_PVC 0x08000153
#define MC_ND_PVD 0x08000154
#define MC_ND_PVE 0x08000155
#define MC_ND_PVF 0x08000156
#define MC_ND_PVG 0x08000157
#define MC_ND_PVH 0x08000158
#define MC_ND_PVI 0x08000159
#define MC_ND_PVJ 0x08000160
#define MC_ND_STR 0x08000161
#define MC_ND_SUR 0x08000162
#define MC_ND_TBE 0x08000163
#define MC_ND_TCB 0x08000164
#define MC_ND_TCC 0x08000165
#define MC_ND_TCE 0x08000166
#define MC_ND_TCF 0x08000167
#define MC_ND_TCG 0x08000168
#define MC_ND_TCO 0x08000169
#define MC_ND_TCP 0x08000170
#define MC_ND_TCS 0x08000171
#define MC_ND_TCW 0x08000172
#define MC_ND_TDN 0x08000173
#define MC_ND_TEB 0x08000174
#define MC_ND_TEC 0x08000175
#define MC_ND_TEO 0x08000176
#define MC_ND_TIB 0x08000177
#define MC_ND_TIC 0x08000178
#define MC_ND_TIU 0x08000179
#define MC_ND_TLA 0x08000180
#define MC_ND_TNF 0x08000181
#define MC_ND_TNW 0x08000182
#define MC_ND_TPB 0x08000183
#define MC_ND_TPC 0x08000184
#define MC_ND_TPL 0x08000185
#define MC_ND_DMC 0x08000186
#define MC_ND_MPH 0x08000187
#define MC_ND_MBF 0x08000188
#define MC_ND_MTP 0x08000189
#define MC_ND_MBM 0x08000190
#define MC_ND_MBB 0x08000191
#define MC_ND_MBC 0x08000192
#define MC_ND_MHD 0x08000193
#define MC_ND_MHL 0x08000194
#define MC_ND_MHM 0x08000195
#define MC_ND_MHN 0x08000196
#define MC_ND_MAQ 0x08000197
#define MC_ND_MDW 0x08000198
#define MC_ND_MLF 0x08000199
#define MC_ND_MAP 0x08000200
#define MC_ND_MLB 0x08000201
#define MC_ND_MLE 0x08000202
#define MC_ND_MBS 0x08000203
#define MC_ND_TWB 0x08000204
#define MC_ND_MBW 0x08000205
#define MC_ND_BPD 0x08000206
#define MC_ND_DWF 0x08000207
#define MC_ND_MWF 0x08000208
#define MC_ND_MPD 0x08000209
#define MC_ND_MWP 0x08000210
#define MC_ND_MET 0x08000211
#define MC_ND_WPD 0x08000212 
#define MC_ND_ACS 0x08000213
#define MC_ND_MDK 0x08000214 
#define MC_ND_MDI 0x08000215

#define MC_ND_DCS 0x08000216
#define MC_ND_DCG 0x08000217
#define MC_ND_DPL 0x08000218
#define MC_ND_DRG 0x08000219
#define MC_ND_DCB 0x08000220
#define MC_ND_DBK 0x08000221
#define MC_ND_DCO 0x08000222
#define MC_ND_DRW 0x08000223
#define MC_ND_DCR 0x08000224
#define MC_ND_DLA 0x08000225
#define MC_ND_DLL 0x08000226
#define MC_ND_DLD 0x08000227
#define MC_ND_DLB 0x08000228
#define MC_ND_DTP 0x08000229
#define MC_ND_DWB 0x08000230
#define MC_ND_DLE 0x08000231
#define MC_ND_DEC 0x08000232
#define MC_ND_DLF 0x08000233
#define MC_ND_DPE 0x08000234
#define MC_ND_DBS 0x08000235

#define MC_ND_MVA 0x08000236
#define MC_ND_MVB 0x08000237
#define MC_ND_MVC 0x08000238
#define MC_ND_MVD 0x08000239
#define MC_ND_MVE 0x08000240
#define MC_ND_MVF 0x08000241
#define MC_ND_MVG 0x08000242
#define MC_ND_MVH 0x08000243
#define MC_ND_MVI 0x08000244
#define MC_ND_MVJ 0x08000245
#define MC_ND_MVK 0x08000246

#define MC_ND_MES 0x08000247

#define MC_ND_MGS 0x08000248
#define MC_ND_MRD 0x08000249

#define MC_ND_MGP 0x08000250

#define MC_ND_MPE 0x08000253
#define MC_ND_MSP 0x08000254
#define MC_ND_MCI 0x08000255
#define MC_ND_MBA 0x08000256
#define MC_ND_MBG 0x08000257
#define MC_ND_MBH 0x08000258
#define MC_ND_MBI 0x08000259
#define MC_ND_MBJ 0x08000260
#define MC_ND_MKA 0x08000261
#define MC_ND_MKB 0x08000262
#define MC_ND_MKC 0x08000263
#define MC_ND_MKD 0x08000264
#define MC_ND_MKE 0x08000265
#define MC_ND_MKF 0x08000266
#define MC_ND_MKG 0x08000267
#define MC_ND_MKH 0x08000268
#define MC_ND_MVL 0x08000269
#define MC_ND_MVM 0x08000270
#define MC_ND_MVN 0x08000271
#define MC_ND_BPC 0x08000272
#define MC_ND_GCS 0x08000273
#define MC_ND_GCP 0x08000274
#define MC_ND_MHG 0x08000275
#define MC_ND_MHP 0x08000276
#define MC_ND_MHS 0x08000277
#define MC_ND_MNS 0x08000278
#define MC_ND_DDG 0x08000279
#define MC_ND_DDS 0x08000280
#define MC_ND_MDE 0x08000281
#define MC_ND_MXG 0x08000282
#define MC_ND_MXO 0x08000283
#define MC_ND_MXP 0x08000284
#define MC_ND_MXR 0x08000285
#define MC_ND_MXS 0x08000286
#define MC_ND_MHW 0x08000287
#define MC_ND_MPQ 0x08000288
#define MC_ND_MIO 0x08000289
#define MC_ND_FIA 0x08000290
#define MC_ND_FIB 0x08000291
#define MC_ND_FIC 0x08000292
#define MC_ND_FID 0x08000293
#define MC_ND_FIE 0x08000294
#define MC_ND_FIF 0x08000295
#define MC_ND_FIG 0x08000296
#define MC_ND_FIH 0x08000297
#define MC_ND_MVO 0x08000298
#define MC_ND_MVP 0x08000299
#define MC_ND_MVQ 0x08000300
#define MC_ND_MVR 0x08000301
#define MC_ND_MVS 0x08000302
#define MC_ND_MVT 0x08000303
#define MC_ND_MVU 0x08000304
#define MC_ND_MVV 0x08000305
#define MC_ND_MVW 0x08000306
#define MC_ND_MVX 0x08000307
#define MC_ND_MVY 0x08000308
#define MC_ND_MVZ 0x08000309
#define MC_ND_ETA 0x08000310
#define MC_ND_ETB 0x08000311
#define MC_ND_ETC 0x08000312
#define MC_ND_ETD 0x08000313
#define MC_ND_ETE 0x08000314
#define MC_ND_ETF 0x08000315
#define MC_ND_ETG 0x08000316
#define MC_ND_SPP 0x08000317
#define MC_ND_SPS 0x08000318
#define MC_ND_SBP 0x08000319
#define MC_ND_BDP 0x08000320
#define MC_ND_ETH 0x08000321
#define MC_ND_ETI 0x08000322
#define MC_ND_ETJ 0x08000323
#define MC_ND_ETK 0x08000324
#define MC_ND_ETL 0x08000325
#define MC_ND_ETM 0x08000326
#define MC_ND_ETN 0x08000327
#define MC_ND_SBJ 0x08000328
#define MC_ND_SBK 0x08000329
#define MC_ND_MTA 0x08000330
#define MC_ND_MTB 0x08000331
#define MC_ND_MTC 0x08000332
#define MC_ND_MTD 0x08000333
#define MC_ND_MTE 0x08000334
#define MC_ND_MTF 0x08000335
#define MC_ND_MTG 0x08000336
#define MC_ND_MTH 0x08000337
#define MC_ND_MTI 0x08000338
#define MC_ND_MTJ 0x08000339
#define MC_ND_MTK 0x08000340
#define MC_ND_MTL 0x08000341
#define MC_ND_MTM 0x08000342
#define MC_ND_MTN 0x08000343
#define MC_ND_MTO 0x08000345
#define MC_ND_MTQ 0x08000346
#define MC_ND_MTR 0x08000347
#define MC_ND_MTS 0x08000348
#define MC_ND_MTT 0x08000349
#define MC_ND_MTU 0x08000350
#define MC_ND_MTV 0x08000351


#define SHC_ISTAUTH_FILE_UPD_FUNCTION_TYPE_ACCOUNT_LEVEL	"01"
#define SHC_ISTAUTH_FILE_UPD_FUNCTION_TYPE_CARD_LEVEL		"02"

#define SHC_ISTAUTH_FILE_UPD_FUNCTION_CODE_ADD				"01"
#define SHC_ISTAUTH_FILE_UPD_FUNCTION_CODE_DEL				"02"
#define SHC_ISTAUTH_FILE_UPD_FUNCTION_CODE_UPD				"03"

//Card type indicator index definitions for segment 
#define CARD_TYPE_IND_DUBIN_REGULATED		 0
#define CARD_TYPE_IND_COMMERCIAL_CARD		 1
#define CARD_TYPE_IND_PREPAID_CARD			 2
#define CARD_TYPE_IND_PAYROLL_CARD			 3
#define CARD_TYPE_IND_HEALTHCARE_CARD		 4
#define CARD_TYPE_IND_AFFLUENT_CATEGORY		 5
#define CARD_TYPE_IND_SIGNATURE_DEBIT		 6
#define CARD_TYPE_IND_PINLESS_DEBIT			 7
#define CARD_TYPE_IND_L3INTERCHANGE_ELIGIBLE 8
#define CARD_TYPE_IND_INTERNATIONAL_CARD	 9
/* R016678 << */

/*------------------------------------------------------------------------*
 * Old History Block (1989 -- 1995)
 *------------------------------------------------------------------------*/
/*
 *  Who	    Date	    Description			Who	Date
 * ===========================================================================
 *	ad		26dec91		Added message type 6000 to tag late messages.
 *	ad		30dec91		Added log message request (8000)
 *	ad		30dec91		Added macro to determine if log request
 *	ad		03Jan92		Added new ISO codes to support POS Terminals
 *	ad		03Jan92		Added added macro to inquire about pre-auth req
 *	ad		08jan92		Added network defines for close day/batch
 *	ad		08jan92		added flags and macros for CCSTLMT
 *	ss		09jan92		Add define for how authnum is generated
 *	ss		13jan92		Add define shcExtBinRecordUpdated for extbin support
 *	ad		01feb92		Added define for SHC_NET_MARKDOWN
 *	ad		02feb92		Added define DEVCAP_KEEP_FORMATTER_USE
 *	ad		06feb92		Added define SHC_NET_GET_TOTALS
 *	ad		03mar92		Added SHC_SERVICE_REQUEST and related defines
 *	ad		07mar92		Added more service request functions
 *	ad		18mar92		Added device cap option to indicate replay
 *	ad		02apr92		Added ServiceRouteIssuer/Acquirer/Invalid PIN
 *	ad		04apr92		Added support for Trace Server
 *	ss		04apr92		Add two defines
 *								SHC_FILEUPD_ACQREQ_ADVICE			320
 *								SHC_FILEUPD_ACQREQ_ADVICE_RESPONSE	330
 *	ss		15apr92		Add define	 shcIsFileUpdateRequest(shcmsg)
 *	ss		29Apr92		Add define for shcServiceRouteToSender
 *	ad/ss	02may92		Added defines for shcServiceManage... and
 *						shcServiceRespondToSender
 *	ss		07Mar92		Added defines from shc_unset_fromdevice
 *	ss		18May92		Added define SH_ACCT_FASTCASH for acct. type
 *	ss		25May92		Added define shcIsCreditTxn.
 *	ad		27may92		Added shcServiceMarkCardStatus
 *	bsa		30jul92		Added flag SH_GETAPP_HOST
 *	bsa		30jul92		Added flag SH_NOREVUPD so that if
 *						SH_GETAPP_HOST set and timeout of 400 we
 *						do NOT create a 410 in database
 *	ad		31Jul92		Added SH_TDIX_REVFLAG
 *	ad		12aug92		Added DEVCAP_KEEPORIGINATOR
 *	ss		12Aug92		Added SH_DEVCAP_FROMIBM4730
 *	ad		09sep92		Added shcIs03xx() and other info for 03xx processing
 *	ad		23oct92		Added SH_CHKFLRLIM, SH_SENDREV, SH_SAFAUTH
 *	ad		23oct92		Added DEVCAP_INTERNAL_REV
 *	ss		04Nov92		Added SH_SENDREV_ALWAYS
 *	ad		13nov92		Added SH_DEVCAP_EBCDIC
 *	ad		20nov92		Added SHC_NET_STOPREPLAY
 *	ad		24nov92		Added SH_SENDACK and related flags
 *	ad		24nov92		Added SH_ISO_CARDVALIDATE
 *						SH_ISO_TERMINAL_REQUEST
 *	ad		26nov92		Added SH_PREAUTH_ON_VALIDATE flag so we only
 *						switch to preauth on validation request
 *	ad		28nov92		Added shcGetISOClass(pcode)
 *	ad		06dec92		Added DEVCAP_KEEP_ACCEPTORNAME
 *	ad		06Jan93		Added DEVCAP_FROM_NETWORK
 *  bsa     10Feb93     Added SH_DEVCAP_INGORE_SERIAL
 *	ad		13mar93		Added SH_ISO_POSDEBIT
 *  bsa     23Mar93     Added SH_POS_PANENTRY_TRK1OR2.
 *	ad		29apr93		Added flag SH_CHECKDUP to allow an issuer to maitain
 *						information in the shccard to allow duplicate txn
 *						checking. This applies only to Auth transactions.
 *  MI      18May93     Added SH_ISO_PREAUTHRESP, SH_ISO_PREAUTHREQ
 *						and SH_ISO_PREAUTHCONF
 *  MI      18May93     Added shcIsPreAuthRsp and shcIsPreAuthReq
 *  MI      18May93     Added SHC_PREAUTH_SERVICEREQ
 *                            SHC_PREAUTH_SERVICERSP
 *  MI      20May93     Added shcIsPreauthServRsp and shcIsPreauthServReq
 *  MI      20May93     Added PreauthServInsRec and PreauthServRetRec
 *	MI		20May93		Added SH_PREAUTH_SUPPORT
 *	MI		25May93		preauth bintype:PREAUTH(ALLOWED,FORWARD,REVERSE)
 *	aes		18Jun93		Added SH_CURRENCY_CONV and SH_TXIDX_CURRENCY_CONV
 *						in order to support currency conversion.
 *	jsg		01Jul93		Modified shcIsFileUpdateRequest to look at third order
 *						digit only.
 *	ad		05jul93		Added SH_ONUS_BIN define,
 *						shcServiceRequestRouteToOnUsIssuer
 *						SH_ISO_INQACCT
 *	ss		09Jul93		Add define SH_ISO_PASSBOOK_UPD_REQUEST
 *	MI		09Jul93		Add preauth state of confirmation request
 *						SH_DEVCAP_PREAGENT_STATE and SH_DEVCAP_PROAGENT_STATE
 *	MI		12Jul93		Check if preauth,reversal or forward are allowed
 *	ad/es	06aug93		Added SHC_NET_CUTOVER_COMPLETE (citi share project)
 *	ad		14aug93		Added SH_DEVCAP_USER_SEGMENT
 *	ad		04nov93		Added SH_ISO_TC
 *	ad		16Nov93		Added SHC_NET_TERM_KEY
 *  wo      10Feb94     Added SHC_SPAN_KEYS_START
 * wo      10Feb94     Added SHC_SPAN_KEYS
 * wo      10Feb94     Added SHC_SPAN_PIN_KEY  (P-48)
 * wo      10Feb94     Added SHC_SPAN_MAC_KEY  (P-48)
 * wo      10Feb94     Added SHC_SPAN_ACQ
 * wo      10Feb94     Added SHC_SPAN_ISS
 * av		02Mar94		Added shcIsRevAdvice(shcmsg)
 * ss		03mar94		Merger Nabanco code. Foumd conflict of defeine, but
 *						I think it should be OK. DO YOU ?
 *--------------------------------------------------------------------------
 * ad		04Mar94		Merge code from other systems. Base line start HERE
 *--------------------------------------------------------------------------
 * aes		06Mar94		Added SH_POS_CAP_CONF_PENDING for confirmation
 *						of pending transactions.
 * aes		06Mar94		Added the macro shcIsConfirmPending(shcmsg).
 * aes		06Mar94		Added SH_POS_CAP_ACK_PROCESSED for processing a
 *						a 9000/280 msg which has been processed already.
 * aes		06Mar94		Added the macro shcIsAckProcessed(shcmsg).
 * ad		24apr94		Added define SH_DEVCAP_KEEP_PCODE: This uses the same
 *						number as SH_DEVCAP_EBCDIC (which is no longer needed).
 * jsg		26apr94		Added SHC_NETWORK_ADVICE_REPEAT;
 * ad		08jul94		Added transfer cnf (1 and 2)
 * jsg		26jul94		Added devcap SH_DEVCAP_DUPLICATE_TXN back in.
 * pk		12sep94		Added macro definitions for identifying origin of
 *						denied transactions. This to help in FEE calculation.
 *						Field effected: extract_flags in shclog
 *							SH_XFLAG_SWITCH_DENY
 *							SH_XFLAG_NETWRK_DENY
 * edc		27Sep94		Added SHC_NET_GROUPSIGNON_START and
 *	                    SHC_NET_GROUPSIGNOFF_START (for group sign-on/off and
 *						patterned after individual sign-on/off)
 * qd		20jun95		Add define for SH_DEVCAP_TERMINALREV and macro for it
 *						used by term8583 formatter
 * aw		27jun95		changed SH_DEVCAP_TERMINALREV to 0x4000?000 to
 *						coordinate the changes from SAMBA.
 * qd		27jun95		Merged SH_DEVCAP_HAS_EXPDATE from v2ndsrvECUnac
 * la		21jul95		Added shcServiceUpdateRespcode for respcode updates.
 * MI	    13Aug95     Should we overwrite capture date from network
 */
/* R005156 */
#ifdef __cplusplus
}
#endif
/* R005156 */

enum {
	T_ROLE_CUTOVER = 0x1000,
	T_ROLE_RECON   = 0x2000,
	T_ROLE_RECON_ISSUER_COMBINED = 0x4000,
	T_ROLE_CUTOVER_RECON_COMBINED = 0x8000  /* R010384 */
};

int shc_isdown(struct shcpkg *bp);

#endif
/*------------------------------------------------------------------------*
 * End of File shcdef.h
 *------------------------------------------------------------------------*/
