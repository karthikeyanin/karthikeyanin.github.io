#ifndef _SHCSHCREVMRHELPER_H_
#define	_SHCSHCREVMRHELPER_H_ 

static char _ShcRevMRHelper_h_what[] =  "@(#) ShcRevMRHelper.h 1.1 15/01/20 14:49:09";

/*
 *  Copyright (C) 2004 eFunds Corporation ("eFunds").  All Rights Reserved.     
 *  eFunds Canada Corporation is an authorized user.                            
 *                                                                              
 *  IST is a registered trademark of eFunds Corporation.  Other brand or        
 *  product names are trademarks or registered trademarks of their respective   
 *  holders.                                                                    
 *                                                                              
 *  The information contained herein is the unpublished proprietary property    
 *  of eFunds.  Except as specifically authorized in writing by eFunds, the     
 *  holder of this document shall: i) keep all information contained herein     
 *  confidential, and ii) protect the information, in whole or in part, from    
 *  disclosure and dissemination to all third parties.                          
 *                                                                          
 *  This document and the software described in it are furnished under license  
 *  and may be used or copied only in accordance with the terms of such license.
 *  This document is supplied for information purposes only, is subject to      
 *  change without notice, and should not be construed as a commitment by       
 *  either eFunds Corporation or eFunds Canada Corporation. 
 *
 *                        MODIFICATION HISTORY                  REVIEW
 *
 * SCR#     Who    Date  Description
 * ===========================================================================
 *
 */
 
#include <ShcHelperBase.h>
#include <ShcmsgHeader.h>
#include <oc/oc_string.h>

const char* const SHCREVMRHELPER_OBJ_NAME = "ShcRevMRHelper";

class ShcRevMRHelper:public ShcHelperBase
{
	public:
	
	ShcRevMRHelper();
	virtual ~ShcRevMRHelper();
	static ShcRevMRHelper* getInstance();

	virtual const char *getName(){return SHCREVMRHELPER_OBJ_NAME;};

	virtual int revOrigMRMessage(OCString& msg);
	virtual int revNoOrigMRMessage(OCString& msg);

	virtual int setSegmentRevOrig(ShcmsgHeader  *header);
	virtual int setSegmentRevNoOrig(ShcmsgHeader  *header);


};






#endif

