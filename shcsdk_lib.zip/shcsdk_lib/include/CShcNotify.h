#ifndef _SHCNOTIFY_H_
#define _SHCNOTIFY_H_

static char _ShcNotify_h_what[] = "@(#) CShcNotify.h 1.4 05/01/10 14:55:29";

/*
 *	IST and IST/Share are registered trademarks of Oasis Technology Ltd.
 *
 *	Copyright (C) 1990 - 2003 Oasis Technology Ltd. 
 *	All Rights Reserved
 *	This Module contains Proprietary Information of
 *	Oasis Technology Ltd., and should be treated as Confidential.
 *
 *	THIS IS UNPUBLISHED PROPRIETARY SOURCE CODE OF OASIS TECHNOLOGY LTD.
 *	The copyright notice above does not evidence any  
 *	actual or intended publication of such source code.
 *
 *
 *                        MODIFICATION HISTORY                  REVIEW
 *
 * SCR#     Who    Date  Description
 * ===========================================================================
 * R0xxxxx ztang 05Nov03 Creation
 */
 

#include <ShcSdkCommon.h>
#include <shcextbuf.h>
#include <ShcHelperBase.h>

class ShcNotify : public ShcHelperBase
{
public:
    const char *getName()
    {
        return (const char *)SHC_ShcNotify;
    }

	virtual int	shc_notify_echo( ShcmsgHeader *header );
	virtual int shc_notify_build( ShcmsgHeader *header, struct istadvice *amsg, int len);
	virtual int shc_notify_construct_tag( ShcmsgHeader *header, struct istadvice *amsg);
	virtual int shc_notify_adjust_msg( struct istadvice *amsg );
	virtual int	shc_notify_send( struct istadvice *amsg , int len);
	virtual int shc_notify_netcode_allowed(ShcmsgHeader *header);
	virtual	int shcIsNotifyOn(ShcmsgHeader *header);
};

#endif

