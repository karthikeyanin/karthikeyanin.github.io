#ifndef _SHC_HELPER_BASE_H_
#define _SHC_HELPER_BASE_H_

static char _ShcHelperBase_h_what[] = "@(#) ShcHelperBase.h 1.8.4.1 16/10/21 10:08:25";

/*
 *  Copyright (C) 2004 eFunds Corporation ("eFunds").  All Rights Reserved.
 *  eFunds Canada Corporation is an authorized user.
 *
 *  IST is a registered trademark of eFunds Corporation.  Other brand or
 *  product names are trademarks or registered trademarks of their respective
 *  holders.
 *
 *  The information contained herein is the unpublished proprietary property
 *  of eFunds.  Except as specifically authorized in writing by eFunds, the
 *  holder of this document shall: i) keep all information contained herein
 *  confidential, and ii) protect the information, in whole or in part, from
 *  disclosure and dissemination to all third parties.
 *
 *  This document and the software described in it are furnished under license
 *  and may be used or copied only in accordance with the terms of such license.
 *  This document is supplied for information purposes only, is subject to
 *  change without notice, and should not be construed as a commitment by
 *  either eFunds Corporation or eFunds Canada Corporation.
 *
 *
 *                        MODIFICATION HISTORY                  REVIEW
 *
 *      SPR#    Who     Date    Description                     Who     Date
 * ===========================================================================
 *	R015826 pve	07Mar06	Support for Generic Log
 */

/*****************************************************************************/

#define SHC_AcqProfile                  "AcqProfile"
#define SHC_InstProfile         "InstProfile"
#define SHC_IssProfile          "IssProfile"
#define SHC_ShcAcceptorName     "ShcAcceptorName"
#define SHC_ShcAppBase          "ShcAppBase"
#define SHC_ShcBin              "ShcBin"
#define SHC_ShcDKEHelper        "ShcDKEHelper"
#define SHC_Balancer            "ShcBalancer"
#define SHC_ShcHelper           "ShcHelper"
#define SHC_ShcKeyHelper        "ShcKeyHelper"
#define SHC_ShcMacHelper        "ShcMacHelper"
#define SHC_ShcPinHelper        "ShcPinHelper"
#define SHC_ShcPosGeoLoc        "ShcPosGeoLoc"
#define SHC_ShcSafIOHelper      "ShcSafIOHelper"
#define SHC_ShcSdkLog           "ShcSdkLog"
#define SHC_ShcLog                              "ShcLog"
#define SHC_Shc600Log			"Shc600Log"
#define SHC_ShcNotify			"ShcNotify"
#define SHC_ShcSender           "ShcSender"
#define SHC_AdviceSender		"AdviceSender"
#define SHC_AccumulationSender	"AccumulationSender"
#define SHC_ShcSenderBase       "ShcSenderBase"
#define SHC_ShcTimerHelper      "ShcTimerHelper"
#define SHC_ShckeyParamsList    "ShckeyParamsList"
#define SHC_ShcmsgHelper        "ShcmsgHelper"
#define SHC_shcPosGeoLoc        "shcPosGeoLoc"
#define SHC_ShcGenericLog	"ShcGenericLog"		//	R015826
#define SHC_McastHelper         "McastHelper"
#define SHC_ShcBalancer         "ShcBalancer"
#define SHC_ShcSharedMemoryHelper               "ShcSharedMemoryHelper"
#define SHC_ShcGenericLogHelper	"ShcGenericLogHelper" // R030273
#define SHC_ShcDuplicateChk     "ShcDuplicateChk"
#define SHC_ShcPinTryCounter     "ShcPinTryCounter"
#define SHC_ShcCardStatusHelper      "ShcCardStatusHelper"
#define SHC_ShcCardStatusChngAlw      "ShcCardStatusChngAlw"
#define SHC_Shc300ReqDB                 "Shc300ReqDB"
#define SHC_Shc300                              "SHC300"
#define SHC_ShcBillToAddress         "ShcBillToAddress"
#define SHC_ShcShipToAddress         "ShcShipToAddress"
#define SHC_ShcSenderDetails         "ShcSenderDetails"


class ShcHelperBase
{
	
public:
	virtual const char *getName() = 0;
};

#endif

