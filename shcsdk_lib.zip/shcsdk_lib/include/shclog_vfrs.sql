/*
*  IST and IST/Share are registered trademarks of Oasis Technology Ltd.
*
*  Copyright (C) 1990 - 2001 Oasis Technology Ltd.
*  All Rights Reserved
*  This Module contains Proprietary Information of
*  Oasis Technology Ltd., and should be treated as Confidential.
*
*  THIS IS UNPUBLISHED PROPRIETARY SOURCE CODE OF OASIS TECHNOLOGY LTD.
*  The copyright notice above does not evidence any
*  actual or intended publication of such source code.
*/
/*
#pragma ident "@(#) SCCS/s.shclog_vfrs.sql 1.2 05/03/01 13:20:22"
*
* Modification History
*
* 			Who	When	Why
* ========================================================================
* R010373 lsun 29Apr04  create to support visa FRS messages
*/

create table shclog_vfrs (
	shclog_idx			char(20),
	expr_date      		smallint,
	fraud_info			varchar(256) null,	
	pos_geo_loc			char(19) null,	
	netcode				int,
	rcvg_inst_id		char(10),
	addtl_trace_data	char(24) null,
	support_info		varchar(255)
)

create index pkshclog_vfrs on shclog_vfrs( shclog_idx )	

