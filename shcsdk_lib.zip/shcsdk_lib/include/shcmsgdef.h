/*
 *  Copyright (C) 2004 eFunds Corporation ("eFunds").  All Rights Reserved.     
 *  eFunds Canada Corporation is an authorized user.                            
 *                                                                              
 *  IST is a registered trademark of eFunds Corporation.  Other brand or        
 *  product names are trademarks or registered trademarks of their respective   
 *  holders.                                                                    
 *                                                                              
 *  The information contained herein is the unpublished proprietary property    
 *  of eFunds.  Except as specifically authorized in writing by eFunds, the     
 *  holder of this document shall: i) keep all information contained herein     
 *  confidential, and ii) protect the information, in whole or in part, from    
 *  disclosure and dissemination to all third parties.                          
 *                                                                          
 *  This document and the software described in it are furnished under license  
 *  and may be used or copied only in accordance with the terms of such license.
 *  This document is supplied for information purposes only, is subject to      
 *  change without notice, and should not be construed as a commitment by       
 *  either eFunds Corporation or eFunds Canada Corporation. 
 */
/*
#pragma ident "@(#) shcmsgdef.h 1.7 09/05/20 17:03:28"
 *
 *                        MODIFICATION HISTORY                  REVIEW
 *
 *	SPR#	Who	Date	Description			Who	Date   
 * ===========================================================================
 *Rxxxxxx ztang 09Oct03 Creation
 *R018667 Emj   16Jan07 Updated macro shcmsgIsChipTxn to support contactless ICC
 *R018983 pve	22Feb07	Use SH_FORMATDEVCAP_TERMINALREV instead of SH_DEVCAP_TERMINALREV
 */


#if !defined( SHCDLLEXPORT )
#   if defined( WIN32 )
#       define SHCDLLEXPORT __declspec(dllimport)
#   else
#       define SHCDLLEXPORT
#   endif
#endif

#ifndef SHCMSGDEF_INCLUDE
#define SHCMSGDEF_INCLUDE

#include <shcdef.h>
#include <shc.h>

/* R005156 */
#ifdef __cplusplus
extern "C" {
#endif
/* R005156 */
/*------------------------------------------------------------------------*
 * Include Block	
 *------------------------------------------------------------------------*/
#include "ist_win32.h"

/*------------------------------------------------------------------------*
 *	Transaction set defines
 *------------------------------------------------------------------------*/
/*		These indexes refer to the database field txnset. The transaction
		permissions are held in an array. It is very important that we
		don't mess around with the order of the fields. Note that this only
		affects the INIT program and does nothing to the runtime.

		To add a new transaction:

		1.		added to the database screen
		2.		add the index in SH_TXIDX_????
		3.		add the flag value as SH_TX_????
		4.		Edit shc_data.c and add the definition in the sch_txn_def[]
				table.

*/

/*------------------------------------------------------------------------*
 *	Macros used to determine tyfpe of transaction 
 *------------------------------------------------------------------------*/
#define shcmsgIsATM(shcmsg)	((shcmsg)->merchant_type == 6011)

#define shcmsgIsReAuthed(shcmsg) \
	((shcmsg)->device_cap & SH_DEVCAP_REAUTHED)

#define	shcmsgIsPreAgentConfReq(shcmsg) \
	((shcmsg)->device_cap & SH_DEVCAP_PREAGENT_STATE)

#define	shcmsgIsProAgentConfReq(shcmsg) \
	((shcmsg)->device_cap & SH_DEVCAP_PROAGENT_STATE)

#define shcmsgIsPreAuthRsp(shcmsg) \
	((shcGetProcessCode((shcmsg)->pcode) == SH_ISO_PREAUTHRESP) && \
	 (shcmsgIsResponse(shcmsg))) 

#define shcmsgIsPreAuthReq(shcmsg) \
	((shcGetProcessCode((shcmsg)->pcode) == SH_ISO_PREAUTHREQ) && \
	 (shcmsgIsRequest(shcmsg)))

#define shcmsgIsPreAuthConfReq(shcmsg) \
	((shcGetProcessCode((shcmsg)->pcode) == SH_ISO_PREAUTHCONF) && \
	 (shcmsgIsRequest(shcmsg)))

#define shcmsgIsPreAuthConfRsp(shcmsg) \
	((shcGetProcessCode((shcmsg)->pcode) == SH_ISO_PREAUTHCONF) && \
	 (shcmsgIsResponse(shcmsg)))

#define shcmsgIsCreditTxn(shcmsg)	\
	((shcmsg)->pos_condition_code & SH_POS_COND_CREDIT_TXN)

#define shcmsgIsEDC(shcmsg)	((shcmsg)->device_cap & SH_DEVCAP_EDC)

#define shcmsgHasSegment(shcmsg) \
		((shcmsg)->device_cap & SH_DEVCAP_USER_SEGMENT)

#define shcmsgIsTERMINALREV(shcmsg) \
	((shcmsg)->formatter_devcap & SH_FORMATDEVCAP_TERMINALREV)	//	R018983

/* R006365 */
#define shcmsgIsDUKPT(shcmsg) \
	((shcmsg)->device_devcap & SH_DEVCAP_TERMINALDUKPT)

/* 10002273 */
/* 961108 */
#define shcmsgIsIBFT(shcmsg)	 ((shcmsg)->shc_devcap & SH_DEVCAP_SHC_IBFT)
//((shcIsTransfer((shcmsg)->pcode) || \
//	shcIsTransfer((shcmsg)->origpcode)) && \
//	atol((shcmsg)->transferee) > 0)

#define shcmsgIsIBFTW(shcmsg)	((shcmsg)->shc_devcap & SH_DEVCAP_SHC_IBFTW)
#define shcmsgIsIBFTD(shcmsg)	((shcmsg)->shc_devcap & SH_DEVCAP_SHC_IBFTD)

										/* R008041 >> */
#define shcmsg_has_shclog_add(shcmsg)  \
		( ((shcmsg)->device_devcap & SH_DEVICE_LOG_SHCLOG_ADD) \
		&& ((shcmsg)->device_cap & SH_DEVCAP_USER_SEGMENT) )

#define shcmsg_has_shclog_cheque(shcmsg)  \
		( ((shcmsg)->device_devcap & SH_DEVICE_LOG_SHCLOG_CHEQUE) \
		&& ((shcmsg)->device_cap & SH_DEVCAP_USER_SEGMENT) )

										/* R008041 << */

/* 961115 */
#define	shcmsgHeaderFwdNak(header)			(header->issShcBin->binPkg->bin.bintype & SH_FORWARD_NAK)
#define	shcmsgHeaderAcqTOGenRev(header)		(header->issShcBin->binPkg->bin.bintype & SH_ACQTO_GEN_REV )

/* 25Apr95, 27jun95
 * Macros for the terminal_trace field.
 * shcMapTerminalTrace() -	If shcmsg->terminal_trace ==
 *							SH_MAP_TERMINAL_TRACE_ZERO, assign 0, return True.
 */
#define shcmsgMapTerminalTrace(shcmsg) \
	(((shcmsg)->terminal_trace == SH_MAP_TERMINAL_TRACE_ZERO) ? \
	shcAssignTerminalTrace(shcmsg) : 0)
#define shcmsgAssignTerminalTrace(shcmsg) \
	(((shcmsg)->terminal_trace=0) ? 1 : 1)

#define shcmsgHeaderPreauthReversalAllowed(header) \
	((header)->issShcBin->binPkg->bin.bintype & SH_PREAUTH_REVERSE)

#define shcmsgHeaderPreauthForwardAllowed(header) \
	((header)->issShcBin->binPkg->bin.bintype & SH_PREAUTH_FORWARD)

#define shcmsgHeaderPreauthAllowed(header) \
	((header)->issShcBin->binPkg->bin.bintype & SH_PREAUTH_ALLOWED)

#define shcmsgHeaderIsFullAuth(header) \
	((header)->issShcBin->binPkg->bin.bintype & SH_FULL_AUTHORIZATION)

/* Determine if it is a chip transaction */
/* Rpc 07Mar00 shcmsgIsChipTxn check if F22(pos_entry_code) is 5 or 95 to indicate
    if it's VSDC chip transaction */
int shcmsgIsChipTxn(struct shcmsg *msg);
//	shcmsgIsChipTxn(shcmsg) \//R026570 Replace this macro with a real function
//    ((((shcmsg)->pos_entry_code & SH_POS_PINPANENTRY_MASK) / 10 == 5)|| \
//    (((shcmsg)->pos_entry_code & SH_POS_PINPANENTRY_MASK) / 10 == 7)|| \
//    (((shcmsg)->pos_entry_code & SH_POS_PINPANENTRY_MASK) / 10 == 95 ))
/* Mch 24Feb00 -End-------------------------------------------------------*/

/*------------------------------------------------------------------------*
 *	Define the type of transactions we process
 *------------------------------------------------------------------------*/
#define shcmsgIsDeviceAck(shcmsg)			(((shcmsg)->msgtype/1000 % 10) == 9)
#define shcmsgIsAuthorizationRequest(shcmsg)	(((shcmsg)->msgtype / 100) == 1)
#define shcmsgIsFinancialRequest(shcmsg)		(((shcmsg)->msgtype / 100) == 2)
#define shcmsgIsFileUpdateRequest(shcmsg)		(((shcmsg)->msgtype/100)%10==3)
#define shcmsgIs03xx(shcmsg)					shcmsgIsFileUpdateRequest(shcmsg)
#define shcmsgIsReversal(shcmsg)				(((shcmsg)->msgtype / 100) == 4)
#define shcmsgIsSettlement(shcmsg)				(((shcmsg)->msgtype / 100) == 5)
#define shcmsgIsAdmin(shcmsg)					(((shcmsg)->msgtype / 100) == 6)
#define shcmsgIsRequest(shcmsg)				(!shcmsgIsResponse((shcmsg)))
#define shcmsgIsAdviceResp(shcmsg) ((shcmsg)->msgtype == SHC_FINREQ_ADVICE_RESPONSE)
/* Ssc - 28Jun00	R004671 integration to 7.2 */
/* Ssc - 17Apr00    SPR # 2007336 Create macro to check 130,230 and 430 txn */
#define shcmsgIsAdviceRespInclu(shcmsg)\
    ((shcmsg)->msgtype == SHC_FINREQ_ADVICE_RESPONSE || \
     (shcmsg)->msgtype == SHC_AUTHREQ_ADVICE_RESPONSE || \
     (shcmsg)->msgtype == SHC_REVREQ_ADVICE_RESPONSE)
#define shcmsgIsRevAdviceResp(shcmsg) ((shcmsg)->msgtype == SHC_REVREQ_ADVICE_RESPONSE)
#define shcmsgIsAdvice(shcmsg) ((shcmsg)->msgtype == SHC_AUTHREQ_ADVICE || \
							 (shcmsg)->msgtype == SHC_FINREQ_ADVICE)

#define shcmsgIsCustomerRequest(shcmsg)\
	(shcmsgIsAuthorizationRequest((shcmsg)) || shcmsgIsFinancialRequest((shcmsg)))

/*	A response has an odd digit in the 10's position */
#define shcmsgIsResponse(shcmsg)		( ((shcmsg)->msgtype / 10 % 10) & 1)
#define shcmsgIsNetwork(shcmsg)		(((shcmsg)->msgtype / 100) == 8)
#define shcmsgIsLogRequest(shcmsg) \
	(((shcmsg)->msgtype - ((shcmsg)->msgtype % 1000)) == SHC_LOGREQ)
#define shcmsgIsRevAdvice(shcmsg) ((shcmsg)->msgtype == SHC_REVREQ_ADVICE)

#define shcmsgIsPreauthServReq(shcmsg)\
	((shcmsg)->msgtype == SHC_PREAUTH_SERVICEREQ)

#define shcmsgIsPreauthServRsp(shcmsg)\
	((shcmsg)->msgtype == SHC_PREAUTH_SERVICERSP)

#define shcmsgIsPreauthServRetRsp(shcmsg)\
	(((shcmsg)->netcode == PreauthServRetRec) && (shcmsgIsPreauthServRsp))
										 
#define shcmsgIsPreauthServInsRsp(shcmsg)\
	(((shcmsg)->netcode == PreauthServInsRec) && (shcmsgIsPreauthServRsp))


#define	shcmsgIsAckProcessed(shcmsg)	((shcmsg)->pos_cap_code & \
										SH_POS_CAP_ACK_PROCESSED)
#define	shcmsgIsConfirmPending(shcmsg)	((shcmsg)->pos_cap_code & \
										SH_POS_CAP_CONF_PENDING)


/*
 *	Flags and values on the Dev Cap field
 */
#define shcmsg_excpect_ack(m)		((m)->device_cap & SH_DEVCAP_WILLACK)
#define shcmsg_fromdevice(m)		((m)->device_cap & SH_DEVCAP_FROMDEVICE)
#define shcmsg_set_willack(m)		((m)->device_cap |= SH_DEVCAP_WILLACK)
#define shcmsg_set_fromdevice(m)	((m)->device_cap |= SH_DEVCAP_FROMDEVICE)
#define shcmsg_devcap_setedc(m)	((m)->device_cap |= SH_DEVCAP_EDC)
#define shcmsg_unset_fromdevice(m)	((m)->device_cap &= ~(SH_DEVCAP_FROMDEVICE))
#define shcmsg_internalrev(m)		((m)->device_cap &  SH_DEVCAP_INTERNALREV)
/* R006365 */
#define shcmsg_set_dukpt(m)      ((m)->device_devcap |= SH_DEVCAP_TERMINALDUKPT)


/* >>>>> ACXSYS. 21Jan98 */
#define shcmsgIsAdmIssReq(shcmsg) ((shcmsg)->msgtype == SHC_ISS_ADMIN || \
                                (shcmsg)->msgtype == SHC_ISS_ADMIN_ADVICE)
#define shcmsgIsAdmIssResp(shcmsg) \
                   ((shcmsg)->msgtype == SHC_ISS_ADMIN_RESPONSE || \
                    (shcmsg)->msgtype == SHC_ISS_ADMIN_ADVICE_RESPONSE)
#define shcmsgIsRevIssReq(shcmsg) \
                   ((shcmsg)->msgtype == SHC_CHARGE_BACK_ADVICE)
#define shcmsgIsRevIssResp(shcmsg) \
				   ((shcmsg)->msgtype == SHC_CHARGE_BACK_ADVICE_RESPONSE)

#define	_shcHeaderNoIBFTUseLog(header)	( _shcBinUseLog((header)->acqShcBin->binPkg) && \
								_shcBinUseLog((header)->issShcBin->binPkg) )
#define	_shcHeaderIBFTUseLog(header)	( _shcHeaderNoIBFTUseLog(header) && \
								_shcBinUseLog((header)->transfereeShcBin->binPkg) )
#define	shcHeaderUseLog(header)		( shcIsIBFT((header)) ? \
								_shcIBFTUseLog((header)) : \
								_shcNoIBFTUseLog((header)) )

#define shcbinPreauthAllowed(pkg) \
	(pkg->bin.bintype & SH_PREAUTH_ALLOWED)

#define shcbinIsFullAuth(pkg) \
	(pkg->bin.bintype & SH_FULL_AUTHORIZATION)


#define shcChangeIssKeys(key_class) \
          (key_class == SH_KEYTYPE_PIN_BOTH || key_class == SH_KEYTYPE_PIN_ISS)

#define shcChangeAcqKeys(key_class) \
          (key_class == SH_KEYTYPE_PIN_BOTH || key_class == SH_KEYTYPE_PIN_ACQ)


#ifdef __cplusplus
}
#endif

#endif
/*------------------------------------------------------------------------*
 * End of File shcdef.h
 *------------------------------------------------------------------------*/
