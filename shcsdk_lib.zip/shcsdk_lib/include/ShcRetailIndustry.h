#ifndef _SHC_RETAILINDUSTRY_H_
#define _SHC_RETAILINDUSTRY_H_

static char _shc_retailIndustry_h_what[] = "@(#) shc_retailIndustry.h 1.0 14/1/22 15:22:34";

/*
 *  Copyright (C) 2004 eFunds Corporation ("eFunds").  All Rights Reserved.     
 *  eFunds Canada Corporation is an authorized user.                            
 *                                                                              
 *  IST is a registered trademark of eFunds Corporation.  Other brand or        
 *  product names are trademarks or registered trademarks of their respective   
 *  holders.                                                                    
 *                                                                              
 *  The information contained herein is the unpublished proprietary property    
 *  of eFunds.  Except as specifically authorized in writing by eFunds, the     
 *  holder of this document shall: i) keep all information contained herein     
 *  confidential, and ii) protect the information, in whole or in part, from    
 *  disclosure and dissemination to all third parties.                          
 *                                                                          
 *  This document and the software described in it are furnished under license  
 *  and may be used or copied only in accordance with the terms of such license.
 *  This document is supplied for information purposes only, is subject to      
 *  change without notice, and should not be construed as a commitment by       
 *  either eFunds Corporation or eFunds Canada Corporation. 
 *
 *
 *                        MODIFICATION HISTORY                  REVIEW
 *
 * SCR#     Who    Date  Description
 * ===========================================================================
 * R0xxxxx 
*/
 
struct ShcRetailIndustryFields
{
	OCString retailDepartmentName;
	OCString retailItemDescription1;
	OCString retailItemQuantity1;
	OCString retailItemAmount1;
	OCString retailItemDescription2;
	OCString retailItemQuantity2;
	OCString retailItemAmount2;
	OCString retailItemDescription3;
	OCString retailItemQuantity3;
	OCString retailItemAmount3;
	OCString retailItemDescription4;
	OCString retailItemQuantity4;
	OCString retailItemAmount4;
	OCString retailItemDescription5;
	OCString retailItemQuantity5;
	OCString retailItemAmount5;
	OCString retailItemDescription6;
	OCString retailItemQuantity6;
	OCString retailItemAmount6;
};


class ShcRetailIndustry
{
	char buff[1300];
	int len;
public:
	ShcRetailIndustry();
	void setTagValue(char *TagName, const char *TagValue);
	void setTagValue(char *TagName, int TagValue);
	void setTagValue(char *TagName, double TagValue);
	char* getBuffer();
	int getBufferLength();
};

#endif
