#ifndef SHCFMT_POS_GEO_LOC_INCLUDE
#define SHCFMT_POS_GEO_LOC_INCLUDE
static char _shcfmt_posGeoLoc_h_what[] = "@(#) shcPosGeoLoc.h 1.3 04/12/15 14:53:52";

/*
 *  Copyright (C) 2004 eFunds Corporation ("eFunds").  All Rights Reserved.     
 *  eFunds Canada Corporation is an authorized user.                            
 *                                                                              
 *  IST is a registered trademark of eFunds Corporation.  Other brand or        
 *  product names are trademarks or registered trademarks of their respective   
 *  holders.                                                                    
 *                                                                              
 *  The information contained herein is the unpublished proprietary property    
 *  of eFunds.  Except as specifically authorized in writing by eFunds, the     
 *  holder of this document shall: i) keep all information contained herein     
 *  confidential, and ii) protect the information, in whole or in part, from    
 *  disclosure and dissemination to all third parties.                          
 *                                                                          
 *  This document and the software described in it are furnished under license  
 *  and may be used or copied only in accordance with the terms of such license.
 *  This document is supplied for information purposes only, is subject to      
 *  change without notice, and should not be construed as a commitment by       
 *  either eFunds Corporation or eFunds Canada Corporation. 
 *
 *                        MODIFICATION HISTORY                  REVIEW
 *
 *	SPR#	Who	Date	Description			Who	Date   
 * ===========================================================================
 *R007563 ztang 02Jan03 Created
 *
 */

#if !defined( shcfmt_posGeoLoc_h_export_directive )
#   if defined( WIN32 )
#       define shcfmt_posGeoLoc_h_export_directive __declspec(dllimport)
#   else
#       define shcfmt_posGeoLoc_h_export_directive
#   endif
#endif

#include "ist_win32.h"
#include "string.h"
#include <ShcHelperBase.h>

#define POS_GEO_LOC_COUNTRY_LEN 		3
#define POS_GEO_LOC_STATE_PROVINCE_LEN 	2
#define POS_GEO_LOC_COUNTY_LEN			3
#define POS_GEO_LOC_POSTAL_CODE_LEN		10
											//R007563 BEGIN
//There are two usage of this class
//1. construct class use ShcAcceptorName(char *shcAcceptorName), and retrieve subfields.
//2. construct class use ShcAcceptorName(), set subfields, and retrieve the whole field.
class shcfmt_posGeoLoc_h_export_directive ShcPosGeoLoc : public ShcHelperBase
{
public:
	ShcPosGeoLoc(char *posGeoLoc);
	ShcPosGeoLoc();
    const char *getName()
    {
        return (const char *)SHC_ShcPosGeoLoc;
    }

	
	virtual const char *getNumericCountryCode();
	virtual void setNumericCountryCode(const char *newCountry);
	virtual void setStateProvince(const char *newStateProvince);
	virtual void setCounty(const char *newCounty);
	virtual void setPostalCode(const char *newPostalCode);
	virtual void getPosGeoLoc(char * posGeoLocBuf);
	
	const char *getCountry() { return country; }
	const char *getStateProvince() { return stateProvince; }
	const char *getCounty() { return county; }
	const char *getPostalCode() { return postalCode; }

	static int getCountryLen() { return countryLen; }
	static int getStateProvinceLen() { return stateProvinceLen; }
	static int getCountyLen() { return countyLen; }
	static int getPostalCodeLen() { return postalCodeLen; }

private:
	static int initialized;
	static int countryLen;
	static int stateProvinceLen;
	static int countyLen;
	static int postalCodeLen;
	static int sum;
	
	char country[4];
	char stateProvince[3];
	char county[4];
	char postalCode[11];
	
	void initialize(void);
	void initFields();
};

class shcfmt_posGeoLoc_h_export_directive ShcPosGeoLocException
{
public:
	ShcPosGeoLocException(char *newErrmsg) { strcpy (errMsg, newErrmsg); }
	const char *getErrMsg() { return errMsg; }
private:
	char errMsg[200];
};
#endif
