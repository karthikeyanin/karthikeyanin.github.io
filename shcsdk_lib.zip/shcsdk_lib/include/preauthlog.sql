
/*
 *  Copyright (C) 2004 eFunds Corporation ("eFunds").  All Rights Reserved.     
 *  eFunds Canada Corporation is an authorized user.                            
 *                                                                              
 *  IST is a registered trademark of eFunds Corporation.  Other brand or        
 *  product names are trademarks or registered trademarks of their respective   
 *  holders.                                                                    
 *                                                                              
 *  The information contained herein is the unpublished proprietary property    
 *  of eFunds.  Except as specifically authorized in writing by eFunds, the     
 *  holder of this document shall: i) keep all information contained herein     
 *  confidential, and ii) protect the information, in whole or in part, from    
 *  disclosure and dissemination to all third parties.                          
 *                                                                          
 *  This document and the software described in it are furnished under license  
 *  and may be used or copied only in accordance with the terms of such license.
 *  This document is supplied for information purposes only, is subject to      
 *  change without notice, and should not be construed as a commitment by       
 *  either eFunds Corporation or eFunds Canada Corporation.                     
 */
 
/*				Modification History
 *
 *	Who		When		Why
 *	========================================================================
 *	MI		10May93		Created table for preauthorization module
 *
 *
*/

create table preauthlog (
	msgtype				int,
	pan					pan_token_t(19) null,
	mask_pan			char(19) null,
	pcode				int,
	amount				money,
	trandate		 date,
	trantime			int,
	trace				int,
	local_time			int,
	expiry_time			int,
	local_date		 date,
	cap_date		 date,
	life_cycle			int,
	acquirer			char(10) null,
	issuer				char(10) null,
	originator			char(10) null,
	refnum				char(12) null,
	termid				char(8) null,
	terminal_trace		int,
	o_rowid				int
)


create index preauthlog_1 on preauthlog (expiry_time)
create index preauthlog_2 on preauthlog (pan, amount, acquirer)
create index preauthlog_rid on preauthlog (o_rowid)

