#ifndef _SHC_PASSENGERTRANSPORT_H_
#define _SHC_PASSENGERTRANSPORT_H_

static char _shc_passengerTransport_h_what[] = "@(#) shc_passengerTransport.h 1.0 26/10/21 15:22:34";

/*
 *  Copyright (C) 2004 eFunds Corporation ("eFunds").  All Rights Reserved.     
 *  eFunds Canada Corporation is an authorized user.                            
 *                                                                              
 *  IST is a registered trademark of eFunds Corporation.  Other brand or        
 *  product names are trademarks or registered trademarks of their respective   
 *  holders.                                                                    
 *                                                                              
 *  The information contained herein is the unpublished proprietary property    
 *  of eFunds.  Except as specifically authorized in writing by eFunds, the     
 *  holder of this document shall: i) keep all information contained herein     
 *  confidential, and ii) protect the information, in whole or in part, from    
 *  disclosure and dissemination to all third parties.                          
 *                                                                          
 *  This document and the software described in it are furnished under license  
 *  and may be used or copied only in accordance with the terms of such license.
 *  This document is supplied for information purposes only, is subject to      
 *  change without notice, and should not be construed as a commitment by       
 *  either eFunds Corporation or eFunds Canada Corporation. 
 *
 *
 *                        MODIFICATION HISTORY                  REVIEW
 *
 * SCR#     Who    Date  Description
 * ===========================================================================
 * R0xxxxx 
 */
 


class ShcPassengerTransport
{
	char buff[1300];
	int len;
public:
	ShcPassengerTransport();
	void setTagValue(char *TagName, const char *TagValue);
	void setTagValue(char *TagName, int TagValue);
	void setTagValueAsDouble(char *TagName, double TagValue);
	char* getBuffer();
	int getBufferLength();
};

struct ShcPassengerTransportFields
{
	OCString issueDate;
	OCString customerCode;
	OCString passengerName;
	OCString computerResSystem;
	OCString travelAgencyCode;
	OCString travelAgencyName;
	OCString restrictedTktIndicator;
	OCString issuerCarrierCode;
	OCString totalFareAmt;
	OCString totalFareCurrCode;
	OCString totalFeesAmt;
	OCString totalFeesCurrCode;
	OCString totalTaxesAmt;
	OCString totalTaxesCurrCode;
	OCString couponNumber;
	OCString ticketId;
	OCString carrierName;
	OCString airlineTransType;
	OCString issuerCity;
	OCString numberInParty;
	OCString documentType;
	OCString documentNumber;
	OCString routeDescription;
	OCString extendedPaymentCode;
	OCString commodityCode;
	OCString taxExemptIndicator;
	OCString exchangeTicketAmt;
	OCString exchangeTicketCurrCode;
	OCString exchangeFeeAmt;
	OCString exchangeFeeCurrCode;
	OCString travelAuthCode;
	OCString iataClientCode;
	OCString controlIdentifier;
	OCString nationalTaxAmt;
	OCString nationalTaxCurrCode;
	OCString exchangeTicketId;
	OCString electronicTktIndicator;
	OCString internetIndicator;
	OCString totalTaxAmount;
	OCString totalTaxCurrCode;
	OCString totalTaxCollectionInd;
	OCString iataNumericCode;
	OCString conjunctionTktIndicator;
	OCString travelPackageIndicator;
	OCString remarks;
	OCString planNumber;
	OCString invoiceNumber;
	OCString originalAmt;
	OCString originalAmtCurrCode;
	OCString arrivalDate;
	OCString ticketType;
	OCString corporateClientCode;
	OCString customerRef;
	OCString cardScheme;
	OCString creditReasonIndicator;
	OCString ticketChangeIndicator;
	OCString ancillaryTicketId;
	OCString ancillaryServiceCategoryCode1;
	OCString ancillaryServiceSubcategoryCode1;
	OCString ancillaryServiceCategoryCode2;
	OCString ancillaryServiceSubcategoryCode2;
	OCString ancillaryServiceCategoryCode3;
	OCString ancillaryServiceSubcategoryCode3;
	OCString ancillaryServiceCategoryCode4;
	OCString ancillaryServiceSubcategoryCode4;
	OCString ancillaryPassengerName;
	OCString ancillaryCreditReasonIndicator;
	OCString ancillaryAdditionalTicketId;
	OCString issuerName;
	OCString eTicketIndicator;
	OCString conjunctionTicket;
	OCString businessAppId;
	OCString ancillaryBusinessAppId;
	OCString airlinePNRNumber;
	OCString numberOfLegs;
};

#endif

