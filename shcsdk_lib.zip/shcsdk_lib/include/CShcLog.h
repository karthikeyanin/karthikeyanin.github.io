#ifndef _SHCLOG_H_
#define _SHCLOG_H_

static char _ShcLog_h_what[] = "@(#) CShcLog.h 1.20.2.2 16/10/21 10:06:20";

/*
 *  Copyright (C) 2004 eFunds Corporation ("eFunds").  All Rights Reserved.     
 *  eFunds Canada Corporation is an authorized user.                            
 *                                                                              
 *  IST is a registered trademark of eFunds Corporation.  Other brand or        
 *  product names are trademarks or registered trademarks of their respective   
 *  holders.                                                                    
 *                                                                              
 *  The information contained herein is the unpublished proprietary property    
 *  of eFunds.  Except as specifically authorized in writing by eFunds, the     
 *  holder of this document shall: i) keep all information contained herein     
 *  confidential, and ii) protect the information, in whole or in part, from    
 *  disclosure and dissemination to all third parties.                          
 *                                                                          
 *  This document and the software described in it are furnished under license  
 *  and may be used or copied only in accordance with the terms of such license.
 *  This document is supplied for information purposes only, is subject to      
 *  change without notice, and should not be construed as a commitment by       
 *  either eFunds Corporation or eFunds Canada Corporation. 
 *
 *                        MODIFICATION HISTORY                  REVIEW
 *
 *  SPR#    Who Date    Description         Who Date
 * ===========================================================================
 * R018276 pve 07Dec06	Don't include "shclog_mc.h" file
 *
 */

#include <shc.h>
#include <ShcSdkLog.h>
#include <ist_seg_list.h>
#include <DBMWrapper.hxx>

class ShcmsgHeader;

//#define IST_SHCLOG_FLAG_LOCATE_FIRST		0x00000001
//#define IST_SHCLOG_FLAG_USE_CHIP_INDEX		0x00000002
//#define IST_SHCLOG_FLAG_LOCATE_REQ		0x00000004
//#define IST_SHCLOG_FLAG_LOCATE_RESP 	0x00000008


class ShcLog : public ShcSdkLog
{
public:
	ShcLog();
	virtual ~ShcLog();

			/* Log <shcmsg> into shclog as a new transaction. */
	virtual int logTxn(ShcHeader *header);
	
			/* If <shcmsg> has not been logged into shclog, log <shcmsg>.
			 * If <shcmsg> has been logged in shclog, returns:
			 *		 3 for reversed advice
			 *		 2 for request
			 *		 1 otherwise
			 */
	virtual int logRepeat(ShcHeader *header);

			/* Update an existing txn in shclog indicated by shcmsg to the new contents 
			 * stored in shcmsg 
			 */
	virtual int updateTxn(ShcmsgHeader *header, struct shcmsg *oldmsg, int flag = IST_SHCLOG_FLAG_LOCATE_FIRST);

			/* Update response code of an existing txn in shclog to shcmsg->msg.respcode */
	virtual int updateRespcode( ShcmsgHeader *header );
	
			/* Sequentially locate an transaction in shclog */
	virtual int locateTxnSeq(ShcmsgHeader *header, struct shcmsg *msg,    struct shclogmatch *shclogmatch, int flag=0);

			/* Locate an tranasaction using shclog_1 index */
	virtual int locateTxn( ShcHeader *header) {return (locateTxn (header, 0));};
	virtual int locateTxn( ShcHeader *header, int flag = 0);
	virtual int locateTxn( ShcmsgHeader *header, struct shcmsg *oldmsg, char *prefix, int flag=0 );
	
			/* Locate an transaction using reference number and pan */
	virtual int locateTxnRefnum(ShcmsgHeader *header, struct shcmsg *oldmsg, int flag=0);
	
                        /* Locate an transaction using pan, pcode, amount, pos condition code, authnum and termloc */
        int locateTxnByExtLookup(ShcmsgHeader *header, struct shcmsg *oldmsg, int flag=0);

			/* Locate an transaction using the Europay specified fields */
	virtual int locateEuropayTxn( ShcmsgHeader *header, struct shcmsg *oldmsg, int flagCheckDup, int flag=0 );

			/* Rewind the tables to release lock */
	virtual int rewind();
	virtual int locateTxnChipIndex(ShcmsgHeader *header, struct shcmsg *oldmsg, int flag);
	
	virtual int use_log(ShcmsgHeader *header);
	
	virtual int doUpdateVoid(ShcmsgHeader *header);
	virtual int doUpdateReversal(ShcmsgHeader *header);
	virtual int doUpdateFinCapture(ShcmsgHeader *header);
	
	struct shclog shclog;
	int seg_req_len;
	int seg_resp_len;
        void replicateMessageToOtherSite(OCString &replService,
                                                                                OCString &replData,
                                                                                OCString &externalRef,
                                                                                int &replDataLen);
	virtual int locateTxnRefnum_xt(ShcmsgHeader *header, struct shcmsg *oldmsg, int flag=0);
	virtual int locateTxnRefnumInit();
	virtual int prepareShcLogAll(DBMStmt* stmt,int tbl);
	virtual int prepareShcLogTrace(DBMStmt* stmt,int tbl);
	virtual int prepareShcLogBkOff(DBMStmt* stmt,int tbl);
	virtual int prepareShcLog(DBMStmt* stmt,int tbl);
	virtual int doBindCol(DBMStmt* stmt);

protected:
			/* Fill member variable shclog with shcmsg */
	virtual int fill_transaction(ShcmsgHeader *header);
	
			/* Fill shcmsg with member variable shclog */
	virtual int fill_message(struct shcmsg *msg);
	
			/* Write transaction from member variable shclog to previously locked record in database*/
	virtual int update_transaction (int log_chip);
	
			/* Write transaction from member variable shclog to shclog table as new record */
	virtual int insert_transaction(int log_chip);
	
			/* Open shclog tables, and assign table descriptors */
	virtual int open_index();
	
			/* Generate value for shclog_id field (chip_index in shclog table) */
	virtual int generate_shclog_id(struct shcmsg *msg);
			/* Decide whether the transaction should be logged into shclog */

	virtual int shcsql_init();
	virtual int shcsql_getfield( char *src, char *dst );
	virtual int shcsql_find( ShcmsgHeader *header, char *dstp, char *prefix );
	virtual int shcsql_cmp( char *expp, char *keyp );

	virtual int initDB();
	virtual int prepareUpdateVoid();
	virtual int prepareUpdateReversal();
	virtual int prepareUpdateFinCapture();
	virtual int prepareUpdateRespcode();



	int shclogfd;
	int	shclogfd_refnum;
	int shclogfd_logID;
	int shcloginsertfd;
	
	int shclogreqfd;
	int	shclogreqfd_refnum;
	int shclogreqfd_logID;
	int shclogreqinsertfd;

	/* 2007336 */
    time_t t;

	int shclogLocateFd;

	DBMConn *_dbConn;
	DBMStmt *_updateVoid;
	DBMStmt *_updateReversal;
	DBMStmt *_updateFinCapture;
	DBMStmt *_updateRespcode;

	DBMStmt *_smtShcLogAll;
	DBMStmt *_smtShcLogTrace;
	DBMStmt *_smtShcLogBkOff;
	DBMStmt *_smtShcLog;
	DBMStmt *_smtShcLogReqAll;
	DBMStmt *_smtShcLogReqTrace;
	DBMStmt *_smtShcLogReqBkOff;
	DBMStmt *_smtShcLogReq;
	DBMStmt *_smtShcLogAllCI;
	DBMStmt *_smtShcLogReqAllCI;

    DBMStmt *_smtShcLogAllP;
    DBMStmt *_smtShcLogTraceP;
    DBMStmt *_smtShcLogBkOffP;
    DBMStmt *_smtShcLogP;
    DBMStmt *_smtShcLogReqAllP;
    DBMStmt *_smtShcLogReqTraceP;
    DBMStmt *_smtShcLogReqBkOffP;
    DBMStmt *_smtShcLogReqP;

	bool _initFlag;
	DBMConn *_dbConn1;
	char Pan[20];
	char Pan1[20];
	int _ind[150];
	char refnum[20];
	long devcap;
	long devcap1;
	int trace;
    
    	
public:
	int setLocateByRefnum(int true_or_false);
	int setExcludeTraceInRefnum(int true_or_false);
	int isLocateByRefnum();
	int isExcludeTraceInRefnum();
	virtual IstSegList *restoreGenericLog(ShcGenericLog *genericLog, ShcmsgHeader *header, char reqresp);
};

extern int locate_for_repeat;

#endif
