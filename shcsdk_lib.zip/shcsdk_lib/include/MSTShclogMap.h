#ifndef MSTSHCLOGMAP_H
#define MSTSHCLOGMAP_H
static char _MST_Shclog_map_h[] = "@(#) MSTShclogMap.h 0.0";

/*
 *  Copyright (C) 2004 eFunds Corporation ("eFunds").  All Rights Reserved.     
 *  eFunds Canada Corporation is an authorized user.                            
 *                                                                              
 *  IST is a registered trademark of eFunds Corporation.  Other brand or        
 *  product names are trademarks or registered trademarks of their respective   
 *  holders.                                                                    
 *                                                                              
 *  The information contained herein is the unpublished proprietary property    
 *  of eFunds.  Except as specifically authorized in writing by eFunds, the     
 *  holder of this document shall: i) keep all information contained herein     
 *  confidential, and ii) protect the information, in whole or in part, from    
 *  disclosure and dissemination to all third parties.                          
 *                                                                          
 *  This document and the software described in it are furnished under license  
 *  and may be used or copied only in accordance with the terms of such license.
 *  This document is supplied for information purposes only, is subject to      
 *  change without notice, and should not be construed as a commitment by       
 *  either eFunds Corporation or eFunds Canada Corporation. 
 *                    
 */

#if !defined( MSTShclogMap_h_export_directive )
#   if defined( WIN32 )
#       define MSTShclogMap_h_export_directive __declspec(dllimport)
#   else
#       define MSTShclogMap_h_export_directive
#   endif
#endif

#include "ist_win32.h"
#include <string.h>
#include <ShcHelperBase.h>
#include <mst_shclog_map.h>
#include <DBMWrapper.hxx>


#define mstshclogmapstruct ((struct mst_shclog_map *)0)

class ShcmsgHeader;

#define MST_SHCLOG_WEIGHT_NON_EXIST 		0
#define MST_SHCLOG_NO_HEADER_NO_CHANGE 		-1
#define MST_SHCLOG_NO_MST_NO_CHANGE 		-2
#define MST_SHCLOG_SMALL_WEIGHT_NO_CHANGE 	-3
#define MST_SHCLOG_DB_ERROR				 	-4

#define MST_WEIGHT_AUTHORIZATION			500
#define MST_WEIGHT_AUTHORIZATION_REQ		100
#define MST_WEIGHT_COMPLETION				600
#define MST_WEIGHT_FINANCIAL				600
#define MST_WEIGHT_FINANCIAL_REQ			100
#define MST_WEIGHT_REVERSAL					600
#define MST_WEIGHT_FROM_ISSUER				50
#define MST_WEIGHT_APPROVED					20
#define MST_WEIGHT_DECLINED					10


class MSTShclogMap_h_export_directive MSTShclogMap 
{
public:
	static int record(ShcmsgHeader *header);
	static int record(ShcmsgHeader *header, char *msgId);
	MSTShclogMap();
	static const char * findShclogId(const char *MSTId, int msgtype, int pcode);
	static long getExistingTrace();

protected:
	static DBMConn* dbConn;
	static DBMStmt* stmtInsert;
	static DBMStmt* stmtSelect;
	static DBMStmt* stmtUpdate;
	int _ind[5];
	char mMSTId[sizeof(mstshclogmapstruct->mst_id)];
	char mShclogId[sizeof(mstshclogmapstruct->shclog_id)];
	short mMsgType;
	short mPcode;
	short mWeight;
	long mTrace;
	DBMDateTime createdTime;
	int _record(ShcmsgHeader *h);
	int _record(ShcmsgHeader *h, char *msgId);
	short calcWeight(ShcmsgHeader *h);
	short getExistingRecord();
	short insert(ShcmsgHeader *h);
	short update(ShcmsgHeader *h);
	const char * _findShclogId(const char *MSTId, short msgtype, short pcode);
	long _getExistingTrace();
	void reset();
};

#endif
