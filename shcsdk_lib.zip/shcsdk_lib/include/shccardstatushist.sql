/*
 *  Copyright (C) 2004 eFunds Corporation ("eFunds").  All Rights Reserved.     
 *  eFunds Canada Corporation is an authorized user.                            
 *                                                                              
 *  IST is a registered trademark of eFunds Corporation.  Other brand or        
 *  product names are trademarks or registered trademarks of their respective   
 *  holders.                                                                    
 *                                                                              
 *  The information contained herein is the unpublished proprietary property    
 *  of eFunds.  Except as specifically authorized in writing by eFunds, the     
 *  holder of this document shall: i) keep all information contained herein     
 *  confidential, and ii) protect the information, in whole or in part, from    
 *  disclosure and dissemination to all third parties.                          
 *                                                                          
 *  This document and the software described in it are furnished under license  
 *  and may be used or copied only in accordance with the terms of such license.
 *  This document is supplied for information purposes only, is subject to      
 *  change without notice, and should not be construed as a commitment by       
 *  either eFunds Corporation or eFunds Canada Corporation. 
 */
/*
	Run time information for a card
*/

create table shccardstatushist (
	Siteid 			int not null,
	Pan			pan_token_t(19 byte) not null,		
	Effective_from		date,	
	Effective_to		date,			/*	date created */
	Status			char(4 byte),		
	Prestatus		char(4 byte),	
	Changetype		int ,
	Created			date not null,	/*	date created */
	Source			varchar2(10) not null,
	Created_time_msec	int not null
)
create unique index shccardstatushist_1 on shccardstatushist (Siteid, Pan, Created, Created_time_msec);

GG_PARAM shccardstatushist
(
);
