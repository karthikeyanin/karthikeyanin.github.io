#ifndef _SHC600LOG_H_
#define _SHC600LOG_H_

static char _Shc600Log_h_what[] = "@(#) Shc600Log.h 1.5 14/04/11 16:55:57";

/*
 *  Copyright (C) 2004 eFunds Corporation ("eFunds").  All Rights Reserved.     
 *  eFunds Canada Corporation is an authorized user.                            
 *                                                                              
 *  IST is a registered trademark of eFunds Corporation.  Other brand or        
 *  product names are trademarks or registered trademarks of their respective   
 *  holders.                                                                    
 *                                                                              
 *  The information contained herein is the unpublished proprietary property    
 *  of eFunds.  Except as specifically authorized in writing by eFunds, the     
 *  holder of this document shall: i) keep all information contained herein     
 *  confidential, and ii) protect the information, in whole or in part, from    
 *  disclosure and dissemination to all third parties.                          
 *                                                                          
 *  This document and the software described in it are furnished under license  
 *  and may be used or copied only in accordance with the terms of such license.
 *  This document is supplied for information purposes only, is subject to      
 *  change without notice, and should not be construed as a commitment by       
 *  either eFunds Corporation or eFunds Canada Corporation. 
 *                    
 *
 *                        MODIFICATION HISTORY                  REVIEW
 *
 *  SPR#    Who Date    Description         Who Date
 * ===========================================================================
 *
 *
 */

#include <shc.h>
#include <shcextbuf.h>
#include <shc600log.h>

#include <ShcSdkLog.h>
class ShcmsgHeader;


class Shc600Log : public ShcSdkLog
{
public:
	virtual int logTxn(ShcHeader *header);
	virtual int logRepeat(ShcHeader *header); 
	virtual int locateTxn( ShcHeader *header) { return (locateTxn(header, 0));};
	virtual int locateTxn( ShcHeader *header, int flag);

			/* Update an existing txn in shclog indicated by shcmsg to the new contents 
			 * stored in shcmsg 
			 */
	virtual int updateTxn(ShcmsgHeader *header, struct shcmsg *oldmsg, int locateFirst = 1);

	Shc600Log(): shc600logfd(-1),shc600logreqfd(-1){ };

protected:
	struct shc600log shc600log;
	int shc600logfd;
	int shc600logreqfd;
			/* Fill member variable shclog with shcmsg */
	virtual int fill_transaction(ShcHeader *header);
			/* Write transaction from member variable shclog to shclog table as new record */
	virtual int insert_transaction(int resp_msg);

};

#endif
