/*
 *	IST and IST/Share are registered trademarks of Oasis Technology Ltd.
 *
 *	Copyright (C) 1990 - 1997 Oasis Technology Ltd.
 *	All Rights Reserved
 *	This Module contains Proprietary Information of
 *	Oasis Technology Ltd., and should be treated as Confidential.
 *
 *	THIS IS UNPUBLISHED PROPRIETARY SOURCE CODE OF OASIS TECHNOLOGY LTD.
 *	The copyright notice above does not evidence any  
 *	actual or intended publication of such source code.
 */


create table mst_shclog_map (
	mst_id			varchar(64) not null,	
	shclog_id		char(20) not null,					
	msgtype			smallint not null,	
	pcode			smallint not null,	
	weight			smallint,
	created			date,
	trace                   smallint not null
)
create unique index mst_shclog_map_1 on mst_shclog_map (mst_id, msgtype, pcode)

GG_PARAM mst_shclog_map
(
);

