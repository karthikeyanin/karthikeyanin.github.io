#ifndef _SHC_PROCESSOR_H_
#define _SHC_PROCESSOR_H_

static char _ShcProcessor_h_what[] = "@(#) ShcProcessor.h 1.2 04/10/06 17:18:35";

/*
 *  Copyright (C) 2004 eFunds Corporation ("eFunds").  All Rights Reserved.     
 *  eFunds Canada Corporation is an authorized user.                            
 *                                                                              
 *  IST is a registered trademark of eFunds Corporation.  Other brand or        
 *  product names are trademarks or registered trademarks of their respective   
 *  holders.                                                                    
 *                                                                              
 *  The information contained herein is the unpublished proprietary property    
 *  of eFunds.  Except as specifically authorized in writing by eFunds, the     
 *  holder of this document shall: i) keep all information contained herein     
 *  confidential, and ii) protect the information, in whole or in part, from    
 *  disclosure and dissemination to all third parties.                          
 *                                                                          
 *  This document and the software described in it are furnished under license  
 *  and may be used or copied only in accordance with the terms of such license.
 *  This document is supplied for information purposes only, is subject to      
 *  change without notice, and should not be construed as a commitment by       
 *  either eFunds Corporation or eFunds Canada Corporation. 
 *
 *                        MODIFICATION HISTORY                  REVIEW
 *
 * SCR#     Who    Date  Description
 * ===========================================================================
 * R0xxxxx jyang 10Oct03 Created
 */
 
/*****************************************************************************/

#include <ShcBaseTxn.h>
#include <ShcHeader.h>

class ShcProcessor 
{
protected:
	//ShcProcessor* processor;
	ShcBaseTxn*  shcTxn;
	
	virtual ShcBaseTxn* classify() {return NULL;};	//Get txn object
	
	virtual int   getBINs() {return -1;};		// Set appropriate bins in header
	virtual int   log() {return -1;};			//Log the transaction
	virtual int   route() {return -1;};			//Route the transaction
	
public:
//	ShcProcessor(ShcProcessor &p);
	virtual ~ShcProcessor();
	
	virtual int   process() {return -1;};	//Begin process this message

	ShcHeader *header;			//messages, bins and flags
};



#endif


