/*
 *  Copyright (C) 2004 eFunds Corporation ("eFunds").  All Rights Reserved.
 *  eFunds Canada Corporation is an authorized user.
 *
 *  IST is a registered trademark of eFunds Corporation.  Other brand or
 *  product names are trademarks or registered trademarks of their respective
 *  holders.
 *
 *  The information contained herein is the unpublished proprietary property
 *  of eFunds.  Except as specifically authorized in writing by eFunds, the
 *  holder of this document shall: i) keep all information contained herein
 *  confidential, and ii) protect the information, in whole or in part, from
 *  disclosure and dissemination to all third parties.
 *
 *  This document and the software described in it are furnished under license
 *  and may be used or copied only in accordance with the terms of such license.
 *  This document is supplied for information purposes only, is subject to
 *  change without notice, and should not be construed as a commitment by
 *  either eFunds Corporation or eFunds Canada Corporation.
 *
 *                        MODIFICATION HISTORY                  REVIEW
 *
 * SCR#     Who    Date  Description
 * ===========================================================================
 * R020052  spa	 21May07 New file created
 * R020938	spa	 16Aug07 IST LM Bridge support
 * R029287  dipa 31May11 WR33845 changes
 */

#ifndef _SHCMSGFMHEADER_H_
#define _SHCMSGFMHEADER_H_

static char _ShcmsgFMHeader_h_what[] = "@(#) ShcmsgFMHeader.h 1.4 11/06/10 01:48:08";

#include <ShcHeader.h>
#include <shc.h>
#include <ShcmsgHeader.h>

#define MAX_FM_ADD_INFO_LEN	256

struct s_FMDecision
{
	int msgtype;							//Must be 8110
	int flipped_msgtype;	//	---	R020938
	char pan[SHC_PAN_LEN+1];
	long pcode;				//	---	R020938
	amount_t	amount;		//	---	R020938
	amount_t	new_amount;	//	---	R020938
	long trace;
	short	pos_entry_code;	//	---	R020938
	bin_t acquirer;
	bin_t issuer;
	bin_t transferee;
	int respcode;							//0->continue;otherwise->deny
	char reasoncode[7];
	int origmsg;
	char txnSrc[MAX_TXN_DESTINATION_LEN+1];//	---	R020938
	char txnDest[MAX_TXN_DESTINATION_LEN+1];
	char additionalInfo[MAX_FM_ADD_INFO_LEN];
	char rule_list[400]; //R029287
	char domain_list[400]; //R029287
	int rule_count; //R029287
	int domain_count; //R029287
};


class ShcmsgFMHeader : public ShcmsgHeader
{
public:
	ShcmsgFMHeader(struct s_FMDecision* fmMsg)
	{
		memcpy(&FMMsg, fmMsg, sizeof(FMMsg));
	}

	const char *getName()
	{
		return (char *)SHC_ShcmsgFMHeader;
	}

	struct s_FMDecision FMMsg;
};

#endif
