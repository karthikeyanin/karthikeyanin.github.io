/*
 *  Copyright (C) 2004 eFunds Corporation ("eFunds").  All Rights Reserved.     
 *  eFunds Canada Corporation is an authorized user.                            
 *                                                                              
 *  IST is a registered trademark of eFunds Corporation.  Other brand or        
 *  product names are trademarks or registered trademarks of their respective   
 *  holders.                                                                    
 *                                                                              
 *  The information contained herein is the unpublished proprietary property    
 *  of eFunds.  Except as specifically authorized in writing by eFunds, the     
 *  holder of this document shall: i) keep all information contained herein     
 *  confidential, and ii) protect the information, in whole or in part, from    
 *  disclosure and dissemination to all third parties.                          
 *                                                                          
 *  This document and the software described in it are furnished under license  
 *  and may be used or copied only in accordance with the terms of such license.
 *  This document is supplied for information purposes only, is subject to      
 *  change without notice, and should not be construed as a commitment by       
 *  either eFunds Corporation or eFunds Canada Corporation. 
 */
/*
#pragma ident "@(#) mt_extbin.h 1.2 18/08/24 10:12:49"
 *
 *                        MODIFICATION HISTORY                  REVIEW
 *
 *	SPR#	Who	Date	Description			Who	Date   
 * ===========================================================================
 *R008717 ztang 15Nov02 Created for multi-institution support
 *						Added alternateAcqBin to shc structure
 */

#ifndef MT_EXTBIN_INCLUDE
#define MT_EXTBIN_INCLUDE

#if !defined( MTDLLEXPORT )
#   if defined( WIN32 )
#       define MTDLLEXPORT __declspec(dllimport)
#   else
#       define MTDLLEXPORT
#   endif
#endif


#ifdef PREPROC_MT_LIB

#if defined ( MTDLLEXPORT )
#   undef     MTDLLEXPORT
#   define    MTDLLEXPORT
#endif
#endif

#include <multi_inst_def.h>


class ExtBinResult
{
public:
    int m_numOfResult;
    struct shcextbin *(result[MAX_EXT_BIN_RESULT_NUM]);
    ExtBinResult() { m_numOfResult = 0; }
};

class ExtBinResultExt
{
public:
    int m_numOfResult;
	int m_numOfAllocated;
    struct shcextbin *(*result);
    ExtBinResultExt();
    ~ExtBinResultExt();
	int addResult(struct shcextbin *oneResult);
protected:
	int accomodate(int newSize);
};

extern ExtBinResultExt gExtBinResultExt;

#endif
