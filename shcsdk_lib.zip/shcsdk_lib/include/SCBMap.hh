#ifndef _SCB_MAP_H_
#define _SCB_MAP_H_
static char _SCBMap_h_what[] = "@(#) SCBMap.hh 1.13 06/07/06 16:00:52";

/*
 *  Copyright (C) 2004 eFunds Corporation ("eFunds").  All Rights Reserved.     
 *  eFunds Canada Corporation is an authorized user.                            
 *                                                                              
 *  IST is a registered trademark of eFunds Corporation.  Other brand or        
 *  product names are trademarks or registered trademarks of their respective   
 *  holders.                                                                    
 *                                                                              
 *  The information contained herein is the unpublished proprietary property    
 *  of eFunds.  Except as specifically authorized in writing by eFunds, the     
 *  holder of this document shall: i) keep all information contained herein     
 *  confidential, and ii) protect the information, in whole or in part, from    
 *  disclosure and dissemination to all third parties.                          
 *                                                                          
 *  This document and the software described in it are furnished under license  
 *  and may be used or copied only in accordance with the terms of such license.
 *  This document is supplied for information purposes only, is subject to      
 *  change without notice, and should not be construed as a commitment by       
 *  either eFunds Corporation or eFunds Canada Corporation. 
 *                    
 *
 *
 *                        MODIFICATION HISTORY                       REVIEW
 *
 *	SPR#	Who	Date	Description								Who	Date   
 * =============================================================================
 *  R002797 fguo 30Dec99 SHC Callback
 *		add OC_CPP_TYPENAME at line 243 & #include "oc_patch.h" at line 64
 */
#include <stl/map.h>
//
#include "oc/oc_patch.h"

template <class Key, class Value> class SCBMapIterator;

template <class Key, class Value>
class SCBMap
{
public:
    //------------------------------------------------------------------
    // Ctor/Dtor
    //------------------------------------------------------------------
    SCBMap ();
    ~SCBMap();

    //------------------------------------------------------------------
    // Public operators
    //------------------------------------------------------------------
    Value&       operator [] (const Key&);
    const Value& operator [] (const Key&) const;
    int          insert      (const Key&, const Value&);
    int		 erase	     (const Key&);
public:
    typedef map < Key, Value
#if ! defined(OC_USE_NEW_STL)
			, less<Key> , __STL_DEFAULT_ALLOCATOR(Value)
#endif
		> container_type;

	typedef typename container_type::iterator iterator;
	typedef typename container_type::const_iterator const_iterator;
	typedef typename container_type::value_type oc_pair;
		
	container_type	_map;

    friend class SCBMapIterator<Key, Value>;
};

//----------------------------------------------------------------------
// Inline functions
//----------------------------------------------------------------------
template <class Key, class Value>
inline SCBMap<Key,Value>::SCBMap():
    _map()
{
}

//----------------------------------------------------------------------
// operator []
//----------------------------------------------------------------------
template <class Key, class Value>
inline Value& SCBMap<Key,Value>::operator [] (const Key& rOther)
{
    iterator it = _map.find( rOther );
	if (it == _map.end()) 
		throw 1;
	else
    	return (*it).second;
}
 
//----------------------------------------------------------------------
// operator [] 
//----------------------------------------------------------------------
template <class Key, class Value>
inline const Value& SCBMap<Key,Value>::operator [] (const Key& rOther) const
{
    const_iterator it = _map.find(rOther);
	if (it == _map.end())
		throw 1;
	else
    	return (*it).second;
    
}

//----------------------------------------------------------------------
// destructor 
//----------------------------------------------------------------------
template <class Key, class Value>
SCBMap<Key,Value>::~SCBMap()
{}

//----------------------------------------------------------------------
// insert() - insert pair (Key,Value). Returns 1 if operation was
// siccessfull, return 0 if pair (Key,Value) nas already been inserted
//----------------------------------------------------------------------
template <class Key, class Value>
int SCBMap<Key,Value>::insert(const Key&   rKey, const Value& rValue)
{
	oc_pair aPair(rKey, rValue);

	pair< iterator, bool > result =
			_map.insert( aPair );

	return ((result.second == true) ? 1 : 0);
}

//---------------------------------------------------------------------
// erase() - erase pair (Key,Value). Returns
//---------------------------------------------------------------------
template <class Key, class Value>
int SCBMap<Key, Value>::erase(const Key& rKey)
{
  return _map.erase(rKey);
}




template <class Key, class Value>
class SCBMapIterator
{
public:
    typedef SCBMap<Key, Value> oc_map;
    typedef typename oc_map::oc_pair oc_pair;
    //------------------------------------------------------------------
    // Ctor/Dtor
    //------------------------------------------------------------------
    SCBMapIterator( oc_map& rMap);
    SCBMapIterator( oc_map& rMap, const Key& rTarget );
    SCBMapIterator( oc_map& rMap, const Key& rStart, const Key& rEnd );

    //------------------------------------------------------------------
    // Public functions
    //------------------------------------------------------------------
    oc_pair* operator () ();

private:
    //------------------------------------------------------------
    // Attributes
    //------------------------------------------------------------
    int                			_targetType;
	oc_map&                     _map;
	typename oc_map::iterator   _iter;
	typename oc_map::iterator   _end;
};





//----------------------------------------------------------------------
// Default ctor
//----------------------------------------------------------------------
template <class Key, class Value>
SCBMapIterator<Key,Value>::SCBMapIterator( oc_map& rMap ):
    _targetType(0),
    _map(rMap)
{
    _iter = _map._map.begin();
    _end  = _map._map.end(); 
}

//----------------------------------------------------------------------
// ctor
//----------------------------------------------------------------------
template <class Key, class Value>
SCBMapIterator<Key,Value>::SCBMapIterator( oc_map& rMap, const Key& rTarget ):
    _targetType(1),
    _map(rMap)
{
    _iter = _map._map.find(rTarget);
    _end  = _map._map.end();
}

//----------------------------------------------------------------------
// ctor
//----------------------------------------------------------------------
template <class Key, class Value>
SCBMapIterator<Key,Value>::SCBMapIterator(
	oc_map& rMap, const Key& rStart, const Key& rEnd ):
    _targetType(2),
    _map(rMap)
{
}

//----------------------------------------------------------------------
// Operator () - return pointer to Value element.          
//----------------------------------------------------------------------
template <class Key, class Value>
OC_CPP_TYPENAME 
SCBMapIterator<Key, Value>::oc_pair* SCBMapIterator<Key,Value>::operator() ()
{
    switch (_targetType)
    {
        case 0 :
            if(_iter != _end)
            {
                return (oc_pair*)&(*_iter++); 
            }
            break;
        case 1 :
            if(_iter != _end)
            {
                return (oc_pair*)&(*_iter);
            }
            break;
        case 2 :
            break;
        default :
            return NULL;
    }
    return NULL;
}





#endif 
