#ifndef _MR_SHCKEYS_TAG_DEFS_H_
#define _MR_SHCKEYS_TAG_DEFS_H_

static char _MRShckeyTagDefs_h_what[] = "@(#) MRShckeysTagDefs.h 1.3 16/01/13 09:20:55"; 

/*
 *  Copyright (C) 2004 eFunds Corporation ("eFunds").  All Rights Reserved.     
 *  eFunds Canada Corporation is an authorized user.                            
 *                                                                              
 *  IST is a registered trademark of eFunds Corporation.  Other brand or        
 *  product names are trademarks or registered trademarks of their respective   
 *  holders.                                                                    
 *                                                                              
 *  The information contained herein is the unpublished proprietary property    
 *  of eFunds.  Except as specifically authorized in writing by eFunds, the     
 *  holder of this document shall: i) keep all information contained herein     
 *  confidential, and ii) protect the information, in whole or in part, from    
 *  disclosure and dissemination to all third parties.                          
 *                                                                          
 *  This document and the software described in it are furnished under license  
 *  and may be used or copied only in accordance with the terms of such license.
 *  This document is supplied for information purposes only, is subject to      
 *  change without notice, and should not be construed as a commitment by       
 *  either eFunds Corporation or eFunds Canada Corporation. 
 *
 *
 *                        MODIFICATION HISTORY                  REVIEW
 *
 * SCR#     Who    Date  Description
 * ===========================================================================
 */

// BITMAP - 2 bytes in the message. Total of 16 bits. Of which the first 4 bits are reserved for custom replication update types.
#define UPDATE_SHCKEYS	0x00000001

//TAG defines - Tag IDs less than 5000 are reserved for core data elements. Tag IDs 5001-9999 are reserved for custom tags

#define	TAG_SHCKEYS_SITE_ID				1
#define TAG_SHCKEYS_INSTITUTION_ID		2
#define	TAG_SHCKEYS_USERBIN				3
#define TAG_SHCKEYS_CLASS				4
#define TAG_SHCKEYS_TYPE				5	
#define TAG_SHCKEYS_INDEX				6
#define TAG_SHCKEYS_KEY					7
#define	TAG_SHCKEYS_CHK_DIGITS			8
#define	TAG_SHCKEYS_STATUS				9	
#define TAG_SHCKEYS_DATE			    10			
#define TAG_SHCKEYS_OLDKEY			 	11	
#define	TAG_SHCKEYS_OLDCHK_DIGITS		12
#define	TAG_SHCKEYS_SENDER_NODEID 		13	
#define	TAG_SHCKEYS_SENDER_MBOXID		14
#define	TAG_SHCKEYS_MSGID				15	
#define	TAG_SHCKEYS_NEW_STATUS				16	
#define	TAG_SHCKEYS_KEY_COUNT			17

#endif
