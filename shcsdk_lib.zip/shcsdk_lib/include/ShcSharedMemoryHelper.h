#ifndef _SHCSHAREDMEMORYHELPER_H_
#define _SHCSHAREDMEMORYHELPER_H_

static char _ShcSharedMemoryHelper_h_what[] = "@(#) ShcSharedMemoryHelper.h 1.1 11/06/14 16:09:19";

/*
 *  Copyright (C) 2004 eFunds Corporation ("eFunds").  All Rights Reserved.     
 *  eFunds Canada Corporation is an authorized user.                            
 *                                                                              
 *  IST is a registered trademark of eFunds Corporation.  Other brand or        
 *  product names are trademarks or registered trademarks of their respective   
 *  holders.                                                                    
 *                                                                              
 *  The information contained herein is the unpublished proprietary property    
 *  of eFunds.  Except as specifically authorized in writing by eFunds, the     
 *  holder of this document shall: i) keep all information contained herein     
 *  confidential, and ii) protect the information, in whole or in part, from    
 *  disclosure and dissemination to all third parties.                          
 *                                                                          
 *  This document and the software described in it are furnished under license  
 *  and may be used or copied only in accordance with the terms of such license.
 *  This document is supplied for information purposes only, is subject to      
 *  change without notice, and should not be construed as a commitment by       
 *  either eFunds Corporation or eFunds Canada Corporation. 
 *
 *                        MODIFICATION HISTORY                  REVIEW
 *
 * SCR#     Who    Date  Description
 * ===========================================================================
 * R0xxxxx 
 * R012339  Emj   08Nov04 Emv Buffer Bitmap
 */
 

#include <ShcSdkCommon.h>
#include <ShcHelperBase.h>


class ShcSharedMemoryHelper : public ShcHelperBase
{
public:
    const char *getName()
    {
        return (const char *)SHC_ShcSharedMemoryHelper;
    }

	virtual int lockRule(const char *ruleName, int *isLocked, int *appid);
	virtual int updateCurrentVersion(const char *rulename, int isLocked, int appid, char *ruleData, int size);
	virtual int attachCurrent(int *appid, struct rules_keytab **pAppHead, const char *ruleName=NULL);

};

#endif

