#ifndef _BINROUTE_H_
#define _BINROUTE_H_

static char _BinRoute_h_what[] = "@(#) BinRoute.h 1.16.3.3 20/02/12 12:23:08";

/*
 *  Copyright (C) 2004 eFunds Corporation ("eFunds").  All Rights Reserved.     
 *  eFunds Canada Corporation is an authorized user.                            
 *                                                                              
 *  IST is a registered trademark of eFunds Corporation.  Other brand or        
 *  product names are trademarks or registered trademarks of their respective   
 *  holders.                                                                    
 *                                                                              
 *  The information contained herein is the unpublished proprietary property    
 *  of eFunds.  Except as specifically authorized in writing by eFunds, the     
 *  holder of this document shall: i) keep all information contained herein     
 *  confidential, and ii) protect the information, in whole or in part, from    
 *  disclosure and dissemination to all third parties.                          
 *                                                                          
 *  This document and the software described in it are furnished under license  
 *  and may be used or copied only in accordance with the terms of such license.
 *  This document is supplied for information purposes only, is subject to      
 *  change without notice, and should not be construed as a commitment by       
 *  either eFunds Corporation or eFunds Canada Corporation. 
 *
 *
 *                        MODIFICATION HISTORY                  REVIEW
 *
 * SCR#     Who    Date  Description
 * ===========================================================================
 * Rxxxxxx ztang 22Feb08 Creation
 * R023394 sel	 30May08 Added flag for SignOn message for each connection from ConnexOE to LM
 * R023551 jyang 09Jun08 Added a member function createPseudoSharedMemory()
 * R028925 dipa  24Jan11 Create getFirstUpRoute()
 * R029275 dipa  08Apr11 Add balancer node info
 * R030556 dipa	 14Jun12 Clone of R030592
 * R031154 dipa  21Dec12 Clone of R031026
 */
 
#include <shc.h>
#include <binroute.h>
#include <ShcBin.h>
#include <mt_inst_profile.h>

extern BINROUTE *_nouse;
extern struct shcmsg *_nouseshcmsg;

#define SHC_BinRoute 					"Binroute"
#define BIN_ROUTE_MESSAGE_NAME			"shc-bin-route"
#define BIN_ROUTE_SIZE_MEM				1024

#define BIN_ROUTE_GROUPTYPE_ROUNDROBIN 	'R'

#define BIN_ROUTE_STATUS_DOWN 			'D'
#define BIN_ROUTE_STATUS_UP 			'U'
#define BIN_ROUTE_STATUS_UNKNOWN		'X'

#define BIN_ROUTE_ECHO_ALWAYS			'A'
#define BIN_ROUTE_ECHO_DOWN				'D'
#define BIN_ROUTE_ECHO_DOWN_CONNECTED	'C'		//BinRoute is down but port is connected
#define BIN_ROUTE_ECHO_UP				'U'
#define BIN_ROUTE_ECHO_NEVER			'N'
#define BIN_ROUTE_ECHO_ONLY_IF_BIN_UP   	'S'
#define BIN_ROUTE_BALANCER_NODE			'B'		//R029275
#define BIN_ROUTE_SWITCH_NODE			'S'		//R029275 

//Index of cfg field
#define BINROUTE_CFG_IDX_CONN_ACTION		0
#define BINROUTE_CFG_IDX_CONN_BINACTION		1
#define BINROUTE_CFG_IDX_DISC_ACTION		2
#define BINROUTE_CFG_IDX_ECHO_SIGNON_ACTION	3

//binroute action when receiving "connect" string, this is cfg index 0
#define BINROUTE_CFG_CONN_NOTHING		'1'
#define BINROUTE_CFG_CONN_UP			'2'
#define BINROUTE_CFG_CONN_ECHO			'3'
#define BINROUTE_CFG_CONN_SIGNON		'4'

//bin action when receiving "connect" string, this is cfg index 1
#define BINROUTE_CFG_CONN_BIN_NOTHING	'1'
#define BINROUTE_CFG_CONN_BIN_UP		'2'
#define BINROUTE_CFG_CONN_BIN_ECHO		'3'
#define BINROUTE_CFG_CONN_BIN_SIGNON	'4'

//binroute action when receiving "disconnect" string, this is cfg index 2
#define BINROUTE_CFG_DISC_NOTHING		'1'
#define BINROUTE_CFG_DISC_DOWN			'2'

// BINROUTE to not follow up Echo response with a Sign-on,this is cfg index 3
#define BINROUTE_CFG_NO_SIGNON_AFTER_ECHO	'1'

//Flag definition for flag in routing info segment
#define ROUTE_INFO_FLAG_USE_BINROUTE	0x00000001	//binroute has been used
#define ROUTE_INFO_FLAG_USE_FOR_REQ		0x00000002	//binroute has been determined when the req msg is created
#define BINROUTE_FLAG_SIGNON_DONE	0x00000001	//	---	R023394

extern int _shouldUpdateCounter;
extern long getRouteEntries_match_IP_ID;

struct s_binroute
{
	char	institutionid[sizeof(_nouse->institutionid)];
	char	userbinid[sizeof(_nouse->userbinid)];
	char	internalid[sizeof(_nouseshcmsg->issuer)];
	char	node[sizeof(_nouse->node)];
	char	mailbox[31];
	char	port[sizeof(_nouse->port)];
	char	status;
	int		flag;
	char	cfg[sizeof(_nouse->cfg)];
	char 	initStatus;
	char	echo;
	char	grouptype;
	long	priority;
	char	misc[40];
	long	balanceInfo[5];
	long	timeoutCounter;
	long 	hashValue;
	int		mailboxId;
	long		inst_profile_id;
	char    base_port_name[sizeof(_nouse->base_port_name)];
	char	blrnode[sizeof(_nouse->blrnode)];  //R029275
	char	binrouteGroup[sizeof(_nouse->binroute_group)];
        short   siteId;
};

class BinRoute : public ShcHelperBase
{
protected:
	struct rules_keytab *appHead;
	char *appKey;
	int numOfCandidates;
	int maxNumOfCandidates;
	struct s_binroute **candidates;
public:
	BinRoute();
	~BinRoute();
	
	const char *getName()
	{
		return (const char *)SHC_BinRoute;
	}
	long getHashValue(char *ptr);
	void resetBalanceInfo();
	void addRouteCandidate(struct s_binroute *c);
	struct s_binroute *decideRoute();
	int chooseRoute(ShcmsgHeader *header, ShcBin *bin, struct RoutingInfo *routingBuf, int *outbound, struct InstitutionProfile *ip);
	void useRoute(struct s_binroute *tmpRoute, struct RoutingInfo *routingInfo, int *outbound);
	
	int  markRouteUp( char *networkId, struct RoutingInfo *routingInfo,  int *needBinUp=NULL , char nodeType=BIN_ROUTE_SWITCH_NODE);  //R029275
	int  markRouteDown( char *networkId, struct RoutingInfo *routingInfo, int *needBinDown=NULL, char nodeType=BIN_ROUTE_SWITCH_NODE ); //R029275
	int  changeBinStatus( char *bin, int upStatus );
	int  changeRouteStatus( char *networkId, struct RoutingInfo *routingInfo, char routeStatus, char *broadcastStr=NULL , size_t brdcastStrSize=0, char nodeType=BIN_ROUTE_SWITCH_NODE ); //R029275
	int  getRouteEntries( char *networkId, struct RoutingInfo *routingInfo, char nodeType=BIN_ROUTE_SWITCH_NODE ); //R029275
	struct s_binroute *getRoute( int n );
	int  getNumOfRouteCandidate() { return maxNumOfCandidates; }
	int  createBroadcastStr( char *buf, size_t bufSize, struct s_binroute *route);
	int tidyUpBinStatus();
	int	 setRemoteRouteStatus(int status);
	int markRouteAndBinUp( char *networkId, struct RoutingInfo *routingInfo );
	struct s_binroute* getFirstUpRoute(); //R028925
	int changeRouteStatus(struct s_binroute *pBinRoute, int status, char *broadcastStr, size_t brdcastStrSize);
	int setBnrtRuleParam();
        int markRouteDownByGroup( char *binrouteGroup, struct RoutingInfo *routingInfo , char nodeType=BIN_ROUTE_SWITCH_NODE );
        int changeRouteStatusByGroup( char *binrouteGroup, struct RoutingInfo *routingInfo, char routeStatus, char *broadcastStr, char nodeType=BIN_ROUTE_SWITCH_NODE);
        int getRouteEntriesByGroup( char *binrouteGroup, struct RoutingInfo *routingInfo, char nodeType=BIN_ROUTE_SWITCH_NODE );
        int markRouteUpByGroup( char *binrouteGroup, struct RoutingInfo *routingInfo, char nodeType=BIN_ROUTE_SWITCH_NODE );
	/* timeout counter */
	void incCounter(struct RoutingInfo *routingBuf);
	int getRouteEntries(struct RoutingInfo *routingInfo);
	void resetCounter(struct RoutingInfo *routingInfo);
	int checkTimeoutCounterVal(struct RoutingInfo *routingInfo, int numTimeoutVal);

protected:
	int createPseudoSharedMemory();
	int instProfileImpacted(struct s_binroute*changeEntry, int status);
};

//	>>>	R030592
class BinRouteForInstProfile : public BinRoute
{
	public :
		BinRouteForInstProfile();
		~BinRouteForInstProfile();
		int setInstProfiles( struct InstProfilesList* iplist, int cnt );
		int indxInstProfileInList( int id, char* networkId, long routeHashValue );
                int indxInstProfileInList( char *group, char* networkId, long routeHashValue );
                int chooseRouteByIPList(struct RoutingInfo *routingBuf, int* outbound, int routeRemoteSite=false );

	protected:
		int _nbrOfIps;
		struct InstProfilesList* _ipFirst;
};
//	>>>	R030592

extern char getRouteEntriesBinrouteGroup[sizeof(_nouse->binroute_group)];

#endif

