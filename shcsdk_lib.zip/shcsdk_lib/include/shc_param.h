/*
 *  Copyright (C) 2004 eFunds Corporation ("eFunds").  All Rights Reserved.     
 *  eFunds Canada Corporation is an authorized user.                            
 *                                                                              
 *  IST is a registered trademark of eFunds Corporation.  Other brand or        
 *  product names are trademarks or registered trademarks of their respective   
 *  holders.                                                                    
 *                                                                              
 *  The information contained herein is the unpublished proprietary property    
 *  of eFunds.  Except as specifically authorized in writing by eFunds, the     
 *  holder of this document shall: i) keep all information contained herein     
 *  confidential, and ii) protect the information, in whole or in part, from    
 *  disclosure and dissemination to all third parties.                          
 *                                                                          
 *  This document and the software described in it are furnished under license  
 *  and may be used or copied only in accordance with the terms of such license.
 *  This document is supplied for information purposes only, is subject to      
 *  change without notice, and should not be construed as a commitment by       
 *  either eFunds Corporation or eFunds Canada Corporation. 
 */
/*
#pragma ident "@(#) shc_param.h 1.2 04/06/10 10:51:40"   
 *
 *                        MODIFICATION HISTORY                  REVIEW
 *
 *	SPR#	Who	Date	Description			Who	Date   
 * ===========================================================================
 *R008717 ztang 15Dec02 Created for multi-institution support
 *R010604 jyang 19Mar04 Moved the total advice route parameter into class
 */

#ifndef SHC_PARAM_INCLUDE
#define SHC_PARAM_INCLUDE

#if !defined( SHCDLLEXPORT )
#   if defined( WIN32 )
#       define SHCDLLEXPORT __declspec(dllimport)
#   else
#       define SHCDLLEXPORT
#   endif
#endif


#ifdef PREPROC_MT_LIB

#if defined ( SHCDLLEXPORT )
#   undef     SHCDLLEXPORT
#   define    SHCDLLEXPORT
#endif


#endif

#include <string.h>
#include <institutionparams.h>
#include <instparamslist.h>
#include <parameteritems.h>
#include <shc.h>


class SHCDLLEXPORT ShcInstParamsList: public InstParamsList
{

public:
	virtual void Load();
	virtual ShcInstParamsList* clone() {return(new ShcInstParamsList(*this));};
	int	getShcActionOnPosauthTimeout() { return shcActionOnPosauthTimeout; }
	int getShc_dev_confirm_timeout() { return shc_dev_confirm_timeout; }
	int getNotify_on() { return notify_on; }
	int getShcDuplicateResponse() { return shcDuplicateResponse; }
	struct a_msgmap * getA_msgmap () { return a_msgmap; }
	int getNumAdviceRoute() { return n_amsg; }		// R010604
private:
	int				shc_dev_confirm_timeout;
	int				shcActionOnPosauthTimeout;
	int				shcDuplicateResponse;
	int				notify_on;
	struct  a_msgmap    *a_msgmap;
	int		n_amsg;		// R010604
};





#endif
