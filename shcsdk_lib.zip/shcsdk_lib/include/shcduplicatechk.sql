/*
 *  Copyright (C) 2004 eFunds Corporation ("eFunds").  All Rights Reserved.     
 *  eFunds Canada Corporation is an authorized user.                            
 *                                                                              
 *  IST is a registered trademark of eFunds Corporation.  Other brand or        
 *  product names are trademarks or registered trademarks of their respective   
 *  holders.                                                                    
 *                                                                              
 *  The information contained herein is the unpublished proprietary property    
 *  of eFunds.  Except as specifically authorized in writing by eFunds, the     
 *  holder of this document shall: i) keep all information contained herein     
 *  confidential, and ii) protect the information, in whole or in part, from    
 *  disclosure and dissemination to all third parties.                          
 *                                                                          
 *  This document and the software described in it are furnished under license  
 *  and may be used or copied only in accordance with the terms of such license.
 *  This document is supplied for information purposes only, is subject to      
 *  change without notice, and should not be construed as a commitment by       
 *  either eFunds Corporation or eFunds Canada Corporation. 
 *                    
 *  #pragma ident "@(#) shcduplicatechk.sql 1.19 14/06/26 15:04:59";
 */
CREATE TABLE shcduplicatechk
(
	site_id				int NOT NULL,
        pan                             pan_token_t(19 byte) NOT NULL,
        created                         date,
	updated 			date,
        lasttxntime                     int,
	lasttxnamt			number(26,8),
	lasttxntermid			char(8 byte),
	lasttxnacquirer 		char(10 byte),
	lasttxnauthnum			char(6 byte),
	lasttxnrespcode		        int
		
);

CREATE UNIQUE INDEX shcduplicatechk_id ON shcduplicatechk (site_id, pan); 
