/*
 *  Copyright (C) 2004 eFunds Corporation ("eFunds").  All Rights Reserved.     
 *  eFunds Canada Corporation is an authorized user.                            
 *                                                                              
 *  IST is a registered trademark of eFunds Corporation.  Other brand or        
 *  product names are trademarks or registered trademarks of their respective   
 *  holders.                                                                    
 *                                                                              
 *  The information contained herein is the unpublished proprietary property    
 *  of eFunds.  Except as specifically authorized in writing by eFunds, the     
 *  holder of this document shall: i) keep all information contained herein     
 *  confidential, and ii) protect the information, in whole or in part, from    
 *  disclosure and dissemination to all third parties.                          
 *                                                                          
 *  This document and the software described in it are furnished under license  
 *  and may be used or copied only in accordance with the terms of such license.
 *  This document is supplied for information purposes only, is subject to      
 *  change without notice, and should not be construed as a commitment by       
 *  either eFunds Corporation or eFunds Canada Corporation. 
 */
/*
	Run time information for a card
*/

create table shccard (
	pan				pan_token_t(19) not null,		/*	pan (key) null */
	mask_pan		char(19) null,	
	created		 date,			/*	date created */

	/*	Hot card status */
	status			int,		/*	0x1 = hot */

	/*	Store and Forward status */
	safdate			int,		/* stored as unix time */
	safnum			int,		/* number of transactions */
	safamount		money,			/* amount taken so far */

	/*	Pin retries paramaters */
	failedpins		smallint,

	cardalert		char(1) null,
	/*	29Apr93 --- Support of Duplicate Authreq txn. */
	lasttxntime		int,		/* Store as unix time */
	lasttxnamt		money,			/* Last approved txn amt */
	lasttxntermid	char(8) null,		/* Last txn terminal Id */
	lasttxnacquirer	char(10) null,		/* Last txn acquirer */
	lasttxnauthnum	char(6) null,		/* Last Authorization number */
	lasttxnrespcode	int,			/* Last txn response code */
	o_rowid			int
)

create unique index shccard_1 on shccard (pan)
create index shccard_rid on shccard (o_rowid)

