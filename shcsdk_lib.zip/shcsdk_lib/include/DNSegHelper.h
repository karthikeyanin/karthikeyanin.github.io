#ifndef _DNSEGHELPER_H_
#define _DNSEGHELPER_H_

static char _DNSegHelper_h_what[] = "@(#) DNSegHelper.h 1.10 14/11/18 10:04:51";

/*
 *  Copyright (C) 2010 FIS Corporation ("FIS").  All Rights Reserved.     
 *  FIS Canada Corporation is an authorized user.                            
 *                                                                              
 *  IST is a registered trademark of FIS Corporation.  Other brand or        
 *  product names are trademarks or registered trademarks of their respective   
 *  holders.                                                                    
 *                                                                              
 *  The information contained herein is the unpublished proprietary property    
 *  of FIS.  Except as specifically authorized in writing by FIS, the     
 *  holder of this document shall: i) keep all information contained herein     
 *  confidential, and ii) protect the information, in whole or in part, from    
 *  disclosure and dissemination to all third parties.                          
 *                                                                          
 *  This document and the software described in it are furnished under license  
 *  and may be used or copied only in accordance with the terms of such license.
 *  This document is supplied for information purposes only, is subject to      
 *  change without notice, and should not be construed as a commitment by       
 *  either FIS Corporation or FIS Canada Corporation. 
 *
 *
 *                        MODIFICATION HISTORY                  REVIEW
 *
 * SCR#     Who    Date  Description
 * ===========================================================================
 * R030491	dipa	20Apr12	Declare POS_SHM_OFFSET and POS_SHM_MASK
 */
 

#include <ShcSdkCommon.h>
#include <shcextbuf.h>
#include <ShcmsgHeader.h>
#include <ShcHelperBase.h>
#include <ist_seg_name.h>
#include <ist_seg_base.h>
#include <ist_seg_list.h>
#include <ist_seg_dn.h>
#include <alt_merchant_id.h>						// 19Apr2010
#include <ShcmsgHeader.h>

#define SHC_DNSegHelper			"DNSegHelper"
#define VOICE_AUTHORIZATION		"MVA"
#define	SIGNATURE_DEBIT			'S'
#define	DEBIT_CARDCATEGORY		'D'
#define	CREDIT_CARDCATEGORY		'C'
#define	OFFSET_SDI				6					// in network_data
#define POS_SHM_OFFSET                          8	//R030491 
#define POS_SHM_MASK                            7	//R030491



//Following a structure of entry in rule. It's a copy from Pos code as shc can not depends on pos.
//For long term solution, we should separate alt_merchant_id from POS system.
typedef struct {
	char 		key[10+30+2+1];
	char			cs_merchant_id[30+1];
} DNSHMEntry_alt_merchant_id;

// -=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
// SPECIAL NOTE:
// This is the later support for DN Segment
// This is the one that should be used instead of the one in shcsdk_srv.  The
// implementation under shcsdk_srv will be removed as soon as possible and
// therefore, should not be used anymore.
// -=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=

class DNSegHelper : public ShcHelperBase
{
public:
	DNSegHelper();

    const char *getName()
    {
        return (const char *)SHC_DNSegHelper;
    }

	int	re_init();

	int 			setAlternateMerchantID (ShcmsgHeader *header, char* instId, char* entId, char* cdscheme);

	// both of these will work on the header value set at initialization
	int	 			setDNSegmentValue(ShcmsgHeader *header);
	char 			setDNCardCategory(ShcmsgHeader *header);

	// 19Apr2010
	char*					altmerchid;
	DNSHMEntry_alt_merchant_id*		ptr_startrec;
	ALT_MERCHANT_ID 		dbRec;
	int						rm_appid;
	struct rules_keytab*	rm_keyp;
	int						pid;
	int						tbl_fd;
	static int				dnCardCategoryBasedOnCardPdt;
protected:
	int				dnSeg_ElfId;
	int				recordSize;
};

#endif

