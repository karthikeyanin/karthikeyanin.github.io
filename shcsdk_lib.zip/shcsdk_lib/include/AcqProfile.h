#ifndef _ACQPROFILE_H_
#define _ACQPROFILE_H_

static char _AcqProfile_h_what[] = "@(#) AcqProfile.h 1.5 10/05/19 15:22:34";

/*
 *  Copyright (C) 2004 eFunds Corporation ("eFunds").  All Rights Reserved.     
 *  eFunds Canada Corporation is an authorized user.                            
 *                                                                              
 *  IST is a registered trademark of eFunds Corporation.  Other brand or        
 *  product names are trademarks or registered trademarks of their respective   
 *  holders.                                                                    
 *                                                                              
 *  The information contained herein is the unpublished proprietary property    
 *  of eFunds.  Except as specifically authorized in writing by eFunds, the     
 *  holder of this document shall: i) keep all information contained herein     
 *  confidential, and ii) protect the information, in whole or in part, from    
 *  disclosure and dissemination to all third parties.                          
 *                                                                          
 *  This document and the software described in it are furnished under license  
 *  and may be used or copied only in accordance with the terms of such license.
 *  This document is supplied for information purposes only, is subject to      
 *  change without notice, and should not be construed as a commitment by       
 *  either eFunds Corporation or eFunds Canada Corporation. 
 *
 *
 *                        MODIFICATION HISTORY                  REVIEW
 *
 * SCR#     Who    Date  Description
 * ===========================================================================
 * R0xxxxx 
 */
 

#include <ShcSdkCommon.h>

#include <multi_inst_def.h>
#include <multi_institution.h>

#include <mt_acq_profile.h>
#include <ShcHelperBase.h>


class AcqProfile : public ShcHelperBase
{
public:
	const char *getName()
	{
		return (const char *)SHC_AcqProfile;
	}
	virtual void locateAcquirer(const char *txnSrc, const char *txnDest, const char *entityId, 
			const int currency, const int merchantType, AcquirerInfo &acquirerInfo, ShcmsgHeader *header=NULL);
	virtual void locateAcquirer(const char *txnSrc, const char *txnDest, const char *entityId, 
			const int currency, const char *deviceType, AcquirerInfo &acquirerInfo, ShcmsgHeader *header=NULL);
	
protected:
	static int initialized;
	static struct AcquirerProfile *acquirerProfileData;
	static struct rules_keytab    *acquirerRuleKeyp;
	static int acquirerProfileAppid;
	
	virtual int Match(const struct AcquirerProfile &ap, const char *txnSrc, 
		const char *txnDest, const char *entityId, const char *deviceType, const char *currencyCode);
	virtual int initialize();


};

#endif

