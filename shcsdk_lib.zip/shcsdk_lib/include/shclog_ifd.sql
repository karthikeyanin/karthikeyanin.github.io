/*
 * Copyright (C) 2004 eFunds Corporation ("eFunds").  All Rights Reserved.
 * eFunds Canada Corporation is an authorized user.
 *
 * IST is a registered trademark of eFunds Corporation.  Other brand or
 * product names are trademarks or registered trademarks of their respective
 * holders.
 *
 * The information contained herein is the unpublished proprietary property
 * of eFunds.  Except as specifically authorized in writing by eFunds, the
 * holder of this document shall: i) keep all information contained herein
 * confidential, and ii) protect the information, in whole or in part, from
 * disclosure and dissemination to all third parties.
 *
 * This document and the software described in it are furnished under license
 * and may be used or copied only in accordance with the terms of such license.
 * This document is supplied for information purposes only, is subject to
 * change without notice, and should not be construed as a commitment by
 * either eFunds Corporation or eFunds Canada Corporation.
 */

/*
*  IST and IST/Share are registered trademarks of Oasis Technology Ltd.
*
*  Copyright (C) 1990 - 2001 Oasis Technology Ltd.
*  All Rights Reserved
*  This Module contains Proprietary Information of
*  Oasis Technology Ltd., and should be treated as Confidential.
*
*  THIS IS UNPUBLISHED PROPRIETARY SOURCE CODE OF OASIS TECHNOLOGY LTD.
*  The copyright notice above does not evidence any
*  actual or intended publication of such source code.
*/
/*
pragma ident "@(#) shclog_ifd.sql 1.2 05/03/01 13:20:16"
*
* Modification History
*
* 			Who	When	Why
* ========================================================================
* R011615 lsun 12Aug04  create to support visa IFD messages
*/

create table shclog_ifd (
	shclog_idx			char(20),
	ifd_data_1			varchar(255) null,	
	ifd_data_2			varchar(255) null
)

create index pkshclog_ifd on shclog_ifd( shclog_idx )	

