#ifndef _ISSPROFILEX_H_
#define _ISSPROFILEX_H_

static char _IssProfileX_h_what[] = "@(#) IssProfileX.h 1.3 14/02/20 03:24:30";

/*
 *  Copyright (C) 2004 eFunds Corporation ("eFunds").  All Rights Reserved.     
 *  eFunds Canada Corporation is an authorized user.                            
 *                                                                              
 *  IST is a registered trademark of eFunds Corporation.  Other brand or        
 *  product names are trademarks or registered trademarks of their respective   
 *  holders.                                                                    
 *                                                                              
 *  The information contained herein is the unpublished proprietary property    
 *  of eFunds.  Except as specifically authorized in writing by eFunds, the     
 *  holder of this document shall: i) keep all information contained herein     
 *  confidential, and ii) protect the information, in whole or in part, from    
 *  disclosure and dissemination to all third parties.                          
 *                                                                          
 *  This document and the software described in it are furnished under license  
 *  and may be used or copied only in accordance with the terms of such license.
 *  This document is supplied for information purposes only, is subject to      
 *  change without notice, and should not be construed as a commitment by       
 *  either eFunds Corporation or eFunds Canada Corporation. 
 *
 *
 *                        MODIFICATION HISTORY                  REVIEW
 *
 * SCR#     Who    Date  Description
 * ===========================================================================
 * R0xxxxx 
 * R012134 Emj 4Oct04 Issuer Entity Support
 * IST_S_120107-5	dipa	20Feb14	Spring Compliance 2014 - Token indicator field in SHCEXTBINDB
 */
 

#include <ShcSdkCommon.h>
#include <mt_extbin.h>
#include <multi_institution.h>
#include <ShcHelperBase.h>
#include <IssProfile.h>


class IssProfileX : public IssProfile
{
public:
	void search_extbin_x(const char *pan, ExtBinResult &searchResult);
	bool isTokenIdSet(const char *pan);
};

#endif

