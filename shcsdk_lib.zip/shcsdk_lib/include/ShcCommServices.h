//
// Copyright (C) 2009 eFunds Corporation ("eFunds").  All Rights Reserved.
// eFunds Canada Corporation is an authorized user.
//
// IST is a registered trademark of eFunds Corporation.  Other brand or
// product names are trademarks or registered trademarks of their respective
// holders.
//
// The information contained herein is the unpublished proprietary property
// of eFunds.  Except as specifically authorized in writing by eFunds, the
// holder of this document shall: i) keep all information contained herein
// confidential, and ii) protect the information, in whole or in part, from
// disclosure and dissemination to all third parties.
//
// This document and the software described in it are furnished under license
// and may be used or copied only in accordance with the terms of such license.
// This document is supplied for information purposes only, is subject to
// change without notice, and should not be construed as a commitment by
// either eFunds Corporation or eFunds Canada Corporation.
//
/*
 *  * Description:
 *   *
 *    *      MODIFICATION HISTORY
 *     *
 *      *  Date         SCR            Who        Description
 *       *  ===========================================================================
 *       */
#ifndef _SHC_COMMSERVICES_H_
#define _SHC_COMMSERVICES_H_

static char _shc_commServices_h_what[] = "@(#) shc_commServices.h 1.0 17/01/22 15:22:34";
struct ShcCommServicesFields
{
	OCString callDate;
	OCString callTime;
	OCString callDurationTime;
	OCString callFromLocationName;
	OCString callFromRegionCode;
	OCString callFromCountryCode;
	OCString callFromPhoneNumber;
	OCString callToLocationName;
	OCString callToRegionCode;
	OCString callToCountryCode;
	OCString callToPhoneNumber;
	OCString phoneCardId;
	OCString serviceDescription;
	OCString billingPeriod;
	OCString communicationsCallTypeCode;
	OCString communicationsRateClass;
};


class ShcCommServices
{
	char buff[1300];
	int len;
public:
	ShcCommServices();
	void setTagValue(char *TagName, const char *TagValue);
	void setTagValue(char *TagName, int TagValue);
	void setTagValue(char *TagName, double TagValue);
	char* getBuffer();
	int getBufferLength();
};

#endif

