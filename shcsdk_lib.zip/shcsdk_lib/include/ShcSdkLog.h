#ifndef _SHCSDKLOG_H_
#define _SHCSDKLOG_H_

static char _ShcSdkLog_h_what[] = "@(#) ShcSdkLog.h 1.4 14/04/01 14:33:23";

/*
 *  Copyright (C) 2004 eFunds Corporation ("eFunds").  All Rights Reserved.     
 *  eFunds Canada Corporation is an authorized user.                            
 *                                                                              
 *  IST is a registered trademark of eFunds Corporation.  Other brand or        
 *  product names are trademarks or registered trademarks of their respective   
 *  holders.                                                                    
 *                                                                              
 *  The information contained herein is the unpublished proprietary property    
 *  of eFunds.  Except as specifically authorized in writing by eFunds, the     
 *  holder of this document shall: i) keep all information contained herein     
 *  confidential, and ii) protect the information, in whole or in part, from    
 *  disclosure and dissemination to all third parties.                          
 *                                                                          
 *  This document and the software described in it are furnished under license  
 *  and may be used or copied only in accordance with the terms of such license.
 *  This document is supplied for information purposes only, is subject to      
 *  change without notice, and should not be construed as a commitment by       
 *  either eFunds Corporation or eFunds Canada Corporation. 
 *
 *                        MODIFICATION HISTORY                  REVIEW
 *
 *  SPR#    Who Date    Description         Who Date
 * ===========================================================================
 *
 *
 */


#include <shc.h>
#include <shcextbuf.h>
#include <ShcHelperBase.h>

class ShcHeader;

#define IST_SHCLOG_FLAG_LOCATE_FIRST        0x00000001
#define IST_SHCLOG_FLAG_USE_CHIP_INDEX      0x00000002
#define IST_SHCLOG_FLAG_LOCATE_REQ      0x00000004
#define IST_SHCLOG_FLAG_LOCATE_RESP     0x00000008

class ShcSdkLog : public ShcHelperBase
{
public:
    const char *getName()
    {
        return (const char *)SHC_ShcSdkLog;
    }

			/* Log <shcmsg> into shclog as a new transaction. */
	virtual int logTxn(ShcHeader *header) { return 0; };
	
			/* If <shcmsg> has not been logged into shclog, log <shcmsg>.
			 * If <shcmsg> has been logged in shclog, returns:
			 *		 3 for reversed advice
			 *		 2 for request
			 *		 1 otherwise
			 */
	virtual int logRepeat(ShcHeader *header) { return 0; };

			/* Locate an tranasaction using shclog_1 index */
	virtual int locateTxn( ShcHeader *header ) { return 0; };
			/* Rewind the tables to release lock */
	virtual int rewind() { return 0; };
	
    	
};

#endif
