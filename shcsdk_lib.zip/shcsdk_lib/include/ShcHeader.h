#ifndef _SHCHEADER_H_
#define _SHCHEADER_H_

static char _ShcHeader_h_what[] = "@(#) ShcHeader.h 1.7 17/08/02 12:56:19";
/*
 *  Copyright (C) 2004 eFunds Corporation ("eFunds").  All Rights Reserved.     
 *  eFunds Canada Corporation is an authorized user.                            
 *                                                                              
 *  IST is a registered trademark of eFunds Corporation.  Other brand or        
 *  product names are trademarks or registered trademarks of their respective   
 *  holders.                                                                    
 *                                                                              
 *  The information contained herein is the unpublished proprietary property    
 *  of eFunds.  Except as specifically authorized in writing by eFunds, the     
 *  holder of this document shall: i) keep all information contained herein     
 *  confidential, and ii) protect the information, in whole or in part, from    
 *  disclosure and dissemination to all third parties.                          
 *                                                                          
 *  This document and the software described in it are furnished under license  
 *  and may be used or copied only in accordance with the terms of such license.
 *  This document is supplied for information purposes only, is subject to      
 *  change without notice, and should not be construed as a commitment by       
 *  either eFunds Corporation or eFunds Canada Corporation. 
 *
 *                        MODIFICATION HISTORY                  REVIEW
 *
 * SCR#     Who    Date  Description
 * ===========================================================================
 * R0xxxxx 
 * R020052 spa	21May07	Added definitions for FMCMDHeader, ShcmsgFMHeader
 */

class ShcBin;
//#include <ShcBin.h>
class ShcSdkLog;
//#include <ShcSdkLog.h>



//procFlag definitions
#define TXN_PROC_SKIP_ENRICH 	0x0001
#define TXN_PROC_SKIP_RESTORE 	0x0002
#define TXN_PROC_SKIP_EDIT 		0x0004
#define TXN_PROC_SKIP_VERIFY	0x0008
#define TXN_PROC_SKIP_DOWORK 	0x0010
#define TXN_PROC_SKIP_POST_PROC 0x0020
#define TXN_PROC_SKIP_NOTIFY	0x0040

//statusFlag definitions
#define TXN_PROC_DENIED			0x0001
#define TXN_PROC_DROPPED		0x0002
#define TXN_PROC_APPROVED		0x0003
#define TXN_PROC_LATE_RESP		0x0004
#define SHC_ShcmsgHeader 		"ShcmsgHeader"
#define SHC_Shc300Header		"Shc300Header"
#define SHC_FMCMDHeader			"FMCMDHeader"		//	---	R020052
#define SHC_ShcmsgFMHeader		"ShcmsgFMHeader"	//	---	R020052
#define SHC_ShcmsgODHeader		"ShcmsgODHeader"

class ShcHeader
{
public:
	ShcBin *issShcBin;	//Stores binpkg, key, pin information for issuer bin
	ShcBin *acqShcBin;	//Stores binpkg, key, pin information for issuer bin

	int senderId;
	int flag;			//Definitions are following the class

	int repeatFlag;
	
	int returnFlag;
//	int ignoreFlag; 	//Txn will be dropped, skip rest of the edit/verify/doWork
//	int skipFlag;		//txn is approved, skip rest of the edit/verify
//	int lateRespFlag; 	//The txn is a late response
	int denyRespCode;	//Txn is denied with the code
	
	int logFlag;		//Definitions are following the class
	
	int   shcerr;		//flags of routing
	long  time_in;		//Time the txn is in
	long  time_out;		//Time the txn is out
	int   eventId;		//event id if the message is a event
	int   applMailboxId;	//application mailbox id if the msg will be sent to a application
	ShcSdkLog *shcLogObj;		//The shclog object that should be used
	
	ShcHeader();
	ShcHeader(ShcHeader &oldHeader);
	
	virtual ~ShcHeader();

	virtual const char *getName() = 0;
		
	virtual void copyFromHeader(ShcHeader *hd);
	int createdInternal();
	int issBinValid();
	int acqBinValid();
	void setIgnoreFlag();
	void setReturnFlag(int respcode);
	void setSkipFlag(unsigned short skipFlag = 
						TXN_PROC_SKIP_ENRICH |
						TXN_PROC_SKIP_RESTORE |
						TXN_PROC_SKIP_EDIT | 
						TXN_PROC_SKIP_VERIFY |
						TXN_PROC_SKIP_DOWORK
					);	//No more edit or verification needed, the txn is approved
	int shouldContinue(unsigned short stepFlag);
	
	void setLateRespFlag() { statusFlag |=  TXN_PROC_LATE_RESP;};
	virtual void setSenderId(int newSenderId) {};
	virtual void setTxnStartTime() { };
	virtual int toShcStruct(struct shc *shcP) { return 0; };
	virtual int fromShcStruct(struct shc *shcP) { return 0; };
	virtual int setAcqShcBin(char *bin);
	virtual int setIssShcBin(char *bin);

	unsigned short procFlag; 	//This is defined as bit flags to indicate what processing step 
								//should be skipped. The definiation of each bit is defined 
								//before the class
protected:
	
	unsigned short statusFlag;	//This is defined as bit flags to indicate the decision for this
								//txn. The definiation of each bit is defined before the class
};

#endif
