INSERT INTO shcbin_counter (networkid) VALUES ( 1 );
