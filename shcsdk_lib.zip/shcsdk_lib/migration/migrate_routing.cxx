static char _shcinit_cxx_what[] = "@(#) migrate_routing.cxx 1.2 15/04/10 16:03:25";

/*
 *  Copyright (C) 2004 eFunds Corporation ("eFunds").  All Rights Reserved.     
 *  eFunds Canada Corporation is an authorized user.                            
 *                                                                              
 *  IST is a registered trademark of eFunds Corporation.  Other brand or        
 *  product names are trademarks or registered trademarks of their respective   
 *  holders.                                                                    
 *                                                                              
 *  The information contained herein is the unpublished proprietary property    
 *  of eFunds.  Except as specifically authorized in writing by eFunds, the     
 *  holder of this document shall: i) keep all information contained herein     
 *  confidential, and ii) protect the information, in whole or in part, from    
 *  disclosure and dissemination to all third parties.                          
 *                                                                          
 *  This document and the software described in it are furnished under license  
 *  and may be used or copied only in accordance with the terms of such license.
 *  This document is supplied for information purposes only, is subject to      
 *  change without notice, and should not be construed as a commitment by       
 *  either eFunds Corporation or eFunds Canada Corporation. 
 */
/*
 *
 *                        MODIFICATION HISTORY                  REVIEW
 *
 *	SPR#   Who	 Date    Description			Who	Date   
 * ===========================================================================
 * R000000 ztang 23Mar15 Creation for routing change, add binroute group
 */

//File Number 137

#include <stdio.h>
#include <string.h>
#include <oasis.h>
#include <oasisenv.h>
#include<ic/ic_instid.h>
#include<ic/ic_bin.h>
#include <ist_argv0.h>
#include <ist_otrace.h>
#include <util.h>
#include <mb.h>
#include <rules.h>

/* R002563 */
#include <DBM3.h>
#include <dbm.h>
#include <dbm_private.h>

#include <HaPtmCctHelper.h>
#include <inst_profile.h>
#include <binroute.h>
#include <shcbin.h>

/*
 *	Example application initialiser
 */

int dbmid = -1;

int main(int a_rgc, char **a_rgv)
{
	int aRet = 0 ;
	int retval = 0;


	argv0 = *a_rgv;
	catch_all_signals(NULL);

	OTraceOn(argv0);

	HaPtmCctHelper::deinit() ;
	
	if(dbm_init() == -1)
	{
		aRet = -1 ;
		printf("dbm_init fail, abort\n");
		return 0;
	}

	dbmid = getpid();
	long dbbuf[240];
	int fd = -1;
	int fd2 = -1;
	INST_PROFILE *ip = (INST_PROFILE *)dbbuf;
	int success_num = 0;

	//Add binroute_group in inst_profile table
	if((fd = dbm_open("inst_profile_i", dbmid)) <0)
	{
		printf("Can Not Open inst_profile_i Db.  Err: %d.\n", dbm_errno);
		goto migrate_binroute;
	}

	memset(dbbuf, 0, sizeof(dbbuf));

	int i;
	for(i = 0;; ++i)
	{
		if(i==0)
			retval = dbm_read(fd, (char *)ip, DBM_RFIRST|DBM_RLOCK);
		else
			retval = dbm_read(fd, (char *)ip, DBM_RNEXT|DBM_RLOCK);

		if(retval == -1)
			if(dbm_errno == DBME_NOTFOUND || dbm_errno == DBME_EOF)
				break;
			else
			{
				printf("Database error when reading inst_profile: %d\n", dbm_errno);
				dbm_rollback(0);
				success_num = 0;
				break;
			}
		if (!ip->binroute_group[0])
		{
			sprintf(ip->binroute_group, "%d", (int)ip->id);
			retval = dbm_write(fd, (char *)ip, 0);
			if(retval == -1)
			{
				printf("Database error: %d when writing back id(%d)\n", dbm_errno, (int)ip->id);
				dbm_rollback(0);
				success_num = 0;
				break;
			}
			else
			{
				printf("inst_profile id(%d) migrated.\n", (int)ip->id);
				success_num++;
			}
		}
	}
	retval = dbm_commit(0);
	if(retval == -1)
	{
		printf("Database error: %d when commit inst_profile change\n", dbm_errno);
	}
	else
		printf("inst_profile %d entries migrated.\n", (int)success_num);

migrate_binroute:
	//Move binroute entries, default binroute_group to inst_profile_id
	BINROUTE *br = (BINROUTE *)dbbuf;
	memset(dbbuf, 0, sizeof(dbbuf));
	SHCBIN bin = { 0 };
	int numBinChanged = 0;
	
	if((fd = dbm_open("binroute_ix", dbmid)) <0)
	{
		printf("Can Not Open binroute_ix Db.  Err: %d.\n", dbm_errno);
		goto migration_end;
	}
	if((fd2 = dbm_open("shcbin_ix_2", dbmid)) <0)
	{
		printf("Can Not Open shcbin Db.  Err: %d.\n", dbm_errno);
		goto migration_end;
	}
	for(i = 0;; ++i)
	{
		if(i==0)
			retval = dbm_read(fd, (char *)br, DBM_RFIRST|DBM_RLOCK);
		else
			retval = dbm_read(fd, (char *)br, DBM_RNEXT|DBM_RLOCK);

		if(retval == -1)
			if(dbm_errno == DBME_NOTFOUND || dbm_errno == DBME_EOF)
				break;
			else
			{
				printf("Database error when reading birnoute: %d\n", dbm_errno);
				dbm_rollback(0);
				success_num = 0;
				break;
			}
		if (!br->binroute_group[0])
		{
			sprintf((char *)br->binroute_group, "%d", br->inst_profile_id);

			retval = dbm_write(fd, (char *)br, 0);
			if(retval == -1)
			{
				printf("Database error: %d when writing binroute id(%d)\n", dbm_errno, (int)br->inst_profile_id);
				dbm_rollback(0);
				success_num = 0;
				break;
			}
		}

		strcpy(bin.institutionid, br->institutionid);
		strcpy(bin.userbinid, br->userbinid);
		retval = dbm_read(fd2, (char *)&bin, DBM_REQUAL|DBM_RLOCK);

		if(retval == -1)
			if(dbm_errno == DBME_NOTFOUND || dbm_errno == DBME_EOF)
				continue;
			else
			{
				printf("Database error when reading bin: %d\n", dbm_errno);
				dbm_rollback(0);
				success_num = 0;
				numBinChanged = 0;
				break;
			}
		if (!bin.mailbox[0])
		{
			strcpy(bin.mailbox, br->mailbox);

			retval = dbm_write(fd2, (char *)&bin, 0);
			if(retval == -1)
			{
				printf("Database error: %d when writing bin (%s,%s)", dbm_errno, bin.institutionid, bin.userbinid);
				dbm_rollback(0);
				success_num = 0;
				numBinChanged = 0;
				break;
			}
			printf("Bin(%s,%s) added mailbox(%s).\n", bin.institutionid, bin.userbinid, bin.mailbox);
			numBinChanged ++;
		}
		printf("binroute record with inst_profile id(%d) migrated.\n", (int)br->inst_profile_id);
		success_num++;
		
	}

migration_end:
	retval = dbm_commit(0);
	if(retval == -1)
	{
		printf("Database error: %d when commit binroute change\n", dbm_errno);
	}
	else
	{
		printf("binroute %d entries migrated.\n", (int)success_num);
		printf("bin %d entries migrated.\n", (int)numBinChanged);
	}

	return(0);
}

